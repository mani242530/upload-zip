'use strict';

const path = require('path');
const fs = require('fs');
const url = require('url');

// Make sure any symlinks in the project folder are resolved:
// https://github.com/facebookincubator/create-react-app/issues/637
const appDirectory = fs.realpathSync(process.cwd());
const resolveApp = relativePath => path.resolve(appDirectory, relativePath);

const envPublicUrl = process.env.PUBLIC_URL;

function ensureSlash(path, needsSlash) {
  const hasSlash = path.endsWith('/');
  if (hasSlash && !needsSlash) {
    return path.substr(path, path.length - 1);
  } else if (!hasSlash && needsSlash) {
    return `${path}/`;
  } else {
    return path;
  }
}

const getPublicUrl = appPackageJson =>
  envPublicUrl || require(appPackageJson).homepage;

// We use `PUBLIC_URL` environment variable or "homepage" field to infer
// "public path" at which the app is served.
// Webpack needs to know it to put the right <script> hrefs into HTML even in
// single-page apps that may serve index.html for nested URLs like /todos/42.
// We can't use a relative path in HTML because we don't want to load something
// like /todos/42/static/js/bundle.7289d.js. We have to know the root.
function getServedPath(appPackageJson) {
  const publicUrl = getPublicUrl(appPackageJson);
  const servedUrl =
    envPublicUrl || (publicUrl ? url.parse(publicUrl).pathname : '/');
  return ensureSlash(servedUrl, true);
}

// config after eject: we're in ./config/
module.exports = {
  dotenv: resolveApp('.env'),
  appBuild: resolveApp('build'),
  appPublic: resolveApp('public'),
  appPackageJson: resolveApp('package.json'),
  serverSrc: resolveApp('src/server'),
  clientSrc: resolveApp('src/client'),
  appSrc: resolveApp('src'),
  testsSetup: resolveApp('src/setupTests.js'),
  appNodeModules: resolveApp('node_modules'),
  ownNodeModules: resolveApp('node_modules'),
  yarnLockFile: resolveApp('yarn.lock'),
  publicUrl: getPublicUrl(resolveApp('package.json')),
  servedPath: getServedPath(resolveApp('package.json')),

  // ULTA SPECIFIC CONFIGURATION BELOW

  config: resolveApp('config'),
  ssrIndex: resolveApp('src/server/server.js'),


  appHtml: resolveApp('public/index.html'), //updated route to index.html
  appIndexJs: resolveApp('src/client/mhp/mhp.js'),  //updated route to index.js

  bagHtml: resolveApp('public/bag/index.html'), //updated route to cart.html
  bagIndexJs: resolveApp('src/client/ccr/cart.js'),

  applyHtml: resolveApp('public/creditcards/index.html'),
  appAbuyJs: resolveApp('src/client/abuy/abuy.js'),

  pdpHtml: resolveApp('public/pdp/index.html'),
  pdpJs: resolveApp('src/client/pdp/pdp.js'),

  externalHtml: resolveApp('public/external/index.html'),
  appExternalJs: resolveApp('src/client/hf/external.js'),

  emailSignUpHtml: resolveApp('public/esu/index.html'),
  emailSignUpJs: resolveApp('src/client/esu/esu.js'),



};
