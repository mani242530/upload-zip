#!/usr/bin/env node

const findRemove = require('find-remove');
const path = require('path');
const spawn = require('cross-spawn');
const script = process.argv[2];
const args = process.argv.slice(3);

switch(script) {
		case 'start':
			findRemove(path.join(process.cwd(), 'src'), { extensions: '.css' });
			//tmp fix to remove generated css files from blade, and jeet
			findRemove(path.join(process.cwd(), 'node_modules/jeet'), { extensions: '.css' });

			const reactScripts = spawn('node', [require.resolve('./' + script)].concat(args), {
							stdio: 'inherit'
						});

			const sassBuild = spawn('node-sass', ['src', '--output', 'src'], {
							stdio: 'inherit'
						});

			const sassWatch = spawn('node-sass', ['src', '--watch', '--output', 'src'], {
							stdio: 'inherit'
						});

			break;

		case 'build':
			findRemove(path.join(process.cwd(), 'src'), { extensions: '.css' });
			//tmp fix to remove generated css files from blade, and jeet
			findRemove(path.join(process.cwd(), 'node_modules/jeet'), { extensions: '.css' });

			spawn.sync('node-sass', ['src', '--output', 'src'], {
							stdio: 'inherit'
						});

		  spawn('node', [require.resolve('./' + script)].concat(args), {
							stdio: 'inherit'
						});

			break;

		default:
			console.log('Unknown script: ' + script);
			console.log('Perhaps you meant to run `react-scripts` or `react-scripts-with-sass start`');
			break;
}
