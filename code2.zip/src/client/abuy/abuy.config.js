import { getLocation } from 'utils/Domain/Domain';
export default {

  DEBUGGING: {
    LOGGING: {
      SCRIPT_TAG_LOGS: false,
      TRACK_DATA_LAYER_LOGS: false,
      TRACK_ANALYTICS_LOGS : false,
      DISABLE_SESSIONCAM: false,
      TRACK_REDUX_EVENTS: true,
      TRACK_SAGA_FAILURES: true
    },
    USER: {
      isSignedIn: false,
      isRewardsMember: true,
      rewardStatus: 'Member', // Member/Platinum/Diamond
      isEmailOptIn: false
    },

    CART: {
      cartQty: '4'
    }
  },
  ENABLE_QUBIT: true,
  ENABLE_REFLEKTION: true,
  ENABLE_SESSIONCAM: true,

  SECONDS_TO_WAIT_FOR_SIGNAL_TIMEOUT: 2,

  SERVICES: {

    SESSION_BLACK_LIST: [
      'session',
      'navigation',
      'switches',
      'page',
      'user'
    ],

    searchTypeAhead:  ( process.env.NODE_ENV === 'production' ) ? `${ getLocation().origin }/ulta/assembler?assemblerContentCollection=/content/Shared/Search%20box` : '/services/search/typeAhead',

    banner: '/services/v1/page/section/banner',

    page: '/services/v1/page',

    productRecs: '/services/v1/prodrecs',

    session: '/services/v1/session/token',

    switches: '/services/v1/global/config',

    applyForm: '/services/v1/user/cc/apply',

    prescreenApply: '/services/v1/user/cc/prescreenApply',

    lpsLookUp : '/services/v1/user/rewards/lookup',

    lpsLookupByPrescreenId: '/services/v1/user/cc/rewards/lookupByPrescreenId',

    user: '/services/v2/user/lite',

    login: '/services/v1/user/login',

    createAccount: '/services/v1/user/create',

    addressbook: '/services/v1/user/profile/addressbook',

    profileCreditCards: '/services/v1/user/profile/creditcards',

    RealtimeOLPS: '/services/v1/user/cc/prescreen',

    preScreenLPSEvent: '/services/v1/user/cc/event/prescreenoffer',

    profile: '/services/v1/user/profile',

    rewardsLookup:'/services/v1/user/rewards/lookupMember',

    readCart: '/services/v1/cart',

    loadCart: '/services/v1/cart/load',

    initiateCheckout: '/services/v1/cart/validateCheckout',

    submitCreditCard: '/services/v1/cart/payments/update',

    getQualifiedShipMethod: '/services/v1/cart/shipping/shipmethods',

    shippingUpdate: '/services/v1/cart/shipping/update',

    estimatedDeliveryDate: '/services/v1/cart/shipping/edd',

    addProductSamples: '/services/v1/cart/sample/add',

    removeProductSamples: '/services/v1/cart/sample/remove',

    removeItemFromCart: '/services/v1/cart/items/remove',

    addItemToCart: '/services/v1/cart/items/add',

    selectGiftVariant: '/services/v1/cart/gwp/update',

    updateCartItems: '/services/v1/cart/items/update',

    removeGiftFromCart: '/services/v1/cart/items/remove',

    applycoupon: '/services/v1/cart/coupon/add',

    removecoupon: '/services/v1/cart/coupon/remove',

    addGiftNote: '/services/v1/cart/giftoptions/update',

    addGiftWrap: '/services/v1/cart/giftoptions/update',

    redeemPoints : '/services/v1/cart/rewards/redeemLevels',

    paymentServiceResponse: '/services/v1/cart/payments/update',

    paypalToken: '/services/v1/cart/payments/paypal/token',

    applyPayment: '/services/v1/cart/payments/update',

    applyExpressPayment: '/services/v1/cart/payments/paypal/express',

    removePaymentService: '/services/v1/cart/payments/remove',

    submitOrderService : '/services/v1/cart/submit',

    navigation: '/services/v2/page/nav',

    logout: '/services/v1/user/logout',

    userRewards: '/services/v1/user/rewards/create'

  }
}
