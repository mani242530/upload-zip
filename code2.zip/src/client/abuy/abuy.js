/**
 * index.js
 *
 * this is the entry file for the application and is only used for setup code
 *
 */

// Needed for redux-saga es6 generator support
import 'babel-polyfill';
import 'shared/theme/theme.css';

// ReactJS specific imports
import React from 'react';
import { renderComponent } from 'utils/ReactDOM/rendering';
import shimReady from 'static/js/shim';
import { isServer } from 'utils/DeviceDetection/deviceDetection';

// Redux specific imports
import { Provider } from 'react-redux';

// i18n (internationalization) imports
import LanguageProvider from 'shared/components/LanguageProvider/LanguageProvider';

// Application component imports
import Global from 'shared/components/Global/Global';
import Header from 'hf/components/Header/Header';
import CreditCards from 'abuy/components/CreditCards/CreditCards';
import Footer from 'hf/components/Footer/Footer'

import { translationMessages } from 'shared/components/LanguageProvider/i18n';
import configureStore from 'abuy/abuy.store';
import {
  BrowserRouter as Router,
  Route
} from 'react-router-dom';

import CONFIG from 'abuy/abuy.config';

import createBrowserHistory from 'history/createBrowserHistory';

import { setConfig } from 'utils/Ajax/Ajax';
setConfig( CONFIG );

import {
  loadState,
  saveState
} from 'utils/LocalStorage/LocalStorage';


import throttle from 'lodash/throttle';

const history = createBrowserHistory();

const persistedState = loadState();
const store = configureStore( persistedState, CONFIG );

store.subscribe( () => {
  let state = store.getState();

  saveState( {
    session: state.session,
    // To fix the sticky footer displayed multiple times in same session when switching between REACT page because SFD (Sticky Footer Displayed) session cookie is deleted or not persisting
    // To save & restore emailSignUp sfd session cookie
    emailSignUp: state.esu.stickyEmailSignUp.sessionData,
    searchInputValue: state.typeaheadsearch.inputValue,
    selectedTerm: state.typeaheadsearch.selectedTerm
  } );
} );

export const render = ( messages ) => {

  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Global />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-global' )
  );


  // HEADER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Header />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileHeader' )
  );


  const baseRoute = '/creditcards';
  // ( process.env.NODE_ENV === 'production' ) ? '/ui/creditcards' : '/creditcards' ;

  // BODY
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>

        <Router
          history={ history }
          basename={ baseRoute }
        >
          <Route
            path='/'
            component={ CreditCards }
          />
        </Router>

      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileBody' )
  );


  // FOOTER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Footer />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileFooter' )
  );
}

// Hot reloadable translation json fiels
if( module.hot ){
  // modules.hot.accept does not accept dynamic dependencies,
  // have to be constants at compile-time
  module.hot.accept( 'shared/components/LanguageProvider/i18n', () => {
    render( translationMessages );
  } );
}

// new polyfill for browsers without Intl support
shimReady( () => {
  render( translationMessages )
} );
