import { render } from './abuy';
import { translationMessages } from 'shared/components/LanguageProvider/i18n';
import * as shim from 'static/js/shim';

jest.mock( 'static/js/shim', () => {
  return jest.fn();
} );

describe( 'abuy test', () => {

  it( 'should be able to execute render method without crashing', () => {

    let appElement = document.createElement( 'div' );
    appElement.id='js-global';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id='js-mobileHeader';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id='js-mobileBody';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id='js-mobileFooter';
    document.body.appendChild( appElement );

    render( translationMessages );
    expect( document.getElementById( 'js-mobileHeader' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'js-mobileFooter' ).innerHTML ).not.toBe( '' );

  } );
} );