/**
 * AdsformDecorator
 */

import React from 'react';
import PropTypes from 'prop-types';
import './AdsformDecorator.css';
import Divider from 'shared/components/Divider/Divider';
import Image from 'shared/components/Image/Image';
import CancelAndReturn from 'shared/components/CancelAndReturn/CancelAndReturn';
import messages from './AdsformDecorator.messages';
import { formatMessage } from 'shared/components/Global/Global';

const propTypes = {
  bannerImageUri: PropTypes.string,
  cancelSteps: PropTypes.number
}

const defaultProps = {
  bannerImageUri: 'https://images.ulta.com/is/image/Ulta/wk1117_m_banner_ccard_application_header_fallback'
}

/**
 * Class
 * @extends React.Component
 */
const AdsformDecorator = ( props ) => {

  /**
   * Create a AdsformDecorator
   */
  const {
    bannerImageUri
  } = props;


  /**
   * Renders the AdsformDecorator component
   */

  return (
    <div className='AdsformDecorator'>
      <div className='AdsformDecorator__divider'>

        <Divider dividerType='gray' />
      </div>

      <CancelAndReturn
        cancelText={ formatMessage( messages.cancel ) }
        history={ history }
        cancelSteps={ props.cancelSteps }
      />

      <div className='AdsformDecorator__banner'>
        <Image
          src={ bannerImageUri }
          alt={ formatMessage( messages.title ) }
          scale='scl=1'
        />
      </div>

      <div
        className='AdsformDecorator__container'
        id='js-AdsformDecorator__container'
      >
        { props.children }
      </div>

    </div>
  );
}

AdsformDecorator.propTypes = propTypes;
AdsformDecorator.defaultProps = defaultProps;

export default AdsformDecorator;
