import React from 'react';
import ReactDOM from 'react-dom';
import AdsformDecorator from './AdsformDecorator';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

describe( '<AdsformDecorator />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <AdsformDecorator /> );
    expect( component.find( 'AdsformDecorator' ).length ).toBe( 1 );
  } );
} );
