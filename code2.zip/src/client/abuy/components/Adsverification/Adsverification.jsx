/**
 * Adsverification
 */

import { scrollWindowToPosition } from 'utils/Animation/Animation';
import React, { Component } from 'react';
import has from 'lodash/has';


/**
 * Class
 * @extends React.Component
 */
class Adsverification extends Component{

  componentDidMount(){
    if( has( this.props, 'location.state.ADSValidated' ) ){
      if( !this.props.location.state.ADSValidated ){
        this.props.history.replace( '/' );
      }
    }
    else {
      this.props.history.replace( '/' );
    }

    scrollWindowToPosition( 0, 'easeInOutQuint' );
  }

  /**
   * Renders the Adsverification component
   */
  render(){
    return (
      <div className='Adsverification'>
        { this.props.children }
      </div>
    );
  }
}


export default Adsverification;
