
/**
 * ApplyAndBuyLoginForm
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
  Link
} from 'react-router-dom';
import CancelAndReturn from 'shared/components/CancelAndReturn/CancelAndReturn';
import { formatMessage } from 'shared/components/Global/Global';
import { reduxForm } from 'redux-form';
import './ApplyAndBuyLoginForm.css';
import messages from './ApplyAndBuyLoginForm.messages';
import Divider from 'shared/components/Divider/Divider';
import LoginForm from 'shared/components/LoginForm/LoginForm';
import Button from 'shared/components/Button/Button';


const propTypes = {
  // an indicator for the login service so it knows what URL the request is coming from.
  sourcePage: PropTypes.string.isRequired,
  successPath: PropTypes.string,
  messageBeans: PropTypes.array,
  analyticsPageName: PropTypes.string,
  analyticsChannel: PropTypes.string
}



/**
 * Class
 * @extends React.Component
 */
class ApplyAndBuyLoginForm extends Component{


  componentDidMount(){
    this.props.getBannerImage();
  }

  /**
   * Renders the ApplyAndBuyLoginForm component
   */
  render(){

    return (
      <div className='ApplyAndBuyLoginForm'>
        <div className='ApplyAndBuyLoginForm__leftPanel'>
          <LoginForm
            { ...this.props }
            scrollElementSelector='js-AdsformDecorator__container'
            title={ formatMessage( messages.getStarted ) }
            formMessage={ formatMessage( messages.applicationMessage ) }
            buttonText={ formatMessage( messages.signandapply ) }
            analyticsSourcePage='creditcard'
          />
        </div>
        <div className='ApplyAndBuyLoginForm__rightPanel'>

          <div className='CreditCards__divider'>
            <Divider dividerType='gray' />
          </div>

          <div className='ApplyAndBuyLoginForm__container'>
            <div className='ApplyAndBuyLoginForm__createAccount'>
              <div className='ApplyAndBuyLoginForm__createAccount--noAccountText'>
                { formatMessage( messages.noUltaAccount ) }
              </div>
              <div className='ApplyAndBuyLoginForm__createAccount--createAccountText'>
                { formatMessage( messages.createAppProcess ) }
              </div>
              <div className='ApplyAndBuyLoginForm__createAccount--submitButton'>
                <Link
                  to={ {
                    pathname: '/apply',
                    state: { formType: 'anonymous' }
                  } }
                >
                  <Button
                    inputTag='button'
                    btnType='submit'
                    btnSize='lg'
                    btnOption='single'
                    btnOutLine={ true }
                    tabIndex={ 4 }
                  >
                    { formatMessage( messages.applyNow ) }
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          <CancelAndReturn
            cancelSteps={ -1 }
            history={ history }
            cancelText={ formatMessage( messages.cancel ) }
          />

        </div>
      </div>
    )
  }
}

ApplyAndBuyLoginForm.propTypes = propTypes;

export default ApplyAndBuyLoginForm;
