import React from 'react';
import ReactDOM from 'react-dom';
import ApplyAndBuyLoginForm from './ApplyAndBuyLoginForm';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';
import messages from './ApplyAndBuyLoginForm.messages';

describe( '<ApplyAndBuyLoginForm />', () => {
  const store = configureStore( {}, CONFIG );
  const props = {
    sourcePage:'ccLogin',
    getBannerImage : jest.fn()
  }
  const component = mountWithIntl(
    <Provider store={ store }>
      <Router>
        <ApplyAndBuyLoginForm { ...props }/>
      </Router>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'ApplyAndBuyLoginForm' ).length ).toBe( 1 );
  } );

  it( 'should render LoginForm component', () => {
    expect( component.find( '.ApplyAndBuyLoginForm__leftPanel .LoginForm' ).length ).toBe( 1 );
  } );

  it( 'should render ApplyAndBuyLoginForm__leftPanel', () => {
    expect( component.find( 'ApplyAndBuyLoginForm .ApplyAndBuyLoginForm__leftPanel' ).length ).toBe( 1 );
  } );

  it( 'should render submit Button with label APPLY NOW ', () => {
    expect( component.find( '.ApplyAndBuyLoginForm__rightPanel .ApplyAndBuyLoginForm__createAccount--submitButton' ).text() ).toBe( messages.applyNow.defaultMessage );
  } );

  it( 'should render no account text', () => {
    expect( component.find( 'ApplyAndBuyLoginForm .ApplyAndBuyLoginForm__createAccount--noAccountText' ).text() ).toBe( messages.noUltaAccount.defaultMessage );
  } );

  it( 'should render create account text', () => {
    expect( component.find( 'ApplyAndBuyLoginForm .ApplyAndBuyLoginForm__createAccount--createAccountText' ).text() ).toBe( messages.createAppProcess.defaultMessage );
  } );

} );
