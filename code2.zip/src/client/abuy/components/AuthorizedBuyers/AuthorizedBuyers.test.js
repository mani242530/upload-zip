import React from 'react';
import ReactDOM from 'react-dom';
import AuthorizedBuyers from './AuthorizedBuyers';
import InputField from 'shared/components/InputField/InputField';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './AuthorizedBuyers.messages';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import { reduxForm } from 'redux-form';

const Decorator=reduxForm( { form:'testForm' } )( AuthorizedBuyers );
describe( '<AuthorizedBuyers />', () => {
  let component;
  let props = {
    user: {
      isSignedIn : true
    },
    tabIndex : 0,
    selectValue : '',
    change:jest.fn()
  }
  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'AuthorizedBuyers' ).length ).toBe( 1 );
  } );

  it( 'it should show the input field', () => {
    expect( component.find( 'InputField' ).length ).toBe( 3 );
  } );
  it( 'it should show the input field firstName message', () => {
    expect( component.find( 'InputField' ).at( 0 ).text() ).toBe( messages.authBuyerFirstName.defaultMessage );
  } );
  it( 'it should show the input field lastName message', () => {
    expect( component.find( 'InputField' ).at( 1 ).text() ).toBe( messages.authBuyerLastName.defaultMessage );
  } );
  it( 'it should show the input field dateofBirth', () => {
    expect( component.find( 'InputField' ).at( 2 ).text() ).toBe( messages.authBuyerdateOfBirth.defaultMessage );
  } );

  it( 'it should show the select field', () => {
    expect( component.find( 'select' ).length ).toBe( 1 );
  } );

  const instance = component.find( 'AuthorizedBuyers' ).instance();

  it( 'should call the updateValue method', () => {
    expect( instance.state.selectValue ).toEqual( '' );
    instance.updateValue( 'test' );
    expect( instance.state.selectValue ).toEqual( 'test' );
  } );

} );
