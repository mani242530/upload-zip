import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './CreditApprovalResponse.css';
import 'shared/components/RadioButton/RadioButton.css';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './CreditApprovalResponse.messages';
import Anchor from 'shared/components/Anchor/Anchor';
import Button from 'shared/components/Button/Button';
import ChevronRightSVG from 'shared/components/Icons/chevron_right';
import Adsverification from 'abuy/components/Adsverification/Adsverification';
import Divider from 'shared/components/Divider/Divider';
import Exclamation from 'shared/components/Icons/exclamationcircle';
import Image from 'shared/components/Image/Image';
import TwoColumn from 'shared/components/TwoColumn/TwoColumn';
import ThreeColumn from 'shared/components/ThreeColumn/ThreeColumn';
import has from 'lodash/has';
import isUndefined from 'lodash/isUndefined';
import LoginForm from 'shared/components/LoginForm/LoginForm';
import CreateAccountForm from 'shared/components/CreateAccountForm/CreateAccountForm';


const propTypes = {
  ADSValidated: PropTypes.bool,
  guestServiceNumber: PropTypes.string
};

const initialState = {
  formToShow: 'existingCustomer'
};

const registered ='<sup>&reg</sup>';

/**
 * Class representing a ULTA ADA compliant CreditApprovalResponse element
 * @extends React.Component
 */
class CreditApprovalResponse extends Component{


  constructor( props ){
    super( props );
    this.state = initialState;
    this.changeForm = this.changeForm.bind( this );
  }

  changeForm( value ){
    if( this.state.formToShow !== value ){
      this.setState( { formToShow: value } );
    }
  }

  /**
   * Create a CreditApprovalResponse
   /**
   * Renders the CreditApprovalResponse component
   */
  render(){


    let numberUrl = `tel:+${this.props.guestServiceNumber}`;
    let instantCreditResponse = has( this.props, 'location.state.instantCreditResponse' ) ? this.props.location.state.instantCreditResponse : {};
    let lpsResponse = ( has( this.props, 'location.state.lpsResponse' ) && !isUndefined( this.props.location.state.lpsResponse ) )? this.props.location.state.lpsResponse : { rewardsMemberCreated:false };

    const {
      rewardsMemberCreated
    } = lpsResponse;

    const {
      firstName,
      creditLimit,
      cardType,
      aprValue,
      creditLimitExceeded,
      tenderPromoMessage,
      firstTimeTransactionLimit,
      responseType
    } = instantCreditResponse;
    let bannerImageUri;
    if( this.props.isMobileDevice ){
      bannerImageUri = cardType === 'MC' ? 'https://images.ulta.com/is/image/Ulta/wk1117_m_banner_ccard_response_approval_blcc' : 'https://images.ulta.com/is/image/Ulta/wk1117_m_banner_ccard_response_approval_plcc'
    }
    else {
      bannerImageUri = cardType ==='MC'? 'https://images.ulta.com/is/image/Ulta/wk1117_d_banner_ccard_response_approval_blcc' : 'https://images.ulta.com/is/image/Ulta/wk1117_d_banner_ccard_response_approval_plcc'
    }

    const preApproved = responseType === '06' && !this.props.location.state.isSignedIn;
    let cardTypeText = cardType==='MC' ? formatMessage( messages.MasterCard ) : formatMessage( messages.CreditCard );

    let Layout = TwoColumn;

    if( preApproved ){
      Layout = ThreeColumn;
    }

    return (
      <Adsverification { ...this.props }>
        <div className='CreditApprovalResponse'>
          <div className='CreditApprovalResponse__divider'>
            <Divider dividerType='gray' />
          </div>
          <div className='CreditApprovalResponse'>
            <Layout
              split={ preApproved ? 'twoThirds|oneThird' : 'half|half' }
              columnOne={ ( () => {
                return (
                  <div>
                    <div className='CreditApprovalResponse__banner'>
                      <Image
                        src={ bannerImageUri }
                        alt='BannerImage'
                      />
                    </div>
                  </div>
                );
              } )() }
              columnTwo={ ( () => {
                return (
                  <div>
                    <div className='CreditApprovalResponse_welcomeTitle'>
                      { formatMessage( messages.welcomeTitle ) }
                      <div className='CreditApprovalResponse_firstName'>
                        { firstName }!
                      </div>
                      <Divider dividerType='orangeHorizontal'/>
                    </div>
                    <div className='CreditApprovalResponse_section'>
                      <div className='CreditApprovalResponse__approvalMessage'>
                        <div className='CreditApprovalResponse__answers'>
                          <p className='CreditApprovalResponse__approvalanswers'>
                            <span dangerouslySetInnerHTML={
                              { __html: formatMessage( messages.answer1_1, { registered, cardTypeText } ) }
                            }
                            />
                          </p>
                          <div className='dividerLine'>
                            <Divider dividerType='gray'/>
                          </div>

                          { ( () => {
                            if( cardType === 'MC' ){
                              return (
                                <div className='CreditApprovalResponse__creditInformationBlock'>
                                  <div className='CreditApprovalResponse__creditLimitBlock'>
                                    <div className='CreditApprovalResponse__creditLimitMessage'>
                                      { formatMessage( messages.creditLimitMessage ) }
                                    </div>
                                    <div className='CreditApprovalResponse__creditLimitNumber'>
                                      ${ creditLimit }.00
                                    </div>
                                  </div>

                                  <div className='CreditApprovalResponse__APRBlock'>
                                    <div className='CreditApprovalResponse__APRMessage'>
                                      { formatMessage( messages.APRMessage ) }
                                    </div>
                                    <div className='CreditApprovalResponse__creditLimitNumber'>
                                      { aprValue }%
                                    </div>
                                  </div>
                                  <div className='CreditApprovalResponse__FirstTimeLimitBlock'>
                                    <div className='CreditApprovalResponse__FirstTimeLimitMessage'>
                                      { formatMessage( messages.firstTimeTransactionLimitMessage ) }
                                    </div>
                                    <div className='CreditApprovalResponse__FirstTimeLimitNumber'>
                                      ${ firstTimeTransactionLimit }.00
                                    </div>
                                  </div>
                                </div>
                              )
                            }
                            else {
                              return (
                                <div className='CreditApprovalResponse__creditInformationBlockForPLCC'>
                                  <div className='CreditApprovalResponse__creditLimitMessageForPLCC'>
                                    { formatMessage( messages.creditLimitMessage ) }
                                  </div>
                                  <div className='CreditApprovalResponse__creditLimitNumberForPLCC'>
                                    ${ creditLimit }.00
                                  </div>
                                </div>
                              )
                            }
                          } )() }
                          { ( () => {
                            if( creditLimitExceeded === 'true' && cardType === 'MC' ){
                              return (
                                <div className='CreditApprovalResponse__promotionSavingErrorMCMessage'>
                                  <div className='CreditApprovalResponse__promotionSavingErrorMCMessage__Icon'>
                                    <Exclamation />
                                  </div>
                                  <div className='CreditApprovalResponse__promotionSavingErrorMCMessage__Block'>
                                    <div className='CreditApprovalResponse__promotionSavingErrorMCMessage__Heading'>
                                      { formatMessage( messages.cardexceedsErrorMessageHeadingMCCard, { firstTimeTransactionLimit } ) }
                                    </div>
                                    <div className='CreditApprovalResponse__promotionSavingErrorMCMessage__MessageOne'>
                                      { formatMessage( messages.cardexceedsErrorMessageMCCardMessageOne, { firstTimeTransactionLimit } ) }
                                    </div>
                                    <Anchor
                                      className='CreditApprovalResponse__promotionSavingErrorMCMessage__EditMessage'
                                      url='/bag'
                                    >
                                      { formatMessage( messages.cardexceedsErrorEditBagMessage ) }
                                    </Anchor>
                                    <div className='CreditApprovalResponse__promotionSavingErrorMCMessage__MessageTwo'>
                                      { formatMessage( messages.cardexceedsErrorMessageMCCardMessageTwo ) }
                                    </div>
                                  </div>
                                </div>
                              )
                            }
                            else if( creditLimitExceeded === 'true' && cardType === 'PL' ){
                              return (
                                <div className='CreditApprovalResponse__promotionSavingErrorMCMessage'>
                                  <div className='CreditApprovalResponse__promotionSavingErrorMCMessage__Icon'>
                                    <Exclamation />
                                  </div>
                                  <div className='CreditApprovalResponse__promotionSavingErrorMCMessage__Block'>
                                    <div className='CreditApprovalResponse__promotionSavingErrorMCMessage__Heading'>
                                      { formatMessage( messages.cardexceedsErrorMessageHeadingPLCard ) }
                                    </div>
                                    <div className='CreditApprovalResponse__promotionSavingErrorMCMessage__MessageOne'>
                                      { formatMessage( messages.cardexceedsErrorMessagePLCardMessageOne ) }
                                    </div>
                                    <Anchor
                                      className='CreditApprovalResponse__promotionSavingErrorMCMessage__EditMessage'
                                      url='/bag'
                                    >
                                      { formatMessage( messages.cardexceedsErrorEditBagMessage ) }
                                    </Anchor>
                                    <div className='CreditApprovalResponse__promotionSavingErrorMCMessage__MessageTwo'>
                                      { formatMessage( messages.cardexceedsErrorMessagePLCardMessageTwo ) }
                                    </div>
                                  </div>
                                </div>
                              )
                            }
                          } )() }

                          { ( () => {
                            if( instantCreditResponse.aprReasons && instantCreditResponse.aprReasons.length > 0 ){
                              return (
                                <div>
                                  <span className='CreditApprovalResponse__answers'>
                                    { formatMessage( messages.answer2_2 ) }
                                  </span>
                                  <span className='ViewDetails CreditApprovalResponse_displayInline '>
                                    <p className='ViewDetails--chevronImg'>
                                      <Anchor
                                        clickHandler={
                                          ( e ) => {
                                            this.props.history.push( '/c/report', {
                                              ADSValidated: true,
                                              instantCreditResponse: this.props.location.state.instantCreditResponse
                                            } )
                                          }
                                        }
                                        className='ViewDetails--link'
                                      >{ formatMessage( messages.answer2_3 ) }
                                      </Anchor>
                                      <ChevronRightSVG />
                                    </p>
                                  </span>
                                </div>
                              )
                            }
                          } )() }
                          <div className='dividerLine'>
                            <Divider dividerType='gray'/>
                          </div>

                          <div className='CreditApprovalResponse__answers'>{ formatMessage( messages.answer2_4 ) }</div>


                          { ( () => {
                            if( creditLimitExceeded === 'false' ){
                              return (
                                <div className='CreditApprovalResponse__promotionSavingMessage'>
                                  { formatMessage( messages.savingsMessage, { tenderPromoMessage, cardTypeText } ) }
                                </div>
                              )
                            }
                          } )() }



                          { ( () => {
                            if( cardType === 'PL' ){
                              return (

                                <div className='CreditApprovalResponse__paymentMethodMessage'>
                                  { formatMessage( messages.paymentMethodPLCCCardMessage ) }
                                </div>
                              )
                            }
                            else if( cardType === 'MC' ){
                              return (

                                <div className='CreditApprovalResponse__paymentMethodMessage'>
                                  { formatMessage( messages.paymentMethodMasterCardMessage ) }
                                </div>

                              )
                            }
                          } )() }


                          <div className='CreditApprovalResponse__promotionCouponMessage'>{ formatMessage( messages.emailCouponMessage ) }</div>


                          { ( () => {
                            if( this.props.history.location.state.isAccountCreated ){
                              return (
                                <div className='CreditApprovalResponse__ultamateRewardsMemberIDHeadingMessage'>
                                  { formatMessage( messages.ultamateRewardsMemberIDHeadingMessage ) }
                                </div>
                              )
                            }
                          } )() }



                          { ( () => {
                            if( rewardsMemberCreated === true ){
                              return (
                                <div className='CreditApprovalResponse__ultamateRewardsMemberIDMessageBlock'>
                                  <div className='CreditApprovalResponse__ultamateRewardsMemberIDMessageBlock__Icon'>
                                    <Exclamation />
                                  </div>
                                  <div className='CreditApprovalResponse__ultamateRewardsMember'>
                                    <p className='CreditApprovalResponse__ultamateRewardsMemberIDMessage'>
                                      { formatMessage( messages.ultamateRewardsMemberIDMessageOne ) }
                                      <Anchor
                                        className='MobileFooterTandC__help MobileFooterTandC__help__link MobileFooterTandC__help__number'
                                        url={ numberUrl }
                                      >
                                        { this.props.guestServiceNumber }
                                      </Anchor>
                                      { formatMessage( messages.ultamateRewardsMemberIDMessageNumber ) }
                                    </p>
                                  </div>
                                </div>
                              )
                            }
                          } )() }



                          { ( () => {
                            if( responseType !== '06' ){
                              if( this.props.shoppingCartCount === '0' ){
                                return (
                                  <div className='CreditApprovalResponse__shopping__btn'>
                                    <Button
                                      inputTag='a'
                                      btnSize='lg'
                                      btnOption='single'
                                      btnURL='/'
                                    >
                                      { formatMessage( messages.continueShopping ) }
                                    </Button>
                                  </div>
                                )
                              }
                              else {
                                return (
                                  <div className='CreditApprovalResponse__shopping__btn'>
                                    <div className='CreditApprovalResponse__shopping__btn'>
                                      <Button
                                        inputTag='a'
                                        btnSize='lg'
                                        btnOption='single'
                                        btnURL='/bag'
                                      >
                                        { formatMessage( messages.continueCheckOut ) }
                                      </Button>
                                    </div>
                                    <div className='CreditApprovalResponse__shopping__btn__Return'>
                                      <Button
                                        inputTag='a'
                                        btnSize='lg'
                                        btnOption='single'
                                        btnOutLine={ true }
                                        btnURL='/'
                                      >
                                        { formatMessage( messages.returnShopping ) }
                                      </Button>
                                    </div>
                                  </div>
                                )
                              }
                            }
                            else if( this.props.location.state.isSignedIn ){
                              return (
                                <div className='CreditApprovalResponse__shopping__btn'>
                                  <Button
                                    inputTag='a'
                                    btnSize='lg'
                                    btnOption='single'
                                    btnURL={ this.props.shoppingCartCount === '0' ? '/' : '/bag' }
                                  >
                                    { formatMessage( messages.continue ) }
                                  </Button>
                                </div>
                              )
                            }
                          } )() }
                        </div>
                      </div>
                    </div>
                  </div>

                );
              } )() }
              columnThree={ ( () => {
                if( preApproved ){
                  return (
                    <div className='CreditApprovalResponse__LoginForm'>
                      <div className='CreditApprovalResponse__LoginForm_Header'>
                        <div className='CreditApprovalResponse_welcomeTitle'>
                          { formatMessage( messages.LoginFormHeader ) }
                        </div>
                        <div className='CreditApprovalResponse_welcomeTitle_DiscountMessage'>
                          { formatMessage( messages.LoginFormSubHeader ) }
                        </div>
                        <Divider dividerType='orangeHorizontal'/>
                      </div>
                      <div className='CreditApprovalResponse__accountCheck'>
                        <div className='CreditApprovalResponse__accountCheck_header'>
                          { formatMessage( messages.accountCheckHeader ) }
                        </div>
                        <div className='CreditApprovalResponse__accountCheck_options'>
                          <div className='RadioButton'>
                            <div className='CreditApprovalResponse-radio form-radio'>
                              <input
                                type='radio'
                                className='form--control'
                                id='approvalPageExistingCustomer'
                                name='customerCheck'
                                value='existingCustomer'
                                onChange={ ( e ) => this.changeForm( e.target.value ) }
                                checked={ this.state.formToShow === 'existingCustomer' }
                              />
                              <label
                                htmlFor='approvalPageExistingCustomer'
                                className='CreditApprovalResponse_options_label form--label'
                              >
                                { formatMessage( messages.existingCustomer ) }
                              </label>
                            </div>
                          </div>
                          <div className='RadioButton'>
                            <div className='CreditApprovalResponse-radio form-radio'>
                              <input
                                type='radio'
                                className='form--control'
                                id='approvalPageNewCustomer'
                                name='customerCheck'
                                value='newCustomer'
                                onChange={ ( e ) => this.changeForm( e.target.value ) }
                                checked={ this.state.formToShow === 'newCustomer' }
                              />
                              <label
                                htmlFor='approvalPageNewCustomer'
                                className='CreditApprovalResponse_options_label form--label'
                              >
                                { formatMessage( messages.newCustomer ) }
                              </label>
                            </div>
                          </div>
                        </div>
                        <div className='CreditApprovalResponse__FormSection'>
                          { ( () => {
                            if( this.state.formToShow === 'existingCustomer' ){
                              return (
                                <LoginForm
                                  { ...this.props }
                                  successPath='/bag'
                                  useRouter={ false }
                                  sourcePage='PreScreenLogin'
                                  buttonText={ formatMessage( messages.signandcontinue ) }
                                  analyticsSourcePage='credit card'
                                  defaultEmail={ this.props.history.location.state.preapprovedUserData.email }
                                />
                              )
                            }
                            else {
                              const historyData = this.props.history.location.state;
                              // userData is used to create account for the user.
                              const userData = {
                                firstName: historyData.preapprovedUserData.firstName,
                                lastName: historyData.preapprovedUserData.lastName,
                                address1: historyData.preapprovedUserData.address1,
                                address2: historyData.preapprovedUserData.address2,
                                city: historyData.preapprovedUserData.city,
                                state: historyData.preapprovedUserData.state,
                                dateOfBirth: historyData.preapprovedUserData.dateOfBirth,
                                postalCode: historyData.preapprovedUserData.postalCode,
                                phoneNumber: historyData.preapprovedUserData.phoneNumber
                              }
                              return (
                                <CreateAccountForm
                                  { ...this.props }
                                  successPath='/bag'
                                  useRouter={ false }
                                  buttonText={ formatMessage( messages.createAccountandcontinue ) }
                                  userData={ userData }
                                  defaultEmail={ historyData.preapprovedUserData.email }
                                  sourcePage='PreScreenCreate'
                                  analyticsSourcePage='credit card'
                                />
                              )
                            }
                          } )() }
                          <div className='CreditApprovalResponse__FormSection__footer'>
                            <div className='CreditApprovalResponse__FormSection__footer-message1'>
                              { formatMessage( messages.FormSectionMessage1 ) }
                            </div>
                            <div className='CreditApprovalResponse__FormSection__footer-message2'>
                              <Anchor
                                url='/'
                              >
                                <span>{ formatMessage( messages.FormSectionMessage2 ) }</span>
                                <ChevronRightSVG />
                              </Anchor>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                }
              } )() }
            />
          </div>
        </div>
      </Adsverification>
    );
  }
}

CreditApprovalResponse.propTypes = propTypes;


export default CreditApprovalResponse;
