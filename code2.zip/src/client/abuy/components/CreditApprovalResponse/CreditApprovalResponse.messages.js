
/*
 * CreditApprovalResponse Messages
 *
 * This contains all the text for the CreditApprovalResponse component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  welcomeTitle: {
    id: 'i18n.CreditApprovalResponse.welcomeTitle',
    defaultMessage: ' WELCOME,'
  },
  continueShopping: {
    id: 'i18n.CreditApprovalResponse.continueShopping',
    defaultMessage: 'Continue Shopping'
  },
  continueCheckOut: {
    id: 'i18n.CreditApprovalResponse.continueCheckOut',
    defaultMessage: 'Continue To Checkout'
  },
  returnShopping: {
    id: 'i18n.CreditApprovalResponse.returnShopping',
    defaultMessage: 'Return To Shopping'
  },
  answer1_1:{
    id: 'i18n.CreditApprovalResponse.answer1_1',
    defaultMessage: 'Your Ultamate Rewards{registered} {cardTypeText} has been approved!'
  },
  creditLimitMessage:{
    id: 'i18n.CreditApprovalResponse.creditLimitMessage',
    defaultMessage: 'Credit Limit: '
  },
  APRMessage:{
    id: 'i18n.CreditApprovalResponse.APRMessage',
    defaultMessage: 'APR:'
  },
  question:{
    id: 'i18n.CreditApprovalResponse.question2',
    defaultMessage: 'We\'ve emailed you a coupon code for 20% off your next purchase'
  },
  answer2_2:{
    id: 'i18n.CreditApprovalResponse.answer2_2',
    defaultMessage: ' We used information from your credit report to set the Annual Percentage Rate and terms of your account.'
  },
  answer2_3:{
    id: 'i18n.CreditApprovalResponse.answer2_3',
    defaultMessage: 'View Details'
  },
  answer2_4:{
    id: 'i18n.CreditApprovalResponse.answer2_4',
    defaultMessage: ' You\'ll receive your credit card by US mail within 10 business days.'
  },
  MasterCard:{
    id: 'i18n.CreditApprovalResponse.MasterCard',
    defaultMessage: 'Mastercard'
  },
  CreditCard:{
    id: 'i18n.CreditApprovalResponse.CreditCard',
    defaultMessage: 'Credit Card'
  },
  savingsMessage:{
    id: 'i18n.CreditApprovalResponse.savingsMessage',
    defaultMessage: '{tenderPromoMessage} {cardTypeText} on this purchase!*'
  },
  emailCouponMessage:{
    id: 'i18n.CreditApprovalResponse.emailCouponMessage',
    defaultMessage: '**Not shopping now? In 1-2 days, you\'ll be emailed a coupon code for 20% off your next purchase!'
  },
  paymentMethodMasterCardMessage:{
    id: 'i18n.CreditApprovalResponse.paymentMethodMessage',
    defaultMessage: 'We\'ve added your credit card as your payment method in Checkout so that you can start earning Ultamate Rewards points today!**'
  },
  paymentMethodPLCCCardMessage:{
    id: 'i18n.CreditApprovalResponse.paymentMethodMessage',
    defaultMessage: 'We\'ve added your credit card as your primary payment method in Checkout and for all future purchases so that you can start earning Ultamate Rewards points today! To update your primary payment method, please visit your payment settings in My Account.**'
  },
  paymentMethodToggleMessage:{
    id: 'i18n.CreditApprovalResponse.paymentMethodMessage',
    defaultMessage: 'Save as primary payment method for all future purchases'
  },
  balanceMessage:{
    id: 'i18n.CreditApprovalResponse.balanceMessage',
    defaultMessage: 'Right now, you still have  available on your account.'
  },
  cardexceedsErrorMessageHeading:{
    id: 'i18n.CreditApprovalResponse.cardexceedsErrorMessageHeading',
    defaultMessage: 'Your bag total currently exceeds your credit limit.'
  },
  cardexceedsErrorMessageOne:{
    id: 'i18n.CreditApprovalResponse.cardexceedsErrorMessageOne',
    defaultMessage: 'In order to receive 20% off today\'s purchase, please remove items to bring your bag total to, or below, your credit limit. '
  },
  cardexceedsErrorMessageTwo:{
    id: 'i18n.CreditApprovalResponse.cardexceedsErrorMessageTwo',
    defaultMessage: 'To proceed without removing items from your current bag, please select a different form of payment in checkout. Within 1-2 days, you\'ll receive a coupon code via email for 20% off your next purchase.'
  },
  cardexceedsErrorMessageHeadingPLCard:{
    id: 'i18n.CreditApprovalResponse.cardexceedsErrorMessageHeadingPLCard',
    defaultMessage: 'Your bag total currently exceeds your credit limit.'
  },
  cardexceedsErrorMessagePLCardMessageOne:{
    id: 'i18n.CreditApprovalResponse.cardexceedsErrorMessagePLCardMessageOne',
    defaultMessage: 'In order to receive 20% off today\'s purchase, please remove items to bring your bag total to, or below, your credit limit.'
  },
  cardexceedsErrorMessagePLCardMessageTwo:{
    id: 'i18n.CreditApprovalResponse.cardexceedsErrorMessagePLCardMessageTwo',
    defaultMessage: 'To proceed without removing items from your current bag, please select a different form of payment at checkout. In 1-2 days, you\'ll be emailed a coupon code for 20% off your next purchase.'
  },
  cardexceedsErrorMessageHeadingMCCard:{
    id: 'i18n.CreditApprovalResponse.cardexceedsErrorMessageHeadingMCCard',
    defaultMessage: 'Your bag total currently exceeds your first time transaction limit of ${firstTimeTransactionLimit}'
  },
  cardexceedsErrorMessageMCCardMessageOne:{
    id: 'i18n.CreditApprovalResponse.cardexceedsErrorMessageMCCardMessageOne',
    defaultMessage: 'To receive 20% off today\'s purchase, please remove items to bring your bag total to, or below, your first time transaction limit of ${firstTimeTransactionLimit}.'
  },
  cardexceedsErrorMessageMCCardMessageTwo:{
    id: 'i18n.CreditApprovalResponse.cardexceedsErrorMessageMCCardMessageTwo',
    defaultMessage: 'To proceed without removing items from your current bag, please select a different form of payment at checkout. In 1-2 days, you\'ll be emailed a coupon code for 20% off your next purchase.'
  },
  cardexceedsErrorEditBagMessage:{
    id: 'i18n.CreditApprovalResponse.cardexceedsErrorEditBagMessage',
    defaultMessage: 'Edit your bag now'
  },
  ultamateRewardsMemberIDHeadingMessage:{
    id: 'i18n.CreditApprovalResponse.ultamateRewardsMemberIDMessage',
    defaultMessage: 'We\'ve also created an Ulta.com account for you where you can shop and earn points on each purchase.'
  },
  ultamateRewardsMemberIDMessageOne:{
    id: 'i18n.CreditApprovalResponse.ultamateRewardsMemberIDMessage',
    defaultMessage: 'A new Ultamate Rewards Member ID has been created and tied to your card. If you are an existing Ultamate Rewards member and wish to tie your existing Member ID to your card, please call '
  },
  ultamateRewardsMemberIDMessageTwo:{
    id: 'i18n.CreditApprovalResponse.ultamateRewardsMemberIDMessage',
    defaultMessage: ' 1-866-983-8582'
  },
  ultamateRewardsMemberIDMessageNumber:{
    id: 'i18n.CreditApprovalResponse.ultamateRewardsMemberIDMessage',
    defaultMessage: ' for assistance.'
  },
  LoginFormHeader:{
    id: 'i18n.CreditApprovalResponse.LoginFormHeader',
    defaultMessage: 'SIGN IN TO YOUR ULTA.COM ACCOUNT OR CREATE ONE NOW.'
  },
  LoginFormSubHeader:{
    id: 'i18n.CreditApprovalResponse.LoginFormSubHeader',
    defaultMessage: 'Then shop and save 20% off this order.'
  },
  accountCheckHeader:{
    id: 'i18n.CreditApprovalResponse.accountCheckHeader',
    defaultMessage: 'Do you have an Ulta.com account?'
  },
  existingCustomer:{
    id: 'i18n.CreditApprovalResponse.existingCustomer',
    defaultMessage: 'Yes, I\'ve shopped here!'
  },
  newCustomer:{
    id: 'i18n.CreditApprovalResponse.newCustomer',
    defaultMessage: 'No, I\'m new to the website.'
  },
  signandcontinue:{
    id: 'i18n.CreditApprovalResponse.signandcontinue',
    defaultMessage: 'SIGN IN & CONTINUE'
  },
  createAccountandcontinue:{
    id: 'i18n.CreditApprovalResponse.createAccountandcontinue',
    defaultMessage: 'CREATE ACCOUNT & CONTINUE'
  },
  firstTimeTransactionLimitMessage:{
    id: 'i18n.CreditApprovalResponse.firstTimeTransactionLimitMessage',
    defaultMessage: 'First-Time Transaction Limit: '
  },
  continue:{
    id: 'i18n.CreditApprovalResponse.continue',
    defaultMessage: 'CONTINUE'
  },
  FormSectionMessage1:{
    id: 'i18n.CreditApprovalResponse.FormSectionMessage1',
    defaultMessage: 'Don’t want to create an account?'
  },
  FormSectionMessage2:{
    id: 'i18n.CreditApprovalResponse.FormSectionMessage2',
    defaultMessage: 'Shop as a guest and apply your 20% off at checkout. '
  }
} );
