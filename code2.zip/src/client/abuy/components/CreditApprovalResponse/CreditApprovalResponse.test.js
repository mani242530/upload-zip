import React from 'react';
import ReactDOM from 'react-dom';
import CreditApprovalResponse from './CreditApprovalResponse';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { IntlProvider } from 'react-intl';
import Button from 'shared/components/Button/Button';
import configureStore from 'abuy/abuy.store';
import CONFIG from 'abuy/abuy.config';
import { Provider } from 'react-redux';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';


const intlProvider = new IntlProvider( { locale: 'en' }, {} );
const { intl } = intlProvider.getChildContext();
window.requestAnimationFrame = jest.fn();
const store = configureStore( {}, CONFIG );

describe( '<CreditApprovalResponse />', () => {

  let props = {
    intl,
    history:{
      location:{ state:{ isSignedIn:true }, url:'/CreditCardApplyForm' },
      replace:jest.fn()
    },
    isMobileDevice: true
  }

  let component = mountWithIntl(
    <CreditApprovalResponse
      { ...props }
    />
  );
  it( 'renders without crashing', ()=>{
    expect( component.find( 'CreditApprovalResponse' ).length ).toBe( 1 );
  } );

  it( 'should have two CreditApprovalResponse_welcomeTitle', ()=>{
    expect( component.find( '.CreditApprovalResponse_welcomeTitle' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditApprovalResponse__banner', ()=>{
    expect( component.find( '.CreditApprovalResponse__banner' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditApprovalResponse__banner', ()=>{
    expect( component.find( '.CreditApprovalResponse__banner .Image' ).find( 'img' ).props().src ).toBe( 'https://images.ulta.com/is/image/Ulta/wk1117_m_banner_ccard_response_approval_plcc' );
  } );

  it( 'should have one CreditApprovalResponse_section', ()=>{
    expect( component.find( '.CreditApprovalResponse_section' ).length ).toBe( 1 );
  } );
  it( 'should have one CreditApprovalResponse__answers', ()=>{
    expect( component.find( '.CreditApprovalResponse__answers' ).length ).toBe( 2 );
  } );
  it( 'should have continue shopping link', ()=>{
    expect( component.find( Button ).length ).toBe( 2 );
    expect( component.find( Button ).at( 1 ).props().btnURL ).toBe( '/' );
  } );
} );
describe( '<CreditApprovalResponse />', () => {
  let props = {
    intl,
    history:{
      location:{ state:{ isSignedIn:true, isAccountCreated:true, lpsResponse:true }, url:'/CreditCardApplyForm' },
      replace:jest.fn()
    },
    location:{
      state:{
        lpsResponse: true,
        responseType: '05',
        instantCreditResponse:{
          cardType: 'MC',
          creditLimitExceeded: 'true',
          aprReasons: 'twrue'
        }
      }
    },
    shoppingCartCount:'0',
    isMobileDevice: false
  }

  let component = mountWithIntl(
    <CreditApprovalResponse
      { ...props }
    />
  );
  it( 'should have one CreditApprovalResponse__banner if isMobileDevice is false', ()=>{
    expect( component.find( '.CreditApprovalResponse__banner .Image' ).find( 'img' ).props().src ).toBe( 'https://images.ulta.com/is/image/Ulta/wk1117_d_banner_ccard_response_approval_blcc' );
  } );

  it( 'should have one CreditApprovalResponse__creditInformationBlock', ()=>{
    expect( component.find( '.CreditApprovalResponse__creditInformationBlock' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditApprovalResponse__promotionSavingErrorMCMessage', ()=>{
    expect( component.find( '.CreditApprovalResponse__promotionSavingErrorMCMessage' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditApprovalResponse__paymentMethodMessage', ()=>{
    expect( component.find( '.CreditApprovalResponse__paymentMethodMessage' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditApprovalResponse__ultamateRewardsMemberIDHeadingMessage', ()=>{
    expect( component.find( '.CreditApprovalResponse__ultamateRewardsMemberIDHeadingMessage' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditApprovalResponse__shopping__btn', ()=>{
    expect( component.find( '.CreditApprovalResponse__shopping__btn' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditApprovalResponse_welcomeTitle', ()=>{
    expect( component.find( '.CreditApprovalResponse' ).at( 1 ).find( '.CreditApprovalResponse_welcomeTitle' ).length ).toBe( 1 );
  } );

  it( 'should have one  CreditApprovalResponse__promotionSavingErrorMCMessage', ()=>{
    let props1 = {
      intl,
      history:{
        location:{ state:{ isSignedIn:true }, url:'/CreditCardApplyForm' },
        replace:jest.fn()
      },
      location:{
        state:{
          instantCreditResponse:{
            cardType: 'PL',
            creditLimitExceeded: 'true',
            aprReasons: 'true'
          }
        }
      }
    }
    let component1 = mountWithIntl(
      <CreditApprovalResponse
        { ...props1 }
      />
    );
    expect( component1.find( '.CreditApprovalResponse__promotionSavingErrorMCMessage' ).length ).toBe( 1 );
    expect( component.find( '.CreditApprovalResponse__paymentMethodMessage' ).length ).toBe( 1 );
  } );

  it( 'should have one  CreditApprovalResponse__promotionSavingMessage', ()=>{
    let props1 = {
      intl,
      history:{
        location:{ state:{ isSignedIn:true }, url:'/CreditCardApplyForm' },
        replace:jest.fn()
      },
      location:{
        state:{
          instantCreditResponse:{
            cardType: 'PL',
            creditLimitExceeded: 'false',
            aprReasons: 'true'
          }
        }
      }
    }
    let component1 = mountWithIntl(
      <CreditApprovalResponse
        { ...props1 }
      />
    );
    expect( component1.find( '.CreditApprovalResponse__promotionSavingMessage' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditApprovalResponse__FormSection', ()=>{
    let props1 = {
      intl,
      history:{
        location:{
          state:{
            preapprovedUserData:{
              email:'dd@ddd'
            },
            isSignedIn:true
          },
          url:'/CreditCardApplyForm' },
        replace:jest.fn()
      },
      location:{
        state:{
          instantCreditResponse:{
            cardType: 'PL',
            creditLimitExceeded: 'false',
            aprReasons: 'true',
            responseType: '06'
          }
        }
      }
    }
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <Router>
          <CreditApprovalResponse { ...props1 }/>
        </Router>
      </Provider>
    );
    const instance = component1.find( 'CreditApprovalResponse' ).instance();
    instance.changeForm( 'ff' );
    expect( component1.find( '.CreditApprovalResponse__FormSection' ).length ).toBe( 1 );
  } );

} );

describe( '<CreditApprovalResponse />', () => {

  it( 'should have continue shopping link which will have the url prop as /, when cart count is 0', ()=>{

    let props = {
      intl,
      history:{
        location:{
          state:{
            isSignedIn:true
          },
          url:'/CreditCardApplyForm' },
        replace:jest.fn()
      },
      location:{
        state:{
          isSignedIn:true,
          instantCreditResponse:{
            responseType: '06'
          }
        },
        url:'/CreditCardApplyForm' },
      shoppingCartCount: '0'
    }

    let component = mountWithIntl(
      <CreditApprovalResponse
        { ...props }
      />
    );

    expect( component.find( Button ).length ).toBe( 1 );
    expect( component.find( Button ).at( 0 ).props().btnURL ).toBe( '/' );
  } );

  it( 'should load loginform component for a nonsigned in user', ()=>{
    const store = configureStore( {}, CONFIG );
    let props = {
      intl,
      history:{
        location:{
          state:{
            isSignedIn:false,
            preapprovedUserData:{}
          },
          url:'/CreditCardApplyForm' },
        replace:jest.fn()
      },
      location:{
        state:{
          isSignedIn:false,
          instantCreditResponse:{
            responseType: '06'
          }
        },
        url:'/CreditCardApplyForm' },
      shoppingCartCount: '0'
    }
    let component = mountWithIntl(
      <Provider store={ store }>
        <CreditApprovalResponse { ...props }/>
      </Provider>
    );

    expect( component.find( 'LoginForm' ).length ).toBe( 1 );
  } );
} );

describe( '<CreditApprovalResponse />', () => {

  let props = {
    intl,
    history:{
      location:{
        state:{
          isSignedIn:true
        },
        url:'/CreditCardApplyForm' },
      replace:jest.fn()
    },
    location:{
      state:{
        isSignedIn:true,
        instantCreditResponse:{
          responseType: '06'
        },
        lpsResponse: {
          rewardsMemberCreated:true
        }
      },
      url:'/CreditCardApplyForm' },
    shoppingCartCount: '4'
  }

  let component = mountWithIntl(
    <CreditApprovalResponse
      { ...props }
    />
  );

  it( 'should have continue shopping link which will have the url prop as /bag, when cart count is greater than 0', ()=>{
    expect( component.find( Button ).length ).toBe( 1 );
    expect( component.find( Button ).at( 0 ).props().btnURL ).toBe( '/bag' );
  } );

  it( 'should set the formToShow property in state when changeForm method is invoked', ()=>{
    component.find( CreditApprovalResponse ).instance().setState( { 'formToShow ': 'CreditCardForm' } );
    component.find( CreditApprovalResponse ).instance().changeForm( 'CreditCardApplyForm' );
    expect( component.find( CreditApprovalResponse ).instance().state.formToShow ).toBe( 'CreditCardApplyForm' );
  } );

  it( 'should have CreditApprovalResponse__ultamateRewardsMemberIDMessageBlock when rewardsMemberCreated is true', ()=>{
    expect( component.find( CreditApprovalResponse ).find( '.CreditApprovalResponse__ultamateRewardsMemberIDMessageBlock' ).length ).toBe( 1 );
  } );
} );