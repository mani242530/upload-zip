/**
 * CreditCardApply
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import './CreditCardApplyForm.css';
import { reduxForm, formValueSelector, untouch, change } from 'redux-form';
import { scrollWindowToPosition } from 'utils/Animation/Animation';
import LegalDisclaimerDropdown from 'abuy/components/LegalDisclaimerDropdown/LegalDisclaimerDropdown';
import EditPrepopulatedData from 'abuy/components/EditPrepopulatedData/EditPrepopulatedData';
import VMasker from 'vanilla-masker';
import LpsLookUp from 'abuy/components/LpsLookUp/LpsLookUp';
import AuthorizedBuyers from 'abuy/components/AuthorizedBuyers/AuthorizedBuyers';
import AddressForm from 'shared/components/AddressForm/AddressForm';
import messages from './CreditCardApplyForm.messages';
import Button from 'shared/components/Button/Button';
import Spinner from 'shared/components/Icons/spinner';
import Anchor from 'shared/components/Anchor/Anchor';
import InputField from 'shared/components/InputField/InputField';
import SsnLastFourInput from 'abuy/components/SsnLastFourInput/SsnLastFourInput';
import ToggleButton from 'shared/components/ToggleButton/ToggleButton';
import Divider from 'shared/components/Divider/Divider';
import LockSVG from 'shared/components/Icons/lock';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import CancelAndReturn from 'shared/components/CancelAndReturn/CancelAndReturn';
import InputWithDropDown from 'shared/components/InputWithDropDown/InputWithDropDown';
import {
  createScriptTag,
  removeScriptTag
} from 'utils/3rdPartyScripts/3rdPartyScripts';

import {
  checkIfAndroidChrome
} from 'utils/DeviceDetection/deviceDetection';
import {
  removeSpecialCharacters,
  fullyQualifyLink,
  host
} from 'utils/Formatters/formatters';

import {
  requiredValidation,
  validate as validationMethod,
  validationKeys
} from 'utils/FormValidations/FormValidations';

import FormValidationMessages from 'utils/FormValidations/FormValidations.messages';
import { formatMessage } from 'shared/components/Global/Global';
import {
  clone,
  forEach,
  keys,
  isEqual,
  isEmpty,
  bind,
  isUndefined,
  has,
  omitBy,
  isNil
} from 'lodash';

import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';
import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';
import classNames from 'classnames';
const propTypes = {
  userStatus: PropTypes.number,
  submitApplyData: PropTypes.func.isRequired,
  lpsService: PropTypes.func,
  lpsFlag: PropTypes.string,
  isPreapprovedForm: PropTypes.bool
}

const defaultProps = {
  userStatus: 0,
  isPreapprovedForm: false
}

const initialState = {
  applyNow: false,
  signIn: true,
  Relationship: false,
  annualText: false,
  learnMore: false,
  displayMessage: true,
  Address: true,
  authorizeBuyer: false,
  isModalOpen: false,
  lpsValuesChanged: false,
  initialLpsValues: {},
  blockLPSRequestUntilSubmit: false,
  loggedInUserData: {},
  displayAnnualIncomeMessage: false,
  selectValue: 'Mobile',
  showDropDown: false,
  tryFormSubmissionAfterLPSLookup: false,
  secondaryLPSLookup: false,
  allTermsLoaded: false
};

let formType = 'anonymous';
let termsLoadedCounter = 0;
/**
 * Class
 * @extends React.Component
 */
class CreditCardApplyForm extends Component{
  IOVATIONCORE = 'JS_IOVATIONCORE';
  IOVATIONCONFIGURATION = 'JS_IOVATIONCONFIGURATION';
  preapprovedUserData = undefined;
  showEditMode = false;
  // if the number of terms files is increased or decreased, modify the count in the 'loadedTerms' function to match
  termsAndConditionsDisclaimer = ( process.env.NODE_ENV === 'development' ? 'https://d.comenity.net/ultamaterewardsmastercard/common/Legal/termsandconditions.xhtml' : 'https://comenity.net/ultamaterewardsmastercard/common/Legal/termsandconditions.xhtml' );
  electronicConsentDisclaimer = ( process.env.NODE_ENV === 'development' ? 'https://d.comenity.net/ultamaterewardsmastercard/common/Legal/ESignDisclosure.xhtml' : 'https://comenity.net/ultamaterewardsmastercard/common/Legal/ESignDisclosure.xhtml' )
  financialTermsDisclaimer= ( process.env.NODE_ENV === 'development' ? 'https://comenity.net/ultamaterewardsmastercard/common/Legal/consent-disclosure.xhtml' : 'https://comenity.net/ultamaterewardsmastercard/common/Legal/consent-disclosure.xhtml' )

  /**
   * Create a CreditCardApplyForm
   */

  constructor( props ){
    super( props );
    this.state = initialState;
    this.handleMessage = this.handleMessage.bind( this );
    this.getAuthorizedBuyerStatus = this.getAuthorizedBuyerStatus.bind( this );
    this.submit = this.submit.bind( this );
    this.toggleModal = this.toggleModal.bind( this );
    this.lookUpLPSValues = this.lookUpLPSValues.bind( this );
    this.loadedTerms = this.loadedTerms.bind( this );

    createScriptTag(
      this.IOVATIONCONFIGURATION,
      undefined,
      undefined,
      `
        var io_install_stm = false; //do not install ActiveX
        var io_install_flash = false; //do not install ActiveX
        var io_exclude_stm = 12; //exclude Active X on XP and higher
        var io_enable_rip  = true;

        //Iovation Support for FRAUD control
        var io_bbout_element_id = 'js_ioBlackBox'; //populate ioBlackBox in form

        //configuration parameters for network latency
       /*
        var io_submit_element_id = 'finalSubmit'; // tie to form's submit button
        var io_max_wait = 3000; //wait 3 seconds
        var io_submit_form_id = 'CreditCardApplyForm';
       */
      `
    );

    createScriptTag(
      this.IOVATIONCORE,
      ( process.env.NODE_ENV === 'development' ? 'https://ci-mpsnare.iovation.com/snare.js' : 'https://mpsnare.iesnare.com/snare.js' ),

    );

    // User is signed in
    if( this.props.hasProfileData ){

      formType = 'loggedIn';
      const user = this.props.user.profileInfo;

      const initialLpsValues = {
        login: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        phoneNumber: removeSpecialCharacters( user.address.phoneNumber )
      }
      // for signedIn user make LPS call only if the user is not a rewards member.
      if( !this.props.user.isRewardsMember ){
        this.props.lpsService( initialLpsValues );
      }

      const loggedInUserData = {
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phoneNumber: removeSpecialCharacters( user.address.phoneNumber ),
        address1: user.address.address1,
        address2: user.address.address2,
        city: user.address.city,
        state: user.address.state,
        postalCode: user.address.postalCode
      };

      this.setState( {
        initialLpsValues,
        loggedInUserData
      } );

    }
  }

  componentWillMount(){
    if( has( this.props.history, 'location.state.lpsData' ) ){
      const historyData = this.props.history.location.state.lpsData;
      historyData.postalCode = VMasker.toPattern( historyData.postalCode, '99999' );
      this.preapprovedUserData = {
        firstName: historyData.firstName,
        lastName: historyData.lastName,
        email: historyData.email,
        address: {
          address1: historyData.address1,
          address2: historyData.address2,
          city: historyData.city,
          state: historyData.state,
          postalCode: historyData.postalCode,
          phoneNumber: historyData.phoneNumber
        }
      };

      forEach( historyData, bind( function( val, key ){
        // check for the data from lps in preapproved flow to make sure it is complete if not complete open the form to make it editable. address2 and cardType need not be checked. phone number also need to checked for the its lenght.
        if( ( key !== 'address2' && key !=='cardType' && ( val === null || val === '' ) ) || ( key === 'phoneNumber' && ( removeSpecialCharacters( val ) ).length !== 10 ) ){
          this.showEditMode = true;
        }
        this.props.change( key, val );
      }, this ) );
    }
    else {
      this.props.history.push( !this.props.user.isSignedIn ? '/apply' : '/c/application' )
    }

    // if preapproved form show different iframes for different cardType
    if( this.props.isPreapprovedForm ){
      this.termsAndConditionsDisclaimer = ( this.props.history.location.state.lpsData.cardType === 'MC' ) ? 'https://comenity.net/UltamateRewardsMasterCard/common/Legal/disclosures.xhtml' : 'https://comenity.net/UltamateRewardsCreditCard/common/Legal/disclosures.xhtml';
      this.electronicConsentDisclaimer = ( this.props.history.location.state.lpsData.cardType === 'MC' ) ? 'https://comenity.net/ultamaterewardsMasterCard/common/Legal/ESignDisclosure.xhtml' : 'https://comenity.net/ultamaterewardscreditcard/common/Legal/ESignDisclosure.xhtml';
      this.financialTermsDisclaimer = ( this.props.history.location.state.lpsData.cardType === 'MC' ) ? 'https://comenity.net/UltamateRewardsMasterCard/common/Legal/schumerbox.xhtml' : 'https://comenity.net/UltamateRewardsCreditCard/common/Legal/schumerbox.xhtml'
    }

  }

  componentWillUnmount(){
    // remove the iovation scripts from the DOM here
    removeScriptTag( this.IOVATIONCORE );
    removeScriptTag( this.IOVATIONCONFIGURATION );

    // this is used to make sure that the dynamic runtime added MPS snare script is removed so that whne we
    // come back to the page we don't have 2 in the DOM
    const allScripts = document.getElementsByTagName( 'script' );
    for ( var i = 0; i < allScripts.length; i++ ){
      if( allScripts[ i ].src.indexOf( 'mpsnare' ) !== -1 ){
        allScripts[ i ].parentNode.removeChild( allScripts[ i ] )
      }
    }
  }


  componentDidMount(){
    this.props.getBannerImage();
    scrollWindowToPosition( 0, 'easeInOutQuint' );

    if( !this.props.isPreapprovedForm ){
      if( !this.props.user.isSignedIn && !has( this.props.location, 'state.isSignedIn' ) ){
        // if the user isn't signed int and they arent' on the /apply route we need to take them there
        if( this.props.location.pathname !== '/apply' ){
          this.props.history.replace( '/apply' );
          return
        }
      }
      // set the form type if the form has been opened by routing
      if( has( this.props, 'location.state.formType' ) ){
        formType = this.props.location.state.formType;
      }

    }

    if( has( this.props.user, 'rewardsInfo.isCardHolder' ) ){
      if( this.props.user.rewardsInfo.isCardHolder ){
        global.location.href = fullyQualifyLink( host, '/ulta/myaccount/index.jsp?member=true' );
      }
    }
  }


  componentDidUpdate( prevProps ){

    // if we just received errors and we didn't have them before scroll the user to them
    if( this.props.messageBeans && isUndefined( prevProps.messageBeans ) ){
      // scrolll user to form level errors
      const scrollElemPos = document.getElementById( 'js-AdsformDecorator__container' );
      scrollWindowToPosition( scrollElemPos.offsetTop, 'easeInOutQuint' );
    }

    // check to see if the user is already a card memeber. If they are we need to redirect them to the proper page


    if( this.props.lpsFlag && this.state.tryFormSubmissionAfterLPSLookup && this.props.lpsRequestComplete ){
      this.setState( { tryFormSubmissionAfterLPSLookup: false } );
      const {
        lpsFlag
      } = this.props;
      if( lpsFlag === '200' || lpsFlag === '404' || lpsFlag === '452' ){
        // normal dom subit doesn't work here...needs redux form method
        const submitter = this.props.handleSubmit( this.submit );
        submitter();
      }
      else {
        const scrollElemPos = document.getElementById( 'js-AdsformDecorator__container' );
        scrollWindowToPosition( scrollElemPos.offsetTop, 'easeInOutQuint' );
      }
    }
  }



  lookUpLPSValues(){

    const {
      values
    } = this.props.formData;

    let phoneValid = false;
    let loginValid = false;

    if( values.phoneNumber ){
      phoneValid = isUndefined( validationMethod( values.phoneNumber, validationKeys.validatePhone, FormValidationMessages.invalidPhoneNumber ) );
    }

    if( values.login ){
      loginValid = isUndefined( validationMethod( values.login, validationKeys.validateEmail, FormValidationMessages.invalidEmail ) );
    }

    if( !this.state.blockLPSRequestUntilSubmit && values.login && loginValid
         && values.firstName && values.lastName && values.phoneNumber && phoneValid ){

      // if( isEmpty( this.state.initialLpsValues ) ){
      this.setState( {
        initialLpsValues: {
          login: values.login,
          firstName: values.firstName,
          lastName: values.lastName,
          phoneNumber: removeSpecialCharacters( values.phoneNumber )
        }
      } );
      // }

      values.phoneNumber = values.phoneNumber.replace( /[^A-Z0-9]+/ig, '' );
      if( !this.props.isPreapprovedForm ){
        this.props.lpsService( values );
      }
      this.setState( { blockLPSRequestUntilSubmit:  true } );
    }
  }

  submit( values ){
    // only submit the form dat if the form isn't currently in submission
    if( !this.props.applyFormIsSubmitting ){
      const submissionData = clone( values );
      // remove match data field
      delete submissionData.passwordMatch;
      delete submissionData.sessionID;
      delete submissionData.consent;

      // datamodified flag centered around LPS update profile
      // is the user logged in if so check to see if the day has changed

      // };
      submissionData.dataModified = false;// this.state.lpsValue

      submissionData._dynSessConf = this.props.sessionID;
      submissionData.iovationBlackBox = document.getElementById( 'js_ioBlackBox' ).value;

      // if there is no address2 value we still have to send it for the form to submit
      // it is critical that this condition is note removed
      if( !has( submissionData, 'address2' ) ){
        submissionData.address2 = '';
      }


      // since an email doesn't exist on the form we fill it with the login value
      if( !has( submissionData, 'email' ) ){
        submissionData.email = submissionData.login;
      }

      // get the authBuyer flag
      if( !this.props.isPreapprovedForm ){
        submissionData.authBuyerEnabled = document.getElementsByName( 'authBuyerEnabled' )[0].checked;
      }

      // sanitze the phoneNumber value
      if( submissionData.phoneNumber ){
        submissionData.phoneNumber = VMasker.toPattern( removeSpecialCharacters( submissionData.phoneNumber ), '999-999-9999' );
      }

      // sanitize the SSN value, swap virtualSSN field & applicantSSN and read it from applicantSSN if it is preapproved form or virtualSSN if it is regular form.
      submissionData.applicantSSN = !this.props.isPreapprovedForm ? removeSpecialCharacters( submissionData.virtualSSN ): submissionData.applicantSSN;
      delete submissionData.virtualSSN;
      // sanitive the applicate income amt
      let index = submissionData.applicantIncomeAmt.lastIndexOf( '.' );
      submissionData.applicantIncomeAmt = removeSpecialCharacters( submissionData.applicantIncomeAmt.substring( 0, index ) + submissionData.applicantIncomeAmt.substring( index + 3 ) );

      submissionData.applicantIncomeAmt = removeSpecialCharacters( submissionData.applicantIncomeAmt );

      if( !this.props.isPreapprovedForm ){

        if( this.props.editUserData ){
          const nData = {
            firstName: submissionData.firstName,
            lastName: submissionData.lastName,
            email: submissionData.email,
            phoneNumber: submissionData.phoneNumber,
            address1: submissionData.address1,
            address2: submissionData.address2,
            city: submissionData.city,
            state: submissionData.state,
            PhoneType: submissionData.PhoneType,
            postalCode: submissionData.postalCode
          }
          if( !isEqual( nData, this.state.loggedInUserData ) ){
            submissionData.dataModified = true;
          }
        }

        const handleSubmitWithLpsValues = ( submissionData ) => {

          let currentValues = {
            login: submissionData.login,
            firstName: submissionData.firstName,
            lastName: submissionData.lastName,
            phoneNumber: removeSpecialCharacters( submissionData.phoneNumber )
          }

          // if the user hasn't chaned any values associated with LPS lookup we can submit the form
          if( ( !this.props.user.isRewardsMember && isEqual( currentValues, this.state.initialLpsValues ) ) || this.props.user.isRewardsMember ){

            this.props.removeValidationMessages();
            if( this.state.secondaryLPSLookup && this.props.lpsFlag !== '405' ){
              let newSubmissionData = clone( submissionData );
              delete newSubmissionData.beautyClubNumber;
              let Data = {
                values: newSubmissionData,
                isSignedIn: this.props.user.isSignedIn,
                history: this.props.history,
                isPreapprovedForm: this.props.isPreapprovedForm
              }
              this.props.submitApplyData( Data );
            }
            else {
              let Data = {
                values: submissionData,
                isSignedIn: this.props.user.isSignedIn,
                history: this.props.history,
                isPreapprovedForm: this.props.isPreapprovedForm
              }
              this.props.submitApplyData( Data );
            }
          }
          else {

            // if the user has chagned ANY of the LPS value forms we must resubmit the lps lookup
            this.setState(
              {
                blockLPSRequestUntilSubmit: false,
                tryFormSubmissionAfterLPSLookup: true,
                secondaryLPSLookup: true
              }
            );
            this.lookUpLPSValues();
            this.props.change( 'phoneNumber', VMasker.toPattern( removeSpecialCharacters( this.props.formData.values.phoneNumber ), '(999) 999-9999' ) );
          }
        }


        // amke sure that an initialLPS lookup has been done, if not we force that
        if( !this.props.user.isSignedIn && isEmpty( this.state.initialLpsValues ) ){
          this.setState(
            {
              blockLPSRequestUntilSubmit: false,
              tryFormSubmissionAfterLPSLookup: true
            }
          );

          this.lookUpLPSValues();
        }
        // check to see if the user is signed in
        else if( this.props.user && this.props.user.isSignedIn ){

          if( this.props.editUserData ){
            handleSubmitWithLpsValues( submissionData );
          }
          else {


            // if the user has chagned ANY of the LPS value forms we must resubmit the lps lookup
            this.setState(
              {
                blockLPSRequestUntilSubmit: false,
                tryFormSubmissionAfterLPSLookup: true
              }
            );
            if( this.props.lspFlag !== '405' ){
              let Data = {
                values: submissionData,
                isSignedIn: this.props.user.isSignedIn,
                history: this.props.history,
                isPreapprovedForm: this.props.isPreapprovedForm
              }
              this.props.submitApplyData( Data );
            }
            else {
              // scrolll user to form level errors
              const scrollElemPos = document.getElementById( 'beautyClubNumber' );
              scrollWindowToPosition( scrollElemPos.offsetParent.offsetTop, 'easeInOutQuint' );
            }
          }

        }
        else {

          handleSubmitWithLpsValues( submissionData );
        }
      }
      else {
        if( has( submissionData, 'login' ) ){
          submissionData.email = submissionData.login;
        }
        let dataModified = false;
        forEach( this.props.history.location.state.lpsData, function( val, key ){
          if( key !== 'cardType' && key !== 'responseType' ){
            let sample  = key === 'phoneNumber' ? VMasker.toPattern( removeSpecialCharacters( val ), '999-999-9999' ) : val;
            if( submissionData[key] !== sample ){
              dataModified = true;
            }
          }
        } );
        submissionData.dataModified = dataModified;

        let Data = {
          values: submissionData,
          isSignedIn: this.props.user.isSignedIn,
          history: this.props.history,
          isPreapprovedForm: this.props.isPreapprovedForm
        }
        this.props.submitPreapprovedApplyData( Data );
      }
    }
  }

  getAuthorizedBuyerStatus(){
    this.props.change( 'authBuyerEnabled', !this.state.authorizeBuyer );
    this.setState( { authorizeBuyer: !this.state.authorizeBuyer } );
  }

  handleMessage( e ){
    this.setState( { displayMessage: !this.state.displayMessage } );
  }

  toggleModal(){
    this.setState( { isModalOpen: !this.state.isModalOpen } );
  }

  loadedTerms(){
    termsLoadedCounter++;
    if( termsLoadedCounter === 2 ){ // Number of terms files loaded into iframes
      this.setState( { allTermsLoaded: true } );
      termsLoadedCounter = 0;
    }
  }


  /**
   * Renders the CreditCardApply component
   */

  render(){
    const {
      history,
      handleSubmit,
      addressOpen,
      address2Open,
      toggleAddressFieldDisplay,
      toggleAddress2FieldDisplay,
      toggleEditUserData,
      formConfig,
      user,
      messageBeans,
      lpsFlag,
      selectedState,
      removeValidationMessages
    } = this.props;

    const options = [
      { value: 'M', label: formatMessage( messages.Mobile ) },
      { value: 'O', label: formatMessage( messages.Other ) },
      { value: 'H', label: formatMessage( messages.Home ) },
      { value: 'W', label: formatMessage( messages.Work ) }
    ]
    const isRightPasswordLength = ( val ) => {
      return validationMethod( val, validationKeys.passwordLength, FormValidationMessages.passwordLength );
    }
    const passwordWarning = ( val ) => {
      return validationMethod( val, validationKeys.showWarningMessage, messages.passwordWarning );
    }
    const passwordMatchWarning = ( val ) => {
      return validationMethod( val, validationKeys.showWarningMessage, messages.passwordMatchWarning );
    }
    const phoneWarning = ( val ) => {
      return validationMethod( val, validationKeys.showWarningMessage, messages.phoneWarning );
    }
    const ssnWarning = ( val ) => {
      return validationMethod( val, validationKeys.showWarningMessage, messages.ssnWarning );
    }
    const annualIncomeWarning = ( val ) => {
      return validationMethod( val, validationKeys.showWarningMessage, messages.annualIncomePurpose );
    }
    const annualIncomeWarningWiscon = ( val ) => {
      return validationMethod( val, validationKeys.showWarningMessage, messages.annualIncomePurposeWisconsin );
    }

    return (
      <div className='CreditCardApply'>
        { ( () => {
          if( this.props.isPreapprovedForm ){
            let name = ( this.props.history.location.state.lpsData.firstName ).toUpperCase();
            let cardType = this.props.history.location.state.lpsData.cardType === 'MC' ? ' MASTERCARD.' :' CREDIT CARD.';
            return (
              <div className='CreditCardApply_Preapproval'>
                <h3 className='CreditCardApply_Preapproval__header'>
                  { formatMessage( messages.preapprovedUserHeaderMsg, { name: name } ) }<br/>
                  { formatMessage( messages.preApprovalMessage ) }
                  ULTAMATE REWARDS<sup>&reg;</sup>
                  { cardType }
                </h3>
                <Divider dividerType='orangeHorizontal'/>
              </div>
            )
          }
        } )() }
        <div className='CreditCardApply_ContentInformationAndRules'>
          <div className='CreditCardApply_Information'>
            { formatMessage( messages.contentHeading ) }
          </div>
          { formatMessage( messages.contentHeadingMessage ) }
          <div className='CreditCardApply_Rules'>
            { formatMessage( messages.qualifyHeading ) }
          </div>
          <li>{ formatMessage( messages.qualifyRuleOne ) }</li>
          <li>{ formatMessage( messages.qualifyRuleTwo ) }</li>
          <li>{ formatMessage( messages.qualifyRuleThree ) }</li>
        </div>

        {
          ( () => {
            if( messageBeans ){
              return (
                <div className='CreditCardApply__errors'>
                  { messageBeans.map( ( message, index ) => {
                    return (
                      <ResponseMessages
                        key={ index }
                        message={ message.messageDesc }
                      />
                    )
                  } ) }
                </div>

              )
            }
          } )()
        }
        <form
          id='js-creditcardapplication'
          onSubmit={ handleSubmit( this.submit ) }
        >
          <div className='CreditCardApplyForm__container'>

            { ( () => {
              if( user.isSignedIn || this.props.isPreapprovedForm ){
                return (
                  <div className={
                    classNames( 'CreditCardApplyForm__column',
                      {
                        'CreditCardApplyForm__column--signedIn': user && !this.props.editUserData,
                        'CreditCardApplyForm__column--notSignedIn': !user,
                        'CreditCardApplyForm__column--editMode': user && this.props.editUserData
                      }
                    )
                  }
                  >

                    <EditPrepopulatedData
                      { ...this.props }
                      userData={ !this.props.isPreapprovedForm ? this.props.user.profileInfo : this.preapprovedUserData }
                      toggleEditUserData={ toggleEditUserData }
                      toggleAddressFieldDisplay={ toggleAddressFieldDisplay }
                      toggleAddress2FieldDisplay={ toggleAddress2FieldDisplay }
                      lpsFlag={ lpsFlag }
                      showEditMode={ this.showEditMode }
                    />
                  </div>
                );
              }
              else {



                return (
                  <div className={
                    classNames( 'CreditCardApplyForm__column',
                      {
                        'CreditCardApplyForm__column--signedIn': user,
                        'CreditCardApplyForm__column--notSignedIn': !user
                      }
                    )
                  }
                  >
                    <div className='CreditCardApplyForm__header'>
                      <div className='CreditCardApplyForm__header--firstText'>
                        { formatMessage( messages.firstThingsFirst ) }
                      </div>

                      { formatMessage( messages.createUltaacc ) }
                      &nbsp;
                      <span className='CreditCardApplyForm__header--signIn'>

                        <Anchor
                          clickHandler={
                            ( e ) => {
                              removeValidationMessages();
                              history.push( '/' );
                            }
                          }
                        >
                          { formatMessage( messages.signin ) }
                        </Anchor>
                      </span>
                    </div>

                    <div className='CreditCardApplyForm__Username'>

                      <InputField
                        label={ formatMessage( messages.emailOrUsername ) }
                        type='email'
                        name='login'
                        handleBlur={ this.lookUpLPSValues }
                      />
                    </div>

                    <div className='CreditCardApplyForm__Password'>
                      <InputField
                        label={ formatMessage( messages.createPassword ) }
                        type='password'
                        name='password'
                        disablePaste={ true }
                        validate={ [isRightPasswordLength] }
                        warn={ [passwordWarning] }
                        clearFields={ ['password', 'passwordMatch'] }
                        maskedToggleTarget='password'
                        showMaskedValue={ formConfig.fieldShowHideToggleData.password }
                      />
                    </div>

                    <div className='CreditCardApplyForm__PasswordMatch'>
                      <InputField
                        label={ formatMessage( messages.confirmPassword ) }
                        type='password'
                        name='passwordMatch'
                        disablePaste={ true }
                        warn={ [passwordMatchWarning] }
                        maskedToggleTarget='password'
                        showMaskedValue={ formConfig.fieldShowHideToggleData.password }
                      />
                    </div>

                    <div className='CreditCardApplyForm__Subscribe'>
                      <ToggleButton
                        name='emailOptIn'
                        label={ formatMessage( messages.subscribe ) }
                        isChecked={ this.props.formData.values? this.props.formData.values.emailOptIn: false }
                      />
                    </div>
                  </div>
                )
              }
            } )() }


            { ( () => {
              if( isEmpty( user.profileInfo ) && !this.props.isPreapprovedForm ){
                return (
                  <div className={
                    classNames( 'CreditCardApplyForm__column',
                      {
                        'CreditCardApplyForm__column--signedIn': user,
                        'CreditCardApplyForm__column--notSignedIn': !user
                      }
                    )
                  }
                  >

                    <div className='CreditCardApplyForm__contactInfo'>
                      <div className='CreditCardApplyForm__header'>
                        <div className='CreditCardApplyForm__contactInfo--heading'>
                          { formatMessage( messages.nextup ) }
                        </div>
                        <div className='CreditCardApplyForm__contactInfo--description'>
                          { formatMessage( messages.contactinfo ) }
                        </div>
                      </div>
                      <div className='CreditCardApplyForm__FirstName'>
                        <InputField
                          label={ formatMessage( messages.FirstName ) }
                          type='text'
                          name='firstName'
                          handleBlur={ this.lookUpLPSValues }
                          autoCapitalize={ true }
                        />
                      </div>

                      <div className='CreditCardApplyForm__LastName'>
                        <InputField
                          label={ formatMessage( messages.LastName ) }
                          type='text'
                          name='lastName'
                          handleBlur={ this.lookUpLPSValues }
                          autoCapitalize={ true }
                        />
                      </div>

                      <AddressForm
                        { ...this.props }
                        addressFormTitle={ formatMessage( messages.HomeAddress ) }
                        toggleAddressFieldDisplay={ toggleAddressFieldDisplay }
                        toggleAddress2FieldDisplay={ toggleAddress2FieldDisplay }
                        addressOpen={ addressOpen }
                        address2Open={ address2Open }
                      />

                      <InputWithDropDown
                        options={ options }
                        nameForDropdown={ 'phoneType' }
                        nameForInput={ 'phoneNumber' }
                        labelForInput={ formatMessage( messages.PhoneNumber ) }
                        warningForInputField={ [phoneWarning] }
                        { ...( has( this.props, 'formData.values.phoneNumber' ) && { formValue: this.props.formData.values.phoneNumber } ) }
                        inputBlurFunction={ this.lookUpLPSValues }
                        { ...this.props }
                        instructionalTextForInput={ formatMessage( messages.instructionalPhoneMessage ) }
                      />

                      <LpsLookUp
                        { ...this.props }
                        lpsFlag={ lpsFlag }
                      />

                    </div>
                  </div>
                )
              }
            } )() }

            <div className={
              classNames( 'CreditCardApplyForm__column',
                {
                  'CreditCardApplyForm__column--signedIn': user && !this.props.editUserData,
                  'CreditCardApplyForm__column--notSignedIn': !user,
                  'CreditCardApplyForm__column--editModeOn': user && this.props.editUserData
                }
              )
            }
            >

              <div className='CreditCardApplyForm__verficationInfo'>
                <div className='CreditCardApplyForm__header'>
                  <div className='CreditCardApplyForm__verficationInfo--heading'>
                    { formatMessage( messages.almostdone ) }
                  </div>
                  <div className='CreditCardApplyForm__verficationInfo--description'>
                    { formatMessage( messages.verifyPurpose ) }
                  </div>
                </div>
                <div className='CreditCardApplyForm__DateOfBirth'>
                  <InputField
                    label={ formatMessage( messages.DateOfBirth ) }
                    placeholder='MM/DD/YYYY'
                    formatter={ { pattern: '99/99/9999' } }
                    type='tel'
                    name='dateOfBirth'
                    disablePaste={ true }
                  />
                </div>

                <div className='CreditCardApplyForm__AnnualIncome'>
                  <InputField
                    label={ formatMessage( messages.AnnualIncome ) }
                    formatter={
                      {
                        money: {}
                      }
                    }
                    warn={ selectedState === 'WI' ? [annualIncomeWarningWiscon]:[annualIncomeWarning] }
                    maxLength={ checkIfAndroidChrome()? 7: 13 }
                    type='tel'
                    name='applicantIncomeAmt'
                    disablePaste={ true }
                    instructionalText={ selectedState === 'WI' ? formatMessage( messages.annualIncomePurposeWisconsin ): formatMessage( messages.annualIncomePurpose ) }
                  />
                </div>

                <div className='CreditCardApplyForm__SocialSecurity'>
                  { ( () => {
                    if( this.props.isPreapprovedForm ){
                      return (
                        <SsnLastFourInput
                          name='applicantSSN'
                        />
                      )
                    }
                    else {
                      return (
                        <InputField
                          label={ formatMessage( messages.SocialSecurity ) }
                          type='tel'
                          formatter={
                            {
                              pattern: '999-99-9999',
                              maskLastFourSSN: true
                            }
                          }
                          showMaskedValue={ formConfig.fieldShowHideToggleData.ssn }
                          maskedToggleTarget='ssn'
                          name='applicantSSN'
                          warn={ [ssnWarning] }
                          disablePaste={ true }
                          instructionalText={ formatMessage( messages.ssnWarning ) }
                        />
                      )
                    }
                  } )() }
                </div>

              </div>

              { ( () => {
                if( !this.props.isPreapprovedForm ){
                  return (
                    <div className='CreditCardApplyForm__AuthorizeBuyerSwitch'>
                      <div className='CreditCardApplyForm__AuthorizeBuyer'>
                        <ToggleButton
                          name='authBuyerEnabled'
                          label={ formatMessage( messages.addsomeone ) }
                          onClick={ this.getAuthorizedBuyerStatus }
                        />

                        { ( () => {
                          if( !this.state.authorizeBuyer && this.state.displayMessage ){
                            return (
                              <div className='CreditCardApplyForm__LearnMoreMessage'>
                                <Anchor
                                  url='#'
                                  clickHandler={ this.handleMessage }
                                >{ formatMessage( messages.learnmore ) }
                                </Anchor>
                              </div>
                            )
                          }
                        } )() }



                        { ( () => {
                          if( !this.state.authorizeBuyer ){
                            return (
                              <div className='CreditCardApplyForm__Message'>
                                { ( () => {
                                  if( !this.state.displayMessage ){
                                    return (
                                      <div>
                                        <div className='CreditCardApplyForm__HelpMessage'>
                                          { formatMessage( messages.authHelpText ) }
                                        </div>
                                        <div className='CreditCardApplyForm__HideMessage'>
                                          <Anchor
                                            className='CreditCardApplyForm__Anchor__HideMessage'
                                            url='#'
                                            clickHandler={ this.handleMessage }
                                          >{ formatMessage( messages.hide ) }
                                          </Anchor>
                                        </div>
                                      </div>
                                    )
                                  }
                                } )() }
                              </div>
                            )
                          }
                          else {
                            return (
                              <div className='CreditCardApplyForm__AuthorizeBuyer__Form'>
                                <AuthorizedBuyers { ...this.props } />
                                <div className='CreditCardApplyForm__HelpMessage'>
                                  { formatMessage( messages.authHelpText ) }
                                </div>
                              </div>
                            )
                          }
                        } )() }
                      </div>
                    </div>
                  )
                }
              } )() }
            </div>


          </div>


          <div className='CreditCardApplyForm__disclosure CreditCardApplyForm__disclosure---Title'>
            <h2>{ formatMessage( messages.disclosureTitle ) }</h2>
          </div>

          <div className='CreditCardApplyForm__disclosure'>
            { formatMessage( messages.disclosure ) }
            <span className='CreditCardApplyForm__disclosureLink'>
              <Anchor
                className='CreditCardApplyForm--link'
                target='_blank'
                url={ this.termsAndConditionsDisclaimer }
              >
                { formatMessage( messages.printDisclosure ) }
              </Anchor>
            </span>
          </div>

          <div className='CreditCardApplyForm__disclosure'>
            { formatMessage( messages.disclosure2 ) }
          </div>

          <div>
            <div className='LegalDisclaimerDropdown__LegalConsent'>
              { formatMessage( messages.esignAgreement ) }
            </div>
            <LegalDisclaimerDropdown
              iframeTitle={ formatMessage( messages.esignAgreement ) }
              iframeSrc={ this.electronicConsentDisclaimer }
              id='collapsible-right-col-terms'
              isLoaded={ this.loadedTerms }
            />

            <div className='dividerLine'>
              <Divider dividerType='gray'/>
            </div>
            <div className='LegalDisclaimerDropdown__LegalEsign'>
              { formatMessage( messages.consentDisclosure ) }
            </div>
            <LegalDisclaimerDropdown
              iframeTitle={ formatMessage( messages.consentDisclosure ) }
              defaultHeight='290px'
              iframeSrc={ this.financialTermsDisclaimer }
              id='collapsible-right-col-finance'
              isLoaded={ this.loadedTerms }
            />
            { ( () => {
              if( !this.props.isPreapprovedForm ){
                return (
                  <div className='CreditCardApplyForm__reviewMessage'>
                    { formatMessage( messages.applicationReviewMsg ) }
                  </div>
                )
              }
            } )() }
          </div>

          { ( ()=>{
            return (
              <div className='CreditCardApplyForm__consent__container'>
                <div className='CreditCardApplyForm__consent__container--colLeft'>
                  <div className='CreditCardApplyForm__consent'>
                    <ToggleButton
                      name='consent'
                      label={ formatMessage( messages.yesConsent ) }
                    />
                    <div className='CreditCardApplyForm__consent__learnMoreText'>
                      { formatMessage( messages.iconsent ) }
                    </div>
                  </div>
                </div>
                <div className='CreditCardApplyForm__consent__container--colRight'>
                  <div className='SigninField__SigninSubmit'>
                    <Button
                      disabled={ !this.state.allTermsLoaded }
                      showLoader={ this.props.applyFormIsSubmitting }
                      class='btn btn-single btn-lg'
                      id='finalSubmit'
                      inputTag='button'
                      btnType='submit'
                      btnSize='lg'
                      btnOption='single'
                    >
                      <div>
                        <span className='SigninField__SigninSubmit--img'>
                          <LockSVG />
                        </span>
                        <span className='SigninField__SigninSubmit--msg'>
                          { formatMessage( messages.submitApp ) }
                        </span>
                      </div>
                    </Button>
                  </div>
                </div>
              </div>
            )
          } )() }


          <CancelAndReturn
            cancelSteps={ -2 }
            history={ history }
            cancelText={ formatMessage( messages.cancel ) }
          />
        </form>
      </div>
    );
  }
}

CreditCardApplyForm.propTypes = propTypes;
CreditCardApplyForm.defaultProps = defaultProps;

export const validate = ( values, props ) => {
  const errors = {};
  let requiredFields = [];
  let emailFields = [];

  // validate the anonymouse usecase
  if( formType === 'anonymous' ){
    if( props.isPreapprovedForm ){
      requiredFields = ['consent', 'firstName', 'lastName', 'address1', 'city', 'state', 'postalCode', 'phoneNumber', 'dateOfBirth', 'applicantSSN', 'applicantIncomeAmt'];
    }
    else {
      requiredFields = ['consent', 'login', 'password', 'passwordMatch', 'firstName', 'lastName', 'address1', 'city', 'state', 'postalCode', 'phoneNumber', 'dateOfBirth', 'applicantSSN', 'applicantIncomeAmt'];
    }
    // match password error messaging
    errors.passwordMatch = validationMethod( [values.password, values.passwordMatch], validationKeys.shouldMatch, FormValidationMessages.passwordsDoNotMatch );
    emailFields.push( 'login' );
  }

  if( props.lpsFlag === '405' ){
    requiredFields.push( 'beautyClubNumber' );
  }

  if( formType === 'loggedIn' ){
    requiredFields = ['consent', 'dateOfBirth', 'applicantSSN', 'applicantIncomeAmt'];


    if( props.editUserData ){
      requiredFields.push( 'firstName' );
      requiredFields.push( 'lastName' );
      requiredFields.push( 'login' );
      requiredFields.push( 'address1' );
      requiredFields.push( 'city' );
      requiredFields.push( 'state' );
      requiredFields.push( 'postalCode' );
      requiredFields.push( 'phoneNumber' );
    }

  }

  if( values.authBuyerEnabled ){
    requiredFields.push( 'authBuyerFirstName' );
    requiredFields.push( 'authBuyerLastName' );
    requiredFields.push( 'authBuyerDOB' );
    requiredFields.push( 'authBuyerRelationship' );
  }


  emailFields.map(
    field => {
      errors[field] = validationMethod( values[field], validationKeys.validateEmail, FormValidationMessages.invalidEmail );
    }
  )

  requiredFields.map(
    field => {
      if( !values[field] ){
        errors[field] = requiredValidation( values[field] );
      }
    }
  );


  if( values.phoneNumber ){
    errors.phoneNumber = validationMethod( values.phoneNumber, validationKeys.validatePhone, FormValidationMessages.invalidPhoneNumber );
  }

  if( values.virtualSSN ){
    if( props.isPreapprovedForm ){
      errors.applicantSSN = validationMethod( values.virtualSSN, validationKeys.validateSSNlastFour, FormValidationMessages.invalidSSNlastFour );
    }
    else {
      errors.applicantSSN = validationMethod( values.virtualSSN, validationKeys.validateSSN, FormValidationMessages.invalidSSN );
    }
  }

  if( values.applicantIncomeAmt ){
    errors.applicantIncomeAmt = validationMethod( values.applicantIncomeAmt, validationKeys.validateAnnualIncome, FormValidationMessages.invalidAnnualIncome );
  }

  if( values.dateOfBirth ){
    errors.dateOfBirth = validationMethod( values.dateOfBirth, validationKeys.validateDOB, FormValidationMessages.invalidDOB );
  }

  if( values.authBuyerDOB ){
    errors.authBuyerDOB = validationMethod( values.authBuyerDOB, validationKeys.validateDOB, FormValidationMessages.invalidDOB );
  }

  if( values.postalCode ){
    errors.postalCode = validationMethod( values.postalCode, validationKeys.validateZipCode, FormValidationMessages.invalidZipCode );
  }

  return errors;
}


export const onSubmitFail = ( errors, dispatch ) => {

  let analyticErrors = [];
  analyticErrors.push( { 'CreditCardApplyFormErrors':  omitBy( errors, isNil ) } );

  let evt = {
    'name': 'trackErrorDisplayed',
    'data': analyticErrors
  }
  dispatch( analyticActions.triggerAnalyticsEvent( evt ) );

  let errorFields = keys( errors );

  for ( let i = 0; i < errorFields.length; i++ ){
    if( !isUndefined( errors[ errorFields[ i ] ] ) ){
      let elem = document.getElementById( errorFields[ i ] );
      if( elem ){
        // scroll to the first element that results in a dom match
        scrollWindowToPosition( elem.parentElement.offsetParent.offsetTop - 150, 'easeInOutQuint' );
      }
    }
  }
}

export const onSubmitSuccess = ( result, dispatch, props ) => {

  if( props.values.emailOptIn && !props.user.isSignedIn ){

    let data =  {
      'globalPageData': {
        'action': {
          'emailOptIn': 'true'
        }
      }
    }
    dispatch( dataLayerActions.setDataLayer( data ) );
  }


  if( !props.user.isSignedIn ){
    let data =  {
      'globalPageData': {
        'action': {
          'accountCreated': 'true',
          'login':'true'
        }
      }
    }
    dispatch( dataLayerActions.setDataLayer( data ) );
  }
  else {
    let data = {
      'globalPageData': {
        'action': {
          'login':'false'
        }
      }
    }
    dispatch( dataLayerActions.setDataLayer( data ) );
  }

}

const selector = formValueSelector( 'CreditCardApplication' );
const mapStateToProps = ( state ) => {
  return {
    formData: state.form.CreditCardApplication,
    selectedState: selector( state, 'state' )
  };
}

export const mapDispatchToProps = dispatch => {
  return {
    removeInputFromReduxForm: field => {
      dispatch( change( 'CreditCardApplication', field, '' ) );
      dispatch( untouch( 'CreditCardApplication', [field] ) );
    }

  }
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return reduxForm( {
    form: 'CreditCardApplication',
    initialValues: {
      virtualSSN: '',
      emailOptIn: true,
      authBuyerEnabled: false,
      consent: false
    },
    validate,
    onSubmitSuccess,
    onSubmitFail
  } )( connect( mapStateToProps, mapDispatchToProps )( CreditCardApplyForm ) );
};

export default connectFunction( mapStateToProps, mapDispatchToProps );
