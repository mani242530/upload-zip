/*
 * CreditCardApply Messages
 *
 * This contains all the text for the CreditCardApply component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {

  esignAgreement: {
    id: 'i18n.CreditCardApplyForm.esignAgreement',
    defaultMessage: 'Consent to Account Terms and Conditions'
  },
  consentDisclosure: {
    id: 'i18n.CreditCardApplyForm.consentDisclosure',
    defaultMessage: 'Consent to Financial Terms of the Account'
  },
  signininfo: {
    id: 'i18n.CreditCardApplyForm.signininfo',
    defaultMessage: 'We\'ll fill out the application form with your saved info to save you some time!'
  },
  cancel: {
    id: 'i18n.CreditCardApplyForm.cancel',
    defaultMessage: 'CANCEL & RETURN'
  },
  firstThingsFirst: {
    id: 'i18n.CreditCardApplyForm.firstThingsFirst',
    defaultMessage: 'First things first!'
  },
  contentHeading: {
    id: 'i18n.CreditCardApplyForm.contentHeading',
    defaultMessage: 'Content information and rules:'
  },
  contentHeadingMessage: {
    id: 'i18n.CreditCardApplyForm.contentHeadingMessage',
    defaultMessage: 'Comenity Bank is the issuer of the Ultamate Rewards Credit Card.If you wish to proceed with this application, you will be providing your personal information to Comenity Bank.'
  },
  qualifyHeading: {
    id: 'i18n.CreditCardApplyForm.firstThingsFirst',
    defaultMessage: 'In order to qualify, you must:'
  },
  qualifyRuleOne: {
    id: 'i18n.CreditCardApplyForm.qualifyRuleOne',
    defaultMessage: 'Be at least 18 years of age'
  },
  qualifyRuleTwo: {
    id: 'i18n.CreditCardApplyForm.qualifyRuleTwo',
    defaultMessage: 'Have a valid government-issued photo ID'
  },
  qualifyRuleThree: {
    id: 'i18n.CreditCardApplyForm.qualifyRuleThree',
    defaultMessage: 'Have a U.S. Social Security number'
  },
  createUltaacc: {
    id: 'i18n.CreditCardApplyForm.createUltaacc',
    defaultMessage: 'Create your Ulta.com account or'
  },
  HomeAddress: {
    id: 'i18n.CreditCardApplyForm.HomeAddress',
    defaultMessage: 'Home Address'
  },
  signin: {
    id: 'i18n.CreditCardApplyForm.signin',
    defaultMessage: 'sign in'
  },
  subscribe: {
    id: 'i18n.CreditCardApplyForm.subscribe',
    defaultMessage: 'Subscribe to emails about sales, new arrivals & special offers'
  },
  emailOrUsername: {
    id: 'i18n.CreditCardApplyForm.emailOrUsername',
    defaultMessage: 'Email Address'
  },
  createPassword: {
    id: 'i18n.CreditCardApplyForm.createPassword',
    defaultMessage: 'Create Password'
  },
  confirmPassword: {
    id: 'i18n.CreditCardApplyForm.confirmPassword',
    defaultMessage: 'Confirm Password'
  },
  FirstName: {
    id: 'i18n.CreditCardApplyForm.FirstName',
    defaultMessage: 'First Name'
  },
  LastName: {
    id: 'i18n.CreditCardApplyForm.LastName',
    defaultMessage: 'Last Name'
  },
  PhoneNumber: {
    id: 'i18n.CreditCardApplyForm.PhoneNumber',
    defaultMessage: 'Phone Number'
  },
  Mobile: {
    id: 'i18n.CreditCardApplyForm.Mobile',
    defaultMessage: 'Mobile'
  },
  Other: {
    id: 'i18n.CreditCardApplyForm.Other',
    defaultMessage: 'Office'
  },
  Home: {
    id: 'i18n.CreditCardApplyForm.Home',
    defaultMessage: 'Home'
  },
  Work: {
    id: 'i18n.CreditCardApplyForm.Work',
    defaultMessage: 'Work'
  },
  DateOfBirth: {
    id: 'i18n.CreditCardApplyForm.DateOfBirth',
    defaultMessage: 'Date of Birth'
  },
  AnnualIncome: {
    id: 'i18n.CreditCardApplyForm.AnnualIncome',
    defaultMessage: 'Annual Income'
  },
  SocialSecurity: {
    id: 'i18n.CreditCardApplyForm.SocialSecurity',
    defaultMessage: 'Social Security Number'
  },
  nextup: {
    id: 'i18n.CreditCardApplyForm.nextup',
    defaultMessage: 'Next up!'
  },
  contactinfo: {
    id: 'i18n.CreditCardApplyForm.contactinfo',
    defaultMessage: 'Now complete your contact info'
  },
  almostdone: {
    id: 'i18n.CreditCardApplyForm.almostdone',
    defaultMessage: 'Almost done!'
  },
  verifyPurpose: {
    id: 'i18n.CreditCardApplyForm.verifyPurpose',
    defaultMessage: 'For verification purposes, please provide'
  },
  addsomeone: {
    id: 'i18n.CreditCardApplyForm.addsomeone',
    defaultMessage: ' Add someone to your credit card account'
  },
  learnmore: {
    id: 'i18n.CreditCardApplyForm.learnmore',
    defaultMessage: ' Learn More'
  },
  annualIncomeButton: {
    id: 'i18n.CreditCardApplyForm.annualIncomeButton',
    defaultMessage: 'Why do you need my annual income?'
  },
  authHelpText: {
    id: 'i18n.CreditCardApplyForm.authHelpText',
    defaultMessage: 'Authorized buyers are allowed to purchase on your Account; however, as the primary account holder, you are responsible for payments on all purchases. You may add one authorized buyer to your account at this time.Once your account is open, you may add up to four total authorized buyers.'
  },
  annualIncomePurpose: {
    id: 'i18n.CreditCardApplyForm.annualIncomePurpose',
    defaultMessage: 'In order to comply with federal law, and to determine factors such as your credit limit, we consider your ability to meet the payment obligations associated with this account. Your income information is part of that consideration. If you do not wish to have alimony, child support and/or separate maintenance income considered as a basis for repaying this obligation, please do not include it in your Annual Income amount.'
  },
  annualIncomePurposeWisconsin: {
    id: 'i18n.CreditCardApplyForm.annualIncomePurposeWisconsin',
    defaultMessage: 'In order to comply with federal law, and to determine factors such as your credit limit, we consider your ability to meet the payment obligations associated with this account. Your income information is part of that consideration. If you do not wish to have alimony, child support and/or separate maintenance income considered as a basis for repaying this obligation, please do not include it in your Annual Income amount. Married WI Residents only: If you are applying for an individual account and your spouse also is a WI resident, combine your and your spouse\'s financial information.'
  },
  yesConsent: {
    id: 'i18n.CreditCardApplyForm.yesConsent',
    defaultMessage: 'Yes, I consent'
  },
  iconsent: {
    id: 'i18n.CreditCardApplyForm.iconsent',
    defaultMessage: 'By selecting “I Consent” and clicking “Submit Application”, I am electronically signing this application/solicitation and agree to enroll as an Ultamate Rewards member if not already enrolled.'
  },
  submitApp: {
    id: 'i18n.CreditCardApplyForm.submitApp',
    defaultMessage: 'SUBMIT APPLICATION'
  },
  hide: {
    id: 'i18n.CreditCardApplyForm.hide',
    defaultMessage: 'Hide'
  },
  continueMessage: {
    id: 'i18n.CreditCardApplyForm.continueMessage',
    defaultMessage: 'CONTINUE APPLICATION'
  },
  passwordWarning: {
    id: 'i18n.CreditCardApplyForm.passwordWarning',
    defaultMessage: 'Minimum of 8 characters and must include an upper case, lower case, number and special character'
  },
  passwordMatchWarning: {
    id: 'i18n.CreditCardApplyForm.passwordMatchWarning',
    defaultMessage: 'Please re-enter your password'
  },
  ssnWarning: {
    id: 'i18n.CreditCardApplyForm.ssnWarning',
    defaultMessage: 'We use this to verify your identity and obtain credit bureau information.'
  },
  phoneWarning: {
    id: 'i18n.CreditCardApplyForm.phoneWarning',
    defaultMessage: 'By providing your contact information, including any cellular or other phone numbers, you agree to be contacted regarding any of your Comenity Bank or Comenity Capital Bank accounts via calls to cell phones, text messages, or telephone calls, including the use of artificial or pre-recorded message calls, and calls made via automatic telephone dialing systems, or via email.'
  },
  disclosureTitle: {
    id: 'i18nCreditCardApplyForm.disclosureTitle',
    defaultMessage: 'Electronic Consent'
  },
  disclosure: {
    id: 'i18n.CreditCardApplyForm.disclosure',
    defaultMessage: 'You must read the disclosures presented in the Electronic Consent section of the Terms and Conditions box below prior to clicking "submit". Please also read the Credit Card Agreement, Privacy Statement and other information presented in the Terms and Conditions box prior to submitting this application and '
  },
  disclosure2: {
    id: 'i18n.CreditCardApplyForm.disclosure',
    defaultMessage: 'By signing or otherwise submitting this application/solicitation, each applicant ("I," "me" or "my" below) agrees and certifies that (1) I have read and agree to the disclosures provided on or with this application/solicitation, (2) the information I have supplied is true and correct, (3) I am applying to Comenity Capital Bank, PO Box 183003 Columbus, OH 43218-3003 ("Bank")for either an Ultamate Rewards® Mastercard Account or Ultamate Rewards® Credit Card Account and the Bank will decide which account, if any, to offer me, (4) I authorize the Bank to obtain credit reports on me, (5) if approved, my account will be governed by the Credit Card Agreement, (6) I understand that I may pay all of my account balance at any time without penalty and (7) this application/solicitation, any information I submitted to the Bank, and the Bank\'s final decision on my application/solicitation may be shared with and retained by Ulta Beauty.'
  },
  printDisclosure: {
    id: 'i18n.CreditCardApplyForm.printDisclosure',
    defaultMessage: 'print a copy for your records.'
  },
  instructionalPhoneMessage: {
    id: 'i18n.CreditCardApplyForm.instructionalPhoneMessage',
    defaultMessage: 'By providing your contact information, including any cellular or other phone numbers, you agree to be contacted regarding any of your Comenity Bank or Comenity Capital Bank accounts via calls to cell phones, text messages, or telephone calls, including the use of artificial or pre-recorded message calls, and calls made via automatic telephone dialing systems, or via email.'
  },
  preapprovedUserHeaderMsg: {
    id: 'i18n.CreditCardApplyForm.preapprovedUserHeaderMsg',
    defaultMessage: 'GOOD NEWS, {name}! '
  },
  preApprovalMessage:{
    id: 'i18n.CreditCardApplyForm.preApprovalMessage',
    defaultMessage: 'YOU\'RE PRE-APPROVED FOR THE '
  },
  applicationReviewMsg:{
    id: 'i18n.CreditCardApplyForm.applicationReviewMsg',
    defaultMessage: 'While your application for the Ultamate Rewards Mastercard is reviewed, if you do not qualify for the Ultamate Rewards Mastercard , you may be considered for and receive the Ultamate Rewards Credit Card, to be used only at Ulta Beauty. Before submitting your application, please review rates, fees and costs for both credit cards.'
  }
} );
