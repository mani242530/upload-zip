import React from 'react';
import ReactDOM from 'react-dom';
import CreditCardApplyForm, { onSubmitSuccess, onSubmitFail, mapDispatchToProps } from './CreditCardApplyForm';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import AuthorizedBuyers from 'abuy/components/AuthorizedBuyers/AuthorizedBuyers';
import messages from './CreditCardApplyForm.messages';
import { Provider } from 'react-redux';
import anim from 'utils/Animation/Animation';
import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';
import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';
import {
  host,
  fullyQualifyLink
} from 'utils/Formatters/formatters';

jest.mock( 'utils/Animation/Animation', () => {
  return {
    scrollWindowToPosition: jest.fn()
  }
} );

global.requestAnimationFrame = jest.fn();
describe( '<CreditCardApplyForm />', () => {
  let component;
  let props= {
    instantCreditResponse:{},
    messageBeans:'',
    change:jest.fn(),
    history :{ push:jest.fn() },
    getBannerImage:jest.fn(),
    formConfig:{ fieldShowHideToggleData:{} },
    user:{
      isRewardsMember: true,
      isSignedIn: true,
      profileInfo: {
        address:{
          address1:'123 N Main St',
          address2:'Apt 1A',
          city:'Chicago',
          country:'US',
          phoneNumber:'(312)-555-5555',
          postalCode:'60657',
          state:'IL'
        },
        beautyClubPlanType:{},
        dateOfBirth:'03/17',
        email:'ssmith@ulta.com',
        firstName:'Sasha',
        lastName:'Smith'
      }
    },
    toggleAddressFieldDisplay:jest.fn(),
    toggleAddress2FieldDisplay: jest.fn(),
    applyFormIsSubmitting:true,
    addressOpen:false,
    submitApplyData: jest.fn(),
    sessionID: '1055506',
    beautyClubNumberisRequired: false,
    lpsService: jest.fn(),
    lpsFlag:''
  }
  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <CreditCardApplyForm { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( '.CreditCardApply' ).length ).toBe( 1 );
  } );

  it( 'show the loading spinner', () => {
    expect( component.find( '.SigninField__SigninSubmit' ).length ).toBe( 1 );
  } )

  it( 'it should show the authorizeBuyer from', () => {
    component.find( '.CreditCardApplyForm__AuthorizeBuyer' ).find( '.ToggleButton__checkbox' ).simulate( 'click' );
    expect( component.find( 'AuthorizedBuyers' ).length ).toBe( 1 );
  } );

  it( 'it should show the authorizeBuyer help text', () => {
    expect( component.find( '.CreditCardApplyForm__HelpMessage' ).at( 0 ).text() ).toBe( messages.authHelpText.defaultMessage );
  } );

  it( 'it should show the learnmore text', () => {
    component.find( '.CreditCardApplyForm__AuthorizeBuyer' ).find( '.ToggleButton__checkbox' ).simulate( 'click' );
    component.find( 'Anchor' ).at( 1 ).simulate( 'click' );
    expect( component.find( '.CreditCardApplyForm__LearnMoreMessage' ).at( 0 ).text() ).toBe( messages.learnmore.defaultMessage );
  } );

  it( 'it should show the authorizeBuyer help text', () => {
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props }/>
      </Provider>
    );
    let node1 = component1.find( 'CreditCardApplyForm' );
    node1.instance().state.displayMessage = false;
    component1 = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props }/>
      </Provider>
    );
    expect( component1.find( '.CreditCardApplyForm__Anchor__HideMessage' ).at( 0 ).text() ).toBe( messages.hide.defaultMessage );
    expect( component1.find( '.CreditCardApplyForm__HelpMessage' ).text() ).toBe( messages.authHelpText.defaultMessage );

  } );

  it( 'it should show the React Modal ', () => {
    let props1 = {
      history :{ push:jest.fn() },
      change:jest.fn(),
      instantCreditResponse:{},
      messageBeans:'',
      formConfig:{ fieldShowHideToggleData:{} },
      user:{
        isRewardsMember: true,
        isSignedIn: true,
        profileInfo: {
          address:{
            address1:'123 N Main St',
            address2:'Apt 1A',
            city:'Chicago',
            country:'US',
            phoneNumber:'(312)-555-5555',
            postalCode:'60657',
            state:'IL'
          },
          beautyClubPlanType:{},
          dateOfBirth:'03/17',
          email:'ssmith@ulta.com',
          firstName:'Sasha',
          lastName:'Smith'
        }
      },
      getBannerImage:jest.fn(),
      toggleAddressFieldDisplay:jest.fn(),
      toggleAddress2FieldDisplay: jest.fn(),
      applyFormIsSubmitting:true,
      addressOpen:false,
      submitApplyData: jest.fn(),
      sessionID: '1055506',
      beautyClubNumberisRequired: false,
      lpsService: jest.fn(),
      lpsFlag:''
    }
    let component11 = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props1 }/>
      </Provider>
    );
    let node1 = component11.find( 'CreditCardApplyForm' );
    node1.state.isModalOpen = true;
    expect( component11.find( 'Modal' ).length ).toBe( 1 );
  } );


  it( 'Check the contact info form is available when user profile object is empty', () => {
    let props1 = {
      ...props,
      user:{
        isRewardsMember: false,
        isSignedIn: false,
        profileInfo: {}
      },
      location: {
        pathname: '/creditcards/apply'
      },
      history: {
        replace: jest.fn(),
        push: jest.fn()
      }
    }
    let component12 = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props1 }/>
      </Provider>
    );

    expect( component12.find( 'CreditCardApplyForm .CreditCardApplyForm__contactInfo' ).length ).toBe( 1 );
  } );

  it( 'tests the submit method ', () => {
    let props1 = {
      history :{ push:jest.fn() },
      change:jest.fn(),
      instantCreditResponse:{},
      messageBeans:'',
      formConfig:{ fieldShowHideToggleData:{} },
      user:{
        isRewardsMember: true,
        isSignedIn: true,
        profileInfo: {
          address:{
            address1:'123 N Main St',
            address2:'Apt 1A',
            city:'Chicago',
            country:'US',
            phoneNumber:'(312)-555-5555',
            postalCode:'60657',
            state:'IL'
          },
          beautyClubPlanType:{},
          dateOfBirth:'03/17',
          email:'ssmith@ulta.com',
          firstName:'Sasha',
          lastName:'Smith'
        }
      },
      getBannerImage:jest.fn(),
      toggleAddressFieldDisplay:jest.fn(),
      toggleAddress2FieldDisplay: jest.fn(),
      applyFormIsSubmitting:false,
      addressOpen:false,
      submitApplyData: jest.fn(),
      sessionID: '1055506',
      beautyClubNumberisRequired: false,
      lpsService: jest.fn(),
      lpsFlag:''
    }
    let component11 = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props1 }/>
      </Provider>
    );

    let appElement = document.createElement( 'div' );
    appElement.id='js_ioBlackBox';
    document.body.appendChild( appElement );

    let radioInput = document.createElement( 'input' );
    radioInput.type = 'radio';
    radioInput.name='authBuyerEnabled';
    document.body.appendChild( radioInput );

    let node1 = component11.find( 'CreditCardApplyForm' ).instance();
    const values = {
      login:'test@test.com',
      phoneNumber: '1234567890',
      firstName: 'test',
      lastName: 'test1',
      // email: 'test@test.com',
      address1: 'test',
      // address2: 'egtts',
      city: 'ABCDEF',
      state: 'AL',
      PhoneType: 'M',
      postalCode: '32456',
      applicantIncomeAmt: '12.34',
      virtualSSN: '12343444554'
    };
    node1.submit( values );
    expect( props1.submitApplyData ).toBeCalled();
  } );

  it( 'should call lookUpLPSValues if isSignedIn is false', () => {
    const props = {
      instantCreditResponse:{},
      messageBeans:'',
      location:{},
      form:'CreditCardApplication',
      history :{ push:jest.fn(), replace:jest.fn() },
      getBannerImage:jest.fn(),
      formConfig:{ fieldShowHideToggleData:{} },
      user:{
        isRewardsMember: true,
        isSignedIn: false,
        profileInfo: {}
      },
      initialValues: {
        virtualSSN: '1231231',
        emailOptIn: true,
        authBuyerEnabled: false,
        consent: false,
        login:'test@test.com',
        phoneNumber:'8471232311',
        firstName:'Joe',
        lastName:'Manuel'
      },
      toggleAddressFieldDisplay:jest.fn(),
      toggleAddress2FieldDisplay: jest.fn(),
      applyFormIsSubmitting:false,
      addressOpen:false,
      submitApplyData: jest.fn(),
      sessionID: '1055506',
      beautyClubNumberisRequired: false,
      lpsService: jest.fn(),
      lpsFlag:''
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props }/>
      </Provider>
    );

    const appElement = document.createElement( 'div' );
    appElement.id='js_ioBlackBox';
    document.body.appendChild( appElement );

    const radioInput = document.createElement( 'input' );
    radioInput.type = 'radio';
    radioInput.name='authBuyerEnabled';
    document.body.appendChild( radioInput );

    let node = component.find( 'CreditCardApplyForm' ).instance();
    const values = {
      login:'test@test.com',
      phoneNumber: '1234567890',
      firstName: 'test',
      lastName: 'test1',
      address1: 'test',
      city: 'ABCDEF',
      state: 'AL',
      PhoneType: 'M',
      postalCode: '32456',
      applicantIncomeAmt: '12.34',
      virtualSSN: '12343444554'
    };
    node.lookUpLPSValues = jest.fn();
    node.submit( values );
    expect( node.lookUpLPSValues ).toBeCalled();
  } );

  it( 'should call submitPreapprovedApplyData if isPreapprovedForm is true', () => {
    const props = {
      toggleEditUserData:jest.fn(),
      submitPreapprovedApplyData:jest.fn(),
      editUserData: true,
      isPreapprovedForm:true,
      instantCreditResponse:{},
      messageBeans:'',
      history:{
        push:jest.fn(),
        replace:jest.fn(),
        location:{
          state:{
            lpsData:{ postalCode:60540, firstName : 'joe', phoneNumber:'8471232' }
          }
        }
      },
      form:'CreditCardApplication',
      location :{},
      getBannerImage:jest.fn(),
      formConfig:{ fieldShowHideToggleData:{} },
      user:{
        isRewardsMember: true,
        isSignedIn: true,
        profileInfo: {}
      },
      initialValues: {
        virtualSSN: '1231231',
        emailOptIn: true,
        authBuyerEnabled: false,
        consent: false,
        login:'test@test.com',
        phoneNumber:'8471232311',
        firstName:'Joe',
        lastName:'Manuel'
      },
      toggleAddressFieldDisplay:jest.fn(),
      toggleAddress2FieldDisplay: jest.fn(),
      applyFormIsSubmitting:false,
      addressOpen:false,
      submitApplyData: jest.fn(),
      sessionID: '1055506',
      beautyClubNumberisRequired: false,
      lpsService: jest.fn(),
      lpsFlag:''
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props }/>
      </Provider>
    );

    const appElement = document.createElement( 'div' );
    appElement.id='js_ioBlackBox';
    document.body.appendChild( appElement );

    const radioInput = document.createElement( 'input' );
    radioInput.type = 'radio';
    radioInput.name='authBuyerEnabled';
    document.body.appendChild( radioInput );

    let node = component.find( 'CreditCardApplyForm' ).instance();
    const values = {
      login:'test@test.com',
      phoneNumber: '1234567890',
      firstName: 'test',
      lastName: 'test1',
      email: 'test@test.com',
      address1: 'test',
      address2: 'egtts',
      city: 'ABCDEF',
      state: 'AL',
      PhoneType: 'M',
      postalCode: '32456',
      applicantIncomeAmt: '12.34',
      virtualSSN: '12343444554'
    };
    node.submit( values );
    expect( props.submitPreapprovedApplyData ).toBeCalled();
  } );

  it( 'should call submitApplyData if secondaryLPSLookup is false', () => {
    const props = {
      removeValidationMessages:jest.fn(),
      hasProfileData: true,
      toggleEditUserData:jest.fn(),
      submitPreapprovedApplyData:jest.fn(),
      editUserData: true,
      isPreapprovedForm:false,
      instantCreditResponse:{},
      messageBeans:'',
      history:{
        push:jest.fn(),
        replace:jest.fn(),
        location:{
          state:{
            lpsData:{ postalCode:60540, firstName : 'joe', phoneNumber:'8471232' }
          }
        }
      },
      form:'CreditCardApplication',
      location: {
        state:{
          formType:'loggedIn'
        }
      },
      getBannerImage:jest.fn(),
      formConfig:{ fieldShowHideToggleData:{} },
      user:{
        isRewardsMember: true,
        isSignedIn: true,
        profileInfo: {
          address:{
            address1:'123 N Main St',
            address2:'Apt 1A',
            city:'Chicago',
            country:'US',
            phoneNumber:'(312)-555-5555',
            postalCode:'60657',
            state:'IL'
          },
          beautyClubPlanType:{},
          dateOfBirth:'03/17',
          email:'ssmith@ulta.com',
          firstName:'Sasha',
          lastName:'Smith'
        }
      },
      initialValues: {
        virtualSSN: '1231231',
        emailOptIn: true,
        authBuyerEnabled: false,
        consent: false,
        login:'test@test.com',
        phoneNumber:'8471232311',
        firstName:'Joe',
        lastName:'Manuel'
      },
      toggleAddressFieldDisplay:jest.fn(),
      toggleAddress2FieldDisplay: jest.fn(),
      applyFormIsSubmitting:false,
      addressOpen:false,
      submitApplyData: jest.fn(),
      sessionID: '1055506',
      beautyClubNumberisRequired: false,
      lpsService: jest.fn(),
      lpsFlag:'406'
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props }/>
      </Provider>
    );

    const appElement = document.createElement( 'div' );
    appElement.id='js_ioBlackBox';
    document.body.appendChild( appElement );

    const radioInput = document.createElement( 'input' );
    radioInput.type = 'radio';
    radioInput.name='authBuyerEnabled';
    document.body.appendChild( radioInput );

    let node = component.find( 'CreditCardApplyForm' ).instance();
    const values = {
      login:'test@test.com',
      phoneNumber: '1234567890',
      firstName: 'test',
      lastName: 'test1',
      email: 'test@test.com',
      address1: 'test',
      address2: 'egtts',
      city: 'ABCDEF',
      state: 'AL',
      PhoneType: 'M',
      postalCode: '32456',
      applicantIncomeAmt: '12.34',
      virtualSSN: '12343444554'
    };
    node.state.secondaryLPSLookup=false;
    node.submit( values );
    expect( props.submitApplyData ).toBeCalled();
  } );
  it( 'should call submitApplyData if secondaryLPSLookup is true', () => {
    const props = {
      removeValidationMessages:jest.fn(),
      hasProfileData: true,
      toggleEditUserData:jest.fn(),
      submitPreapprovedApplyData:jest.fn(),
      editUserData: true,
      isPreapprovedForm:false,
      instantCreditResponse:{},
      messageBeans:'',
      history:{
        push:jest.fn(),
        replace:jest.fn(),
        location:{
          state:{
            lpsData:{ postalCode:60540, firstName : 'joe', phoneNumber:'8471232' }
          }
        }
      },
      form:'CreditCardApplication',
      location: {
        state:{
          formType:'loggedIn'
        }
      },
      getBannerImage:jest.fn(),
      formConfig:{ fieldShowHideToggleData:{} },
      user:{
        isRewardsMember: true,
        isSignedIn: true,
        profileInfo: {
          address:{
            address1:'123 N Main St',
            address2:'Apt 1A',
            city:'Chicago',
            country:'US',
            phoneNumber:'(312)-555-5555',
            postalCode:'60657',
            state:'IL'
          },
          beautyClubPlanType:{},
          dateOfBirth:'03/17',
          email:'ssmith@ulta.com',
          firstName:'Sasha',
          lastName:'Smith'
        }
      },
      initialValues: {
        virtualSSN: '1231231',
        emailOptIn: true,
        authBuyerEnabled: false,
        consent: false,
        login:'test@test.com',
        phoneNumber:'8471232311',
        firstName:'Joe',
        lastName:'Manuel'
      },
      toggleAddressFieldDisplay:jest.fn(),
      toggleAddress2FieldDisplay: jest.fn(),
      applyFormIsSubmitting:false,
      addressOpen:false,
      submitApplyData: jest.fn(),
      sessionID: '1055506',
      beautyClubNumberisRequired: false,
      lpsService: jest.fn(),
      lpsFlag:'405'
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props }/>
      </Provider>
    );

    const appElement = document.createElement( 'div' );
    appElement.id='js_ioBlackBox';
    document.body.appendChild( appElement );

    const radioInput = document.createElement( 'input' );
    radioInput.type = 'radio';
    radioInput.name='authBuyerEnabled';
    document.body.appendChild( radioInput );

    let node = component.find( 'CreditCardApplyForm' ).instance();
    node.state.secondaryLPSLookup=true;
    const values = {
      login:'test@test.com',
      phoneNumber: '1234567890',
      firstName: 'test',
      lastName: 'test1',
      email: 'test@test.com',
      address1: 'test',
      address2: 'egtts',
      city: 'ABCDEF',
      state: 'AL',
      PhoneType: 'M',
      postalCode: '32456',
      applicantIncomeAmt: '12.34',
      virtualSSN: '12343444554'
    };
    node.submit( values );
    expect( props.submitApplyData ).toBeCalled();
  } );
  it( 'should set tryFormSubmissionAfterLPSLookup and secondaryLPSLookup as true if isRewardsMember is false', () => {
    const props = {
      removeValidationMessages:jest.fn(),
      hasProfileData: true,
      toggleEditUserData:jest.fn(),
      submitPreapprovedApplyData:jest.fn(),
      editUserData: true,
      isPreapprovedForm:false,
      instantCreditResponse:{},
      messageBeans:'',
      history:{
        push:jest.fn(),
        replace:jest.fn(),
        location:{
          state:{
            lpsData:{ postalCode:60540, firstName : 'joe', phoneNumber:'8471232' }
          }
        }
      },
      form:'CreditCardApplication',
      location: {
        state:{
          formType:'loggedIn'
        }
      },
      getBannerImage:jest.fn(),
      formConfig:{ fieldShowHideToggleData:{} },
      user:{
        isRewardsMember: false,
        isSignedIn: true,
        profileInfo: {
          address:{
            address1:'123 N Main St',
            address2:'Apt 1A',
            city:'Chicago',
            country:'US',
            phoneNumber:'(312)-555-5555',
            postalCode:'60657',
            state:'IL'
          },
          beautyClubPlanType:{},
          dateOfBirth:'03/17',
          email:'ssmith@ulta.com',
          firstName:'Sasha',
          lastName:'Smith'
        }
      },
      initialValues: {
        virtualSSN: '1231231',
        emailOptIn: true,
        authBuyerEnabled: false,
        consent: false,
        login:'test@test.com',
        phoneNumber:'8471232311',
        firstName:'Joe',
        lastName:'Manuel'
      },
      toggleAddressFieldDisplay:jest.fn(),
      toggleAddress2FieldDisplay: jest.fn(),
      applyFormIsSubmitting:false,
      addressOpen:false,
      submitApplyData: jest.fn(),
      sessionID: '1055506',
      beautyClubNumberisRequired: false,
      lpsService: jest.fn(),
      lpsFlag:'406'
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props }/>
      </Provider>
    );

    const appElement = document.createElement( 'div' );
    appElement.id='js_ioBlackBox';
    document.body.appendChild( appElement );

    const radioInput = document.createElement( 'input' );
    radioInput.type = 'radio';
    radioInput.name='authBuyerEnabled';
    document.body.appendChild( radioInput );

    let node = component.find( 'CreditCardApplyForm' ).instance();
    node.state.secondaryLPSLookup=true;
    const values = {
      login:'test@test.com',
      phoneNumber: '1234567890',
      firstName: 'test',
      lastName: 'test1',
      email: 'test@test.com',
      address1: 'test',
      address2: 'egtts',
      city: 'ABCDEF',
      state: 'AL',
      PhoneType: 'M',
      postalCode: '32456',
      applicantIncomeAmt: '12.34',
      virtualSSN: '12343444554'
    };
    node.submit( values );
    expect( node.state.tryFormSubmissionAfterLPSLookup ).toBe( true );
    expect( node.state.secondaryLPSLookup ).toBe( true );
  } );

  it( 'should put analytics and datalayer events on onsubmitFail and onSubmitSuccess', () => {
    let props1 = {
      history :{ push:jest.fn() },
      change:jest.fn(),
      instantCreditResponse:{},
      messageBeans:'',
      formConfig:{ fieldShowHideToggleData:{} },
      user:{
        isRewardsMember: true,
        isSignedIn: true,
        profileInfo: {
          address:{
            address1:'123 N Main St',
            address2:'Apt 1A',
            city:'Chicago',
            country:'US',
            phoneNumber:'(312)-555-5555',
            postalCode:'60657',
            state:'IL'
          },
          beautyClubPlanType:{},
          dateOfBirth:'03/17',
          email:'ssmith@ulta.com',
          firstName:'Sasha',
          lastName:'Smith'
        }
      },
      getBannerImage:jest.fn(),
      toggleAddressFieldDisplay:jest.fn(),
      toggleAddress2FieldDisplay: jest.fn(),
      applyFormIsSubmitting:false,
      addressOpen:false,
      submitApplyData: jest.fn(),
      sessionID: '1055506',
      beautyClubNumberisRequired: false,
      lpsService: jest.fn(),
      lpsFlag:''
    }
    let component11 = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props1 }/>
      </Provider>
    );

    let evt = {
      'name': 'trackErrorDisplayed',
      'data': [
        { CreditCardApplyFormErrors: { 'email':'Required' } }
      ]
    }

    let dispatch = jest.fn();
    component11.find( 'CreditCardApplyForm' ).props().onSubmitFail( { 'email':'Required' }, dispatch );
    expect( dispatch ).toBeCalledWith( analyticActions.triggerAnalyticsEvent( evt ) );

    const result=true;
    dispatch=jest.fn();
    let props = {
      values:{
        emailOptIn:true
      },
      user:{
        isSignedIn:false
      }
    }
    let data = {
      'globalPageData': {
        'action': {
          'emailOptIn': 'true'
        }
      }
    }
    component11.find( 'CreditCardApplyForm' ).props().onSubmitSuccess( result, dispatch, props );
    expect( dispatch ).toBeCalledWith( dataLayerActions.setDataLayer( data ) );

    dispatch=jest.fn();
    props = {
      values:{
        emailOptIn:false
      },
      user:{
        isSignedIn:false
      }
    }
    data = {
      'globalPageData': {
        'action': {
          'accountCreated': 'true',
          'login':'true'
        }
      }
    }
    component11.find( 'CreditCardApplyForm' ).props().onSubmitSuccess( result, dispatch, props );
    expect( dispatch ).toBeCalledWith( dataLayerActions.setDataLayer( data ) );

    dispatch=jest.fn();
    props = {
      values:{
        emailOptIn:false
      },
      user:{
        isSignedIn:true
      }
    }
    data = {
      'globalPageData': {
        'action': {
          'login':'false'
        }
      }
    }
    component11.find( 'CreditCardApplyForm' ).props().onSubmitSuccess( result, dispatch, props );
    expect( dispatch ).toBeCalledWith( dataLayerActions.setDataLayer( data ) );

  } );

  it( 'tests the loadedTerms method ', () => {
    let props1 = {
      history :{ push:jest.fn() },
      change:jest.fn(),
      instantCreditResponse:{},
      messageBeans:'',
      formConfig:{ fieldShowHideToggleData:{} },
      user:{
        isRewardsMember: true,
        isSignedIn: true,
        profileInfo: {
          address:{
            address1:'123 N Main St',
            address2:'Apt 1A',
            city:'Chicago',
            country:'US',
            phoneNumber:'(312)-555-5555',
            postalCode:'60657',
            state:'IL'
          },
          beautyClubPlanType:{},
          dateOfBirth:'03/17',
          email:'ssmith@ulta.com',
          firstName:'Sasha',
          lastName:'Smith'
        }
      },
      getBannerImage:jest.fn(),
      toggleAddressFieldDisplay:jest.fn(),
      toggleAddress2FieldDisplay: jest.fn(),
      applyFormIsSubmitting:true,
      addressOpen:false,
      submitApplyData: jest.fn(),
      sessionID: '1055506',
      beautyClubNumberisRequired: false,
      lpsService: jest.fn(),
      lpsFlag:''
    }
    let component11 = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props1 }/>
      </Provider>
    );
    let node1 = component11.find( 'CreditCardApplyForm' ).instance();
    node1.loadedTerms();
    node1.loadedTerms();
    expect( node1.state.allTermsLoaded ).toBeTruthy();
  } );

  it( 'should dispatch an event to store when removeInputFromReduxForm method is invoked ', () => {
    const dispatch  = jest.fn();
    const props = mapDispatchToProps( dispatch );
    props.removeInputFromReduxForm();
    expect( dispatch ).toBeCalled();
  } );

  it( 'should set blockLPSRequestUntilSubmit to true when lookUpLPSValues ', () => {
    let component;
    let props= {
      instantCreditResponse:{},
      messageBeans:'',
      location:{},
      form:'CreditCardApplication',
      history :{ push:jest.fn(), replace:jest.fn() },
      getBannerImage:jest.fn(),
      formConfig:{ fieldShowHideToggleData:{} },
      user:{
        isRewardsMember: true,
        isSignedIn: false,
        profileInfo: {}
      },
      initialValues: {
        virtualSSN: '1231231',
        emailOptIn: true,
        authBuyerEnabled: false,
        consent: false,
        login:'test@test.com',
        phoneNumber:'8471232311',
        firstName:'Joe',
        lastName:'Manuel'
      },
      toggleAddressFieldDisplay:jest.fn(),
      toggleAddress2FieldDisplay: jest.fn(),
      applyFormIsSubmitting:true,
      addressOpen:false,
      submitApplyData: jest.fn(),
      sessionID: '1055506',
      beautyClubNumberisRequired: false,
      lpsService: jest.fn(),
      lpsFlag:''
    }
    const store = configureStore( {}, CONFIG );

    component = mountWithIntl(
      <Provider store={ store }>
        <CreditCardApplyForm { ...props }/>
      </Provider>
    );

    component.find( 'CreditCardApplyForm' ).instance().setState( { 'blockLPSRequestUntilSubmit':false } );
    component.find( 'CreditCardApplyForm' ).instance().lookUpLPSValues();
    expect( component.find( 'CreditCardApplyForm' ).instance().state.blockLPSRequestUntilSubmit ).toBe( true );
  } );


  component = mountWithIntl(
    <Provider store={ store }>
      <CreditCardApplyForm { ...props }/>
    </Provider>
  );
  let instance = component.find( 'CreditCardApplyForm' ).instance();

  it( 'should call the handleMessage method', () => {
    expect( instance.state.displayMessage ).toEqual( true );
    instance.handleMessage();
    expect( instance.state.displayMessage ).toEqual( false );
  } );

  it( 'should call the toggleModal method', () => {
    expect( instance.state.isModalOpen ).toEqual( false );
    instance.toggleModal();
    expect( instance.state.isModalOpen ).toEqual( true );
  } );

} );

