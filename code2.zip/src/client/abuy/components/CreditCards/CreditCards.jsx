/**
e* CreditCards
 */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { formatMessage } from 'shared/components/Global/Global';
import CreditCardsFooter from 'hf/components/Footers/shared/CreditCardsFooter/CreditCardsFooter';
import './CreditCards.css';
import {
  actions,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import {
  actions as formActions
} from 'shared/actions/Forms/Forms.actions';

import {
  Route,
  Redirect,
  Switch
} from 'react-router-dom';

import isEmpty from 'lodash/isEmpty';
import has from 'lodash/has';

import messages from './CreditCards.messages';

import BaseLayout from 'shared/components/BaseLayout/BaseLayout';
import ApplyAndBuyLoginForm from 'abuy/components/ApplyAndBuyLoginForm/ApplyAndBuyLoginForm';
import CreditCardApplyForm from 'abuy/components/CreditCardApplyForm/CreditCardApplyForm';
import CreditcardPrescreenEntryForm from 'abuy/components/CreditcardPrescreenEntryForm/CreditcardPrescreenEntryForm';
import AdsformDecorator from 'abuy/components/AdsformDecorator/AdsformDecorator';
import CreditProcessingError from 'abuy/components/CreditProcessingError/CreditProcessingError';
import CreditApprovalResponse from 'abuy/components/CreditApprovalResponse/CreditApprovalResponse';
import ExistingCardholderResponse from 'abuy/components/ExistingCardholderResponse/ExistingCardholderResponse';
import NotifyMailResponse from 'abuy/components/NotifyMailResponse/NotifyMailResponse';
import CreditReport from 'abuy/components/CreditReport/CreditReport';
import Spinner from 'shared/components/Icons/spinner';
import MetaData from 'shared/components/MetaData/MetaData';
import isUndefined from 'lodash/isUndefined';


/**
 * Class
 * @extends React.Component
 */
export class CreditCards extends Component{

  constructor( props ){
    super( props );
    this.getBannerImage = this.getBannerImage.bind( this );
  }


  componentDidMount(){
    global.onpopstate = e => {
      e.preventDefault();
    }
  }

  componentDidUpdate( prevProps ){
    // if the sessionmanger had determined that the session isn'ta ctive redirect the user
    if( isUndefined( this.props.session.activeSession ) && prevProps.session.activeSession ){
      this.props.history.replace( '/' );
    }

    // handle the response from the profile lite service
    if( this.props.user.isSignedIn && isUndefined( prevProps.user.isSignedIn ) ){
      if( this.props.history.location.pathname !== '/c/preapproved' && this.props.history.location.pathname.indexOf( '/c/offer' ) === -1 ){
        this.props.history.replace( '/c/application' );
      }
    }
  }

  getBannerImage( sourcePage = 'ApplyCardLogin' ){

    // bannr service data instantiation
    let data = {
      sourcePage
    }
    this.props.getBannerData( data );
  }
  /*
   * Renders the CreditCards component
   */
  render(){



    /* we must show the loading spinner until we have a valid sessionID and we get a response back from the profile lite servive around the status of the user  */
    if( isUndefined( this.props.user.isRewardsMember ) || isUndefined( this.props.session.activeSession ) ){
      return (
        <BaseLayout hasLeftNav={ false } >
          <div className='Loading__spinner'>
            <Spinner />
          </div>
        </BaseLayout>
      )
    }
    else {

      const {
        bannerImageUri,
        addressOpen,
        address2Open,
        sessionID,
        toggleAddressFieldDisplay,
        lpsFlag
      } = this.props;
      return (
        <div className='CreditCards'>
          <BaseLayout
            hasLeftNav={ false }
          >
            <Route
              exact
              path='/'
              render={
                ( props ) => {
                  return (
                    <div className='creditcardsPage'>
                      <AdsformDecorator
                        bannerImageUri={ bannerImageUri }
                        cancelSteps={ -1 }
                      >
                        <MetaData
                          title={ formatMessage( messages.basetitle ) }
                          description={ formatMessage( messages.basedescription ) }
                          noFollow={ true }
                          analyticsPageName='credit card:sign in'
                          analyticsPageChannel='credit card'
                          setDataLayer={ this.props.setDataLayer }
                          headerDisplayConfig={
                            {
                              mobileHeaderDisplayMode: 'focused',
                              desktopHeaderDisplayMode: 'focused'
                            }
                          }
                          footerDisplayConfig={
                            {
                              mobileFooterDisplayMode: 'bare',
                              desktopFooterDisplayMode: 'bare'
                            }
                          }
                        >
                          <ApplyAndBuyLoginForm
                            { ...props }
                            messageBeans={ this.props.user.messageBeans }
                            isSignedIn={ this.props.user.isSignedIn }
                            successPath='/c/application'
                            getBannerImage={ ()=>{
                              this.getBannerImage( 'ApplyCardLogin' )
                            } }
                            removeValidationMessages={ this.props.removeValidationMessages }
                            sourcePage='ccLogin'
                            sessionID={ sessionID }
                            fieldShowHideToggleData={ this.props.fieldShowHideToggleData }
                          />
                        </MetaData>
                      </AdsformDecorator>
                    </div>
                  )
                }
              }
            />
            <Route
              exact
              path='/c/application'
              render={
                ( props ) => {
                  return (
                    <div className='loggedInApplication'>
                      <AdsformDecorator
                        bannerImageUri={ bannerImageUri }
                        cancelSteps={ -2 }
                      >
                        <MetaData
                          title={ formatMessage( messages.CapplicationTitle ) }
                          analyticsPageName='credit card:apply'
                          analyticsPageChannel='credit card'
                          analyticsPageLocation='credit card'
                          setDataLayer={ this.props.setDataLayer }
                          headerDisplayConfig={
                            {
                              mobileHeaderDisplayMode: 'focused',
                              desktopHeaderDisplayMode: 'focused'
                            }
                          }
                          footerDisplayConfig={
                            {
                              mobileFooterDisplayMode: 'bare',
                              desktopFooterDisplayMode: 'bare'
                            }
                          }
                        >
                          <CreditCardApplyForm
                            { ...this.props }
                            { ...props }
                            removeValidationMessages={ this.props.removeValidationMessages }
                            getBannerImage={ ()=>{
                              this.getBannerImage( 'ApplyCardLogin' )
                            } }
                            toggleAddressFieldDisplay={ toggleAddressFieldDisplay }
                            addressOpen={ addressOpen }
                            address2Open={ address2Open }
                            sessionID={ sessionID }
                            lpsFlag={ lpsFlag }
                          />
                        </MetaData>
                      </AdsformDecorator>
                    </div>
                  )
                }
              }
            />
            <Route
              exact
              path='/c/preapproved'
              render={
                ( props ) => {
                  return (
                    <div className='preapprovedApplication'>
                      <AdsformDecorator
                        bannerImageUri={ bannerImageUri }
                        cancelSteps={ -2 }
                      >
                        <MetaData
                          title={ formatMessage( messages.CpreapprovalTitle ) }
                          description={ formatMessage( messages.applyDescription ) }
                          analyticsPageName={ 'credit card:apply:'+props.location.state.flow }
                          analyticsPageChannel='credit card'
                          firePageNavEvent={ false }
                          setDataLayer={ this.props.setDataLayer }
                          headerDisplayConfig={
                            {
                              mobileHeaderDisplayMode: 'focused',
                              desktopHeaderDisplayMode: 'focused'
                            }
                          }
                          footerDisplayConfig={
                            {
                              mobileFooterDisplayMode: 'bare',
                              desktopFooterDisplayMode: 'bare'
                            }
                          }
                        >
                          <CreditCardApplyForm
                            { ...props }
                            { ...this.props }
                            isPreapprovedForm={ true }
                            getBannerImage={ ()=>{
                              this.getBannerImage( 'ApplyCardLogin' )
                            } }
                            toggleAddressFieldDisplay={ toggleAddressFieldDisplay }
                            addressOpen={ addressOpen }
                            address2Open={ address2Open }
                            sessionID={ sessionID }
                            lpsFlag={ lpsFlag }
                          />
                        </MetaData>
                      </AdsformDecorator>
                    </div>
                  )
                }
              }
            />

            <Route
              exact
              path='/apply'
              render={
                ( props ) => {

                  return (
                    <div className='anonymousApplication'>
                      <AdsformDecorator
                        bannerImageUri={ bannerImageUri }
                        cancelSteps={ -2 }
                      >
                        <MetaData
                          title={ formatMessage( messages.applyTitle ) }
                          description={ formatMessage( messages.applyDescription ) }
                          noFollow={ true }
                          analyticsPageName='credit card:apply'
                          analyticsPageChannel='credit card'
                          analyticsPageLocation='credit card'
                          setDataLayer={ this.props.setDataLayer }
                          headerDisplayConfig={
                            {
                              mobileHeaderDisplayMode: 'focused',
                              desktopHeaderDisplayMode: 'focused'
                            }
                          }
                          footerDisplayConfig={
                            {
                              mobileFooterDisplayMode: 'bare',
                              desktopFooterDisplayMode: 'bare'
                            }
                          }
                        >
                          <CreditCardApplyForm
                            { ...this.props }
                            { ...props }
                            instantCreditResponse={ this.props.instantCreditResponse }
                            messageBeans={ this.props.messageBeans }
                            user={ this.props.user }
                            removeValidationMessages={ this.props.removeValidationMessages }
                            getBannerImage={ ()=>{
                              this.getBannerImage( 'ApplyCardLogin' )
                            } }
                            toggleAddressFieldDisplay={ toggleAddressFieldDisplay }
                            toggleAddress2FieldDisplay={ this.props.toggleAddress2FieldDisplay }
                            applyFormIsSubmitting={ this.props.applyFormIsSubmitting }
                            addressOpen={ addressOpen }
                            address2Open={ address2Open }
                            fieldShowHideToggleData={ this.props.fieldShowHideToggleData }
                            submitApplyData={ this.props.submitApplyData }
                            sessionID={ sessionID }
                            beautyClubNumberisRequired={ this.props.beautyClubNumberisRequired }
                            lpsService={ this.props.lpsService }
                            lpsFlag={ lpsFlag }

                          />
                        </MetaData>
                      </AdsformDecorator>
                    </div>
                  )
                }
              }
            />

            <Route
              exact
              path='/c/mail-notify'
              render={
                props => (
                  <div className='emailNotifyResponsePage'>
                    <MetaData
                      title={ formatMessage( messages.mailNotifyTitle ) }
                      analyticsPageName='credit card:apply:under review'
                      analyticsPageChannel='credit card'
                      setDataLayer={ this.props.setDataLayer }
                      analyticActions={ { 'creditCardNotifyByMail': 'true' } }
                      headerDisplayConfig={
                        {
                          mobileHeaderDisplayMode: 'focused',
                          desktopHeaderDisplayMode: 'focused'
                        }
                      }
                      footerDisplayConfig={
                        {
                          mobileFooterDisplayMode: 'bare',
                          desktopFooterDisplayMode: 'bare'
                        }
                      }
                    >
                      <NotifyMailResponse { ...props }
                        isMobileDevice={ this.props.isMobileDevice }
                        guestServiceNumber={ formatMessage( messages.guestServiceNumber ) }
                        shoppingCartCount={ this.props.user.shoppingCartCount }
                        isRewardsMember={ this.props.user.isRewardsMember }
                      />
                    </MetaData>
                  </div>
                )
              }
            />
            { /* route for users who got preapproval notice in letter */ }
            <Route
              exact
              path='/c/offer'
              render={
                props => (
                  <div className='preScreenIdEntryForm'>
                    <AdsformDecorator
                      bannerImageUri={ bannerImageUri }
                      cancelSteps={ -2 }
                    >
                      <MetaData
                        title={ formatMessage( messages.offerTitle ) }
                        analyticsPageName='credit card:prescreen id entry'
                        analyticsPageChannel='credit card'
                        setDataLayer={ this.props.setDataLayer }
                        description={ formatMessage( messages.applyDescription ) }
                        noFollow={ true }
                        headerDisplayConfig={
                          {
                            mobileHeaderDisplayMode: 'focused',
                            desktopHeaderDisplayMode: 'focused'
                          }
                        }
                        footerDisplayConfig={
                          {
                            mobileFooterDisplayMode: 'bare',
                            desktopFooterDisplayMode: 'bare'
                          }
                        }
                      >
                        <CreditcardPrescreenEntryForm
                          { ...props }
                          user={ this.props.user }
                          successPath='/c/preapproved'
                          getBannerImage={ ()=>{
                            this.getBannerImage( 'ApplyCardLogin' )
                          } }
                        />
                      </MetaData>
                    </AdsformDecorator>
                  </div>
                )
              }
            />

            <Route
              exact
              path='/c/error'
              render={
                props => (
                  <div className='errorResponsePage'>
                    <MetaData
                      title={ formatMessage( messages.errorTitle ) }
                      analyticsPageName='credit card:apply:error'
                      analyticsPageChannel='credit card'
                      setDataLayer={ this.props.setDataLayer }
                      analyticActions={ { 'creditCardProcessingError': 'true' } }
                      headerDisplayConfig={
                        {
                          mobileHeaderDisplayMode: 'focused',
                          desktopHeaderDisplayMode: 'focused'
                        }
                      }
                      footerDisplayConfig={
                        {
                          mobileFooterDisplayMode: 'bare',
                          desktopFooterDisplayMode: 'bare'
                        }
                      }
                    >
                      <CreditProcessingError { ...props }
                        isMobileDevice={ this.props.isMobileDevice }
                        guestServiceNumber={ formatMessage( messages.guestServiceNumber ) }
                        goBack={ this.props.goBack }
                        shoppingCartCount={ this.props.user.shoppingCartCount }
                        helpPhoneNumber={ formatMessage( messages.helpPhone ) }
                        isRewardsMember={ this.props.user.isRewardsMember }
                      />
                    </MetaData>
                  </div>
                )
              }
            />
            <Route
              exact
              path='/c/existing'
              render={
                props => (
                  <div className='existingCustomerResponsePage'>
                    <MetaData
                      title={ formatMessage( messages.exisitingTitle ) }
                      analyticsPageName='credit card:apply:existing'
                      analyticsPageChannel='credit card'
                      setDataLayer={ this.props.setDataLayer }
                      analyticActions={ { 'creditCardExistingCardHolder': 'true' } }
                      headerDisplayConfig={
                        {
                          mobileHeaderDisplayMode: 'focused',
                          desktopHeaderDisplayMode: 'focused'
                        }
                      }
                      footerDisplayConfig={
                        {
                          mobileFooterDisplayMode: 'bare',
                          desktopFooterDisplayMode: 'bare'
                        }
                      }
                    >
                      <ExistingCardholderResponse { ...props }
                        isMobileDevice={ this.props.isMobileDevice }
                        guestServiceNumber={ formatMessage( messages.guestServiceNumber ) }
                        shoppingCartCount={ this.props.user.shoppingCartCount }
                      />
                    </MetaData>
                  </div>
                )
              }
            />
            <Route
              exact
              path='/c/report'
              render={
                props => (
                  <div className='creditReportPage'>
                    <MetaData
                      title={ formatMessage( messages.reportTitle ) }
                      analyticsPageName='credit card:apply:credit report'
                      analyticsPageChannel='credit card'
                      setDataLayer={ this.props.setDataLayer }
                      headerDisplayConfig={
                        {
                          mobileHeaderDisplayMode: 'focused',
                          desktopHeaderDisplayMode: 'focused'
                        }
                      }
                      footerDisplayConfig={
                        {
                          mobileFooterDisplayMode: 'bare',
                          desktopFooterDisplayMode: 'bare'
                        }
                      }
                    >
                      <CreditReport { ...props } />
                    </MetaData>
                  </div>
                )
              }
            />
            <Route
              exact
              path='/c/approved'
              render={
                props => (
                  <div className='approvalResponsePage'>
                    <MetaData
                      title={ formatMessage( messages.CapprovedTitle ) }
                      analyticsPageName='credit card:apply:approved'
                      analyticsPageChannel='credit card'
                      setDataLayer={ this.props.setDataLayer }
                      analyticActions={ { 'creditCardApproved': 'true' } }
                      headerDisplayConfig={
                        {
                          mobileHeaderDisplayMode: 'focused',
                          desktopHeaderDisplayMode: 'focused'
                        }
                      }
                      footerDisplayConfig={
                        {
                          mobileHeaderDisplayMode: 'bare',
                          desktopHeaderDisplayMode: 'bare'
                        }
                      }
                    >
                      <CreditApprovalResponse { ...props }
                        isMobileDevice={ this.props.isMobileDevice }
                        guestServiceNumber={ formatMessage( messages.guestServiceNumber ) }
                        shoppingCartCount={ this.props.user.shoppingCartCount }
                        isRewardsMember={ this.props.user.isRewardsMember }
                      />
                    </MetaData>
                  </div>
                )
              }
            />
            <Route
              exact
              path='/c/preapproved/approved'
              render={
                props => (
                  <div className='preApprovedApprovalResponsePage'>
                    <MetaData
                      title={ formatMessage( messages.CPreapprovedApprovedTitle ) }
                      analyticActions={ { 'creditCardPreapproved': 'true' } }
                      analyticsPageName='credit card:apply:preapproved'
                      analyticsPageChannel='credit card'
                      setDataLayer={ this.props.setDataLayer }
                      headerDisplayConfig={
                        {
                          mobileHeaderDisplayMode: 'focused',
                          desktopHeaderDisplayMode: 'focused'
                        }
                      }

                      footerDisplayConfig={
                        {
                          mobileFooterDisplayMode: 'bare',
                          desktopFooterDisplayMode: 'bare'
                        }
                      }
                    >
                      <CreditApprovalResponse
                        { ...props }
                        isSignedIn={ this.props.user.isSignedIn }
                        shoppingCartCount={ this.props.user.shoppingCartCount }
                      />
                    </MetaData>
                  </div>
                )
              }
            />

            <div className='CreditCards__Footer'>
              <CreditCardsFooter helpPhoneNumber={ formatMessage( messages.helpPhone ) } />
            </div>
          </BaseLayout>
        </div>
      );
    }
  }
}

export const mapStateToProps = ( state ) => {
  return {
    ...state.pagedata.creditcards,
    formConfig: state.pagedata.formConfig,
    session: state.session,
    user: state.user,
    isMobileDevice: state.global.isMobileDevice
  };
}

let lpsINDEX = 0;

export const mapDispatchToProps = ( dispatch ) => {

  return {

    getBannerData: ( data ) => {
      dispatch( getActionDefinition( 'banner', 'requested' )( data ) );
    },

    setDataLayer: ( data, evt ) => {
      dispatch( dataLayerActions.setDataLayer( data, evt ) );
    },

    triggerAnalyticsEvent: ( evt ) => {
      dispatch( analyticActions.triggerAnalyticsEvent( evt ) );
    },

    toggleAddressFieldDisplay: () => {
      dispatch( formActions.toggleAddressFieldDisplay() )
    },

    toggleAddress2FieldDisplay: () => {
      dispatch( formActions.toggleAddress2FieldDisplay() )
    },

    goBack: () => {
      dispatch( formActions.goBack() )
    },

    toggleEditUserData: () => {
      dispatch( formActions.toggleEditUserData() )
    },

    removeValidationMessages: () => {
      dispatch( formActions.removeValidationMessages() )
    },

    submitApplyData:( data ) => {
      dispatch( getActionDefinition( 'applyForm', 'requested' )( data ) );
    },

    submitPreapprovedApplyData:( data ) => {
      dispatch( getActionDefinition( 'prescreenApply', 'requested' )( data ) );
    },

    lpsService: ( data ) => {
      let _data = data;
      if( process.env.NODE_ENV === 'development' ){
        const codes = ['404', '405'];
        _data.__FORCE_CODE = codes[lpsINDEX]
        lpsINDEX++;
      }
      dispatch( getActionDefinition( 'lpsLookUp', 'requested' )( _data ) );
    }
  }
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( CreditCards ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );
