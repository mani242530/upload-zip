/*
 * MobileBodi Messages
 *
 * This contains all the text for the MobileBodi component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  CPreapprovedApprovedTitle:{
    id: 'i18n.CreditCards.CPreapprovedApprovedTitle',
    defaultMessage: 'Ulta Credit Card Preapproval'
  },
  CapprovedTitle:{
    id: 'i18n.CreditCards.Capproved',
    defaultMessage: 'Ulta Credit Card Approval'
  },
  reportTitle:{
    id: 'i18n.CreditCards.reportTitle',
    defaultMessage: 'Ulta Credit Card Credit Report'
  },
  exisitingTitle:{
    id: 'i18n.CreditCards.exisitingTitle',
    defaultMessage: 'Ulta Credit Card Existing Account'
  },
  errorTitle:{
    id: 'i18n.CreditCards.errorTitle',
    defaultMessage: 'Ulta Credit Card Processing Error'
  },
  offerTitle:{
    id: 'i18n.CreditCards.offerTitle',
    defaultMessage: 'Ulta Preapproved Credit Card Application'
  },
  mailNotifyTitle:{
    id: 'i18n.CreditCards.mailNotifyTitle',
    defaultMessage: 'Ulta Credit Card Review'
  },
  applyDescription:{
    id: 'i18n.CreditCards.applyDescription',
    defaultMessage: 'Submit an Ulta credit card application today to get even more perks on purchases at Ulta Beauty. Subject to credit approval.'
  },
  applyTitle:{
    id: 'i18n.CreditCards.applyTitle',
    defaultMessage: 'Ulta Credit Card Application'
  },
  CpreapprovalTitle: {
    id: 'i18n.CreditCards.CpreapprovalTitle',
    defaultMessage: 'Ulta Credit Card Preapproval'
  },
  CapplicationTitle: {
    id: 'i18n.CreditCards.CapplicationTitle',
    defaultMessage: 'Ulta Credit Card Application'
  },
  basetitle: {
    id: 'i18n.CreditCards.basetitle',
    defaultMessage: 'Ulta Credit Card Application Log-In'
  },

  basedescription: {
    id: 'i18n.CreditCards.basedescription',
    defaultMessage: 'Ready to apply for the Ulta credit card? Begin here. With the Ultamate Rewards credit card, beauty loves you back even more.'
  },
  cancel: {
    id: 'i18n.CreditCards.cancel',
    defaultMessage: 'CANCEL & RETURN'
  },
  hereToHelp: {
    id: 'i18n.CreditCards.hereToHelp',
    defaultMessage: 'We\'re here to help every day:'
  },
  helpHours: {
    id: 'i18n.CreditCards.helpHours',
    defaultMessage: '7am-11pm CT'
  },
  helpPhone: {
    id: 'i18n.CreditCards.helpPhone',
    defaultMessage: ' 1-866-257-9195'
  },
  guestServiceNumber: {
    id: 'i18n.CreditCards.guestServiceNumber',
    defaultMessage: ' 1-866-983-8582'
  },
  cardIssue: {
    id: 'i18n.CreditCards.cardIssue',
    defaultMessage: 'This card is issued by Comenity Capital Bank, pursuant to a license from Mastercard International Incorporated. Mastercard is a registered trademark of Mastercard International Incorporated. 1-866-257-9195 (Ultamate Rewards Mastercard) 1-866-271-2680 (Ultamate Rewards World Mastercard) (TDD/TTY 1-888-819-1918)'
  }
} );
