import React from 'react';
import ReactDOM from 'react-dom';
import CreditCards, { pageDataObj, mapDispatchToProps } from './CreditCards';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './CreditCards.messages';
import InputField from 'shared/components/InputField/InputField';
import { IntlProvider } from 'react-intl';
import { Provider } from 'react-redux';
import configureStore from 'abuy/abuy.store';
import CONFIG from 'ccr/ccr.config';
import {
  MemoryRouter,
  BrowserRouter as Router,
  Route
} from 'react-router-dom';
import {
  getActionDefinition,
  registerServiceName
} from 'shared/actions/Services/Services.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';

import {
  actions as formActions
} from 'shared/actions/Forms/Forms.actions';

describe( '<CreditCards />', () => {


  const store = configureStore( {}, CONFIG );
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <Router>
          <CreditCards />
        </Router>
      </Provider>
    );
  } );

  describe( 'route tests', () => {

    it( 'renders the /c/preapproved/approved url with the correct attributes on the compoennt', () => {
      global.requestAnimationFrame = jest.fn();
      let component = createCreditCardComponent( '/c/preapproved/approved' );
      const creditApprovalResponse = component.find( 'CreditApprovalResponse' );
      expect( creditApprovalResponse.length ).toBe( 1 );
    } );

    it( 'renders the / url with the correct attributes on the compoennt', () => {
      let component = createCreditCardComponent( '/' );
      const applyAndBuyLoginForm = component.find( 'ApplyAndBuyLoginForm' );
      expect( applyAndBuyLoginForm.length ).toBe( 1 );
    } );

    it( 'renders the /c/application url with the correct attributes on the compoennt', () => {
      let component = createCreditCardComponent( '/c/application' );
      const creditCardApplyForm = component.find( 'CreditCardApplyForm' );
      expect( creditCardApplyForm.length ).toBe( 1 );
    } );

    it( 'renders the /c/preapproved url with the correct attributes on the compoennt', () => {
      let component = createCreditCardComponent( '/c/preapproved' );
      const creditCardApplyForm = component.find( 'CreditCardApplyForm' );
      expect( creditCardApplyForm.length ).toBe( 1 );
    } );

    it( 'renders the /apply url with the correct attributes on the compoennt', () => {
      let component = createCreditCardComponent( '/apply' );
      const creditCardApplyForm = component.find( 'CreditCardApplyForm' );
      expect( creditCardApplyForm.length ).toBe( 1 );
    } );

    it( 'renders the /c/mail-notify url with the correct attributes on the compoennt', () => {
      let component = createCreditCardComponent( '/c/mail-notify' );
      const notifyMailResponse = component.find( 'NotifyMailResponse' );
      expect( notifyMailResponse.length ).toBe( 1 );
    } );

    it( 'renders the /c/offer url with the correct attributes on the compoennt', () => {
      let component = createCreditCardComponent( '/c/offer' );
      const notifyMailResponse = component.find( 'CreditcardPrescreenEntryForm' );
      expect( notifyMailResponse.length ).toBe( 1 );
    } );

    it( 'renders the /c/error url with the correct attributes on the compoennt', () => {
      let component = createCreditCardComponent( '/c/error' );
      const notifyMailResponse = component.find( 'CreditProcessingError' );
      expect( notifyMailResponse.length ).toBe( 1 );
    } );

    it( 'renders the /c/existing url with the correct attributes on the compoennt', () => {
      let component = createCreditCardComponent( '/c/existing' );
      const notifyMailResponse = component.find( 'ExistingCardholderResponse' );
      expect( notifyMailResponse.length ).toBe( 1 );
    } );

    it( 'renders the /c/report url with the correct attributes on the compoennt', () => {
      let component = createCreditCardComponent( '/c/report' );
      const notifyMailResponse = component.find( 'CreditReport' );
      expect( notifyMailResponse.length ).toBe( 1 );
    } );

    it( 'renders the /c/approved url with the correct attributes on the compoennt', () => {
      let component = createCreditCardComponent( '/c/approved' );
      const notifyMailResponse = component.find( 'CreditApprovalResponse' );
      expect( notifyMailResponse.length ).toBe( 1 );
    } );


  } );

  describe( '<Creditcards /> - MapDispatchToProps', () => {
    const store = configureStore( {}, CONFIG );
    const props = {
      // checkoutPage: jest.fn(),
      // user: jest.fn(),
      // session: jest.fn(),
      // pagedata:jest.fn(),
      // minicart:jest.fn(),
      // global:jest.fn()
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <CreditCards { ...props }/>
      </Provider>
    );
    const dispatch = jest.fn();
    beforeEach( ()=> {
      dispatch.mockClear();
    } )
    const mdp  = mapDispatchToProps( dispatch );

    it( 'getBannerData should dispatch the proper action', () => {
      const data = jest.fn();
      registerServiceName( 'banner' );
      const event = mdp.getBannerData( data );
      expect( dispatch ).toHaveBeenCalledWith(
        getActionDefinition( 'banner', 'requested' )( data )
      );
    } );

    it( 'submitApplyData should dispatch the proper action', () => {
      const data = jest.fn();
      registerServiceName( 'applyForm' );
      const event = mdp.submitApplyData( data );
      expect( dispatch ).toHaveBeenCalledWith(
        getActionDefinition( 'applyForm', 'requested' )( data )
      );
    } );

    it( 'setDataLayer should dispatch the proper action', () => {
      const data = jest.fn();
      const evt = jest.fn();
      const event = mdp.setDataLayer( data, evt );
      expect( dispatch ).toHaveBeenCalledWith(
        dataLayerActions.setDataLayer( data, evt )
      );
    } );

    it( 'triggerAnalyticsEvent should dispatch the proper action', () => {
      const evt = jest.fn();
      const event = mdp.triggerAnalyticsEvent( evt );
      expect( dispatch ).toHaveBeenCalledWith(
        analyticActions.triggerAnalyticsEvent( evt )
      );
    } );

    it( 'toggleAddressFieldDisplay should dispatch the proper action', () => {
      const event = mdp.toggleAddressFieldDisplay( );
      expect( dispatch ).toHaveBeenCalledWith(
        formActions.toggleAddressFieldDisplay( )
      );
    } );

    it( 'toggleAddress2FieldDisplay should dispatch the proper action', () => {
      const event = mdp.toggleAddress2FieldDisplay( );
      expect( dispatch ).toHaveBeenCalledWith(
        formActions.toggleAddress2FieldDisplay( )
      );
    } );

    it( 'goBack should dispatch the proper action', () => {
      const event = mdp.goBack( );
      expect( dispatch ).toHaveBeenCalledWith(
        formActions.goBack( )
      );
    } );

    it( 'toggleEditUserData should dispatch the proper action', () => {
      const event = mdp.toggleEditUserData( );
      expect( dispatch ).toHaveBeenCalledWith(
        formActions.toggleEditUserData( )
      );
    } );

    it( 'removeValidationMessages should dispatch the proper action', () => {
      const event = mdp.removeValidationMessages( );
      expect( dispatch ).toHaveBeenCalledWith(
        formActions.removeValidationMessages( )
      );
    } );

    it( 'submitPreapprovedApplyData should dispatch the proper action', () => {
      const data = jest.fn();
      registerServiceName( 'prescreenApply' );
      const event = mdp.submitPreapprovedApplyData( data );
      expect( dispatch ).toHaveBeenCalledWith(
        getActionDefinition( 'prescreenApply', 'requested' )( data )
      );
    } );

    it( 'lpsService should dispatch the proper action', () => {
      const data = jest.fn();
      registerServiceName( 'lpsLookUp' );
      const event = mdp.lpsService( data );
      expect( dispatch ).toHaveBeenCalledWith(
        getActionDefinition( 'lpsLookUp', 'requested' )( data )
      );
    } );

    // it( 'hideOutOfStockItems should dispatch the proper action', () => {
    //   const event = mdp.hideOutOfStockItems();
    //   expect( dispatch ).toHaveBeenCalledWith(
    //     miniCartActions.hideOutOfStockItems()
    //   );
    // } );

    // it( 'setChkoutBtnStatus should dispatch the proper action', () => {
    //   const event = mdp.setChkoutBtnStatus();
    //   expect( dispatch ).toHaveBeenCalledWith(
    //     miniCartActions.setChkoutBtnStatus()
    //   );
    // } );

    // it( 'submitRealtimeResponse should dispatch the proper action', () => {
    //   const data = jest.fn();
    //   registerServiceName( 'QubitRealtimeEvent' );
    //   const event = mdp.submitRealtimeResponse( data );
    //   expect( dispatch ).toHaveBeenCalledWith(
    //     getActionDefinition( 'QubitRealtimeEvent', 'requested' )( data )
    //   );
    // } );

  } ) ;

} );

const createCreditCardComponent = ( pathname ) => {

  const store1 = configureStore( {
    session:{
      activeSession: true
    },
    user: {
      isRewardsMember: true
    }

  }, CONFIG );
  const props = {
    setDataLayer: jest.fn()
  }
  const component = mountWithIntl(
    <Provider store={ store1 }>
      <MemoryRouter initialEntries={ [{ pathname :pathname, state : { 'isAccountCreated':true, 'lpsData': { postalCode:60540, firstName : 'joe', phoneNumber:'8471232' } } }] }>
        <CreditCards { ...props } />
      </MemoryRouter>
    </Provider>
  );
  return component;
}
