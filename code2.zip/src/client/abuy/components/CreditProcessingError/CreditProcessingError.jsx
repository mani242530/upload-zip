import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './CreditProcessingError.css';
import Exclamation from 'shared/components/Icons/exclamationcircle';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './CreditProcessingError.messages';
import Anchor from 'shared/components/Anchor/Anchor';
import Button from 'shared/components/Button/Button';
import Image from 'shared/components/Image/Image';
import Divider from 'shared/components/Divider/Divider';
import has from 'lodash/has';
import isUndefined from 'lodash/isUndefined';
import { connect } from 'react-redux';


const MOBILE_BANNERIMAGE_URL = 'https://images.ulta.com/is/image/Ulta/wk1117_m_banner_ccard_response_processingerror';

import Adsverification from 'abuy/components/Adsverification/Adsverification';

const propTypes = {
  guestServiceNumber: PropTypes.string,
  helpPhoneNumber:PropTypes.string
};

const mapStateToProps = ( state ) => {
  return {
    ...state.global
  };
}
const defaultProps = {
  bannerImageUri: 'https://images.ulta.com/is/image/Ulta/wk1117_d_banner_ccard_response_processingerror'
}

/** s
 * Class representing a ULTA ADA compliant CreditProcessingError element
 * @extends React.Component
 */
class CreditProcessingError extends Component{

  /**
   * Renders the CreditProcessingError component
   */
  render(){



    const {
      bannerImageUri
    }=this.props;

    let numberUrl = `tel:+${this.props.guestServiceNumber}`;
    let comenityBankNumberUrl = `tel:+${this.props.helpPhoneNumber}`;
    let lpsResponse = ( has( this.props, 'location.state.lpsResponse' ) && !isUndefined( this.props.location.state.lpsResponse ) )? this.props.location.state.lpsResponse : { rewardsMemberCreated:false };

    const {
      rewardsMemberCreated
    } = lpsResponse;

    return (
      <Adsverification { ...this.props }>
        <div className='CreditProcessingError'>
          <div className='CreditProcessingError__divider'>
            <Divider dividerType='gray' />
          </div>
          <div className='CreditProcessingError__container'>
            <div className='CreditProcessingError__column1'>
              <div className='CreditProcessingError__banner'>
                <Image
                  src={ this.props.isMobileDevice ? MOBILE_BANNERIMAGE_URL : bannerImageUri }
                  alt='BannerImage'
                />
              </div>
            </div>

            <div className='CreditProcessingError__column2'>
              <div className='CreditProcessingError_wentWrong'>
                { formatMessage( messages.wentWrong ) }
                <div className='CreditProcessingError_wentWrongMessage'>
                  { formatMessage( messages.wentWrongMessage ) }
                </div>
              </div>
              <Divider dividerType='orangeHorizontal'/>
              <div className='CreditProcessingError_messageContainer'>
                <span className='CreditProcessingError_errorOccured'>{ formatMessage( messages.errorOccured ) }</span>
                <Anchor
                  clickHandler={

                    ( e ) => {
                      this.props.goBack();
                      if( !isUndefined( this.props.location.state.isPreapprovedForm ) && !this.props.location.state.isPreapprovedForm ){
                        if( this.props.isSignedIn === true ){
                          this.props.history.push( '/c/application', {
                            instantCreditResponse: this.props.location.state.instantCreditResponse
                          } )
                        }
                        else {
                          this.props.history.push( '/apply', {
                            instantCreditResponse: this.props.location.state.instantCreditResponse
                          } )
                        }
                      }
                      else {
                        const historyData = this.props.location.state.preapprovedUserData;
                        let preapprovedUserData = {
                          firstName: historyData.firstName,
                          lastName: historyData.lastName,
                          email: historyData.email,
                          address1: historyData.address1,
                          address2: historyData.address2,
                          city: historyData.city,
                          state: historyData.state,
                          postalCode: historyData.postalCode,
                          phoneNumber: historyData.phoneNumber
                        }
                        this.props.history.push( '/c/preapproved', {
                          lpsData: preapprovedUserData
                        } )
                      }
                    }
                  }
                  className='CreditProcessingError_goingBack'
                >{ formatMessage( messages.goingBack ) }
                </Anchor>
                <span className='CreditProcessingError_tryAgain'>{ formatMessage( messages.tryAgain ) }</span>
                <div className='CreditProcessingError__column3'>
                  <span className='CreditProcessingError_services'>{ formatMessage( messages.services ) }</span>
                  <Anchor
                    className='MobileFooterTandC__help MobileFooterTandC__help__link MobileFooterTandC__help__number'
                    url={ comenityBankNumberUrl }
                  >
                    { this.props.helpPhoneNumber }
                  </Anchor>
                  <span className='CreditProcessingError_services'>{ formatMessage( messages.ultamateRewardsMemberIDMessageNumber ) }</span>
                </div>
              </div>

              { ( () => {
                if( rewardsMemberCreated === true ){
                  return (
                    <div className='CreditApprovalResponse__ultamateRewardsMemberIDMessageBlock'>
                      <div className='CreditApprovalResponse__ultamateRewardsMemberIDMessageBlock__Icon'>
                        <Exclamation />
                      </div>
                      <div className='CreditApprovalResponse__ultamateRewardsMember'>
                        <p className='CreditApprovalResponse__ultamateRewardsMemberIDMessage'>
                          { formatMessage( messages.ultamateRewardsMemberIDMessageOne ) }
                          <Anchor
                            className='MobileFooterTandC__help MobileFooterTandC__help__link MobileFooterTandC__help__number'
                            url={ numberUrl }
                          >
                            { this.props.guestServiceNumber }
                          </Anchor>
                          { formatMessage( messages.ultamateRewardsMemberIDMessageNumber ) }
                        </p>
                      </div>
                    </div>
                  )
                }
              } )() }

              { ( () => {
                if( this.props.shoppingCartCount === '0' ){
                  return (
                    <div className='CreditProcessingError__shopping__btn'>
                      <Button
                        inputTag='a'
                        btnSize='lg'
                        btnOption='single'
                        btnURL='/'
                      >
                        { formatMessage( messages.continueShopping ) }
                      </Button>
                    </div>
                  )
                }
                else {
                  return (
                    <div className='CreditProcessingError__shopping__btn'>
                      <div className='CreditProcessingError__shopping__btn'>
                        <Button
                          inputTag='a'
                          btnSize='lg'
                          btnOption='single'
                          btnURL='/bag'
                        >
                          { formatMessage( messages.continueCheckOut ) }
                        </Button>
                      </div>
                      <div className='CreditProcessingError__shopping__btn__Return'>
                        <Button
                          inputTag='a'
                          btnSize='lg'
                          btnOption='single'
                          btnOutLine={ true }
                          btnURL='/'
                        >
                          { formatMessage( messages.returnShopping ) }
                        </Button>
                      </div>
                    </div>
                  )
                }
              } )() }

            </div>
          </div>
        </div>
      </Adsverification>
    );
  }
}

CreditProcessingError.propTypes = propTypes;
CreditProcessingError.defaultProps = defaultProps;


const intlCreditProcessingError = CreditProcessingError;
export default connect( mapStateToProps )( intlCreditProcessingError );
