/**
 * Created by satchuyutuni on 5/12/17.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  wentWrong: {
    id: 'i18n.CreditProcessingError.wentWrong',
    defaultMessage: 'HMM, SOMETHING '
  },
  wentWrongMessage: {
    id: 'i18n.CreditProcessingError.wentWrongMessage',
    defaultMessage: 'WENT WRONG...'
  },
  errorOccured:{
    id: 'i18n.CreditProcessingError.error',
    defaultMessage: 'An error has occurred.You may '
  },
  goingBack:{
    id: 'i18n.CreditProcessingError.goBack',
    defaultMessage: 'go back '
  },
  tryAgain:{
    id: 'i18n.CreditProcessingError.tryAgain',
    defaultMessage: 'and try again.'
  },

  services:{
    id: 'i18n.CreditProcessingError.services',
    defaultMessage: 'If you continue to receive this message, please call'
  },
  thankYou:{
    id: 'i18n.CreditProcessingError.thankYou',
    defaultMessage: 'Thank You'
  },
  ultamateRewardsMemberIDMessageOne:{
    id: 'i18n.CreditProcessingError.ultamateRewardsMemberIDMessage',
    defaultMessage: 'A new Ultamate Rewards Member ID has been created and tied to your Ulta.com account. If you are an existing Ultamate Rewards member and wish to tie your existing Member ID to your Ulta.com account, please call '
  },
  ultamateRewardsMemberIDMessageNumber:{
    id: 'i18n.CreditProcessingError.ultamateRewardsMemberIDMessage',
    defaultMessage: ' for assistance.'
  },

  continueShopping: {
    id: 'i18n.CreditProcessingError.continueShopping',
    defaultMessage: 'Continue Shopping'
  },
  continueCheckOut: {
    id: 'i18n.CreditProcessingError.continueCheckOut',
    defaultMessage: 'Continue To Checkout'
  },
  returnShopping: {
    id: 'i18n.CreditProcessingError.returnShopping',
    defaultMessage: 'Return To Shopping'
  }

} );
