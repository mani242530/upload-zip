/**
 * Created by satchuyutuni on 5/12/17.
 */
import React from 'react';
import ReactDOM from 'react-dom';
import CreditProcessingError from './CreditProcessingError';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { IntlProvider } from 'react-intl';
import messages from './CreditProcessingError.messages';
import Button from 'shared/components/Button/Button';
import Anchor from 'shared/components/Anchor/Anchor';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';

const intlProvider = new IntlProvider( { locale: 'en' }, {} );
const { intl } = intlProvider.getChildContext();
window.requestAnimationFrame = jest.fn();
describe( '<CreditProcessingError/>', () => {

  let props = {
    intl,
    history:{
      push:jest.fn(),
      replace:jest.fn()
    },
    shoppingCartCount:'0',
    goBack:jest.fn(),
    location:{
      state:{
        lpsResponse:{
          rewardsMemberCreated:true
        },
        preapprovedUserData:{
          firstName:'test'
        },
        instantCreditResponse:{
          lpsData:{

          }
        }
      }
    }
  }
  const store = configureStore( {}, CONFIG );
  let component = mountWithIntl(
    <Provider store={ store }>
      <CreditProcessingError
        { ...props }
      />
    </Provider>
  );
  it( 'renders without crashing', () =>{
    expect( component.find( '.CreditProcessingError' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditProcessingError_welcomeTitle', () =>{
    expect( component.find( '.CreditProcessingError_wentWrong' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditProcessingError_messageContainer', () =>{
    expect( component.find( '.CreditProcessingError_messageContainer' ).length ).toBe( 1 );
  } );
  it( 'should have continue go Back link', () =>{
    expect( component.find( '.CreditProcessingError_goingBack a' ).length ).toBe( 1 );
  } );
  it( 'should have continue shopping link', () =>{
    expect( component.find( Button ).length ).toBe( 1 );
    expect( component.find( Button ).props().btnURL ).toBe( '/' );
  } );
  it( 'should invoke goBack on click CreditProcessingError_goingBack link', () =>{
    let node = component.find( 'CreditProcessingError' ).instance();
    expect( component.find( Anchor ).length ).toBe( 3 );
    component.find( Anchor ).at( 0 ).simulate( 'click' );
    expect( props.goBack ).toBeCalled();
  } );

  it( 'should invoke history.push on click CreditProcessingError_goingBack link for a signed in user', () =>{
    let props1 = {
      intl,
      isSignedIn:true,
      history:{
        push:jest.fn(),
        replace:jest.fn()
      },
      shoppingCartCount:'0',
      goBack:jest.fn(),
      location:{
        state:{
          lpsResponse:{
            rewardsMemberCreated:true
          },
          isPreapprovedForm:false

        }
      }
    }
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <CreditProcessingError
          { ...props1 }
        />
      </Provider>
    );
    // let node = component1.find( 'CreditProcessingError' ).instance();
    component1.find( Anchor ).at( 0 ).simulate( 'click' );
    expect( props.history.push ).toBeCalled
  } );

} );
