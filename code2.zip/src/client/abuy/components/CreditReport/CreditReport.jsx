import React from 'react';
import './CreditReport.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './CreditReport.messages';
import Anchor from 'shared/components/Anchor/Anchor';
import Divider from 'shared/components/Divider/Divider';
import Button from 'shared/components/Button/Button';
import ChevronLeftSVG from 'shared/components/Icons/chevronleft';
import has from 'lodash/has';
import validator from 'utils/Validator/validator';

import {
  Redirect
} from 'react-router-dom';

import Adsverification from 'abuy/components/Adsverification/Adsverification';


/**
 * Class representing a ULTA ADA compliant CreditReport element
 * @extends React.Component
 */
const CreditReport = ( props ) => {



  const date = new Date();

  var currentMonth=( '0'+( date.getMonth()+1 ) ).slice( -2 )

  var currentDate=( '0' + date.getDate() ).slice( -2 )

  const dateString = `${currentMonth}-${currentDate}-${date.getUTCFullYear()}`

  let instantCreditResponse = has( props, 'location.state.instantCreditResponse' ) ? props.location.state.instantCreditResponse : {};
  const { creditScore, bureauCode }= instantCreditResponse;
  let reasons = has( props, 'location.state.instantCreditResponse.aprReasons' ) ? props.location.state.instantCreditResponse.aprReasons : [];

  /**
   * Renders the CreditReport component
   */

  return (
    <Adsverification { ...props }>
      <div className='CreditReport'>
        <div>
          <div className='ReturnPageTop'>
            <div className='ReturnPage--chevronImgTop'>
              <Anchor className='ReturnPage--previousPageTop'
                clickHandler={
                  ( e ) => {
                    props.history.push( '/c/approved', {
                      ADSValidated: true,
                      instantCreditResponse: props.location.state.instantCreditResponse
                    } )
                  }
                }
              >
                <ChevronLeftSVG />{ formatMessage( messages.previousPage ) }
              </Anchor>
            </div>
          </div>
          <div className='CreditReport__container'>
            <div className='CreditReport__column'>
              <div>
                <div className='CreditReport__title'>
                  { formatMessage( messages.title1 ) }
                </div>
                <div className='CreditReport_query'>
                  { formatMessage( messages.section1_query1 ) }
                </div>
                <div className='CreditReport_info'>
                  <p>
                    { formatMessage( messages.section1_info1 ) }
                  </p>
                </div>
                <div className='CreditReport_query'>
                  { formatMessage( messages.section1_query2 ) }
                </div>
                <div className='CreditReport_info'>
                  <p>
                    { formatMessage( messages.section1_info2_1 ) }
                  </p>
                  <p>
                    { formatMessage( messages.section1_info2_2 ) }
                  </p>
                </div>
                <div className='CreditReport_query'>
                  { formatMessage( messages.section1_query3 ) }
                </div>
                <div className='CreditReport_info'>
                  <p>
                    { formatMessage( messages.section1_info3_1 ) }
                  </p>
                  <p>
                    { formatMessage( messages.section1_info3_2 ) }
                  </p>
                  <p>
                    { formatMessage( messages.section1_info3_3 ) }
                  </p>
                </div>
                <div className='CreditReport_query'>
                  { formatMessage( messages.section1_query4 ) }
                </div>

                { ( () => {
                  if( bureauCode === 'CBI' ){
                    return (
                      <div className='CreditReport_info'>
                        <p>
                          { formatMessage( messages.section1_info4_1 ) }
                        </p>
                        <div>
                          { formatMessage( messages.section1_info4_2 ) }
                        </div>
                        <div>
                          { formatMessage( messages.section1_info4_3 ) }
                        </div>
                        <div>
                          { formatMessage( messages.section1_info4_4 ) }
                        </div>
                        <div>
                          { formatMessage( messages.section1_info4_5 ) }
                        </div>
                      </div>
                    )
                  }
                  else {
                    return (
                      <div className='CreditReport_info'>
                        <p>
                          { formatMessage( messages.section1_info4_1 ) }
                        </p>
                        <div>
                          { formatMessage( messages.section1_info4_6 ) }
                        </div>
                        <div>
                          { formatMessage( messages.section1_info4_7 ) }
                        </div>
                        <div>
                          { formatMessage( messages.section1_info4_8 ) }
                        </div>
                        <div>
                          { formatMessage( messages.section1_info4_9 ) }
                        </div>
                      </div>
                    )
                  }
                } )() }

                <div className='CreditReport_query'>
                  { formatMessage( messages.section1_query5 ) }
                </div>
                <div className='CreditReport_info'>
                  <span>
                    { formatMessage( messages.section1_info5_1 ) }
                  </span>
                </div>
                <Anchor className='CreditReport__anchor' url='https://www.consumerfinance.gov/learnmore/'>
                  <div className='CreditReport_info'>
                    { formatMessage( messages.section1_info5_2 ) }
                  </div>
                </Anchor>
              </div>
              <div className='CreditReport_divider'>
                <Divider dividerType='gray'/>
              </div>
            </div>

            <div className='CreditReport__column'>
              <div className='CreditReport__title'>
                { formatMessage( messages.title2 ) }
              </div>
              <div className='CreditReport_query'>
                { formatMessage( messages.section2_query1 ) }
              </div>
              <div className='CreditReport_info'>
                <p>
                  { formatMessage( messages.section2_info1_1 ) }
                </p>
                <div className='CreditReport_query'>
                  <p>
                    { formatMessage( messages.section2_info1_2, { creditScore, dateString } ) }
                  </p>
                </div>
                <p>
                  { formatMessage( messages.section2_info1_3 ) }
                </p>
                <p>
                  { formatMessage( messages.section2_info1_4 ) }
                </p>
                { reasons.map( ( reason, index ) => {
                  return (
                    <div
                      key={ index }
                      className='CreditReport__bullets'
                    >
                      { reason }
                    </div>
                  )
                } ) }
                <p>{ formatMessage( messages.section2_info1_10 ) }</p>
              </div>
            </div>
          </div>

        </div>
        <div className='CreditReport__row'>
          <div className='CreditReport__shopping__btn CreditReport__row__shoppingButton'>
            <Button
              inputTag='a'
              btnSize='lg'
              btnOption='single'
              btnURL='/'
            >
              { formatMessage( messages.continueShopping ) }
            </Button>
          </div>



          <div className='ReturnPage CreditReport__row__returnPage'>
            <div className='ReturnPage--chevronImg'>
              <Anchor className='ReturnPage--previousPage'
                clickHandler={
                  ( e ) => {
                    props.history.push( '/c/approved', {
                      ADSValidated: true,
                      instantCreditResponse: props.location.state.instantCreditResponse
                    } )
                  }
                }
              >
                <ChevronLeftSVG />
                { formatMessage( messages.previousPage ) }
              </Anchor>
            </div>
          </div>


        </div>
      </div>
    </Adsverification>
  );
}

export default CreditReport;
