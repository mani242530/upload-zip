/**
 * Created by satchuyutuni on 5/12/17.
 */

/*
 * CreditReport Messages
 *
 * This contains all the text for the CreditReport component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {

  title1: {
    id: 'i18n.CreditReport.title1',
    defaultMessage: 'Your credit report and the Price You Pay for Credit '
  },
  previousPage: {
    id: 'i18n.CreditReport.previousPage',
    defaultMessage: 'RETURN TO PREVIOUS PAGE'
  },
  continueShopping: {
    id: 'i18n.CreditReport.continueShopping',
    defaultMessage: 'Continue Shopping'
  },
  section1_query1: {
    id: 'i18n.CreditReport.section1_query1',
    defaultMessage: 'What is a credit report?'
  },
  section1_info1:{
    id: 'i18n.CreditReport.section1_info1',
    defaultMessage: 'A credit report is a record of your credit history. It includes information about whether you pay your bills on time and how much you owe to creditors'
  },
  section1_query2:{
    id: 'i18n.CreditReport.section1_query2',
    defaultMessage: 'How did we use your credit report?'
  },
  section1_info2_1:{
    id: 'i18n.CreditReport.section1_info2_1',
    defaultMessage: 'We used information from your credit report to set the terms of the credit we are offering you, such as the Annual Percentage Rate.'
  },
  section1_info2_2:{
    id: 'i18n.CreditReport.section1_info2_2',
    defaultMessage: 'The terms offered to you may be less favorable than the terms offered to consumers who have better credit histories.'
  },
  section1_query3:{
    id: 'i18n.CreditReport.section1_query3',
    defaultMessage: 'What if there are mistakes in your credit report?'
  },
  section1_info3_1:{
    id: 'i18n.CreditReport.section1_info3_1',
    defaultMessage: 'You have the right to dispute any inaccurate information in your credit report.'
  },
  section1_info3_2:{
    id: 'i18n.CreditReport.section1_info3_2',
    defaultMessage: 'If you find mistakes on your credit report, contact the consumer reporting agency listed below, which is the consumer reporting agency from which we obtained your credit report.'
  },
  section1_info3_3:{
    id: 'i18n.CreditReport.section1_info3_3',
    defaultMessage: 'It is a good idea to check your credit report to make sure the information it contains is accurate.'
  },
  section1_query4:{
    id: 'i18n.CreditReport.section1_query4',
    defaultMessage: 'How can you obtain a copy of your credit report?'
  },
  section1_info4_1:{
    id: 'i18n.CreditReport.section1_info4_1',
    defaultMessage: 'Under Federal law, you have the right to obtain a copy of your credit report without charge for 60 days after you receive this notice. To obtain your free report,contact:'
  },
  section1_info4_2:{
    id: 'i18n.CreditReport.section1_info4_2',
    defaultMessage: 'EQUIFAX  '
  },
  section1_info4_3:{
    id: 'i18n.CreditReport.section1_info4_3',
    defaultMessage: 'PO Box 740241 '
  },
  section1_info4_4:{
    id: 'i18n.CreditReport.section1_info4_4',
    defaultMessage: 'ATLANTA, GA 30374'
  },
  section1_info4_5:{
    id: 'i18n.CreditReport.section1_info4_5',
    defaultMessage: ' (800) 685-111'
  },
  section1_info4_6:{
    id: 'i18n.CreditReport.section1_info4_2',
    defaultMessage: 'EXPERIAN  '
  },
  section1_info4_7:{
    id: 'i18n.CreditReport.section1_info4_3',
    defaultMessage: 'PO Box 2002 '
  },
  section1_info4_8:{
    id: 'i18n.CreditReport.section1_info4_4',
    defaultMessage: 'ALLEN, TX 75013'
  },
  section1_info4_9:{
    id: 'i18n.CreditReport.section1_info4_5',
    defaultMessage: ' (888) 397-3742'
  },

  section1_query5:{
    id: 'i18n.CreditReport.section1_query5',
    defaultMessage: 'How can you get more information about credit reports?'
  },
  section1_info5_1:{
    id: 'i18n.CreditReport.section1_info5_1',
    defaultMessage: 'For more information about credit reports and your rights under federal law, visit the Consumer Financial Protection Bureau\'s website at  '
  },
  section1_info5_2:{
    id: 'i18n.CreditReport.section1_info5_2',
    defaultMessage: 'www.consumerfinance.gov/learnmore'
  },
  title2: {
    id: 'i18n.CreditReport.title2',
    defaultMessage: 'Your Credit Score and Understanding Your Credit Score'
  },
  section2_query1:{
    id: 'i18n.CreditReport.section2_query1',
    defaultMessage: 'What you should know about credit scores.'
  },
  section2_info1_1:{
    id: 'i18n.CreditReport.section2_info1_1',
    defaultMessage: 'Your credit score is a number that reflects the information in your credit report. Your credit score can change, depending on how your credit history changes .'
  },
  section2_info1_2:{
    id: 'i18n.CreditReport.section2_info1_2',
    defaultMessage: 'Your credit score as of {dateString}: {creditScore}'
  },
  section2_info1_3:{
    id: 'i18n.CreditReport.section2_info1_3',
    defaultMessage: 'We used your credit score to set terms of credit we are offering you. In the scoring system we used, scores can range from 479 to the possible, 898. Please be aware, there are a number of different credit scoring systems available, and each uses a different range of numbers.'
  },
  section2_info1_4:{
    id: 'i18n.CreditReport.section2_info1_4',
    defaultMessage: 'Here are the highest key factors that adversely affected the score: '
  },
  section2_info1_10:{
    id: 'i18n.CreditReport.section2_info1_10',
    defaultMessage: 'If you have any questions about the factors impacting your credit score, we encourage you to contact the consumer reporting agency.'
  }

} );








