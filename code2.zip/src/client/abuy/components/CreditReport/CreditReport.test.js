import React from 'react';
import ReactDOM from 'react-dom';
import CreditReport from './CreditReport';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { IntlProvider } from 'react-intl';
import Divider from 'shared/components/Divider/Divider';
import Button from 'shared/components/Button/Button';
import messages from './CreditReport.messages';
import Adsverification from 'abuy/components/Adsverification/Adsverification';


const intlProvider = new IntlProvider( { locale: 'en' }, {} );
const { intl } = intlProvider.getChildContext();

describe( '<CreditReport />', () => {

  let props = {
    intl,
    history:{
      push:jest.fn()
    },
    location:{
      state:{
        instantCreditResponse: {
          aprReasons: ['CBI']
        }
      }
    }
  }
  Adsverification.prototype.componentDidMount = jest.fn();
  let component = mountWithIntl(
    <CreditReport
      { ...props }
    />
  );

  it( 'renders without crashing', ()=>{
    expect( component.find( '.CreditReport' ).length ).toBe( 1 );
  } );

  it( 'should have two CreditReport__column', ()=>{
    expect( component.find( '.CreditReport__column' ).length ).toBe( 2 );
  } );

  it( 'should have one divider', ()=>{
    expect( component.find( Divider ).length ).toBe( 1 );
  } );

  it( 'should have title for sections', ()=>{
    const titlecompList = component.find( '.CreditReport__title' );
    titlecompList.forEach( ( title, index ) => {
      expect( title.text() ).toBe( messages[`title${index+1}`].defaultMessage );
    } )

  } );

  it( 'should have shopping link', ()=>{
    expect( component.find( Button ).length ).toBe( 1 );
    expect( component.find( Button ).props().btnURL ).toBe( '/' );
  } );

  it( 'should invoke history.push on click ReturnPage--previousPageTop link', () =>{
    component.find( '.ReturnPage--chevronImgTop' ).find( 'Anchor' ).at( 0 ).simulate( 'click' );
    expect( props.history.push ).toBeCalled();
  } );

  it( 'should invoke history.push on click ReturnPage--previousPage link', () =>{
    component.find( '.ReturnPage .CreditReport__row__returnPage' ).find( '.ReturnPage--chevronImg' ).find( 'Anchor' ).at( 0 ).simulate( 'click' );
    expect( props.history.push ).toBeCalled();
  } );

  it( 'should have CreditReport_info if bureauCode is CBI', () =>{
    let props = {
      intl,
      history:{
        push:jest.fn()
      },
      location:{
        state:{
          instantCreditResponse: {
            bureauCode: 'CBI'
          }
        }
      }
    }
    let component1 = mountWithIntl(
      <CreditReport
        { ...props }
      />
    );
    expect( component.find( '.CreditReport_info' ).at( 3 ).length ).toBe( 1 );
  } );

} );
