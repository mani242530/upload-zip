/**
 * CreditcardPrescreenEntryForm
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './CreditcardPrescreenEntryForm.css';
import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './CreditcardPrescreenEntryForm.messages';
import TwoColumn from 'shared/components/TwoColumn/TwoColumn';
import Button from 'shared/components/Button/Button';
import InputField from 'shared/components/InputField/InputField';
import Divider from 'shared/components/Divider/Divider';
import CancelAndReturn from 'shared/components/CancelAndReturn/CancelAndReturn';
import {
  validationKeys,
  validate
} from 'utils/FormValidations/FormValidations';
import FormValidationMessages from 'utils/FormValidations/FormValidations.messages';
import {
  getActionDefinition
} from 'shared/actions/Services/Services.actions';
import { has, omitBy, isNil } from 'lodash';
import {
  fullyQualifyLink,
  host
} from 'utils/Formatters/formatters';

import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';
const propTypes = {
  successPath: PropTypes.string.isRequired
}
/**
 * Class
 * @extends React.Component
 */
class CreditcardPrescreenEntryForm extends Component{

  /**
   * Create a CreditcardPrescreenEntryForm
   */
  constructor( props ){
    super( props );
    this.submitPreScreenId = this.submitPreScreenId.bind( this );
  }

  submitPreScreenId( preScreenId ){
    if( preScreenId ){
      const data = {
        values: { preScreenId },
        paths: {
          successPath: this.props.successPath,
          failurePath: !this.props.user.isSignedIn? '/apply' : '/c/application'
        },
        history: this.props.history,
        flow: 'email'
      }
      this.props.submitPrescreenEntryForm( data );
    }
  }

  componentDidMount(){
    this.props.getBannerImage();
    const params = this.props.location.search;
    const index = params.indexOf( 'id=' );
    // this is to get the 12 digit ID which starts right after 'id='
    const preScreenId = params.substring( index+3, index+15 );
    if( has( this.props.user, 'rewardsInfo.isCardHolder' ) ){
      if( this.props.user.rewardsInfo.isCardHolder ){
        global.location.href = fullyQualifyLink( host, '/ulta/myaccount/index.jsp?member=true' );
      }
      else {
        this.submitPreScreenId( preScreenId );
      }
    }
    else {
      this.submitPreScreenId( preScreenId );
    }
  }

  submit = values => {
    const data = {
      values: values,
      paths: {
        successPath: this.props.successPath,
        failurePath: !this.props.user.isSignedIn? '/apply' : '/c/application'
      },
      history: this.props.history,
      flow: 'letter'
    }
    this.props.submitPrescreenEntryForm( data );
  }

  /**
   * Renders the CreditcardPrescreenEntryForm component
   */
  render(){

    const prescreenIdWarning = ( val ) => {
      let returnVal = validate( val, validationKeys.showWarningMessage, messages.prescreenIdHelpTxt );
      return returnVal;
    }

    const validationTrigger = ( val ) => {
      let requiredValidations = [validationKeys.required, validationKeys.validateADSprescreenID];
      let validationMsgs = [FormValidationMessages.prescreenIdHelpTxt, FormValidationMessages.invalidADSprescreenID];
      let returnVal = validate( val, requiredValidations, validationMsgs );
      return returnVal;
    }

    return (
      <div className='CreditcardPrescreenEntry'>
        <h3>
          { formatMessage( messages.greatNews ) }<br/>
          { formatMessage( messages.preApprovedMessage ) }<br/>
          Ultamate Rewards<sup>&reg;</sup>
          { formatMessage( messages.creditCard ) }
        </h3>
        <div className='HeaderDivider'>
          <Divider dividerType='orangeHorizontal'/>
        </div>
        <TwoColumn split='half|half'
          columnOne={ ( () => {
            return (
              <div className='CreditcardPrescreenEntryForm'>
                <h4> { formatMessage( messages.acceptPreapprovalMsg ) } </h4>
                <p> { formatMessage( messages.enterPrescreenIdMsg ) } </p>
                <form onSubmit={ this.props.handleSubmit( this.submit ) }>
                  <InputField
                    label={ formatMessage( messages.prescreenIdNumber ) }
                    type='tel'
                    name='preScreenId'
                    formatter={
                      {
                        pattern: '999999999999'
                      }
                    }
                    validate={ [validationTrigger] }
                    warn={ [prescreenIdWarning] }
                    tabIndex={ 1 }
                  />
                  <Button
                    id='acceptApply'
                    inputTag='button'
                    btnType='submit'
                    btnSize='lg'
                    btnOption='single'
                    tabIndex={ 2 }
                  >
                    <span className='PrescreenField__ApplySubmit--msg'>
                      { formatMessage( messages.acceptApplyNowBtn ) }
                    </span>
                  </Button>
                </form>
              </div>
            );
          } )() }
          columnTwo={ ( () => {
            return (
              <div className='CreditcardPrescreenApply'>
                <h4> { formatMessage( messages.noPreapprovalOfferMsg1 ) } </h4>
                <h4> { formatMessage( messages.noPreapprovalOfferMsg2 ) } </h4>
                <p> { formatMessage( messages.applyWithoutMsg ) } </p>
                <Button
                  id='applyNow'
                  inputTag='a'
                  btnURL='/creditcards/apply'
                  btnSize='lg'
                  btnOption='single'
                  btnOutLine={ true }
                  tabIndex={ 3 }
                >
                  <span className='ApplyNow__Submit--msg'>
                    { formatMessage( messages.applyNowBtn ) }
                  </span>
                </Button>
                <CancelAndReturn
                  cancelSteps={ -2 }
                  history={ history }
                  cancelText={ formatMessage( messages.cancel ) }
                />
              </div>
            );
          } )() }
        />
      </div>
    );
  }
}


export const onSubmitSuccess = ( result, dispatch, props ) => {
  // go to the application form if there are no errors
}

export const onSubmitFail = ( errors, dispatch ) => {
  let analyticErrors = [];
  analyticErrors.push( { 'PrescreenEntryFormErrors':  omitBy( errors, isNil ) } );

  let evt = {
    'name': 'trackErrorDisplayed',
    'data': analyticErrors
  }
  dispatch( analyticActions.triggerAnalyticsEvent( evt ) );
}

export const mapStateToProps = state => {
  return {

  }
}

export const mapDispatchToProps = dispatch => {
  return {
    submitPrescreenEntryForm: data => {
      dispatch( getActionDefinition( 'lpsLookupByPrescreenId', 'requested' )( data ) );
    }
  }
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return reduxForm( {
    form: 'CreditcardPrescreenEntry',
    onSubmitSuccess,
    onSubmitFail
  } )( connect( mapStateToProps, mapDispatchToProps )( CreditcardPrescreenEntryForm ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );

CreditcardPrescreenEntryForm.propTypes = propTypes;
