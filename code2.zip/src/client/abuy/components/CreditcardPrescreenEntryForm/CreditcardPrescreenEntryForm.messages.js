/*
 * CreditcardPrescreenEntryForm Messages
 *
 * This contains all the text for the CreditcardPrescreenEntryForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.CreditcardPrescreenEntryForm.header',
    defaultMessage: 'This is the CreditcardPrescreenEntryForm component!'
  },
  greatNews: {
    id: 'i18n.CreditcardPrescreenEntryForm.greatNews',
    defaultMessage: 'Great News!'
  },
  preApprovedMessage: {
    id: 'i18n.CreditcardPrescreenEntryForm.preApprovedMessage',
    defaultMessage: 'You\'re pre-approved for the '
  },
  creditCard: {
    id: 'i18n.CreditcardPrescreenEntryForm.creditCard',
    defaultMessage: ' credit card.'
  },
  acceptPreapprovalMsg: {
    id: 'i18n.CreditcardPrescreenEntryForm.acceptPreapprovalMsg',
    defaultMessage: 'Accept Your Pre-Approval Offer'
  },
  enterPrescreenIdMsg: {
    id: 'i18n.CreditcardPrescreenEntryForm.enterPrescreenIdMsg',
    defaultMessage: 'Please enter your 12-digit Prescreen ID Number to accept this offer and apply now.'
  },
  prescreenIdNumber: {
    id: 'i18n.CreditcardPrescreenEntryForm.prescreenIdNumber',
    defaultMessage: 'Prescreen ID Number'
  },
  prescreenIdHelpTxt: {
    id: 'i18n.CreditcardPrescreenEntryForm.prescreenIdHelpTxt',
    defaultMessage: 'Please enter your 12-digit Prescreen ID Number.'
  },
  noPreapprovalOfferMsg1: {
    id: 'i18n.CreditcardPrescreenEntryForm.noPreapprovalOfferMsg1',
    defaultMessage: 'No Pre-Approval Offer?'
  },
  noPreapprovalOfferMsg2: {
    id: 'i18n.CreditcardPrescreenEntryForm.noPreapprovalOfferMsg2',
    defaultMessage: 'No worries!'
  },
  acceptApplyNowBtn: {
    id: 'i18n.CreditcardPrescreenEntryForm.acceptApplyNowBtn',
    defaultMessage: 'Accept & Apply Now'
  },
  applyWithoutMsg: {
    id: 'i18n.CreditcardPrescreenEntryForm.applyWithoutMsg',
    defaultMessage: 'You\'re welcome to apply without being pre-approved. Select \'Apply Now\' to proceed'
  },
  applyNowBtn: {
    id: 'i18n.CreditcardPrescreenEntryForm.applyNowBtn',
    defaultMessage: 'Apply Now'
  },
  cancel: {
    id: 'i18n.CreditcardPrescreenEntryForm.cancel',
    defaultMessage: 'CANCEL & RETURN'
  }
} );
