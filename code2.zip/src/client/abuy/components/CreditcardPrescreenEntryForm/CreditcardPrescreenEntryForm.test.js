import React from 'react';
import ReactDOM from 'react-dom';
import CreditcardPrescreenEntryForm, { mapDispatchToProps, connectFunction } from './CreditcardPrescreenEntryForm';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import has from 'lodash/has';
import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';

import {
  getActionDefinition,
  registerServiceName
} from 'shared/actions/Services/Services.actions';

describe( '<CreditcardPrescreenEntryForm />', () => {
  let component;
  let props = {
    location :{
      search :''
    },
    user:{
      isSignedIn:true
    },
    getBannerImage: jest.fn(),
    successPath: '/bag'
  }
  const store = configureStore( {}, CONFIG );

  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <CreditcardPrescreenEntryForm { ...props }/>
      </Provider>
    );
    expect( component.find( 'CreditcardPrescreenEntryForm' ).length ).toBe( 1 );
  } );

  it( 'has the props to make service call for the banner', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <CreditcardPrescreenEntryForm { ...props }/>
      </Provider>
    );
    expect( has( component.find( 'CreditcardPrescreenEntryForm' ).instance(), 'props.getBannerImage' ) ).toBe( true );
    let prop = component.find( 'CreditcardPrescreenEntryForm' ).at( 0 ).props();
    expect( prop.getBannerImage ).toBeCalled();
  } );

  it( 'makes service call for the banner', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <CreditcardPrescreenEntryForm { ...props }/>
      </Provider>
    );
    let prop = component.find( 'CreditcardPrescreenEntryForm' ).at( 0 ).props();
    expect( prop.getBannerImage ).toBeCalled();
  } );

  it( 'should trigger analytics event when onSubmitFail is invoked', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <CreditcardPrescreenEntryForm { ...props }/>
      </Provider>
    );
    const dispatch=jest.fn();
    component.find( 'CreditcardPrescreenEntryForm' ).props().onSubmitFail( {}, dispatch );
    let evt = {
      'name': 'trackErrorDisplayed',
      'data': [{ 'PrescreenEntryFormErrors': {} }]
    }
    expect( dispatch ).toBeCalledWith( analyticActions.triggerAnalyticsEvent( evt ) );
  } );

  it( 'should have CreditcardPrescreenEntryForm invoking submitPreScreenId and submit methods', () => {
    let props = {
      location :{
        search :''
      },
      user:{
        isSignedIn:true,
        rewardsInfo:{
          isCardHolder: false
        }
      },
      getBannerImage: jest.fn(),
      successPath: '/bag'
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <CreditcardPrescreenEntryForm { ...props }/>
      </Provider>
    );
    const dispatch=jest.fn();
    component.find( 'CreditcardPrescreenEntryForm' ).props().onSubmitFail( {}, dispatch );

    const instance = component.find( 'CreditcardPrescreenEntryForm' ).instance();
    const mdp  = mapDispatchToProps( dispatch );
    const data = jest.fn();
    registerServiceName( 'lpsLookupByPrescreenId' );
    mdp.submitPrescreenEntryForm( data );
    instance.submitPreScreenId( '43567' );
    instance.submit( 'letter' );
    expect( component.find( '.CreditcardPrescreenEntryForm' ).length ).toBe( 1 );
  } );
} );

describe( '<CreditcardPrescreenEntryForm /> - MapDispatchToProps', () => {
  const store = configureStore( {}, CONFIG );
  const props = {
    location :{
      search :''
    },
    user:{
      isSignedIn:true
    },
    getBannerImage: jest.fn(),
    successPath: '/bag'
  }
  const component = mountWithIntl(
    <Provider store={ store }>
      <CreditcardPrescreenEntryForm { ...props } />
    </Provider>
  );
  const dispatch = jest.fn();
  beforeEach( ()=> {
    dispatch.mockClear();
  } )
  const mdp  = mapDispatchToProps( dispatch );

  it( 'applyPayment should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'lpsLookupByPrescreenId' );
    mdp.submitPrescreenEntryForm( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'lpsLookupByPrescreenId', 'requested' )( data )
    );
  } );
} );
