/**
 * EditPrepopulatedData
 */

import React, { Component } from 'react';
import './EditPrepopulatedData.css';
import InputField from 'shared/components/InputField/InputField';
import Anchor from 'shared/components/Anchor/Anchor';
import LpsLookUp from 'abuy/components/LpsLookUp/LpsLookUp';
import AddressForm from 'shared/components/AddressForm/AddressForm';
import messages from './EditPrepopulatedData.messages';
import InputWithDropDown from 'shared/components/InputWithDropDown/InputWithDropDown';
import {
  validationKeys,
  validate
} from 'utils/FormValidations/FormValidations';
import { formatMessage } from 'shared/components/Global/Global';
import has from 'lodash/has';
import PropTypes from 'prop-types';

const propTypes = {
  showEditMode: PropTypes.bool
};
const defaultProps = {
  showEditMode: false
}

/**
 * Class
 * @extends React.Component
 */
class EditPrepopulatedData extends Component{

  /**
   * Create a EditPrepopulatedData
   */
  constructor( props ){
    super( props );
    this.handlePrepopulatedDataForm = this.handlePrepopulatedDataForm.bind( this );
  }

  componentWillMount(){
    if( this.props.showEditMode ){
      this.handlePrepopulatedDataForm();
    }
  }

  componentDidMount(){
    this.props.toggleAddressFieldDisplay();
  }


  handlePrepopulatedDataForm(){
    this.props.toggleEditUserData();
  }

  /**
   * Renders the EditPrepopulatedData component
   */
  render(){
    const {
      userData,
      lpsFlag
    } = this.props;

    const options = [
      { value: 'M', label: formatMessage( messages.Mobile ) },
      { value: 'O', label: formatMessage( messages.Other ) },
      { value: 'H', label: formatMessage( messages.Home ) },
      { value: 'W', label: formatMessage( messages.Work ) }
    ]
    const phoneWarning = ( val ) => {
      return validate( val, validationKeys.showWarningMessage, messages.phoneWarning );
    }

    return (
      <div className='EditPrepopulatedData'>
        <div className='EditPrepopulatedData__ReviewDataTitle'>
          { formatMessage( messages.titleMessage ) }

        </div>
        { ( () => {
          if( this.props.editUserData === false && userData ){
            return (
              <div className='EditPrepopulatedData__ReviewData'>

                <div className='EditPrepopulatedData__ReviewErrorMessage'>
                  <div className='EditPrepopulatedData__ReviewErrorMessage__SomethingText'>
                    { formatMessage( messages.errorMessage ) }
                  </div>
                  <Anchor
                    url='#'
                    clickHandler={ this.handlePrepopulatedDataForm }
                    className='EditPrepopulatedData__ReviewErrorMessage__EditText'
                  >
                    { formatMessage( messages.editMessage ) }
                  </Anchor>

                </div>


                <div className='EditPrepopulatedData__UserDetails'>
                  <div className='EditPrepopulatedData__UserDetails__FullName'>
                    { userData.firstName } { userData.lastName }
                  </div>
                  <div className='EditPrepopulatedData__UserDetails__Address'>
                    { userData.address.address1 }, { userData.address.address2 }
                  </div>
                  <div className='EditPrepopulatedData__UserDetails__City'>
                    { userData.address.city }, { userData.address.state }
                  </div>
                  <div className='EditPrepopulatedData__UserDetails__Zipcode'>
                    { userData.address.postalCode }
                  </div>
                  <div className='EditPrepopulatedData__UserDetails__MobileNo'>
                    { userData.address.phoneNumber }
                  </div>
                  <div className='EditPrepopulatedData__UserDetails__emailID'>
                    { userData.email }
                  </div>
                </div>
              </div>
            )
          }


        } )() }

        { ( () => {

          if( this.props.editUserData === true ){
            return (
              <div className='EditPrepopulatedData__UserEditForm'>
                <div className='EditPrepopulatedData__ReviewChangeMessage'>
                  { formatMessage( messages.changeMessage ) }
                </div>
                <div className='EditPrepopulatedData__ReviewDataForm'>
                  <div className='EditPrepopulatedData__Column'>
                    <div className='EditPrepopulatedData__FirstName'>
                      <InputField
                        label={ formatMessage( messages.FirstName ) }
                        type='text'
                        name='firstName'
                        value={ userData.firstName }
                        autoCapitalize={ true }
                      />
                    </div>
                    <div className='EditPrepopulatedData__LastName'>
                      <InputField
                        value={ userData.lastName }
                        label={ formatMessage( messages.LastName ) }
                        type='text'
                        name='lastName'
                        autoCapitalize={ true }
                      />
                    </div>

                    <div className='EditPrepopulatedData__EmailId'>
                      <InputField
                        value={ userData.email }
                        label={ formatMessage( messages.emailOrUsername ) }
                        type='email'
                        name='login'
                      />
                    </div>
                    <InputWithDropDown
                      options={ options }
                      nameForDropdown={ 'phoneType' }
                      nameForInput={ 'phoneNumber' }
                      labelForInput={ formatMessage( messages.PhoneNumber ) }
                      warningForInputField={ [phoneWarning] }
                      formValue={ this.props.formData.values.phoneNumber }
                      inputFieldValue={ userData.address.phoneNumber }
                      { ...this.props }

                    />
                  </div>
                  <div className='EditPrepopulatedData__Column'>
                    <AddressForm
                      { ...this.props }
                      addressData={ userData.address }
                      addressFormTitle={ formatMessage( messages.HomeAddress ) }
                      toggleAddressFieldDisplay={ this.props.toggleAddressFieldDisplay }
                      toggleAddress2FieldDisplay={ this.props.toggleAddress2FieldDisplay }
                      addressOpen={ true }
                      { ...( has( userData, 'address.address2' ) && { address2Open: true } ) }
                    />
                  </div>
                </div>

              </div>
            )
          }

        } )() }

        <LpsLookUp
          { ...this.props }
          lpsFlag={ lpsFlag }
        />

      </div>

    );
  }
}
EditPrepopulatedData.defaultProps = defaultProps;
EditPrepopulatedData.propTypes = propTypes;
export default EditPrepopulatedData;