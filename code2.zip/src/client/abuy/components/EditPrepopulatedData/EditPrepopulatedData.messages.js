/*
 * EditPrepopulatedData Messages
 *
 * This contains all the text for the EditPrepopulatedData component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  emailOrUsername: {
    id: 'i18n.EditPrepopulatedData.emailOrUsername',
    defaultMessage: 'Email Address'
  },
  PhoneNumber: {
    id: 'i18n.EditPrepopulatedData.PhoneNumber',
    defaultMessage: 'Phone Number'
  },
  Mobile: {
    id: 'i18n.EditPrepopulatedData.Mobile',
    defaultMessage: 'Mobile'
  },
  Other: {
    id: 'i18n.EditPrepopulatedData.Other',
    defaultMessage: 'Office'
  },
  Home: {
    id: 'i18n.EditPrepopulatedData.Home',
    defaultMessage: 'Home'
  },
  Work: {
    id: 'i18n.EditPrepopulatedData.Work',
    defaultMessage: 'Work'
  },
  phoneWarning: {
    id: 'i18n.EditPrepopulatedData.phoneWarning',
    defaultMessage: 'By providing your contact information, including any cellular or other phone numbers, you agree to be contacted regarding any of your Comenity Bank or Comenity Capital Bank accounts via calls to cell phones, text messages, or telephone calls, including the use of artificial or pre-recorded message calls, and calls made via automatic telephone dialing systems, or via email.'
  },
  header: {
    id: 'i18n.EditPrepopulatedData.header',
    defaultMessage: 'This is the EditPrepopulatedData component !'
  },
  titleMessage: {
    id: 'i18n.EditPrepopulatedData.titleMessage',
    defaultMessage: 'Review your info'
  },
  errorMessage: {
    id: 'i18n.EditPrepopulatedData.errorMessage',
    defaultMessage: 'Something is not right?'
  },
  changeMessage: {
    id: 'i18n.EditPrepopulatedData.changeMessage',
    defaultMessage: 'Make any change below'
  },
  editMessage: {
    id: 'i18n.EditPrepopulatedData.editMessage',
    defaultMessage: 'Edit'
  },
  FirstName: {
    id: 'i18n.CreditCardApplyForm.FirstName',
    defaultMessage: 'First Name'
  },
  LastName: {
    id: 'i18n.CreditCardApplyForm.LastName',
    defaultMessage: 'Last Name'
  },

  HomeAddress: {
    id: 'i18n.EditPrepopulatedData.HomeAddress',
    defaultMessage: 'Home Address'
  },
  continueMessage: {
    id: 'i18n.EditPrepopulatedData.continueMessage',
    defaultMessage: 'CONTINUE APPLICATION'
  }

} );
