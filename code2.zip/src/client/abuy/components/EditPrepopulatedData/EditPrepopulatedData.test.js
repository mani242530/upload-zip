import React from 'react';
import ReactDOM from 'react-dom';
import EditPrepopulatedData from './EditPrepopulatedData';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './EditPrepopulatedData.messages';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { reduxForm } from 'redux-form';

const Decorator=reduxForm( { form:'testForm' } )( EditPrepopulatedData );
describe( '<EditPrepopulatedData />', () => {
  let component;
  const store = configureStore( {}, CONFIG );
  let props={
    user:{
      isRewardsMember: true,
      isSignedIn: true,
      profileInfo: {
        address:{
          address1:'123 N Main St',
          address2:'Apt 1A',
          city:'Chicago',
          country:'US',
          phoneNumber:'(312)-555-5555',
          postalCode:'60657',
          state:'IL'
        },
        beautyClubPlanType:{},
        dateOfBirth:'03/17',
        email:'ssmith@ulta.com',
        firstName:'Sasha',
        lastName:'Smith'
      }
    },
    editUserData:false,
    userData:{
      email:'ssmith@ulta.com',
      firstName:'Sasha',
      lastName:'Smith',
      address:{
        address1:'123 N Main St',
        address2:'Apt 1A',
        city:'Chicago',
        country:'US',
        phoneNumber:'(312)-555-5555',
        postalCode:'60657',
        state:'IL'
      } },
    formData:{ values:{ phoneNumber:'2343344' } },
    toggleAddressFieldDisplay: jest.fn(),
    toggleAddress2FieldDisplay: jest.fn()
  };

  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <EditPrepopulatedData { ...props }/>
      </Provider>
    );
    expect( component.find( 'EditPrepopulatedData' ).length ).toBe( 1 );
  } );
  it( 'it should show the title messgae', () => {
    expect( component.find( '.EditPrepopulatedData__ReviewDataTitle' ).at( 0 ).text() ).toBe( messages.titleMessage.defaultMessage );
  } );
  it( 'it should show the error Something text message', () => {
    expect( component.find( '.EditPrepopulatedData__ReviewErrorMessage__SomethingText' ).at( 0 ).text() ).toBe( messages.errorMessage.defaultMessage );
  } );
  it( 'it should show the error edit text message', () => {
    expect( component.find( '.EditPrepopulatedData__ReviewErrorMessage__EditText' ).at( 0 ).text() ).toBe( messages.editMessage.defaultMessage );
  } );
  it( 'it should show the fullName', () => {
    expect( component.find( '.EditPrepopulatedData__UserDetails__FullName' ).at( 0 ).text() ).toBe( 'Sasha Smith' );
  } );
  it( 'it should show the Address', () => {
    expect( component.find( '.EditPrepopulatedData__UserDetails__Address' ).at( 0 ).text() ).toBe( '123 N Main St, Apt 1A' );
  } );
  it( 'it should show the State', () => {
    expect( component.find( '.EditPrepopulatedData__UserDetails__City' ).at( 0 ).text() ).toBe( 'Chicago, IL' );
  } );
  it( 'it should show the Zipcode', () => {
    expect( component.find( '.EditPrepopulatedData__UserDetails__Zipcode' ).at( 0 ).text() ).toBe( '60657' );
  } );
  it( 'it should show the MobileNo', () => {
    expect( component.find( '.EditPrepopulatedData__UserDetails__MobileNo' ).at( 0 ).text() ).toBe( '(312)-555-5555' );
  } );
  it( 'it should show the emailID', () => {
    expect( component.find( '.EditPrepopulatedData__UserDetails__emailID' ).at( 0 ).text() ).toBe( 'ssmith@ulta.com' );
  } );
  it( 'it should show the Review Message', () => {
    props.editUserData = true;
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <Decorator { ...props }/>
      </Provider>
    );

    expect( component1.find( '.EditPrepopulatedData__ReviewChangeMessage' ).text() ).toBe( messages.changeMessage.defaultMessage );
  } );
  it( 'it should show the Data form', () => {
    props.editUserData = true;
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <Decorator { ...props }/>
      </Provider>
    );
    expect( component1.find( '.EditPrepopulatedData__ReviewDataForm' ).length ).toBe( 1 );
  } );


} );
