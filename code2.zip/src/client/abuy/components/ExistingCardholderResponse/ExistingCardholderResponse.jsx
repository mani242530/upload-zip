/**
 * ExistingCardholderResponse
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './ExistingCardholderResponse.css';
import Button from 'shared/components/Button/Button';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './ExistingCardholderResponse.messages';
import Image from 'shared/components/Image/Image';
import { connect } from 'react-redux';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';


import has from 'lodash/has';

import {
  Redirect
} from 'react-router-dom';

import Adsverification from 'abuy/components/Adsverification/Adsverification';

const propTypes = {
  guestServiceNumber: PropTypes.string
}

const registered ='<sup>&reg</sup>'

const mapStateToProps = ( state ) => {
  return {
    ...state.global
  };
}

/**
 * Class
 * @extends React.Component
 */
class ExistingCardholderResponse extends Component{


  /**
   * Renders the ExistingCardholderResponse component
   */
  render(){


    let numberUrl = `tel:+${this.props.guestServiceNumber}`;

    let instantCreditResponse = has( this.props, 'location.state.instantCreditResponse' ) ? this.props.location.state.instantCreditResponse : {};
    const { firstName, cardType } = instantCreditResponse;
    let bannerImageUri;
    if( this.props.isMobileDevice ){
      bannerImageUri = cardType === 'MC' ? 'https://images.ulta.com/is/image/Ulta/wk1117_m_banner_ccard_response_existingcardholder_blcc' : 'https://images.ulta.com/is/image/Ulta/wk1117_m_banner_ccard_response_existingcardholder_plcc'
    }
    else {
      bannerImageUri = cardType ==='MC'? 'https://images.ulta.com/is/image/Ulta/wk1117_d_banner_ccard_response_existingcardholder_blcc' : 'https://images.ulta.com/is/image/Ulta/wk1117_d_banner_ccard_response_existingcardholder_plcc'
    }

    let cardTypeText = cardType==='MC' ? formatMessage( messages.MasterCard ) : formatMessage( messages.CreditCard );
    return (
      <Adsverification { ...this.props }>
        <div className='ExistingCardholderResponse'>
          <div className='ExistingCardholderResponse__divider'>
            <Divider dividerType='gray' />
          </div>
          <div className='ExistingCardholderResponse__container'>
            <div className='ExistingCardholderResponse__column1'>
              <div className='ExistingCardholderResponse__banner'>
                <Image
                  src={ bannerImageUri }
                  alt='BannerImage'
                />
              </div>
            </div>
            <div className='ExistingCardholderResponse__column2'>
              <div className='ExistingCardholderResponse__welcomeBackMessage'>
                { formatMessage( messages.welcomeMessage ) }
                <div className='ExistingCardholderResponse_firstName'>
                  { firstName }
                </div>
                <Divider dividerType='orangeHorizontal'/>
              </div>
              <div className='ExistingCardholderResponse__responseMessage'>
                <span dangerouslySetInnerHTML={
                  { __html: formatMessage( messages.responseMessage, { registered, cardTypeText } ) }
                }
                />
              </div>
              <div className='ExistingCardholderResponse__supportMessage'>
                { formatMessage( messages.supportMessage ) }
                <Anchor
                  className='MobileFooterTandC__help MobileFooterTandC__help__link MobileFooterTandC__help__number'
                  url={ numberUrl }
                >
                  { this.props.guestServiceNumber }
                </Anchor>
                { formatMessage( messages.supportMessageTwo ) }
              </div>
              { ( () => {
                if( this.props.shoppingCartCount === '0' ){
                  return (
                    <div className='ExistingCardholderResponse__shopping__btn'>
                      <Button
                        inputTag='a'
                        btnSize='lg'
                        btnOption='single'
                        btnURL='/'
                      >
                        { formatMessage( messages.continueShopping ) }
                      </Button>
                    </div>
                  )
                }
                else {
                  return (
                    <div className='ExistingCardholderResponse__shopping__btn'>
                      <div className='ExistingCardholderResponse__shopping__btn'>
                        <Button
                          inputTag='a'
                          btnSize='lg'
                          btnOption='single'
                          btnURL='/bag'
                        >
                          { formatMessage( messages.continueCheckOut ) }
                        </Button>
                      </div>
                      <div className='ExistingCardholderResponse__shopping__btn__Return'>
                        <Button
                          inputTag='a'
                          btnSize='lg'
                          btnOption='single'
                          btnOutLine={ true }
                          btnURL='/'
                        >
                          { formatMessage( messages.returnShopping ) }
                        </Button>
                      </div>
                    </div>
                  )
                }
              } )() }
            </div>
          </div>
        </div>
      </Adsverification>
    );
  }
}

ExistingCardholderResponse.propTypes = propTypes;

const intlExistingCardholderResponse =  ExistingCardholderResponse;
export default connect( mapStateToProps )( intlExistingCardholderResponse );
