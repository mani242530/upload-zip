/*
 * ExistingCardholderResponse Messages
 *
 * This contains all the text for the ExistingCardholderResponse component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {

  welcomeMessage: {
    id: 'i18n.ExistingCardholderResponse.welcomeMessage',
    defaultMessage: 'WELCOME BACK,'
  },
  responseMessage:{
    id: 'i18n.ExistingCardholderResponse.responseMessage',
    defaultMessage: 'Our records indicate that you already have an Ultamate Rewards{registered} {cardTypeText}.'
  },
  supportMessage:{
    id: 'i18n.ExistingCardholderResponse.supportMessage',
    defaultMessage: 'Please call '
  },
  supportMessageTwo:{
    id: 'i18n.ExistingCardholderResponse.supportMessage',
    defaultMessage: ' if you need further assistance.'
  },
  continueShopping:{
    id: 'i18n.ExistingCardholderResponse.continueShopping',
    defaultMessage: 'CONTINUE SHOPPING'
  },
  MasterCard:{
    id: 'i18n.ExistingCardholderResponse.MasterCard',
    defaultMessage: 'Mastercard'
  },
  CreditCard:{
    id: 'i18n.ExistingCardholderResponse.CreditCard',
    defaultMessage: 'Credit Card'
  },
  continueCheckOut: {
    id: 'i18n.ExistingCardholderResponse.continueCheckOut',
    defaultMessage: 'Continue To Checkout'
  },
  returnShopping: {
    id: 'i18n.ExistingCardholderResponse.returnShopping',
    defaultMessage: 'Return To Shopping'
  }

} );
