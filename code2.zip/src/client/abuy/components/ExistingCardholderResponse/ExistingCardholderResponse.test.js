import React from 'react';
import ReactDOM from 'react-dom';
import ExistingCardholderResponse from './ExistingCardholderResponse';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './ExistingCardholderResponse.messages';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import { formatMessage } from 'shared/components/Global/Global';

describe( '<ExistingCardholderResponse />', () => {
  global.requestAnimationFrame = jest.fn();
  let component;
  const store = configureStore( {}, CONFIG );

  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <ExistingCardholderResponse
          history={ '/CreditCardApplyForm' }
        />
      </Provider>
    );
    expect( component.find( 'ExistingCardholderResponse' ).length ).toBe( 1 );
  } );
  it( 'should show the number of button', () => {
    let props = {
      shoppingCartCount : '0'
    };
    component = mountWithIntl( <Provider store={ store }>
      <ExistingCardholderResponse
        history={ '/CreditCardApplyForm' }
        { ...props }
      />
    </Provider>
    );
    expect( component.find( 'Button' ).length ).toBe( 1 );
  } );
  it( 'it should show the welcome message', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <ExistingCardholderResponse
          history={ '/CreditCardApplyForm' }
        />
      </Provider>
    );
    expect( component.find( '.ExistingCardholderResponse__welcomeBackMessage' ).at( 0 ).text() ).toBe( messages.welcomeMessage.defaultMessage.replace( '{firstName}', '' ) );
  } );
  it( 'it should show the response message', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <ExistingCardholderResponse
          history={ '/CreditCardApplyForm' }
        />
      </Provider>
    );
    const registered ='<sup>&reg</sup>';
    const cardTypeText = formatMessage( messages.CreditCard )
    const message =  formatMessage( messages.responseMessage, { registered, cardTypeText } );

    var temp = document.createElement( 'div' );
    temp.innerHTML = message;

    expect( component.find( '.ExistingCardholderResponse__responseMessage' ).at( 0 ).text() ).toBe( temp.textContent );
  } );
  it( 'it should show the support message', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <ExistingCardholderResponse
          history={ '/CreditCardApplyForm' }
        />
      </Provider>
    );
    expect( component.find( '.ExistingCardholderResponse__supportMessage' ).at( 0 ).text() ).toBe( messages.supportMessage.defaultMessage + messages.supportMessageTwo.defaultMessage );
  } );
  it( 'it should show the checkout message', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <ExistingCardholderResponse
          history={ '/CreditCardApplyForm' }
        />
      </Provider>
    );
    expect( component.find( '.ExistingCardholderResponse__shopping__btn' ).find( 'Button' ).at( 0 ).text() ).toBe( messages.continueCheckOut.defaultMessage );
  } );

} );
