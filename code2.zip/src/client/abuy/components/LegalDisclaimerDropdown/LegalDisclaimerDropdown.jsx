/**
 * LeagalDisclaimerDropdown
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './LegalDisclaimerDropdown.css';
import { formatMessage } from 'shared/components/Global/Global';
import Loader from 'shared/components/Loader/Loader';
import Image from 'shared/components/Image/Image';
import messages from './LegalDisclaimerDropdown.messages';
import classNames from 'classnames';
import ChevronRightSVG from 'shared/components/Icons/chevron_right';

const propTypes = {
  defaultHeight: PropTypes.string,
  open: PropTypes.bool,
  iframeSrc: PropTypes.string.isRequired,
  iframeTitle: PropTypes.string.isRequired,
  id: PropTypes.string.isRequired,
  isLoaded: PropTypes.func
};

const defaultProps = {
  defaultHeight: '200px',
  open: false
};


/**
 * Class
 * @extends React.Component
 */
class LegalDisclaimerDropdown extends Component{

  /**
   * Create a LegalDisclaimerDropdown
   */

  iframe = undefined;

  constructor( props ){
    super( props );

    this.state = {
      iframeHeight: props.defaultHeight,
      open: props.open,
      iframeLoaded: false
    };

    this.toggleIframeHeight = this.toggleIframeHeight.bind( this );

    this.setIframeDisplay = this.setIframeDisplay.bind( this );
  }

  componentDidMount(){
    this.ifr.onload = () => {
      this.setIframeDisplay();
    }
  }



  setIframeDisplay( ){
    this.setState( { iframeLoaded: true } );
    this.props.isLoaded();
  }

  toggleIframeHeight( iframeID ){
    let newOpen = !this.state.open;
    this.setState( { open: newOpen } );
    this.setState( { iframeHeight: newOpen ? '300px' : this.props.defaultHeight } )
  }

  /**
   * Renders the LegalDisclaimerDropdown component
   */

  render(){


    let frameHeight = this.state.iframeHeight;

    return (
      <div className='LegalDisclaimerDropdown'>
        <div
          className={
            classNames( 'LegalDisclaimerDropdown__messageTextMore',
              {
                'LegalDisclaimerDropdown__iframe': !this.state.open
              }
            )
          }
          id={ this.props.id }
          aria-hidden={ !this.state.open }
        >
          { ( () => {
            if( !this.state.iframeLoaded ){
              return (
                <div className='Loading__spinner'>
                  <Loader
                    loaderType='skeleton'
                  />
                </div>
              )
            }
          } )() }
          { ( () => {
            if( this.state.open ){
              return (
                <iframe
                  title={ this.props.iframeTitle }
                  scrolling='yes'
                  src={ this.props.iframeSrc }
                  style={
                    {
                      height: this.state.iframeHeight
                    }
                  }
                  ref={ ( ifr ) => this.ifr = ifr }
                />
              );
            }
            else {
              return (
                <div>
                  <iframe
                    title={ this.props.iframeTitle }
                    scrolling='no'
                    src={ this.props.iframeSrc }
                    style={
                      {
                        height: this.state.iframeHeight
                      }
                    }
                    ref={ ( ifr ) => this.ifr = ifr }
                  />
                </div>
              );
            }
          } )() }
        </div>
        <div
          className={
            classNames( 'LegalDisclaimerDropdown__Show',
              {
                'LegalDisclaimerDropdown__Show--more': this.state.open,
                'LegalDisclaimerDropdown__Show--less': !this.state.open
              }
            )
          }
          onClick={ this.toggleIframeHeight }
          role='button'
          tabIndex='0'
          aria-expanded={ this.state.open }
          aria-controls={ this.props.id }
        >
          { ( () => {
            return this.state.open ? formatMessage( messages.showLess ) : formatMessage( messages.showMore );
          } )() }
          <ChevronRightSVG />
        </div>
      </div>
    );

  }

}

LegalDisclaimerDropdown.propTypes = propTypes;
LegalDisclaimerDropdown.defaultProps = defaultProps;

export default LegalDisclaimerDropdown;
