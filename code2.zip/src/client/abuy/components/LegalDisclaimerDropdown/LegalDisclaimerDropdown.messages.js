/*
 * LeagalDisclaimerDropdown Messages
 *
 * This contains all the text for the LeagalDisclaimerDropdown component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.LegalDisclaimerDropdown.header',
    defaultMessage: 'This is the LegalDisclaimerDropdown component !'
  },
  showMore: {
    id: 'i18n.InputField.showMore',
    defaultMessage: 'SHOW MORE'
  },
  showLess:{
    id: 'i18n.InputField.showLess',
    defaultMessage: 'SHOW LESS'
  }

} );
