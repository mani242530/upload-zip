import React from 'react';
import ReactDOM from 'react-dom';
import LegalDisclaimerDropdown from './LegalDisclaimerDropdown';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './LegalDisclaimerDropdown.messages';

describe( '<LegalDisclaimerDropdown />', () => {
  let component;
  let props = {
    defaultHeight: '100px',
    open: false,
    iframeSrc: ''
  }
  it( 'renders without crashing', () => {
    component = mountWithIntl( <LegalDisclaimerDropdown { ...props } /> );
    expect( component.find( 'LegalDisclaimerDropdown' ).length ).toBe( 1 );
  } );


  it( 'shows iframe', () => {
    component = mountWithIntl( <LegalDisclaimerDropdown { ...props } /> );
    expect( component.find( '.LegalDisclaimerDropdown__messageTextMore' ).length ).toBe( 1 );
  } )


  it( 'it should change the show less message to show more message', () => {
    props.open = true;
    component = mountWithIntl( <LegalDisclaimerDropdown { ...props }/> );
    let j = component.find( '.LegalDisclaimerDropdown__Show' );
    expect( j.text( 0 ) ).toBe( messages.showLess.defaultMessage );

  } )

  it( 'it should change the show less messaege to show more message', () => {
    props.open = false;
    component = mountWithIntl( <LegalDisclaimerDropdown { ...props }/> );
    let i = component.find( '.LegalDisclaimerDropdown__Show' );
    expect( i.text( 1 ) ).toBe( messages.showMore.defaultMessage );

  } )

  props.isLoaded = jest.fn();
  component = mountWithIntl( <LegalDisclaimerDropdown { ...props }/> );
  const instance = component.find( 'LegalDisclaimerDropdown' ).instance();

  it( 'should call the setIframeDisplay method', () => {
    expect( instance.state.iframeLoaded ).toEqual( false );
    instance.setIframeDisplay();
    expect( instance.state.iframeLoaded ).toEqual( true );
    expect( props.isLoaded ).toHaveBeenCalled( );
  } );

  it( 'should call the toggleIframeHeight method', () => {
    expect( instance.state.open ).toEqual( false );
    instance.toggleIframeHeight();
    expect( instance.state.open ).toEqual( true );
    expect( instance.state.iframeHeight ).toEqual( '300px' );
  } );

} );
