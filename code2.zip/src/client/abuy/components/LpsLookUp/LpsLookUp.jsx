/**
 * LpsLookUp
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './LpsLookUp.css';
import NewUltamateRewardsUser from 'abuy/components/UltamateRewards/NewUltamateRewardsUser/NewUltamateRewardsUser';
import ExistingUltamateRewardsUser from 'abuy/components/UltamateRewards/ExistingUltamateRewardsUser/ExistingUltamateRewardsUser';
import UltamateRewardsMemberId from 'abuy/components/UltamateRewards/UltamateRewardsMemberId/UltamateRewardsMemberId';
import Anchor from 'shared/components/Anchor/Anchor';
import ChevronRightSVG from 'shared/components/Icons/chevron_right';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './LpsLookUp.messages';


const propTypes = {
  lpsFlag: PropTypes.string
}

const initialState = {
  isModalOpen: false
};

/**
 * Class
 * @extends React.Component
 */
class LpsLookUp extends Component{

  /**
   * Create a LpsLookUp
   */
  constructor( props ){
    super( props );
    this.state = initialState;
    this.toggleModal = this.toggleModal.bind( this );
  }

  toggleModal(){
    this.setState( { isModalOpen: !this.state.isModalOpen } );
  }

  /**
   * Renders the LpsLookUp component
   */
  render(){
    const {
      lpsFlag
    } = this.props;

    return (
      <div className='LpsLookUp'>
        <UltamateRewardsMemberId
          modalStatus={ this.toggleModal }
          isModalOpen={ this.state.isModalOpen }
        />

        { ( () => {
          switch ( lpsFlag ){
            case '405':
              return (
                <ExistingUltamateRewardsUser
                  removeInputFromReduxForm={ this.props.removeInputFromReduxForm }
                  modalStatus={ this.toggleModal }
                />
              );

            case '404':
            case '452':
              return (
                <NewUltamateRewardsUser
                  removeInputFromReduxForm={ this.props.removeInputFromReduxForm }
                  modalStatus={ this.toggleModal }
                />
              );
          }
        } )() }

      </div>
    );
  }
}

LpsLookUp.propTypes = propTypes;

export default LpsLookUp;
