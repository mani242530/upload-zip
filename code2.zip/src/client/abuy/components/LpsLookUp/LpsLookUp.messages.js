/*
 * LpsLookUp Messages
 *
 * This contains all the text for the LpsLookUp component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  continueMessage: {
    id: 'i18n.LpsLookUp.continueMessage',
    defaultMessage: 'CONTINUE APPLICATION'
  }
} );
