import React from 'react';
import ReactDOM from 'react-dom';
import LpsLookUp from './LpsLookUp';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import CONFIG from 'abuy/abuy.config';
import configureStore from 'abuy/abuy.store';
import { Provider } from 'react-redux';

describe( '<LpsLookUp />', () => {
  let component;
  const store = configureStore( {}, CONFIG );
  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <LpsLookUp />
      </Provider>
    );
    expect( component.find( 'LpsLookUp' ).length ).toBe( 1 );
  } );

  it( 'should change the isModalOpen value', () => {
    const instance = component.find( 'LpsLookUp' ).instance();
    expect( instance.state.isModalOpen ).toEqual( false );
    instance.toggleModal();
    expect( instance.state.isModalOpen ).toEqual( true );
  } );
} );
