import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './NotifyMailResponse.css';
import { connect } from 'react-redux';
import Exclamation from 'shared/components/Icons/exclamationcircle';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './NotifyMailResponse.messages';
import Button from 'shared/components/Button/Button';
import Anchor from 'shared/components/Anchor/Anchor';
import Image from 'shared/components/Image/Image';
import Divider from 'shared/components/Divider/Divider';


const MOBILE_BANNERIMAGE_URL = 'https://images.ulta.com/is/image/Ulta/wk1117_m_banner_ccard_response_notifybymail'

import has from 'lodash/has';
import isUndefined from 'lodash/isUndefined';
import {
  Redirect
} from 'react-router-dom';

import Adsverification from 'abuy/components/Adsverification/Adsverification';


const propTypes = {
  guestServiceNumber: PropTypes.string
}

const defaultProps = {
  bannerImageUri: 'https://images.ulta.com/is/image/Ulta/wk1117_d_banner_ccard_response_notifybymail'
}

const mapStateToProps = ( state ) => {
  return {
    ...state.global
  };
}

const registered ='<sup>&reg</sup>';

/**
 * Class representing a ULTA ADA compliant NotifyMailResponse element
 * @extends React.Component
 */
class NotifyMailResponse extends Component{


  render(){


    const {
      bannerImageUri
    }=this.props;

    let numberUrl = `tel:+${this.props.guestServiceNumber}`;

    let instantCreditResponse = has( this.props, 'location.state.instantCreditResponse' ) ? this.props.location.state.instantCreditResponse : {};
    let lpsResponse = ( has( this.props, 'location.state.lpsResponse' ) && !isUndefined( this.props.location.state.lpsResponse ) )? this.props.location.state.lpsResponse : { rewardsMemberCreated:false };

    const {
      rewardsMemberCreated
    } = lpsResponse;
    const { firstName } = instantCreditResponse;

    return (
      <Adsverification { ...this.props }>
        <div className='NotifyMailResponse'>
          <div className='NotifyMailResponse__divider'>
            <Divider dividerType='gray' />
          </div>
          <div className='NotifyMailResponse__container'>
            <div className='NotifyMailResponse__column1'>
              <div className='NotifyMailResponse__banner'>
                <Image
                  src={ this.props.isMobileDevice ? MOBILE_BANNERIMAGE_URL : bannerImageUri }
                  alt='BannerImage'
                />
              </div>
            </div>
            <div className='NotifyMailResponse__column2'>
              { ( ()=>{
                const welcomeMsg =  formatMessage( messages.welcome );
                return (
                  <div className='NotifyMailResponse_welcome'>
                    { welcomeMsg }
                    <div className='NotifyMailResponse_firstName'>
                      { firstName }
                    </div>
                    <Divider dividerType='orangeHorizontal'/>
                  </div>
                )
              } )() }

              <div className='NotifyMailResponse_messageContainer'>
                <span dangerouslySetInnerHTML={
                  { __html: formatMessage( messages.message2, { registered } ) }
                }
                />

                { ( () => {
                  if( this.props.location.state.isAccountCreated ){
                    return (
                      <div className='CreditApprovalResponse__ultamateRewardsMemberIDHeadingMessage'>
                        { formatMessage( messages.ultamateRewardsMemberIDHeadingMessage ) }
                      </div>
                    )
                  }
                } )() }

              </div>
              <div className='NotifyMailResponse_message__convenienceMessage'>
                { formatMessage( messages.message3 ) }
              </div>


              { ( () => {
                if( rewardsMemberCreated === true ){
                  return (
                    <div className='CreditApprovalResponse__ultamateRewardsMemberIDMessageBlock'>
                      <div className='CreditApprovalResponse__ultamateRewardsMemberIDMessageBlock__Icon'>
                        <Exclamation />
                      </div>
                      <div className='CreditApprovalResponse__ultamateRewardsMember'>
                        <p className='CreditApprovalResponse__ultamateRewardsMemberIDMessage'>
                          { formatMessage( messages.ultamateRewardsMemberIDMessageOne ) }
                          <Anchor
                            className='MobileFooterTandC__help MobileFooterTandC__help__link MobileFooterTandC__help__number'
                            url={ numberUrl }
                          >
                            { this.props.guestServiceNumber }
                          </Anchor>
                          { formatMessage( messages.ultamateRewardsMemberIDMessageNumber ) }
                        </p>
                      </div>
                    </div>
                  )
                }
              } )() }

              { ( () => {
                if( this.props.shoppingCartCount === '0' ){
                  return (
                    <div className='NotifyMailResponse__shopping__btn'>
                      <Button
                        inputTag='a'
                        btnSize='lg'
                        btnOption='single'
                        btnURL='/'
                      >
                        { formatMessage( messages.continueShopping ) }
                      </Button>
                    </div>
                  )
                }
                else {
                  return (
                    <div className='NotifyMailResponse__shopping__btn'>
                      <div className='NotifyMailResponse__shopping__btn'>
                        <Button
                          inputTag='a'
                          btnSize='lg'
                          btnOption='single'
                          btnURL='/bag'
                        >
                          { formatMessage( messages.continueCheckOut ) }
                        </Button>
                      </div>
                      <div className='NotifyMailResponse__shopping__btn__Return'>
                        <Button
                          inputTag='a'
                          btnSize='lg'
                          btnOption='single'
                          btnOutLine={ true }
                          btnURL='/'
                        >
                          { formatMessage( messages.returnShopping ) }
                        </Button>
                      </div>
                    </div>
                  )
                }
              } )() }

            </div>
          </div>
        </div>
      </Adsverification>
    );
  }
}

NotifyMailResponse.propTypes = propTypes;
NotifyMailResponse.defaultProps = defaultProps;

const intlNotifyMailResponse =  NotifyMailResponse;
export default connect( mapStateToProps )( intlNotifyMailResponse );
