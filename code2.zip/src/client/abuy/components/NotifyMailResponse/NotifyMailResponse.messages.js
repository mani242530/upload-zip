import { defineMessages } from 'react-intl';

export default defineMessages( {
  welcome: {
    id: 'i18n.NotifyMailResponse.welcome',
    defaultMessage: 'THANK YOU FOR YOUR APPLICATION,'
  },
  message1:{
    id: 'i18n.NotifyMailResponse.message1',
    defaultMessage: 'Your new Ulta.com account has been created! '
  },
  message2:{
    id: 'i18n.NotifyMailResponse.message2',
    defaultMessage: 'Your Ultamate Rewards{registered} Credit Card application is under review. We\'ll let you know about your application status by mail within 10 business days.'
  },
  message3: {
    id: 'i18n.NotifyMailResponse.message3',
    defaultMessage: 'For your convenience, use any of our other payment methods to complete your order today and earn Ultamate Rewards points on your purchase.'
  },
  continueShopping: {
    id: 'i18n.NotifyMailResponse.continueShopping',
    defaultMessage: 'Continue Shopping'
  },
  continueCheckOut: {
    id: 'i18n.NotifyMailResponse.continueCheckOut',
    defaultMessage: 'Continue To Checkout'
  },
  returnShopping: {
    id: 'i18n.NotifyMailResponse.returnShopping',
    defaultMessage: 'Return To Shopping'
  },
  thankyou: {
    id: 'i18n.NotifyMailResponse.thankyou',
    defaultMessage: 'Thanks for applying, {firstName}!'
  },
  ultamateRewardsMemberIDHeadingMessage:{
    id: 'i18n.NotifyMailResponse.ultamateRewardsMemberIDMessage',
    defaultMessage: 'We\'ve also created an Ulta.com account for you where you can shop and earn points on each purchase.'
  },
  ultamateRewardsMemberIDMessageOne:{
    id: 'i18n.NotifyMailResponse.ultamateRewardsMemberIDMessage',
    defaultMessage: 'A new Ultamate Rewards Member ID has been created and tied to your Ulta.com account. If you are an existing Ultamate Rewards member and wish to tie your existing Member ID to your Ulta.com account, please call '
  },
  ultamateRewardsMemberIDMessageNumber:{
    id: 'i18n.NotifyMailResponse.ultamateRewardsMemberIDMessage',
    defaultMessage: ' for assistance.'
  }
} );
