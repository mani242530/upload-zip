
import React from 'react';
import ReactDOM from 'react-dom';
import NotifyMailResponse from './NotifyMailResponse';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { IntlProvider } from 'react-intl';
import Button from 'shared/components/Button/Button';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';

const intlProvider = new IntlProvider( { locale: 'en' }, {} );
const { intl } = intlProvider.getChildContext();
const store = configureStore( {}, CONFIG );
window.requestAnimationFrame = jest.fn();
describe( '<NotifyMailResponse/>', () => {

  let props = {
    intl,
    history:'/CreditCardApplyForm',
    location: {
      state : {
        isAccountCreated : true
      }
    },
    shoppingCartCount : '0'
  }

  let component = mountWithIntl(
    <Provider store={ store }>
      <NotifyMailResponse
        { ...props }
      />
    </Provider>
  );
  it( 'renders without crashing', ()=>{
    expect( component.find( '.NotifyMailResponse' ).length ).toBe( 1 );
  } );

  it( 'should have one NotifyMailResponse_welcome', ()=>{
    expect( component.find( '.NotifyMailResponse_welcome' ).length ).toBe( 1 );
  } );

  it( 'should have one NotifyMailResponse_messageContainer', ()=>{
    expect( component.find( '.NotifyMailResponse_messageContainer' ).length ).toBe( 1 );
  } );

  it( 'should have continue shopping link', ()=>{
    expect( component.find( Button ).length ).toBe( 1 );
    expect( component.find( Button ).props().btnURL ).toBe( '/' );
  } );

} );
