/**
 * SsnLastFourInput
 */

import React from 'react';
import PropTypes from 'prop-types';
import './SsnLastFourInput.css';
import messages from './SsnLastFourInput.messages';
import InputField from 'shared/components/InputField/InputField';
import {
  validate,
  validationKeys
} from 'utils/FormValidations/FormValidations';
import FormValidationMessages from 'utils/FormValidations/FormValidations.messages';
import { formatMessage } from 'shared/components/Global/Global';
const propTypes = {
  name: PropTypes.string,
  tabIndex: PropTypes.number,
  showMaskedValue: PropTypes.bool,
  maskedToggleTarget: PropTypes.string
}

const defaultProps = {
  name: 'ssnLastFour',
  tabIndex: -1,
  showMaskedValue: false,
  maskedToggleTarget: 'ssn'
}


const SsnLastFourInput = ( props ) => {

  const {
    name,
    tabIndex
  } = props

  const ssnLastFourWarning = ( val ) => {
    return validate( val, validationKeys.showWarningMessage, messages.ssnWarning );
  }
  const validateSSN = ( val ) => {
    return validate( val, validationKeys.validateSSNlastFour, FormValidationMessages.invalidSSNlastFour );
  }

  return (
    <div className='SsnLastFourInput'>
      <div className='SsnLastFourInput--ssnPrefix'>
        <p className='SsnLastFourInput--ssnPrefixTxt InputField'>XXX&nbsp;-&nbsp;XX&nbsp;-</p>
      </div>
      <div className='SsnLastFourInput--field'>
        <InputField
          label={ formatMessage( messages.ssnLastFourMsg1 ) }
          placeholder={ formatMessage( messages.ssnLastFourMsg2 ) }
          type='tel'
          name={ name }
          maxLength={ 4 }
          validate={ [validateSSN] }
          warn={ [ssnLastFourWarning] }
          instructionalText={ formatMessage( messages.ssnWarning ) }
          tabIndex={ tabIndex }
          formatter={
            {
              pattern: '9999'
            }
          }
          disablePaste={ true }
        />
      </div>
    </div>
  );

}

SsnLastFourInput.propTypes = propTypes;
SsnLastFourInput.defaultProps = defaultProps;

export default SsnLastFourInput;