/*
 * SsnLastFourInput Messages
 *
 * This contains all the text for the SsnLastFourInput component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.SsnLastFourInput.header',
    defaultMessage: 'This is the SsnLastFourInput component !'
  },
  SocialSecurity: {
    id: 'i18n.CreditCardApplyForm.SocialSecurity',
    defaultMessage: 'Social Security Number'
  },
  ssnLastFourMsg1: {
    id: 'i18n.SsnLastFourInput.ssnLastFourMsg1',
    defaultMessage: 'Last 4 Digits of SSN'
  },
  ssnLastFourMsg2: {
    id: 'i18n.SsnLastFourInput.ssnLastFourMsg2',
    defaultMessage: 'Last 4 Digits'
  },
  ssnWarning: {
    id: 'i18n.CreditCardApplyForm.ssnWarning',
    defaultMessage: 'We use this to verify your identity and obtain credit bureau information.'
  }
} );
