import React from 'react';
import ReactDOM from 'react-dom';
import SsnLastFourInput from './SsnLastFourInput';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { reduxForm } from 'redux-form';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';

const Decorator=reduxForm( { form:'testForm' } )( SsnLastFourInput );
describe( '<SsnLastFourInput />', () => {
  let component;
  const store = configureStore( {}, CONFIG );

  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <Decorator />
      </Provider>
    );
    expect( component.find( 'SsnLastFourInput' ).length ).toBe( 1 );
  } );
} );
