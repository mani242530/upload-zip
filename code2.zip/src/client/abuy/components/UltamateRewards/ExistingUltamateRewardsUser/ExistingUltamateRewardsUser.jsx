import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Modal from 'react-modal';
import './ExistingUltamateRewardsUser.css';
import InputField from 'shared/components/InputField/InputField';
import messages from './ExistingUltamateRewardsUser.messages';
import Anchor from 'shared/components/Anchor/Anchor';
import { getRoute } from 'utils/Omniture/Omniture'
import {
  memberIdLengthValidation
} from 'utils/FormValidations/FormValidations';
import { formatMessage } from 'shared/components/Global/Global';
const isCheckout = getRoute( 'checkout' );

const propTypes = {
  modalStatus :  PropTypes.func
}

class ExistingUltamateRewardsUser extends Component{

  constructor( props ){
    super( props );
    this.handleOpenPopup = this.handleOpenPopup.bind( this );
  }

  handleOpenPopup( e ){
    this.props.modalStatus();
  }

  componentWillUnMount(){
    this.props.removeInputFromReduxForm( 'beautyClubNumber' );
  }

  render(){

    const copyright = '<sup>&copy</sup>'

    return (
      <div className='ExistingUltamateRewardsUser'>
        <div
          className='ExistingUltamateRewardsUser__ExistingMessage'
          dangerouslySetInnerHTML={ { __html: formatMessage( messages.existingMessage, { copyright } ) } }
        />
        <div className='ExistingUltamateRewardsUser__MemberIdMessage'>
          { formatMessage( messages.memberIdMessage ) }
        </div>

        <div className='ExistingUltamateRewardsUser__IdForm'>
          <InputField
            label={ formatMessage( messages.memberId ) }
            type='tel'
            name='beautyClubNumber'
            formatter={ { pattern: '9999999999999' } }
            validate={ memberIdLengthValidation }
            clearOnUnmount={ this.props.removeInputFromReduxForm }
            formName={ 'checkout-rewards' }
            trackAnalytics={ !!isCheckout }
          />
        </div>

        <div className='ExistingUltamateRewardsUser__LinkIdMessage'>
          <Anchor
            url='#'
            clickHandler={ this.handleOpenPopup }
          >
            { formatMessage( messages.newMemberIdMessage ) }
          </Anchor>

        </div>
      </div>
    );
  }
}

ExistingUltamateRewardsUser.propTypes = propTypes;

export default ExistingUltamateRewardsUser;