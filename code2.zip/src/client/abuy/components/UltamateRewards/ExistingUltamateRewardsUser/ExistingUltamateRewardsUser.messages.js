/*
 * ExistingUltamateRewardsUser Messages
 *
 * This contains all the text for the ExistingUltamateRewardsUser component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {

  memberId: {
    id: 'i18n.ExistingUltamateRewardsUser.memberId',
    defaultMessage: 'Member ID'
  },
  existingMessage: {
    id: 'i18n.ExistingUltamateRewardsUser.existingMessage',
    defaultMessage: 'Looks like you are already an Ultamate Rewards{copyright} member!'
  },
  memberIdMessage: {
    id: 'i18n.ExistingUltamateRewardsUser.memberIdMessage',
    defaultMessage: 'Please enter your Member ID to link it to your new credit card.'
  },
  newMemberIdMessage: {
    id: 'i18n.ExistingUltamateRewardsUser.newMemberIdMessage',
    defaultMessage: 'Need to find your Member ID?'
  }


} );
