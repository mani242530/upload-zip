import React from 'react';
import ReactDOM from 'react-dom';
import ExistingUltamateRewardsUser from './ExistingUltamateRewardsUser';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './ExistingUltamateRewardsUser.messages';
import { reduxForm } from 'redux-form';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import { formatMessage } from 'shared/components/Global/Global';

const Decorator=reduxForm( { form:'testForm' } )( ExistingUltamateRewardsUser );
describe( '<ExistingUltamateRewardsUser />', () => {
  const store = configureStore( {}, CONFIG );
  let component = mountWithIntl(
    <Provider store={ store }>
      <Decorator />
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'ExistingUltamateRewardsUser' ).length ).toBe( 1 );
  } );
  it( 'it should show the number of anchor', () => {
    expect( component.find( 'Anchor' ).length ).toBe( 1 );
  } );

  it( 'it should show the Existing Message', () => {
    const copyright = '<sup>&copy</sup>';
    const message =  formatMessage( messages.existingMessage, { copyright } );

    var temp = document.createElement( 'div' );
    temp.innerHTML = message;
    expect( component.find( '.ExistingUltamateRewardsUser__ExistingMessage' ).at( 0 ).text() ).toBe( temp.textContent );
  } );
  it( 'it should show the Member Id Message', () => {
    expect( component.find( '.ExistingUltamateRewardsUser__MemberIdMessage' ).at( 0 ).text() ).toBe( messages.memberIdMessage.defaultMessage );
  } );

  it( 'it should show the Input field', () => {
    expect( component.find( 'InputField' ).length ).toBe( 1 );
  } );

  it( 'it should show the New Member Id Message', () => {
    expect( component.find( '.ExistingUltamateRewardsUser__LinkIdMessage' ).at( 0 ).text() ).toBe( messages.newMemberIdMessage.defaultMessage );
  } );

  let props = {
    modalStatus:jest.fn(),
    removeInputFromReduxForm: jest.fn()
  };

  const component1 = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props }/>
    </Provider>
  );
  const instance = component1.find( 'ExistingUltamateRewardsUser' ).instance();

  it( 'should call the handleOpenPopup method', () => {
    instance.handleOpenPopup();
    expect( props.modalStatus ).toHaveBeenCalled();
  } );

  it( 'should call the componentWillUnMount', () => {
    instance.componentWillUnMount();
    expect( props.removeInputFromReduxForm ).toHaveBeenCalledWith( 'beautyClubNumber' );
  } );
} );
