/**
 * NewUltamateRewardsUser
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Field, reduxForm } from 'redux-form';
import './NewUltamateRewardsUser.css';
import InputField from 'shared/components/InputField/InputField';
import messages from './NewUltamateRewardsUser.messages';
import Anchor from 'shared/components/Anchor/Anchor';
import {
  memberIdLengthValidation
} from 'utils/FormValidations/FormValidations';
import { formatMessage } from 'shared/components/Global/Global';


const propTypes = {
  modalStatus :  PropTypes.func
}

const initialState = {
  displayMemberIdField: true
}
const copyright ='<sup>&copy</sup>'
/**
 * Class
 * @extends React.Component
 */
class NewUltamateRewardsUser extends Component{

  /**
   * Create a NewUltamateRewardsUser
   */
  constructor( props ){
    super( props );
    this.state = initialState;
    this.handleOpenPopup = this.handleOpenPopup.bind( this );
    this.handleMemberIdField = this.handleMemberIdField.bind( this );
  }

  handleOpenPopup( e ){
    this.props.modalStatus();
  }

  handleMemberIdField( e ){
    this.setState( { displayMemberIdField: !this.state.displayMemberIdField } );
  }

  /**
   * Renders the NewUltamateRewardsUser component
   */
  render(){
    return (
      <div className='NewUltamateRewardsUser'>
        { ( () => {
          if( this.state.displayMemberIdField === true ){
            return (
              <div className='NewUltamateRewardsUser__Messages'>
                <div className='NewUltamateRewardsUser__ExistingMessage'
                  dangerouslySetInnerHTML={ { __html: formatMessage( messages.existingMessage, { copyright } ) } }
                />
                <div className='NewUltamateRewardsUser__PointsMessage'>
                  { formatMessage( messages.pointsMessage ) }
                </div>
                <div className='NewUltamateRewardsUser__LinkMessage'>
                  <Anchor
                    url='#'
                    clickHandler={ this.handleMemberIdField }
                  >
                    <span dangerouslySetInnerHTML={
                      { __html: formatMessage( messages.linkMessage, { copyright } ) }
                    }
                    />
                  </Anchor>
                </div>
              </div>
            )
          }
          else {
            return (
              <div className='NewUltamateRewardsUser__FormMessages'>
                <div className='NewUltamateRewardsUser__ExistingMessage'>
                  <span dangerouslySetInnerHTML={ { __html: formatMessage( messages.linkHeaderMessage, { copyright } ) } }/>
                  <Anchor
                    url='#'
                    clickHandler={ this.handleMemberIdField }
                  >
                    <span className='NewUltamateRewardsUser__CancelMessage'>
                      { formatMessage( messages.cancelMessage ) }
                    </span>
                  </Anchor>
                </div>
                <div className='NewUltamateRewardsUser__PointsMessage'>
                  { formatMessage( messages.memberIdMessage ) }
                </div>
                <div className='NewUltamateRewardsUser__IdForm'>
                  <InputField
                    label={ formatMessage( messages.memberId ) }
                    type='tel'
                    name='beautyClubNumber'
                    formatter={ { pattern: '9999999999999' } }
                    validate={ memberIdLengthValidation }
                    clearOnUnmount={ this.props.removeInputFromReduxForm }
                  />
                </div>
                <div className='NewUltamateRewardsUser__LinkIdMessage'>
                  <Anchor
                    url='#'
                    clickHandler={ this.handleOpenPopup }
                  >
                    { formatMessage( messages.newMemberIdMessage ) }
                  </Anchor>
                </div>
              </div>
            )
          }
        } )() }

      </div>
    );
  }
}

NewUltamateRewardsUser.propTypes = propTypes;

export default NewUltamateRewardsUser;