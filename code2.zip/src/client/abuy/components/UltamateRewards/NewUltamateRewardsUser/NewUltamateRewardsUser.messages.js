/*
 * NewUltamateRewardsUser Messages
 *
 * This contains all the text for the NewUltamateRewardsUser component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {

  memberId: {
    id: 'i18n.NewUltamateRewardsUser.memberId',
    defaultMessage: 'Member ID'
  },
  existingMessage: {
    id: 'i18n.NewUltamateRewardsUser.existingMessage',
    defaultMessage: 'Looks like you are new to Ultamate Rewards{copyright}!'
  },
  memberIdMessage: {
    id: 'i18n.NewUltamateRewardsUser.memberIdMessage',
    defaultMessage: 'Please enter your Member ID to link it to your new credit card'
  },
  newMemberIdMessage: {
    id: 'i18n.NewUltamateRewardsUser.newMemberIdMessage',
    defaultMessage: 'Need to find your Member ID?'
  },
  pointsMessage: {
    id: 'i18n.NewUltamateRewardsUser.pointsMessage',
    defaultMessage: 'You will now start earning points on every purchase'
  },

  linkMessage: {
    id: 'i18n.NewUltamateRewardsUser.linkMessage',
    defaultMessage: 'Link your existing Ultamate Rewards{copyright} membership?'
  },
  linkHeaderMessage: {
    id: 'i18n.NewUltamateRewardsUser.linkHeaderMessage',
    defaultMessage: 'Link your existing Ultamate Rewards{copyright} membership'
  },
  cancelMessage: {
    id: 'i18n.NewUltamateRewardsUser.cancelMessage',
    defaultMessage: 'or cancel'
  }
} );
