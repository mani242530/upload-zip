import React from 'react';
import ReactDOM from 'react-dom';
import NewUltamateRewardsUser from './NewUltamateRewardsUser';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './NewUltamateRewardsUser.messages';
import { reduxForm } from 'redux-form';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import { formatMessage } from 'shared/components/Global/Global';

const Decorator=reduxForm( { form:'testForm' } )( NewUltamateRewardsUser );
describe( '<NewUltamateRewardsUser />', () => {
  const store = configureStore( {}, CONFIG );
  let component= mountWithIntl(
    <Provider store={ store }>
      <Decorator />
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'NewUltamateRewardsUser' ).length ).toBe( 1 );
  } );
  it( 'it should show the number of anchor components', () => {
    expect( component.find( 'Anchor' ).length ).toBe( 1 );
  } );

  it( 'it should show the Existing Message', () => {
    const copyright = '<sup>&copy</sup>';
    const message =  formatMessage( messages.existingMessage, { copyright } );

    var temp = document.createElement( 'div' );
    temp.innerHTML = message;

    expect( component.find( '.NewUltamateRewardsUser__ExistingMessage' ).at( 0 ).text() ).toBe( temp.textContent );
  } );

  it( 'it should show the Member Id message on clicking the link', () => {
    component.find( 'Anchor' ).at( 0 ).simulate( 'click' );
    expect( component.find( '.NewUltamateRewardsUser__PointsMessage' ).at( 0 ).text() ).toBe( messages.memberIdMessage.defaultMessage );
  } );


  it( 'it should show the Member Id Message', () => {
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <Decorator />
      </Provider>
    );

    let node1 = component1.find( 'NewUltamateRewardsUser' );
    node1.instance().state.displayMemberIdField = false;
    component1 = mountWithIntl(
      <Provider store={ store }>
        <Decorator />
      </Provider>
    );
    expect( component.find( '.NewUltamateRewardsUser__PointsMessage' ).text() ).toBe( messages.memberIdMessage.defaultMessage );
  } );


} );
