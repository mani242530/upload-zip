/**
 * UltamateRewardsMemberId
 */

import React, { Component } from 'react';
import './UltamateRewardsMemberId.css';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './UltamateRewardsMemberId.messages';
import Slider from 'react-slick';
import Image from 'shared/components/Image/Image';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { connect } from 'react-redux';
import CloseSVG from 'shared/components/Icons/close';
import Modal from 'react-modal';
import Anchor from 'shared/components/Anchor/Anchor';
import isUndefined from 'lodash/isUndefined';

const mapStateToProps = ( state ) => {
  return {
    ...state.global
  };
}

/**
 * Class
 * @extends React.Component
 */
class UltamateRewardsMemberId extends Component{

  /**
   * Create a UltamateRewardsMemberId
   */
  constructor( props ){
    super( props );
    this.getMobileView = this.getMobileView.bind( this );
    this.getDesktopView = this.getDesktopView.bind( this );

    this.isSlickDotsElemsHidden = false; // This flag is used to stop re-render the componentDidUpdate
    if( !isUndefined( this.props.loadModelContainerId ) ){
      /* This tells react-modal which is the parent div */
      Modal.setAppElement( this.props.loadModelContainerId );
    }
  }

  componentDidUpdate(){
    if( this.props.displayType === 'mobile' && this.props.isModalOpen && !this.isSlickDotsElemsHidden ){
      // Wait carousel to load when isModalOpen prop set to ture
      // Added aria-hidden to slick dots element to hide from screenreader
      setTimeout( () => {
        let jsCarouselSlickDotsElem = document.querySelector( '.UltamateRewardsMemberId ul.slick-dots' );
        jsCarouselSlickDotsElem.setAttribute( 'aria-hidden', 'true' );
      }, 1000 );

      this.isSlickDotsElemsHidden = true;
    }

    // reset isSlickDotsElemsHidden flag when isModalOpen prop set to false
    if( this.props.displayType === 'mobile' && !this.props.isModalOpen && this.isSlickDotsElemsHidden ){
      this.isSlickDotsElemsHidden = false;
    }
  }

  /**
   * Renders the UltamateRewardsMemberId component
   */
  getMobileView( settings ){


    return (
      <div className='UltamateRewardsMemberIdContent_mobile'>
        <div className='UltamateRewardsMemberIdContent__MemberIdMessageItems'>

          <Slider className='slider'{ ...settings }>
            <div className='UltamateRewardsMemberIdContent_column'>
              <div className='UltamateRewardsMemberIdContent__ImageOne'>
                <div className='UltamateRewardsMemberIdContent__TitleMessage'>
                  { formatMessage( messages.titleMessageOne ) }
                </div>
                <Image
                  src='//images.ulta.com/is/image/Ulta/wk1417_ccard_findmemberid_receipt'
                  alt=''
                  width={ 130 }
                  height={ 170 }
                />
              </div>
            </div>

            <div className='UltamateRewardsMemberIdContent_column'>
              <div className='UltamateRewardsMemberIdContent__ImageTwo'>
                <div className='UltamateRewardsMemberIdContent__TitleMessage'>
                  { formatMessage( messages.titleMessageTwo ) }
                </div>
                <Image
                  src='//images.ulta.com/is/image/Ulta/wk1417_ccard_findmemberid_magazine'
                  alt=''
                  width={ 130 }
                  height={ 170 }
                />
              </div>
            </div>
            <div className='UltamateRewardsMemberIdContent_column'>
              <div className='UltamateRewardsMemberIdContent__ImageThree'>
                <div className='UltamateRewardsMemberIdContent__TitleMessage'>
                  { formatMessage( messages.titleMessageThree ) }
                </div>
                <Image
                  src='//images.ulta.com/is/image/Ulta/wk1417_ccard_findmemberid_membershipcard'
                  alt=''
                  width={ 130 }
                  height={ 170 }
                />

              </div>
            </div>
          </Slider>
        </div>
      </div>
    )
  }
  getDesktopView(){


    return ( <div className='UltamateRewardsMemberIdContent_desktop'>
      <div className='UltamateRewardsMemberIdContent_column'>
        <div className='UltamateRewardsMemberIdContent__ImageOne'>
          <div className='UltamateRewardsMemberIdContent__TitleMessage'>
            { formatMessage( messages.titleMessageOne ) }
          </div>
          <Image
            src='//images.ulta.com/is/image/Ulta/wk1417_ccard_findmemberid_receipt'
            alt=''
            width={ 130 }
            height={ 170 }
          />
        </div>
      </div>

      <div className='UltamateRewardsMemberIdContent_column'>
        <div className='UltamateRewardsMemberIdContent__ImageTwo'>
          <div className='UltamateRewardsMemberIdContent__TitleMessage'>
            { formatMessage( messages.titleMessageTwo ) }
          </div>
          <Image
            src='//images.ulta.com/is/image/Ulta/wk1417_ccard_findmemberid_magazine'
            alt=''
            width={ 130 }
            height={ 170 }
          />
        </div>
      </div>
      <div className='UltamateRewardsMemberIdContent_column'>
        <div className='UltamateRewardsMemberIdContent__ImageThree'>
          <div className='UltamateRewardsMemberIdContent__TitleMessage'>
            { formatMessage( messages.titleMessageThree ) }
          </div>
          <Image
            src='//images.ulta.com/is/image/Ulta/wk1417_ccard_findmemberid_membershipcard'
            alt=''
            width={ 130 }
            height={ 170 }
          />

        </div>
      </div>
    </div> )
  }
  render(){
    let settings = {
      accessibility:true,
      dots: true,
      infinite: false,
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      className: 'center',
      swipeToSlide: true,
      centerMode: true,
      centerPadding: '22px'
    };




    return (
      <Modal
        isOpen={ this.props.isModalOpen }
        onRequestClose={ this.props.modalStatus }
        contentLabel={ formatMessage( messages.a11yLabel ) }
        role='dialog'
      >
        <div className='UltamateRewardsMemberId'>
          <div className='UserRewardsLookup__closeModal'>

            <button className='UserRewardsLookup__CloseButton' onClick={ this.props.modalStatus }>
              <CloseSVG/>
            </button>
          </div>
          <div className='UltamateRewardsMemberIdContent'>

            <div className='UltamateRewardsMemberIdContent__headerMessage'>
              { formatMessage( messages.headerMessage ) }
            </div>

            <div className='UltamateRewardsMemberIdContent_mobileDesktop'>
              { ( this.props.displayType === 'mobile' ) ? this.getMobileView( settings ): this.getDesktopView() }
            </div>

            <div className='UltamateRewardsMemberIdContent_footerMessage'>
              <div className='UltamateRewardsMemberIdContent__ForgetMessage'>
                { formatMessage( messages.ForgotMessage ) }
              </div>
              <div className='UltamateRewardsMemberIdContent__assistanceMessage'>
                { formatMessage( messages.assistanceMessage ) }
                <span className='UltamateRewardsMemberIdContent__assistanceMessageTwo'>
                  { formatMessage( messages.assistanceMessageTwo ) }
                </span>
                { formatMessage( messages.assistanceMessageThree ) }
              </div>
            </div>
          </div>
          <button
            className='sr-only'
            onClick={ this.props.modalStatus }
            role='link'
          >
            { formatMessage( messages.closeModal ) }
          </button>
        </div>
      </Modal>
    );
  }
}


const intlUltamateRewardsMemberId = UltamateRewardsMemberId;
export default connect( mapStateToProps )( intlUltamateRewardsMemberId );
