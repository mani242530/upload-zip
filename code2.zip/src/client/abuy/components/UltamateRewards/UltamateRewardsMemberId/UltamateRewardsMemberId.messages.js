/*
 * UltamateRewardsMemberId Messages
 *
 * This contains all the text for the UltamateRewardsMemberId component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  headerMessage: {
    id: 'i18n.UltamateRewardsMemberId.header',
    defaultMessage: 'You can find your Member ID in a few places:'
  },
  SalesMessage: {
    id: 'i18n.UltamateRewardsMemberId.SalesMessage',
    defaultMessage: 'Sales Receipt'
  },
  MagazineMessage: {
    id: 'i18n.UltamateRewardsMemberId.MagazineMessage',
    defaultMessage: 'Ulta Beauty Magazine'
  },
  MembershipMessageMessage: {
    id: 'i18n.UltamateRewardsMemberId.MembershipMessageMessage',
    defaultMessage: 'Membership Card'
  },
  ForgotMessage: {
    id: 'i18n.UltamateRewardsMemberId.ForgotMessage',
    defaultMessage: 'Forgot it? No problem!'
  },
  assistanceMessage: {
    id: 'i18n.UltamateRewardsMemberId.assistanceMessage',
    defaultMessage: 'Give us a call at'
  },
  assistanceMessageTwo: {
    id: 'i18n.UltamateRewardsMemberId.assistanceMessageTwo',
    defaultMessage: '1-866-983-8582'
  },
  assistanceMessageThree: {
    id: 'i18n.UltamateRewardsMemberId.assistanceMessageThree',
    defaultMessage: 'for assistance'
  },
  titleMessageOne: {
    id: 'i18n.UltamateRewardsMemberId.titleMessageOne',
    defaultMessage: 'Sales Receipt'
  },
  titleMessageTwo: {
    id: 'i18n.UltamateRewardsMemberId.titleMessageTwo',
    defaultMessage: 'Ulta Beauty Magazine'
  },
  titleMessageThree: {
    id: 'i18n.UltamateRewardsMemberId.titleMessageThree',
    defaultMessage: 'Membership Card'
  },
  a11yLabel: {
    id: 'i18n.UltamateRewardsMemberId.a11yLabel',
    defaultMessage: 'ultamate rewards member id dialog box is open'
  },
  closeModal: {
    id: 'i18n.UltamateRewardsMemberId.closeModal',
    defaultMessage: 'Close ultamate rewards member id pop up'
  }


} );
