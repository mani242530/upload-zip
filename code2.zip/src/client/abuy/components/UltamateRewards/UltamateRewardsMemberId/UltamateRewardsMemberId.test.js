import React from 'react';
import ReactDOM, { findDOMNode } from 'react-dom';
import UltamateRewardsMemberId from './UltamateRewardsMemberId';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './UltamateRewardsMemberId.messages';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';

let appElement = document.createElement( 'div' );
appElement.id='js-cartpage';
document.body.appendChild( appElement );

describe( '<UltamateRewardsMemberId />', () => {
  let component;
  const store = configureStore( {}, CONFIG );
  const props = {
    modalStatus:jest.fn(),
    isModalOpen:true,
    isOpen:true,
    loadModelContainerId: '#js-cartpage'
  }
  store.getState().global={
    displayType:'mobile'
  }
  component = mountWithIntl(
    <Provider store={ store }>
      <UltamateRewardsMemberId { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'UltamateRewardsMemberId' ).length ).toBe( 1 );
  } );
  it( 'it should show the header message', () => {

    expect( document.body.getElementsByClassName( 'UltamateRewardsMemberIdContent__headerMessage' )[0].innerHTML ).toBe( messages.headerMessage.defaultMessage );
  } );
  it( 'it should show slider', () => {

    expect( document.body.getElementsByClassName( 'slick-slider' ).length ).toBe( 1 );
  } );
  it( 'it should show the title message', () => {

    expect( document.body.getElementsByClassName( 'UltamateRewardsMemberIdContent__TitleMessage' )[0].innerHTML ).toBe( messages.titleMessageOne.defaultMessage );
  } );
  it( 'it should show the title message', () => {

    expect( document.body.getElementsByClassName( 'UltamateRewardsMemberIdContent__TitleMessage' )[1].innerHTML ).toBe( messages.titleMessageTwo.defaultMessage );
  } );
  it( 'it should show the title message', () => {

    expect( document.body.getElementsByClassName( 'UltamateRewardsMemberIdContent__TitleMessage' )[2].innerHTML ).toBe( messages.titleMessageThree.defaultMessage );
  } );
  it( 'it should show the Images', () => {

    expect( document.body.getElementsByClassName( 'Image' ).length ).toBe( 3 );
  } );
  it( 'it should show the Image one', () => {

    expect( document.body.getElementsByClassName( 'Image' )[0].getElementsByTagName( 'img' )[0].src ).toBe( '//images.ulta.com/is/image/Ulta/wk1417_ccard_findmemberid_receipt' )

  } );
  it( 'it should show the Image two', () => {

    expect( document.body.getElementsByClassName( 'Image' )[1].getElementsByTagName( 'img' )[0].src ).toBe( '//images.ulta.com/is/image/Ulta/wk1417_ccard_findmemberid_magazine' )

  } );
  it( 'it should show the Image three', () => {

    expect( document.body.getElementsByClassName( 'Image' )[2].getElementsByTagName( 'img' )[0].src ).toBe( '//images.ulta.com/is/image/Ulta/wk1417_ccard_findmemberid_membershipcard' )

  } );

  it( 'should render the Modal with dialog and contentLabel a11yLabel text', () => {
    expect( component.find( 'UltamateRewardsMemberId Modal' ).props().contentLabel ).toBe( messages.a11yLabel.defaultMessage );
    expect( component.find( 'UltamateRewardsMemberId Modal' ).props().role ).toBe( 'dialog' );
  } );

  it( 'should render ( close modal ) anchor with SVG and ariaLabel', () => {
    expect( document.body.getElementsByTagName( 'button' )[0].innerHTML.indexOf( '<title>Close</title>' ) ).toBeGreaterThan( 0 );
  } );

  it( 'renders a screen-reader only close Button component', () => {
    expect( component.find( 'UltamateRewardsMemberId Modal button.sr-only' ).props().children ).toBe( messages.closeModal.defaultMessage );
    expect( component.find( 'UltamateRewardsMemberId Modal button.sr-only' ).props().role ).toBe( 'link' );
  } );

  it( 'should close the Model when close Button clicked', () => {
    component.find( 'UltamateRewardsMemberId Modal button.sr-only' ).simulate( 'click' );
    expect( component.find( 'UltamateRewardsMemberId' ).instance().props.modalStatus ).toBeCalled();
  } );

  it( 'Check isSlickDotsElemsHidden set to be true after componentDidUpdate when Model open', () => {

    let props1 = {
      ...props,
      displayType: 'mobile',
      isModalOpen: true
    }

    let component2 = mountWithIntl(
      <Provider store={ store }>
        <UltamateRewardsMemberId { ...props }/>
      </Provider>
    );

    let node = component2.find( 'UltamateRewardsMemberId' ).instance();
    expect( node.isSlickDotsElemsHidden ).toBeFalsy();
    node.componentDidUpdate( props1 );
    expect( node.isSlickDotsElemsHidden ).toBeTruthy();

  } );

  it( 'Check isSlickDotsElemsHidden set to be false after componentDidUpdate when Model closed', () => {

    props.isModalOpen = false;

    let component2 = mountWithIntl(
      <Provider store={ store }>
        <UltamateRewardsMemberId { ...props }/>
      </Provider>
    );

    let node = component2.find( 'UltamateRewardsMemberId' ).instance();
    expect( node.isSlickDotsElemsHidden ).toBeFalsy();

  } );

} );
