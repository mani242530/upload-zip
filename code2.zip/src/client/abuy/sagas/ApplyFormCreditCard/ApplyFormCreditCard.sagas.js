/**
 * Created by rush on 5/16/17.
 */

import { takeEvery, take, call, put } from 'redux-saga/effects';
import { delay } from 'redux-saga';
import {
  types,
  actions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';

import isUndefined from 'lodash/isUndefined';
import isEmpty from 'lodash/isEmpty';
import has from 'lodash/has';
import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';
export const listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );


    // if the user has updated the form after making a lps update then we have to call LPS again in the submit first, then submit it on success back from them,

    let _action = action;
    yield call( delay, 2000 );
    if( process.env.NODE_ENV === 'development' ){
      // debug cases


      _action.data.values.__FORCE_RES = '06';

    }
    const res = yield call(
      ajax, {
        type,
        method:'post',
        values: _action.data.values
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body ) );

    if( !isUndefined( res.body ) && !isEmpty( res.body.instantCreditResponse ) ){

      yield put( getActionDefinition( 'user', 'requested' )() );

      const profileData = yield take( getServiceType( 'user', 'success' ) );

      // passing preapprovedUserData for the data that needs to be passed to create account form to fill missing data
      // isAccountCreated is flag which is true if newly account is created.
      // instant creditresponse is the response form the service which is used in response pages.
      const state = {
        ADSValidated: true,
        isAccountCreated: !!( !action.data.isSignedIn && has( profileData.data, 'user.accountInfo.firstName' ) ), // Updated the condition based on v2 user lite services
        isSignedIn: !!has( profileData.data, 'user.accountInfo.firstName' ), // Updated the condition based on v2 user lite services
        instantCreditResponse: res.body.instantCreditResponse,
        lpsResponse: res.body.lpsResponse,
        preapprovedUserData: action.data.values,
        isPreapprovedForm: action.data.isPreapprovedForm
      }

      switch ( res.body.instantCreditResponse.responseType ){
        case '01':
          action.data.history.replace( '/c/approved', state );
          break;

        case '02':
          action.data.history.replace( '/c/mail-notify', state );
          break;

        case '03':
          action.data.history.replace( '/c/error', state );
          break;

        case '04':
          action.data.history.replace( '/c/existing', state );
          break;

        case '05':
          action.data.history.replace( '/c/approved', state );
          break;

        case '06':
          action.data.history.replace( '/c/preapproved/approved', state );
          break;
      }
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'applyForm';
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );

  let preapprovedServiceType = 'prescreenApply';
  registerServiceName( preapprovedServiceType );
  yield takeEvery( getServiceType( preapprovedServiceType, 'requested' ), listener, preapprovedServiceType );
}
