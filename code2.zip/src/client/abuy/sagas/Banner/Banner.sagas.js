import { takeEvery, takeLatest, call, put, select } from 'redux-saga/effects';

import {
  types,
  actions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import { makeGetSessionID, makeGetSessionInfo } from 'shared/reducers/Session/Session.reducer';

import {
  ajax
} from 'utils/Ajax/Ajax';


// Individual exports for testing
export const listener = function*( type, action ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );

    let query = {
      sourcePage: action.data.sourcePage
    }

    const res = yield call( ajax, { type, query } );
    yield put( getActionDefinition( type, 'success' )( res.body ) );

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'banner';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
