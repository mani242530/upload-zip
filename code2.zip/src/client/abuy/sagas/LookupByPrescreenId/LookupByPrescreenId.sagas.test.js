import { takeEvery, call, put } from 'redux-saga/effects';
import saga, { listener } from './LookupByPrescreenId.sagas';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import {
  ajax
} from '../../../utils/Ajax/Ajax';

import { fullyQualifyLink } from 'utils/Formatters/formatters';

jest.mock( 'utils/Ajax/Ajax', () => {
  return { ajax:jest.fn() }
} );

jest.mock( 'utils/Formatters/formatters', () => {
  return { fullyQualifyLink:jest.fn() }
} );

const push = jest.fn();

describe( 'lpsLookupByPrescreenId Saga', () => {

  const type  = 'lpsLookupByPrescreenId';

  registerServiceName( type );

  const lpslookupbyprescreenid = saga();

  it( 'should listen for the navigation request method', () => {

    const takeEveryDescriptor = lpslookupbyprescreenid.next( global ).value;

    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );

  } );

  describe( 'listener saga success path for returnCode = 01', () => {

    const action = {
      data: {
        values: {
          __FORCE_RES: false
        },
        history: {
          push: push
        },
        paths: {
          successPath: '',
          failurePath : ''
        }
      }
    }
    const listenerSaga = listener( type, action );

    it( 'should wait until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next( process ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values: action.data.values } ) );

    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        body: {
          lpsPreScreenResponse: {
            firstName: 'TestFN',
            returnCode: '01'
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.lpsPreScreenResponse ) ) );

    } );

    it( 'should put a setDataLayer action', () => {

      const omnitureData = {
        'globalPageData': {
          'action': {
            'creditCardPrescreenApproval': 'true'
          }
        }
      };
      const omnitureEvt = {
        'name': 'pageNavigation'
      };
      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( omnitureData, omnitureEvt ) ) );

    } );

    it( 'Should call action.data.history.push method', () => {

      listenerSaga.next();

      expect( action.data.history.push ).toHaveBeenCalled();

    } );

    describe( 'listener saga success path for returnCode = 03', () => {

      const action = {
        data: {
          values: {
            __FORCE_RES: false
          },
          history: {
            push: push
          },
          paths: {
            successPath: '',
            failurePath : ''
          }
        }
      }
      const listenerSaga = listener( type, action );

      it( 'should wait until the loading event has been put', () => {

        const putDescriptor = listenerSaga.next( process ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

      } );

      it( 'should yield on requesting data and return that data with a sucess method', () => {

        const callDescriptor = listenerSaga.next().value;

        expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values: action.data.values } ) );

      } );

      it( 'should put a success event after data is called', () => {

        const res = {
          body: {
            lpsPreScreenResponse: {
              firstName: 'TestFN',
              returnCode: '03'
            }
          }
        };
        const putDescriptor = listenerSaga.next( res ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.lpsPreScreenResponse ) ) );

      } );

      it( 'Should call action.data.history.push method with the failure path.', () => {

        listenerSaga.next();

        expect( action.data.history.push ).toHaveBeenCalled();

      } );

    } );

    describe( 'listener saga success path for returnCode = 04', () => {

      const action = {
        data: {
          values: {
            __FORCE_RES: false
          },
          history: {
            push: push
          },
          paths: {
            successPath: '/success',
            failurePath : '/failure'
          }
        }
      }
      const listenerSaga = listener( type, action );

      it( 'should wait until the loading event has been put', () => {

        const putDescriptor = listenerSaga.next( process ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

      } );

      it( 'should yield on requesting data and return that data with a sucess method', () => {

        const callDescriptor = listenerSaga.next().value;

        expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values: action.data.values } ) );

      } );

      it( 'should put a success event after data is called', () => {

        const res = {
          body: {
            lpsPreScreenResponse: {
              firstName: 'TestFN',
              returnCode: '04'
            }
          }
        };
        const putDescriptor = listenerSaga.next( res ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.lpsPreScreenResponse ) ) );

      } );

      it( 'Should call fullyQualifyLink method', () => {

        listenerSaga.next();

        expect( fullyQualifyLink ).toHaveBeenCalled();

      } );

    } );

    describe( 'listener saga success path when lpsPreScreenResponse.returnCode is not present', () => {

      const action = {
        data: {
          values: {
            __FORCE_RES: false
          },
          history: {
            push: push
          },
          paths: {
            successPath: '',
            failurePath : ''
          }
        }
      }
      const listenerSaga = listener( type, action );

      it( 'should wait until the loading event has been put', () => {

        const putDescriptor = listenerSaga.next( process ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

      } );

      it( 'should yield on requesting data and return that data with a sucess method', () => {

        const callDescriptor = listenerSaga.next().value;

        expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values: action.data.values } ) );

      } );

      it( 'should put a success event after data is called', () => {

        const res = {
          body: {
            lpsPreScreenResponse: {
              firstName: 'TestFN'
            }
          }
        };
        const putDescriptor = listenerSaga.next( res ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.lpsPreScreenResponse ) ) );

      } );

      it( 'Should call action.data.history.push method with the failure path.', () => {

        listenerSaga.next();

        expect( action.data.history.push ).toHaveBeenCalled();

      } );

    } );

    describe( 'listener saga path when lpsPreScreenResponse is empty', () => {

      const action = {
        data: {
          values: {
            __FORCE_RES: false
          },
          history: {
            push: push
          },
          paths: {
            successPath: '',
            failurePath : ''
          }
        }
      }
      const listenerSaga = listener( type, action );

      it( 'should wait until the loading event has been put', () => {

        const putDescriptor = listenerSaga.next( process ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

      } );

      it( 'should yield on requesting data and return that data with a sucess method', () => {

        const callDescriptor = listenerSaga.next().value;

        expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values: action.data.values } ) );

      } );

      it( 'should put a success event after data is called', () => {

        const res = {
          body: {}
        };
        const putDescriptor = listenerSaga.next( res ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.lpsPreScreenResponse ) ) );

      } );

      it( 'Should call action.data.history.push method with the failure path.', () => {

        listenerSaga.next();

        expect( action.data.history.push ).toHaveBeenCalled();

      } );

    } );

  } );

  describe( 'listener saga failure path', () => {

    global.TRACK_SAGA_FAILURES = true;
    const err = {
      statusText:'some failure message'
    }
    const action = {
      data: {
        values: {
          __FORCE_RES: false
        },
        history: {
          push: push
        },
        paths: {
          successPath: '/success',
          failurePath : '/failure'
        }
      }
    }
    const listenerSaga = listener( type, action );

    it( 'should wait until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next( global ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should throw the error', () => {

      expect( () => {
        listenerSaga.next().throw( err )
      } ).toThrow();

    } );

  } );

} )
