/**
 * CheckoutPage Actions
 *
 * This file defines the action types and action creators for 'CheckoutPage'
 **/


/**
 * ACTION TYPES
 */
export const types = {

  NEWSLETTER_SIGNUP_STATUS: 'CHECKOUT_PAGE::NEWSLETTER_SIGNUP_STATUS',
  SET_EDIT_ADDRESS_DATA: 'CHECKOUT_PAGE::SET_EDIT_ADDRESS_DATA',
  SET_EDIT_CREDITCARD_DATA: 'CHECKOUT_PAGE::SET_EDIT_CREDITCARD_DATA',
  UPDATE_CREDIT_CARD: 'CHECKOUT_PAGE::UPDATE_CREDIT_CARD',
  UPDATE_STATE_DROPDOWN_VALUE: 'CART_AND_CHECKOUT_APP::UPDATE_STATE_DROPDOWN_VALUE',
  PAYPAL_RESPONSE: 'CHECKOUT_PAGE::PAYPAL_RESPONSE',
  UPDATE_SHIPPING_STATUS: 'CHECKOUT_PAGE::UPDATE_SHIPPING_STATUS',
  UPDATE_PAYMENT_STATUS: 'CHECKOUT_PAGE::UPDATE_PAYMENT_STATUS',
  UPDATE_DAV_POPUP: 'CHECKOUT_PAGE::UPDATE_DAV_POPUP',
  SET_PAYMENT_FORM_TYPE: 'CHECKOUT_PAGE::SET_PAYMENT_FORM_TYPE',
  SET_CREDITCARD_PAYMENT_TYPE: 'CHECKOUT_PAGE::SET_CREDITCARD_PAYMENT_TYPE',
  SET_CC_PAYMENT_FORM_SUBMIT: 'CHECKOUT_PAGE::SET_CC_PAYMENT_FORM_SUBMIT',
  SET_TEMP_PAYMENT_CCV_NUMBER: 'CHECKOUT_PAGE::SET_TEMP_PAYMENT_CCV_NUMBER',
  RESET_CART_MERGED: 'CHECKOUT_PAGE::RESET_CART_MERGED',
  CHANGE_CREDIT_CARD: 'CHECKOUT_PAGE::CHANGE_CREDIT_CARD',
  RESET_CARTPAGE_NAVIGATION: 'CHECKOUT_PAGE::RESET_CARTPAGE_NAVIGATION',
  RESET_ORDER_STATUS: 'CHECKOUT_PAGE::RESET_ORDER_STATUS',
  TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY: 'CHECKOUT_PAGE::TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY',
  TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY: 'CHECKOUT_PAGE::TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY',
  SET_SHIPPING_ERROR_MESSAGE: 'CHECKOUT_PAGE::SET_SHIPPING_ERROR_MESSAGE',
  SET_IS_COUPON_BUTTON_CLICKED: 'CHECKOUT_PAGE::SET_IS_COUPON_BUTTON_CLICKED',
  TOGGLE_SECURITY_CODE_ICON: 'CHECKOUT_PAGE::TOGGLE_SECURITY_CODE_ICON'
}


/**
 * ACTIONS
 */
export const actions = {

  newsLetterSignupStatus: ( status ) => ( { type: types.NEWSLETTER_SIGNUP_STATUS, status } ),
  setEditAddressData: ( data ) => ( { type: types.SET_EDIT_ADDRESS_DATA, data } ),
  setEditCreditCardData: ( data ) => ( { type: types.SET_EDIT_CREDITCARD_DATA, data } ),
  updateCreditCard: ( _dynSessConf, paymentFormValues ) => ( { type: types.UPDATE_CREDIT_CARD, _dynSessConf, paymentFormValues } ),
  updateStateDropdownValue: ( form, value ) => ( { type: types.UPDATE_STATE_DROPDOWN_VALUE, form, value } ),
  getPaypalResponse: ( info ) => ( { type: types.PAYPAL_RESPONSE, info } ),
  updateShippingStatus: ( data ) => ( { type: types.UPDATE_SHIPPING_STATUS, data } ),
  setShippingErrorMessage: ( data ) => ( { type: types.SET_SHIPPING_ERROR_MESSAGE, data } ),
  updatePaymentStatus: ( data ) => ( { type: types.UPDATE_PAYMENT_STATUS, data } ),
  setPaymentType: ( paymentType ) => ( { type: types.SET_PAYMENT_FORM_TYPE, paymentType } ),
  setCreditCardPaymentType: ( data ) => ( { type: types.SET_CREDITCARD_PAYMENT_TYPE, data } ),
  setCCPaymentFormSubmit: ( data ) => ( { type: types.SET_CC_PAYMENT_FORM_SUBMIT, data } ),
  setTempPaymentCCVNumber: ( data ) => ( { type: types.SET_TEMP_PAYMENT_CCV_NUMBER, data } ),
  resetCartMerge: ( ) => ( { type: types.RESET_CART_MERGED } ),
  updateDavPopup: ( ) => ( { type: types.UPDATE_DAV_POPUP } ),
  changeCreditCard: ( data ) => ( { type: types.CHANGE_CREDIT_CARD, data } ),
  resetCartPageNavigation: ( ) => ( { type: types.RESET_CARTPAGE_NAVIGATION } ),
  resetOrderStatus: ( ) => ( { type: types.RESET_ORDER_STATUS } ),
  toggleInputFieldShippingDisplay: ( ) => ( { type: types.TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY } ),
  toggleInputFieldPaymentDisplay: ( ) => ( { type: types.TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY } ),
  isCouponBtnClicked: ( data ) => ( { type: types.SET_IS_COUPON_BUTTON_CLICKED, data } ),
  toggleSecurityCode: ( status, displayType ) => ( { type: types.TOGGLE_SECURITY_CODE_ICON, status, displayType } )
}
