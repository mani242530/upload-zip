/**
 * Test for CheckoutPage actions
 */

import { types, actions } from './CheckoutPage.actions';
import _ from 'lodash';


describe( 'CheckoutPage actions/types', () => {

  describe( 'Edit address data', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_EDIT_ADDRESS_DATA ).toBe( 'CHECKOUT_PAGE::SET_EDIT_ADDRESS_DATA' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setEditAddressData ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data={
        refId : 'checkoutaddress',
        firstName : 'joe',
        lastName:'joe',
        phoneNumber: '1234567876',
        isPrimaryAddress: true,
        isPaypalFlag: true,
        addressData: {
          address1: 'address',
          address2: '',
          city: 'chicago',
          state: 'IL',
          postalCode: 12345
        }
      }

      const creator = actions.setEditAddressData( data );
      expect( creator ).toEqual( {
        type: types.SET_EDIT_ADDRESS_DATA,
        data
      } )
    } );
  } );

  describe( 'newsLetterSignupStatus', () => {

    it( 'The action type should exist', () => {
      expect( types.NEWSLETTER_SIGNUP_STATUS ).toBe( 'CHECKOUT_PAGE::NEWSLETTER_SIGNUP_STATUS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.newsLetterSignupStatus ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const status = true

      const creator = actions.newsLetterSignupStatus( status );
      expect( creator ).toEqual( {
        type: types.NEWSLETTER_SIGNUP_STATUS,
        status
      } )
    } );
  } );

  describe( 'Edit Creditcard data', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_EDIT_CREDITCARD_DATA ).toBe( 'CHECKOUT_PAGE::SET_EDIT_CREDITCARD_DATA' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setEditCreditCardData ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = {
        nickName: 'Mastercard - 4444',
        creditCardType: 'Mastercard',
        creditCardNumber: '4444',
        expirationMonth: '06',
        expirationYear: '2031',
        firstName: 'Jane',
        lastName: 'Doe',
        phoneNumber: '123-456-7890',
        addressData: {
          address1: '724 Greenwood Circle',
          address2: 'Apt#102',
          city: 'Naperville',
          state: 'IL',
          postalCode: '92476'
        }
      }

      const creator = actions.setEditCreditCardData( data );
      expect( creator ).toEqual( {
        type: types.SET_EDIT_CREDITCARD_DATA,
        data
      } )
    } );
  } );

  describe( 'Update Credit card', () => {

    it( 'The action type should exist', () => {
      expect( types.UPDATE_CREDIT_CARD ).toBe( 'CHECKOUT_PAGE::UPDATE_CREDIT_CARD' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.updateCreditCard ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const paymentFormValues= {
        paymentType: 'creditCard',
        creditCardNumber: '1234567891234567',
        expirationMonth: '',
        expirationYear: '',
        firstName: 'abc',
        lastName: 'bcd',
        phoneNumber: '(222) 222-2222',
        address1: 'abc ave',
        address2: 'bcd',
        cardVerificationNumber: '',
        city: 'abc',
        state: 'AB',
        postalCode: '22332',
        primary: undefined,
        creditCardType: 'Visa',
        sameAsShipping: false
      };
      const _dynSessConf = '12345';

      const creator = actions.updateCreditCard( _dynSessConf, paymentFormValues );
      expect( creator ).toEqual( {
        type: types.UPDATE_CREDIT_CARD,
        _dynSessConf,
        paymentFormValues
      } )
    } );
  } );

  describe( 'UPDATE_STATE_DROPDOWN_VALUE', () => {

    it( 'The action type should exist', () => {
      expect( types.UPDATE_STATE_DROPDOWN_VALUE ).toBe( 'CART_AND_CHECKOUT_APP::UPDATE_STATE_DROPDOWN_VALUE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.updateStateDropdownValue ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const form = jest.fn();
      const value = jest.fn();
      const creator = actions.updateStateDropdownValue( form, value );
      expect( creator ).toEqual( {
        type: types.UPDATE_STATE_DROPDOWN_VALUE,
        form,
        value
      } )
    } );
  } );

  describe( 'get paypal response', () => {

    it( 'The action type should exist', () => {
      expect( types.PAYPAL_RESPONSE ).toBe( 'CHECKOUT_PAGE::PAYPAL_RESPONSE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.getPaypalResponse ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const info = jest.fn();
      const creator = actions.getPaypalResponse( info );
      expect( creator ).toEqual( {
        type: types.PAYPAL_RESPONSE,
        info
      } )
    } );
  } );

  describe( 'Update Shipping status', () => {

    it( 'The action type should exist', () => {
      expect( types.UPDATE_SHIPPING_STATUS ).toBe( 'CHECKOUT_PAGE::UPDATE_SHIPPING_STATUS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.updateShippingStatus ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = 'Complete';
      const creator = actions.updateShippingStatus( data );
      expect( creator ).toEqual( {
        type: types.UPDATE_SHIPPING_STATUS,
        data
      } )
    } );
  } );

  describe( 'Set Shipping Error Message', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_SHIPPING_ERROR_MESSAGE ).toBe( 'CHECKOUT_PAGE::SET_SHIPPING_ERROR_MESSAGE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setShippingErrorMessage ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = {
        messageDesc: 'First name is invalid, please correct.',
        messageKey: 'ERR_SHIPPING_INVALID_FIRST_NAME',
        messageType: 'Error',
        messageRef: ''
      };

      const creator = actions.setShippingErrorMessage( data );
      expect( creator ).toEqual( {
        type: types.SET_SHIPPING_ERROR_MESSAGE,
        data
      } )
    } );
  } );

  describe( 'Update Payment Status', () => {

    it( 'The action type should exist', () => {
      expect( types.UPDATE_PAYMENT_STATUS ).toBe( 'CHECKOUT_PAGE::UPDATE_PAYMENT_STATUS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.updatePaymentStatus ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = 'success';
      const creator = actions.updatePaymentStatus( data );
      expect( creator ).toEqual( {
        type: types.UPDATE_PAYMENT_STATUS,
        data
      } )
    } );
  } );

  describe( 'Set Payment Type', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_PAYMENT_FORM_TYPE ).toBe( 'CHECKOUT_PAGE::SET_PAYMENT_FORM_TYPE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setPaymentType ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const paymentType = 'paypal';
      const creator = actions.setPaymentType( paymentType );
      expect( creator ).toEqual( {
        type: types.SET_PAYMENT_FORM_TYPE,
        paymentType
      } )
    } );
  } );

  describe( 'Set CreditCard Payment Type', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_CREDITCARD_PAYMENT_TYPE ).toBe( 'CHECKOUT_PAGE::SET_CREDITCARD_PAYMENT_TYPE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setCreditCardPaymentType ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = 'Ultamate Rewards Credit Card';
      const creator = actions.setCreditCardPaymentType( data );
      expect( creator ).toEqual( {
        type: types.SET_CREDITCARD_PAYMENT_TYPE,
        data
      } )
    } );
  } );

  describe( 'Set Creditcard Payment Form Submit', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_CC_PAYMENT_FORM_SUBMIT ).toBe( 'CHECKOUT_PAGE::SET_CC_PAYMENT_FORM_SUBMIT' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setCCPaymentFormSubmit ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = jest.fn();
      const creator = actions.setCCPaymentFormSubmit( data );
      expect( creator ).toEqual( {
        type: types.SET_CC_PAYMENT_FORM_SUBMIT,
        data
      } )
    } );
  } );

  describe( 'Set Payment CCV Number', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_TEMP_PAYMENT_CCV_NUMBER ).toBe( 'CHECKOUT_PAGE::SET_TEMP_PAYMENT_CCV_NUMBER' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setTempPaymentCCVNumber ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {

      const data = '111';

      const creator = actions.setTempPaymentCCVNumber( data );
      expect( creator ).toEqual( {
        type: types.SET_TEMP_PAYMENT_CCV_NUMBER,
        data
      } )
    } );
  } );

  describe( 'Reset Cart Merge', () => {

    it( 'The action type should exist', () => {
      expect( types.RESET_CART_MERGED ).toBe( 'CHECKOUT_PAGE::RESET_CART_MERGED' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.resetCartMerge ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = actions.resetCartMerge( );
      expect( creator ).toEqual( {
        type: types.RESET_CART_MERGED
      } )
    } );
  } );

  describe( 'Update Dav Popup', () => {

    it( 'The action type should exist', () => {
      expect( types.UPDATE_DAV_POPUP ).toBe( 'CHECKOUT_PAGE::UPDATE_DAV_POPUP' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.updateDavPopup ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = actions.updateDavPopup( );
      expect( creator ).toEqual( {
        type: types.UPDATE_DAV_POPUP
      } )
    } );
  } );

  describe( 'Change CreditCard', () => {

    it( 'The action type should exist', () => {
      expect( types.CHANGE_CREDIT_CARD ).toBe( 'CHECKOUT_PAGE::CHANGE_CREDIT_CARD' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.changeCreditCard ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = jest.fn();
      const creator = actions.changeCreditCard( data );
      expect( creator ).toEqual( {
        type: types.CHANGE_CREDIT_CARD,
        data
      } )
    } );
  } );

  describe( 'Reset Cart Page Navigation', () => {

    it( 'The action type should exist', () => {
      expect( types.RESET_CARTPAGE_NAVIGATION ).toBe( 'CHECKOUT_PAGE::RESET_CARTPAGE_NAVIGATION' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.resetCartPageNavigation ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = actions.resetCartPageNavigation( );
      expect( creator ).toEqual( {
        type: types.RESET_CARTPAGE_NAVIGATION
      } )
    } );
  } );

  describe( 'Reset Order Status', () => {

    it( 'The action type should exist', () => {
      expect( types.RESET_ORDER_STATUS ).toBe( 'CHECKOUT_PAGE::RESET_ORDER_STATUS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.resetOrderStatus ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = actions.resetOrderStatus( );
      expect( creator ).toEqual( {
        type: types.RESET_ORDER_STATUS
      } )
    } );
  } );

  describe( 'Toggle Input Field Shipping Display', () => {

    it( 'The action type should exist', () => {
      expect( types.TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY ).toBe( 'CHECKOUT_PAGE::TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.toggleInputFieldShippingDisplay ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = actions.toggleInputFieldShippingDisplay( );
      expect( creator ).toEqual( {
        type: types.TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY
      } )
    } );
  } );

  describe( 'Toggle InputField Payment Display', () => {

    it( 'The action type should exist', () => {
      expect( types.TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY ).toBe( 'CHECKOUT_PAGE::TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.toggleInputFieldPaymentDisplay ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = actions.toggleInputFieldPaymentDisplay( );
      expect( creator ).toEqual( {
        type: types.TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY
      } )
    } );
  } );

  describe( 'Is Coupon Button Clicked', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_IS_COUPON_BUTTON_CLICKED ).toBe( 'CHECKOUT_PAGE::SET_IS_COUPON_BUTTON_CLICKED' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.isCouponBtnClicked ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = 'true';
      const creator = actions.isCouponBtnClicked( data );
      expect( creator ).toEqual( {
        type: types.SET_IS_COUPON_BUTTON_CLICKED,
        data
      } )
    } );
  } );

  describe( 'toggle Security Code', () => {

    it( 'The action type should exist', () => {
      expect( types.TOGGLE_SECURITY_CODE_ICON ).toBe( 'CHECKOUT_PAGE::TOGGLE_SECURITY_CODE_ICON' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.toggleSecurityCode ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const status = 'true';
      const creator = actions.toggleSecurityCode( status );
      expect( creator ).toEqual( {
        type: types.TOGGLE_SECURITY_CODE_ICON,
        status
      } )
    } );
  } );
} );