/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 **/

import { combineReducers } from 'redux';
import has from 'lodash/has';
import {
  reducer as formReducer,
  actionTypes as formActionTypes
} from 'redux-form';

import global from 'shared/reducers/Global/Global.reducer';
import session from 'shared/reducers/Session/Session.reducer';
import user from 'shared/reducers/User/User.reducer';
import language from 'shared/reducers/Language/Language.reducer';
import header from 'hf/reducers/Header/Header.reducer';
import footer from 'hf/reducers/Footer/Footer.reducer';
import esu from 'esu/reducers/EmailSignUp/EmailSignUp.reducer';
import minicart from 'hf/reducers/MiniCart/MiniCart.reducer';
import typeaheadsearch from 'hf/reducers/TypeAheadSearch/TypeAheadSearch.reducer';
import mobileLeftNav from 'hf/reducers/MobileLeftNav/MobileLeftNav.reducer';
import pagedata from 'shared/reducers/Page/Page.reducer';
import checkoutPage from 'ccr/reducers/CheckoutPage/CheckoutPage.reducer';
// import reducers that are globally required in the ULTA app

export const removeUnregisteredFormValue  = ( state, action )=> {
  if( action.type !== formActionTypes.UNREGISTER_FIELD ){
    return state;
  }

  const { values: { [action.payload.name]: unregistered, ...values } } = state
  return { ...state, values }

}

export default ( asyncReducers ) => {
  return combineReducers( {
    global,
    session,
    user,
    language,
    header,
    footer,
    esu,
    minicart,
    mobileLeftNav,
    typeaheadsearch,
    pagedata,
    checkoutPage,
    form: formReducer,
    ...asyncReducers
  } )

}
