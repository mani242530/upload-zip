import CONFIG from 'ccr/ccr.config';
import { fork } from 'redux-saga/effects';

import loadCart from 'ccr/sagas/LoadCart/LoadCart.sagas';
import gwp from 'ccr/sagas/GWP/Gwp.sagas';
import productCellSaga from 'ccr/sagas/ProductCell/ProductCell.sagas';
import productSamplesSaga from 'ccr/sagas/ProductSamples/ProductSamples.sagas';
import giftWrapSaga from 'ccr/sagas/GiftWrap/GiftWrap.sagas';
import productRecsSaga from 'ccr/sagas/ProductRecs/ProductRecs.sagas';
import coupon from 'ccr/sagas/Coupons/Coupon.sagas';
import checkout, { ccrRedirects } from 'ccr/sagas/Checkout/Checkout.sagas';
import readCart from 'ccr/sagas/ReadCart/ReadCart.sagas';
import creditCardPayment from 'ccr/sagas/CreditCardPayment/CreditCardPayment.sagas';
import shippingUpdate from 'ccr/sagas/ShippingUpdate/ShippingUpdate.sagas';
import addressbook from 'ccr/sagas/AddressBook/AddressBook.sagas';
import getQualifiedShipMethod from 'ccr/sagas/GetQualifiedShipMethod/GetQualifiedShipMethod.sagas';
import profileCreditCards from 'ccr/sagas/ProfileCreditCards/ProfileCreditCards.sagas';
import redeemPoints from 'ccr/sagas/RedeemPoints/RedeemPoints.sagas';
import paymentServiceResponse from 'ccr/sagas/PaymentService/PaymentService.sagas';
import rewardsLookup from 'ccr/sagas/RewardsLookUp/RewardsLookUp.sagas';
import applyPayment from 'ccr/sagas/ApplyPayment/ApplyPayment.sagas';
import submitOrderService from 'ccr/sagas/SubmitOrderService/SubmitOrderService.sagas';
import applyExpressPayment from 'ccr/sagas/ApplyExpressPayment/ApplyExpressPayment.sagas';
import estimatedDeliveryDate from 'ccr/sagas/estimatedDeliveryDate/estimatedDeliveryDate.sagas';
import RealtimeOLPS from 'abuy/sagas/RealtimeOLPS/RealtimeOLPS.sagas';
import userRewards from 'ccr/sagas/UserRewards/UserRewards.sagas';
import PaypalToken from 'ccr/sagas/PaypalToken/PaypalToken.sagas';

import searchtypeaheadsaga from 'hf/sagas/SearchTypeAhead/SearchTypeAhead.sagas';

import sessionsaga, { sessionManager } from 'shared/sagas/Session/Session.sagas';
import usersaga from 'shared/sagas/User/User.sagas';
import profilesaga from 'shared/sagas/Profile/Profile.sagas';
import loginsaga from 'shared/sagas/Login/Login.sagas';
import navigationsaga from 'shared/sagas/Navigation/Navigation.sagas';
import pagesaga from 'shared/sagas/Page/Page.sagas';
import switches from 'shared/sagas/Switches/Switches.sagas';
import analyticssaga from 'shared/sagas/Analytics/Analytics.sagas';
import logout from 'shared/sagas/Logout/Logout.sagas';


// All sagas to be loaded
// sessionSAGA must be the first in the list
export default function*(){
  yield[
    // SHARED Module
    fork( sessionManager ),
    fork( analyticssaga ),
    fork( sessionsaga( CONFIG ) ),
    fork( usersaga( CONFIG ) ),
    fork( profilesaga ),
    fork( loginsaga ),
    fork( navigationsaga ),
    fork( pagesaga ),
    fork( switches( CONFIG ) ),

    fork( logout ),

    // Header Footer Module
    fork( searchtypeaheadsaga ),

    // CCR Module
    fork( loadCart( CONFIG ) ),
    fork( gwp ),
    fork( productCellSaga ),
    fork( productSamplesSaga ),
    fork( giftWrapSaga ),
    fork( productRecsSaga ),
    fork( coupon ),
    fork( checkout ),
    fork( ccrRedirects ),
    fork( readCart ),
    fork( creditCardPayment ),
    fork( shippingUpdate ),
    fork( addressbook ),
    fork( getQualifiedShipMethod ),
    fork( profileCreditCards ),
    fork( redeemPoints ),
    fork( paymentServiceResponse ),
    fork( rewardsLookup ),
    fork( applyPayment ),
    fork( submitOrderService ),
    fork( applyExpressPayment ),
    fork( estimatedDeliveryDate ),
    fork( userRewards ),
    fork( RealtimeOLPS ),
    fork( PaypalToken )
  ]
}
