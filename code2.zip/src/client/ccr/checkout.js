/**
 * cart.js
 *
 * this is the entry file for the cart application
 *
 */

// Needed for redux-saga es6 generator support
import 'babel-polyfill';
import 'shared/theme/theme.css';

// ReactJS specific imports
import React from 'react';
import { renderComponent } from 'utils/ReactDOM/rendering';
import shimReady from 'static/js/shim';


// Redux specific imports
import { Provider } from 'react-redux';

// i18n (internationalization) imports
import LanguageProvider from 'shared/components/LanguageProvider/LanguageProvider';

// Application component imports
import Global from 'shared/components/Global/Global';
import Header from 'hf/components/Header/Header';
import Footer from 'hf/components/Footer/Footer';
import LeftNav from 'hf/components/LeftNav/LeftNav';
import { translationMessages } from 'shared/components/LanguageProvider/i18n';
import configureStore from 'ccr/ccr.store';
import CheckoutPage from 'ccr/components/CheckoutPage/CheckoutPage';

import { initialState as footerInitialState } from 'hf/reducers/Footer/Footer.reducer';
import { initialState as headerInitialState } from 'hf/reducers/Header/Header.reducer';

import {
  loadState,
  saveState
} from 'utils/LocalStorage/LocalStorage';
import throttle from 'lodash/throttle';

import CONFIG from 'ccr/ccr.config';

import { setConfig } from 'utils/Ajax/Ajax';
setConfig( CONFIG );

let persistedState = loadState();
// set the displaymodes for the header and footer
persistedState = {
  ...persistedState,
  header:{
    ...headerInitialState,
    mobileHeaderDisplayMode: 'focused',
    desktopHeaderDisplayMode: 'focused'
  },
  footer:{
    ...footerInitialState,
    mobileFooterDisplaymode: 'customerService',
    desktopFooterDisplaymode: 'customerService'
  }
}
const store = configureStore( persistedState, CONFIG );

store.subscribe( () => {
  let state = store.getState();

  saveState( {
    session: state.session,
    // To fix the sticky footer displayed multiple times in same session when switching between REACT page because SFD (Sticky Footer Displayed) session cookie is deleted or not persisting
    // To save & restore emailSignUp sfd session cookie
    emailSignUp: state.esu.stickyEmailSignUp.sessionData
  } );
} );

export const render = ( messages ) => {

  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Global isCheckoutPage={ true }/>
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-global' )
  );


  // HEADER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Header />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileHeader' )
  );

  // LEFTNAV
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <LeftNav />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileNav' )
  );


  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <CheckoutPage />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-checkout' )
  );


  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Footer />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileFooter' )
  );


}

// Hot reloadable translation json fiels
if( module.hot ){
  // modules.hot.accept does not accept dynamic dependencies,
  // have to be constants at compile-time
  module.hot.accept( 'shared/components/LanguageProvider/i18n', () => {
    render( translationMessages );
  } );
}

// new polyfill for browsers without Intl support
shimReady( () => {
  render( translationMessages )
} );
