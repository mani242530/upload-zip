import React from 'react';
import PropTypes from 'prop-types';
import './AddressCard.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './AddressCard.messages';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';
import RadioButton from 'shared/components/RadioButton/RadioButton';
import 'shared/components/Gutter/Gutter.css';


const propTypes = {
  selectShippingAddress: PropTypes.func,
  editShippingAddress: PropTypes.func
}


const AddressCard = ( props ) => {

  /**
   * Create a AddressCard
   */
  const {
    index,
    refId,
    isDefault,
    isSelected,
    firstName,
    lastName,
    address1,
    address2,
    city,
    state,
    postalCode,
    phoneNumber
  } = props;




  const updateAddressValue = ( e ) => {
    if( props.selectShippingMethod ){
      props.selectShippingMethod( e.target.value );
    }
    else {
      props.handleDoneShippingAddress( e.target.value );
    }
  }

  const editAddress = () => {
    if( props.editShippingAddress ){
      props.editShippingAddress( props );
    }
  }

  /**
   * Renders the AddressCard component
   */

  return (
    <div className='AddressCard Gutter'>
      <RadioButton
        id={ refId + '-' + index }
        name='changeShippingAddress'
        value={ refId }
        isChecked={ isSelected === true }
        onClick={ updateAddressValue }
      >
        <div className='AddressCard__Item'>
          <div className='AddressCard__Item--bold'>
            <span>{ firstName }</span>
            <span> { lastName }</span>
            { ( () => {
              try {
                if( isDefault ){
                  return (
                    <span> (Primary)</span>
                  );
                }
              }
              catch ( e ){
              }
            } )() }
          </div>

          <div className='AddressCard__Item--normal'>
            <span>{ address1 }</span>
            { ( () => {
              try {
                if( address2 !== null && address2 !== '' ){
                  return (
                    <span> { address2 }</span>
                  );
                }
              }
              catch ( e ){
              }
            } )() }
            <span>, { city }</span>
            <span> { state }</span>
            <span> { postalCode }</span>
            <div> { phoneNumber } </div>
          </div>
        </div>
      </RadioButton>
      <div className='AddressCard__Item--bottom'>
        <div className='AddressCard__line'>
          <Divider dividerType={ 'gray' } />
        </div>
        <div className='AddressCard__Item--normal AddressCard__Item--data'>
          <Anchor
            url='#'
            clickHandler={ editAddress }
            ariaLabel={ formatMessage( messages.edit ) + ' ' + address1 + ' ' + formatMessage( messages.address ) }
            title={ formatMessage( messages.edit ) + ' ' + address1 + ' ' + formatMessage( messages.address ) }
          >
            { formatMessage( messages.edit ) }
          </Anchor>
        </div>
      </div>

    </div>
  );
}

AddressCard.propTypes = propTypes;

export default AddressCard;
