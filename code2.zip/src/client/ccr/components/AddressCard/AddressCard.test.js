import React from 'react';
import ReactDOM from 'react-dom';
import AddressCard from './AddressCard';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './AddressCard.messages';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import { reduxForm } from 'redux-form';

const Decorator=reduxForm( { form:'testForm' } )( AddressCard );
describe( '<AddressCard />', () => {
  let component;
  let props = {
    address: {
      contactInfo: {
        address1: '2491 Warm Springs Lane',
        city :'Naperville',
        firstName:'',
        lastName:'Muller',
        phoneNumber:'510-213-8348',
        postalCode:'60564',
        state:'IL'
      },
      isDefault:false,
      isSelected:true
    },
    refId: 'forRadioButtonValue'
  };
  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'AddressCard' ).length ).toBe( 1 );
  } );
  it( 'renders without crashing', () => {
    expect( component.find( 'RadioButton' ).length ).toBe( 1 );
  } );
  it( 'renders without crashing', () => {
    expect( component.find( '.AddressCard__Item--bold' ).length ).toBe( 1 );
  } );
  it( 'renders without crashing', () => {
    expect( component.find( '.AddressCard__Item--normal' ).length ).toBe( 2 );
  } );
  it( 'renders without crashing', () => {
    expect( component.find( 'Divider' ).length ).toBe( 1 );
  } );
  it( 'renders without crashing', () => {
    let text=messages.edit.defaultMessage;
    expect( component.find( '.AddressCard__Item--data' ).text() ).toBe( text );
  } );
  it( 'Invokes selectShippingMethod on click of RadioButton', () => {
    const selectShippingMethod = jest.fn( ) ;
    props.selectShippingMethod = selectShippingMethod ;
    const component =  mountWithIntl(
      <Provider store={ store }>
        <Decorator { ...props }/>
      </Provider>
    );
    const node = component.find( 'AddressCard' );
    component.find( 'RadioButton' ).find( 'input' ).simulate( 'click' );
    expect( selectShippingMethod ).toBeCalled();
  } );
  it( 'Invokes handleDoneShippingAddress on click of RadioButton if selectShippingMethod is not defined', () => {
    const handleDoneShippingAddress = jest.fn();
    const props1 = {
      address: {
        contactInfo: {
          address1: '2491 Warm Springs Lane',
          city :'Naperville',
          firstName:'',
          lastName:'Muller',
          phoneNumber:'510-213-8348',
          postalCode:'60564',
          state:'IL'
        },
        isDefault:false,
        isSelected:true
      },
      refId: 'forRadioButtonValue',
      handleDoneShippingAddress : handleDoneShippingAddress
    }
    const component1 =  mountWithIntl(
      <Provider store={ store }>
        <Decorator { ...props1 }/>
      </Provider>
    );
    component1.find( 'RadioButton' ).find( 'input' ).simulate( 'click' );
    expect( handleDoneShippingAddress ).toBeCalled();
  } );
  it( 'Invokes editShippingAddress on click of Anchor ', () => {
    const editShippingAddress = jest.fn( ) ;
    props.editShippingAddress = editShippingAddress ;//eslint-disable-line
    const component =  mountWithIntl(
      <Provider store={ store }>
        <Decorator { ...props }/>
      </Provider>
    );
    const node = component.find( 'AddressCard' );
    component.find( 'Anchor' ).simulate( 'click' );
    expect( editShippingAddress ).toBeCalled();
  } );
} );
