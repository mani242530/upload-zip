import React from 'react';
import PropTypes from 'prop-types';
import { findKey, values } from 'lodash';
import './BfxProductCellItem.css';

const propTypes = {
  index: PropTypes.number,
  skuId: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  productName: PropTypes.string,
  productImageUrl: PropTypes.string,
  productURL: PropTypes.string,
  quantity: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  price: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  variantInfo: PropTypes.object
}

const BfxProductCellItem = ( props ) => {
  /*
    Global Shipping - Implmentation of divs to be consumed by BorderFree.
    The following divs should be hidden always.
    BorderFree will process divs starting with 'bfx-' and these should not be visible.
  */
  let classNameBfxProductCellItem = `itemPrice${props.index+1} hidden bfx-product BfxProductCellItem__hideDiv`;
  return (
    <div
      className={ classNameBfxProductCellItem }
      key={ props.index }
    >
      <span className='bfx-sku-id'>{ props.skuId }</span>
      <span className='bfx-product-name'>{ props.productName }</span>
      <span className='bfx-product-image-url'>{ props.productImageUrl }</span>
      <span className='bfx-product-url'>{ props.productURL }</span>
      <span className='bfx-qty'>{ props.quantity }</span>
      <span className='bfx-price'>{ props.price }</span>
      { ( ()=>{
        if( props.variantInfo ){
          return ( <span className='bfx-product-option-label'>{ findKey( props.variantInfo ) }</span> );
        }
      } )() }
      { ( ()=>{
        if( props.variantInfo ){
          return ( <span className='bfx-product-option-value'>{ values( props.variantInfo ) [0] }</span> );
        }
      } )() }
    </div>
  );
}
BfxProductCellItem.propTypes = propTypes;

export default BfxProductCellItem;
