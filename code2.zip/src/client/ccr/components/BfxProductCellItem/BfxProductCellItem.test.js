import React from 'react';
import ReactDOM from 'react-dom';
import BfxProductCellItem from './BfxProductCellItem';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

describe( '<BfxProductCellItem />', () => {
  let component;
  let props = {
    couponApplied: false,
    brandName: 'Cargo',
    quantity: 3,
    productId: 'xlsImpprod1380016',
    excludedFromCoupon: false,
    adbugMessageMap: {
      adbugMessag: 'Buy 2, get 1 off!  Add 3 items to qualify!',
      promoUrl: 'https://qa2.ulta.com/ulta/promotion/buy-more-save-more/detail/0000012352'
    },
    catalogRefId: '2208100',
    categoryName: 'Mascara',
    discountMessage: 'Discount Applied',
    errorMsg: '',
    commerceItemid: 'ci15593000751',
    priceInfo: {
      salePrice: '$40.00',
      regularPrice: '$60.00',
      bfxPriceMap: [
        {
          bfxQty: '1',
          bfxPrice: 0
        },
        {
          bfxQty: '2',
          bfxPrice: 20
        }
      ],
      unitPriceMessage: '1 for FREE, 2 @ $20.00'
    },
    productDisplayName: 'Online Only TexasLash Mascara',
    imageURL: 'https://images.ulta.com/is/image/Ulta/2208100?$md$',
    variantInfo: {
      Color: 'Black'
    },
    skuDisplayName: 'Online Only TexasLash Mascara',
    shippingRestriction: null,
    maxQty: 10,
    productURL: '/texaslash-mascara?productId=xlsImpprod1380016&sku=2208100'
  };

  it( 'renders without crashing', () => {
    component = mountWithIntl( <BfxProductCellItem item={ props } /> );
    expect( component.find( 'BfxProductCellItem' ).length ).toBe( 1 );
  } );

  it( 'should display price', () => {
    component = mountWithIntl( <BfxProductCellItem item={ props } /> );
    expect( component.find( '.bfx-price' ).length ).toBe( 1 );
  } );

  it( 'should display product option label', () => {
    props.variantInfo = { Color: 'Black' };
    component = mountWithIntl( <BfxProductCellItem { ...props } /> );
    expect( component.find( '.bfx-product-option-label' ).length ).toBe( 1 );
  } );

  it( 'should display product option value', () => {
    props.variantInfo = { Color: 'Black' };
    component = mountWithIntl( <BfxProductCellItem { ...props } /> );
    expect( component.find( '.bfx-product-option-value' ).length ).toBe( 1 );
  } );
} );
