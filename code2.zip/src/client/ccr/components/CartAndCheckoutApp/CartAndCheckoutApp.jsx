/**
 * CartAndCheckoutApp
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import classNames from 'classnames';
import Spinner from 'shared/components/Icons/spinner';
import './CartAndCheckoutApp.css';
import {
  createScriptTag
} from 'utils/3rdPartyScripts/3rdPartyScripts';

import MetaData from 'shared/components/MetaData/MetaData';
import {
  actions,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';
import {
  actions as miniCartActions
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  Redirect,
  Route,
  Switch
} from 'react-router-dom';


import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';


import {
  actions as userActions
} from 'shared/actions/User/User.actions';

import BaseLayout from 'shared/components/BaseLayout/BaseLayout';
import Gutter from 'shared/components/Gutter/Gutter';
import CartPage from 'ccr/components/CartPage/CartPage';
import CheckoutPage from 'ccr/components/CheckoutPage/CheckoutPage';
import EmptyBag from 'ccr/components/EmptyBag/EmptyBag';
import isUndefined from 'lodash/isUndefined';
import { scrollWindowToPosition } from 'utils/Animation/Animation';

/**
 * Class
 * @extends React.Component
 */
class CartAndCheckoutApp extends Component{

  /**
   * Renders the CartAndCheckoutApp component
   */
  componentDidUpdate( prevProps ){



    // load mooveweb when the switch data is available
    if( !isUndefined( this.props.switchData ) && isUndefined( prevProps.switchData ) ){
      const {
        switchData: { switches }
      } = this.props;
      if( switches.enableMoovweb ){
        createScriptTag( 'MoovWebScript', switches.moovWebScriptURL );
      }
    }

    // if the sessionmanger had determined that the session isn't active redirect the user
    if( isUndefined( this.props.activeSession ) && prevProps.activeSession ){

      if( isUndefined( this.props.isSignedIn ) && prevProps.isSignedIn === true ){
        this.props.history.push( '/bag/login', {
          sessionTimeoutDisplay: true
        } );
      }
      else {
        // for a non signed in user we do not need to show the sessionTimeoutDisplay since they can't
        // pickup where they left off since the items in teh cart are 100% lost
        this.props.history.push( '/bag/login' );
      }
    }

  }

  componentDidMount(){
    // event listeners for the model window for realtime on checkoutpage
    document.addEventListener( 'QUBIT::PREAPPROVED_FLOW_ACCEPT', ( e ) => {
      this.props.submitRealtimeResponse( e );
    } );

    document.addEventListener( 'QUBIT::PREAPPROVED_FLOW_DECLINE', ( e ) => {
      this.props.submitRealtimeResponse( e )
    } );

    // this listener is added here to make sure we know which among model, footer, header is dispalyed to the user before we actually update the
    // data layer for omniture and fire event.
    document.addEventListener( 'QUBIT_DISPLAY_TYPE', ( e ) => {
      const omnitureData = {
        'globalPageData': {
          'navigation': {
            'location': 'checkout'
          }
        }
      }
      const omnitureEvt = {
        'name': 'creditCardPrescreenOfferOverlay',
        'data': {
          'methodOfPresentedOfferkey': e.detail.displayType
        }
      }
      this.props.setDataLayer( omnitureData, omnitureEvt );
    } );
  }

  componentWillUnmount(){
    document.removeEventListener( 'QUBIT::PREAPPROVED_FLOW_ACCEPT' );
    document.removeEventListener( 'QUBIT::PREAPPROVED_FLOW_DECLINE' );
    document.removeEventListener( 'QUBIT_DISPLAY_TYPE' );
  }


  render(){
    const bagQuantity =  parseInt( this.props.quantity, 10 );
    // in order to render the application we need to make sure that we have
    // gathered the sessionID from the token service as well as the cart data
    // from the profile lite service. By default isSignedIn is undefined until the profile
    // lite service has responded, so we are checking to make sure that we got a response
    // from the profile lite service by checking the isSignedIn flag

    if( !isUndefined( this.props.activeSession ) && !isUndefined( this.props.isSignedIn ) && !isNaN( bagQuantity ) ){
      return (
        <div className={
          classNames( {
            'CartAndCheckoutApp': true,
            'CartAndCheckoutApp--noLeftNav': this.props.desktopHeaderDisplayMode === 'focused'
          } )
        }
        >
          <Switch>
            <Route
              path='/bag'
              exact
              render={
                ( props ) =>{

                  return (
                    <div className='bagPage'>
                      <MetaData
                        analyticsPageName={ 'bag' }
                        title={ 'Bag | Cosmetics, Fragrance, Skincare and Beauty Gifts' }
                        analyticsPageChannel='checkout'
                        analyticsPageType='bag'
                        setDataLayer={ this.props.setDataLayer }
                        firePageNavEvent={ false }
                        noFollow={ true }
                        headerDisplayConfig={
                          {
                            mobileHeaderDisplayMode: 'no_search',
                            desktopHeaderDisplayMode: 'default'
                          }
                        }
                        footerDisplayConfig={
                          {
                            mobileFooterDisplayMode: 'customerService',
                            desktopFooterDisplayMode: 'default'
                          }

                        }
                      >
                        <BaseLayout
                          hasLeftNav={ false }
                          containerMarginTop={ '100px' }
                          { ...this.props }
                        >

                          {
                            ( ()=>{
                              if( !isUndefined( this.props.quantity ) ){
                                return (
                                  <CartPage
                                    { ...props }
                                    itemCount={ parseInt( this.props.quantity, 10 ) }
                                    sessionID={ this.props.sessionID }
                                  />
                                )
                              }
                            } )()
                          }


                        </BaseLayout>

                      </MetaData>
                    </div>
                  );
                }
              }
            />

            <Route
              exact
              path='/bag/empty'
              render={
                ( props ) =>{
                  return (
                    <div className='EmptyBagPage'>
                      <MetaData
                        analyticsPageName='empty bag'
                        analyticsPageChannel='checkout'
                        analyticsPageType='bag'
                        setDataLayer={ this.props.setDataLayer }
                        firePageNavEvent={ false }
                        noFollow={ true }
                        headerDisplayConfig={
                          {
                            mobileHeaderDisplayMode: 'no_search',
                            desktopHeaderDisplayMode: 'default'
                          }
                        }
                        footerDisplayConfig={
                          {
                            mobileFooterDisplayMode: 'customerService',
                            desktopFooterDisplayMode: 'default'
                          }
                        }
                      >
                        <div className='CartPage'>
                          <BaseLayout
                            hasLeftNav={ false }
                            containerMarginTop={ '100px' }
                            { ...this.props }
                          >

                            <EmptyBag
                              { ...props }
                              { ...this.props }
                              bagQuantity={ bagQuantity }
                              isSignedIn={ this.props.isSignedIn }
                              displayType={ this.props.displayType }
                              cartPageData={ this.props.cartPageData ? this.props.cartPageData : {} }
                              recommendedProducts={ this.props.recommendedProducts ? this.props.recommendedProducts : {} }
                            />

                          </BaseLayout>

                        </div>
                      </MetaData>
                    </div>
                  )
                }
              }
            />

            <Route
              exact
              path='/bag/login'
              render={
                ( props ) => {
                  return (
                    <div className='bagPageLogin'>
                      <MetaData
                        analyticsPageName='empty bag'
                        setDataLayer={ this.props.setDataLayer }
                        analyticsPageChannel='checkout'
                        analyticsPageType='bag'
                        firePageNavEvent={ false }
                        noFollow={ true }
                        headerDisplayConfig={
                          {
                            mobileHeaderDisplayMode: 'no_search',
                            desktopHeaderDisplayMode: 'default'
                          }
                        }
                        footerDisplayConfig={
                          {
                            mobileFooterDisplayMode: 'customerService',
                            desktopFooterDisplayMode: 'default'
                          }
                        }
                      >
                        <div className='CartPage'>
                          <BaseLayout
                            hasLeftNav={ false }
                            containerMarginTop={ '100px' }
                            { ...this.props }
                          >

                            <EmptyBag
                              { ...props }
                              { ...this.props }
                              bagQuantity={ bagQuantity }
                              isSignedIn={ this.props.isSignedIn }
                              userName={ this.props.userName }
                              displayType={ this.props.displayType }
                              cartPageData={ this.props.cartPageData ? this.props.cartPageData : {} }
                              recommendedProducts={ this.props.recommendedProducts ? this.props.recommendedProducts : {} }
                            />

                          </BaseLayout>

                        </div>
                      </MetaData>
                    </div>
                  )
                }
              }
            />

            <Route
              exact
              path='/checkout'
              render={
                ( props ) =>{
                  return (
                    <div className='checkoutPage'>
                      <BaseLayout
                        className='Gutter'
                        hasLeftNav={ false }
                        containerMarginTop={ '50px' }
                        { ...this.props }
                      >
                        <CheckoutPage { ...props } />
                      </BaseLayout>
                    </div>
                  )
                }
              }
            />
          </Switch>
        </div>

      );
    }
    else {
      return (
        <div className='CartAndCheckoutApp'>
          <div className='CartAndCheckoutApp--spinner_loading'>
            <Spinner loaderType='spinner'/>
          </div>
        </div>
      )
    }

  }
}

export const mapStateToProps = ( state ) =>{
  return {
    ...state.pagedata,
    ...state.minicart,
    ...state.user,
    ...state.global,
    ...state.header,
    ...state.session,
    ...state.pagedata.creditcards
  };
}

export const mapDispatchToProps = ( dispatch ) =>{
  return {
    setDataLayer: ( data, evt ) =>{
      dispatch( dataLayerActions.setDataLayer( data, evt ) );
    },
    loadCart: ( data ) =>{
      dispatch( getActionDefinition( 'loadCart', 'requested' )( data ) );
    },
    getProfileData: ( data ) => {
      dispatch( getActionDefinition( 'profile', 'requested' )( data ) );
    },
    resetLogoutFlag: () => {
      dispatch( userActions.resetLogoutFlag( ) );
    },

    hideOutOfStockItems: () =>{
      dispatch( miniCartActions.hideOutOfStockItems() );
    },
    setChkoutBtnStatus: ( status ) => {
      dispatch( miniCartActions.setChkoutBtnStatus( status ) );
    },
    handleScrollView: ( el ) =>{
      let elem = document.getElementById( el );
      scrollWindowToPosition( elem.offsetTop - 30, 'easeInOutQuint' );
    },
    submitRealtimeResponse: ( data ) => {
      dispatch( getActionDefinition( 'QubitRealtimeEvent', 'requested' )( data ) )
    }
  }
}

// this is to mock the data for test cases
export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( CartAndCheckoutApp ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );