import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { initialState } from 'hf/reducers/MiniCart/MiniCart.reducer';
import { MemoryRouter } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import CartAndCheckoutApp, { connectFunction, mapStateToProps, mapDispatchToProps } from './CartAndCheckoutApp';
import {
  getActionDefinition,
  registerServiceName
} from 'shared/actions/Services/Services.actions';

import {
  actions as userActions
} from 'shared/actions/User/User.actions';

import {
  actions as miniCartActions
} from 'hf/actions/MiniCart/MiniCart.actions';

const store = configureStore( {}, CONFIG );

let props = {
  userDataLoaded: true,
  quantity: 2,
  isSigneIn: true
}

const setDataLayerMock = jest.fn();
const submitRealtimeResponseMock =jest.fn();
let mapDispatchToPropsMock = ( dispatch ) =>{
  return {
    setDataLayer: setDataLayerMock,
    submitRealtimeResponse :submitRealtimeResponseMock
  }
}
let component = mountWithIntl(
  <Provider store={ store }>
    <CartAndCheckoutApp { ...props }/>
  </Provider>
);

describe( '<CartAndCheckoutApp />', () => {
  it( 'renders without crashing', () => {
    expect( component.find( 'CartAndCheckoutApp' ).length ).toBe( 1 );
  } );
  it( 'should take to home page if the cart count is 0 and user is trying to access CHeckoutPage directly', () => {
    expect( component.find( 'CartAndCheckoutApp' ).length ).toBe( 1 );
  } );

  it( 'should Invoke custom model event to accept method', () => {

    let CartAndCheckoutAppMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let component = mountWithIntl(
      <Provider store={ store }>
        <CartAndCheckoutAppMock { ...props }/>
      </Provider>
    );
    let evt = new CustomEvent( 'QUBIT_DISPLAY_TYPE', {
      detail:{
        displayType: 'modal'
      }
    } );
    document.dispatchEvent( evt );
    expect( setDataLayerMock ).toBeCalled();
  } );

  it( 'renders the CartPage component', () => {

    global.requestAnimationFrame = jest.fn();
    const component1 = createCartAndCheckoutAppComponent( '/bag' );
    const cartPage = component1.find( 'CartPage' );

    expect( cartPage.length ).toBe( 1 );

  } );

  it( 'renders the CheckoutPage component ', () => {

    window.requestAnimationFrame = jest.fn();
    const component2 = createCartAndCheckoutAppComponent( '/checkout' );
    const checkoutPage = component2.find( 'CheckoutPage' );

    expect( checkoutPage.length ).toBe( 1 );

  } );

  it( 'should contain Bag in the bagPage title', () => {

    const helmet = Helmet.peek();
    expect( helmet.title[0] ).toEqual( 'Bag | Cosmetics, Fragrance, Skincare and Beauty Gifts' );

  } );

  props.history ={ push:jest.fn() };
  const store1 = configureStore( {
    global:{
      switchData: {
        switches: {
          guestServiceHours: '7am-11pm',
          moovWebScriptURL : '/test',
          enableMoovweb : true
        }
      }
    },
    minicart:{
      ...initialState,
      quantity: 2
    },
    user: {
      isRewardsMember: true
    }
  }, CONFIG );
  component = mountWithIntl(
    <Provider store={ store1 }>
      <CartAndCheckoutApp { ...props }/>
    </Provider>
  );
  const instance = component.find( 'CartAndCheckoutApp' ).instance();

  it( 'should invoke componentDidUpdate for a non signed in user', () => {
    const prevProps={ activeSession: true };
    instance.componentDidUpdate( prevProps );
    expect( props.history.push ).toBeCalled();
  } );

  it( 'should invoke componentDidUpdate for a signed in user', () => {
    const prevProps={
      activeSession: true,
      isSignedIn:true
    };
    instance.componentDidUpdate( prevProps );
    expect( props.history.push ).toBeCalled();
  } );

  describe( '<CheckoutPage /> - MapDispatchToProps', () => {
    const store = configureStore( {}, CONFIG );
    const props = {
      checkoutPage: jest.fn(),
      user: jest.fn(),
      session: jest.fn(),
      pagedata:jest.fn(),
      minicart:jest.fn(),
      global:jest.fn()
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <CartAndCheckoutApp { ...props }/>
      </Provider>
    );
    const dispatch = jest.fn();
    beforeEach( ()=> {
      dispatch.mockClear();
    } )
    const mdp  = mapDispatchToProps( dispatch );

    it( 'loadCart should dispatch the proper action', () => {
      const data = jest.fn();
      registerServiceName( 'loadcart' );
      const event = mdp.loadCart( data );
      expect( dispatch ).toHaveBeenCalledWith(
        getActionDefinition( 'loadCart', 'requested' )( data )
      );
    } );

    it( 'getProfileData should dispatch the proper action', () => {
      const data = jest.fn();
      registerServiceName( 'profile' );
      const event = mdp.getProfileData( data );
      expect( dispatch ).toHaveBeenCalledWith(
        getActionDefinition( 'profile', 'requested' )( data )
      );
    } );

    it( 'resetLogoutFlag should dispatch the proper action', () => {
      const event = mdp.resetLogoutFlag();
      expect( dispatch ).toHaveBeenCalledWith(
        userActions.resetLogoutFlag()
      );
    } );

    it( 'hideOutOfStockItems should dispatch the proper action', () => {
      const event = mdp.hideOutOfStockItems();
      expect( dispatch ).toHaveBeenCalledWith(
        miniCartActions.hideOutOfStockItems()
      );
    } );

    it( 'setChkoutBtnStatus should dispatch the proper action', () => {
      const event = mdp.setChkoutBtnStatus();
      expect( dispatch ).toHaveBeenCalledWith(
        miniCartActions.setChkoutBtnStatus()
      );
    } );

    it( 'submitRealtimeResponse should dispatch the proper action', () => {
      const data = jest.fn();
      registerServiceName( 'QubitRealtimeEvent' );
      const event = mdp.submitRealtimeResponse( data );
      expect( dispatch ).toHaveBeenCalledWith(
        getActionDefinition( 'QubitRealtimeEvent', 'requested' )( data )
      );
    } );

    it( 'Should invoke submitRealtimeResponse on event : QUBIT::PREAPPROVED_FLOW_ACCEPT', () => {
      let evt = new CustomEvent( 'QUBIT::PREAPPROVED_FLOW_ACCEPT' );
      document.dispatchEvent( evt );
      expect( submitRealtimeResponseMock ).toBeCalled();
    } );

    it( 'Should invoke submitRealtimeResponse on event :QUBIT::PREAPPROVED_FLOW_DECLINE', () => {
      let evt = new CustomEvent( 'QUBIT::PREAPPROVED_FLOW_DECLINE' );
      expect( submitRealtimeResponseMock.mock.calls.length ).toBe( 1 );
      document.dispatchEvent( evt );
      expect( submitRealtimeResponseMock ).toBeCalled();
      expect( submitRealtimeResponseMock.mock.calls.length ).toBe( 2 );
    } );

    it( 'Should invoke removeEventListener on componentWillUnmount', () => {
      let removeEventListenerMock =jest.fn();
      document.removeEventListener = removeEventListenerMock;
      let node1 = component.find( 'CartAndCheckoutApp' ).instance();
      node1.componentWillUnmount();
      expect( removeEventListenerMock ).toBeCalled();
      expect( removeEventListenerMock.mock.calls.length ).toBe( 3 );
    } );

  } ) ;

} );

const createCartAndCheckoutAppComponent = ( pathname ) => {

  const store1 = configureStore( {
    global:{
      switchData: {
        switches: {
          guestServiceHours: '7am-11pm'
        }
      }
    },
    minicart:{
      ...initialState,
      quantity: 2
    },
    session:{
      activeSession: true
    },
    user: {
      isRewardsMember: true
    }
  }, CONFIG );
  const props = {
    userDataLoaded: true,
    isSignedIn: true,
    activeSession: true,
    quantity: 2
  }
  const component = mountWithIntl(
    <Provider store={ store1 }>
      <MemoryRouter initialEntries={ [{ pathname :pathname, state : { } }] }>
        <CartAndCheckoutApp { ...props } />
      </MemoryRouter>
    </Provider>
  );
  return component;
}
