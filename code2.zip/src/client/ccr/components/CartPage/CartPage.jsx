/**
 * CartPage
 **/

import React, { Component } from 'react';
import { connect } from 'react-redux';
import ProductSamples from 'ccr/components/ProductSamples/ProductSamples';
import './CartPage.css';
import OrderSummaryItem from 'ccr/components/OrderSummaryItem/OrderSummaryItem';
import GWPProductList from 'ccr/components/GWPProductList/GWPProductList';
import ProductRecs from 'ccr/components/ProductRecs/ProductRecs';
import HeaderBagSummary from 'ccr/components/HeaderBagSummary/HeaderBagSummary';
import Divider from 'shared/components/Divider/Divider';
import messages from './CartPage.messages';
import Button from 'shared/components/Button/Button';
import PaypalCheckoutButton from 'ccr/components/PaypalCheckoutButton/PaypalCheckoutButton';
import SVG from 'shared/components/Icons/lock';
import OutOfStockProductItems from 'ccr/components/OutOfStockProductItems/OutOfStockProductItems';
import ProductCellList from 'ccr/components/ProductCellList/ProductCellList';
import Coupons from 'ccr/components/Coupons/Coupons';
import isEmpty from 'lodash/isEmpty';
import isEqual from 'lodash/isEqual';
import isNull from 'lodash/isNull';
import find from 'lodash/find';
import GiftBox from 'ccr/components/GiftBox/GiftBox';
import Anchor from 'shared/components/Anchor/Anchor';
import { formatMessage } from 'shared/components/Global/Global';
import Spinner from 'shared/components/Icons/spinner';
import ShippingBanner from 'hf/components/Headers/shared/ShippingBanner/ShippingBanner';
import Sticker from 'react-stickyfill';
import FooterHelpText from 'hf/components/FooterHelpText/FooterHelpText';
import 'shared/components/Gutter/Gutter.css';
import classNames from 'classnames';
import UltamateRewardsCreditCard from 'ccr/components/UltamateRewardsCreditCard/UltamateRewardsCreditCard';
import {
  createScriptTag,
  removeScriptTag
} from 'utils/3rdPartyScripts/3rdPartyScripts';

import {
  actions as userActions
} from 'shared/actions/User/User.actions';

import {
  actions as miniCartActions
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  actions as checkoutPageActions
} from 'ccr/actions/CheckoutPage/CheckoutPage.actions'

import has from 'lodash/has';
import isUndefined from 'lodash/isUndefined';
import { scrollWindowToPosition } from 'utils/Animation/Animation';

export const mapStateToProps = ( state ) => {
  return {
    ...state.pagedata,
    ...state.global,
    ...state.minicart,
    ...state.checkoutPage,
    ...state.header,
    ...state.session,
    user: state.user
  };
}
export const mapDispatchToProps = ( dispatch ) => {
  return {
    setCartRightPanelCollapse: ( panelID ) => {
      dispatch( miniCartActions.setCartRightPanelCollapse( panelID ) );
    },
    getProfileData: ( data ) => {
      dispatch( getActionDefinition( 'profile', 'requested' )( data ) );
    },
    setGiftMessage: ( text ) => {
      dispatch( miniCartActions.setGiftMessage( text ) );
    },
    setGiftBoxToggleStatus: ( status ) => {
      dispatch( miniCartActions.setGiftBoxToggleStatus( status ) );
    },
    addToCart: ( item, history ) =>{
      dispatch( miniCartActions.addToCart( item, history ) );
    },
    selectGiftVariant: ( promotionid, skuid, history ) =>{
      dispatch( miniCartActions.selectGiftVariant( promotionid, skuid, history ) );
    },
    setChkoutBtnStatus: ( status ) => {
      dispatch( miniCartActions.setChkoutBtnStatus( status ) );
    },
    removeFromCart: ( item ) =>{
      dispatch( miniCartActions.removeFromCart( item ) );
    },
    removeGiftFromCart: ( item, history ) =>{
      dispatch( miniCartActions.removeGiftFromCart( item, history ) );
    },
    updateCart: ( item, quantity, history ) =>{
      dispatch( miniCartActions.updateCart( item, quantity, history ) );
    },
    couponCodeUpdated: ( item, history ) =>{
      dispatch( miniCartActions.couponCodeUpdated( item, history ) );
    },
    couponCodeRemoved: ( history ) =>{
      dispatch( miniCartActions.couponCodeRemoved( history ) );
    },
    setCouponOfferReqMet: ( status ) => {
      dispatch( miniCartActions.setCouponOfferReqMet( status ) );
    },
    setShowBagSummaryStatus: ( status ) => {
      dispatch( miniCartActions.setShowBagSummaryStatus( status ) );
    },
    setProductSample: ( catalogId ) => {
      dispatch( miniCartActions.setProductSample( catalogId ) );
    },
    selectProductSampleService: ( catalogID, quantity, history ) =>{
      dispatch( miniCartActions.selectProductSampleService( catalogID, quantity, history ) );
    },
    removeProductSampleService: ( history ) =>{
      dispatch( miniCartActions.removeProductSampleService( history ) );
    },
    setGiftWrapGiftNoteService: ( giftNote, history ) =>{
      dispatch( miniCartActions.setGiftWrapGiftNoteService( giftNote, history ) );
    },
    setGiftWrapGiftBoxService: ( giftboxStatus, history ) =>{
      dispatch( miniCartActions.setGiftWrapGiftBoxService( giftboxStatus, history ) );
    },
    initiateCheckout: ( data ) =>{
      dispatch( miniCartActions.initiateCheckout( data ) );
    },
    resetCheckoutEligibility: () => {
      dispatch( miniCartActions.resetCheckoutEligibility() );
    },
    getPaypalResponse: ( info ) => {
      dispatch( miniCartActions.getPaypalResponse( info ) );
    },
    applyExpressPayment: ( data ) => {
      dispatch( getActionDefinition( 'applyExpressPayment', 'requested' )( data ) );
    },
    resetCartMerge: () => {
      dispatch( checkoutPageActions.resetCartMerge() );
    },
    loadCart: ( data ) =>{
      dispatch( getActionDefinition( 'loadCart', 'requested' )( data ) );
    },
    applyExpressPaymentSameSession: ( data ) => {
      dispatch( getActionDefinition( 'applyExpressPaymentSameSession', 'requested' )( data ) );
    },
    hideOutOfStockItems: () => {
      dispatch( miniCartActions.hideOutOfStockItems() );
    },
    resetCartPageNavigation: () => {
      dispatch( checkoutPageActions.resetCartPageNavigation() )
    },
    getPaypalToken: ( ) =>{
      dispatch( getActionDefinition( 'paypalToken', 'requested' )() );
    },
    focusGiftBox: () => {
      dispatch( miniCartActions.focusGiftBox() );
    },
    blurGiftBox: () => {
      dispatch( miniCartActions.blurGiftBox() );
    }
  }
}

/**
 * Class
 * @extends React.Component
 */


export class CartPage extends Component{

  REFLEKTIONBEACON = 'refBeaconScriptUrl';
  REFLEKTIONREALTIME = 'refRealTime';

  constructor( props ){
    super( props );

    this.toggleBagSummary = this.toggleBagSummary.bind( this );
    this.gwpcheck = this.gwpcheck.bind( this );
    this.handleScrollView= this.handleScrollView.bind( this );
    this.button_func = this.button_func.bind( this );
  }

  componentDidMount(){
    this.props.setShowBagSummaryStatus();
    // if we have an active seesion when the component is mounteded go ahead and make the call to the loadCart svc
    this.props.loadCart( {
      history: this.props.history
    } );

    /**
     * Analytics code
     */
  }

  componentWillMount(){
    global.scrollTo( 0, 0 );
  }

  componentWillUnmount(){
    // remove the reflektion real-time script from the DOM here
    removeScriptTag( this.REFLEKTIONREALTIME );
  }

  handleScrollView( el ){
    let elem = document.getElementById( el );
    scrollWindowToPosition( elem.offsetTop - 30, 'easeInOutQuint' );
  }

  componentDidUpdate( prevProps ){

    if( this.props.navigateToCartPage ){
      this.props.resetCartPageNavigation();
    }

    if( this.props && this.props.eligibleForCheckout ){
      this.props.resetCheckoutEligibility();
    }
    // scroll the screen to the bag level error, when cases where there is a change in the messages/removedItems/updated value in the props
    if( ( has( this.props, 'cartPageData.messages.items' ) && ( !has( prevProps, 'cartPageData.messages.items' ) || !isEqual( this.props.cartPageData.messages.items, prevProps.cartPageData.messages.items ) ) ) ||
      ( has( this.props, 'cartPageData.removedItems' ) && ( !has( prevProps, 'cartPageData.removedItems' ) || !isEqual( this.props.cartPageData.removedItems, prevProps.cartPageData.removedItems ) ) ) ||
      ( has( this.props, 'cartPageData.updatedItems' ) && ( !has( prevProps, 'cartPageData.updatedItems' ) || !isEqual( this.props.cartPageData.updatedItems, prevProps.cartPageData.updatedItems ) ) ) ){
      this.handleScrollView( 'js-cartpage' );
    }
  }

  /**
   * Returns boolean
   * True - If all variants are selected
   * False - If a variant is not selected
   */
  checkForVariantsSelection( giftsData ){
    // Verify for Variant Selection before going to Checkout Page
    let isAllVariantsSelected = true;
    for ( let giftItem of giftsData ){
      if( giftItem && giftItem.indulge && giftItem.freeGifts && giftItem.freeGifts.items.length > 2 ){
        let selectedItemVals = giftItem.freeGifts.items.map( ( freeGift ) => freeGift.selected );
        // If any of the selected prop is not true then focus on the variant with error message
        if( selectedItemVals.indexOf( 'true' ) < 0 ){
          isAllVariantsSelected = false;
          break;
        }
      }
    }
    return isAllVariantsSelected;
  }

  /**
   * Renders the CartPage component
   */
  gwpcheck(){
    this.props.setChkoutBtnStatus( true );
    if( document.getElementById( 'Gifts' ) !== null && has( this.props, 'cartPageData.giftItems.items' ) && !this.checkForVariantsSelection( this.props.cartPageData.giftItems.items ) ){
      this.handleScrollView( 'Gifts' );
    }
    this.props.initiateCheckout( {
      history: this.props.history
    } );
  }

  toggleBagSummary( status ){
    // to toggle HeaderBagOrderSummary component
    this.props.setShowBagSummaryStatus( status );
  }

  button_func( val, tabIndex ){
    return (
      <div>
        <Button
          btnOption='single'
          inputTag='button'
          btnOutLine={ false }
          btnBlock={ true }
          btnSize={ 'lg' }
          tabIndex={ tabIndex }
          analyticsEvent={ {
            eventName: 'cartCheckoutButtonClick',
            data: ''
          } }
          clickEventHandler={ e => {
            this.gwpcheck();
            e.stopPropagation();
          } }
        >

          <span className='lock'>
            <SVG />
          </span>

          { val }


        </Button>
      </div>

    )
  }

  render(){

    const {
      cartDataAvailable,
      switchesDataAvailable
    } = this.props;
    const { ultamateRewardsCCInfo } = this.props.cartPageData;
    let checkout_message = formatMessage( messages.checkout );

    if( cartDataAvailable && switchesDataAvailable ){
      if( this.props.switchData.switches.enableReflektionTag && this.props.cartPageData.cartItems ){
        let skuIds = this.props.cartPageData.cartItems.items.filter( cartItem => cartItem.displayType !== 'removed' ).map( cartItem => cartItem.catalogRefId.toString() );

        createScriptTag(
          this.REFLEKTIONREALTIME,
          undefined,
          undefined,
          `
          var rfk = rfk || [];
          rfk.push({'product_ids': [${ '\'' + skuIds.join( '\',\'' ) + '\'' }] });
          `,
          this.REFLEKTIONBEACON
        );
      }
    }

    if( !cartDataAvailable && !switchesDataAvailable && isUndefined( this.props.quantity ) ){
      return (


        <div className='CartPage'>
          <div className='CartPage--spinner_loading'>
            <Spinner loaderType='spinner' />
          </div>
        </div>
      )
    }
    else {
      return (

        <div className='CartPage'>

          { ( () => {
            if( !this.props.isMobileDevice ){
              try {
                return (
                  <div className='CartPage__Right--header'>
                    <HeaderBagSummary
                      bagCount={ this.props.cartPageData.cartSummary.itemCount }
                      chevronStatus={ this.props.showBagSummary }
                      toggleChevronFunction={ this.props.setShowBagSummaryStatus }
                      chevronDisplay={ 'desktop' }
                      estimatedTotal={ this.props.cartPageData.cartSummary.estimatedTotal }
                    />
                  </div>
                )
              }
              catch ( e ){

              }

            }
            else if( !isUndefined( this.props.cartPageShippingBanner.message ) ){
              return (
                <ShippingBanner
                  message={ this.props.cartPageShippingBanner.message }
                  url={ this.props.cartPageShippingBanner.url }
                />
              )
            }
          } )() }
          { ( () => {
            if( this.props.itemCount && this.props.itemCount > 0 ){
              return (
                <div className='CartPage__Right CartPage__ContentContainer'>
                  <div className='CartPage__MainContainerLeftPanel'>
                    { ( () => {
                      if( !this.props.isMobileDevice ){
                        return (
                          <div className='CartPage__headerbag--divider'>
                            <Divider dividerType={ 'gray' }></Divider>
                          </div>
                        )
                      }
                    } )() }
                    { ( () => {
                      if( !isEmpty( this.props.cartPageData.giftItems ) ){
                        return (
                          <div className='CartPage__gwpmessage'>
                            <span className='CartPage__gwpmessage--title'>
                              { formatMessage( messages.gwpmessage ) }
                            </span>
                            <span className='CartPage__gwpmessage CartPage__gwpmessage--space'>\</span>
                            <span className='CartPage__gwpmessage CartPage__gwpmessage--addmessage'>
                              <Anchor url={ '#GiftAnchor' }>
                                { this.props.cartPageData.giftHeaderMessage }
                                <span className='CartPage__gwpmessage CartPage__gwpmessage--space'>
                                  { formatMessage( messages.addmessage ) }
                                </span>
                              </Anchor>
                            </span>
                          </div>
                        )
                      }
                    } )() }

                    { ( () => {
                      if( !isEmpty( this.props.cartPageData.messages ) || !isEmpty( this.props.cartPageData.removedItems ) || !isEmpty( this.props.cartPageData.updatedItems ) ){
                        return (
                          <OutOfStockProductItems
                            showPanel={ this.props.hideOOSPanel }
                            handleOutOfStock={ this.props.hideOutOfStockItems }
                            { ...( !isNull( this.props.cartPageData.messages ) && { 'messagesData' : this.props.cartPageData.messages.items } ) }
                            { ...( !isNull( this.props.cartPageData.removedItems ) && { 'removedItems' : this.props.cartPageData.removedItems } ) }
                            { ...( !isNull( this.props.cartPageData.updatedItems ) && { 'updatedItems' : this.props.cartPageData.updatedItems } ) }
                          />
                        );
                      }
                    } )() }


                    { ( () => {
                      if( this.props.isMobileDevice ){
                        try {

                          return (
                            <div className='CartPage__cartPageItems--headerBags Gutter'>
                              <div className='CartPage__cartPageItems--headerBag'>
                                <HeaderBagSummary
                                  bagCount={ this.props.cartPageData.cartSummary.itemCount }
                                  chevronStatus={ this.props.showBagSummary }
                                  toggleChevronFunction={ this.props.setShowBagSummaryStatus }
                                  chevronDisplay={ 'mobile' }
                                  estimatedTotal={ this.props.cartPageData.cartSummary.estimatedTotal }
                                />

                                <Divider dividerType={ 'gray' }></Divider>
                              </div>
                              {
                                ( () => {
                                  if( this.props.showBagSummary ){
                                    try {
                                      return (
                                        <OrderSummaryItem
                                          showBagSummary={ this.props.showBagSummary }
                                          itemCount={ this.props.cartPageData.cartSummary.itemCount }
                                          giftBoxPrice={ this.props.cartPageData.cartSummary.orderGiftWrapAmt }
                                          couponDiscountPrice={ this.props.cartPageData.cartSummary.couponDiscount }
                                          promotionalDiscountPrice={ this.props.cartPageData.cartSummary.additionalDiscount }
                                          shippingCost={ this.props.cartPageData.cartSummary.shippingCost }
                                          estimatedTax={ this.props.cartPageData.cartSummary.estimatedTax }
                                          estimatedTotal={ this.props.cartPageData.cartSummary.estimatedTotal }
                                          subTotalPrice={ this.props.cartPageData.cartSummary.subTotal }
                                          displayEstimatedTotal={ true }
                                          displayProductInfo={ true }
                                          orderId={ this.props.cartPageData.orderId }
                                        />
                                      );
                                    }

                                    catch ( e ){

                                    }
                                  }
                                } )()
                              }
                            </div>
                          )
                        }
                        catch ( e ){
                        }
                      }
                    } )() }
                    { ( () => {
                      if( this.props.cartPageData.cartItems ){
                        return (
                          <ProductCellList
                            productData={ this.props.cartPageData.cartItems.items.filter( cartItem => cartItem.displayType !== 'removed' ) }
                            displayProductInfo={ true }
                            showShippingRestrictionMsg={ this.props.cartPageData.showShippingRestrictionMsg }
                            { ...this.props }
                          />
                        );
                      }

                    } )() }
                    { ( () => {

                      try {
                        if( this.props.cartPageData.giftItems ){
                          return (
                            <div className='CartPage__gwpProductList Gutter'>
                              <GWPProductList
                                isMobileDevice={ this.props.isMobileDevice }
                                giftItems={ this.props.cartPageData.giftItems.items }
                                chkoutbtnClk={ this.props.chkoutbtnClk }
                                handleScrollView={ this.handleScrollView }
                                { ...this.props }
                              />
                            </div>
                          )
                        }
                      }
                      catch ( e ){
                      }
                    } )() }

                    { ( () => {
                      if( !this.props.isMobileDevice ){
                        // the div below is only used for Reflektion and must appear before CartPage__ProductRecs
                        // specific data attribute is also added to CartPage__ProductRecs if enabled is true
                        if( this.props.switchData.switches.enableReflektionTag ){
                          return ( <div data-rfkid='rfkid_4'></div> );
                        }
                      }
                    } )() }

                    { ( () => {
                      if( !this.props.isMobileDevice ){
                        if( !isEmpty( this.props.recommendedProducts ) ){
                          return (
                            <div
                              className='CartPage__ProductRecs'
                              data-rfkid={ ( this.props.switchData.switches.enableReflektionTag ) ? 'rfkid_x4' : null }
                            >
                              <ProductRecs
                                { ...this.props }
                                showOnlyListPrice={ true }
                                productRecList={ this.props.recommendedProducts }
                              />
                            </div>
                          );
                        }
                      }

                    } )() }
                  </div>

                  <div className='CartPage__MainContainerRightPanel'>
                    { ( () => {
                      if( this.props.itemCount && this.props.itemCount > 0 ){
                        return (
                          <div className='CartPage__OrderSummary'>

                            { ( () => {
                              if( !this.props.isMobileDevice ){
                                return (
                                  <div>
                                    <div className='CartPage__headerbag--divider'>
                                      <Divider dividerType={ 'gray' }></Divider>
                                    </div>
                                    <div className='CartPage__ButtonRightPanel'>
                                      { this.button_func( checkout_message, -1 ) }
                                    </div>
                                  </div> )
                              }
                            } )() }

                            { ( () => {
                              if( has( this.props.cartPageData, 'freeSamplesInfo.items' ) ){
                                return (
                                  <ProductSamples
                                    { ...this.props }
                                    samplesListItems={ this.props.cartPageData.freeSamplesInfo.items }
                                    { ...( this.props.cartPageData.freeSamplesInfo.messages && { 'sampleSelectionDefaultMessage' : this.props.cartPageData.freeSamplesInfo.messages.items[0].message } ) }
                                  />
                                );
                              }
                            } )() }
                            { ( () => {
                              if( this.props.cartPageData.giftOptions ){
                                let headerMsg = undefined;
                                if( has( this.props.cartPageData, 'giftOptions.messages.items' ) ){
                                  headerMsg = find( this.props.cartPageData.giftOptions.messages.items, { type:'Info' } );
                                }
                                return (
                                  <GiftBox
                                    { ...this.props }
                                    giftBoxMessage={ this.props.cartPageData.giftOptions.giftBoxDesc }
                                    giftBoxTitle={ formatMessage( messages.giftBoxTitle ) }
                                    giftBoxReceiptMessage={ formatMessage( messages.giftBoxReceiptMessage ) }
                                    giftBoxPrice={ this.props.cartPageData.giftOptions.giftBoxPrice }
                                    giftInclude={ this.props.cartPageData.giftOptions.giftBoxSelected }
                                    giftNoteTitle={ formatMessage( messages.giftNoteTitle ) }
                                    giftNoteMessage={ this.props.cartPageData.giftOptions.giftAdditionalMessage }
                                    giftMessage={ this.props.cartPageData.giftOptions.giftNote }
                                    { ...( headerMsg && { 'giftHeaderMessage' : headerMsg.message } ) }
                                  />
                                )
                              }
                            } )() }

                            { ( () => {
                              if( this.props.cartPageData.appliedCouponSummary ){
                                let appliedCouponSummary = this.props.cartPageData.appliedCouponSummary;
                                let couponAppliedErrorMessage = undefined;
                                let couponAppliedMsg = undefined;
                                if( this.props.cartPageData.appliedCouponSummary.messages ){
                                  couponAppliedErrorMessage = find( this.props.cartPageData.appliedCouponSummary.messages.items, { type:'Error' } );
                                  couponAppliedMsg = find( this.props.cartPageData.appliedCouponSummary.messages.items, { type:'Info' } );
                                }
                                return (
                                  <Coupons
                                    { ...this.props }
                                    couponAppliedStatus={ appliedCouponSummary.couponAppliedStatus }
                                    couponDescription={ appliedCouponSummary.couponDescription }
                                    { ...( couponAppliedMsg && { 'couponAppliedMsg' : couponAppliedMsg.message } ) }
                                    couponCode={ appliedCouponSummary.couponCode }
                                    { ...( couponAppliedErrorMessage && { 'couponAppliedErrorMessage' : couponAppliedErrorMessage.message } ) }
                                  />
                                )
                              }
                            } )() }
                          </div>
                        )
                      }
                    } )() }
                  </div>

                  <Sticker>
                    <div className='CartPage__MainContainerRightPanel CartPage__MainContainerRightPanel--stickPanel'>
                      { ( () => {
                        if( this.props.itemCount && this.props.itemCount > 0 ){
                          return (
                            <div className='CartPage__OrderSummary'>
                              <div className='CartPage__orderSummaryPayPal Gutter'>
                                { ( () => {
                                  try {
                                    return (
                                      <OrderSummaryItem
                                        itemCount={ this.props.cartPageData.cartSummary.itemCount }
                                        giftBoxPrice={ this.props.cartPageData.cartSummary.orderGiftWrapAmt }
                                        couponDiscountPrice={ this.props.cartPageData.cartSummary.couponDiscount }
                                        promotionalDiscountPrice={ this.props.cartPageData.cartSummary.additionalDiscount }
                                        shippingCost={ this.props.cartPageData.cartSummary.shippingCost }
                                        estimatedTax={ this.props.cartPageData.cartSummary.estimatedTax }
                                        estimatedTotal={ this.props.cartPageData.cartSummary.estimatedTotal }
                                        subTotalPrice={ this.props.cartPageData.cartSummary.subTotal }
                                        displayEstimatedTotal={ true }
                                        displayProductInfo={ true }
                                        orderId={ this.props.cartPageData.orderId }
                                      />
                                    );
                                  }
                                  catch ( e ){

                                  }
                                } )() }
                                { ( () => {
                                  if( ultamateRewardsCCInfo &&
                                    ( ultamateRewardsCCInfo.action === 'apply' ||
                                      ultamateRewardsCCInfo.action === 'get'
                                    )
                                  ){
                                    return (
                                      <div className='CartPage__ApplyUltamateRewards'>
                                        <UltamateRewardsCreditCard
                                          isSignedIn={ this.props.isSignedIn }
                                          ultamateRewardsCCInfo={ ultamateRewardsCCInfo }
                                        />
                                        <Divider dividerType={ 'gray' }></Divider>
                                      </div>
                                    );
                                  }
                                } )() }
                                <div className='CartPage__Button'>
                                  { this.button_func( checkout_message, 0 ) }
                                </div>
                                { ( () => {
                                  if( !isUndefined( this.props.cartPageData ) && !isEmpty( this.props.cartPageData ) ){
                                    return (
                                      <PaypalCheckoutButton
                                        payPalClientToken={ this.props.payPalClientToken }
                                        getPaypalToken={ this.props.getPaypalToken }
                                        getPaypalResponse={ this.props.getPaypalResponse }
                                        applyPayment={ this.props.applyExpressPayment }
                                        applyPaymentSameSession={ this.props.applyExpressPaymentSameSession }
                                        amount={ has( this.props.loadCartData, 'cartSummary' ) ? this.props.loadCartData.cartSummary.estimatedTotal : '' }
                                        currency={ has( this.props.loadCartData, 'cartSummary' ) ? this.props.loadCartData.cartSummary.currencyCode : '' }
                                        displayMode={ 'button' }
                                        paypalEnvironment={ this.props.switchData.switches.paypalEnvironment }
                                        enablePaypalButton={ this.props.switchData.switches.enableExpressPaypalCheckout }
                                        history={ this.props.history }
                                      />
                                    );
                                  }
                                } )() }

                                { ( () => {
                                  if( !this.props.isMobileDevice ){
                                    return (
                                      <div className='footerText'>
                                        <FooterHelpText
                                          hoursOfOperation={ this.props.switchData.switches.guestServiceHours }
                                          serviceNumber={ this.props.switchData.switches.guestServiceNumber }
                                        />
                                      </div>
                                    );
                                  }

                                } )() }

                              </div>

                              { ( () => {
                                if( this.props.isMobileDevice ){
                                  // the div below is only used for Reflektion and must appear before CartPage__ProductRecs
                                  // specific data attribute is also added to CartPage__ProductRecs if enabled is true
                                  if( this.props.switchData.switches.enableReflektionTag ){
                                    return ( <div data-rfkid='rfkid_4'></div> );
                                  }
                                }
                              } )() }

                              { ( () => {
                                if( this.props.isMobileDevice ){
                                  if( !isEmpty( this.props.recommendedProducts ) ){
                                    return (
                                      <div className='CartPage__ProductRecs'
                                        data-rfkid={ ( this.props.switchData.switches.enableReflektionTag ) ? 'rfkid_x4' : null }
                                      >
                                        <ProductRecs
                                          { ...this.props }
                                          showOnlyListPrice={ true }
                                          productRecList={ this.props.recommendedProducts }
                                        />
                                      </div>
                                    );
                                  }
                                }
                              } )() }
                            </div>
                          )
                        }
                      } )() }
                    </div>
                  </Sticker>
                </div>
              )
            }
          } )() }
        </div>

      );
    }


  }
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( CartPage ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );
