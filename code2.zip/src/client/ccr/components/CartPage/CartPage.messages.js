/*
 * CartPage Messages
 *
 * This contains all the text for the CartPage container.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  emptyBagMessage: {
    id: 'i18n.CartPage.emptyBagMessage',
    defaultMessage: 'Oops, your bag is empty!'
  },
  gwpmessage: {
    id: 'i18n.CartPage.gwpmessage',
    defaultMessage: 'FREE gifts for you'
  },
  addmessage: {
    id: 'i18n.CartPage.addmessage',
    defaultMessage: 'Below'
  },
  checkout: {
    id: 'i18n.CartPage.checkout',
    defaultMessage: 'Secure Checkout'
  },
  giftBoxTitle: {
    id: 'i18n.CartPage.giftBoxTitle',
    defaultMessage: 'Gift Box - '
  },
  giftNoteTitle: {
    id: 'i18n.CartPage.giftCardTitle',
    defaultMessage: 'Add a Little Note - FREE'
  },

  giftBoxReceiptMessage: {
    id: 'i18n.ProductSamples.giftBoxReceiptMessage',
    defaultMessage: 'Gift Receipt Included'
  },
  richRelevanceMessage: {
    id: 'i18n.CartPage.richRelevanceMessage',
    defaultMessage: 'You Might Also Like...'
  },
  productsRecommendationsTitle: {
    id: 'i18n.CartPage.productsRecommendationsTitle',
    defaultMessage: 'Beauty Experts bought...'
  }
} );
