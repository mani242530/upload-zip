import React from 'react';
import ReactDOM from 'react-dom';
import ConnectedCartPage, {
  connectFunction,
  mapStateToProps,
  mapDispatchToProps
} from './CartPage';
import { shallow } from 'enzyme';

import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import messages from './CartPage.messages';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import HeaderBagSummary from 'ccr/components/HeaderBagSummary/HeaderBagSummary';
import OrderSummaryItem from 'ccr/components/OrderSummaryItem/OrderSummaryItem';
import ProductCellList from 'ccr/components/ProductCellList/ProductCellList';
import OutOfStockProductItems from 'ccr/components/OutOfStockProductItems/OutOfStockProductItems';
import find from 'lodash/find';
import {
  createScriptTag,
  removeScriptTag
} from 'utils/3rdPartyScripts/3rdPartyScripts';

import {
  actions as userActions
} from 'shared/actions/User/User.actions';

import {
  actions as miniCartActions
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  actions as checkoutPageActions
} from 'ccr/actions/CheckoutPage/CheckoutPage.actions'


jest.mock( 'utils/3rdPartyScripts/3rdPartyScripts', () =>{
  return {
    createScriptTag: jest.fn(),
    removeScriptTag: jest.fn()
  }
} );

let appElement = document.createElement( 'div' );
appElement.id='js-cartpage';
document.body.appendChild( appElement );

describe( '<CartPage />', () => {
  let handleScrollViewMock = jest.fn();
  window.braintree = { client:{ create:jest.fn() } };
  const scrollWindowToPosition = jest.fn();
  window.requestAnimationFrame = jest.fn();
  window.innerWidth = 767;
  window.paypal = {
    Button: {
      render: jest.fn()
    }
  }
  let props = {
    isMobileDevice: false,
    match: {
      path: '/bag'
    },
    switchData: {
      switches: {
        guestServiceHours: '7am-11pm'
      }
    },
    messages: {
      items: [
        {
          type: 'Info',
          message: 'Looks like you have items in your bag from before.'
        }
      ]
    },
    itemCount: '3'

  }
  props.requestPageData = jest.fn();
  props.handleScrollView= jest.fn();
  const store = configureStore( {}, CONFIG );
  store.getState().global = {
    switchData: {
      switches: {
        guestServiceHours: '7am-11pm',
        enableReflektionTag:true
      }
    }
  };
  store.getState().minicart = {
    quantity: 4,
    giftText: 'Happy Birthday',
    giftBoxToggle: true,
    showBagSummary: true,
    productSampleCatalogID: '',
    cartRightPanelCollapse: {
      samples: false,
      gifts: false,
      coupons: false
    },
    switchesDataAvailable:true,
    cartDataAvailable:true,
    setShowBagSummaryStatus: jest.fn(),
    handleScrollView: jest.fn(),
    cartPageData: {
      cartSummary: {
        shippingCost: 0,
        subTotal: 0,
        itemCount: '3',
        additionalDiscount: '',
        couponDiscount: 0,
        estimatedTax: 'TBD',
        giftBox: '',
        estimatedTotal: 0
      },
      cartItems: {
        items: [
          {
            commerceItemId: 'ci108397018736',
            brandName: 'Laura Geller Beauty',
            quantity: {
              value:3,
              messages:null
            },
            productId: 'xlsImpprod2240027',
            skuDisplayName: 'Balance N Brighten',
            catalogRefId: 2218588,
            categoryName: 'Face Wash',
            priceInfo: {
              salePrice: '$21.98',
              regularPrice: '$32.97',
              unitPriceMessage: '1 @ $4.40,2 @ $8.79'
            },
            imageURL: 'http://s7d5.scene7.com/is/image/Ulta/2218588?$sm$',
            maxQty: 10,
            shippingRestriction: 'Can\'t be shipped via air',
            excludedFromCoupon: false,
            discountMessage: 'Discount Applied',
            couponApplied: true,
            pdpUrl: 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
            variantInfo: {
              color: 'Red',
              size: '7oz'
            },
            adbugMessageMap: {
              adbugMessage: 'Buy 1, get 1 at 50% off! Add 2 items to qualify!',
              promoUrl: 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
            },
            errorMsg: ''
          }
        ]
      },
      giftOptions: {
        giftBoxProductId: 'prod9990099',
        giftBoxPrice: 0,
        giftHeaderMessage: 'Add Gift Box & A Personal Message',
        giftBoxSelected: false,
        giftAdditionalMessage: 'Prices will be hidden on the receipt',
        giftBoxSkuId: '9990099',
        giftBoxDesc: 'Ulta.com Gift Packaging (One Charge Per Order)',
        giftBoxImageURL: 'http://images.ulta.com/is/image/Ulta/9990099?$md$',
        giftNote: 'Happy Birthday Teja'
      },
      freeSamplesInfo: {
        messages: null,
        items: [
          {
            catalogRefId: '2252998',
            sampleDesc: 'Fragrance',
            shippingRestriction: 'Cannot ship to selected address',
            selected: false
          },
          {
            catalogRefId: '2252999',
            sampleDesc: 'Skincare',
            shippingRestriction: null,
            selected: false
          },
          {
            catalogRefId: '2253000',
            sampleDesc: 'Variety',
            shippingRestriction: null,
            selected: false
          }
        ]
      },
      appliedCouponSummary: {
        couponAppliedStatus: false,
        couponOfferReqNotMet: true,
        couponDescription: [
          '$10 off any $30 purchase CPW12345',
          '$2 off any $30 purchase CPW12345'
        ],
        couponAppliedMsg: 'CPW13345 has been applied',
        couponCode: 'CPW12345',
        couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
      },
      messages: {
        items: [
          {
            type: 'Info',
            message: 'Looks like you have items in your bag from before.'
          }
        ]
      }
    }

  }

  let component = mountWithIntl(
    <Provider store={ store }>
      <ConnectedCartPage { ...props } />
    </Provider>
  );
  component.find( 'CartPage' ).instance().handleScrollView = handleScrollViewMock;
  it( 'renders without crashing', () => {
    expect( component.find( 'CartPage' ).length ).toBe( 1 );
  } );

  it( 'Should contain CartPage__MainContainerLeftPanel', () => {
    expect( component.find( '.CartPage__MainContainerLeftPanel' ).length ).toBe( 1 );
  } );

  it( 'Should contain Main Container Right Panel inside Right Panel', () => {
    expect( component.find( '.CartPage__MainContainerRightPanel' ).length ).toBe( 2 );
  } );

  it( 'Should invoke handleScrollView', () => {
    component.find( 'CartPage' ).instance().componentDidUpdate();
    expect( handleScrollViewMock ).toBeCalled();
  } );

  it( 'Should invoke createScriptTag method to insert the reflektion script on component render', () => {
    expect( createScriptTag ).toBeCalledWith( 'refRealTime', undefined, undefined, expect.stringContaining( '\'product_ids\': [\'2218588\']' ), 'refBeaconScriptUrl' );
  } );

  it( 'Should invoke removeScriptTag to remove the reflektion scrip on unmount', () => {
    component.find( 'CartPage' ).instance().componentWillUnmount();
    expect( removeScriptTag ).toBeCalledWith( 'refRealTime' );
  } );

  it( 'Should invoke handleScrollView when an item is updated or removed', () => {
    store.getState().minicart.cartPageData.updatedItems=[
      {
        'skuId':'1232312',
        'quantity':{
          'messages':{
            'items':[
              {
                'type':'info',
                'message':'quantity updated'
              }
            ]
          }
        }
      }
    ]
    store.getState().minicart.cartPageData.removedItems=[
      {
        'skuId':'1232312',
        'messages':{
          'items':[
            {
              'type':'info',
              'message':'item removed'
            }
          ]
        }
      }
    ]
    store.getState().minicart.cartPageData.messages = null;
    const prevProps = {
      cartPageData:{}
    }
    const handleScrollViewMock = jest.fn();

    let component5 = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );
    component5.find( 'CartPage' ).instance().handleScrollView = handleScrollViewMock;
    component5.find( 'CartPage' ).instance().componentDidUpdate( prevProps );
    expect( handleScrollViewMock ).toBeCalled();
  } );


  it( 'Should contain HeaderSummary component if window width is less than 992px', () => {

    props = {
      ...props,
      isMobileDevice: true,
      switchData: {
        switches: {
          guestServiceHours: '7am-11pm'
        }
      },
      messages: {
        items: [
          {
            type: 'Info',
            message: 'Looks like you have items in your bag from before.'
          }
        ]
      }
    }

    store.getState().minicart = {
      quantity: 4,
      giftText: 'Happy Birthday',
      giftBoxToggle: true,
      showBagSummary: true,
      setShowBagSummaryStatus: jest.fn(),
      productSampleCatalogID: '',
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      },
      cartPageData: {
        cartSummary: {
          shippingCost: 0,
          subTotal: 0,
          itemCount: '3',
          additionalDiscount: '',
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftBox: '',
          estimatedTotal: 0
        },
        giftOptions: {
          giftBoxProductId: 'prod9990099',
          giftBoxPrice: 0,
          giftHeaderMessage: 'Add Gift Box & A Personal Message',
          giftBoxSelected: false,
          giftAdditionalMessage: 'Prices will be hidden on the receipt',
          giftBoxSkuId: '9990099',
          giftBoxDesc: 'Ulta.com Gift Packaging (One Charge Per Order)',
          giftBoxImageURL: 'http://images.ulta.com/is/image/Ulta/9990099?$md$',
          giftNote: 'Happy Birthday Teja'
        },
        freeSamplesInfo: {
          messages: {
            items: [
              {
                type: 'Info',
                message: null
              }
            ]
          },
          items: [
            {
              catalogRefId: '2252998',
              sampleDesc: 'Fragrance',
              shippingRestriction: 'Cannot ship to selected address',
              selected: false
            },
            {
              catalogRefId: '2252999',
              sampleDesc: 'Skincare',
              shippingRestriction: null,
              selected: false
            },
            {
              catalogRefId: '2253000',
              sampleDesc: 'Variety',
              shippingRestriction: null,
              selected: false
            }
          ]
        },
        appliedCouponSummary: {
          couponAppliedStatus: 'Error',
          couponOfferReqNotMet: true,
          couponDescription: [
            '$10 off any $30 purchase CPW12345',
            '$2 off any $30 purchase CPW12345'
          ],
          couponAppliedMsg: 'CPW13345 has been applied',
          couponCode: 'CPW12345',
          couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
        },
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Looks like you have items in your bag from before.'
            }
          ]
        }
      }

    }

    let new_component = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );
    expect( new_component.find( 'HeaderBagSummary' ).length ).toBe( 1 );
  } );


  it( 'Should contain OrderSummaryItem component at top of the bag if showBagSummary state is set to true', () => {
    const store = configureStore( {}, CONFIG );
    window.innerWidth = 600;
    store.getState().global = {
      switchData: {
        switches: { guestServiceHours: '7am-11pm' }
      }
    };
    store.getState().minicart = {
      quantity: 4,
      giftText: 'Happy Birthday',
      giftBoxToggle: true,
      showBagSummary: true,
      setShowBagSummaryStatus: jest.fn(),
      productSampleCatalogID: '',
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      },
      cartPageData: {
        cartSummary: {
          shippingCost: 0,
          subTotal: 0,
          itemCount: '3',
          additionalDiscount: '',
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftBox: '',
          estimatedTotal: 0
        },

        giftOptions: {
          giftBoxProductId: 'prod9990099',
          giftBoxPrice: 0,
          giftHeaderMessage: 'Add Gift Box & A Personal Message',
          giftBoxSelected: false,
          giftAdditionalMessage: 'Prices will be hidden on the receipt',
          giftBoxSkuId: '9990099',
          giftBoxDesc: 'Ulta.com Gift Packaging (One Charge Per Order)',
          giftBoxImageURL: 'http://images.ulta.com/is/image/Ulta/9990099?$md$',
          giftNote: 'Happy Birthday Teja'
        },
        freeSamplesInfo: {
          messages: {
            items: [
              {
                type: 'Info',
                message: null
              }
            ]
          },
          items: [
            {
              catalogRefId: '2252998',
              sampleDesc: 'Fragrance',
              shippingRestriction: 'Cannot ship to selected address',
              selected: false
            },
            {
              catalogRefId: '2252999',
              sampleDesc: 'Skincare',
              shippingRestriction: null,
              selected: false
            },
            {
              catalogRefId: '2253000',
              sampleDesc: 'Variety',
              shippingRestriction: null,
              selected: false
            }
          ]
        },
        appliedCouponSummary: {
          couponAppliedStatus: 'Error',
          couponOfferReqNotMet: true,
          couponDescription: [
            '$10 off any $30 purchase CPW12345',
            '$2 off any $30 purchase CPW12345'
          ],
          couponAppliedMsg: 'CPW13345 has been applied',
          couponCode: 'CPW12345',
          couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
        },
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Looks like you have items in your bag from before.'
            }
          ]
        }
      }


    }

    let new_component1 = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );


    expect( new_component1.find( 'OrderSummaryItem' ).length ).toBe( 1 );
  } );


  it( 'Should contain secure checkout button component Mobile', () => {
    const store = configureStore( {}, CONFIG );
    store.getState().global = {
      switchData: {
        switches: { guestServiceHours: '7am-11pm' }
      }
    };
    store.getState().minicart = {
      quantity: 4,
      giftText: 'Happy Birthday',
      giftBoxToggle: true,
      showBagSummary: true,
      setShowBagSummaryStatus: jest.fn(),
      handleScrollView: jest.fn(),
      productSampleCatalogID: '',
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      },
      cartPageData: {
        cartSummary: {
          shippingCost: 0,
          subTotal: 0,
          itemCount: '3',
          additionalDiscount: '',
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftBox: '',
          estimatedTotal: 0
        },
        giftOptions: {
          giftBoxProductId: 'prod9990099',
          giftBoxPrice: 0,
          giftHeaderMessage: 'Add Gift Box & A Personal Message',
          giftBoxSelected: false,
          giftAdditionalMessage: 'Prices will be hidden on the receipt',
          giftBoxSkuId: '9990099',
          giftBoxDesc: 'Ulta.com Gift Packaging (One Charge Per Order)',
          giftBoxImageURL: 'http://images.ulta.com/is/image/Ulta/9990099?$md$',
          giftNote: 'Happy Birthday Teja'
        },
        freeSamplesInfo: {
          messages: {
            items: [
              {
                type: 'Info',
                message: null
              }
            ]
          },
          items: [
            {
              catalogRefId: '2252998',
              sampleDesc: 'Fragrance',
              shippingRestriction: 'Cannot ship to selected address',
              selected: false
            },
            {
              catalogRefId: '2252999',
              sampleDesc: 'Skincare',
              shippingRestriction: null,
              selected: false
            },
            {
              catalogRefId: '2253000',
              sampleDesc: 'Variety',
              shippingRestriction: null,
              selected: false
            }
          ]
        },
        appliedCouponSummary: {
          couponAppliedStatus: 'Error',
          couponOfferReqNotMet: true,
          couponDescription: [
            '$10 off any $30 purchase CPW12345',
            '$2 off any $30 purchase CPW12345'
          ],
          couponAppliedMsg: 'CPW13345 has been applied',
          couponCode: 'CPW12345',
          couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
        },
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Looks like you have items in your bag from before.'
            }
          ]
        }
      }

    }
    window.innerWidth = 600;
    let new_component2 = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );
    expect( component.find( '.CartPage__Button' ).length ).toBe( 1 );

  } );
  it( 'Should contain secure checkout button component Desktop', () => {
    window.innerWidth = 1000;
    props = {
      ...props,
      isMobileDevice: false,
      switchData: {
        switches: {
          guestServiceHours: '7am-11pm'
        }
      },
      messages: {
        items: [
          {
            type: 'Info',
            message: 'Looks like you have items in your bag from before.'
          }
        ]
      }
    }

    store.getState().minicart = {
      quantity: 4,
      giftText: 'Happy Birthday',
      giftBoxToggle: true,
      showBagSummary: true,
      setShowBagSummaryStatus: jest.fn(),
      handleScrollView: jest.fn(),
      productSampleCatalogID: '',
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      },
      cartPageData: {
        cartSummary: {
          shippingCost: 0,
          subTotal: 0,
          itemCount: '3',
          additionalDiscount: '',
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftBox: '',
          estimatedTotal: 0
        },
        cartItems: {
          items: [
            {
              'commerceItemId': 'ci108397018736',
              'brandName': 'Laura Geller Beauty',
              'displayType':'default',
              'quantity': {
                value:9,
                messages:null
              },
              'productId': 'xlsImpprod2240027',
              'displayName': 'Balance N Brighten',
              'catalogRefId': '2218588',
              'priceInfo': {
                'regularPrice': '$19.98',
                'salePrice': null,
                'unitPriceMessage': '1 @ $5,1 @ $9.99'
              },
              'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$',
              'maxQty': 10,
              'adbugMessageMap': {
                'adbugMessage': 'Buy 1, get 1 at 50% off! ',
                'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
              },
              'hazmatCode': '',
              'excludedFromCoupon': true,
              'discountMessage': 'Discount Applied!',
              'couponApplied': true,
              'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
              'variantInfo': {
                'color': 'Red',
                'size': '7oz'
              },
              'errorMsg': ''
            },
            {
              'commerceItemId': 'ci108397018736',
              'brandName': 'Laura Geller Beauty',
              'displayType':'removed',
              'quantity': {
                value:9,
                messages:null
              },
              'productId': 'xlsImpprod2240027',
              'displayName': 'Balance N Brighten',
              'catalogRefId': '2218588',
              'priceInfo': {
                'regularPrice': '$19.98',
                'salePrice': null,
                'unitPriceMessage': '1 @ $5,1 @ $9.99'
              },
              'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$',
              'maxQty': 10,
              'adbugMessageMap': {
                'adbugMessage': 'Buy 1, get 1 at 50% off! ',
                'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
              },
              'hazmatCode': '',
              'excludedFromCoupon': true,
              'discountMessage': 'Discount Applied!',
              'couponApplied': true,
              'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
              'variantInfo': {
                'color': 'Red',
                'size': '7oz'
              },
              'errorMsg': ''
            }
          ]
        },
        giftOptions: {
          giftBoxProductId: 'prod9990099',
          giftBoxPrice: 0,
          giftHeaderMessage: 'Add Gift Box & A Personal Message',
          giftBoxSelected: false,
          giftAdditionalMessage: 'Prices will be hidden on the receipt',
          giftBoxSkuId: '9990099',
          giftBoxDesc: 'Ulta.com Gift Packaging (One Charge Per Order)',
          giftBoxImageURL: 'http://images.ulta.com/is/image/Ulta/9990099?$md$',
          giftNote: 'Happy Birthday Teja'
        },
        freeSamplesInfo: {
          messages: {
            items: [
              {
                type: 'Info',
                message: null
              }
            ]
          },
          items: [
            {
              catalogRefId: '2252998',
              sampleDesc: 'Fragrance',
              shippingRestriction: 'Cannot ship to selected address',
              selected: false
            },
            {
              catalogRefId: '2252999',
              sampleDesc: 'Skincare',
              shippingRestriction: null,
              selected: false
            },
            {
              catalogRefId: '2253000',
              sampleDesc: 'Variety',
              shippingRestriction: null,
              selected: false
            }
          ]
        },
        appliedCouponSummary: {
          couponAppliedStatus: 'Error',
          couponOfferReqNotMet: true,
          couponDescription: [
            '$10 off any $30 purchase CPW12345',
            '$2 off any $30 purchase CPW12345'
          ],
          couponAppliedMsg: 'CPW13345 has been applied',
          couponCode: 'CPW12345',
          couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
        },
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Looks like you have items in your bag from before.'
            }
          ]
        }
      }


    }
    component = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );
    store.getState().global.innerWidth = 1000;
    store.getState().global.isMobileDevice = false;
    expect( component.find( '.CartPage__Button' ).length ).toBe( 1 );
    expect( component.find( '.CartPage__ButtonRightPanel .btn .btn-single .btn-lg .btn-block' ).props().tabIndex ).toBe( -1 );
    expect( component.find( '.CartPage__Button .btn .btn-single .btn-lg .btn-block' ).props().tabIndex ).toBe( 0 );

  } );
  it( 'Should call button function', () => {
    let tmp = component.find( 'CartPage' );
    tmp.instance().button_func = jest.fn();
    tmp.instance().render()
    expect( tmp.instance().button_func ).toBeCalled();
  } );

  it( 'Should call handleScrollView on invoking gwpcheck function', () => {
    store.getState().minicart.cartPageData.giftItems = {
      'items': [
        {
          'bfxPriceMap': null,
          'promoId': 1143243243,
          'indulge': true,
          'freeGifts': {
            'items': [
              {
                'giftCatalogRefId': '112023775',
                'giftVariant': 'Silver',
                'giftDisplayName': 'Eternity for Men Eau de Toilette',
                'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
                'selected': 'false',
                'giftBrandName': 'Calvin Klein',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              },
              {
                'giftCatalogRefId': '112023774',
                'giftVariant': 'Silvers',
                'giftDisplayName': 'Eternity for Men Eau de Toilette',
                'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
                'selected': 'false',
                'giftBrandName': 'Calvin Klein',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              },
              {
                'giftCatalogRefId': '132023776',
                'giftVariant': 'XXX',
                'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
                'selected': 'default',
                'giftBrandName': 'Calvin Klein',
                'giftHazmatRestriction': 'Can\'t be shipped via air',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              }
            ]
          }
        }
      ]
    };
    const cartComponent = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );
    expect( cartComponent.find( 'GWPProductList' ).length ).toBe( 1 );
    expect( cartComponent.find( 'GWPProductList' ).props().handleScrollView ).toBeTruthy();

    var giftElement = document.createElement( 'div' );
    giftElement.id = 'Gifts';
    document.body.appendChild( giftElement );

    let node = cartComponent.find( 'CartPage' ).instance();
    const handleScrollViewMock1=jest.fn();
    node.handleScrollView = handleScrollViewMock1;
    node.gwpcheck();
    expect( handleScrollViewMock1 ).toBeCalled();
  } );

  it( 'Should render GWPProductList component without crashing even after the gift items list gets updated', () => {
    // GWPProductList component was crashing when giftitems are updated, as it was just index which was
    // being used as the key while iterating, and hence GWPProductList was trying to update the wrong GWPProductItem even if the
    // gift item list is coming in a different order.
    // made modification to use the promoId as the key while looping, so that giftitems will be uniquely identified
    store.getState().minicart.cartPageData.giftItems = {
      'items': [
        {
          'bfxPriceMap': null,
          'promoId': 1143243243,
          'indulge': true,
          'freeGifts': {
            'items': [
              {
                'giftCatalogRefId': '112023775',
                'giftVariant': 'Silver',
                'giftDisplayName': 'Eternity for Men Eau de Toilette',
                'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
                'selected': 'false',
                'giftBrandName': 'Calvin Klein',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              },
              {
                'giftCatalogRefId': '112023774',
                'giftVariant': 'Silvers',
                'giftDisplayName': 'Eternity for Men Eau de Toilette',
                'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
                'selected': 'false',
                'giftBrandName': 'Calvin Klein',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              },
              {
                'giftCatalogRefId': '132023776',
                'giftVariant': 'XXX',
                'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
                'selected': 'default',
                'giftBrandName': 'Calvin Klein',
                'giftHazmatRestriction': 'Can\'t be shipped via air',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              }
            ]
          }
        }
      ]
    };

    const cartComponent1 = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );

    store.getState().minicart.cartPageData.giftItems = {
      'items': [
        {
          'bfxPriceMap': null,
          'promoId': 1111111,
          'indulge': true,
          'freeGifts': {
            'items': [
              {
                'giftCatalogRefId': '212023775',
                'giftVariant': 'new Silver',
                'giftDisplayName': 'new Eternity for Men Eau de Toilette',
                'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
                'selected': 'false',
                'giftBrandName': 'new Calvin Klein',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              },
              {
                'giftCatalogRefId': '232023776',
                'giftVariant': 'new XXX',
                'giftDisplayName': 'new Hair Building Fibers-Medium Blonde',
                'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
                'selected': 'default',
                'giftBrandName': 'new Calvin Klein',
                'giftHazmatRestriction': 'Can\'t be shipped via air',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              }
            ]
          }
        },
        {
          'bfxPriceMap': null,
          'promoId': 1143243243,
          'indulge': true,
          'freeGifts': {
            'items': [
              {
                'giftCatalogRefId': '112023775',
                'giftVariant': 'Silver',
                'giftDisplayName': 'Eternity for Men Eau de Toilette',
                'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
                'selected': 'false',
                'giftBrandName': 'Calvin Klein',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              },
              {
                'giftCatalogRefId': '112023774',
                'giftVariant': 'Silvers',
                'giftDisplayName': 'Eternity for Men Eau de Toilette',
                'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
                'selected': 'false',
                'giftBrandName': 'Calvin Klein',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              },
              {
                'giftCatalogRefId': '132023776',
                'giftVariant': 'XXX',
                'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
                'selected': 'default',
                'giftBrandName': 'Calvin Klein',
                'giftHazmatRestriction': 'Can\'t be shipped via air',
                'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
              }
            ]
          }
        }
      ]
    };
    cartComponent1.find( 'CartPage' ).instance().forceUpdate();
    expect( cartComponent1.find( 'GWPProductList' ).length ).toBe( 1 );

  } );

  it( 'should contain paypal button component', () => {
    expect( component.find( 'PaypalCheckoutButton' ).length ).toBe( 1 );
  } );

  it( 'Should contain OrderSummaryItem component at the bottom of the bag', () => {

    const store = configureStore( {}, CONFIG );
    window.innerWidth = 1000;
    store.getState().global = {
      switchData: {
        switches: { guestServiceHours: '7am-11pm' }
      }
    };
    store.getState().minicart = {
      quantity: 4,
      giftText: 'Happy Birthday',
      giftBoxToggle: true,
      showBagSummary: true,
      setShowBagSummaryStatus: jest.fn(),
      handleScrollView: jest.fn(),
      productSampleCatalogID: '',
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      },
      cartPageData: {
        cartSummary: {
          shippingCost: 0,
          subTotal: 0,
          itemCount: '3',
          additionalDiscount: '',
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftBox: '',
          estimatedTotal: 0
        },
        giftOptions: {
          giftBoxProductId: 'prod9990099',
          giftBoxPrice: 0,
          giftHeaderMessage: 'Add Gift Box & A Personal Message',
          giftBoxSelected: false,
          giftAdditionalMessage: 'Prices will be hidden on the receipt',
          giftBoxSkuId: '9990099',
          giftBoxDesc: 'Ulta.com Gift Packaging (One Charge Per Order)',
          giftBoxImageURL: 'http://images.ulta.com/is/image/Ulta/9990099?$md$',
          giftNote: 'Happy Birthday Teja'
        },
        freeSamplesInfo: {
          messages: {
            items: [
              {
                type: 'Info',
                message: null
              }
            ]
          },
          items: [
            {
              catalogRefId: '2252998',
              sampleDesc: 'Fragrance',
              shippingRestriction: 'Cannot ship to selected address',
              selected: false
            },
            {
              catalogRefId: '2252999',
              sampleDesc: 'Skincare',
              shippingRestriction: null,
              selected: false
            },
            {
              catalogRefId: '2253000',
              sampleDesc: 'Variety',
              shippingRestriction: null,
              selected: false
            }
          ]
        },
        appliedCouponSummary: {
          couponAppliedStatus: 'Error',
          couponOfferReqNotMet: true,
          couponDescription: [
            '$10 off any $30 purchase CPW12345',
            '$2 off any $30 purchase CPW12345'
          ],
          couponAppliedMsg: 'CPW13345 has been applied',
          couponCode: 'CPW12345',
          couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
        },
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Looks like you have items in your bag from before.'
            }
          ]
        }
      }

    }
    let component2 = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );
    expect( component2.find( '.CartPage__OrderSummary .OrderSummaryItem' ).length ).toBe( 1 );
  } );

  it( 'Should contain AnB CTA in cart page', () => {

    const store = configureStore( {}, CONFIG );
    window.innerWidth = 1000;
    store.getState().global = {
      switchData: {
        switches: { guestServiceHours: '7am-11pm' }
      }
    };
    store.getState().minicart = {
      quantity: 4,
      giftText: 'Happy Birthday',
      giftBoxToggle: true,
      showBagSummary: true,
      setShowBagSummaryStatus: jest.fn(),
      handleScrollView: jest.fn(),
      productSampleCatalogID: '',
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      },
      cartPageData: {
        cartSummary: {
          shippingCost: 0,
          subTotal: 0,
          itemCount: '3',
          additionalDiscount: '',
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftBox: '',
          estimatedTotal: 0
        },
        ultamateRewardsCCInfo: {
          hasUltaCC: false,
          msgHeader: 'Save 20% on this order! Plus start earning 2 points per dollar!',
          appliedToProfile: false,
          action: 'apply',
          msgTxt: 'Get the Ultamate Rewards Credit Card'
        },
        giftOptions: {
          giftBoxProductId: 'prod9990099',
          giftBoxPrice: 0,
          giftHeaderMessage: 'Add Gift Box & A Personal Message',
          giftBoxSelected: false,
          giftAdditionalMessage: 'Prices will be hidden on the receipt',
          giftBoxSkuId: '9990099',
          giftBoxDesc: 'Ulta.com Gift Packaging (One Charge Per Order)',
          giftBoxImageURL: 'http://images.ulta.com/is/image/Ulta/9990099?$md$',
          giftNote: 'Happy Birthday Teja'
        },
        freeSamplesInfo: {
          messages: {
            items: [
              {
                type: 'Info',
                message: null
              }
            ]
          },
          items: [
            {
              catalogRefId: '2252998',
              sampleDesc: 'Fragrance',
              shippingRestriction: 'Cannot ship to selected address',
              selected: false
            },
            {
              catalogRefId: '2252999',
              sampleDesc: 'Skincare',
              shippingRestriction: null,
              selected: false
            },
            {
              catalogRefId: '2253000',
              sampleDesc: 'Variety',
              shippingRestriction: null,
              selected: false
            }
          ]
        },
        appliedCouponSummary: {
          couponAppliedStatus: 'Error',
          couponOfferReqNotMet: true,
          couponDescription: [
            '$10 off any $30 purchase CPW12345',
            '$2 off any $30 purchase CPW12345'
          ],
          couponAppliedMsg: 'CPW13345 has been applied',
          couponCode: 'CPW12345',
          couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
        },
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Looks like you have items in your bag from before.'
            }
          ]
        }
      }

    }
    let component2 = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props }/>
      </Provider>
    );
    expect( component2.find( '.CartPage__OrderSummary .CartPage__ApplyUltamateRewards' ).length ).toBe( 1 );
  } );

  it( 'Should contain ProductSamples component', () => {
    expect( component.find( '.ProductSamples' ).length ).toBe( 1 );
  } );

  it( 'Should not contain ProductSamples component if there are no items in freesamplesinfo ', () => {
    store.getState().minicart.cartPageData.freeSamplesInfo = {
      messages:null
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props }/>
      </Provider>
    );
    expect( component.find( '.ProductSamples' ).length ).toBe( 0 );
  } );

  it( 'Should contain GiftWrap component', () => {
    expect( component.find( 'GiftBox' ).length ).toBe( 1 );
  } );

  it( 'Should contain Coupons component', () => {
    expect( component.find( '.Coupons' ).length ).toBe( 1 );
  } );

  it( 'Should contain OutOfStockProductItems component,if there is a merge cart message', () => {
    expect( component.find( '.CartPage__MainContainerLeftPanel .OutOfStockProductItems' ).length ).toBe( 1 );
  } );

  it( 'Should contain OutOfStockProductItems component, if there is a removeditems from bag', ()=> {
    const store = configureStore( {}, CONFIG );
    window.innerWidth = 1000;
    store.getState().global = {
      switchData: {
        switches: { guestServiceHours: '7am-11pm' }
      }
    };
    store.getState().minicart = {
      quantity: 4,
      giftText: 'Happy Birthday',
      giftBoxToggle: true,
      showBagSummary: true,
      setShowBagSummaryStatus: jest.fn(),
      handleScrollView: jest.fn(),
      productSampleCatalogID: '',
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      },
      cartPageData: {
        cartSummary: {
          shippingCost: 0,
          subTotal: 0,
          itemCount: '3',
          additionalDiscount: '',
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftBox: '',
          estimatedTotal: 0
        },
        giftOptions: {
          giftBoxProductId: 'prod9990099',
          giftBoxPrice: 0,
          giftHeaderMessage: 'Add Gift Box & A Personal Message',
          giftBoxSelected: false,
          giftAdditionalMessage: 'Prices will be hidden on the receipt',
          giftBoxSkuId: '9990099',
          giftBoxDesc: 'Ulta.com Gift Packaging (One Charge Per Order)',
          giftBoxImageURL: 'http://images.ulta.com/is/image/Ulta/9990099?$md$',
          giftNote: 'Happy Birthday Teja'
        },
        freeSamplesInfo: {
          messages: {
            items: [
              {
                type: 'Info',
                message: null
              }
            ]
          },
          items: [
            {
              catalogRefId: '2252998',
              sampleDesc: 'Fragrance',
              shippingRestriction: 'Cannot ship to selected address',
              selected: false
            },
            {
              catalogRefId: '2252999',
              sampleDesc: 'Skincare',
              shippingRestriction: null,
              selected: false
            },
            {
              catalogRefId: '2253000',
              sampleDesc: 'Variety',
              shippingRestriction: null,
              selected: false
            }
          ]
        },
        appliedCouponSummary: {
          couponAppliedStatus: 'Error',
          couponOfferReqNotMet: true,
          couponDescription: [
            '$10 off any $30 purchase CPW12345',
            '$2 off any $30 purchase CPW12345'
          ],
          couponAppliedMsg: 'CPW13345 has been applied',
          couponCode: 'CPW12345',
          couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
        },
        messages:null,
        removedItems: [
          {
            couponApplied: false,
            brandName: 'OPI',
            quantity: null,
            productId: 'xlsImpprod5180311',
            excludedFromCoupon: false,
            adbugMessageMap: null,
            catalogRefId: '2056976',
            categoryName: null,
            commerceItemid: null,
            priceInfo: {
              salePrice: null,
              regularPrice: '$10',
              unitPriceMessage: null,
              bfxPriceMap: null
            },
            productDisplayName: 'Soft Shades Nail Lacquer Collection',
            imageURL: 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
            variantInfo: {
              Color: 'Bubble Bath'
            },
            skuDisplayName: 'Soft Shades Nail Lacquer Collection',
            shippingRestriction: null,
            maxQty: null,
            productURL: null,
            messages: {
              items: [
                {
                  type: 'Info',
                  message: 'Selected items is out of stock'
                }
              ]
            }
          }
        ]
      }
    }

    let component2 = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );
    expect( component2.find( '.CartPage__MainContainerLeftPanel .OutOfStockProductItems' ).length ).toBe( 1 );
  } );

  it( 'Should contain OutOfStockProductItems component, if there is a updatedItems from bag', ()=> {
    const store = configureStore( {}, CONFIG );
    window.innerWidth = 1000;
    store.getState().global = {
      switchData: {
        switches: { guestServiceHours: '7am-11pm' }
      }
    };
    store.getState().minicart = {
      quantity: 4,
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      },
      cartPageData: {
        messages:null,
        updatedItems: [
          {
            couponApplied: false,
            brandName: 'OPI',
            quantity: {
              value:3,
              messages:{
                items: [
                  {
                    type: 'Info',
                    message: 'Selected items is out of stock'
                  }
                ]
              }
            },
            productId: 'xlsImpprod5180311',
            excludedFromCoupon: false,
            adbugMessageMap: null,
            catalogRefId: '2056976',
            categoryName: null,
            commerceItemid: null,
            priceInfo: {
              salePrice: null,
              regularPrice: '$10',
              unitPriceMessage: null,
              bfxPriceMap: null
            },
            productDisplayName: 'Soft Shades Nail Lacquer Collection',
            imageURL: 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
            variantInfo: {
              Color: 'Bubble Bath'
            },
            skuDisplayName: 'Soft Shades Nail Lacquer Collection',
            shippingRestriction: null,
            maxQty: null,
            productURL: null,
            messages: null
          }
        ]
      }
    }

    let component2 = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );
    expect( component2.find( '.CartPage__MainContainerLeftPanel .OutOfStockProductItems' ).length ).toBe( 1 );
  } );

  it( 'Should contain ProductCellList component', () => {
    expect( component.find( 'ProductCellList' ).length ).toBe( 1 );
  } );

  it( 'productcell list component props should have only those items with displaytype as default', () => {
    expect( find( component.find( 'ProductCellList' ).instance().props.productData, ( { displayType:'default' } ) ) ).toBeTruthy;
    expect( find( component.find( 'ProductCellList' ).instance().props.productData, ( { displayType:'removed' } ) ) ).toBeFalsy;
  } );

  // success case for variants selection -- Whether to anchor mandatory variant selction
  it( 'checkForVariantSelection', () => {
    let giftsData = [
      {
        'freeGifts': {
          'items':[
            {
              'giftCatalogRefId': '112023775',
              'giftVariant': 'Silver',
              'giftDisplayName': 'Eternity for Men Eau de Toilette',
              'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
              'selected': 'false',
              'giftBrandName': 'Calvin Klein',
              'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
            },
            {
              'giftCatalogRefId': '112023774',
              'giftVariant': 'Silvers',
              'giftDisplayName': 'Eternity for Men Eau de Toilette',
              'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
              'selected': 'false',
              'giftBrandName': 'Calvin Klein',
              'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
            },
            {
              'giftCatalogRefId': '132023776',
              'giftVariant': 'XXX',
              'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
              'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
              'selected': 'default',
              'giftBrandName': 'Calvin Klein',
              'giftHazmatRestriction': 'Can\'t be shipped via air',
              'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
            }
          ]
        },
        'promoID': 1143243243,
        'indulge': true
      }
    ];

    let component = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props }/>
      </Provider>
    );
    const node1 = component.find( 'CartPage' );
    expect( node1.instance().checkForVariantsSelection( giftsData ) ).toBe( false );

  } );

  // failure case for variants selection
  it( 'checkForVariantSelection', () => {
    let giftsData = [
      {
        'freeGifts': {
          'items':[
            {
              'giftCatalogRefId': '112023775',
              'giftVariant': 'Silver',
              'giftDisplayName': 'Eternity for Men Eau de Toilette',
              'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
              'selected': 'false',
              'giftBrandName': 'Calvin Klein',
              'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
            },
            {
              'giftCatalogRefId': '112023774',
              'giftVariant': 'Silvers',
              'giftDisplayName': 'Eternity for Men Eau de Toilette',
              'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
              'selected': 'true',
              'giftBrandName': 'Calvin Klein',
              'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
            },
            {
              'giftCatalogRefId': '132023776',
              'giftVariant': 'XXX',
              'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
              'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
              'selected': 'default',
              'giftBrandName': 'Calvin Klein',
              'giftHazmatRestriction': 'Can\'t be shipped via air',
              'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
            }
          ]
        },
        'promoID': 1143243243,
        'indulge': true
      }
    ];

    let component = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props }/>
      </Provider>
    );
    const node1 = component.find( 'CartPage' );
    expect( node1.instance().checkForVariantsSelection( giftsData ) ).toBe( true );

  } );

  it( 'should render the FooterHelpText component if scrren width greater than or equal to 992', () => {
    window.innerWidth = 993;

    store.getState().minicart = {
      quantity: 4,
      giftText: 'Happy Birthday',
      giftBoxToggle: true,
      showBagSummary: true,
      setShowBagSummaryStatus: jest.fn(),
      handleScrollView: jest.fn(),
      productSampleCatalogID: '',
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      },
      cartPageData: {
        cartSummary: {
          shippingCost: 0,
          subTotal: 0,
          itemCount: '3',
          additionalDiscount: '',
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftBox: '',
          estimatedTotal: 0
        },
        giftOptions: {
          giftBoxProductId: 'prod9990099',
          giftBoxPrice: 0,
          giftHeaderMessage: 'Add Gift Box & A Personal Message',
          giftBoxSelected: false,
          giftAdditionalMessage: 'Prices will be hidden on the receipt',
          giftBoxSkuId: '9990099',
          giftBoxDesc: 'Ulta.com Gift Packaging (One Charge Per Order)',
          giftBoxImageURL: 'http://images.ulta.com/is/image/Ulta/9990099?$md$',
          giftNote: 'Happy Birthday Teja'
        },
        freeSamplesInfo: {
          messages: {
            items: [
              {
                type: 'Info',
                message: null
              }
            ]
          },
          items: [
            {
              catalogRefId: '2252998',
              sampleDesc: 'Fragrance',
              shippingRestriction: 'Cannot ship to selected address',
              selected: false
            },
            {
              catalogRefId: '2252999',
              sampleDesc: 'Skincare',
              shippingRestriction: null,
              selected: false
            },
            {
              catalogRefId: '2253000',
              sampleDesc: 'Variety',
              shippingRestriction: null,
              selected: false
            }
          ]
        },
        appliedCouponSummary: {
          couponAppliedStatus: 'Error',
          couponOfferReqNotMet: true,
          couponDescription: [
            '$10 off any $30 purchase CPW12345',
            '$2 off any $30 purchase CPW12345'
          ],
          couponAppliedMsg: 'CPW13345 has been applied',
          couponCode: 'CPW12345',
          couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
        }

      }


    }

    component = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );
    expect( component.find( 'FooterHelpText' ).length ).toBe( 1 );
  } );
} );

describe( '<CartPage /> MapDispatchToProps', () => {

  const dispatch = jest.fn();
  beforeEach( ()=> {
    dispatch.mockClear();
  } )
  const mdp  = mapDispatchToProps( dispatch );

  it( 'setCartRightPanelCollapse should dispatch the proper action', ( ) => {
    mdp.setCartRightPanelCollapse( 1 );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setCartRightPanelCollapse( 1 ) )
  } );

  it( 'getProfileData should dispatch the proper action', ( ) => {
    mdp.getProfileData( 'test' );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'profile', 'requested' )( 'test' ) )
  } );

  it( 'setGiftMessage should dispatch the proper action', ( ) => {
    mdp.setGiftMessage( 'test' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setGiftMessage( 'test' ) )
  } );

  it( 'setGiftBoxToggleStatus should dispatch the proper action', ( ) => {
    mdp.setGiftBoxToggleStatus( true );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setGiftBoxToggleStatus( true ) )
  } );

  it( 'addToCart should dispatch the proper action', ( ) => {
    mdp.addToCart( 'item', 'history' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.addToCart( 'item', 'history' ) )
  } );

  it( 'selectGiftVariant should dispatch the proper action', ( ) => {
    mdp.selectGiftVariant( 'promotionid', 'skuid', 'history' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.selectGiftVariant( 'promotionid', 'skuid', 'history' ) )
  } );

  it( 'setChkoutBtnStatus should dispatch the proper action', ( ) => {
    mdp.setChkoutBtnStatus( 'status' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setChkoutBtnStatus( 'status' ) )
  } );

  it( 'removeFromCart should dispatch the proper action', ( ) => {
    mdp.removeFromCart( 'item' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.removeFromCart( 'item' ) )
  } );

  it( 'removeGiftFromCart should dispatch the proper action', ( ) => {
    mdp.removeGiftFromCart( 'item', 'history' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.removeGiftFromCart( 'item', 'history' ) )
  } );

  it( 'updateCart should dispatch the proper action', ( ) => {
    mdp.updateCart( 'item', 'quantity', 'history' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.updateCart( 'item', 'quantity', 'history' ) )
  } );

  it( 'couponCodeUpdated should dispatch the proper action', ( ) => {
    mdp.couponCodeUpdated( 'item', 'history' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.couponCodeUpdated( 'item', 'history' ) )
  } );

  it( 'couponCodeRemoved should dispatch the proper action', ( ) => {
    mdp.couponCodeRemoved( 'history' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.couponCodeRemoved( 'history' ) )
  } );

  it( 'setCouponOfferReqMet should dispatch the proper action', ( ) => {
    mdp.setCouponOfferReqMet( 'history' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setCouponOfferReqMet( 'history' ) )
  } );

  it( 'setShowBagSummaryStatus should dispatch the proper action', ( ) => {
    mdp.setShowBagSummaryStatus( 'status' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setShowBagSummaryStatus( 'status' ) )
  } );

  it( 'setProductSample should dispatch the proper action', ( ) => {
    mdp.setProductSample( 'status' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setProductSample( 'status' ) )
  } );

  it( 'selectProductSampleService should dispatch the proper action', ( ) => {
    mdp.selectProductSampleService( 'catalogID', 'quantity', 'history' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.selectProductSampleService( 'catalogID', 'quantity', 'history' ) )
  } );

  it( 'removeProductSampleService should dispatch the proper action', ( ) => {
    mdp.removeProductSampleService( 'status' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.removeProductSampleService( 'status' ) )
  } );

  it( 'setGiftWrapGiftNoteService should dispatch the proper action', ( ) => {
    mdp.setGiftWrapGiftNoteService( 'giftNote', 'history' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setGiftWrapGiftNoteService( 'giftNote', 'history' ) )
  } );

  it( 'setGiftWrapGiftBoxService should dispatch the proper action', ( ) => {
    mdp.setGiftWrapGiftBoxService( 'giftboxStatus', 'history' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setGiftWrapGiftBoxService( 'giftboxStatus', 'history' ) )
  } );

  it( 'initiateCheckout should dispatch the proper action', ( ) => {
    mdp.initiateCheckout( 'status' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.initiateCheckout( 'status' ) )
  } );

  it( 'resetCheckoutEligibility should dispatch the proper action', ( ) => {
    mdp.resetCheckoutEligibility( );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.resetCheckoutEligibility( ) )
  } );

  it( 'getPaypalResponse should dispatch the proper action', ( ) => {
    mdp.getPaypalResponse( 'status' );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.getPaypalResponse( 'status' ) )
  } );

  it( 'applyExpressPayment should dispatch the proper action', ( ) => {
    mdp.applyExpressPayment( 'data' );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'applyExpressPayment', 'requested' )( 'data' ) )
  } );

  it( 'resetCartMerge should dispatch the proper action', ( ) => {
    mdp.resetCartMerge( );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.resetCartMerge( ) )
  } );

  it( 'loadCart should dispatch the proper action', ( ) => {
    mdp.loadCart( 'data' );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'loadCart', 'requested' )( 'data' ) )
  } );


  it( 'applyExpressPaymentSameSession should dispatch the proper action', ( ) => {
    mdp.applyExpressPaymentSameSession( 'data' );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'applyExpressPaymentSameSession', 'requested' )( 'data' ) )
  } );

  it( 'hideOutOfStockItems should dispatch the proper action', ( ) => {
    mdp.hideOutOfStockItems( );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.hideOutOfStockItems( ) )
  } );

  it( 'resetCartPageNavigation should dispatch the proper action', ( ) => {
    mdp.resetCartPageNavigation( );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.resetCartPageNavigation() )
  } );

  it( 'getPaypalToken should dispatch the proper action', ( ) => {
    mdp.getPaypalToken( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'paypalToken', 'requested' )() )
  } );

  it( 'focusGiftBox should dispatch the proper action', ( ) => {
    mdp.focusGiftBox( );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.focusGiftBox( ) )
  } );

  it( 'blurGiftBox should dispatch the proper action', ( ) => {
    mdp.blurGiftBox( );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.blurGiftBox( ) )
  } );
} );

describe( ' <ProductRecs/>', () => {
  window.braintree = { client:{ create:jest.fn() } };
  const scrollWindowToPosition = jest.fn();
  const document = { getElementById:jest.fn( () =>document.createElement( 'div' ) ) };
  const handleScrollView = jest.fn().mockImplementation( () =>true );

  window.innerWidth = 993;
  let props1 = {
    isMobileDevice: false,
    match: {
      path: '/bag'
    },
    homepage: {
      mainContent: []
    },
    switchData: {
      switches: {
        guestServiceHours: '7am-11pm',
        enableReflektionTag: true
      }
    },
    recommendedProducts: {
      recommendedProducts: {
        errorMessage: null,
        errorCode: null,
        pageId: null,
        productItems: [{
          strategyMesssage: 'Previously Viewed',
          productItemsList: [
            {
              clickURL: 'http://integration.richrelevance.com/rrserver/apiclick?a=f42e6dcbc17086cd&cak=17a88ce787db5c27&ct=http%3A%2F%2Fda3.ulta.com%2Fvinylux-weekly-polish%3FproductId%3DxlsImpprod11351077&vg=5d9f2ea7-3366-452f-f742-ef57086d146f&stid=1000079&pti=3&pa=8316&pos=3&p=xlsImpprod11351077&channelId=17a88ce787db5c27&s=967294371893567744&u=967294371893567744',
              skuImageUrl: null,
              childSkuId: null,
              numReviews: '507',
              rating: null,
              productBrandName: null,
              isGwp: 0,
              adbugMessage: null,
              showListRange: true,
              lowRangeListPrice: 10.5,
              reviewCount: null,
              showListAndSaleRange: false,
              highRangeSalePrice: 0,
              onSale: false,
              multiSku: true,
              productImageUrl: '//images.ulta.com/is/image/Ulta/2281501?$md$',
              prodParentCatId: 'cat80068',
              brandName: 'Cnd',
              activeSkusCount: 28,
              productId: 'xlsImpprod11351077',
              dfltSkuId: '2281501',
              salePrice: 0,
              parentCatDispName: 'Nail Polish',
              badges: [{
                badgeName: 'isNew_badge',
                priority: 8,
                imageURL: 'http://images.ulta.com/is/image/Ulta/badge-whats-new'
              }],
              badge: null,
              powerReviewRating: '4.0',
              productDisplayName: 'Vinylux Weekly Polish',
              lowRangeSalePrice: 0,
              skuDisplayName: null,
              ratingDecimal: null,
              highRangeListPrice: 10.5,
              listPrice: 0,
              promotionDO: null,
              varaintDispName: 'Colors'
            }
          ],
          placmentName: 'cart_page.rvi'
        }

        ],
        productIds: null,
        success: true,
        trackingId: null
      }
    },
    messages: {
      items: [
        {
          type: 'Info',
          message: 'Looks like you have items in your bag from before.'
        }
      ]
    },
    itemCount: '3'
  };
  props1.requestPageData = jest.fn();
  const store = configureStore( {}, CONFIG );
  store.getState().global = {
    switchData: {
      switches: {
        guestServiceHours: '7am-11pm',
        enableReflektionTag: true
      }
    }
  };
  store.getState().minicart = {
    quantity: 4,
    giftText: 'Happy Birthday',
    giftBoxToggle: true,
    showBagSummary: true,
    setShowBagSummaryStatus: jest.fn(),
    productSampleCatalogID: '',
    cartRightPanelCollapse: {
      samples: false,
      gifts: false,
      coupons: false
    },
    recommendedProducts: {
      recommendedProducts: {
        errorMessage: null,
        errorCode: null,
        pageId: null,
        productItems: [{
          strategyMesssage: 'Previously Viewed',
          productItemsList: [
            {
              clickURL: 'http://integration.richrelevance.com/rrserver/apiclick?a=f42e6dcbc17086cd&cak=17a88ce787db5c27&ct=http%3A%2F%2Fda3.ulta.com%2Fvinylux-weekly-polish%3FproductId%3DxlsImpprod11351077&vg=5d9f2ea7-3366-452f-f742-ef57086d146f&stid=1000079&pti=3&pa=8316&pos=3&p=xlsImpprod11351077&channelId=17a88ce787db5c27&s=967294371893567744&u=967294371893567744',
              skuImageUrl: null,
              childSkuId: null,
              numReviews: '507',
              rating: null,
              productBrandName: null,
              isGwp: 0,
              adbugMessage: null,
              showListRange: true,
              lowRangeListPrice: 10.5,
              reviewCount: null,
              showListAndSaleRange: false,
              highRangeSalePrice: 0,
              onSale: false,
              multiSku: true,
              productImageUrl: '//images.ulta.com/is/image/Ulta/2281501?$md$',
              prodParentCatId: 'cat80068',
              brandName: 'Cnd',
              activeSkusCount: 28,
              productId: 'xlsImpprod11351077',
              dfltSkuId: '2281501',
              salePrice: 0,
              parentCatDispName: 'Nail Polish',
              badges: [{
                badgeName: 'isNew_badge',
                priority: 8,
                imageURL: 'http://images.ulta.com/is/image/Ulta/badge-whats-new'
              }],
              badge: null,
              powerReviewRating: '4.0',
              productDisplayName: 'Vinylux Weekly Polish',
              lowRangeSalePrice: 0,
              skuDisplayName: null,
              ratingDecimal: null,
              highRangeListPrice: 10.5,
              listPrice: 0,
              promotionDO: null,
              varaintDispName: 'Colors'
            }
          ],
          placmentName: 'cart_page.rvi'
        }

        ],
        productIds: null,
        success: true,
        trackingId: null
      }
    },
    cartPageData: {
      cartSummary: {
        shippingCost: 0,
        subTotal: 0,
        itemCount: '3',
        additionalDiscount: '',
        couponDiscount: 0,
        estimatedTax: 'TBD',
        giftBox: '',
        estimatedTotal: 0
      },
      cartItems: {
        items: [
          {
            'commerceItemId': 'ci108397018736',
            'brandName': 'Laura Geller Beauty',
            'displayType':'default',
            'quantity': {
              value:9,
              messages:null
            },
            'productId': 'xlsImpprod2240027',
            'displayName': 'Balance N Brighten',
            'catalogRefId': '2218588',
            'priceInfo': {
              'regularPrice': '$19.98',
              'salePrice': null,
              'unitPriceMessage': '1 @ $5,1 @ $9.99'
            },
            'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$',
            'maxQty': 10,
            'adbugMessageMap': {
              'adbugMessage': 'Buy 1, get 1 at 50% off! ',
              'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
            },
            'hazmatCode': '',
            'excludedFromCoupon': true,
            'discountMessage': 'Discount Applied!',
            'couponApplied': true,
            'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
            'variantInfo': {
              'color': 'Red',
              'size': '7oz'
            },
            'errorMsg': ''
          },
          {
            'commerceItemId': 'ci108397018736',
            'brandName': 'Laura Geller Beauty',
            'displayType':'removed',
            'quantity': {
              value:9,
              messages:null
            },
            'productId': 'xlsImpprod2240027',
            'displayName': 'Balance N Brighten',
            'catalogRefId': '2218588',
            'priceInfo': {
              'regularPrice': '$19.98',
              'salePrice': null,
              'unitPriceMessage': '1 @ $5,1 @ $9.99'
            },
            'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$',
            'maxQty': 10,
            'adbugMessageMap': {
              'adbugMessage': 'Buy 1, get 1 at 50% off! ',
              'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
            },
            'hazmatCode': '',
            'excludedFromCoupon': true,
            'discountMessage': 'Discount Applied!',
            'couponApplied': true,
            'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
            'variantInfo': {
              'color': 'Red',
              'size': '7oz'
            },
            'errorMsg': ''
          }
        ]
      },
      giftOptions: {
        giftBoxProductId: 'prod9990099',
        giftBoxPrice: 0,
        giftHeaderMessage: 'Add Gift Box & A Personal Message',
        giftBoxSelected: false,
        giftAdditionalMessage: 'Prices will be hidden on the receipt',
        giftBoxSkuId: '9990099',
        giftBoxDesc: 'Ulta.com Gift Packaging (One Charge Per Order)',
        giftBoxImageURL: 'http://images.ulta.com/is/image/Ulta/9990099?$md$',
        giftNote: 'Happy Birthday Teja'
      },
      freeSamplesInfo: {
        messages: {
          items: [
            {
              type: 'Info',
              message: null
            }
          ]
        },
        items: [
          {
            catalogRefId: '2252998',
            sampleDesc: 'Fragrance',
            shippingRestriction: 'Cannot ship to selected address',
            selected: false
          },
          {
            catalogRefId: '2252999',
            sampleDesc: 'Skincare',
            shippingRestriction: null,
            selected: false
          },
          {
            catalogRefId: '2253000',
            sampleDesc: 'Variety',
            shippingRestriction: null,
            selected: false
          }
        ]
      },
      appliedCouponSummary: {
        couponAppliedStatus: false,
        couponOfferReqNotMet: true,
        couponDescription: [
          '$10 off any $30 purchase CPW12345',
          '$2 off any $30 purchase CPW12345'
        ],
        couponAppliedMsg: 'CPW13345 has been applied',
        couponCode: 'CPW12345',
        couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
      },
      messages: {
        items: [
          {
            type: 'Info',
            message: 'Looks like you have items in your bag from before.'
          }
        ]
      }
    }
  }

  let component = mountWithIntl(
    <Provider store={ store }>
      <ConnectedCartPage { ...props1 } />
    </Provider>
  );
  it( 'Should contain ProductRecs component', () => {
    expect( component.find( 'ProductRecs' ).length ).toBe( 1 );
  } );
  it( 'Should contain Divider components under HeaderSummary component', () => {
    expect( component.find( '.CartPage__headerbag--divider' ).length ).toBe( 2 );
  } );
  it( 'Should have a Reflektion data-rfkid attribute if enableReflektionTag is true', ()=> {
    expect( component.find( '.CartPage__ProductRecs' ).prop( 'data-rfkid' ) ).toBeTruthy();
  } );
  it( 'Should contain Anchor tag', () => {
    let props = {
      isMobileDevice: false,
      match: {
        path: '/bag'
      }
    };
    store.getState().minicart = {
      quantity: 4,
      giftText: 'Happy Birthday',
      giftBoxToggle: true,
      showBagSummary: true,
      setShowBagSummaryStatus: jest.fn(),
      cartPageData: {
        cartSummary: {
          shippingCost: 0,
          subTotal: 0,
          itemCount: '3',
          additionalDiscount: '',
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftBox: '',
          estimatedTotal: 0
        },
        giftItems: {
          items: [
            {
              freeGifts: {
                items: [
                  {
                    giftCatalogRefId: '112023775',
                    giftVariant: 'Silver',
                    giftDisplayName: 'Eternity for Men Eau de Toilette',
                    giftImageURL: 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
                    selected: 'false',
                    giftBrandName: 'Calvin Klein',
                    giftPdpUrl: 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
                  },
                  {
                    giftCatalogRefId: '132023776',
                    giftVariant: 'XXX',
                    giftDisplayName: 'Hair Building Fibers-Medium Blonde',
                    giftImageURL: 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
                    selected: 'default',
                    giftBrandName: 'Calvin Klein',
                    giftHazmatRestriction: 'Can\'t be shipped via air',
                    giftPdpUrl: 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
                  }
                ]
              },
              promoId: 1143243243,
              indulge: true
            }
          ]
        }
      },
      itemCount:'3'
    }

    let component2 = mountWithIntl(
      <Provider store={ store }>
        <ConnectedCartPage { ...props } />
      </Provider>
    );
    expect( component2.find( '.CartPage__gwpmessage .CartPage__gwpmessage--addmessage' ).length ).toBe( 1 );
    expect( component2.find( '.CartPage__gwpmessage--addmessage' ).text() ).toEqual( messages.addmessage.defaultMessage );
    expect( component2.find( '.CartPage__gwpmessage--title' ).text() ).toEqual( messages.gwpmessage.defaultMessage );
  } );
} );
