/**
 * CheckOutRedeemPoints
 */

import React, { Component } from 'react';
import './CheckOutRedeemPoints.css';
import { Collapse } from 'react-bootstrap';
import MixedMenuButton from 'shared/components/MixedMenuButton/MixedMenuButton';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './CheckOutRedeemPoints.messages';
import Anchor from 'shared/components/Anchor/Anchor';
import classNames from 'classnames';
import Select from 'react-select';
import { isEmpty, has } from 'lodash';
import 'react-select/dist/react-select.css';
import Divider from 'shared/components/Divider/Divider';
import isUndefined from 'lodash/isUndefined';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import { fireAnalyticsEvent } from 'utils/Omniture/Omniture';
import PropTypes from 'prop-types';
const propTypes={
  user: PropTypes.object,
  getRedeemPoints: PropTypes.func,
  redeemPoints: PropTypes.object,
  loyaltyCardDetails: PropTypes.object,
  updatePaymentServiceResponse: PropTypes.func,
  removePaymentService: PropTypes.func,
  isRewardPointsRemoved: PropTypes.bool,
  placeHolder: PropTypes.string,
  broadcastMessage: PropTypes.func
}

const defaultProps = {
  placeHolder: 'Select Rewards Points'
}

/**
 * Class
 * @extends React.Component
 */
class CheckOutRedeemPoints extends Component{

  /**
   * Create a CheckOutRedeemPoints
   */
  constructor( props ){
    super( props );
    const loyaltyPoints = this.getSelectedRedeemPoints();
    this.state = {
      showRedeemPointsPanel: false,
      selectedPoint: { value: loyaltyPoints ? loyaltyPoints.paymentInfo.paymentDetails.pointsApplied : undefined }
    };
    this.toggleRedeemPointsPanel = this.toggleRedeemPointsPanel.bind( this );
    this.onRedeemPointChange = this.onRedeemPointChange.bind( this );
    this.removeRedeemCard = this.removeRedeemCard.bind( this );

  }

  getSelectedRedeemPoints(){
    if( has( this.props, 'loyaltyCardDetails.paymentInfo' ) ){
      return this.props.loyaltyCardDetails;
    }
  }

  onRedeemPointChange( selectedPoint = {} ){
    let data =
      {
        values: {
          paymentType: 'loyalty',
          loyaltyPoints: selectedPoint.value,
          loyaltyAmount: selectedPoint.labelActualValue
        }
      }
    this.props.updatePaymentServiceResponse( data );
    this.setState( { selectedPoint } );
  }

  toggleRedeemPointsPanel(){
    this.setState( { showRedeemPointsPanel: !this.state.showRedeemPointsPanel } )
  }

  removeRedeemCard(){
    this.setState( { showRedeemPointsPanel: false, selectedPoint: {} } )

    let data =
      {
        values: {
          paymentType: 'loyalty'
        }
      }
    this.props.removePaymentService( data );
  }

  componentWillMount(){
    this.props.getRedeemPoints( )
  }

  componentDidUpdate( prevProps ){
    if( this.props.isRewardPointsRemoved !== prevProps.isRewardPointsRemoved ){
      if( this.props.isRewardPointsRemoved ){
        this.props.broadcastMessage( formatMessage( messages.rewardPointsRemoved ) );
      }
      else {
        this.props.broadcastMessage( '' );
      }
    }
  }

  /**
   * Renders the CheckOutRedeemPoints component
   */

  render(){

    const {
      user,
      redeemPoints = {},
      isRewardPointsRemoved
    } = this.props;

    const redeemPointTotal = this.props.user.rewardPointTotal;
    const loyaltyCardDetails = this.props.loyaltyCardDetails;
    const isError = !loyaltyCardDetails.paymentInfo && loyaltyCardDetails.messages || redeemPoints.messages;
    try {
      if( this.props ){
        return (
          <div
            className='CheckOutRedeemPoints'
            role='region'
            aria-live='assertive'
          >
            { ( () =>{
              if( this.props.user.rewardPointTotal > 0 ){
                return (
                  <div>
                    { ( () =>{
                      if( ( has( this.props, 'loyaltyCardDetails.paymentInfo' ) && has( this.state.selectedPoint, 'value' ) ) || isError ){
                        return (
                          <div className='CheckOutRedeemPoints__full'>
                            {
                              ( () =>{
                                if( isError ){

                                  let analyticsEvent =
                                    {
                                      eventName: 'trackErrorDisplayed',
                                      data: {
                                        'errorType': 'form',
                                        'errorLabel': 'redeem points',
                                        'errorDescription': redeemPoints.messages.concat( loyaltyCardDetails.messages )
                                      }
                                    };

                                  fireAnalyticsEvent( analyticsEvent.name, analyticsEvent.data );

                                  return (
                                    <div className='CheckOutRedeemPoints__errorSection'>
                                      { ( redeemPoints.messages || [] ).concat( ( loyaltyCardDetails.messages || [] ) ).map( ( message, index ) =>{
                                        return (
                                          <div>
                                            <div className='CheckOutRedeemPoints__titleError'>
                                              { formatMessage( messages.checkOutRedeemPointsTitle ) }
                                            </div>
                                            <ResponseMessages
                                              key={ index }
                                              message={ message.messageDesc }
                                            />
                                          </div>
                                        )
                                      } ) }
                                    </div>

                                  )
                                }
                              } )()
                            }
                            { ( () =>{
                              if( !isError ){
                                const amount = loyaltyCardDetails.paymentInfo.amount;
                                const pointsApplied = loyaltyCardDetails.paymentInfo.paymentDetails.pointsApplied;
                                const pointsBalance = ( loyaltyCardDetails.paymentInfo.paymentDetails.pointsBalance === 0 )
                                  ? '0'
                                  : loyaltyCardDetails.paymentInfo.paymentDetails.pointsBalance;
                                return (
                                  <div className='CheckOutRedeemPoints__redeemPointsApplied'>

                                    <MixedMenuButton
                                      label={ formatMessage( messages.pointsData1, { amount, pointsApplied } ) }
                                      details={ formatMessage( messages.pointsData2, { pointsBalance } ) }
                                      pointerType='collapse'
                                      pointerMinus={ this.state.showRedeemPointsPanel }
                                      onClick={ this.toggleRedeemPointsPanel }
                                    />
                                    <span className='CheckOutRedeemPoints_remove'>
                                      <Anchor
                                        clickHandler={ this.removeRedeemCard }
                                        ariaLabel={ formatMessage( messages.removeRewards ) }
                                      >
                                        { formatMessage( messages.removeThis ) }
                                      </Anchor>
                                    </span>

                                  </div>
                                )
                              }
                            } )() }

                          </div>
                        )
                      }
                      else if( !this.state.selectedPoint.value || this.state.selectedPoint.value > 10 ){
                        return (
                          <div>
                            <MixedMenuButton
                              label={ formatMessage( messages.checkOutRedeemPointsTitle ) }
                              details={ formatMessage( messages.checkOutRedeemPointsMessage, { redeemPointTotal } ) }
                              pointerType='collapse'
                              pointerMinus={ this.state.showRedeemPointsPanel }
                              onClick={ this.toggleRedeemPointsPanel }
                            />

                            { ( () =>{
                              const options = ( redeemPoints.profileRedeemLevels || [] ).map( reward =>{
                                return {
                                  value: reward.points,
                                  label: reward.points + formatMessage( messages.pointsDollar ) + formatMessage( messages.dollar ) + reward.value,
                                  labelActualValue: reward.value
                                }
                              } )
                              return (
                                <Collapse in={ this.state.showRedeemPointsPanel }>
                                  <div className='CheckOutRedeemPoint__collapse'>
                                    <div className='CheckOutRedeemPoints__CollapseContainer'>

                                      <Select
                                        autoBlur
                                        openOnFocus
                                        clearable={ true }
                                        className='CheckOutRedeemPoints__dropdown'
                                        placeholder={ this.props.placeHolder }
                                        options={ options }
                                        value={ this.state.selectedPoint.value }
                                        onChange={ this.onRedeemPointChange }
                                      >
                                      </Select>

                                    </div>
                                  </div>
                                </Collapse>
                              )
                            } )() }


                          </div>

                        )
                      }
                    } )()
                    }


                  </div>
                );
              }
              else {
                return (
                  <div className='CheckOutRedeemPoints__noRedeem'>
                    <div className='CheckOutRedeemPoints__title'>
                      { formatMessage( messages.checkOutRedeemPointsTitle ) }
                    </div>
                    <div className='CheckOutRedeemPoints__redeemMessage'>
                      { formatMessage( messages.noRedeem ) }
                    </div>
                  </div>
                );
              }
            } )() }
          </div>
        );
      }
    }
    catch ( e ){
      return null;
    }
  }
}

CheckOutRedeemPoints.propTypes = propTypes;
CheckOutRedeemPoints.defaultProps = defaultProps;

export default CheckOutRedeemPoints;

