/**
 * Created by satchuyutuni on 6/13/17.
 */
/*
 * CheckOutRedeemPoints Messages
 *
 * This contains all the text for the CheckOutRedeemPoints component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  checkOutRedeemPointsTitle: {
    id: 'i18n.CheckOutRedeemPoints.checkOutRedeemPointsTitle',
    defaultMessage: 'Redeem Ultamate Rewards Points'
  },
  checkOutRedeemPointsMessage: {
    id: 'i18n.CheckOutRedeemPoints.checkOutRedeemPointsMessage',
    defaultMessage: 'You have {redeemPointTotal} points. '
  },
  removeThis: {
    id: 'i18n.CheckOutRedeemPoints.remove',
    defaultMessage: 'Remove'
  },
  removeRewards: {
    id: 'i18n.CheckOutRedeemPoints.removeRewards',
    defaultMessage: 'Remove Rewards'
  },
  label: {
    id: 'i18n.CheckOutRedeemPoints.label',
    defaultMessage: 'LABEL'
  },
  pointsData1: {
    id: 'i18n.CheckOutRedeemPoints.pointsData1',
    defaultMessage: '$ {amount} ({pointsApplied} points) Applied! '
  },
  pointsData2: {
    id: 'i18n.CheckOutRedeemPoints.pointsData2',
    defaultMessage: ' Rewards Points Balance : {pointsBalance} pts'
  },
  noRedeem: {
    id: 'i18n.CheckOutRedeemPoints.noRedeem',
    defaultMessage: 'You do not have enough points to redeem online.'
  },
  dollar: {
    id: 'i18n.CheckOutRedeemPoints.dollar',
    defaultMessage: '$'
  },
  pointsDollar:{
    id: 'i18n.CheckOutRedeemPoints.pointsDollar',
    defaultMessage: ' points = '
  },
  rewardPointsRemoved:{
    id: 'i18n.CheckOutRedeemPoints.rewardPointsRemoved',
    defaultMessage: 'Rewards have been removed'
  }
} );
