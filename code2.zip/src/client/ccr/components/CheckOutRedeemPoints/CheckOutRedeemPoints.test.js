import React from 'react';
import ReactDOM from 'react-dom';
import CheckOutRedeemPoints from './CheckOutRedeemPoints';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './CheckOutRedeemPoints.messages';


describe( '<CheckOutRedeemPoints />', () => {
  let component;
  let props = {
    user: { rewardPointTotal: 20 },
    getRedeemPoints: jest.fn(),
    toggleRedeemPointsPanel: jest.fn(),
    showRedeemPointsPanel: {},
    loyaltyCardDetails : {}

  }


  component = mountWithIntl( <CheckOutRedeemPoints { ...props } /> );
  it( 'renders without crashing', () => {
    expect( component.find( 'CheckOutRedeemPoints' ).length ).toBe( 1 );
  } );
  it( 'Should contain MixedMenuButton component', () => {
    expect( component.find( 'MixedMenuButton' ).length ).toBe( 1 );
  } );
  it( 'Should contain Anchor component', () => {
    expect( component.find( 'Anchor' ).length ).toBe( 1 );
  } );
  it( 'Should contain Select component', () => {
    expect( component.find( 'Select' ).length ).toBe( 1 );
  } );
  it( 'Should contain Select component has the placeholder', () => {
    expect( component.find( 'Select' ).props().placeholder ).toBe( 'Select Rewards Points' );
  } );

  props.removePaymentService = jest.fn();
  props.updatePaymentServiceResponse = jest.fn();
  let component1 = mountWithIntl( <CheckOutRedeemPoints { ...props } /> );
  const instance = component1.find( 'CheckOutRedeemPoints' ).instance();

  it( 'should change the showRedeemPointsPanel value', () => {
    expect( instance.state.showRedeemPointsPanel ).toEqual( false );
    instance.toggleRedeemPointsPanel();
    expect( instance.state.showRedeemPointsPanel ).toEqual( true );
  } );

  it( 'should call the onRedeemPointChange method', () => {
    expect( instance.state.selectedPoint ).toEqual( { undefined } );
    instance.onRedeemPointChange( instance.state.selectedPoint );
    let data =
      {
        values: {
          paymentType: 'loyalty',
          loyaltyPoints: instance.state.selectedPoint.value,
          loyaltyAmount: instance.state.selectedPoint.labelActualValue
        }
      };
    expect( props.updatePaymentServiceResponse ).toHaveBeenCalledWith( data );
    expect( instance.state.selectedPoint ).toEqual( {} );
  } );

  it( 'should call the removeRedeemCard method', () => {
    expect( instance.state.showRedeemPointsPanel ).toEqual( true );
    instance.removeRedeemCard();
    expect( instance.state.showRedeemPointsPanel ).toEqual( false );
    expect( instance.state.selectedPoint ).toEqual( {} );
    let data =
      {
        values: {
          paymentType: 'loyalty'
        }
      }
    expect( props.removePaymentService ).toHaveBeenCalledWith( data );
  } );

} );

describe( 'MixedMenuButton', () => {
  let component;
  let props = {
    user: { rewardPointTotal: 20 },
    getRedeemPoints: jest.fn(),
    toggleRedeemPointsPanel: jest.fn(),
    showRedeemPointsPanel: {},
    loyaltyCardDetails : {}

  }
  component = mountWithIntl( <CheckOutRedeemPoints { ...props } /> );

  it( 'Should contain label MixedMenuButton component', () => {
    expect( component.find( 'MixedMenuButton' ).props().label ).toBe( messages.checkOutRedeemPointsTitle.defaultMessage );
  } );

  it( 'Should contain label MixedMenuButton', () => {
    expect( component.find( 'MixedMenuButton' ).props().details ).toBe( 'You have 20 points. ' );
  } );

} );

describe( '<CheckOutRedeemPoints /> rewards points applied view', () => {
  const props = {
    user: { rewardPointTotal: 20 },
    getRedeemPoints: jest.fn(),
    toggleRedeemPointsPanel: jest.fn(),
    showRedeemPointsPanel: {},
    loyaltyCardDetails : {
      paymentInfo: {
        paymentDetails:{
          pointsApplied : 50
        }
      }
    }
  }
  const component = mountWithIntl( <CheckOutRedeemPoints { ...props } /> );
  const node = component.find( 'CheckOutRedeemPoints' ).instance();

  node.state.selectedPoint = {
    value: 10
  };

  it( 'aria label should be present for the Anchor tag - Remove', () => {
    expect( component.find( '.CheckOutRedeemPoints_remove a' ).at( 0 ).props()['aria-label'] ).toBe( messages.removeRewards.defaultMessage );
  } );
} );

describe( '<CheckOutRedeemPoints /> Rendering Reward points message', () => {

  it( 'broadcast message is invoked with the rewards removed message', () => {
    const broadcastMessageMock = jest.fn();
    const props = {
      user: { rewardPointTotal: 20 },
      getRedeemPoints: jest.fn(),
      toggleRedeemPointsPanel: jest.fn(),
      showRedeemPointsPanel: {},
      loyaltyCardDetails : {},
      isRewardPointsRemoved: true,
      broadcastMessage:broadcastMessageMock
    }
    const prevProps = {}
    const component = mountWithIntl( <CheckOutRedeemPoints { ...props } /> );
    component.find( 'CheckOutRedeemPoints' ).instance().componentDidUpdate( prevProps );
    expect( broadcastMessageMock ).toBeCalledWith( messages.rewardPointsRemoved.defaultMessage );
  } );
} );

describe( '<CheckOutRedeemPoints /> Removing Reward points message', () => {

  it( 'Reward points removed message will be removed when isRewardPointsRemoved is false', () => {
    const broadcastMessageMock = jest.fn();
    const props = {
      user: { rewardPointTotal: 20 },
      getRedeemPoints: jest.fn(),
      toggleRedeemPointsPanel: jest.fn(),
      showRedeemPointsPanel: {},
      loyaltyCardDetails : {},
      isRewardPointsRemoved: false,
      broadcastMessage:broadcastMessageMock
    }
    const prevProps = {
      isRewardPointsRemoved: true
    }
    const component = mountWithIntl( <CheckOutRedeemPoints { ...props } /> );
    component.find( 'CheckOutRedeemPoints' ).instance().componentDidUpdate( prevProps );
    expect( broadcastMessageMock ).toBeCalledWith( '' );
  } );
} );