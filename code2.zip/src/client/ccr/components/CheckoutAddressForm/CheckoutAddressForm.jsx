/**
 * CheckoutAddressForm
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './CheckoutAddressForm.css';
import { connect } from 'react-redux';
import { isUndefined, isEqual, keys, pull, values, has, forEach, omitBy, isNil } from 'lodash';
import messages from './CheckoutAddressForm.messages';
import { Field, reduxForm, getFormValues, isValid, change } from 'redux-form';
import AddressForm from 'shared/components/AddressForm/AddressForm';
import InputField from 'shared/components/InputField/InputField';
import ToggleButton from 'shared/components/ToggleButton/ToggleButton';
import Anchor from 'shared/components/Anchor/Anchor';
import Divider from 'shared/components/Divider/Divider';
import Button from 'shared/components/Button/Button';
import Exclamation from 'shared/components/Icons/exclamationcircle';
import VMasker from 'vanilla-masker';
import {
  actions as miniCartActions
} from 'hf/actions/MiniCart/MiniCart.actions';
import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';
import {
  checkDevice
} from 'utils/DeviceDetection/deviceDetection';
import {
  actions,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';
import {
  actions as formActions
} from 'shared/actions/Forms/Forms.actions';
import {
  requiredValidation,
  validate as validationMethod,
  validationKeys
} from 'utils/FormValidations/FormValidations';
import FormValidationMessages from 'utils/FormValidations/FormValidations.messages';
import {
  actions as headerActions
} from 'hf/actions/Header/Header.actions'
import 'shared/components/Gutter/Gutter.css';
import { formatMessage } from 'shared/components/Global/Global';
const propTypes = {
  formName: PropTypes.string,
  addEditAddress: PropTypes.oneOf( ['yes', 'no', ''] ),
  handleCancelAddShippingAddress: PropTypes.func,
  handleAddNewShippingAddress: PropTypes.func,
  changeShippingAddressView: PropTypes.func,
  isAddFormTag: PropTypes.oneOf( ['yes', 'no', ''] ),
  address2Open: PropTypes.bool,
  toggleAddress2FieldDisplay: PropTypes.func,
  toggleInputFieldShippingDisplay: PropTypes.func,
  editAddressData: PropTypes.object,
  shippingValid: PropTypes.bool,
  updateShipMethod: PropTypes.func,
  toggleAddressFieldDisplayPaymentForm: PropTypes.func,
  shippingSuccess: PropTypes.bool,
  addressOpen: PropTypes.bool,
  toggleAddressFieldDisplay: PropTypes.bool,
  handleSubmit: PropTypes.func,
  checkoutFormAddressOpen: PropTypes.object,
  handleScrollToFormError: PropTypes.func
}

const defaultProps = {
  formName: ''
}
export const mapStateToProps = ( state ) => {
  return {
    user: state.user,
    paymentform: ( state.form.paymentForm ),
    shipingform: ( state.form.Shipping ) ? state.form.Shipping : state.form.shippingAddressList,
    shippingData: getFormValues( 'shippingAddressList' )( state ),
    shippingValid: ( state.form.Shipping ) ? isValid( 'Shipping' )( state ) : isValid( 'shippingAddressList' )( state )
  };
}

let formType = 'anonymous';

/**
 * Class
 * @extends React.Component
 */

class CheckoutAddressForm extends Component{

  /**
   * Create a CheckoutAddressForm
   */
  constructor( props ){
    super( props );
    this.validateAddresss = this.validateAddresss.bind( this ) ;
    this.state = {
      isPrimaryAddress: false,
      initialShippingData: {}
    }

    this.makePrimaryAddressToggle = this.makePrimaryAddressToggle.bind( this );
    this.cancelAddShippingAddress = this.cancelAddShippingAddress.bind( this );
    this.addNewShippingAddress = this.addNewShippingAddress.bind( this );
  }
  makePrimaryAddressToggle(){
    this.setState( { isPrimaryAddress: !this.state.isPrimaryAddress } )
  }

  cancelAddShippingAddress(){
    if( this.props.handleCancelAddShippingAddress ){
      this.props.handleCancelAddShippingAddress();
    }
    this.props.toggleInputFieldShippingDisplay();
  }

  addNewShippingAddress( e ){
    let shippingFormData = this.props.shipingform.values;
    let shippingFormError = this.props.shipingform.syncErrors;
    if( shippingFormData ){
      if( shippingFormData.firstNameshippingAddressForm && shippingFormData.lastNameshippingAddressForm && shippingFormData.address1shippingAddressForm && shippingFormData.cityshippingAddressForm && shippingFormData.state && shippingFormData.postalCodeshippingAddressForm && shippingFormData.phoneNumbershippingAddressForm && isUndefined( shippingFormError.firstNameshippingAddressForm )
        && isUndefined( shippingFormError.lastNameshippingAddressForm )
        && isUndefined( shippingFormError.address1shippingAddressForm )
        && isUndefined( shippingFormError.postalCodeshippingAddressForm )
        && isUndefined( shippingFormError.cityshippingAddressForm )
        && isUndefined( shippingFormError.state )
        && isUndefined( shippingFormError.phoneNumbershippingAddressForm ) ){
        let phNumber =  VMasker.toPattern( shippingFormData.phoneNumbershippingAddressForm, '999-999-9999' );

        const postData = {
          values: {
            firstName: shippingFormData.firstNameshippingAddressForm,
            lastName: shippingFormData.lastNameshippingAddressForm,
            address1: shippingFormData.address1shippingAddressForm,
            address2: shippingFormData.address2shippingAddressForm,
            city: shippingFormData.cityshippingAddressForm,
            state: shippingFormData.state,
            postalCode: shippingFormData.postalCodeshippingAddressForm,
            phoneNumber: phNumber,
            primary: this.state.isPrimaryAddress
          }
        }
        if( this.props.editAddressData.refId !== '' ){
          postData.values.shipAddrNickName = this.props.editAddressData.refId;
        }
        this.props.updateShippingStatus( !this.props.shippingValid );
        this.props.updateShipMethod( postData );
        this.props.handleAddNewShippingAddress();
      }
    }
  }

  validateAddresss( e ){

    const {
      values,
      syncErrors
    } = this.props.shipingform;
    const currentTarget=e.currentTarget;

    if(
      values &&
      ( !isEqual( this.state.initialShippingData, values ) ||
        has( this.props, 'shippingInfo.isShippingAddressErrorCleared' )
      ) &&
      values.address1shippingAddressForm &&
      values.postalCodeshippingAddressForm &&
      values.cityshippingAddressForm &&
      values.firstNameshippingAddressForm &&
      values.lastNameshippingAddressForm &&
      values.emailaddressshippingAddressForm &&
      values.state &&
      values.phoneNumbershippingAddressForm &&
      isUndefined( syncErrors.firstNameshippingAddressForm ) &&
      isUndefined( syncErrors.lastNameshippingAddressForm ) &&
      isUndefined( syncErrors.address1shippingAddressForm ) &&
      isUndefined( syncErrors.postalCodeshippingAddressForm ) &&
      isUndefined( syncErrors.emailaddressshippingAddressForm ) &&
      isUndefined( syncErrors.cityshippingAddressForm ) &&
      isUndefined( syncErrors.state ) &&
      isUndefined( syncErrors.phoneNumbershippingAddressForm ) ){

      let phNumber =  VMasker.toPattern( values.phoneNumbershippingAddressForm, '999-999-9999' );
      let newValues ={
        firstName: values.firstNameshippingAddressForm,
        lastName: values.lastNameshippingAddressForm,
        address1:  values.address1shippingAddressForm,
        city: values.cityshippingAddressForm,
        phoneNumber: phNumber,
        email:values.emailaddressshippingAddressForm,
        postalCode : values.postalCodeshippingAddressForm,
        state: values.state,
        isPrimaryAddress:false,
        isPaypalFlag : false,
        ...( values.address2shippingAddressForm && { address2: values.address2shippingAddressForm } )
      }
      setTimeout( function(){
        if( !currentTarget.contains( document.activeElement ) ){
          let postData = {
            values: newValues
          }
          this.props.setEditAddressData( newValues );
          this.props.updateShippingStatus( !this.props.shippingValid );
          this.setState( { initialShippingData: values } );
          this.props.updateShipMethod( postData );
        }
      }.bind( this ), 0 )
    }
  }

  toggleAddressForm(){
    this.props.toggleAddressFieldDisplayPaymentForm( this.props.formName );
  }

  componentWillUnmount(){
    if( this.props.shippingSuccess && this.props.changeShippingAddressView ){
      this.props.changeShippingAddressView();
    }
  }

  componentWillMount(){
    if( !isUndefined( this.props.editAddressData.refId ) ){
      this.setState( { isPrimaryAddress: this.props.editAddressData.isPrimaryAddress } )
    }
  }

  componentDidMount(){
    if( this.props.user.isSignedIn ){
      formType = 'loggedIn';
    }
  }

  componentDidUpdate( prevProps ){
    if( !isEqual( this.props.editAddressData, prevProps.editAddressData ) ){
      forEach( this.props.editAddressData, ( val, key ) => {
        let pair=key+'shippingAddressForm';
        if( key === 'addressData' ){
          forEach( val, ( val1, key1 ) => {
            if( isUndefined( prevProps.editAddressData.addressData ) || this.props.editAddressData.addressData[key1] !== prevProps.editAddressData.addressData[key1] ){
              pair=( key1 !== 'state' ) ? key1 + 'shippingAddressForm' : key1;
              this.props.change( pair, val1 );
            }
          } );
        }
        else if( this.props.editAddressData[key] !== prevProps.editAddressData[key] ){
          this.props.change( pair, val );
        }
      } );
    }
  }


  render(){

    const {
      addressOpen,
      address2Open,
      toggleAddressFieldDisplay,
      toggleAddressFieldDisplayPaymentForm,
      toggleAddress2FieldDisplay,
      formName,
      addEditAddress,
      isAddFormTag,
      handleSubmit
    } = this.props;

    let formData = ( formName === 'shippingAddressForm' ) ? this.props.editAddressData : this.props.editCreditCardData.contactInfo;

    let checkoutAddressFormHTML = ( <div className='CheckoutAddressForm'>


      <div className='CheckoutAddressForm__FirstLastNames'>
        <div className='CheckoutAddressForm__FirstName'>
          <InputField
            label={ formatMessage( messages.FirstName ) }
            type='text'
            name={ `firstName${this.props.formName}` }
            { ...( formData && { value: formData.firstName } ) }
            autoComplete='given-name'
            formName={ formName }
            trackAnalytics={ true }
          />
        </div>

        <div className='CheckoutAddressForm__LastName'>
          <InputField
            label={ formatMessage( messages.LastName ) }
            type='text'
            name={ `lastName${this.props.formName}` }
            { ...( formData && { value: formData.lastName } ) }
            autoComplete='family-name'
            formName={ formName }
            trackAnalytics={ true }
          />
        </div>
      </div>

      <AddressForm
        change={ this.props.change }
        name={ this.props.formName }
        addressFormTitle={ formatMessage( messages.checkoutAddress1 ) }
        addressOneLabel={ formatMessage( messages.checkoutAddress1 ) }
        addressTwoLabel={ formatMessage( messages.checkoutAddress2 ) }
        addressFormID={ this.props.formName }
        addressFormInfo={ ( this.props.formName !=='paymentAddressForm' )? ( this.props.shipingform ) :this.props.paymentform }
        toggleAddressFieldDisplay={ this.toggleAddressForm.bind( this ) }
        toggleAddress2FieldDisplay={ toggleAddress2FieldDisplay }
        addressOpen={ checkDevice( 'iPhone' ) || checkDevice( 'iPad' )? true : ( this.props.formName !=='paymentAddressForm' )? ( this.props.checkoutFormAddressOpen.shippingAddressForm ) : ( this.props.checkoutFormAddressOpen.paymentAddressForm ) }
        { ...( formData && { addressData: formData.addressData } ) }
        address2Open={ ( formData && has( formData.addressData, 'address2' ) && formData.addressData.address2 !==null ) ? true : address2Open }
        trackAnalytics={ true }
      />

      { ( () => {
        if( !this.props.user.isSignedIn && this.props.formName!=='paymentAddressForm' ){
          return (
            <div className='CheckoutAddressForm__Username'>
              <div className='CheckoutAddressForm__UsernameContainer'>
                <InputField
                  label={ formatMessage( messages.emailaddress ) }
                  type='email'
                  name={ `emailaddress${this.props.formName}` }
                  formName={ formName }
                  { ...( formData && { value: formData.emailaddress } ) }
                  autoComplete='email'
                  trackAnalytics={ true }
                />
              </div>
              <div className='CheckoutAddressForm__emailUsage'>
                { formatMessage( messages.emailUsage ) }
              </div>
            </div>
          );
        }
      } )() }

      <div className='CheckoutAddressForm__PhoneNumber'>
        <div className='CheckoutAddressForm__phoneNumberContainer'>
          <InputField
            label={ formatMessage( messages.PhoneNumber ) }
            formatter={ { pattern: '(999) 999-9999' } }
            type='tel'
            name={ `phoneNumber${this.props.formName}` }
            { ...( formData && { value: formData.phoneNumber } ) }
            autoComplete='tel'
            formName={ formName }
            trackAnalytics={ true }

          />
        </div>
        { ( ()=>{
          if( this.props.formName !== 'paymentAddressForm' ){
            return (
              <div className='CheckoutAddressForm__phoneNumberUsage'>
                { formatMessage( messages.phoneNumberUsage ) }
              </div>
            )
          }
        } )() }
      </div>

      { ( () => {
        if( addEditAddress === 'yes' ){
          return (
            <div className='CheckoutAddressForm__addEditAddress'>
              { ( () => {
                if( !formData.isPaypalFlag && !formData.isPrimaryAddress ){
                  return (
                    <div className='CheckoutAddressForm__toggleSection'>
                      <Divider dividerType={ 'gray' } />
                      <div className='CheckoutAddressForm__toggleButtonContainer'>
                        <div className='CheckoutAddressForm__makePrimaryAddress'>
                          { formatMessage( messages.makePrimaryAddress ) }
                        </div>
                        <div className='CheckoutAddressForm__toggleButton'>
                          <label htmlFor='isPrimary' className='sr-only'>{ formatMessage( messages.makePrimaryAddress ) }</label>
                          <ToggleButton
                            id='isPrimary'
                            name='isPrimary'
                            isChecked={ this.state.isPrimaryAddress }
                            onClick={ this.makePrimaryAddressToggle }
                          />
                        </div>
                      </div>
                    </div>
                  );
                }
              } )() }

              <div className='CheckoutAddressForm__cancelDone'>
                <Divider dividerType={ 'gray' } />
                <div className='PaymentForm__shippingAddressFooterMessage'>
                  { formatMessage( messages.shippingAddressFooterMessage ) }
                </div>
                <Anchor
                  url='#'
                  ariaLabel={ formatMessage( messages.cancelAriaLabel ) }
                  title={ formatMessage( messages.cancelAriaLabel ) }
                  clickHandler={ this.cancelAddShippingAddress }
                >
                  { formatMessage( messages.cancel ) }
                </Anchor>
                <span className='CheckoutAddressForm__cancelDone--space'>\</span>
                <Button
                  inputTag='button'
                  btnType='submit'
                  btnSize='xs'
                  btnOption='link'
                  btnOutLine={ false }
                  title={ formatMessage( messages.doneAriaLabel ) }
                >
                  { formatMessage( messages.save ) }
                </Button>
              </div>
            </div>
          );
        }
      } )() }
    </div> )

    if( isAddFormTag === 'yes' ){
      return (
        <form
          className='Gutter'
          onBlur={ this.validateAddresss }
          onSubmit={ handleSubmit( this.addNewShippingAddress ) }
        >
          { checkoutAddressFormHTML }
        </form>
      );
    }
    else {
      return (
        <div>
          { checkoutAddressFormHTML }
        </div>
      );
    }
  }
}

CheckoutAddressForm.propTypes = propTypes;
CheckoutAddressForm.defaultProps = defaultProps;

export const validate = ( values, props ) => {
  const errors = {};
  let requiredFields = [];

  // validate the anonymous usecase

  requiredFields = ['emailaddress'+props.formName, 'firstName'+props.formName, 'lastName'+props.formName, 'address1'+props.formName,
    'city'+props.formName, 'state', 'postalCode'+props.formName, 'phoneNumber'+props.formName];

  // This is added so that we do not validate against a hidden fields
  // Otherwise th fields get tracked as an error in Omniture.

  if( formType !== 'anonymous' ){
    pull( requiredFields, 'emailaddress'+props.formName );
  }
  requiredFields.map(
    field => {
      if( !values[field] ){
        errors[ field ] = requiredValidation( values[ field ] );
      }
    }
  );

  if( values['firstName'+props.formName] ){
    errors['firstName'+props.formName] = validationMethod( values['firstName'+props.formName], validationKeys.firstValidateName, FormValidationMessages.validateFirstName );
  }

  if( values['lastName'+props.formName] ){
    errors['lastName'+props.formName] = validationMethod( values['lastName'+props.formName], validationKeys.lastValidateName, FormValidationMessages.validateLastName );
  }

  if( values['emailaddress'+props.formName] ){
    errors['emailaddress'+props.formName] = validationMethod( values['emailaddress'+props.formName], validationKeys.validateEmail, FormValidationMessages.invalidEmail );
  }

  if( values['phoneNumber'+props.formName] ){
    errors['phoneNumber'+props.formName] = validationMethod( values['phoneNumber'+props.formName], validationKeys.validatePhone, FormValidationMessages.invalidPhoneNumber );
  }


  if( values['postalCode'+props.formName] ){
    errors['postalCode'+props.formName] = validationMethod( values['postalCode'+props.formName], validationKeys.validateZipCode, FormValidationMessages.invalidZipCode );
  }


  return errors;
}

export const onSubmitFail = ( errors, dispatch, submitError, props ) => {
  let analyticErrors = [];
  analyticErrors.push( { 'CheckoutAddressFormErrors':  omitBy( errors, isNil ) } );

  let evt = {
    'name': 'trackErrorDisplayed',
    'data': analyticErrors
  }
  dispatch( analyticActions.triggerAnalyticsEvent( evt ) );

  // handle scroll to error fields
  props.handleScrollToFormError( errors );
}

export const mapDispatchToProps = ( dispatch ) => {
  return {
    changeFieldValue: function( field, value ){
      dispatch( change( 'Shipping', field, value ) )
    }
  };
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return reduxForm( {
    form: 'Shipping',
    validate,
    onSubmitFail
  } )( connect( mapStateToProps, mapDispatchToProps )( CheckoutAddressForm ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );