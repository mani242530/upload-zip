/*
 * CheckoutAddressForm Messages
 *
 * This contains all the text for the CheckoutAddressForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.CheckoutAddressForm.header',
    defaultMessage: 'This is the CheckoutAddressForm component !'
  },
  Address: {
    id: 'i18n.CheckoutAddressForm.Address',
    defaultMessage: 'Address'
  },
  FirstName: {
    id: 'i18n.CheckoutAddressForm.FirstName',
    defaultMessage: 'First Name'
  },
  LastName: {
    id: 'i18n.CheckoutAddressForm.LastName',
    defaultMessage: 'Last Name'
  },
  emailaddress: {
    id: 'i18n.CheckoutAddressForm.emailaddress',
    defaultMessage: 'Email Address'
  },
  emailUsage: {
    id: 'i18n.CheckoutAddressForm.emailUsage',
    defaultMessage: 'Used for order confirmation only'
  },
  PhoneNumber: {
    id: 'i18n.CheckoutAddressForm.PhoneNumber',
    defaultMessage: 'Phone Number'
  },
  phoneNumberUsage: {
    id: 'i18n.CheckoutAddressForm.phoneNumberUsage',
    defaultMessage: 'Used for shipping issues only.'
  },
  makePrimaryAddress: {
    id: 'i18n.CheckoutAddressForm.makePrimaryAddress',
    defaultMessage: 'Make this my primary shipping address'
  },
  save: {
    id: 'i18n.ShippingAddress.save',
    defaultMessage: 'Save'
  },
  doneAriaLabel: {
    id: 'i18n.QualifiedShippingMethodList.doneAriaLabel',
    defaultMessage: 'Click or enter to add a new shipping address'
  },
  cancel: {
    id: 'i18n.ShippingAddress.cancel',
    defaultMessage: 'Cancel'
  },
  cancelAriaLabel: {
    id: 'i18n.QualifiedShippingMethodList.cancelAriaLabel',
    defaultMessage: 'Click to cancel the changes'
  },
  shippingAddressFooterMessage: {
    id: 'i18n.QualifiedShippingMethodList.shippingAddressFooterMessage',
    defaultMessage: 'Your address will be saved to your account.'
  },
  checkoutAddress1:{
    id: 'i18n.CheckoutAddressForm.checkoutAddress1',
    defaultMessage: 'Address'
  },
  checkoutAddress2:{
    id: 'i18n.CheckoutAddressForm.checkoutAddress1',
    defaultMessage: 'Address 2 (Optional)'
  }
} );
