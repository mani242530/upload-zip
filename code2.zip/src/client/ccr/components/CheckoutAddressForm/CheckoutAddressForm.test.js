import React from 'react';
import ReactDOM from 'react-dom';
import CheckoutAddressForm, { initialState } from './CheckoutAddressForm';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import messages from './CheckoutAddressForm.messages';

jest.useFakeTimers( );
describe( '<CheckoutAddressForm />', () => {
  const store = configureStore( {}, CONFIG );
  let props = initialState;
  props={
    toggleAddressFieldDisplayPaymentForm: jest.fn(),
    addEditAddress:'yes',
    checkoutFormAddressOpen: {
      paymentAddressForm: false,
      shippingAddressForm: true
    },
    editAddressData: {
      refId:'',
      isPaypalFlag:false,
      isPrimaryAddress: false
    },
    editCreditCardData:{
      refId:'',
      contactInfo:{

      }
    },
    formName:'shippingAddressForm'
  }

  store.getState().user.isSignedIn=false;

  let component = mountWithIntl(
    <Provider store={ store }>
      <CheckoutAddressForm { ...props }/>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'CheckoutAddressForm' ).length ).toBe( 1 );
  } );


  it( 'renders Field components', () => {
    expect( component.find( '.CheckoutAddressForm' ).find( 'InputField' ).length ).toBe( 7 );
    expect( component.find( '.CheckoutAddressForm' ).find( 'SelectField' ).length ).toBe( 1 );
  } );

  it( 'renders AddressForm component', () => {
    expect( component.find( 'AddressForm' ).length ).toBe( 1 );
  } );

  it( 'displays label message for the input boxes', () => {
    expect( component.find( '.CheckoutAddressForm__FirstName' ).text() ).toBe( messages.FirstName.defaultMessage );
    expect( component.find( '.CheckoutAddressForm__LastName' ).text() ).toBe( messages.LastName.defaultMessage );
    expect( component.find( '.CheckoutAddressForm__Username' ).text() ).toBe( messages.emailaddress.defaultMessage + messages.emailUsage.defaultMessage );
    expect( component.find( '.CheckoutAddressForm__PhoneNumber' ).text() ).toBe( messages.PhoneNumber.defaultMessage + messages.phoneNumberUsage.defaultMessage );
    expect( component.find( '.CheckoutAddressForm__Username InputField' ).length ).toBe( 1 );

  } );

  it( 'Scroll to top on submitFail', () => {
    expect( component.find( 'CheckoutAddressForm' ).length ).toBe( 1 );
    component.find( '.CheckoutAddressForm' ).find( 'Button' ).simulate( 'click' );
    expect( component.find( '.ResponseMessages__message--error' ).length ).toBe( 0 );
  } );

  it( 'The id of the toggle button and the htmlFor of the label element should match', () => {
    expect( component.find( '.CheckoutAddressForm__toggleButton' ).children( 'label' ).text() ).toBe( messages.makePrimaryAddress.defaultMessage );
    expect( component.find( '.ToggleButton__checkbox' ).props()['id'] ).toBe( component.find( '.CheckoutAddressForm__toggleButton' ).children( 'label' ).props()['htmlFor'] );
  } );

  it( 'Should not render EmailID field if form name is paymentAddressForm or if user is signed in', () => {
    let props1={
      toggleAddressFieldDisplayPaymentForm: jest.fn(),
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      editAddressData: {
        refId:'',
        isPaypalFlag:true
      },
      editCreditCardData:{
        refId:'',
        contactInfo:{
        }
      },
      formName:'paymentAddressForm'
    }

    let component1 = mountWithIntl(
      <Provider store={ store }>
        <CheckoutAddressForm { ...props1 }/>
      </Provider>
    );
    expect( component1.find( '.CheckoutAddressForm__Username' ).length ).toBe( 0 );
  } );

  it( 'should render form component', () => {
    expect( component.find( 'Form' ).length ).toBe( 1 );
  } );
  it( 'should render toggle button component when primary address flag is false', () => {
    expect( component.find( '.CheckoutAddressForm__toggleSection' ).length ).toBe( 1 );
    expect( component.find( 'ToggleButton' ).length ).toBe( 1 );
  } );
  it( 'should not render toggle button component when primary address flag is true', () => {
    props.editAddressData.isPrimaryAddress=true;
    let component2 = mountWithIntl(
      <Provider store={ store }>
        <CheckoutAddressForm { ...props }/>
      </Provider>
    );
    expect( component2.find( '.CheckoutAddressForm__toggleSection' ).length ).toBe( 0 );
    expect( component2.find( 'ToggleButton' ).length ).toBe( 0 );
  } );

  it( 'If the mobile is iphone the collapse should open', () => {
    navigator.__defineGetter__( 'userAgent', function(){
      return 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1';
    } );
    let component3 = mountWithIntl(
      <Provider store={ store }>
        <CheckoutAddressForm { ...props }/>
      </Provider>
    );

    expect( component3.find( 'InputField' ).at( 3 ).length ).toBe( 1 );
    expect( component3.find( 'InputField' ).at( 4 ).length ).toBe( 1 );
    expect( component3.find( 'SelectField' ).length ).toBe( 1 );
  } );

  it( 'If the mobile is ipad the collapse should open', () => {
    navigator.__defineGetter__( 'userAgent', function(){
      return 'Mozilla/5.0 (iPad; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1';
    } );
    let component3 = mountWithIntl(
      <Provider store={ store }>
        <CheckoutAddressForm { ...props }/>
      </Provider>
    );

    expect( component3.find( 'InputField' ).at( 3 ).length ).toBe( 1 );
    expect( component3.find( 'InputField' ).at( 4 ).length ).toBe( 1 );
    expect( component3.find( 'SelectField' ).length ).toBe( 1 );
  } );

  it( 'It should show phone number helper text if the form type is shippingAddressForm', () => {
    props.formName='shippingAddressForm';
    let component = mountWithIntl(
      <Provider store={ store }>
        <CheckoutAddressForm { ...props }/>
      </Provider>
    );

    expect( component.find( '.CheckoutAddressForm__phoneNumberUsage' ).length ).toBe( 1 );
  } );

  it( 'It should not show phone number helper text if the form type is paymentAddressForm', () => {
    props.formName='paymentAddressForm';
    let component = mountWithIntl(
      <Provider store={ store }>
        <CheckoutAddressForm { ...props }/>
      </Provider>
    );

    expect( component.find( '.CheckoutAddressForm__phoneNumberUsage' ).length ).toBe( 0 );
  } );

  it( 'it should invoke change() if there is any change in addressData', () => {

    const changeMock = jest.fn();

    const editAddressData = {
      firstName: 'John',
      lastName: 'CS',
      phoneNumber: '513-791-2513',
      isPrimaryAddress: false,
      emailaddress: 'sreekala3@ulta.com',
      isPaypalFlag: false,
      addressData: {
        address1: '7800 Smith Rd',
        address2: null,
        city: 'Honolulu',
        state: 'HI',
        postalCode: '96814'
      }
    }

    let props = {
      onChange : changeMock,
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      shippingInfo:{
        shippingStatus:'InvalidAddress'
      },
      editCreditCardData:{
        refId:''
      },
      editAddressData: editAddressData
    }
    let componenet1 = mountWithIntl(
      <Provider store={ store }>
        <CheckoutAddressForm { ...props }/>
      </Provider>
    );

    let prevPropsSame = {
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      editAddressData: editAddressData
    }

    componenet1.find( 'CheckoutAddressForm' ).instance().componentDidUpdate( prevPropsSame );

    expect( changeMock ).not.toBeCalled();

    const prevPropsDifferent = {
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      editAddressData: {
        firstName: 'Joh',
        lastName: 'CS',
        phoneNumber: '513-791-2513',
        isPrimaryAddress: false,
        emailaddress: 'sreekala3@ulta.com',
        isPaypalFlag: false,
        addressData: {
          address1: '7800 Smith Rd',
          address2: null,
          city: 'Honolulu',
          state: 'HI',
          postalCode: '96814'
        }
      }
    }

    componenet1.find( 'CheckoutAddressForm' ).instance().componentDidUpdate( prevPropsDifferent );
    expect( changeMock ).toBeCalled();

  } );

  it( 'tests validateAddresss() ', () => {
    const changeMock = jest.fn();
    const editAddressData = {
      firstName: 'John',
      lastName: 'CS',
      phoneNumber: '513-791-2513',
      isPrimaryAddress: false,
      emailaddress: 'sreekala3@ulta.com',
      isPaypalFlag: false,
      addressData: {
        address1: '7800 Smith Rd',
        address2: null,
        city: 'Honolulu',
        state: 'HI',
        postalCode: '96814'
      }
    }
    const props4 = {
      onChange : changeMock,
      isShippingAddressErrorCleared: true,
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      shippingInfo:{
        shippingStatus:'InvalidAddress'
      },
      editCreditCardData:{
        refId:''
      },
      editAddressData: editAddressData,
      updateShipMethod: jest.fn(),
      updateShippingStatus: jest.fn(),
      setEditAddressData: jest.fn()
    }
    store.getState().form = {
      Shipping : {
        values: {
          address1shippingAddressForm : 'test1',
          postalCodeshippingAddressForm : '13243',
          cityshippingAddressForm : 'Alabama',
          firstNameshippingAddressForm : 'hello',
          lastNameshippingAddressForm : 'world',
          emailaddressshippingAddressForm : 'abc@efhg.com',
          state : 'AL',
          phoneNumbershippingAddressForm : '1234567890'
        },
        syncErrors: {}
      }
    };
    const component4 = mountWithIntl(
      <Provider store={ store }>
        <CheckoutAddressForm { ...props4 }/>
      </Provider>
    );
    const e = { currentTarget: { contains: jest.fn( () => false ) } };
    component4.find( 'CheckoutAddressForm' ).instance().validateAddresss( e );
    jest.runAllTimers();
    expect( setTimeout.mock.calls.length ).toBe( 2 );
    expect( props4.updateShipMethod ).toBeCalled();
    expect( props4.updateShippingStatus ).toBeCalled();
    expect( props4.setEditAddressData ).toBeCalled();
  } );

  it( 'tests addNewShippingAddress() ', () => {
    const changeMock = jest.fn();
    const editAddressData = {
      firstName: 'John',
      lastName: 'CS',
      phoneNumber: '513-791-2513',
      isPrimaryAddress: false,
      emailaddress: 'sreekala3@ulta.com',
      isPaypalFlag: false,
      addressData: {
        address1: '7800 Smith Rd',
        address2: null,
        city: 'Honolulu',
        state: 'HI',
        postalCode: '96814'
      }
    }
    const props4 = {
      onChange : changeMock,
      isShippingAddressErrorCleared: true,
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      shippingInfo:{
        shippingStatus:'InvalidAddress'
      },
      editCreditCardData:{
        refId:'123'
      },
      editAddressData: editAddressData,
      updateShipMethod: jest.fn(),
      updateShippingStatus: jest.fn(),
      handleAddNewShippingAddress: jest.fn()
    }
    store.getState().form = {
      Shipping : {
        values: {
          address1shippingAddressForm : 'test1',
          postalCodeshippingAddressForm : '13243',
          cityshippingAddressForm : 'Alabama',
          firstNameshippingAddressForm : 'hello',
          lastNameshippingAddressForm : 'world',
          emailaddressshippingAddressForm : 'abc@efhg.com',
          state : 'AL',
          phoneNumbershippingAddressForm : '1234567890'
        },
        syncErrors: {}
      }
    };
    const component4 = mountWithIntl(
      <Provider store={ store }>
        <CheckoutAddressForm { ...props4 }/>
      </Provider>
    );
    const e = { currentTarget: { contains: jest.fn( () => false ) } };
    component4.find( 'CheckoutAddressForm' ).instance().addNewShippingAddress( e );
    expect( props4.updateShipMethod ).toBeCalled();
    expect( props4.updateShippingStatus ).toBeCalled();
    expect( props4.handleAddNewShippingAddress ).toBeCalled();
  } );

} );
