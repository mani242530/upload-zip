/**
 * CheckoutItemList
 */

import React from 'react';
import PropTypes from 'prop-types';
import './CheckoutItemList.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './CheckoutItemList.messages';
import Image from 'shared/components/Image/Image';
import { findKey, values } from 'lodash';

const propTypes = {
  image:PropTypes.string,
  quantity:PropTypes.number,
  brandName: PropTypes.string,
  productName: PropTypes.string,
  variantInfo: PropTypes.object
}

const defaultProps = {
  image: '',
  quantity: 0,
  brandName: '',
  productName: '',
  variantInfo: null
}

/**
 * Create a CheckoutItemList
 */
const CheckoutItemList = ( props ) => {



  let variantName = findKey( props.variantInfo );
  let variantValue;

  if( variantName ){
    variantValue = values( props.variantInfo, variantValue )[ 0 ];
  }

  return (
    <div className='CheckoutItemList'>
      <div className='CheckoutItemList__image'>
        <Image
          className=''
          src={ props.image }
          alt={ `${props.brandName} ${props.productName} ${ variantName ? formatMessage( messages.variantInfo, { variantName: variantName, variantValue:variantValue } ) : '' }` }
        />
      </div>
      { ( ()=>{
        if( props.quantity && props.quantity > 0 ){
          return (
            <div className='CheckoutItemList__quantity'>
              { formatMessage( messages.quantity, { itemCount:props.quantity } ) }
            </div>
          )
        }
      } )() }

    </div>
  );

}

CheckoutItemList.propTypes = propTypes;
CheckoutItemList.defaultProps = defaultProps;

export default CheckoutItemList;
