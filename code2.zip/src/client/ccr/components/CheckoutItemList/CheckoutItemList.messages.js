/*
 * CheckoutItemList Messages
 *
 * This contains all the text for the CheckoutItemList component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.CheckoutItemList.header',
    defaultMessage: 'This is the CheckoutItemList component !'
  },
  quantity: {
    id: 'i18n.CheckoutItemList.quantity',
    defaultMessage: 'Qty: {itemCount}'
  },
  variantInfo: {
    id: 'i18n.ProductDescriptionCard.variantInfo',
    defaultMessage: '{variantName}: {variantValue}'
  }
} );
