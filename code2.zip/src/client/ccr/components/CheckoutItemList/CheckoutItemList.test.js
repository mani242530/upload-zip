import React from 'react';
import ReactDOM from 'react-dom';
import CheckoutItemList from './CheckoutItemList';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './CheckoutItemList.messages';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';

describe( '<CheckoutItemList />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <CheckoutItemList /> );
    expect( component.find( 'CheckoutItemList' ).length ).toBe( 1 );
  } );

  it( 'renders image ', () => {
    let component1 =  mountWithIntl( <CheckoutItemList quantity={ 9 } image={ 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$' }/> );
    expect( component1.find( '.CheckoutItemList__image' ).length ).toBe( 1 );
  } );

  it( 'renders quantity ', () => {
    let component2 =  mountWithIntl( <CheckoutItemList quantity={ 9 } image={ 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$' }/> );
    expect( component2.find( '.CheckoutItemList__quantity' ).length ).toBe( 1 );
  } );

  it( 'renders correct quantiy', () => {
    let component3 = mountWithIntl( <CheckoutItemList quantity={ 9 } image={ 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$' }/> );

    expect( component3.find( '.CheckoutItemList__quantity' ).text( ) ).toBe( messages.quantity.defaultMessage.replace( '{itemCount}', '9' ) );
  } );

  it( 'renders alt text for the image - when no variant is available', () => {
    const props = {
      'imageURL':'http://s7d5.scene7.com/is/image/Ulta/2257743?$sm$',
      'brandName':'Nars',
      'displayName':'Balance N Brighten'
    };
    const variantName='';
    const variantValue='';

    let component =  mountWithIntl( <CheckoutItemList quantity={ 9 } image={ 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$' } brandName={ props.brandName } productName={ props.displayName }/> );
    expect( component.find( 'img' ).props().alt ).toBe( `${props.brandName} ${props.displayName} ` );
  } );

  it( 'renders alt text for the image - with variant info', () => {
    const props = {
      'imageURL':'http://s7d5.scene7.com/is/image/Ulta/2257743?$sm$',
      'brandName':'Nars',
      'displayName':'Balance N Brighten',
      'variant':{ 'color':'yellow' }
    };
    const variantName='color';
    const variantValue='yellow';

    let component =  mountWithIntl( <CheckoutItemList quantity={ 9 } image={ 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$' } brandName={ props.brandName } productName={ props.displayName } variantInfo={ props.variant }/> );
    expect( component.find( 'img' ).props().alt ).toBe( `${props.brandName} ${props.displayName} ${variantName}: ${variantValue}` );
  } );
} );
