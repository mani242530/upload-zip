/**
 * CheckoutModal
 */


import React, { Component } from 'react';
import './CheckoutModal.css';
import Modal from 'react-modal';
import CloseSVG from 'shared/components/Icons/close';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './CheckoutModal.messages';
import Button from 'shared/components/Button/Button';
import ShippingAddress from 'ccr/components/ShippingAddress/ShippingAddress';
import has from 'lodash/has';
import PropTypes from 'prop-types';

/**
 * Class
 * @extends React.Component
 */
const propTypes={
  updateShipMethod: PropTypes.func,
  shippingInfo: PropTypes.object,
  focusOnModalClose: PropTypes.object
}
class CheckoutModal extends Component{

  /**
   * Create a CheckoutModal
   */
  constructor( props ){
    super( props );
    this.state = {
      isModalOpen: true,
      shippingObj: {},
      addressUpdated: false
    };
    this.toogleModal = this.toogleModal.bind( this );
    this.addressToggle = this.addressToggle.bind( this );

    /* This tells react-modal which is the parent div */
    Modal.setAppElement( '#js-cartpage' );
  }

  toogleModal(){
    const postData = {
      values: {
        confirmAddress: false
      }
    }
    this.props.updateShipMethod( postData );

    this.setFocusOnModalClose()

    this.setState( { isModalOpen: !this.state.isModalOpen } );
    this.setState( { shippingObj: this.props.shippingInfo.shippingAddress } );
  }

  setFocusOnModalClose(){
    // check to see if the modal is being closed if the user has passed a focusONModalClose prop
    if( !this.state.isModalOpen === false && this.props.focusOnModalClose ){
      let el = this.props.focusOnModalClose;

      // once if focus when there is any component updates happening the focus is getting lost.
      // Setting a timeout helps getting around this issue
      setTimeout( () => {
        el.focus();
      }, 1000 );
    }
  }
  addressToggle(){
    const postData = {
      values: {
        confirmAddress: true
      }
    }
    this.props.updateShipMethod( postData );

    this.setFocusOnModalClose();

    this.setState( { addressUpdated: !this.state.addressUpdated } );
    this.setState( { isModalOpen: !this.state.isModalOpen } );
    if( !this.state.addressUpdated ){
      this.setState( { shippingObj: this.props.shippingInfo.correctedShippingAddress } );
    }
  }

  // Filter dav popup messages
  getDavPopupMesssages( messages ){
    return messages.filter( function( message ){
      if( message.messageType === 'Info' ){
        return message;
      }
    } );
  }

  // jsx structure for Response message Elements
  getResponseMessages = ( messages ) =>{
    return messages.map( function( message, index ){
      return (
        <div className='Shipping__Modal--uspstext' key={ index }>
          { message.messageDesc }
        </div>
      )
    } )
  }

  /**
   * Renders the CheckoutModal component
   *
   * a11y - hidden (sr-only) button for safari voice over so user can close modal.
   *        safari vo by-passes svg close.
   */
  render(){

    const {
      shippingInfo
    } = this.props;
    let responseMessages = ( shippingInfo.messages ) ? this.getDavPopupMesssages( shippingInfo.messages ) : [];
    return (
      <div className='CheckoutModal'>
        <Modal
          isOpen={ this.state.isModalOpen }
          contentLabel={ formatMessage( messages.a11yLabel ) }
          className='Modal'
          onRequestClose={ this.toogleModal }
          role='dialog'
        >

          <button className='CheckoutModal__CloseButton' onClick={ this.toogleModal }>
            <CloseSVG/>
          </button>
          <div className='Shipping__Modal'>
            <h2>
              { formatMessage( messages.addressVerification ) }
              <hr/>
            </h2>
            { this.getResponseMessages( responseMessages ) }
            <div className='Shipping__Modal--address'>
              <div className='Shipping__Modal--firstNameLastName Gutter'>
                <span>{ shippingInfo.correctedShippingAddress.firstName }</span>
                <span> { shippingInfo.correctedShippingAddress.lastName }</span>
              </div>
              <div className='Shipping__Modal--addressLine1 Gutter'>
                <div>{ shippingInfo.correctedShippingAddress.address1 },</div>
                { ( () =>{
                  if( has( shippingInfo.correctedShippingAddress, 'address2' ) && shippingInfo.correctedShippingAddress.address2 !== null && shippingInfo.correctedShippingAddress.address2 !== '' ){
                    return (
                      <span> { shippingInfo.correctedShippingAddress.address2 }</span>
                    );
                  }
                } )() }
                <span> { shippingInfo.correctedShippingAddress.city }, </span>
                <span> { shippingInfo.correctedShippingAddress.state }</span>
                <span> { shippingInfo.correctedShippingAddress.postalCode }</span>
              </div>

            </div>

            <Button
              inputTag='button'
              btnType='submit'
              btnSize='lg'
              btnOption='single'
              btnOutLine={ false }
              clickEventHandler={ this.addressToggle }
              btnBlock={ true }
              analyticsEvent={ {
                eventName: 'trackAddressVerification'
              } }
            >
              { formatMessage( messages.addressbtn ) }
            </Button>

            <div className='Shipping__Modal--button'>
              <Button
                inputTag='button'
                btnType='button'
                btnSize='xs'
                btnOption='no-style'
                btnOutLine={ false }
                title={ formatMessage( messages.changeShippingMethod ) }
                clickEventHandler={ this.toogleModal }
              >
                { formatMessage( messages.addressEntr ) }
              </Button>
            </div>
            <button className='sr-only' onClick={ this.toogleModal }>
              { formatMessage( messages.closeModal ) }
            </button>
          </div>
        </Modal>
      </div>
    );
  }
}

CheckoutModal.propTypes = propTypes;
export default CheckoutModal;
