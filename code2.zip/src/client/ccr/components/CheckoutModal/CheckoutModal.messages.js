/*
 * CheckoutModal Messages
 *
 * This contains all the text for the CheckoutModal component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {

  changeShippingAddress: {
    id: 'i18n.CheckoutModal.changeShippingAddress',
    defaultMessage: 'Change Shipping Address'
  },
  changeShippingMethod: {
    id: 'i18n.CheckoutModal.changeShippingMethod',
    defaultMessage: 'Change Shipping Method'
  },
  addressVerification: {
    id: 'i18n.CheckoutModal.addressVerification',
    defaultMessage: 'Address Verification'
  },
  addressVerified: {
    id: 'i18n.CheckoutModal.addressVerified',
    defaultMessage: 'Verified Address'
  },
  addressbtn: {
    id: 'i18n.CheckoutModal.addressbtn',
    defaultMessage: 'USE THIS ADDRESS'
  },
  addressEntr: {
    id: 'i18n.CheckoutModal.addressEntr',
    defaultMessage: 'Use the Address I Entered'
  },
  uspstext: {
    id: 'i18n.CheckoutModal.uspstext',
    defaultMessage: 'We recommend using the following address verified by the Postal Service.'
  },
  a11yLabel: {
    id: 'i18n.CheckoutModal.a11yLabel',
    defaultMessage: 'Please verify your address dialog box is open'
  },
  closeModal: {
    id: 'i18n.CheckoutModal.closeModal',
    defaultMessage: 'Close address verification pop up'
  }
} );
