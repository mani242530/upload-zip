import React from 'react';
import ReactDOM from 'react-dom';
import CheckoutModal from './CheckoutModal';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import messages from './CheckoutModal.messages';
import Modal from 'react-modal';


let appElement = document.createElement( 'div' );
appElement.id='js-cartpage';
document.body.appendChild( appElement );

jest.useFakeTimers( );
describe( '<CheckoutModal />', () => {
  let component;
  const focusOnModalCloseMock = jest.fn();
  let props = {
    updateShipMethod : jest.fn(),
    focusOnModalClose : {
      focus : focusOnModalCloseMock
    },
    isSignedIn: false,
    shippingInfo: {
      shippingStatus: 'CorrectedAddress',
      shippingAddress: {
        firstName: 'Jane',
        lastName: 'Doe',
        address1: '1000 Remington Boulevard',
        address2: 'Suite # 120',
        city: 'Bolingbrook',
        state: 'IL',
        postalCode: '60564',
        phoneNumber: '(510)-213-8347'
      },
      correctedShippingAddress: {
        firstName: 'Jane',
        lastName: 'Doe',
        address1: '1000 Remington Blvd',
        address2: 'Suite # 120',
        city: 'Bolingbrook',
        state: 'IL',
        postalCode: '60440',
        phoneNumber: '(510)-213-8347'
      },
      shipMethodInfo: {
        shipMethod: 'ups_ground',
        estimatedDelivery: 'Within 3 to 8 business days',
        cost: '$5.95',
        displayName: 'Standard Ground Shipping'
      },
      messages: [{
        messageDesc: 'A correction available for the specified shipping address.',
        messageKey: 'SHIP_ADDRESS_CORRECTION',
        messageType: 'Infoo'
      }]

    }
  }

  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <CheckoutModal { ...props }/>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'CheckoutModal' ).length ).toBe( 1 );
  } );

  // verify for response messages
  it( 'render response messages', () => {
    expect( document.body.getElementsByClassName( 'Shipping__Modal--uspstext' ).length ).toBe( 0 );
  } );

  it( 'renders modal with out crashing', () => {
    expect( component.find( 'Modal' ).length ).toBe( 1 );
  } );
  it( 'renders data on modal', () => {
    expect( document.body.getElementsByClassName( 'Shipping__Modal' ).length ).toBe( 1 );
  } );
  it( 'renders h2 header', () => {
    expect( document.body.getElementsByTagName( 'h2' ).length ).toBe( 1 );
  } );
  it( 'renders ( close modal ) button with SVG titled CLOSE', () => {
    expect( document.body.getElementsByTagName( 'Button' )[0].innerHTML.indexOf( '<title>Close</title>' ) ).toBeGreaterThan( 0 );
  } );

  it( 'renders ( use this address ) Button component', () => {
    expect( document.body.getElementsByTagName( 'Button' )[1].innerHTML ).toBe( messages.addressbtn.defaultMessage );
  } );

  it( 'renders ( use the address I entered) Button component', () => {
    expect( document.body.getElementsByTagName( 'Button' )[2].innerHTML ).toBe( messages.addressEntr.defaultMessage );
  } );

  it( 'renders a screen-reader only close Button component', () => {
    expect( document.body.getElementsByTagName( 'Button' )[3].innerHTML ).toBe( messages.closeModal.defaultMessage );
  } );


  it( 'displays corrected shipping address', () => {
    expect( document.body.getElementsByClassName( 'Shipping__Modal--address' ).length ).toBe( 1 );
  } );
  it( 'Should have first and Last Names', () => {
    expect( document.body.getElementsByClassName( 'Shipping__Modal--firstNameLastName Gutter' ).length ).toBe( 1 );
  } );
  it( 'Should have address, city, state and zip', () => {
    expect( document.body.getElementsByClassName( 'Shipping__Modal--addressLine1 Gutter' ).length ).toBe( 1 );
  } );
  it( 'should invoke focus method once the togglemodal is invoked', () => {
    component.find( 'CheckoutModal' ).instance().toogleModal();
    jest.runAllTimers();
    expect( props.focusOnModalClose.focus ).toBeCalled();
    // The function was called exactly once
    expect( setTimeout.mock.calls.length ).toBe( 1 );
    // The second arg of the first call to the function was 1000(delay in milliseconds)
    expect( setTimeout.mock.calls[0][1] ).toBe( 1000 );
  } );
  it( 'should invoke focus method once the addressToggle is invoked', () => {
    component.find( 'CheckoutModal' ).instance().addressToggle();
    jest.runAllTimers();
    expect( props.focusOnModalClose.focus ).toBeCalled();
    // The function was called exactly once
    expect( setTimeout.mock.calls.length ).toBe( 1 );
    // The second arg of the first call to the function was 1000(delay in milliseconds)
    expect( setTimeout.mock.calls[0][1] ).toBe( 1000 );
  } );

  it( 'should invoke setFocusOnModalCloseMock method once the addressToggle is invoked', () => {
    const setFocusOnModalCloseMock = jest.fn();
    component.find( 'CheckoutModal' ).instance().setFocusOnModalClose = setFocusOnModalCloseMock;
    component.find( 'CheckoutModal' ).instance().addressToggle();
    expect( setFocusOnModalCloseMock ).toBeCalled();
  } );

  it( 'should invoke setFocusOnModalCloseMock method once the toogleModal is invoked', () => {
    const setFocusOnModalCloseMock = jest.fn();
    component.find( 'CheckoutModal' ).instance().setFocusOnModalClose = setFocusOnModalCloseMock;
    component.find( 'CheckoutModal' ).instance().toogleModal();
    expect( setFocusOnModalCloseMock ).toBeCalled();
  } );

} );
