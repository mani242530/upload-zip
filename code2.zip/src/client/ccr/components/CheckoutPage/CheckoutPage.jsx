/**
 * CheckoutPage
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './CheckoutPage.messages';
import './CheckoutPage.css';
import { isUndefined, isEmpty, has, keys } from 'lodash';
import { Field, reduxForm, touch, isValid } from 'redux-form';
import NewsLetterSignup from 'hf/components/NewsLetterSignup/NewsLetterSignup';
import CheckoutHeader from 'hf/components/Headers/shared/CheckOutHeader/CheckOutHeader';
import ProductCellList from 'ccr/components/ProductCellList/ProductCellList';
import OrderSummaryItem from 'ccr/components/OrderSummaryItem/OrderSummaryItem';
import { scrollWindowToPosition } from 'utils/Animation/Animation';
import { injectFingerPrint } from 'utils/Cybersource/Cybersource';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';
import Sticker from 'react-stickyfill';
import FragranceIcon from 'shared/components/Icons/FragranceIcon';
import SkincareIcon from 'shared/components/Icons/SkincareIcon';
import VarietyIcon from 'shared/components/Icons/VarietyIcon';
import PlusCircle from 'shared/components/Icons/PlusCircle';
import LoginForm from 'shared/components/LoginForm/LoginForm';
import UserRewardsLookup from 'ccr/components/UserRewardsLookup/UserRewardsLookup';

import ShippingInformation from 'ccr/components/ShippingInformation/ShippingInformation';
import PaymentInformation from 'ccr/components/PaymentInformation/PaymentInformation';
import CheckOutRedeemPoints from 'ccr/components/CheckOutRedeemPoints/CheckOutRedeemPoints';
import PlaceOrderComponent from 'ccr/components/PlaceOrderComponent/PlaceOrderComponent';
import Spinner from 'shared/components/Icons/spinner';
import GiftCard from 'ccr/components/GiftCard/GiftCard';
import MetaData from 'shared/components/MetaData/MetaData';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import Coupons from 'ccr/components/Coupons/Coupons';
import round from 'lodash/round';
import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import {
  actions as miniCartActions
} from 'hf/actions/MiniCart/MiniCart.actions';
import {
  actions,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';
import {
  BrowserRouter as Router,
  Route,
  browserHistory,
  Redirect,
  Switch
} from 'react-router-dom';
import {
  actions as formActions
} from 'shared/actions/Forms/Forms.actions';
import {
  actions as headerActions
} from 'hf/actions/Header/Header.actions';
import {
  actions as checkoutPageActions
} from 'ccr/actions/CheckoutPage/CheckoutPage.actions'
import {
  actions as userActions
} from 'shared/actions/User/User.actions';


import 'shared/components/Gutter/Gutter.css';

import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';


export const mapStateToProps = ( state ) =>{
  return {
    ...state.checkoutPage,
    ...state.user,
    ...state.session,
    ...state.pagedata,
    ...state.minicart,
    ...state.global,
    user: state.user
  };
}

export const mapDispatchToProps = ( dispatch ) =>{
  return {
    setCartRightPanelCollapse: ( panelID ) =>{
      dispatch( miniCartActions.setCartRightPanelCollapse( panelID ) );
    },
    newsLetterSignupStatus: ( status ) =>{
      dispatch( checkoutPageActions.newsLetterSignupStatus( status ) );
    },
    closeRealtimeModal: () => {
      let triggerForClosingModel = new CustomEvent( 'QUBIT::PREAPPROVED_FLOW_CLOSE_MODAL' );
      document.dispatchEvent( triggerForClosingModel );
    },
    updateStateDropdownValue: ( form, value ) =>{
      dispatch( checkoutPageActions.updateStateDropdownValue( form, value ) );
    },
    updateShippingStatus: ( value ) =>{
      dispatch( checkoutPageActions.updateShippingStatus( value ) );
    },
    updatePaymentStatus: ( value ) =>{
      dispatch( checkoutPageActions.updatePaymentStatus( value ) );
    },
    submitUserLogin: ( data ) =>{
      dispatch( getActionDefinition( 'login', 'requested' )( data ) );
    },
    applyPayment: ( data ) =>{
      dispatch( getActionDefinition( 'applyPayment', 'requested' )( data ) );
    },
    applyPaymentSameSession: ( data ) =>{
      dispatch( getActionDefinition( 'applyPaymentSameSession', 'requested' )( data ) );
    },
    savePaypaltoMyAccount: ( data ) =>{
      dispatch( getActionDefinition( 'savePaypaltoMyAccount', 'requested' )( data ) );
    },
    setPaymentType: ( paymentType ) =>{
      dispatch( checkoutPageActions.setPaymentType( paymentType ) );
    },
    getBannerData: ( data ) =>{
      dispatch( getActionDefinition( 'banner', 'requested' )( data ) )
    },
    toggleAddress2FieldDisplay: () =>{
      dispatch( formActions.toggleAddress2FieldDisplay() )
    },
    toggleAddressFieldDisplay: () =>{
      dispatch( formActions.toggleAddressFieldDisplay() )
    },
    toggleAddressFieldDisplayPaymentForm: ( formName ) =>{
      dispatch( formActions.toggleAddressFieldDisplayPaymentForm( formName ) )
    },
    updateCreditCard: ( data ) =>{
      dispatch( getActionDefinition( 'submitCreditCard', 'requested' )( data ) );
    },
    getRealtimeOLPS: () =>{
      dispatch( getActionDefinition( 'RealtimeOLPS', 'requested' )() );
    },
    firePreScreenLPSEvent: ( data ) => {
      dispatch( getActionDefinition( 'preScreenLPSEvent', 'requested' )( data ) );
    },
    getAddressBook: () =>{
      dispatch( getActionDefinition( 'addressbook', 'requested' )() );
    },
    getCheckoutFormInitialState: ( formName ) =>{
      dispatch( formActions.getCheckoutFormInitialState( formName ) )
    },
    getCheckoutPage: ( data ) =>{
      dispatch( getActionDefinition( 'readCart', 'requested' )( data ) );
    },
    getEstimatedDelivery: () =>{
      dispatch( getActionDefinition( 'estimatedDeliveryDate', 'requested' )() );
    },
    getShipMethod: ( ) =>{
      dispatch( getActionDefinition( 'getQualifiedShipMethod', 'requested' )( ) );
    },
    getRedeemPoints: ( ) =>{
      dispatch( getActionDefinition( 'redeemPoints', 'requested' )( ) );
    },
    updatePaymentServiceResponse: ( loyalty ) =>{
      dispatch( getActionDefinition( 'paymentServiceResponse', 'requested' )( loyalty ) );
    },
    removePaymentService: ( data ) =>{
      dispatch( getActionDefinition( 'removePaymentService', 'requested' )( data ) );
    },
    updateShipMethod: ( data ) =>{
      dispatch( getActionDefinition( 'shippingUpdate', 'requested' )( data ) );
    },
    getRewardsLookup: ( data ) =>{
      dispatch( getActionDefinition( 'rewardsLookup', 'requested' )( data ) );
    },
    getProfileData: ( data ) =>{
      dispatch( getActionDefinition( 'profile', 'requested' )( data ) );
    },
    setEditAddressData: ( data ) =>{
      dispatch( checkoutPageActions.setEditAddressData( data ) );
    },
    updateDavPopup: ( ) =>{
      dispatch( checkoutPageActions.updateDavPopup( ) );
    },
    setEditCreditCardData: ( data ) =>{
      dispatch( checkoutPageActions.setEditCreditCardData( data ) );
    },
    setCreditCardPaymentType: ( data ) =>{
      dispatch( checkoutPageActions.setCreditCardPaymentType( data ) );
    },
    setTempPaymentCCVNumber: ( data ) =>{
      dispatch( checkoutPageActions.setTempPaymentCCVNumber( data ) );
    },
    resetCartMerge: () =>{
      dispatch( checkoutPageActions.resetCartMerge() );
    },
    getProfileCreditCardList: ( ) =>{
      dispatch( getActionDefinition( 'profileCreditCards', 'requested' )( ) );
    },
    setDataLayer: ( data, evt ) =>{
      dispatch( dataLayerActions.setDataLayer( data, evt ) );
    },
    triggerAnalyticsEvent: ( evt ) =>{
      dispatch( analyticActions.triggerAnalyticsEvent( evt ) );
    },
    resetOrderStatus: () =>{
      dispatch( checkoutPageActions.resetOrderStatus() );
    },
    handleScrollView: ( el ) =>{
      let elem = document.getElementById( el );
      if( elem !== null ){
        scrollWindowToPosition( elem.offsetTop - 30, 'easeInOutQuint' );
      }
    },
    handleScrollViewShippingMethod: ( el ) =>{
      let elem = document.getElementById( el );
      if( elem !== null ){
        scrollWindowToPosition( elem.offsetTop - 30, 'easeInOutSine', 800 );
      }
    },
    handleScrollToFormError: ( errors ) =>{
      let errorFields = keys( errors );
      for ( let i = 0; i < errorFields.length; i++ ){
        if( !isUndefined( errors[ errorFields[ i ] ] ) ){
          let elem = document.getElementById( errorFields[ i ] );
          if( elem ){
            // scroll to the first element that results in a dom match
            scrollWindowToPosition( elem.parentElement.offsetParent.offsetTop, 'easeInOutQuint' );
            return;
          }
        }
      }
    },
    getPaypalResponse: ( info ) =>{
      dispatch( checkoutPageActions.getPaypalResponse( info ) );
    },
    updateSubmitOrder: ( data ) =>{
      dispatch( getActionDefinition( 'submitOrderService', 'requested' )( data ) );
    },
    changeCreditCard: ( data ) =>{
      dispatch( checkoutPageActions.changeCreditCard( data ) );
    },
    setCCPaymentFormSubmit: ( data ) =>{
      dispatch( checkoutPageActions.setCCPaymentFormSubmit( data ) );
    },
    toggleInputFieldShippingDisplay: ( data ) =>{
      dispatch( checkoutPageActions.toggleInputFieldShippingDisplay() );
    },
    toggleInputFieldPaymentDisplay: ( data ) =>{
      dispatch( checkoutPageActions.toggleInputFieldPaymentDisplay() );
    },
    setShippingErrorMessage: ( data ) =>{
      dispatch( checkoutPageActions.setShippingErrorMessage( data ) );
    },
    loadCart: () =>{
      dispatch( getActionDefinition( 'loadCart', 'requested' )() );
    },
    couponCodeUpdated: ( item, history, fromCheckout ) =>{
      dispatch( miniCartActions.couponCodeUpdated( item, history, fromCheckout ) );
    },
    couponCodeRemoved: ( history, fromCheckout ) =>{
      dispatch( miniCartActions.couponCodeRemoved( history, fromCheckout ) );
    },
    resetCouponsState: ( ) =>{
      dispatch( formActions.resetCouponsState() );
    },
    updateUserData: () =>{
      dispatch( userActions.updateUserData() );
    },
    getPaypalToken: ( ) =>{
      dispatch( getActionDefinition( 'paypalToken', 'requested' )() );
    },
    submitShippingAddressForm: () => {
      dispatch( touch(
        'shippingAddressList',
        'firstNameshippingAddressForm',
        'lastNameshippingAddressForm',
        'address1shippingAddressForm',
        'cityshippingAddressForm',
        'state',
        'postalCodeshippingAddressForm',
        'phoneNumbershippingAddressForm',
        'emailaddressshippingAddressForm'
      ) );
    },
    submitPaymentForm: ( remainingPaymentDue ) => {
      if( remainingPaymentDue>0 ){
        // if remainingPaymentDue is greater than 0 then creditCardNumber details is a required field
        dispatch( touch(
          'paymentForm',
          'creditCardNumber',
          'expirationDate',
          'securityCode',
          'firstNamepaymentAddressForm',
          'lastNamepaymentAddressForm',
          'address1paymentAddressForm',
          'citypaymentAddressForm',
          'state',
          'postalCodepaymentAddressForm',
          'phoneNumberpaymentAddressForm',
          'emailaddresspaymentAddressForm'
        ) );
      }
      else {
        // if remainingPaymentDue is less than 0 then creditCardNumber details is not a required field
        dispatch( touch(
          'paymentForm',
          'firstNamepaymentAddressForm',
          'lastNamepaymentAddressForm',
          'address1paymentAddressForm',
          'citypaymentAddressForm',
          'state',
          'postalCodepaymentAddressForm',
          'phoneNumberpaymentAddressForm',
          'emailaddresspaymentAddressForm'
        ) );
      }
    },
    submitPaymentFormCvv: ( remainingPaymentDue ) => {
      if( remainingPaymentDue>0 ){
        // if remainingPaymentDue is greater than 0 then PaymentCCSecurityCode is a required field
        dispatch( touch(
          'PaymentCCSecurityCode',
          'ccSecurityCode',
        ) );
      }
    },
    joinNowRewards: () =>{
      dispatch( getActionDefinition( 'userRewards', 'requested' )() )
    },
    isCouponBtnClicked: ( data ) =>{
      dispatch( checkoutPageActions.isCouponBtnClicked( data ) );
    },
    validateShippingForm: () =>{
      dispatch( touch(
        'Shipping',
        'firstNameshippingAddressForm',
        'lastNameshippingAddressForm',
        'address1shippingAddressForm',
        'cityshippingAddressForm',
        'state',
        'postalCodeshippingAddressForm',
        'phoneNumbershippingAddressForm',
        'emailaddressshippingAddressForm'
      ) );
    },
    toggleSecurityCode: ( status, displayType ) =>{
      dispatch( checkoutPageActions.toggleSecurityCode( status, displayType ) )
    },
    broadcastMessage : function( message ){
      dispatch( globalActions.setBroadcastMessage( message ) )
    }
  };
}

/**
 * Class
 * @extends React.Component
 */
export class CheckoutPage extends Component{

  constructor( props ){
    super( props );
    this.productItems = this.productItems.bind( this );
    this.toggleModal = this.toggleModal.bind( this );
    this.pageUpFor = this.pageUpFor.bind( this );
    this.state = {
      isModalOpen: false
    };
  }

  componentDidMount(){
    this.props.getCheckoutPage( {
      history: this.props.history,
      firePageNavigation: true
    } );

    // check the user data to see if realtime should be started
    if( has( this.props, 'rewardsInfo.preScreenRequired' ) && this.props.rewardsInfo.preScreenRequired === true ){
      this.props.getRealtimeOLPS();
    }
  }

  toggleModal(){
    this.setState( { isModalOpen: !this.state.isModalOpen }, () => {
      // once if focus when there is any component updates happening the focus is getting lost.
      // Setting a timeout helps getting around this issue
      if( !this.state.isModalOpen ){
        document.querySelector( '.UserRewardsLookup__forgotField a' ).focus();
      }
    } );
  }

  componentWillMount(){
    global.scrollTo( 0, 0 );
  }

  productItems( itemCategory ){
    let itemsList = [];
    this.props.readCartData.cartItems.commerceItems.map( ( section, index ) =>{
      if( section.itemType === itemCategory ){
        itemsList.push( section );
      }
    } );
    return { commerceItems: itemsList }
  }

  pageUpFor(){
    this.props.handleScrollView( 'checkoutPaymentHeader' );
    const elemCC = document.querySelector( '#creditCardNumber' );
    const elemPaypal = document.querySelector( '#paypalContentPanel iframe' );
    if( this.props.paymentType === 'creditCard' && elemCC ){
      elemCC.focus();
    }
    if( this.props.paymentType === 'paypal' && elemPaypal ){
      elemPaypal.focus();
    }
  }

  componentDidUpdate( prevProps ){
    if( this.props.orderSuccess ){
      location.replace( '/ulta/checkout/checkoutThankYou.jsp' );
      this.props.resetOrderStatus();
    }

    if( this.props.cartMerged || this.props.navigateToCartPage ){
      this.props.resetCartMerge();
      this.props.history.push( '/bag' );
    }

    if( !isUndefined( this.props.orderId ) && this.props.orderId !== prevProps.orderId ){
      injectFingerPrint( this.props.orderId );
    }

    // to check if the qubit is loaded later and if we need to show the modal to user.
    if( this.props.canFireLpsEvent === true && prevProps.canFireLpsEvent === false ){
      this.props.firePreScreenLPSEvent( { 'eventType': 'NoResponse' } );
    }
  }

  // we will close the modal by firing this event when the user navigated between the app without interacting with the modal or the footer or the header.
  componentWillUnmount(){
    this.props.closeRealtimeModal();
  }

  /**
   * Renders the CheckoutPage component
   */
  render(){


    if( !this.props.isCheckoutDataAvailable ){
      return (
        <div className='CartPage CheckoutPage container'>
          <div className='CheckoutPage--spinner_loading'>
            <Spinner loaderType='spinner'/>
          </div>
        </div>
      )
    }
    else {
      return (
        <MetaData
          analyticsPageName={ 'checkout' }
          title={ formatMessage( messages.checkoutTitle ) }
          analyticsPageChannel='checkout'
          analyticsPageType='checkout'
          firePageNavEvent={ false }
          setDataLayer={ this.props.setDataLayer }
          headerDisplayConfig={
            {
              mobileHeaderDisplayMode: 'focused',
              desktopHeaderDisplayMode: 'focused'
            }
          }
          footerDisplayConfig={
            {
              mobileFooterDisplayMode: 'customerService',
              desktopFooterDisplayMode: 'customerService'
            }
          }
        >
          <div className='CartPage CheckoutPage container'>
            <CheckoutHeader/>
            <hr className='Divider_Line Gutter'/>
            <div className='CartPage__Right'>
              <div className='CartPage__MainContainerLeftPanel'>
                { ( () =>{
                  if( has( this.props, 'checkoutError' ) ){
                    if( !isEmpty( this.props.checkoutError ) ){
                      return (
                        <div className='CheckoutPage__errorMessages'>
                          { ( () =>{
                            return this.props.checkoutError.map( ( message, index1 ) =>{
                              return (
                                <ResponseMessages
                                  messageType={ message.messageType }
                                  message={ message.messageDesc }
                                  key={ index1 }
                                />
                              );
                            } );
                          } )() }
                        </div>
                      )
                    }
                    else if( this.props.displayCheckoutLevelErrorMessage ){
                      return (
                        <div className='CheckoutPage__errorMessages'>
                          <ResponseMessages
                            message={ formatMessage( messages.checkoutLevelGenericError ) }
                          />
                        </div>
                      )
                    }
                  }
                } )() }
                { ( () =>{
                  if( !this.props.isSignedIn ){
                    return (
                      <div className='CheckoutPage__LoginPanel Gutter'>
                        <div className='CheckoutPage__MainContainerLeftPanel--background'>
                          <h2>
                            { formatMessage( messages.checkoutSignInHeader ) }
                          </h2>

                          <div className='CheckoutPage__SignIn'>
                            <LoginForm
                              messageBeans={ this.props.user.messageBeans }
                              successPath='/checkout'
                              submitUserLogin={ this.props.submitUserLogin }
                              sourcePage='checkoutLogin'
                              fieldShowHideToggleData={ this.props.fieldShowHideToggleData }
                              getBannerImage={ this.props.getBannerData }
                              buttonText={ formatMessage( messages.loginButtonText ) }
                              btnOption='tertiary'
                              analyticsSourcePage='checkout'
                              history={ this.props.history }
                              title={ this.props.title }
                              formMessage={ this.props.formMessage }
                              defaultEmail={ this.props.defaultEmail }
                            />
                          </div>

                        </div>
                        <div className='CheckoutPage__SignIn CheckoutPage__SignIn--Divider'>
                          <Divider dividerType={ 'gray-default' }/>
                        </div>
                        <h2>
                          { formatMessage( messages.guestCheckoutHeader ) }
                        </h2>
                        <div className='CheckoutPage__SignIn--FooterText'>
                          { formatMessage( messages.guestCheckoutFooter ) }
                        </div>
                      </div>
                    )
                  }
                } )() }

                { ( () =>{
                  if( this.props.readCartData !== undefined ){
                    return (
                      <section className='checkoutPage__shopping'>
                        <h3
                          id='checkoutShippingHeader'
                          className='Gutter'
                        >
                          { formatMessage( messages.Shipping ) }
                        </h3>
                        <div className='checkoutPage__shopping--divider Gutter'>
                          <Divider dividerType={ 'gray' }/>
                        </div>
                        <div className='Checkout__LeftPanel'>
                          <ShippingInformation
                            shippingSuccess={ this.props.shippingSuccess }
                            isSignedIn={ this.props.isSignedIn }
                            getAddressBook={ this.props.getAddressBook }
                            handleScrollView={ this.props.handleScrollView }
                            setEditAddressData={ this.props.setEditAddressData }
                            shippingError={ this.props.shippingError }
                            holdDavPopUp={ this.props.holdDavPopUp }
                            editAddressData={ this.props.editAddressData }
                            checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                            toggleInputFieldShippingDisplay={ this.props.toggleInputFieldShippingDisplay }
                            isMobileDevice={ this.props.isMobileDevice }
                            shippingInfo={ this.props.readCartData.shippingInfo }
                            updateShipMethod={ this.props.updateShipMethod }
                            updateShippingStatus={ this.props.updateShippingStatus }
                            setShippingErrorMessage={ this.props.setShippingErrorMessage }
                            addressbook={ this.props.addressbook }
                            address2Open={ this.props.address2Open }
                            shippingAddress={ this.props.shippingAddress }
                            shippingStatus={ this.props.shippingStatus }
                            changeAddress={ this.props.changeAddress }
                            errorMsg={ this.props.errorMsg }
                            hazmatAddressChange={ this.props.hazmatAddressChange }
                            handleHazmatChange={ this.props.handleHazmatChange }
                            getEstimatedDelivery={ this.props.getEstimatedDelivery }
                            getQualifiedShipMethod={ this.props.getQualifiedShipMethod }
                            getShipMethod={ this.props.getShipMethod }
                            checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                            toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                            setEditCreditCardData={ this.props.setEditCreditCardData }
                            updateDavPopup={ this.props.updateDavPopup }
                            handleScrollViewShippingMethod={ this.props.handleScrollViewShippingMethod }
                            showAddressBookSpinner={ this.props.showAddressBookSpinner }
                          />
                        </div>

                      </section>
                    );
                  }
                } )() }

                <section className='CheckoutPage__section'>

                  <h3
                    id='checkoutPaymentHeader'
                    className='Gutter'
                  >
                    { formatMessage( messages.payment ) }
                  </h3>
                  <div className='CheckoutPage__paymentDivider Gutter'>

                    <Divider dividerType={ 'gray' }/>
                  </div>

                  <div className='Checkout__LeftPanel'>
                    <PaymentInformation
                      setPaymentType={ this.props.setPaymentType }
                      creditCardDetails={ this.props.creditCardDetails }
                      isSignedIn={ this.props.isSignedIn }
                      ultamateRewardsCCInfo={ this.props.readCartData.ultamateRewardsCCInfo }
                      paymentError={ this.props.paymentError }
                      paypalResponse={ this.props.paypalResponse }
                      getPaypalToken={ this.props.getPaypalToken }
                      getPaypalResponse={ this.props.getPaypalResponse }
                      applyPayment={ this.props.applyPayment }
                      cartSummary={ this.props.readCartData.cartSummary }
                      setCCPaymentFormSubmit={ this.props.setCCPaymentFormSubmit }
                      checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                      toggleInputFieldPaymentDisplay={ this.props.toggleInputFieldPaymentDisplay }
                      setTempPaymentCCVNumber={ this.props.setTempPaymentCCVNumber }
                      setCreditCardPaymentType={ this.props.setCreditCardPaymentType }
                      editCreditCardData={ this.props.editCreditCardData }
                      setEditCreditCardData={ this.props.setEditCreditCardData }
                      setEditAddressData={ this.props.setEditAddressData }
                      submitShippingAddressForm={ this.props.submitShippingAddressForm }
                      handleScrollView={ this.props.handleScrollView }
                      updatePaymentStatus={ this.props.updatePaymentStatus }
                      updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
                      editCCData={ this.props.editCCData }
                      isSetCCPaymentFormSubmit={ this.props.isSetCCPaymentFormSubmit }
                      previousPaymentType={ this.props.previousPaymentType }
                      toggleSecurityCode={ this.props.toggleSecurityCode }
                      displayType={ this.props.displayType }
                      fieldShowHideToggleData={ this.props.fieldShowHideToggleData }
                      showSecurityIcon={ this.props.showSecurityIcon }
                      checkoutFormConfig={ this.props.checkoutFormConfig }
                      shippingInfo={ this.props.readCartData.shippingInfo }
                      enableExpressPaypalCheckout={ this.props.switchData.switches.enableExpressPaypalCheckout }
                      paypalEnvironment={ this.props.switchData.switches.paypalEnvironment }
                      editAddressData={ this.props.editAddressData }
                      toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                      checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                      handleScrollToFormError={ this.props.handleScrollToFormError }
                      getProfileCreditCardList={ this.props.getProfileCreditCardList }
                      payPalClientToken={ this.props.payPalClientToken }
                      profileCreditCardList={ this.props.profileCreditCardList }
                      tempPaymentCCVNumber={ this.props.tempPaymentCCVNumber }
                      paymentDetails={ this.props.readCartData.paymentDetails }
                      paymentType={ this.props.paymentType }
                      showProfileCreditCardsSpinner={ this.props.showProfileCreditCardsSpinner }
                      broadcastMessage={ this.props.broadcastMessage }
                    />

                    <div className='CheckoutPage__giftRedeem'>
                      <GiftCard
                        removePaymentService={ this.props.removePaymentService }
                        giftCardApplying={ this.props.giftCardApplying }
                        updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
                        giftCardDetails={ this.props.giftCardDetails }
                        setCartRightPanelCollapse={ this.props.setCartRightPanelCollapse }
                        cartRightPanelCollapse={ this.props.cartRightPanelCollapse }
                        giftCardError={ this.props.giftCardError }
                        isGiftCardRemoved={ this.props.isGiftCardRemoved }
                      />
                      { ( () =>{
                        if( this.props.user.isSignedIn && this.props.user.isRewardsMember ){
                          return (
                            <CheckOutRedeemPoints
                              user={ this.props.user }
                              getRedeemPoints={ this.props.getRedeemPoints }
                              redeemPoints={ this.props.redeemPoints }
                              loyaltyCardDetails={ this.props.loyaltyCardDetails }
                              updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
                              removePaymentService={ this.props.removePaymentService }
                              isRewardPointsRemoved={ this.props.isRewardPointsRemoved }
                              placeHolder={ this.props.placeHolder }
                              broadcastMessage={ this.props.broadcastMessage }
                            />
                          );
                        }
                      } )() }
                      { ( () =>{
                        var remainingAmount = this.props.remainingPaymentDue;
                        remainingAmount = round( remainingAmount, 2 );

                        if( ( !isEmpty( this.props.giftCardDetails ) || !isEmpty( this.props.loyaltyCardDetails ) ) &&
                          isEmpty( this.props.creditCardDetails ) &&
                          this.props.remainingPaymentDue !== 0 ){
                          return (
                            <div className='CheckoutPage__remainingDue'>
                              <p>{ formatMessage( messages.remainingDue, { remainingAmount } ) }</p>
                              <PlusCircle/>
                              <Anchor
                                url='#'
                                clickHandler={ this.pageUpFor }
                              >
                                { formatMessage( messages.addNewPaymentMethod ) }
                              </Anchor>
                            </div>
                          );
                        }
                      } )() }
                    </div>
                  </div>
                </section>
                <div className='CheckoutPage__subHeader Gutter'>
                  <h3>
                    { formatMessage( messages.reviewYourItems ) }
                  </h3>
                  <span className='editMessage'>
                    <Anchor
                      url={ '/bag' }
                    >
                      { formatMessage( messages.editBag ) }
                    </Anchor>
                  </span>
                </div>

                <div className='CheckoutPage--divider Gutter'>
                  <Divider dividerType={ 'gray' }/>
                </div>

                <section className='Checkout__LeftPanel'>
                  { ( () =>{
                    let cartItems = this.productItems( 'cartItem' );
                    if( cartItems.commerceItems.length > 0 ){
                      return (
                        <div className='Checkout__Items Gutter'>
                          <div className='CheckoutPage__cartItems'>
                            <ProductCellList
                              productData={ cartItems.commerceItems }
                              displayProductInfo={ false }
                              removeFromCart={ this.props.removeFromCart }
                              showShippingRestrictionMsg={ this.props.cartPageData.showShippingRestrictionMsg }
                              errorRemoving={ this.props.errorRemoving }
                              removingItem={ this.props.removingItem }
                              commerceItemid={ this.props.commerceItemid }
                              removeItem={ this.props.removeItem }
                              remove={ this.props.cartPageData.removeItem }
                            />
                          </div>
                        </div>
                      )
                    }
                  } )() }

                  { ( () =>{
                    let giftItems = this.productItems( 'giftItem' );
                    if( giftItems.commerceItems.length > 0 ){
                      return (
                        <div className='CheckoutPage__gifts Gutter'>

                          <h3>
                            { formatMessage( messages.YourGifts ) }
                          </h3>
                          <Divider dividerType={ 'gray' }/>


                          <div className='CheckoutPage__gifts'>
                            <ProductCellList
                              productData={ giftItems.commerceItems }
                              displayProductInfo={ false }
                              removeFromCart={ this.props.removeFromCart }
                              showShippingRestrictionMsg={ this.props.cartPageData.showShippingRestrictionMsg }
                              errorRemoving={ this.props.errorRemoving }
                              removingItem={ this.props.removingItem }
                              commerceItemid={ this.props.commerceItemid }
                              removeItem={ this.props.removeItem }
                              remove={ this.props.cartPageData.removeItem }
                            />
                          </div>
                        </div>
                      )
                    }
                  } )() }
                  { ( () =>{
                    let sampleItem = this.productItems( 'sample' );
                    if( sampleItem.commerceItems.length > 0 ){
                      let svg;
                      switch ( sampleItem.commerceItems[0].brandName ){
                        case 'Fragrance':
                          svg = <FragranceIcon/>
                          break;

                        case 'Skincare':
                          svg = <SkincareIcon/>
                          break;

                        case 'Variety':
                          svg = <VarietyIcon/>
                          break;

                      }
                      return (
                        <div className='CheckoutPage__header--item CheckoutPage__giftsSection Gutter'>
                          <h3>
                            { formatMessage( messages.YourSamples ) }
                          </h3>
                          <Divider dividerType={ 'gray' }/>
                          <div className='CheckoutPage__samples'>
                            { svg }
                            <span className='CheckoutPage__samples__text'>
                              { sampleItem.commerceItems[0].brandName }
                            </span>
                          </div>
                        </div>
                      )
                    }
                  } )() }

                </section>
              </div>
              <Sticker>
                <section className='CartPage__MainContainerRightPanel CheckoutPage__StickyPanel'>
                  <div className='CheckoutPage__orderSummarySection Gutter'>
                    { ( () =>{
                      return (
                        <OrderSummaryItem
                          itemCount={ this.props.readCartData.cartSummary.itemCount }
                          giftBoxPrice={ this.props.readCartData.cartSummary.orderGiftWrapAmt }
                          giftCard={ this.props.readCartData.cartSummary.giftCard }
                          couponDiscountPrice={ this.props.readCartData.cartSummary.couponDiscount }
                          promotionalDiscountPrice={ this.props.readCartData.cartSummary.additionalDiscount }
                          shippingCost={ this.props.readCartData.cartSummary.shippingCost }
                          rewardPointsDiscount={ this.props.readCartData.cartSummary.rewardPointsDiscount }
                          estimatedTax={ this.props.readCartData.cartSummary.estimatedTax }
                          estimatedTotal={ this.props.readCartData.cartSummary.estimatedTotal }
                          subTotalPrice={ this.props.readCartData.cartSummary.subTotal }
                          displayEstimatedTotal={ false }
                          showBagSummary={ this.props.showBagSummary }
                          displayProductInfo={ this.props.displayProductInfo }
                          orderId={ this.props.orderId }
                        />
                      );
                    } )() }

                    { ( () =>{
                      if( this.props.switchData.switches.checkoutCouponEnabled === true ){
                        if( has( this.props.readCartData, 'appliedCouponSummary' ) && this.props.readCartData.appliedCouponSummary !== undefined ){
                          let appliedCouponSummary = this.props.readCartData.appliedCouponSummary;
                          return (
                            <Coupons
                              couponAppliedStatus={ appliedCouponSummary.couponAppliedStatus }
                              couponDescription={ appliedCouponSummary.couponDescription }
                              couponAppliedMsg={ appliedCouponSummary.couponAppliedMsg }
                              couponCode={ appliedCouponSummary.couponCode }
                              couponAppliedErrorMessage={ appliedCouponSummary.couponAppliedErrorMsg }
                              fromCheckout={ true }
                              couponApplying={ this.props.couponApplyingOnCheckout }
                              cartRightPanelCollapse={ this.props.cartRightPanelCollapse }
                              setCartRightPanelCollapse={ this.props.setCartRightPanelCollapse }
                              couponCodeUpdated={ this.props.couponCodeUpdated }
                              history={ this.props.history }
                              resetCouponsState={ this.props.resetCouponsState }
                              couponCodeRemoved={ this.props.couponCodeRemoved }
                            />
                          )
                        }
                      }
                      else {
                        return null;
                      }

                    } )() }

                    <UserRewardsLookup
                      isModalOpen={ this.state.isModalOpen }
                      modalStatus={ this.toggleModal }
                      getRewardsLookup={ this.props.getRewardsLookup }
                      setCartRightPanelCollapse={ this.props.setCartRightPanelCollapse }
                      cartRightPanelCollapse={ this.props.cartRightPanelCollapse }
                      creditCardDetails={ this.props.creditCardDetails }
                      user={ this.props.user }
                      isSignedIn={ this.props.isSignedIn }
                      preScreenBeautyClubNumber={ this.props.readCartData.preScreenBeautyClubNumber }
                      rewardPointsEarned={ this.props.readCartData.cartSummary.rewardPointsEarned }
                      joinNowRewardsError={ this.props.joinNowRewardsError }
                      isRewardsMember={ this.props.isRewardsMember }
                      lpsTurnOff={ this.props.switchData.switches.lpsTurnOff }
                      joinNowRewards={ this.props.joinNowRewards }
                      broadcastMessage={ this.props.broadcastMessage }
                    />

                    { ( () =>{
                      if( !this.props.isSignedIn ){
                        return (
                          <div>
                            <NewsLetterSignup
                              newsLetterSignupStatus={ this.props.newsLetterSignupStatus }
                              signUpLetterFlag={ this.props.signUpLetterFlag }
                            />
                          </div>
                        );
                      }
                    } )() }
                    <div className='CheckoutPage__Terms__Policy'>
                      <div className='CheckoutPage__Terms__Policy--copy'>
                        { formatMessage( messages.TCPPTextContent ) }
                      </div>
                      <div className='CheckoutPage__Terms__Policy--copy'>
                        <Anchor
                          url={ '/ulta/common/user_agreement.jsp' }
                          ariaLabel={ formatMessage( messages.termsAndConditions ) }
                          title={ formatMessage( messages.termsAndConditions ) }
                        >
                          { formatMessage( messages.termsAndConditions ) }
                        </Anchor>
                        <span> and </span>
                        <Anchor
                          url={ '/ulta/common/privacyPolicy.jsp' }
                          ariaLabel={ formatMessage( messages.privacyPolicy ) }
                          title={ formatMessage( messages.privacyPolicy ) }
                        >
                          { formatMessage( messages.privacyPolicy ) }
                        </Anchor>
                      </div>
                    </div>

                    <div className='CheckoutPage__Button'>
                      <PlaceOrderComponent
                        isErrorBeforeSubmitOrder={ this.props.isErrorBeforeSubmitOrder }
                        holdDavPopUp={ this.props.holdDavPopUp }
                        isSignedIn={ this.props.isSignedIn }
                        estimatedTotal={ this.props.readCartData.cartSummary.estimatedTotal }
                        shippingError={ this.props.shippingError }
                        validateShippingForm={ this.props.validateShippingForm }
                        submitShippingAddressForm={ this.props.submitShippingAddressForm }
                        handleScrollView={ this.props.handleScrollView }
                        paymentServiceResponse={ this.props.paymentServiceResponse }
                        submitPaymentForm={ this.props.submitPaymentForm }
                        submitPaymentFormCvv={ this.props.submitPaymentFormCvv }
                        paymentType={ this.props.paymentType }
                        creditCardDetails={ this.props.creditCardDetails }
                        isCouponButtonClicked={ this.props.isCouponButtonClicked }
                        paymentForm={ this.props.paymentForm }
                        creditCardPaymentType={ this.props.creditCardPaymentType }
                        editCreditCardData={ this.props.editCreditCardData }
                        editCCData={ this.props.editCCData }
                        tempPaymentCCVNumber={ this.props.tempPaymentCCVNumber }
                        setTempPaymentCCVNumber={ this.props.setTempPaymentCCVNumber }
                        signUpLetterFlag={ this.props.signUpLetterFlag }
                        anchorAfterSubmitServiceCall={ this.props.anchorAfterSubmitServiceCall }
                        readCartData={ this.props.readCartData }
                        updateDavPopup={ this.props.updateDavPopup }
                        updateSubmitOrder={ this.props.updateSubmitOrder }
                      />
                    </div>
                  </div>

                </section>
              </Sticker>
            </div>
          </div>
        </MetaData>
      );
    }


  }
}
export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( CheckoutPage ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );
