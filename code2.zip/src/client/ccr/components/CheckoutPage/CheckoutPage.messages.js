/*
 * CheckoutPage Messages
 *
 * This contains all the text for the CheckoutPage component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  loginButtonText: {
    id: 'i18n.checkoutpage.loginButtonText',
    defaultMessage: 'SIGN IN'
  },
  reviewYourItems: {
    id: 'i18n.CheckoutPage.reviewYourItems',
    defaultMessage: 'Review Your Items'
  },
  editBag: {
    id: 'i18n.CheckoutPage.editBag',
    defaultMessage: 'Edit Bag'
  },
  Items: {
    id: 'i18n.CheckoutPage.Items',
    defaultMessage: 'Items'
  },
  payment: {
    id: 'i18n.HeaderBagSummary.payment',
    defaultMessage: 'Payment & Billing'
  },
  shipping: {
    id: 'i18n.CheckoutPage.shipping',
    defaultMessage: 'Shipping'
  },
  HomeAddress: {
    id: 'i18n.CheckoutPage.HomeAddress',
    defaultMessage: 'Home Address'
  },
  YourGifts: {
    id: 'i18n.HeaderBagSummary.YourGifts',
    defaultMessage: 'Your Gifts'
  },
  YourSamples: {
    id: 'i18n.HeaderBagSummary.YourSamples',
    defaultMessage: 'Your Samples'
  },
  termsAndConditions: {
    id: 'i18n.CheckoutPage.termsAndConditions',
    defaultMessage: 'Terms & Conditions'
  },
  privacyPolicy: {
    id: 'i18n.CheckoutPage.privacyPolicy',
    defaultMessage: 'Privacy Policy'
  },
  TCPPTextContent: {
    id: 'i18n.CheckoutPage.TCPPTextContent',
    defaultMessage: 'By placing an order, you agree to ULTA.com\'s'
  },
  checkoutSignInHeader: {
    id: 'i18n.CheckoutPage.checkoutSignInHeader',
    defaultMessage: 'Sign In For Faster Checkout & Access to Rewards!'
  },
  guestCheckoutHeader: {
    id: 'i18n.CheckoutPage.guestCheckoutHeader',
    defaultMessage: 'Continue With Guest Checkout'
  },
  guestCheckoutFooter: {
    id: 'i18n.CheckoutPage.guestCheckoutFooter',
    defaultMessage: 'You can create an account and sign up for rewards after completing checkout'
  },
  Shipping: {
    id: 'i18n.CheckoutPage.Shipping',
    defaultMessage: 'Shipping'
  },
  remainingDue: {
    id: 'i18n.CheckoutPage.remainingDue',
    defaultMessage: 'Remaining Payment due: ${remainingAmount}'
  },
  addNewPaymentMethod: {
    id:'i18n.CheckoutPage.addNewPaymentMethod',
    defaultMessage: 'Add additional payment method'
  },
  checkoutLevelGenericError: {
    id:'i18n.CheckoutPage.checkoutLevelGenericError',
    defaultMessage: 'Almost! Fix the errors below and try again.'
  },
  checkoutTitle: {
    id:'i18n.CheckoutPage.checkoutTitle',
    defaultMessage: 'Secure Checkout | Cosmetics, Fragrance, Skincare and Beauty Gifts'
  }
} );
