import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { initialState } from 'ccr/reducers/CheckoutPage/CheckoutPage.reducer';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import messages from './CheckoutPage.messages';
import placeOrderMessages from 'ccr/components/PlaceOrderComponent/PlaceOrderComponent.messages';
import { touch } from 'redux-form';
import {
  actions as checkoutPageActions
} from 'ccr/actions/CheckoutPage/CheckoutPage.actions';

import {
  getActionDefinition,
  registerServiceName
} from 'shared/actions/Services/Services.actions';

import CheckoutPage, {
  connectFunction,
  mapStateToProps,
  mapDispatchToProps
} from './CheckoutPage';

import {
  actions as miniCartActions
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  actions as formActions
} from 'shared/actions/Forms/Forms.actions';

import {
  actions as userActions
} from 'shared/actions/User/User.actions';

import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';

import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';

import { Helmet } from 'react-helmet';

import find from 'lodash/find'

const store = configureStore( {}, CONFIG );
global.globalPageData = {};

let appElement = document.createElement( 'div' );
appElement.id='js-cartpage';
document.body.appendChild( appElement );

registerServiceName( 'readCart' );
describe( '<CheckoutPage />', () => {

  let props = initialState;
  props.resetCartMerge = jest.fn();
  props.handleScrollView = jest.fn();
  store.getState().global = {
    switchData: {
      switches: {
        guestServiceHours:'7am-11pm',
        checkoutCouponEnabled: true
      }
    },
    isCheckoutDataAvailable:true,
    history:[]
  };
  store.getState().checkoutPage = {
    ...props,
    isCheckoutDataAvailable:true,
    giftCardDetails:{
      paymentInfo:{
        paymentType:'giftCard',
        amount:25.5,
        paymentDetails:{
          giftcardBalance:350,
          currencyCode:'USD',
          giftcardNumber:'1234'
        }
      },
      messages:[
        {
          messageKey:'giftcardbalance',
          messageType:'Info',
          messageDesc:'Your gift card has been applied. You have $9,830.00 remaining on this card.',
          messageField:'paymentInfo.payemntDetails.amount'
        }
      ]
    },
    loyaltyCardDetails:{
      paymentInfo:{
        paymentType:'loyalty',
        amount:61,
        paymentDetails:{
          pointsApplied:1200,
          pointsBalance:50,
          currencyCode:'USD'
        }
      },
      messages:[
        {
          messageDesc:'Sorry we are Experiencing an issue right now.',
          messageKey:'LOYALTY_NOT_APPLIED',
          messageType:'Error',
          messageField:'paymentInfo.payemtnDetails.amount'
        }
      ]
    },
    remainingPaymentDue: 30.95,
    readCartData:{
      'cartSummary': {
        'shippingCost': 5.95,
        'subTotal': 160.98999999999998,
        'itemCount': '9',
        'orderGiftWrapAmt': 3.99,
        'additionalDiscount': null,
        'couponDiscount': 0,
        'estimatedTax': 'TBD',
        'estimatedTotal': 170.93,
        'currencyCode': 'USD',
        'rewardPointsDiscount': -3.00
      },
      'id': 'US463704869',
      'cartItems': {
        'commerceItems': [
          {
            'couponApplied': false,
            'brandName': 'Laura Geller Beauty',
            'quantity': 2,
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': false,
            'adbugMessageMap': null,
            'catalogRefId': '2230775',
            'hazmatCode': 'Ships within Continental US only',
            'discountMessage': '',
            'commerceItemid': 'ci270000001',
            'priceInfo': {
              'salePrice': null,
              'regularPrice': '$12.00',
              'unitPriceMessage': '2 @ $6.00'
            },
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2230775?$md$',
            'variantInfo': {

            },
            'skuDisplayName': 'Salon Topcoat',
            'productURL': '/salon-nail-clear-topcoat?productId=xlsImpprod3570045&sku=2230775',
            'itemType': 'cartItem'
          },
          {
            'couponApplied': false,
            'brandName': 'Calvin Klein',
            'quantity': 2,
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': false,
            'adbugMessageMap': {
              'adbugMessage': 'Group discount_Bundle_Buy 1 of 2154759 and 3 of 5051326,get group discount of $40!',
              'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
            },
            'catalogRefId': '2230775',
            'hazmatCode': 'Ships within Continental US only',
            'discountMessage': '',
            'commerceItemid': 'ci270000001',
            'priceInfo': {
              'salePrice': null,
              'regularPrice': '$12.00',
              'unitPriceMessage': '2 @ $6.00'
            },
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$',
            'variantInfo': {

            },
            'skuDisplayName': 'Nail Clear',
            'productURL': '/salon-nail-clear-topcoat?productId=xlsImpprod3570045&sku=2230775',
            'itemType': 'cartItem'
          },
          {
            'couponApplied': true,
            'brandName': 'MAC Foundation',
            'quantity': 2,
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': false,
            'adbugMessageMap': {
              'adbugMessage': 'Buy 2, get 1 off!',
              'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
            },
            'catalogRefId': '2230775',
            'hazmatCode': 'Ships within Continental US only',
            'discountMessage': '',
            'commerceItemid': 'ci270000001',
            'priceInfo': {
              'salePrice': null,
              'regularPrice': '$12.00',
              'unitPriceMessage': '2 @ $6.00'
            },
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
            'variantInfo': {

            },
            'skuDisplayName': 'Salon',
            'productURL': '/salon-nail-clear-topcoat?productId=xlsImpprod3570045&sku=2230775',
            'itemType': 'cartItem'
          },
          {
            'couponApplied': false,
            'brandName': 'Cleanser',
            'quantity': 2,
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': false,
            'adbugMessageMap': null,
            'catalogRefId': '2230775',
            'hazmatCode': 'Ships within Continental US only',
            'discountMessage': '',
            'commerceItemid': 'ci270000001',
            'priceInfo': {
              'salePrice': null,
              'regularPrice': '$11.00',
              'unitPriceMessage': '1 @ $6.00 2 @ $5.50'
            },
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/22185888?$md$',
            'variantInfo': {

            },
            'skuDisplayName': 'Salon Nail Clear Topcoat',
            'productURL': '/salon-nail-clear-topcoat?productId=xlsImpprod3570045&sku=2230775',
            'itemType': 'cartItem'
          },
          {
            'couponApplied': true,
            'brandName': 'Calvin Klein',
            'quantity': 4,
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': true,
            'adbugMessageMap': null,
            'catalogRefId': '2230775',
            'hazmatCode': 'Ships within Continental US only',
            'discountMessage': 'Discount applied on lowest marked item',
            'commerceItemid': 'ci270000001',
            'priceInfo': {
              'salePrice': null,
              'regularPrice': '$12.00',
              'unitPriceMessage': '2 @ $6.00'
            },
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$',
            'variantInfo': {

            },
            'skuDisplayName': 'Nail Clear',
            'productURL': '/salon-nail-clear-topcoat?productId=xlsImpprod3570045&sku=2230775',
            'itemType': 'cartItem'
          },
          {
            'couponApplied': true,
            'brandName': 'MAC Foundation',
            'quantity': 3,
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': false,
            'adbugMessageMap': {
              'adbugMessage': 'Buy 1, get 1 at 50% off! ',
              'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
            },
            'catalogRefId': '2230775',
            'hazmatCode': 'Ships within Continental US only',
            'discountMessage': 'Discount applied',
            'commerceItemid': 'ci270000001',
            'priceInfo': {
              'salePrice': null,
              'regularPrice': '$22.00',
              'unitPriceMessage': '1 @ $8.00 3 @ $22.00'
            },
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
            'variantInfo': {

            },
            'skuDisplayName': 'Salon',
            'productURL': '/salon-nail-clear-topcoat?productId=xlsImpprod3570045&sku=2230775',
            'itemType': 'cartItem'
          },
          {
            'couponApplied': false,
            'brandName': 'GIO Armani',
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': false,
            'adbugMessageMap': null,
            'catalogRefId': '2230775',
            'hazmatCode': 'Ships within Continental US only',
            'discountMessage': '',
            'commerceItemid': 'ci270000001',
            'priceInfo': {
              'salePrice': null,
              'regularPrice': 'FREE'
            },
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2257743?$md$',
            'variantInfo': {

            },
            'skuDisplayName': 'Clear Topcoat',
            'productURL': '/salon-nail-clear-topcoat?productId=xlsImpprod3570045&sku=2230775',
            'itemType': 'giftItem'
          },
          {
            'couponApplied': false,
            'brandName': 'Eye Liner',
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': false,
            'adbugMessageMap': null,
            'catalogRefId': '2230775',
            'hazmatCode': 'Ships within Continental US only',
            'discountMessage': '',
            'commerceItemid': 'ci270000001',
            'priceInfo': {
              'salePrice': null,
              'regularPrice': 'FREE'
            },
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'imageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
            'variantInfo': {

            },
            'skuDisplayName': 'Salon Nail',
            'productURL': '/salon-nail-clear-topcoat?productId=xlsImpprod3570045&sku=2230775',
            'itemType': 'giftItem'
          },
          {
            'couponApplied': false,
            'brandName': 'Fragrance',
            'quantity': 1,
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': false,
            'adbugMessageMap': null,
            'catalogRefId': '2230775',
            'discountMessage': '',
            'commerceItemid': 'ci270000001',
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'skuDisplayName': 'Salon Nail Clear Topcoat',
            'productURL': '/salon-nail-clear-topcoat?productId=xlsImpprod3570045&sku=2230775',
            'itemType': 'sample'
          }
        ]
      },
      'paymentDetails': [
        {
          'paymentInfo': {
            'paymentType': 'creditCard',
            'paymentDetails': {
              'expirationMonth': '09',
              'expirationYear': '2021',
              'creditCardNumber': '1111',
              'creditCardType': 'Visa'
            },
            'amount': 46.18,
            'currencyCode': 'USD',
            'contactInfo': {
              'firstName': 'Pushpendra',
              'lastName': 'Kabdaula',
              'phoneNumber': '123-456-7890',
              'email': 'pkabdaula@ulta.com',
              'address1': '1000 remngton blvd',
              'address2': 'Ste 200',
              'city': 'Boolingbrook',
              'state': 'IL',
              'zipCode': '07105-2258',
              'country': 'US'
            }
          },
          'messages': [
            {
              'messageDesc': 'Sorry we are Experiencing an issue right now.',
              'messageKey': 'CREDIT_CARD_NOT_APPLIED',
              'messageType': 'Error'
            },
            {
              'messageDesc': 'Credit card is expired.',
              'messageKey': 'CREDIT_CARD_NOT_VALID',
              'messageType': 'Error',
              'messageField': 'paymentInfo.payemtnDetails.expirationYear'
            }
          ]
        }
      ],
      'shippingInfo': {
        'shippingStatus': 'CorrectedAddress',
        'shippingAddress': {
          'firstName': 'Jane',
          'lastName': 'Doe',
          'address1': '1000 Remington Boulevard',
          'address2': 'Suite # 120',
          'city': 'Bolingbrook',
          'state': 'IL',
          'postalCode': '60564',
          'phoneNumber': '(510)-213-8347'
        },
        'correctedShippingAddress': {
          'firstName': 'Jane',
          'lastName': 'Doe',
          'address1': '1000 Remington Blvd',
          'address2': 'Suite # 120',
          'city': 'Bolingbrook',
          'state': 'IL',
          'postalCode': '60440',
          'phoneNumber': '(510)-213-8347'
        },
        'shipInfo': {
          'shipMethod': 'ups_ground',
          'estimatedDelivery': 'Within 3 to 8 business days',
          'cost': '$5.95',
          'displayName': 'Standard Ground Shipping'
        },
        'messages': [
          {
            'messageDesc': 'A correction available for the specified shipping address.',
            'messageKey': 'SHIP_ADDRESS_CORRECTION',
            'messageType': 'Info'
          }
        ]
      },
      'appliedCouponSummary': {
        'couponAppliedStatus': false,
        'couponOfferReqNotMet': true,
        'couponAppliedMsg': 'CPW13345 has been applied',
        'couponCode': 'CPW12345',
        'couponAppliedErrorMessage': 'Discount will appear once offer requirements have been met'
      }
    },
    checkoutError:[
      {
        'messageKey': 'ERROR_PROCESSING_ORDER',
        'messageType': 'Error',
        'messageDesc': 'Error Processing the Order. Please try again..',
        'messageRef': 'checkout'
      }
    ],
    displayCheckoutLevelErrorMessage: false

  }
  let component = mountWithIntl(
    <Provider store={ store }>
      <CheckoutPage { ...props } />
    </Provider>
  );
  it( 'renders without crashing', ( ) => {
    expect( component.find( 'CheckoutPage' ).length ).toBe( 1 );
  } );

  it( 'should contain Secure Checkout in the checkoutPage title', () => {
    const helmet = Helmet.peek();
    expect( helmet.title[0] ).toEqual( messages.checkoutTitle.defaultMessage );
  } );

  it( 'Should contain ProductCellList component', ( ) => {
    expect( component.find( 'ProductCellList' ).length ).toBe( 2 );
  } );

  it( 'should render the samples section', ( ) => {
    expect( component.find( '.CheckoutPage__samples' ).length ).toBe( 1 );
  } )

  it( 'should render the header summary for the product cells', ( ) => {
    expect( component.find( '.CheckoutPage__header--item' ).length ).toBe( 1 );
  } );

  it( 'Should render the CheckoutPage header', ( ) => {
    expect( component.find( '.CheckoutPage .CheckoutPage__subHeader' ).length ).toBe( 1 );
  } );

  it( 'renders order summary component', () => {
    expect( component.find( 'OrderSummaryItem' ).length ).toBe( 1 );
  } );

  it( 'renders NewsLetterSignup component', () => {
    expect( component.find( 'NewsLetterSignup' ).length ).toBe( 1 );
  } );

  it( 'renders NewsLetterSignup component', () => {
    expect( component.find( 'UserRewardsLookup' ).length ).toBe( 1 );
  } );

  it( 'should render the edit bag component', ( ) => {
    expect( component.find( '.CheckoutPage .editMessage' ).text( ) ).toBe( messages.editBag.defaultMessage );
  } );

  it( 'should render anchor component for the editMessage', ( ) => {
    expect( component.find( '.CheckoutPage .CheckoutPage__subHeader .Anchor' ).length ).toBe( 1 );
  } );

  it( 'should render LoginForm component', ( ) => {
    expect( component.find( 'LoginForm' ).length ).toBe( 1 );
  } );

  it( 'should render Shipping form component', ( ) => {
    expect( component.find( 'ShippingInformation' ).length ).toBe( 1 );
  } );

  it( 'should Display signin heading', ( ) => {
    expect( component.find( '.CheckoutPage__LoginPanel' ).length ).toBe( 1 );
  } );

  it( 'should render Divider component', ( ) => {
    expect( component.find( '.CheckoutPage__SignIn .CheckoutPage__SignIn--Divider' ).find( 'Divider' ).length ).toBe( 1 );
  } );

  it( 'should render Guest Message', ( ) => {
    expect( component.find( '.CheckoutPage__SignIn--FooterText' ).text( ) ).toBe( messages.guestCheckoutFooter.defaultMessage );
  } );

  it( 'should render correct url for the editMessage', ( ) => {
    expect( component.find( '.CheckoutPage .CheckoutPage__subHeader .Anchor a' ).props().href ).toBe( '//www.ulta.com/bag' )
  } );

  it( 'should contain place order button component', ( ) => {
    expect( component.find( '.CheckoutPage__Button' ).length ).toBe( 1 );
    expect( component.find( 'button.CheckoutPage__Button--placeorder' ).length ).toBe( 1 );
    expect( component.find( '.CheckoutPage__Button--placeorder--img' ).length ).toBe( 1 );
    expect( component.find( '.CheckoutPage__Button--placeorder--msg' ).text() ).toEqual( placeOrderMessages.placeOrder.defaultMessage );
  } );

  it( 'should render copy below place order button', ( ) => {
    expect( component.find( '.CheckoutPage .CheckoutPage__Terms__Policy' ).length ).toBe( 1 );
  } );

  it( 'should render correct url for Terms & Conditions and Privacy Policy', ( ) => {
    expect( component.find( '.CheckoutPage .CheckoutPage__Terms__Policy .Anchor' ).at( 0 ).props().href ).toBe( '//www.ulta.com/ulta/common/user_agreement.jsp' );
    expect( component.find( '.CheckoutPage .CheckoutPage__Terms__Policy .Anchor' ).at( 1 ).props().href ).toBe( '//www.ulta.com/ulta/common/privacyPolicy.jsp' );
  } );

  it( 'Show the error message', () => {
    expect( component.find( '.CheckoutPage__remainingDue' ).length ).toBe( 1 );
  } );

  it( 'should render Anchor link for add payment method', () => {
    expect( component.find( '.CheckoutPage__remainingDue .Anchor' ).length ).toBe( 1 );
    expect( component.find( '.CheckoutPage__remainingDue .Anchor' ).text() ).toBe( messages.addNewPaymentMethod.defaultMessage );
  } );

  it( 'should handle Anchor click event to add payment method', () => {
    let mockJestFn = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) =>{
      return {
        setEditAddressData: ( data ) =>{
          dispatch( checkoutPageActions.setEditAddressData( data ) );
        },
        getCheckoutPage: ( data ) =>{
          dispatch( getActionDefinition( 'readCart', 'requested' )( data ) );
        },
        newsLetterSignupStatus: ( status ) =>{
          dispatch( checkoutPageActions.newsLetterSignupStatus( status ) );
        },
        handleScrollView : mockJestFn
      }
    }

    let CheckoutPageMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <CheckoutPageMock { ...props }/>
      </Provider>
    );

    let node = component1.find( 'CheckoutPage' );
    node.pageUpFor = mockJestFn;

    component1.find( '.CheckoutPage__remainingDue .Anchor' ).at( 0 ).simulate( 'click' );
    expect( node.pageUpFor ).toBeCalled();
  } );

  it( 'should have invoke the element focus when pageUpFor method is invoked', () => {
    let mockJestFn = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) =>{
      return {
        setEditAddressData: ( data ) =>{
          dispatch( checkoutPageActions.setEditAddressData( data ) );
        },
        getCheckoutPage: ( data ) =>{
          dispatch( getActionDefinition( 'readCart', 'requested' )( data ) );
        },
        newsLetterSignupStatus: ( status ) =>{
          dispatch( checkoutPageActions.newsLetterSignupStatus( status ) );
        },
        handleScrollView : mockJestFn
      }
    }

    let CheckoutPageMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <CheckoutPageMock { ...props }/>
      </Provider>
    );

    let node = component1.find( 'CheckoutPage' ).instance();
    node.pageUpFor();
    expect( node.props.handleScrollView ).toBeCalledWith( 'checkoutPaymentHeader' );
  } );

  it( 'dont show the error message', () => {
    store.getState().checkoutPage.remainingPaymentDue = 0;
    component = mountWithIntl(
      <Provider store={ store }>
        <CheckoutPage { ...props }/>
      </Provider>
    );
    expect( component.find( '.CheckoutPage__remainingDue' ).length ).toBe( 0 );
  } );

  it( 'should render Coupons component', ( ) => {
    expect( component.find( 'CheckoutPage .Coupons' ).length ).toBe( 1 );
  } );

  it( 'should render Error Messages if there is checkout level errors after submit order', ( ) => {
    expect( component.find( 'CheckoutPage .CheckoutPage__errorMessages ResponseMessages' ).length ).toBe( 1 );
    expect( component.find( 'CheckoutPage .CheckoutPage__errorMessages ResponseMessages' ).props().message ).toBe( store.getState().checkoutPage.checkoutError[0].messageDesc );
  } );

  it( 'should invoke focus method once the togglemodal is invoked', () => {
    let node = component.find( 'CheckoutPage' ).instance();
    expect( node.state.isModalOpen ).toBeFalsy();
    node.toggleModal();
    expect( node.state.isModalOpen ).toBeTruthy();
  } );

  it( 'should render front-end Error Message if there is no checkout level error after submit order', ( ) => {
    store.getState().checkoutPage.checkoutError= [];
    store.getState().checkoutPage.displayCheckoutLevelErrorMessage= true;
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <CheckoutPage { ...props }/>
      </Provider>
    );
    expect( component1.find( 'CheckoutPage .CheckoutPage__errorMessages ResponseMessages' ).length ).toBe( 1 );
    expect( component1.find( 'CheckoutPage .CheckoutPage__errorMessages ResponseMessages' ).props().message ).toBe( messages.checkoutLevelGenericError.defaultMessage );
  } );

  it( 'Merge Cart', () => {
    store.getState().checkoutPage.cartMerged = true;
    let resetCartMergeMock = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) =>{
      return {
        setEditAddressData: ( data ) =>{
          dispatch( checkoutPageActions.setEditAddressData( data ) );
        },
        getCheckoutPage: ( data ) =>{
          dispatch( getActionDefinition( 'readCart', 'requested' )( data ) );
        },
        newsLetterSignupStatus: ( status ) =>{
          dispatch( checkoutPageActions.newsLetterSignupStatus( status ) );
        },
        resetCartMerge : resetCartMergeMock
      }
    }

    let CheckoutPageMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );

    let comp = mountWithIntl(
      <Provider store={ store }>
        <CheckoutPageMock { ...props }/>
      </Provider>
    );
    store
      .getState()
      .cartMerged = true;
    comp.update();
    expect( resetCartMergeMock ).toBeCalled();
  } );

  it( 'Should have broadcastmessage as a prop to PaymentInformation', ()=>{
    expect( component.find( 'PaymentInformation' ).props().broadcastMessage ).toBeTruthy();
  } );

  it( 'Should not show CheckOutRedeemPoints if the user is not a reward member', ()=>{
    store.getState().user.isRewardsMember=false;
    mountWithIntl(
      <Provider store={ store }>
        <CheckoutPage { ...props }/>
      </Provider>
    );
    expect( component.find( '.CheckOutRedeemPoints' ).length ).toBe( 0 );
  } );

  it( 'show CheckOutRedeemPoints if the user is reward member', ()=>{
    store.getState().user.isRewardsMember =true;
    store.getState().user.isSignedIn =true;
    store.getState().checkoutPage.getRedeemPoints =jest.fn();
    store.getState().checkoutPage.isRewardPointsRemoved=true;
    props.removePaymentService =jest.fn();
    props.placeHolder ='Select Rewards Points';
    let component = mountWithIntl(
      <Provider store={ store }>
        <CheckoutPage { ...props }/>
      </Provider>
    );
    expect( component.find( '.CheckOutRedeemPoints' ).length ).toBe( 1 );
    expect( component.find( 'CheckOutRedeemPoints' ).props().isRewardPointsRemoved ).toBe( true );
    expect( component.find( 'CheckOutRedeemPoints' ).props().placeHolder ).toBe( 'Select Rewards Points' );
    expect( component.find( 'CheckOutRedeemPoints' ).props().removePaymentService ).toBeTruthy();
    expect( component.find( 'CheckOutRedeemPoints' ).props().broadcastMessage ).toBeTruthy();
  } );

  it( 'show GiftCard', ()=>{
    store.getState().checkoutPage.isGiftCardRemoved=true;
    let component = mountWithIntl(
      <Provider store={ store }>
        <CheckoutPage { ...props }/>
      </Provider>
    );
    expect( component.find( 'GiftCard' ).props().isGiftCardRemoved ).toBe( true );
  } );

  it( 'should display proper heading for review your items and the link for edit bag', ()=>{
    expect( component.find( '.CheckoutPage__subHeader h3' ).text() ).toBe( messages.reviewYourItems.defaultMessage );
    expect( component.find( '.CheckoutPage__subHeader a' ).text() ).toBe( messages.editBag.defaultMessage );
  } );

  component = mountWithIntl(
    <Provider store={ store }>
      <CheckoutPage { ...props }/>
    </Provider>
  );
  const instance = component.find( 'CheckoutPage' ).instance();

  it( 'should call the toggleModal method', () => {
    expect( instance.state.isModalOpen ).toEqual( false );
    instance.toggleModal();
    expect( instance.state.isModalOpen ).toEqual( true );
  } );

  it( 'Should have broadcastmessage as a prop to UserRewardsLookup', ()=>{
    expect( component.find( 'UserRewardsLookup' ).props().broadcastMessage ).toBeTruthy();
  } );

} );



describe( 'Merge Cart Functionality', () => {
  let props = initialState;
  const store1 = configureStore( {}, CONFIG );
  store1.getState().global = {
    shippingInfo:{},
    history:[]
  };
  store1.getState().checkoutPage = {
    ...props,
    resetCartMerge: jest.fn( ()=>true ),
    firePreScreenLPSEvent: jest.fn( ()=>true ),
    getRealtimeOLPS: jest.fn( ()=>true ),
    history:[],
    shippingInfo:{}
  }

  let component = mountWithIntl(
    <Provider store={ store1 }>
      <CheckoutPage { ...props }/>
    </Provider>
  );
  it( 'cart Merge should be false if the service returns true after user login in checkout', ( ) => {
    store1.getState().checkoutPage={
      cartMerged:true
    }

    mountWithIntl(
      <Provider store={ store1 }>
        <CheckoutPage { ...props }/>
      </Provider>
    );

    expect( store1.getState().checkoutPage.cartMerged ).toBe( false );
  } );

  it( 'cart Merge should be false if the service returns false after user login in checkout111', ( ) => {
    store1.getState().checkoutPage={
      cartMerged:false
    }

    component = mountWithIntl(
      <Provider store={ store1 }>
        <CheckoutPage { ...props }/>
      </Provider>
    );

    expect( store1.getState().checkoutPage.cartMerged ).toBe( false );
  } );

  it( 'should have firePreScreenLPSEvent in the props', () => {
    expect( component.find( 'CheckoutPage' ).props() ).toHaveProperty( 'firePreScreenLPSEvent' )
  } );

  it( 'should have getRealtimeOLPS in the props', () => {
    expect( component.find( 'CheckoutPage' ).props() ).toHaveProperty( 'getRealtimeOLPS' )
  } );

  const closeRealtimeModalMock = jest.fn();
  let mapDispatchToPropsMock = ( dispatch ) =>{
    return {
      closeRealtimeModal: closeRealtimeModalMock,
      setEditAddressData: ( data ) =>{
        dispatch( checkoutPageActions.setEditAddressData( data ) );
      },
      getCheckoutPage: ( data ) =>{
        dispatch( getActionDefinition( 'readCart', 'requested' )( data ) );
      },
      newsLetterSignupStatus: ( status ) =>{
        dispatch( checkoutPageActions.newsLetterSignupStatus( status ) );
      }
    }
  }

  it( 'should invoke closeRealtimeModal on componentWillUnmount', () => {
    let CheckoutPageMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let component = mountWithIntl(
      <Provider store={ store }>
        <CheckoutPageMock { ...props }/>
      </Provider>
    );
    component.find( 'CheckoutPage' ).instance().componentWillUnmount();
    expect( closeRealtimeModalMock ).toBeCalled();
  } );

} );

describe( '<CheckoutPage /> - MapDispatchToProps', () => {
  const store = configureStore( {}, CONFIG );
  const props = {
    checkoutPage: jest.fn(),
    user: jest.fn(),
    session: jest.fn(),
    pagedata:jest.fn(),
    minicart:jest.fn(),
    global:jest.fn()
  }
  const component = mountWithIntl(
    <Provider store={ store }>
      <CheckoutPage { ...props }/>
    </Provider>
  );
  const dispatch = jest.fn();
  beforeEach( ()=> {
    dispatch.mockClear();
  } )
  const mdp  = mapDispatchToProps( dispatch );

  it( 'resetCartMerge should dispatch the proper action', ( ) => {
    mdp.resetCartMerge();
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.resetCartMerge( ) )
  } );

  it( 'submitUserLogin should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'login' );
    const event = mdp.submitUserLogin( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'login', 'requested' )( data )
    );
  } );
  it( 'applyPayment should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'applyPayment' );
    mdp.applyPayment( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'applyPayment', 'requested' )( data )
    );
  } );
  it( 'applyPaymentSameSession should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'applyPaymentSameSession' );
    mdp.applyPaymentSameSession( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'applyPaymentSameSession', 'requested' )( data )
    );
  } );
  it( 'savePaypaltoMyAccount should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'savePaypaltoMyAccount' );
    mdp.savePaypaltoMyAccount( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'savePaypaltoMyAccount', 'requested' )( data )
    );
  } );

  it( 'getBannerData should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'banner' );
    mdp.getBannerData( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'banner', 'requested' )( data )
    );
  } );

  it( 'updateCreditCard should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'submitCreditCard' );
    mdp.updateCreditCard( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'submitCreditCard', 'requested' )( data )
    );
  } );

  it( 'getRealtimeOLPS should dispatch the proper action', () => {
    registerServiceName( 'RealtimeOLPS' );
    mdp.getRealtimeOLPS( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'RealtimeOLPS', 'requested' )( )
    );
  } );

  it( 'firePreScreenLPSEvent should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'preScreenLPSEvent' );
    mdp.firePreScreenLPSEvent( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'preScreenLPSEvent', 'requested' )( data )
    );
  } );

  it( 'getAddressBook should dispatch the proper action', () => {
    registerServiceName( 'addressbook' );
    mdp.getAddressBook( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'addressbook', 'requested' )( )
    );
  } );
  it( 'getEstimatedDelivery should dispatch the proper action', () => {
    registerServiceName( 'estimatedDeliveryDate' );
    mdp.getEstimatedDelivery( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'estimatedDeliveryDate', 'requested' )( )
    );
  } );
  it( 'getShipMethod should dispatch the proper action', () => {
    registerServiceName( 'getQualifiedShipMethod' );
    mdp.getShipMethod( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'getQualifiedShipMethod', 'requested' )( )
    );
  } );
  it( 'getRedeemPoints should dispatch the proper action', () => {
    registerServiceName( 'redeemPoints' );
    mdp.getRedeemPoints( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'redeemPoints', 'requested' )( )
    );
  } );
  it( 'updatePaymentServiceResponse should dispatch the proper action', () => {
    const loyalty = jest.fn();
    registerServiceName( 'paymentServiceResponse' );
    mdp.updatePaymentServiceResponse( loyalty );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'paymentServiceResponse', 'requested' )( loyalty )
    );
  } );
  it( 'removePaymentService should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'removePaymentService' );
    mdp.removePaymentService( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'removePaymentService', 'requested' )( data )
    );
  } );
  it( 'updateShipMethod should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'shippingUpdate' );
    mdp.updateShipMethod( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'shippingUpdate', 'requested' )( data )
    );
  } );
  it( 'getRewardsLookup should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'rewardsLookup' );
    mdp.getRewardsLookup( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'rewardsLookup', 'requested' )( data )
    );
  } );

  it( 'getProfileData should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'profile' );
    mdp.getProfileData( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'profile', 'requested' )( data )
    );
  } );

  it( 'getProfileCreditCardList should dispatch the proper action', () => {
    registerServiceName( 'profileCreditCards' );
    mdp.getProfileCreditCardList( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'profileCreditCards', 'requested' )( )
    );
  } );

  it( 'updateSubmitOrder should dispatch the proper action', () => {
    const data = jest.fn();
    registerServiceName( 'submitOrderService' );
    mdp.updateSubmitOrder( data );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'submitOrderService', 'requested' )( data )
    );
  } );

  it( 'getPaypalToken should dispatch the proper action', () => {
    registerServiceName( 'paypalToken' );
    mdp.getPaypalToken();
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'paypalToken', 'requested' )( )
    );
  } );

  it( 'joinNowRewards should dispatch the proper action', () => {
    registerServiceName( 'userRewards' );
    mdp.joinNowRewards( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'userRewards', 'requested' )()
    );
  } );

  it( 'setCartRightPanelCollapse should dispatch the proper action', () => {
    const panelID = jest.fn();
    mdp.setCartRightPanelCollapse( panelID );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setCartRightPanelCollapse( panelID )
    );
  } );

  it( 'updateStateDropdownValue should dispatch the proper action', () => {
    const form = jest.fn();
    const value = jest.fn();
    mdp.updateStateDropdownValue( form, value );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.updateStateDropdownValue( form, value )
    );
  } );

  it( 'updateShippingStatus should dispatch the proper action', () => {
    const value = jest.fn();
    mdp.updateShippingStatus( value );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.updateShippingStatus( value )
    );
  } );

  it( 'updatePaymentStatus should dispatch the proper action', () => {
    const value = jest.fn();
    mdp.updatePaymentStatus( value );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.updatePaymentStatus( value )
    );
  } );

  it( 'setPaymentType should dispatch the proper action', () => {
    const paymentType = jest.fn();
    mdp.setPaymentType( paymentType );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.setPaymentType( paymentType )
    );
  } );

  it( 'toggleAddress2FieldDisplay should dispatch the proper action', () => {
    mdp.toggleAddress2FieldDisplay( );
    expect( dispatch ).toHaveBeenCalledWith(
      formActions.toggleAddress2FieldDisplay( )
    );
  } );

  it( 'toggleAddressFieldDisplay should dispatch the proper action', () => {
    mdp.toggleAddressFieldDisplay( );
    expect( dispatch ).toHaveBeenCalledWith(
      formActions.toggleAddressFieldDisplay( )
    );
  } );

  it( 'updatePaymentStatus should dispatch the proper action', () => {
    const value = jest.fn();
    mdp.updatePaymentStatus( value );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.updatePaymentStatus( value )
    );
  } );

  it( 'updateDavPopup should dispatch the proper action', () => {
    mdp.updateDavPopup( );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.updateDavPopup( )
    );
  } );

  it( 'setEditCreditCardData should dispatch the proper action', () => {
    const data = jest.fn();
    mdp.setEditCreditCardData( data );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.setEditCreditCardData( data )
    );
  } );

  it( 'setCreditCardPaymentType should dispatch the proper action', () => {
    const data = jest.fn();
    mdp.setCreditCardPaymentType( data );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.setCreditCardPaymentType( data )
    );
  } );

  it( 'setTempPaymentCCVNumber should dispatch the proper action', () => {
    const data = jest.fn();
    mdp.setTempPaymentCCVNumber( data );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.setTempPaymentCCVNumber( data )
    );
  } );

  it( 'resetOrderStatus should dispatch the proper action', () => {
    mdp.resetOrderStatus( );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.resetOrderStatus( )
    );
  } );

  it( 'getPaypalResponse should dispatch the proper action', () => {
    const info = jest.fn();
    mdp.getPaypalResponse( info );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.getPaypalResponse( info )
    );
  } );

  it( 'changeCreditCard should dispatch the proper action', () => {
    const data = jest.fn();
    mdp.changeCreditCard( data );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.changeCreditCard( data )
    );
  } );

  it( 'setCCPaymentFormSubmit should dispatch the proper action', () => {
    const data  = jest.fn();
    mdp.setCCPaymentFormSubmit( data );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.setCCPaymentFormSubmit( data )
    );
  } );

  it( 'toggleInputFieldShippingDisplay should dispatch the proper action', () => {
    mdp.toggleInputFieldShippingDisplay();
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.toggleInputFieldShippingDisplay( )
    );
  } );

  it( 'toggleInputFieldPaymentDisplay should dispatch the proper action', () => {
    const data  = jest.fn();
    mdp.toggleInputFieldPaymentDisplay( data );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.toggleInputFieldPaymentDisplay( data )
    );
  } );

  it( 'setShippingErrorMessage should dispatch the proper action', () => {
    const data  = jest.fn();
    mdp.setShippingErrorMessage( data );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.setShippingErrorMessage( data )
    );
  } );

  it( 'resetCouponsState should dispatch the proper action', () => {
    mdp.resetCouponsState( );
    expect( dispatch ).toHaveBeenCalledWith(
      formActions.resetCouponsState( )
    );
  } );

  it( 'loadCart should dispatch the proper action', () => {
    registerServiceName( 'loadCart' );
    mdp.loadCart( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'loadCart', 'requested' )()
    );
  } );

  it( 'couponCodeUpdated should dispatch the proper action', () => {
    const item = jest.fn();
    const history = jest.fn();
    const fromCheckout  = jest.fn();
    mdp.couponCodeUpdated( item, history, fromCheckout );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.couponCodeUpdated( item, history, fromCheckout )
    );
  } );

  it( 'couponCodeRemoved should dispatch the proper action', () => {
    const history = jest.fn();
    const fromCheckout  = jest.fn();
    mdp.couponCodeRemoved( history, fromCheckout );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.couponCodeRemoved( history, fromCheckout )
    );
  } );

  it( 'isCouponBtnClicked should dispatch the proper action', () => {
    const data  = jest.fn();
    mdp.isCouponBtnClicked( data );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.isCouponBtnClicked( data )
    );
  } );

  it( 'triggerAnalyticsEvent should dispatch the proper action', () => {
    const evt  = jest.fn();
    mdp.triggerAnalyticsEvent( evt );
    expect( dispatch ).toHaveBeenCalledWith(
      analyticActions.triggerAnalyticsEvent( evt )
    );
  } );

  it( 'toggleSecurityCode should dispatch the proper action', () => {
    let status = true;
    let displayType = 'mobile'
    mdp.toggleSecurityCode( status, displayType );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.toggleSecurityCode( status, displayType )
    );
  } );

  it( 'newsLetterSignupStatus should dispatch the proper action', () => {
    let status = true;
    mdp.newsLetterSignupStatus( status );
    expect( dispatch ).toHaveBeenCalledWith(
      checkoutPageActions.newsLetterSignupStatus( status )
    );
  } );

  it( 'submitPaymentForm should dispatch the proper action - If remainingPaymentDue > 0 creditcard validation should be done (dispatch touch for credit card fields) ', () => {
    const remainingPaymentDue  = 10;
    mdp.submitPaymentForm( remainingPaymentDue );
    expect( dispatch ).toHaveBeenCalledWith(
      touch(
        'paymentForm',
        'creditCardNumber',
        'expirationDate',
        'securityCode',
        'firstNamepaymentAddressForm',
        'lastNamepaymentAddressForm',
        'address1paymentAddressForm',
        'citypaymentAddressForm',
        'state',
        'postalCodepaymentAddressForm',
        'phoneNumberpaymentAddressForm',
        'emailaddresspaymentAddressForm'
      ) )
  } );

  it( 'submitPaymentForm should dispatch the proper action - If remainingPaymentDue < 0 creditcard validation should be done (dispatch touch for credit card fields) ', () => {
    const remainingPaymentDue  = 0;
    mdp.submitPaymentForm( remainingPaymentDue );
    expect( dispatch ).toHaveBeenCalledWith(
      touch(
        'paymentForm',
        'firstNamepaymentAddressForm',
        'lastNamepaymentAddressForm',
        'address1paymentAddressForm',
        'citypaymentAddressForm',
        'state',
        'postalCodepaymentAddressForm',
        'phoneNumberpaymentAddressForm',
        'emailaddresspaymentAddressForm'
      ) )
  } );

  it( 'submitPaymentFormCvv should dispatch the proper action - If remainingPaymentDue > 0 security code validation should be done (dispatch touch for security code field) ', () => {
    const remainingPaymentDue  = 10;
    mdp.submitPaymentFormCvv( remainingPaymentDue );
    expect( dispatch ).toHaveBeenCalledWith(
      touch(
        'PaymentCCSecurityCode',
        'ccSecurityCode',
      ) )
  } );

  it( 'submitPaymentFormCvv should dispatch the proper action - If remainingPaymentDue < 0 security code validation should not be done (dispatch touch for security code field) ', () => {
    const remainingPaymentDue  = 0;
    mdp.submitPaymentFormCvv( remainingPaymentDue );
    expect( dispatch ).not.toHaveBeenCalledWith(
      touch(
        'PaymentCCSecurityCode',
        'ccSecurityCode',
      ) )
  } );

  it( 'broadcastMessage should dispatch the proper action', () => {
    const message = 'test message';
    mdp.broadcastMessage( message );
    expect( dispatch ).toHaveBeenCalledWith(
      globalActions.setBroadcastMessage( message )
    );
  } );

} );
