/**
 * CouponForm
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './CouponForm.css';
import InputField from 'shared/components/InputField/InputField';
import Button from 'shared/components/Button/Button';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './CouponForm.messages';
import { Field, reduxForm, getFormValues, isValid } from 'redux-form';

import isUndefined from 'lodash/isUndefined';
import keys from 'lodash/keys';
import omitBy from 'lodash/omitBy';
import isNil from 'lodash/isNil';

import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';
import classNames from 'classnames';
import Spinner from 'shared/components/Icons/spinner';
import {
  validate as validationMethod,
  validationKeys
} from 'utils/FormValidations/FormValidations';

const propTypes = {
  couponSuccess: PropTypes.bool,
  couponAppliedStatus: PropTypes.bool,
  couponCodeChangedFunction: PropTypes.func,
  inputBox:PropTypes.string,
  inputBoxChange: PropTypes.func
}



/**
 * Class
 * @extends React.Component
 */
class CouponForm extends Component{

  /**
   * Create a CouponForm
   */
  constructor( props ){
    super( props );

    this.inputBoxOnChange=this.inputBoxOnChange.bind( this );
    this.couponCodeChanged=this.couponCodeChanged.bind( this );
    this.addCouponToCart=this.addCouponToCart.bind( this );
    this.couponWarning=this.couponWarning.bind( this );
  }

  /**
   * Renders the CouponForm component
   */

  couponCodeChanged( couponStatusValue ){
    this.props.couponCodeChangedFunction( this.props.couponSuccess );
  }

  addCouponToCart(){
    let couponFormData = this.props.Coupons.values;
    let couponFormError = this.props.Coupons.syncErrors;
    if( couponFormData ){
      if( couponFormData.couponName && isUndefined( couponFormError ) ){
        let couponStatusValue = this.props.couponSuccess;
        this.couponCodeChanged( couponStatusValue );
        if( this.props.fromCheckout ){
          this.props.isCouponBtnClicked( true );
        }
      }
    }
    else {
      this.couponCodeChanged( 'Empty' );
    }
  }

  inputBoxOnChange( e ){
    const val = e && e.trim();
    this.props.inputBoxChange( val ) ;
  }

  couponWarning = ( val ) => {
    return validationMethod( val, validationKeys.showWarningMessage, messages.couponDefaultMessage );
  }

  render(){


    return (
      <div className='CouponForm'>
        <div
          className={
            classNames( 'CouponForm__inputField', {
              'CouponForm__applying':this.props.couponApplying
            } )
          }
        >
          <form onSubmit={ this.props.handleSubmit( this.addCouponToCart ) } >

            <InputField
              label={ formatMessage( messages.enterCoupon ) }
              type='text'
              name={ 'couponName' }
              tabIndex={ 1 }
              { ...( this.props.isMobileDevice && { autoComplete: 'off' } ) } // Coupon Field does not want autocomplete. refer ECOMM-36517
              { ...this.props.errorMessage && { 'errorMsg': this.props.errorMessage } }
              handleChange={ this.inputBoxOnChange }
              value={ this.props.inputBox }
              warn={ [this.couponWarning] }
            />

            <Button
              btnOption='single'
              btnType='submit'
              inputTag='button'
              btnSize='xs'
              btnOutLine={ true }
            >
              { formatMessage( messages.apply ) }
            </Button>
          </form>
        </div>
        {
          ( ()=>{
            if( this.props.couponApplying ){
              return (
                <div className='CouponForm__SpinnerContainer'>
                  <div className='CouponForm__spinner'>
                    <Spinner />
                    <span className='applyText'>{ formatMessage( messages.applying ) }</span>
                  </div>
                </div>
              )
            }
          } )()
        }
      </div>
    );
  }
}

CouponForm.propTypes = propTypes;


export const onSubmitFail = ( errors, dispatch ) => {

  let analyticErrors = [];
  analyticErrors.push( { 'CouponFormErrors':  omitBy( errors, isNil ) } );

  let evt = {
    'name': 'trackErrorDisplayed',
    'data': analyticErrors
  }
  dispatch( analyticActions.triggerAnalyticsEvent( evt ) );
}

export default
reduxForm( {
  form: 'Coupon',
  onSubmitFail
} )( CouponForm );