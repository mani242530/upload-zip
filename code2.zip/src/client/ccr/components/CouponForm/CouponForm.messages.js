/*
 * CouponForm Messages
 *
 * This contains all the text for the CouponForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  couponMessage: {
    id: 'i18n.CouponForm.couponMessage',
    defaultMessage: 'Apply Coupon To Save'
  },
  enterCoupon: {
    id: 'i18n.CouponForm.enterCoupon',
    defaultMessage: 'Enter Coupon'
  },
  couponEmpty: {
    id: 'i18n.CouponForm.couponEmpty',
    defaultMessage: 'Please enter a coupon.'
  },
  success: {
    id: 'i18n.CouponForm.success',
    defaultMessage: 'Success'
  },
  error: {
    id: 'i18n.CouponForm.error',
    defaultMessage: 'Error'
  },
  initial: {
    id: 'i18n.CouponForm.initial',
    defaultMessage: 'Initial'
  },
  empty: {
    id: 'i18n.CouponForm.empty',
    defaultMessage: 'Empty'
  },
  couponDefaultMessage: {
    id: 'i18n.CouponForm.couponMessage',
    defaultMessage: 'Enjoy 1 coupon per order!'
  },
  couponOffers: {
    id: 'i18n.CouponForm.couponOffers',
    defaultMessage: 'offer requirements'
  },
  apply: {
    id: 'i18n.CouponForm.apply',
    defaultMessage: 'apply'
  },
  remove: {
    id: 'i18n.CouponForm.remove',
    defaultMessage: 'remove'
  },
  applying: {
    id: 'i18n.CouponForm.applying',
    defaultMessage: 'Applying...'
  }
} );
