import React from 'react';
import ReactDOM from 'react-dom';
import CouponForm from './CouponForm';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import Button from 'shared/components/Button/Button';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';


describe( '<CouponForm />', () => {
  const store = configureStore( {}, CONFIG );
  let component = mountWithIntl(
    <Provider store={ store }>
      <CouponForm />
    </Provider> );

  it( 'renders without crashing', () => {
    expect( component.find( 'CouponForm' ).length ).toBe( 1 );
  } );
  it( 'it should show the Input field', () => {
    expect( component.find( 'InputField' ).length ).toBe( 1 );
  } );
  it( 'should have apply button', ()=>{
    expect( component.find( 'Button' ).length ).toBe( 1 );
  } );

} );


describe( '<CouponForm />', () => {
  let props = {
    couponSuccess: false,
    couponAppliedStatus: 'Success',
    couponCodeChangedFunction: jest.fn(),
    inputBoxChange: jest.fn(),
    fromCheckout: true,
    intl: jest.fn(),
    couponApplying: false,
    isCouponBtnClicked: jest.fn(),
    Coupons:{
      values:{
        couponName: 'O2810'
      }
    }
  };

  let component = mountComponent( props );

  it( 'renders without crashing', () => {
    expect( component.find( 'CouponForm' ).length ).toBe( 1 );
  } );

  it( 'Should show the Input field', () => {
    expect( component.find( 'InputField' ).length ).toBe( 1 );
    expect( component.find( 'InputField' ).props().warn ).toBeTruthy();
  } );

  it( 'should have apply button', ()=>{
    expect( component.find( 'Button' ).length ).toBe( 1 );
  } );

  it( 'handles input change event', () => {
    let node = component.find( 'CouponForm' ).at( 0 );
    component.find( 'input' ).simulate( 'change', { target: { value: '425225' } } );
    expect( props.inputBoxChange ).toBeCalled();
  } );

  it( 'handles input change event without leading  and trailing spaces', () => {
    let node = component.find( 'CouponForm' ).instance();
    component.find( 'input' ).simulate( 'change', { target: { value: '99999  ' } } );
    expect( props.inputBoxChange ).toHaveBeenCalledWith( '99999' );
  } );

  it( 'handles form submit event', () => {
    let node = component.find( 'CouponForm' ).at( 0 );
    component.find( 'button' ).simulate( 'submit' );
    expect( props.isCouponBtnClicked ).toBeCalled();
  } );

  it( 'Verify spinner on coupon apply', () => {
    let tempProps = {
      ...props,
      couponApplying: true
    };
    let component = mountComponent( tempProps );

    expect( component.find( '.CouponForm__SpinnerContainer' ).length ).toBe( 1 );
  } );

  it( 'handles form submit event with empty values', () => {
    props.Coupons.values = undefined;
    let component1 = mountComponent( props );
    let node = component1.find( 'CouponForm' ).at( 0 );
    component1.find( 'button' ).simulate( 'submit' );
    expect( props.isCouponBtnClicked ).toBeCalled();
  } );

  it( 'handles form submit event with coupon value', () => {
    props.Coupons.values = {
      couponName: 'Or234'
    };
    props.Coupons.syncErrors = undefined;
    let component1 = mountComponent( props );
    let node = component1.find( 'CouponForm' ).at( 0 );
    component1.find( 'button' ).simulate( 'submit' );
    expect( props.couponCodeChangedFunction ).toBeCalled();
    expect( props.isCouponBtnClicked ).toBeCalled();
  } );

  it( 'handles form submit from checkout page', () => {
    let tempProps = {
      ...props,
      Coupons:{
        values:{
          couponName: 'Or234'
        },
        syncErrors: undefined
      },
      fromCheckout: undefined
    };
    let component1 = mountComponent( tempProps );
    let node = component1.find( 'CouponForm' ).at( 0 );
    component1.find( 'button' ).simulate( 'submit' );
    expect( props.couponCodeChangedFunction ).toBeCalled();
  } );

  it( 'handles form onSubmitFail', () => {
    props.Coupons.values = {
      couponName: 'Or234'
    };
    props.Coupons.syncErrors = {
      couponName: 'Required'
    };
    let dispatch = jest.fn();
    let component1 = mountComponent( props );
    let node = component1.find( 'CouponForm' ).at( 0 );
    component1.find( 'button' ).simulate( 'submit' );
    node.props().onSubmitFail( props.Coupons.syncErrors, dispatch );
  } );

  it( 'autoComplete props has to be off for mobile devices', () => {
    props.isMobileDevice = true;
    component = mountComponent( props );
    expect( component.find( 'input' ).props().autoComplete ).toBe( 'off' );
  } );

} );


function mountComponent( props ){
  const store = configureStore( {}, CONFIG );
  return mountWithIntl(
    <Provider store={ store }>
      <CouponForm { ...props }/>
    </Provider>
  );
}
