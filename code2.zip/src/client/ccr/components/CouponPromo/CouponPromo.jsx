/**
 * CouponPromo
 */

import React from 'react';
import PropTypes from 'prop-types';
import Image from 'shared/components/Image/Image';
import Anchor from 'shared/components/Anchor/Anchor';
import classNames from 'classnames';
import ChevronRightSVG from 'shared/components/Icons/chevron_right';
import './CouponPromo.css';



const propTypes = {
  displayTopDivider: PropTypes.bool,
  displayBottomDivider: PropTypes.bool,
  linkUrl: PropTypes.string.isRequired,
  target: PropTypes.bool,
  imageUrl: PropTypes.string.isRequired,
  imageAlt: PropTypes.string.isRequired,
  couponText1: PropTypes.string.isRequired,
  couponText2: PropTypes.string
}

/**
 * Create a CouponPromo
 */
const CouponPromo = ( props ) => {

  const {
    displayTopDivider,
    displayBottomDivider,
    dataNavDescription,
    linkUrl,
    target,
    imageUrl,
    imageAlt,
    couponText1,
    couponText2
  } = props

  return (
    <div className='CouponPromo'>

      <div
        className={
          // TOP divider defaults to ON
          classNames( {
            'CouponPromo__divider': true,
            'CouponPromo__divider--off': !displayTopDivider && displayTopDivider !== undefined
          } ) }
      ></div>

      <div className='CouponPromo__container' >
        <Anchor
          dataNavDescription={ dataNavDescription }
          url={ linkUrl }
          target={ target ? '_blank' : '_self' }
        >
          { ( ()=>{
            if( imageUrl ){
              return (
                <Image
                  className='CouponPromo__image'
                  src={ imageUrl }
                  alt={ imageAlt }
                />
              )
            }
          } )() }

          <div className='CouponPromo__text-wrapper' >

            <div className='CouponPromo__text' >

              <div
                className={
                  classNames( {
                    'CouponPromo__div': true,
                    'CouponPromo__div--bottom': !couponText2
                  } )
                }
              >
                { couponText1 }
              </div>

              {
                ( ()=>{

                  if( couponText2 ){
                    return (
                      <div className='CouponPromo__div CouponPromo__div--bottom' >
                        { couponText2 }
                      </div>
                    )
                  }

                } )()
              }

            </div>

            <div className='CouponPromo__chevron-right' >
              <ChevronRightSVG />
            </div>

          </div>

        </Anchor>

      </div>

      <div
        className={
          // BOTTOM divider defaults to OFF
          classNames( {
            'CouponPromo__divider': true,
            'CouponPromo__divider--off': !displayBottomDivider
          } ) }
      ></div>

    </div>
  );
}

CouponPromo.propTypes = propTypes;

export default CouponPromo;
