import React from 'react';
import ReactDOM from 'react-dom';
import CouponPromo from './CouponPromo';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

let CouponPromoData={
  'name': 'Coupon',
  'topDivider': true,
  'bottomDivider': true,
  'couponImage': 'http://images.ulta.com/is/image/Ulta/coupon_20_off',
  'couponImgAlt': '20 percent any one qualifying item',
  'couponText1': 'any one qualifying item',
  'couponText2': 'a second item',
  'imageAlt': 'alt text',
  'couponLink': {
    'linkText': '',
    'showInNewPage': false,
    'navTargetLink': 'http://ulta.com/ulta/global/global_print_coupon_image_slot.jsp'
  }
}

describe( '<CouponPromo />', () => {
  let component;
  let props = {
    displayTopDivider: CouponPromoData.topDivider,
    displayBottomDivider: CouponPromoData.bottomDivider,
    linkUrl: CouponPromoData.couponLink.navTargetLink,
    target: CouponPromoData.couponLink.showInNewPage,
    imageUrl: CouponPromoData.couponImage,
    imageAlt: CouponPromoData.imageAlt,
    couponText1: CouponPromoData.couponText1,
    couponText2: CouponPromoData.couponText2
  }

  it( 'renders without crashing', () => {
    component = mountCouponPromo( props );
    expect( component.find( 'CouponPromo' ).length ).toBe( 1 );
  } );

  it( 'should reneder an image followed by coupon text', () => {
    component = mountCouponPromo( props );
    expect( component.find( 'Image.CouponPromo__image' ).length ).toBe( 1 );
    expect( component.find( '.CouponPromo__text' ).length ).toBe( 1 );
  } );

  it( 'should render a TOP divider by default', () => {

    props.displayTopDivider = undefined;

    component = mountCouponPromo( props );

    expect( component.find( '.CouponPromo__divider' ).at( 0 ).props().className ).toBe( 'CouponPromo__divider' );
  } );

  it( 'should NOT render a BOTTOM divider by default', () => {

    props.displayBottomDivider = undefined;

    component = mountCouponPromo( props );

    expect( component.find( '.CouponPromo__divider' ).at( 1 ).props().className ).toBe( 'CouponPromo__divider CouponPromo__divider--off' );
  } );

  it( 'should NOT render a TOP divider when \'displayTopDivider\' attribute is set to false', () => {

    props.displayTopDivider = false;
    component = mountCouponPromo( props );

    expect( component.find( '.CouponPromo__divider' ).at( 0 ).props().className ).toBe( 'CouponPromo__divider CouponPromo__divider--off' );
  } );

  it( 'should render a TOP divider when \'displayTopDivider\' attribute is set to true', () => {

    props.displayTopDivider = true;
    component = mountCouponPromo( props );

    expect( component.find( '.CouponPromo__divider' ).at( 0 ).props().className ).toBe( 'CouponPromo__divider' );
  } );

  it( 'should render a BOTTOM divider when \'displayBottomDivider\' attribute is set to true', () => {

    props.displayBottomDivider = true;
    component = mountCouponPromo( props );

    expect( component.find( '.CouponPromo__divider' ).at( 1 ).props().className ).toBe( 'CouponPromo__divider' );
  } );

  it( 'should NOT render a BOTTOM divider when \'displayBottomDivider\' attribute is set to false', () => {

    props.displayBottomDivider = false;
    component = mountCouponPromo( props );

    expect( component.find( '.CouponPromo__divider' ).at( 1 ).props().className ).toBe( 'CouponPromo__divider CouponPromo__divider--off' );
  } );

} );

function mountCouponPromo( props ){
  return mountWithIntl(
    <CouponPromo
      { ...props }
    />
  );
}


