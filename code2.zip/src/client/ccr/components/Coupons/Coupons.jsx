/**
 * Coupons
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './Coupons.css';
import { Collapse } from 'react-bootstrap';
import merge from 'lodash/merge';
import MixedMenuButton from 'shared/components/MixedMenuButton/MixedMenuButton';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './Coupons.messages';
import classNames from 'classnames';
import Checkmarkcircle from 'shared/components/Icons/checkmarkcircle';
import Exclamation_Circle from 'shared/components/Icons/exclamationcircle';
import Anchor from 'shared/components/Anchor/Anchor';
import { isEmpty, isUndefined } from 'lodash';
import Divider from 'shared/components/Divider/Divider';
import { connect } from 'react-redux';
import CouponForm from 'ccr/components/CouponForm/CouponForm';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';

const propTypes = {
  couponAppliedStatus: PropTypes.oneOfType( [PropTypes.bool, PropTypes.string] ),
  couponDescription: PropTypes.array,
  couponAppliedMsg: PropTypes.string,
  couponCode: PropTypes.string,
  couponAppliedErrorMessage: PropTypes.string,
  couponSuccess: PropTypes.bool,
  cartRightPanelCollapse: PropTypes.object,
  setCartRightPanelCollapse: PropTypes.func,
  couponCodeUpdated: PropTypes.func,
  history: PropTypes.object,
  resetCouponsState: PropTypes.func,
  couponCodeRemoved: PropTypes.func
}

export const initialState = {
  couponStatus: 'Initial',
  inptbox: ''
};
/**
 * Class
 * @extends React.Component
 */
class Coupons extends Component{

  /**
   * Create a Coupons
   */
  constructor( props ){
    super( props );
    this.state = initialState;
    this.couponCodeChanged = this.couponCodeChanged.bind( this );
    this.inptboxchange = this.inptboxchange.bind( this );
  }

  componentWillMount(){
    let couponSuccess = ( !isUndefined( this.props.couponDescription ) );

    if( this.props.cartRightPanelCollapse.coupons && !couponSuccess ){
      this.props.setCartRightPanelCollapse( 'coupons' );
    }
  }

  couponCodeChanged( couponStatusValue ){
    this.setState( { couponStatus: couponStatusValue } );

    if( isEmpty( this.state.inptbox ) ){
      this.setState( { couponStatus: 'Empty' } );
    }
    else {
      this.props.couponCodeUpdated( this.state.inptbox, this.props.history, this.props.fromCheckout );
    }

  }

  inptboxchange( val ){
    this.setState( { inptbox: val } );
    if( !isEmpty( val ) ){
      this.setState( { couponStatus: false } );
    }
    if( this.props.resetCouponsState ){
      this.props.resetCouponsState( false );
    }

  }

  /**
   * Renders the Coupons component
   */

  render(){

    const {
      setCartRightPanelCollapse,
      couponAppliedStatus,
      couponDescription,
      couponAppliedMsg,
      couponAppliedErrorMessage,
      cartRightPanelCollapse,
      isCouponRemoved
    } = this.props;
    let couponSuccess = ( !isUndefined( couponDescription ) );

    const errorMessage = this.state.couponStatus === 'Empty'? formatMessage( messages.couponEmpty ):( couponAppliedErrorMessage || undefined );

    return (
      <div className='Coupons'
        role='region'
        aria-live='assertive'
      >
        { ( () =>{
          if( isCouponRemoved ){
            return (
              <label
                className='sr-only'
              >
                { formatMessage( messages.couponRemove ) }
              </label>
            )
          }
        } )() }
        <div
          className={
            classNames( {
              'Coupons__MixedMenu': ( couponSuccess )
            } )
          }
        >

          { ( couponSuccess ) ?
            (
              <div className='Coupons_Container'>
                <div className='Coupons_details'>
                  { couponAppliedMsg }
                </div>
                <div className='Coupons_CouponLink'>
                  <div className='Coupons__column1'>
                    <div className='Coupons__pointsData2'>
                      { ( () => {
                        if( !isUndefined( couponDescription ) ){
                          return (
                            couponDescription.map( ( desc, index ) => {
                              {
                                return (
                                  <div className='Coupons__Descripation' key={ index }>
                                    { desc }
                                  </div>

                                )
                              }
                            } )
                          )
                        }
                      } )() }
                      { ( () =>{
                        if( !isUndefined( couponAppliedErrorMessage ) ){
                          return (
                            <div className='Coupons__error'>
                              { couponAppliedErrorMessage }
                            </div>
                          )
                        }
                      } )() }
                    </div>
                  </div>
                  <div className='Coupons__column2'>
                    <span className='Coupons_remove'>
                      <Anchor
                        clickHandler={ ( event ) => this.props.couponCodeRemoved( this.props.history, this.props.fromCheckout ) }
                        ariaLabel={ formatMessage( messages.ariaRemove ) }
                      >
                        { formatMessage( messages.remove ) }
                      </Anchor>
                    </span>
                  </div>
                </div>
              </div>
            ) :
            (
              <div className='Coupon__section'>
                <MixedMenuButton
                  label={ formatMessage( messages.coupon ) }
                  details={ couponAppliedMsg }
                  pointerType='collapse'
                  onClick={ e => {
                    e.preventDefault();
                    setCartRightPanelCollapse( 'coupons' );
                  } }
                  pointerMinus={ cartRightPanelCollapse.coupons }
                />
                <Collapse in={ cartRightPanelCollapse.coupons }>
                  <div className='Coupon__collapse'>
                    <div className='collapseElements__coupons'>
                      <CouponForm
                        Coupons={ this.props.Coupons }
                        couponSuccess={ couponSuccess }
                        couponAppliedStatus={ this.props.couponAppliedStatus }
                        couponCodeChangedFunction={ this.couponCodeChanged }
                        inputBox={ this.state.inptbox }
                        inputBoxChange={ this.inptboxchange }
                        couponApplying={ this.props.couponApplying }
                        fromCheckout={ ( this.props.fromCheckout ) ? this.props.fromCheckout : false }
                        { ...( this.props.fromCheckout && { isCouponBtnClicked: this.props.isCouponBtnClicked } ) }
                        isMobileDevice={ this.props.isMobileDevice }
                        errorMessage={ errorMessage }
                      />
                    </div>
                    <div className='Coupon_bottomBorder'>
                      <Divider
                        dividerType='gray'
                      />
                    </div>
                  </div>
                </Collapse>
              </div>
            )


          }
        </div>
      </div>
    );
  }
}

Coupons.propTypes = propTypes;

const mapStateToProps = ( state ) => {
  return {
    Coupons: state.form.Coupon
  };
}

export default ( connect( mapStateToProps )( Coupons ) );

