/*
 * Coupons Messages
 *
 * This contains all the text for the Coupons component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  coupon: {
    id: 'i18n.Coupons.coupon',
    defaultMessage: 'Add Coupon Code'
  },
  couponMessage: {
    id: 'i18n.Coupons.couponMessage',
    defaultMessage: 'Apply Coupon To Save'
  },
  couponEmpty: {
    id: 'i18n.Coupons.couponEmpty',
    defaultMessage: 'Please enter a coupon.'
  },
  success: {
    id: 'i18n.Coupons.success',
    defaultMessage: 'Success'
  },
  error: {
    id: 'i18n.Coupons.error',
    defaultMessage: 'Error'
  },
  initial: {
    id: 'i18n.Coupons.initial',
    defaultMessage: 'Initial'
  },
  empty: {
    id: 'i18n.Coupons.empty',
    defaultMessage: 'Empty'
  },
  couponDefaultMessage: {
    id: 'i18n.Coupons.couponMessage',
    defaultMessage: 'Enjoy 1 coupon per order!'
  },
  couponOffers: {
    id: 'i18n.Coupons.couponOffers',
    defaultMessage: ' offer requirements '
  },
  apply: {
    id: 'i18n.Coupons.apply',
    defaultMessage: 'apply'
  },
  remove: {
    id: 'i18n.Coupons.remove',
    defaultMessage: 'Remove'
  },
  ariaRemove: {
    id: 'i18n.Coupons.ariaRemove',
    defaultMessage: 'Remove Coupon'
  },
  couponRemove: {
    id: 'i18n.Coupons.couponRemove',
    defaultMessage: 'Coupon Removed'
  }
} );
