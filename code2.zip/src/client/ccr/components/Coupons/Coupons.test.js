import React from 'react';
import Coupons from './Coupons';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import messages from './Coupons.messages';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';


describe( '<Coupons />', () => {
  let component;
  let props = {
    cartRightPanelCollapse: {},
    couponAppliedStatus: false,
    couponOfferReqNotMet: true,
    couponAppliedMsg: 'CPW13344 has been applied',
    couponCode: 'CPW13344',
    couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
  }

  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <Coupons { ...props } />
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'Coupons' ).length ).toBe( 1 );
  } );
  it( 'renders MixedMenuButton component', () => {
    expect( component.find( 'MixedMenuButton' ).length ).toBe( 1 );
  } );
  it( 'renders collapse menu', () => {
    expect( component.find( 'Collapse' ).length ).toBe( 1 );
    expect( component.find( 'CouponForm' ).length ).toBe( 1 );
    expect( component.find( 'CouponForm' ).props().errorMessage ).toBeTruthy()
  } );
  it( 'remains same color in mixed menu coupon', () => {
    expect( component.find( '.Coupons__MixedMenu' ).length ).toBe( 0 );

  } );

  it( 'label is rendered when isCouponRemoved is true', () => {
    props.isCouponRemoved = true;
    component = mountWithIntl(
      <Provider store={ store }>
        <Coupons { ...props } />
      </Provider>
    );
    expect( component.find( '.sr-only' ).length ).toBe( 1 );
    expect( component.find( '.sr-only' ).text() ).toBe( messages.couponRemove.defaultMessage );

  } );

  it( 'label is not rendered when isCouponRemoved is false', () => {
    props.isCouponRemoved = false;
    component = mountWithIntl(
      <Provider store={ store }>
        <Coupons { ...props } />
      </Provider>
    );
    expect( component.find( '.sr-only' ).length ).toBe( 0 );

  } );


  it( 'coupon has been successfully applied', () => {
    let component;
    let props = {
      cartRightPanelCollapse: {},
      couponAppliedStatus: true,
      couponOfferReqNotMet: false,

      couponDescription: [
        '$10 off any $30 purchase CPW13344',
        '$2 off any $30 purchase CPW13344'
      ],
      couponAppliedMsg: 'CPW13344 has been applied',
      couponCode: 'CPW13344',
      couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
    }

    const store = configureStore( {}, CONFIG );
    component = mountWithIntl(
      <Provider store={ store }>
        <Coupons { ...props } />
      </Provider>
    );
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <Coupons { ...props } />
      </Provider>
    );
    let node1 = component.find( 'Coupons' ).instance();
    node1.state.couponStatus = 'Success';
    component1 = mountWithIntl(
      <Provider store={ store }>
        <Coupons { ...props } />
      </Provider>
    );
    expect( component1.find( '.Coupons_details' ).length ).toBe( 1 );
    expect( component1.find( '.Coupons' ).props()['aria-live'] ).toBe( 'assertive' );
    expect( component1.find( '.Coupons' ).props()['role'] ).toBe( 'region' );
    expect( component1.find( '.Coupons_remove' ).text() ).toBe( messages.remove.defaultMessage );
    expect( component1.find( '.Coupons_remove a' ).props()['aria-label'] ).toBe( messages.ariaRemove.defaultMessage );
  } );
  it( 'handles input change event', () => {
    let node = component.find( 'Coupons' ).instance();
    node.inptboxchange = jest.fn();
    component.find( 'input' ).simulate( 'change', { target: { value: 'CPW13344' } } );
    component.find( 'input' ).simulate( 'change', { target: { value: 'CPW13344' } } );
    expect( node.inptboxchange ).toBeCalled();
  } );

  it( 'Coupon has failed to apply', () => {
    let props = {
      cartRightPanelCollapse: {},
      couponAppliedStatus: false,
      couponDescription: [
        '$10 off any $30 purchase CPW13344',
        '$2 off any $30 purchase CPW13344'
      ],
      couponAppliedMsg: 'CPW13344 has been applied',
      couponCode: 'CPW13344',
      couponAppliedErrorMessage: 'Discount will appear once offer requirements have been met'
    }

    const store = configureStore( {}, CONFIG );
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <Coupons { ...props } />
      </Provider>
    );
    let node1 = component1.find( 'Coupons' ).instance();
    node1.state.couponStatus = 'Error';
    component1 = mountWithIntl(
      <Provider store={ store }>
        <Coupons { ...props } />
      </Provider>
    );

    expect( component1.find( '.Coupons__error' ).text() ).toBe( props.couponAppliedErrorMessage );
    expect( component1.find( '.Coupons_details' ).text() ).toBe( props.couponAppliedMsg );
  } );

  it( 'Collapse Coupon incase of failure', () => {
    let props = {
      cartRightPanelCollapse: { coupons:true },
      couponAppliedStatus: false,
      setCartRightPanelCollapse: jest.fn()
    }
    const store = configureStore( {}, CONFIG );
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <Coupons { ...props } />
      </Provider>
    );
    let node1 = component1.find( 'Coupons' ).instance();
    node1.state.couponStatus = 'Error';
    component1 = mountWithIntl(
      <Provider store={ store }>
        <Coupons { ...props } />
      </Provider>
    );

    expect( props.setCartRightPanelCollapse ).toHaveBeenCalled();

  } );

  props.couponCodeUpdated = jest.fn();
  props.history = {};
  props.fromCheckout = true;
  props.resetCouponsState = jest.fn();
  component = mountWithIntl(
    <Provider store={ store }>
      <Coupons { ...props } />
    </Provider>
  );

  const instance = component.find( 'Coupons' ).instance();

  it( 'should call the couponCodeChanged method with state.inptbox is empty', () => {
    expect( instance.state.couponStatus ).toEqual( 'Error' );
    instance.couponCodeChanged( 'Success' );
    expect( instance.state.couponStatus ).toEqual( 'Empty' );
  } );

  it( 'should call the couponCodeChanged method with state.inptbox is not empty', () => {
    expect( instance.state.couponStatus ).toEqual( 'Empty' );
    instance.state.inptbox = 'test';
    instance.couponCodeChanged( 'Success' );
    expect( props.couponCodeUpdated ).toHaveBeenCalledWith( instance.state.inptbox, props.history, props.fromCheckout );
  } );

  it( 'should call the inptboxchange method', () => {
    instance.inptboxchange();
    expect( props.resetCouponsState ).toHaveBeenCalledWith( false );
  } );

} );
