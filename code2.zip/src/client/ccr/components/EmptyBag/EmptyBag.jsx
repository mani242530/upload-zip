/**
 * EmptyBag
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './EmptyBag.css';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './EmptyBag.messages';
import EmptyBagLoginForm from 'ccr/components/EmptyBagLoginForm/EmptyBagLoginForm';
import classNames from 'classnames';
import ProductRecs from 'ccr/components/ProductRecs/ProductRecs';
import isEmpty from 'lodash/isEmpty';
import OutOfStockProductItems from 'ccr/components/OutOfStockProductItems/OutOfStockProductItems';
import Image from 'shared/components/Image/Image';
import TextCartridge from 'shared/components/TextCartridge/TextCartridge';
import Button from 'shared/components/Button/Button';
import Spinner from 'shared/components/Icons/spinner';
import Gutter from 'shared/components/Gutter/Gutter';
import has from 'lodash/has';
import isNull from 'lodash/isNull';

import ShippingBanner from 'hf/components/Headers/shared/ShippingBanner/ShippingBanner';


const propTypes = {
  loginPanelMessage: PropTypes.string
}


/**
 * Class
 * @extends React.Component
 */
class EmptyBag extends Component{


  componentDidMount(){
    // we need to make the loadcart call only in cases when cartpagedata is not available in the store
    // i.e. for cases when the login url is accessed directly
    // if empty bag is loaded as part of redirect from bag page, cartpagedata will already be available in the store
    if( !this.props.cartDataAvailable ){
      this.props.loadCart( {
        history: this.props.history
      } );
    }

    this.props.handleScrollView( 'js-cartpage' );
  }

  /**
   * Renders the EmptyBag component
   */
  render(){


    const {
      cartDataAvailable,
      location
    } = this.props;

    let sessionTimeoutDisplay = false;

    if( has( location, 'state.sessionTimeoutDisplay' ) && location.state.sessionTimeoutDisplay ){
      sessionTimeoutDisplay = true;
    }


    if( !cartDataAvailable ){
      return (
        <div className='CartPage--spinner_loading'>
          <Spinner loaderType='spinner'/>
        </div>
      )
    }
    else {
      return (
        <div className={
          classNames(
            'EmptyBag',
            {
              'EmptyBag--sessionTimeoutDisplay': sessionTimeoutDisplay
            }
          )
        }
        >

          { ( () =>{
            if( this.props.cartPageData && ( !isEmpty( this.props.cartPageData.messages ) || !isEmpty( this.props.cartPageData.removedItems ) )&& !sessionTimeoutDisplay ){
              return (
                <OutOfStockProductItems
                  showPanel={ this.props.hideOOSPanel }
                  handleOutOfStock={ this.props.hideOutOfStockItems }
                  { ...( !isNull( this.props.cartPageData.messages ) && { 'messagesData' : this.props.cartPageData.messages.items } ) }
                  { ...( !isNull( this.props.cartPageData.removedItems ) && { 'removedItems' : this.props.cartPageData.removedItems } ) }
                />
              );
            }
          } )() }

          <Image
            src={ this.props.displayType === 'desktop' ? '//images.ulta.com/is/image/Ulta/wk1917_d_banner_emptybag_header?scl=1' : '//images.ulta.com/is/image/Ulta/wk1917_m_banner_emptybag_header?scl=1' }
            alt='Empty Bag Banner Image'
            className='EmptyBag__bannerImage'
            width='100%'
          />
          <Gutter>
            <TextCartridge
              headlineText={ sessionTimeoutDisplay ? formatMessage( messages.pickupwhereyouleftoff ) : formatMessage( messages.emptyBagTitle ) }
              shortHR={ true }
              hrColor='orangepop'
              marginBottom={ this.props.isSignedIn ? '20px' : '0' }
            />

            { ( () =>{
              if( this.props.isSignedIn ){
                return (
                  <div className='EmptyBag__LoggedInMessage'>
                    <p>
                      { sessionTimeoutDisplay ? formatMessage( messages.emptyBagLoggedInMessage ) : formatMessage( messages.emptyBagLoggedInMessage ) }
                    </p>

                    <Button
                      inputTag='a'
                      btnSize='lg'
                      btnOption='single'
                      btnURL='/'
                    >
                      { formatMessage( messages.continueShopping ) }
                    </Button>
                  </div>
                )
              }
            } )() }

            { ( () =>{

              return (
                <div className={ classNames( {
                  'EmptyBag__desktop': ( this.props.displayType === 'desktop' )
                } ) }
                >

                  { ( () =>{
                    if( !this.props.isSignedIn ){
                      return (
                        <EmptyBagLoginForm
                          { ...( this.props.user && this.props.user.messageBeans && { messageBeans: this.props.user.messageBeans } ) }
                          successPath='/bag'
                          submitUserLogin={ this.props.submitUserLogin }
                          sourcePage='ccLogin'
                          sessionTimeoutDisplay={ sessionTimeoutDisplay }
                          history={ this.props.history }
                        />
                      )
                    }
                  } )() }


                </div>
              );

            } )() }
          </Gutter>
          { ( () => {
            // the div below is only used for Reflektion and must appear before EmptyBag__ProductRecsDesktop
            // specific data attribute is also added to EmptyBag__ProductRecsDesktop if enabled is true
            if( !sessionTimeoutDisplay && this.props.switchData.switches.enableReflektionTag ){
              return ( <div data-rfkid='rfkid_8'></div> );
            }
          } )() }
          { ( () =>{
            if( !isEmpty( this.props.recommendedProducts ) && !sessionTimeoutDisplay ){
              return (
                <div className={
                  classNames( {
                    EmptyBag__ProductRecsDesktop: this.props.displayType === 'desktop'
                  } )
                }
                data-rfkid={ ( this.props.switchData.switches.enableReflektionTag ) ? 'rfkid_x8' : null }
                >
                  <ProductRecs
                    { ...this.props }
                    productRecList={ this.props.recommendedProducts }
                  />
                </div>
              )
            }
          } )() }
        </div>
      );
    }

  }
}

EmptyBag.propTypes = propTypes;

export default EmptyBag;
