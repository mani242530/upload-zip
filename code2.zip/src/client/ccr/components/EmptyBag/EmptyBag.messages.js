/*
 * EmptyBag Messages
 *
 * This contains all the text for the EmptyBag component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  emptyBagTitle: {
    id: 'i18n.EmptyBag.emptyBagTitle',
    defaultMessage: 'Your bag is empty'
  },
  emptyBagLoginHeading: {
    id: 'i18n.EmptyBag.emptyBagLoginHeading',
    defaultMessage: 'Have an account?'
  },
  emptyBagLoginMessage: {
    id: 'i18n.EmptyBag.emptyBagLoginMessage',
    defaultMessage: 'Sign in to see your saved bag.'
  },
  emptyBagLoggedInMessage: {
    id: 'i18n.EmptyBag.emptyBagLoggedInMessage',
    defaultMessage: 'Start filling it with pretty things!'
  },
  continueShopping: {
    id: 'i18n.EmptyBag.continueShopping',
    defaultMessage: 'Continue Shopping'
  },
  pickupwhereyouleftoff: {
    id: 'i18n.EmptyBag.pickupwhereyouleftoff',
    defaultMessage: 'PICK UP WHERE YOU LEFT OFF'
  },
  signintoviewyourbag: {
    id: 'i18n.EmptyBag.signintoviewyourbag',
    defaultMessage: 'Sign in to view your bag'
  }

} );
