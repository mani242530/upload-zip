import React from 'react';
import ReactDOM from 'react-dom';
import EmptyBag from './EmptyBag';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';

describe( '<EmptyBag />', () => {
  const store = configureStore( {}, CONFIG );
  let component;
  let props = {
    displayType:'',
    userName:'',
    loadCart: jest.fn(),
    handleScrollView: jest.fn(),
    cartPageData : {
      'messages': {
        'items': [
          {
            'type': 'Info',
            'message': 'Looks like you have items in your bag from before. They\'ve been added below.'
          }
        ]
      }
    },
    location:{
      state:{
        loadCartMessages:{
          items:{}
        }
      }
    }
  }
  it( 'renders without crashing', () => {
    component = mountWithIntl( <EmptyBag { ...props } /> );
    expect( component.find( 'EmptyBag' ).length ).toBe( 1 );
  } );

} )


describe( 'Should render LoginPanel and CreateAccount components if the user is not logged in', () => {
  let component;
  let props ={
    'switchData': {
      'switches': {
        'enableReflektionTag': true
      }
    },
    loadCart: jest.fn(),
    handleScrollView: jest.fn(),
    cartDataAvailable : true,
    isSignedIn : false,
    cartPageData : {
      'messages': {
        'items': [
          {
            'type': 'Info',
            'message': 'Looks like you have items in your bag from before. They\'ve been added below.'
          }
        ]
      }
    }
  };
  const store = configureStore( {}, CONFIG );
  it( 'should contain LoginPanel component', () => {
    props.displayType='desktop';
    props.userName='';
    component = mountWithIntl(
      <Provider store={ store }>
        <EmptyBag { ...props } />
      </Provider>
    );
    expect( component.find( 'EmptyBag .EmptyBag__desktop .EmptyBagLoginForm .EmptyBagLoginForm__leftPanel .LoginForm' ).length ).toBe( 1 );
  } );

  it( 'should render OutOfStockProductItems when the item is OOS', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <EmptyBag { ...props }/>
      </Provider>
    );
    expect( component.find( 'OutOfStockProductItems' ).length ).toBe( 1 );
  } );

  it( 'should not render OutOfStockProductItems when there is no messages or removedItems', () => {
    props.cartPageData = { messages: null };
    component = mountWithIntl(
      <Provider store={ store }>
        <EmptyBag { ...props }/>
      </Provider>
    );
    expect( component.find( 'OutOfStockProductItems' ).length ).toBe( 0 );
  } );

  it( 'should invoke loadCart when cartDataAvailable is false', () => {
    const props1 = { ...props };
    props1.cartDataAvailable = false ;
    component = mountWithIntl(
      <Provider store={ store }>
        <EmptyBag { ...props1 }/>
      </Provider>
    );
    expect( props1.loadCart ).toBeCalled( );
  } );

  it( 'should contain CreateAccount component', () => {
    props.displayType='desktop';
    props.userName='';
    component = mountWithIntl(
      <Provider store={ store }>
        <EmptyBag { ...props } />
      </Provider>
    );
    expect( component.find( 'EmptyBag .EmptyBag__desktop .EmptyBagLoginForm .EmptyBagLoginForm__rightPanel .EmptyBagLoginForm__createAccount' ).length ).toBe( 1 );
  } );

  it( 'should render OutOfStockProductItems when removeditem is present and messages not present', () => {
    let props ={
      'switchData': {
        'switches': {
          'enableReflektionTag': true
        }
      },
      loadCart: jest.fn(),
      handleScrollView: jest.fn(),
      cartDataAvailable : true,
      isSignedIn : false,
      cartPageData : {
        'messages':null,
        removedItems: [
          {
            skuId:'122321312'
          }
        ]
      }
    };
    component = mountWithIntl(
      <Provider store={ store }>
        <EmptyBag { ...props }/>
      </Provider>
    );
    expect( component.find( 'OutOfStockProductItems' ).length ).toBe( 1 );
    expect( component.find( 'OutOfStockProductItems' ).instance().props.removedItems ).toBeTruthy();
    expect( component.find( 'OutOfStockProductItems' ).instance().props.messagesData ).toBeFalsy();
  } );

  it( 'should render OutOfStockProductItems when the item is OOS item (removed item)', () => {
    let props2 = {
      'switchData': {
        'switches': {
          'enableReflektionTag': true
        }
      },
      'loadCart': jest.fn(),
      'handleScrollView': jest.fn(),
      'cartDataAvailable' : true,
      'cartPageData' : {
        'removedItems':[
          {
            'couponApplied': false,
            'brandName': 'OPI',
            'quantity': null,
            'productId': 'xlsImpprod5180311',
            'excludedFromCoupon': false,
            'adbugMessageMap': null,
            'catalogRefId': '2056976',
            'categoryName': null,
            'commerceItemid': null,
            'priceInfo': {
              'salePrice': null,
              'regularPrice': '$10',
              'unitPriceMessage': null,
              'bfxPriceMap': null
            },
            'productDisplayName': 'Soft Shades Nail Lacquer Collection',
            'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
            'variantInfo': {
              'Color': 'Bubble Bath'
            },
            'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
            'shippingRestriction': null,
            'maxQty': null,
            'productURL': null,
            'messages': {
              'items': [
                {
                  'type': 'Info',
                  'message': 'Selected items is out of stock'
                }
              ]
            }
          }
        ],
        messages:null
      }
    }
    let component2 = mountWithIntl(
      <Provider store={ store }>
        <EmptyBag { ...props2 }/>
      </Provider>
    );
    expect( component2.find( 'OutOfStockProductItems' ).length ).toBe( 1 );
    expect( component2.find( 'OutOfStockProductItems' ).instance().props.removedItems ).toBeTruthy();
  } );


  it( 'Should have a div with the reflektion data-rfkid attribute if enableReflektionTag is true and no recommended products', () => {

    let props2 = {
      'switchData': {
        'switches': {
          'enableReflektionTag': true
        }
      },
      'displayType':'desktop',
      'userName':'Mickey@disney.com',
      'isSignedIn': true,
      'recommendedProducts': null,
      'loadCart': jest.fn(),
      'handleScrollView': jest.fn(),
      'cartDataAvailable' : true,
      'cartPageData' : {
        'removedItems':[
          {
            'couponApplied': false,
            'brandName': 'OPI',
            'quantity': null,
            'productId': 'xlsImpprod5180311',
            'excludedFromCoupon': false,
            'adbugMessageMap': null,
            'catalogRefId': '2056976',
            'categoryName': null,
            'commerceItemid': null,
            'priceInfo': {
              'salePrice': null,
              'regularPrice': '$10',
              'unitPriceMessage': null,
              'bfxPriceMap': null
            },
            'productDisplayName': 'Soft Shades Nail Lacquer Collection',
            'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
            'variantInfo': {
              'Color': 'Bubble Bath'
            },
            'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
            'shippingRestriction': null,
            'maxQty': null,
            'productURL': null,
            'messages': {
              'items': [
                {
                  'type': 'Info',
                  'message': 'Selected items is out of stock'
                }
              ]
            }
          }
        ],
        messages:null
      }
    }


    let sessionTimeoutDisplay = false;
    let component2 = mountWithIntl(
      <Provider store={ store }>
        <EmptyBag { ...props2 }/>
      </Provider>
    );

    expect( component2.contains( <div data-rfkid='rfkid_8'></div> ) ).toBe( true ) ;

  } );


  it( 'Should have a Reflektion data-rfkid attribute if enableReflektionTag is true and recommended products is not empty', () => {
    let props2 = {
      'switchData': {
        'switches': {
          'enableReflektionTag': true
        }
      },
      'displayType':'desktop',
      'userName':'Mickey@disney.com',
      'isSignedIn': true,
      'recommendedProducts': {
        'recommendedProducts': {
          'errorCode': null,
          'errorMessage': null,
          'pageId': null,
          'productIds': null,
          'productItems': [{
            'placmentName': 'cart_page.rvi',
            'productItemsList': [{
              'activeSkusCount': 28,
              'adbugMessage': null,
              'badge': null,
              'badges': [],
              'brandName': 'Cnd',
              'childSkuId': null,
              'clickURL': 'http://integration.richrelevance.com/rrserver/apiclick?a=f42e6dcbc17086cd&cak=17a88ce787db5c27&ct=http%3A%2F%2Fda3.ulta.com%2Fvinylux-weekly-polish%3FproductId%3DxlsImpprod11351077&vg=5d9f2ea7-3366-45â€¦',
              'dfltSkuId': '2281501',
              'highRangeListPrice': 10.5,
              'highRangeSalePrice': 0,
              'isGwp': 0,
              'listPrice': 0,
              'lowRangeListPrice': 10.5,
              'lowRangeSalePrice': 0,
              'multiSku': true,
              'numReviews': '507',
              'onSale': false,
              'parentCatDispName': 'Nail Polish',
              'powerReviewRating': '4.0',
              'prodParentCatId': 'cat80068',
              'productBrandName': null,
              'productDisplayName': 'Vinylux Weekly Polish',
              'productId': 'xlsImpprod11351077',
              'productImageUrl': '//images.ulta.com/is/image/Ulta/2281501?$md$',
              'promotionDO': null,
              'rating': null,
              'ratingDecimal': null,
              'reviewCount': null,
              'salePrice': 0,
              'showListAndSaleRange': false,
              'showListRange': true,
              'skuDisplayName': null,
              'skuImageUrl': null,
              'varaintDispName': 'Colors'
            }],
            'strategyMesssage': 'Previously Viewed',
            'success': true,
            'trackingId': null
          }]
        }
      },
      'loadCart': jest.fn(),
      'handleScrollView': jest.fn(),
      'cartDataAvailable' : true,
      'cartPageData' : {
        'removedItems':[
          {
            'couponApplied': false,
            'brandName': 'OPI',
            'quantity': null,
            'productId': 'xlsImpprod5180311',
            'excludedFromCoupon': false,
            'adbugMessageMap': null,
            'catalogRefId': '2056976',
            'categoryName': null,
            'commerceItemid': null,
            'priceInfo': {
              'salePrice': null,
              'regularPrice': '$10',
              'unitPriceMessage': null,
              'bfxPriceMap': null
            },
            'productDisplayName': 'Soft Shades Nail Lacquer Collection',
            'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
            'variantInfo': {
              'Color': 'Bubble Bath'
            },
            'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
            'shippingRestriction': null,
            'maxQty': null,
            'productURL': null,
            'messages': {
              'items': [
                {
                  'type': 'Info',
                  'message': 'Selected items is out of stock'
                }
              ]
            }
          }
        ],
        messages:null
      }
    }
    let sessionTimeoutDisplay = false;
    let component2 = mountWithIntl(
      <Provider store={ store }>
        <EmptyBag { ...props2 }/>
      </Provider>
    );

    expect( component2.find( '.EmptyBag__ProductRecsDesktop' ).prop( 'data-rfkid' ) ).toBeTruthy();
  } );




} )