
/**
 * EmptyBagLoginForm
 */

import React from 'react';
import PropTypes from 'prop-types';
import { formatMessage } from 'shared/components/Global/Global';
import './EmptyBagLoginForm.css';
import messages from './EmptyBagLoginForm.messages';
import Divider from 'shared/components/Divider/Divider';
import LoginForm from 'shared/components/LoginForm/LoginForm';
import Button from 'shared/components/Button/Button';
import classNames from 'classnames';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';

const propTypes = {
  // an indicator for the login service so it knows what URL the request is coming from.
  sourcePage: PropTypes.string.isRequired,
  successPath: PropTypes.string,
  messageBeans: PropTypes.array,
  analyticsPageName: PropTypes.string,
  analyticsChannel: PropTypes.string
}


const EmptyBagLoginForm = ( props ) => {

  const {
    sessionTimeoutDisplay
  } = props;

  return (
    <div className='EmptyBagLoginForm'>
      <div>
        <div
          className={
            classNames(
              'EmptyBagLoginForm__leftPanel',
              {
                'EmptyBagLoginForm__leftPanel--sessionTimeoutDisplay': sessionTimeoutDisplay
              }
            )
          }
        >
          <LoginForm
            { ...props }
            scrollElementSelector='js-AdsformDecorator__container'
            title={ sessionTimeoutDisplay? formatMessage( messages.signInToView ) : formatMessage( messages.haveAnAccount ) }
            { ...( !sessionTimeoutDisplay && { formMessage: formatMessage( messages.signInToSee ) } ) }
            buttonText={ formatMessage( messages.signInButton ) }
            analyticsSourcePage='empty bag'
          />
        </div>
        { ( ()=>{
          if( !sessionTimeoutDisplay ){
            return (
              <div className='EmptyBagLoginForm__rightPanel'>

                <div className='EmptyBagLoginForm__MobileDivider'>
                  <Divider dividerType='gray' />
                </div>

                <div className='EmptyBagLoginForm__container'>
                  <div className='EmptyBagLoginForm__createAccount'>
                    <div className='EmptyBagLoginForm__createAccount--noAccountText'>
                      { formatMessage( messages.noUltaAccount ) }
                    </div>
                    <div className='EmptyBagLoginForm__createAccount--createAccountText'>
                      { formatMessage( messages.createAnAccount ) }
                    </div>
                    <div className='EmptyBagLoginForm__createAccount--submitButton'>
                      <Button
                        inputTag='a'
                        btnSize='lg'
                        btnOption='single'
                        btnOutLine={ true }
                        tabIndex={ 4 }
                        btnURL='ulta/myaccount/register.jsp'
                      >
                        { formatMessage( messages.createAccountButton ) }
                      </Button>
                    </div>
                  </div>
                </div>

              </div>
            );
          }
        } )() }
      </div>
    </div>
  )

}

EmptyBagLoginForm.propTypes = propTypes;

export default EmptyBagLoginForm;
