/*
 * EmptyBagEmptyBagLoginForm Messages
 *
 * This contains all the text for the EmptyBagEmptyBagLoginForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  haveAnAccount: {
    id: 'i18n.EmptyBagLoginForm.haveAnAccount',
    defaultMessage: 'Have an account?'
  },
  signInToView: {
    id: 'i18n.EmptyBagLoginForm.signInToSee',
    defaultMessage: 'Sign in to view your bag'
  },
  signInToSee: {
    id: 'i18n.EmptyBagLoginForm.signInToSee',
    defaultMessage: 'Sign in to see your saved bag.'
  },
  signInButton: {
    id: 'i18n.EmptyBagLoginForm.signInButton',
    defaultMessage: 'SIGN IN'
  },
  noUltaAccount: {
    id: 'i18n.InputField.noUltaAccount',
    defaultMessage: ' No Ulta.com account?'
  },
  createAnAccount: {
    id: 'i18n.InputField.createAnAccount',
    defaultMessage: 'Create one and join the fun!'
  },
  createAccountButton:{
    id: 'i18n.InputField.createAccountButton',
    defaultMessage: 'CREATE ACCOUNT'
  }
} );
