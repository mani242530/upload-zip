import React from 'react';
import ReactDOM from 'react-dom';
import EmptyBagLoginForm from './EmptyBagLoginForm';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './EmptyBagLoginForm.messages';

describe( '<EmptyBagLoginForm />', () => {
  const store = configureStore( {}, CONFIG );
  const props = {
    sourcePage:'ccLogin',
    sessionTimeoutDisplay: false
  }
  const component = mountWithIntl(
    <Provider store={ store }>
      <EmptyBagLoginForm { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'EmptyBagLoginForm' ).length ).toBe( 1 );
  } );
  it( 'should render EmptyBagLoginForm__leftPanel--sessionTimeoutDisplay on session timeout', () => {
    const props1 = {
      sourcePage:'ccLogin',
      sessionTimeoutDisplay: true
    }
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <EmptyBagLoginForm { ...props1 }/>
      </Provider>
    );
    expect( component1.find( '.EmptyBagLoginForm__leftPanel .EmptyBagLoginForm__leftPanel--sessionTimeoutDisplay' ).length ).toBe( 1 );
  } );

  it( 'Should contain EmptyBagLoginForm__leftPanel', () => {
    expect( component.find( 'EmptyBagLoginForm .EmptyBagLoginForm__leftPanel' ).length ).toBe( 1 );
  } );

  it( 'Should contain EmptyBagLoginForm__rightPanel', () => {
    expect( component.find( 'EmptyBagLoginForm .EmptyBagLoginForm__rightPanel' ).length ).toBe( 1 );
  } );

  it( 'Should render LoginForm component', () => {
    expect( component.find( '.EmptyBagLoginForm__leftPanel .LoginForm' ).length ).toBe( 1 );
  } );

  it( 'Should render no account text message', () => {
    expect( component.find( '.EmptyBagLoginForm__container .EmptyBagLoginForm__createAccount--noAccountText' ).text() ).toBe( messages.noUltaAccount.defaultMessage );
  } );

  it( 'Should have two submit button', ()=>{
    expect( component.find( 'Button' ).length ).toBe( 2 );
  } );

  it( 'Should contain `Have an account?` message', ()=>{
    expect( component.find( '.EmptyBagLoginForm__leftPanel .LoginForm__getStartedMessage' ).text() ).toBe( messages.haveAnAccount.defaultMessage );
  } );

  it( 'Should contain `Create one and join the fun!` message', ()=>{
    expect( component.find( '.EmptyBagLoginForm__rightPanel .EmptyBagLoginForm__createAccount--createAccountText' ).text() ).toBe( messages.createAnAccount.defaultMessage );
  } );

} );
