/**
 * GWPProductItem
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './GWPProductItem.css';
import { connect } from 'react-redux';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './GWPProductItem.messages';
import Image from 'shared/components/Image/Image';
import Anchor from 'shared/components/Anchor/Anchor';
import { isEmpty } from 'lodash';
import ChevronDownSVG from 'shared/components/Icons/chevrondown';
import Exclamation from 'shared/components/Icons/exclamationcircle';
import classNames from 'classnames';
import ToggleButton from 'shared/components/ToggleButton/ToggleButton';
import { reduxForm } from 'redux-form';
import Divider from 'shared/components/Divider/Divider';
import has from 'lodash/has';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';

const propTypes = {
  gifts: PropTypes.object,
  removeFromCart: PropTypes.func,
  giftCount: PropTypes.number
}


/**
 * Class
 * @extends React.Component
 */
class GWPProductItem extends Component{

  /**
   * Create a GWPProductItem
   */
  constructor( props ){
    super( props );

    this.state = {
      variantSelected: '',
      variantIndex: 0,
      defaultIndex: 0,
      gwpToggle: true
    }

    this.clickEventFunction = this.clickEventFunction.bind( this );
    this.handleGWPChange = this.handleGWPChange.bind( this );
    this.UpdateGwpDropdown = this.UpdateGwpDropdown.bind( this );
  }

  // a reference to th Gift Variant Dropdown Element
  selectGiftVariantDropdown = undefined;

  clickEventFunction( value ){
    this.setState( { gwpToggle:value } );
    if( !value ){
      this.props.removeGiftFromCart( this.props.gifts.promoId, this.props.history );
    }
    else {
      this.props.addToCart( this.props.gifts.promoId, this.props.history );
    }
  }

  handleGWPChange( event, section ){
    if( event !== -1 ){
      if( event === 0 ){
        this.props.removeGiftFromCart( this.props.gifts.promoId, this.props.history );
      }
      else {
        this.setState( { variantSelected: 'true' } );
        this.setState( { variantIndex: event - 1 } );
        this.props.selectGiftVariant( this.props.gifts.promoId, section[event - 1].giftCatalogRefId, this.props.history );
      }
    }
  }

  UpdateGwpDropdown(){
    let notupdated = false;
    this.props.gifts.freeGifts.items.map( ( gift, index ) =>{
      if( !notupdated && gift.selected === 'default' ){
        this.setState( { variantSelected: gift.selected } );
        this.setState( { variantIndex: index } );
      }
      else if( gift.selected === 'true' ){
        notupdated = true;
        this.setState( { variantSelected: gift.selected } );
        this.setState( { variantIndex: index } );
      }
      if( gift.selected === 'default' ){
        this.setState( { defaultIndex: index } );
      }
    } )
  }

  componentWillMount(){
    this.UpdateGwpDropdown();
    this.setState( { gwpToggle:this.props.gifts.indulge } );
  }

  componentDidUpdate( prevProps ){
    if( this.props.gifts.indulge !== prevProps.gifts.indulge ){
      this.setState( { gwpToggle:this.props.gifts.indulge } );
    }

    if( prevProps.gifts.freeGifts.items !== this.props.gifts.freeGifts.items ){
      this.UpdateGwpDropdown();
    }
    if( this.props.isChkoutBtnClk && !prevProps.isChkoutBtnClk && this.props.gifts.indulge && this.state.variantSelected && this.state.variantSelected === 'default' ){
      this.selectGiftVariantDropdown.focus();
      this.props.broadcastMessage( `${ formatMessage( messages.selectOption ) } ${ formatMessage( messages.optOut ) }` );
    }
  }

  /**
   * Renders the GWPProductItem component
   */
  render(){
    const {
      gifts
    } = this.props;
    let price = ( this.props.gifts.indulge ) ? messages.free : messages.opt;

    return (
      <div className='GWPProductItem'>

        { ( () =>{
          return (
            <div>
              <div
                className={
                  classNames( {
                    'GWPProductItem__headerDivider': !this.props.gifts.indulge
                  } )
                }
              >
                { ( () =>{
                  if( this.props.giftCount !== 0 ){
                    return (
                      <Divider dividerType={ 'gray' }/>
                    )
                  }
                } )() }


              </div>
              { ( () =>{
                if( has( this.props, 'cartPageData.showShippingRestrictionMsg' ) ){
                  if( this.props.cartPageData.showShippingRestrictionMsg ){
                    if( !isEmpty( gifts.freeGifts.items[this.state.variantIndex].giftShippingRestriction ) ){
                      return (
                        <ResponseMessages
                          message={ gifts.freeGifts.items[this.state.variantIndex].giftShippingRestriction }
                        />
                      )
                    }
                  }
                }
              } )() }
              <div
                className={
                  classNames( {
                    'GWPProductItem__optedOut': !this.props.gifts.indulge
                  } )
                }
              >

                <div className='GWPProductItem__column GWPProductItem__column--image'>
                  <Anchor url={ gifts.freeGifts.items[this.state.variantIndex].giftPDPUrl }>
                    <Image
                      src={ gifts.freeGifts.items[this.state.variantIndex].giftImageURL }
                      alt={ gifts.freeGifts.items[this.state.variantIndex].giftVariant ? `${gifts.freeGifts.items[this.state.variantIndex].giftBrandName} ${gifts.freeGifts.items[this.state.variantIndex].giftDisplayName} ${gifts.freeGifts.items[this.state.variantIndex].giftVariant }` : `${gifts.freeGifts.items[this.state.variantIndex].giftBrandName} ${gifts.freeGifts.items[this.state.variantIndex].giftDisplayName}` }
                      injectSVG={ false }
                      lazyLoad={ false }
                    />
                  </Anchor>
                </div>
                <div className='GWPProductItem__column GWPProductItem__column--info'>
                  <div className='GWPProductItem__data--width'>
                    <Anchor url={ gifts.freeGifts.items[this.state.variantIndex].giftPDPUrl }>
                      <div className='GWPProductItem__title'>
                        { gifts.freeGifts.items[this.state.variantIndex].giftBrandName }
                      </div>
                      <div className='GWPProductItem__itemDescription'>
                        <span>
                          { gifts.freeGifts.items[this.state.variantIndex].giftDisplayName }
                        </span>
                      </div>
                    </Anchor>
                  </div>

                  <div className='GWPProductItem__dropdown__container'>
                    { ( () =>{
                      if( gifts.freeGifts.items.length > 2 ){
                        const giftVariantNameOrDisplayname = ( freeGifts ) =>{
                          return freeGifts.items[this.state.variantIndex].giftVariant ? freeGifts.items[this.state.variantIndex].giftVariant : freeGifts.items[this.state.variantIndex].giftDisplayName;
                        };
                        const labelFreeGiftDropdown = `GWPProductItem-dropdown${this.props.giftCount}`;
                        return (
                          <div>
                            <select
                              className={
                                classNames( {
                                  'GWPProductItem__dropdown': true,
                                  'GWPProductItem__dropdown--color': this.props.gifts.indulge && this.state.variantSelected === 'default' && this.props.isChkoutBtnClk
                                } )
                              }
                              value={ ( ( this.state.variantIndex >= 0 ) && ( this.state.variantSelected === 'true' || this.state.variantSelected === 'false' ) ) ? giftVariantNameOrDisplayname( this.props.gifts.freeGifts ) : formatMessage( messages.selectOption ) }
                              onChange={
                                ( e ) => this.handleGWPChange( ( e.target ).selectedIndex, gifts.freeGifts.items )
                              }
                              { ...( this.props.ariaLabel && { 'aria-labelledby' : this.props.ariaLabel } ) }
                              ref={ ( el )=>{
                                this.selectGiftVariantDropdown = el
                              } }
                            >
                              <option value={ formatMessage( messages.selectOption ) }>
                                { formatMessage( messages.selectOption ) }
                              </option>

                              { ( () =>{
                                try {
                                  return gifts.freeGifts.items.map( ( gift, index ) =>{
                                    if( gift.selected !== 'default' ){
                                      return (
                                        <option key={ index }>
                                          { ( gift.giftVariant ) ? ( gift.giftVariant ) : ( gift.giftDisplayName ) }
                                        </option>
                                      );
                                    }
                                  } );
                                }
                                catch ( e ){
                                }
                              } )() }

                            </select>
                            <div
                              className={
                                classNames( {
                                  'GWPProductItem__Chevron': true,
                                  'GWPProductItem__Chevron--color': this.props.gifts.indulge && this.state.variantSelected === 'default' && this.props.isChkoutBtnClk
                                } )
                              }
                            >
                              <ChevronDownSVG/>
                            </div>

                            { ( () =>{
                              if( this.props.isChkoutBtnClk && this.props.gifts.indulge && this.state.variantSelected === 'default' ){
                                this.props.handleScrollView( 'Gifts' );
                                return (
                                  <div className={ 'GWPProductItem__dropdown--message' }>
                                    <label className='sr-only'>
                                      { formatMessage( messages.optOutVariantAriaLabel ) }
                                    </label>
                                    { formatMessage( messages.optOut ) }
                                  </div>
                                )
                              }

                            } )() }
                          </div>
                        )
                      }
                    } )() }

                  </div>
                </div>
              </div>

              <div className='GWPProductItem__column GWPProductItem__column--price GWPProductItem__Footer'>
                <span className='GWPProductItem__Footer--info'>
                  { formatMessage( price ) }
                </span>
                <div className='GWPProductItem__indbtn'>
                  <span className='GWPProductItem__Footer--indulge'>
                    { formatMessage( messages.indulge ) }
                  </span>
                  <span className='GWPProductItem__Footer--button'>
                    <form>
                      <ToggleButton
                        name={ 'gwpItem' }
                        label={ '' }
                        onClick={ this.clickEventFunction }
                        isChecked={ this.state.gwpToggle }
                        ariaLabelledBy='gwpIncludeLabel'
                      />
                    </form>
                  </span>
                </div>
              </div>
            </div>
          )

        } )() }

      </div>
    )
  }

}

export const mapDispatchToProps = ( dispatch ) => {
  return {
    broadcastMessage : function( message ){
      dispatch( globalActions.setBroadcastMessage( message ) )
    }
  };
}

const mapStateToProps = ( state ) =>{
  return {
    formData: state.form.gwpProductItem
  };
}

GWPProductItem.propTypes = propTypes;

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return reduxForm( {
    form: 'gwpProductItem'
  } )( connect( mapStateToProps, mapDispatchToProps )( GWPProductItem ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );
