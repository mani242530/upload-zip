import { defineMessages } from 'react-intl';

export default defineMessages( {
  free: {
    id: 'i18n.GWPProductItem.free',
    defaultMessage: 'FREE'
  },
  hazmatMessage: {
    id: 'i18n.GWPProductItem.hazmatMessage',
    defaultMessage: `Can't be shipped via air`
  },
  indulge: {
    id: 'i18n.GWPProductItem.indulge',
    defaultMessage: 'Include'
  },
  opt:{
    id: 'i18n.GWPProductItem.opt',
    defaultMessage: 'Opted Out'
  },
  selectOption:{
    id: 'i18n.GWPProductItem.opt',
    defaultMessage: 'Select Free Gift'
  },
  freeGiftDropDownLabel:{
    id: 'i18n.GWPProductItem.freeGiftDropDown.label',
    defaultMessage: 'Free Gift Variant'
  },
  optOut: {
    id: 'i18n.GWPProductItem.optOut',
    defaultMessage: 'Select Option or Opt Out'
  },
  optOutVariantAriaLabel: {
    id: 'i18n.GWPProductItem.optOut',
    defaultMessage: 'Gift Item, '
  }
} );
