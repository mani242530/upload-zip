import React from 'react';
import ReactDOM from 'react-dom';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './GWPProductItem.messages';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import GWPProductItem, { connectFunction, mapDispatchToProps, mapStateToProps } from './GWPProductItem';


describe( '<GWPProductItem />', () => {
  let component;
  const store = configureStore( {}, CONFIG );
  let props={

    removeGiftFromCart: jest.fn()
  }
  let gifts = {
    'freeGifts': {
      'items': [
        {
          'giftCatalogRefId': '112023775',
          'giftVariant': 'Silver',
          'giftDisplayName': 'Eternity for Men Eau de Toilette',
          'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
          'selected': 'false',
          'giftBrandName': 'Calvin Klein',
          'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
        },
        {
          'giftCatalogRefId': '122023776',
          'giftVariant': 'Purple',
          'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
          'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2265812?$md$',
          'selected': 'false',
          'giftBrandName': 'Calvin Klein',
          'giftHazmatRestriction': 'Can\'t be shipped via air',
          'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
        },
        {
          'giftCatalogRefId': '132023776',
          'giftVariant': 'XXX',
          'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
          'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
          'selected': 'default',
          'giftBrandName': 'Calvin Klein',
          'giftHazmatRestriction': 'Can\'t be shipped via air',
          'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
        }
      ]
    },
    'promoID': 1143243243,
    'promoValidity': 'offer valid 1/29/17-2/11/17 or while supplies last',
    'indulge': true
  };
  component = mountWithIntl(
    <Provider store={ store }>
      <GWPProductItem
        { ...props }
        gifts={ gifts }
      />
    </Provider>
  );

  it( 'renders Image component', () => {
    expect( component.find( 'GWPProductItem' ).find( 'Image' ).length ).toBe( 1 );
  } );

  it( 'Displays header message', () => {
    expect( component.find( '.GWPProductItem__Footer--info' ).text() ).toBe( messages.free.defaultMessage )
  } );

  it( 'Product Cell contains two links', () => {
    expect( component.find( 'Anchor' ).length ).toBe( 2 );
  } );

  it( 'GWP contains chevrondown', () => {
    expect( component.find( '.GWPProductItem__Chevron' ).length ).toBe( 1 );
  } );

  it( 'should call handleGWPChange when the select field is changed', () => {
    let gwpItem = component.find( 'GWPProductItem' );
    let node = gwpItem.find( 'select' );
    const handleGWPChangeMock = jest.fn();
    gwpItem.instance().handleGWPChange = handleGWPChangeMock;
    component.update();
    node.simulate( 'change' );
    expect( handleGWPChangeMock ).toBeCalled();
  } );

  it( 'Toggle button displays', () => {
    expect( component.find( 'ToggleButton' ).length ).toBe( 1 );
  } );

  it( 'dropdown button condition displays', () => {
    expect( component.find( 'select' ).length ).toBe( 1 );
    expect( component.find( 'option' ).length ).toBe( 3 );
  } );

  it( 'dropdown selected', () => {
    expect( component.find( 'select' ).length ).toBe( 1 );
    expect( component.find( 'option' ).length ).toBe( 3 );
  } );

  it( 'dropdown button should not display when no variants', () => {
    gifts = {
      'freeGifts': {
        'items': [
          {
            'giftCatalogRefId': '212023775',
            'giftVariant': 'Silver',
            'giftDisplayName': 'Eternity for Men Eau de Toilette',
            'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
            'selected': 'true',
            'giftBrandName': 'Calvin Klein',
            'giftHazmatRestriction': 'Can\'t be shipped via air',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          },
          {
            'giftCatalogRefId': '222023776',
            'giftVariant': 'XXX',
            'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
            'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
            'selected': 'default',
            'giftBrandName': 'Calvin Klein',
            'giftHazmatRestriction': 'Can\'t be shipped via air',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          }
        ]
      },
      'promoID': 2243243243,
      'promoValidity': 'offer valid 1/29/17-2/11/17 or while supplies last',
      'indulge': false
    };
    component = mountWithIntl(
      <Provider store={ store }>
        <GWPProductItem
          gifts={ gifts }
          { ...props }
          addToCart={ jest.fn() }
        />
      </Provider>
    );
    expect( gifts.freeGifts.items.length ).toBe( 2 );
    expect( component.find( 'select' ).length ).toBe( 0 );
  } );

  it( 'Displays hazmatMessage', () => {
    const store = configureStore( {}, CONFIG );
    gifts = {
      'freeGifts': {
        'items': [
          {
            'giftCatalogRefId': '112023775',
            'giftVariant': 'Silver',
            'giftDisplayName': 'Eternity for Men Eau de Toilette',
            'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
            'selected': 'false',
            'giftBrandName': 'Calvin Klein',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          },
          {
            'giftCatalogRefId': '122023776',
            'giftVariant': 'Purple',
            'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
            'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2265812?$md$',
            'selected': 'true',
            'giftBrandName': 'Calvin Klein',
            'giftShippingRestriction': 'Can\'t be shipped via air',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          },
          {
            'giftCatalogRefId': '132023776',
            'giftVariant': 'XXX',
            'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
            'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
            'selected': 'default',
            'giftBrandName': 'Calvin Klein',
            'giftHazmatRestriction': 'Can\'t be shipped via air',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          }
        ]
      },
      'promoID': 1143243243,
      'promoValidity': 'offer valid 1/29/17-2/11/17 or while supplies last',
      'indulge': true
    };
    let props={
      cartPageData :{
        showShippingRestrictionMsg: true
      }
    };
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <GWPProductItem
          gifts={ gifts }
          { ...props }
        />
      </Provider>
    );
    expect( component1.find( 'ResponseMessages' ).length ).toBe( 1 );
    expect( component1.find( 'ResponseMessages' ).text() ).toBe( messages.hazmatMessage.defaultMessage );
  } );

  it( 'displays opted out when toggled', () => {
    expect( component.find( '.GWPProductItem__Footer--info' ).text() ).toEqual( messages.opt.defaultMessage );
  } );

  describe( 'Gift Variant not selected warning message when clicking on Secure Checkout button', () => {
    let isChkoutBtnClk = true;
    const store = configureStore( {}, CONFIG );
    const broadcastMessageMock = jest.fn();
    gifts ={
      'freeGifts': {
        'items': [
          {
            'giftCatalogRefId': '112023775',
            'giftVariant': 'Silver',
            'giftDisplayName': 'Eternity for Men Eau de Toilette',
            'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
            'selected': 'false',
            'giftBrandName': 'Calvin Klein',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          },
          {
            'giftCatalogRefId': '122023776',
            'giftVariant': 'Purple',
            'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
            'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2265812?$md$',
            'selected': 'false',
            'giftBrandName': 'Calvin Klein',
            'giftHazmatRestriction': 'Can\'t be shipped via air',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          },
          {
            'giftCatalogRefId': '132023776',
            'giftVariant': 'XXX',
            'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
            'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
            'selected': 'default',
            'giftBrandName': 'Calvin Klein',
            'giftHazmatRestriction': 'Can\'t be shipped via air',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          }
        ]
      },
      'promoID': 1143243243,
      'promoValidity': 'offer valid 1/29/17-2/11/17 or while supplies last',
      'indulge': true
    };
    const mapDispatchToPropsMock =()=>{
      return {
        broadcastMessage:broadcastMessageMock
      }
    }
    const GWPProductItemMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <GWPProductItemMock
          gifts={ gifts }
          isChkoutBtnClk={ true }
          handleScrollView={ jest.fn() }
        />
      </Provider>
    );

    it( 'have helper label for the screen reader', () => {
      expect( component1.find( '.GWPProductItem__dropdown--message label' ).text() ).toEqual( messages.optOutVariantAriaLabel.defaultMessage );
    } );

    it( 'the label should have the sr-only class name on it', () => {
      expect( component1.find( '.GWPProductItem__dropdown--message label' ).props().className ).toEqual( 'sr-only' );
    } );

    it( 'should display a warning message to select the gift or opt out', () => {
      expect( component1.find( '.GWPProductItem__dropdown--message' ).text() ).toEqual( messages.optOutVariantAriaLabel.defaultMessage+messages.optOut.defaultMessage );
    } );
    it( 'Should call broadcastMessage to broadcast aria region messages', () => {
      const prevProps = {
        gifts: {
          indulge:true,
          freeGifts:{
            items:[]
          }
        }
      }
      const componentNode = component1.find( 'GWPProductItem' ).instance();
      componentNode.state.variantSelected = 'default';
      const focusMock = jest.fn();
      componentNode.selectGiftVariantDropdown.focus = focusMock;
      componentNode.componentDidUpdate( prevProps );
      expect( focusMock ).toBeCalled();
      expect( broadcastMessageMock ).toHaveBeenCalledWith( 'Select Free Gift Select Option or Opt Out' );
    } );
  } );

  it( 'Default ToggleButton should be true', () => {
    const store = configureStore( {}, CONFIG );
    gifts = {
      'freeGifts': {
        'items': [
          {
            'giftCatalogRefId': '112023775',
            'giftVariant': 'Silver',
            'giftDisplayName': 'Eternity for Men Eau de Toilette',
            'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
            'selected': 'false',
            'giftBrandName': 'Calvin Klein',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          },
          {
            'giftCatalogRefId': '122023776',
            'giftVariant': 'Purple',
            'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
            'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2265812?$md$',
            'selected': 'true',
            'giftBrandName': 'Calvin Klein',
            'giftShippingRestriction': 'Can\'t be shipped via air',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          },
          {
            'giftCatalogRefId': '132023776',
            'giftVariant': 'XXX',
            'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
            'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
            'selected': 'default',
            'giftBrandName': 'Calvin Klein',
            'giftHazmatRestriction': 'Can\'t be shipped via air',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          }
        ]
      },
      'promoID': 1143243243,
      'promoValidity': 'offer valid 1/29/17-2/11/17 or while supplies last',
      'indulge': true
    };
    let props={
      cartPageData :{
        showShippingRestrictionMsg: true
      }
    };
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <GWPProductItem
          gifts={ gifts }
          { ...props }
        />
      </Provider>
    );
    expect( component1.find( 'GWPProductItem' ).find( 'ToggleButton' ).props().isChecked ).toBe( true );
  } );

  it( 'displays opted out when toggled', () => {
    expect( component.find( '.GWPProductItem__Footer--info' ).text() ).toEqual( messages.opt.defaultMessage );
  } );

  it( 'displays warning message down the select', () => {
    let isChkoutBtnClk = true;
    const store = configureStore( {}, CONFIG );
    gifts ={
      'freeGifts': {
        'items': [
          {
            'giftCatalogRefId': '112023775',
            'giftVariant': 'Silver',
            'giftDisplayName': 'Eternity for Men Eau de Toilette',
            'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
            'selected': 'false',
            'giftBrandName': 'Calvin Klein',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          }
        ]
      },
      'promoID': 1143243243,
      'promoValidity': 'offer valid 1/29/17-2/11/17 or while supplies last',
      'indulge': true
    };
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <GWPProductItem
          gifts={ gifts }
          { ...props }
        />
      </Provider>
    );
    expect( component1.find( 'ToggleButton' ).props().isChecked ).toBe( true );
  } );

  it( 'Default ToggleButton should be false', () => {
    let isChkoutBtnClk = true;
    const store = configureStore( {}, CONFIG );
    gifts ={
      'freeGifts': {
        'items': [
          {
            'giftCatalogRefId': '112023775',
            'giftVariant': 'Silver',
            'giftDisplayName': 'Eternity for Men Eau de Toilette',
            'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
            'selected': 'false',
            'giftBrandName': 'Calvin Klein',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          }
        ]
      },
      'promoID': 1143243243,
      'promoValidity': 'offer valid 1/29/17-2/11/17 or while supplies last',
      'indulge': true
    };
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <GWPProductItem
          gifts={ gifts }
          { ...props }
        />
      </Provider>
    );
    component1.find( 'ToggleButton input' ).simulate( 'click' );
    setTimeout( expect( component1.find( 'ToggleButton' ).props().isChecked ).toBe( false ), 1000 );
  } );

  it( 'The Select free Gift dropdown box must be labeled as ‘Free Gift Variant’ so it can be identified by assistive technologies', () => {
    const isChkoutBtnClk = true;
    const store = configureStore( {}, CONFIG );
    gifts ={
      'freeGifts': {
        'items': [
          {
            'giftCatalogRefId': '112023775',
            'giftVariant': 'Silver',
            'giftDisplayName': 'Eternity for Men Eau de Toilette',
            'giftImageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
            'selected': 'false',
            'giftBrandName': 'Calvin Klein',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          },
          {
            'giftCatalogRefId': '122023776',
            'giftVariant': 'Purple',
            'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
            'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2265812?$md$',
            'selected': 'false',
            'giftBrandName': 'Calvin Klein',
            'giftHazmatRestriction': 'Can\'t be shipped via air',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          },
          {
            'giftCatalogRefId': '132023776',
            'giftVariant': 'XXX',
            'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
            'giftImageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
            'selected': 'default',
            'giftBrandName': 'Calvin Klein',
            'giftHazmatRestriction': 'Can\'t be shipped via air',
            'giftPdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
          }
        ]
      },
      'promoID': 1143243243,
      'promoValidity': 'offer valid 1/29/17-2/11/17 or while supplies last',
      'indulge': true
    };
    const ariaLabelVal = 'gwpQuanityLabel';
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <GWPProductItem
          gifts={ gifts }
          isChkoutBtnClk={ true }
          handleScrollView={ jest.fn() }
          ariaLabel={ ariaLabelVal }
        />
      </Provider>
    );
    expect( component1.find( '.GWPProductItem__dropdown__container select' ).props()['aria-labelledby'] ).toBe( ariaLabelVal )
  } );


  it( 'Should display proper alternative text for images in gift section', () => {
    expect( component.find( 'Anchor' ).at( 0 ).find( '.Image .Loader__content' ).find( 'img' ).props().alt ).toBe( `${gifts.freeGifts.items[0].giftBrandName} ${gifts.freeGifts.items[0].giftDisplayName} ${gifts.freeGifts.items[0].giftVariant}` );
  } );

  it( 'Toggle Button should have aria-labelledby field', () => {
    expect( component.find( 'GWPProductItem' ).find( 'ToggleButton' ).props()['ariaLabelledBy'] ).toBe( 'gwpIncludeLabel' );
  } );

} );
