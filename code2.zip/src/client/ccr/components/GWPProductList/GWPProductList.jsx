/**
 * GWPProductList
 */


import React from 'react';
import PropTypes from 'prop-types';
import './GWPProductList.css';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './GWPProductList.messages';
import GWPProductItem from 'ccr/components/GWPProductItem/GWPProductItem';
import BfxProductCellItem from 'ccr/components/BfxProductCellItem/BfxProductCellItem';
import Divider from 'shared/components/Divider/Divider';
const propTypes = {
  giftItems: PropTypes.array
}


const GWPProductList = ( props ) => {


  const {
    giftItems
  } = props;
  try {

    return (
      <div id='Gifts' className='GWPProductList'>
        <div className='GWPProductList__edge'>
          <h3>  { formatMessage( messages.header ) } </h3>
          <label
            id='gwpQuantityLabel'
            hidden
          >
            { formatMessage( messages.quantityLabel ) }
          </label>
          <label
            id='gwpIncludeLabel'
            hidden
          >
            { formatMessage( messages.include ) }
          </label>
          <Divider dividerType={ 'gray' }/>
          { ( () => {
            return ( giftItems ).map( ( section, index ) => {
              return (
                <div key={ section.promoId }>
                  <GWPProductItem
                    gifts={ section }
                    isChkoutBtnClk={ props.chkoutbtnClk }
                    giftCount={ index }
                    ariaLabel='gwpQuantityLabel'
                    { ...props }
                  />
                  { ( () => {
                    if( section.freeGifts &&
                      section.bfxPriceMap &&
                      section.indulge ){
                      return section.freeGifts.items.map( ( giftInfo, index ) => {
                        if( giftInfo.selected === 'true' ){
                          return (
                            <div
                              className='BfxProductCellItem'
                              key={ index }
                            >
                              { ( () => {
                                return section.bfxPriceMap.items.map( ( bfxPriceInfo, index ) => {
                                  return (
                                    <BfxProductCellItem
                                      key={ index }
                                      index={ index }
                                      skuId={ giftInfo.giftCatalogRefId }
                                      productName={ giftInfo.giftDisplayName }
                                      productImageUrl={ giftInfo.giftImageURL }
                                      productURL={ giftInfo.giftPDPUrl }
                                      quantity={ bfxPriceInfo.bfxQty }
                                      price={ bfxPriceInfo.bfxPrice }
                                    />
                                  );
                                } );
                              } )() }
                            </div>
                          )
                        }
                      } );
                    }
                  } )() }
                </div>
              );
            } );
          } )() }
        </div>

        { !props.isMobileDevice &&
          <div className='GWPProductList__border--header'>
            <Divider dividerType={ 'gray' }/>
          </div>
        }

      </div>
    )

  }
  catch ( exception ){
  }
}

GWPProductList.propTypes = propTypes;

export default GWPProductList;
