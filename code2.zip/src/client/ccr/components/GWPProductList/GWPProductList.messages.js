/*
 * GWPProductList Messages
 *
 * This contains all the text for the GWPProductList component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.GWPProductList.header',
    defaultMessage: 'Your Gifts'
  },
  quantityLabel: {
    id: 'i18n.GWPProductList.quantityLabel',
    defaultMessage: 'Free Gift Variant'
  },
  include: {
    id: 'i18n.GWPProductItem.include',
    defaultMessage: 'Include free gift'
  }
} );
