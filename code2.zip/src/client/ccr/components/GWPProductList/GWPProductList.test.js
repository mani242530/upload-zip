import React from 'react';
import ReactDOM from 'react-dom';
import GWPProductList from './GWPProductList';
import messages from './GWPProductList.messages';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';


describe( '<GWPProductList />', () => {


  let component;
  let store = configureStore( {}, CONFIG );
  let giftItems = {
    items: [
      {
        bfxPriceMap:{
          items: [
            {
              bfxQty: '1',
              bfxPrice: '$0.00'
            }
          ]
        },
        freeGifts: {
          items: [
            {
              giftCatalogRefId: '112023775',
              giftVariant: 'Silver',
              giftDisplayName: 'Eternity for Men Eau de Toilette',
              giftImageURL: 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
              selected: 'true',
              giftBrandName: 'Calvin Klein',
              giftPdpUrl: 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
            },
            {
              giftCatalogRefId: '132023776',
              giftVariant: 'XXX',
              giftDisplayName: 'Hair Building Fibers-Medium Blonde',
              giftImageURL: 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
              selected: 'default',
              giftBrandName: 'Calvin Klein',
              giftPdpUrl: 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
            }
          ]
        },
        promoID: 1143243243,
        indulge: true
      },
      {
        bfxPriceMap:{
          items: [
            {
              bfxQty: '1',
              bfxPrice: '$0.00'
            }
          ]
        },
        freeGifts: {
          items: [
            {
              giftCatalogRefId: '112023775',
              giftVariant: 'Silver',
              giftDisplayName: 'Eternity for Men Eau de Toilette',
              giftImageURL: 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
              selected: 'false',
              giftBrandName: 'Calvin Klein',
              giftPdpUrl: 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
            },
            {
              giftCatalogRefId: '132023776',
              giftVariant: 'XXX',
              giftDisplayName: 'Hair Building Fibers-Medium Blonde',
              giftImageURL: 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
              selected: 'default',
              giftBrandName: 'Calvin Klein',
              giftShippingRestriction: 'Can\'t be shipped via air',
              giftPdpUrl: 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588'
            }
          ]
        },
        promoID: 1143243243,
        indulge: true
      }
    ]
  };
  // store.getState().cartPageData.showShippingRestrictionMsg=true;
  let props={
    cartPageData:{
      'showShippingRestrictionMsg': true
    }
  }
  component = mountWithIntl(
    <Provider store={ store }>
      <GWPProductList
        giftItems={ giftItems.items }
        { ...props }
      />
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'GWPProductList' ).length ).toBe( 1 );
  } );
  it( 'should have the label present for the screenreader to be able to assosicate to the gift dropdown', () => {
    expect( component.find( '#gwpQuantityLabel' ).length ).toBe( 1 );
    expect( component.find( '#gwpQuantityLabel' ).props().hidden ).toBeTruthy();
    expect( component.find( '#gwpQuantityLabel' ).text() ).toBe( messages.quantityLabel.defaultMessage );
  } );
  it( 'should have the label present for the screenreader to be able to assosicate to the include toggle buttons', () => {
    expect( component.find( '#gwpIncludeLabel' ).length ).toBe( 1 );
    expect( component.find( '#gwpIncludeLabel' ).props().hidden ).toBeTruthy();
    expect( component.find( '#gwpIncludeLabel' ).text() ).toBe( messages.include.defaultMessage );
  } );
  it( 'renders Divider component', () => {
    expect( component.find( 'GWPProductList' ).find( 'Divider' ).length ).toBe( 3 );
  } );
  it( 'renders GWPProductItem component', () => {
    expect( component.find( 'GWPProductList' ).find( 'GWPProductItem' ).length ).toBe( 2 );
  } );
  it( 'renders Hazmat message if the showShippingRestrictionMsg is true', () => {
    expect( component.find( 'GWPProductList' ).find( 'ResponseMessages' ).length ).toBe( 1 );
  } );
  it( 'renders BfxProductCellItem component only once', () => {
    expect( component.find( '.BfxProductCellItem' ).length ).toBe( 1 );
  } );

  it( 'should not render BfxProductCellItem if induldge is false', () => {
    giftItems.items[0].indulge = false;
    component = mountWithIntl(
      <Provider store={ store }>
        <GWPProductList
          giftItems={ giftItems.items }
          { ...props }
        />
      </Provider>
    );

    expect( component.find( '.BfxProductCellItem' ).length ).toBe( 0 );
  } );
} );
