/**
 * GiftBox
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './GiftBox.css';
import { connect } from 'react-redux';
import GiftBoxSVG from 'shared/components/Icons/giftbox';
import { Collapse } from 'react-bootstrap';
import { formatMessage, formatNumber } from 'shared/components/Global/Global';
import messages from './GiftBox.messages';
import ProductDescriptionCard from 'ccr/components/ProductDescriptionCard/ProductDescriptionCard';
import ToggleButton from 'shared/components/ToggleButton/ToggleButton';
import Divider from 'shared/components/Divider/Divider';
import _ from 'lodash';
import classNames from 'classnames';
import MixedMenuButton from 'shared/components/MixedMenuButton/MixedMenuButton';
import { reduxForm } from 'redux-form';
import has from 'lodash/has';

const propTypes = {
  giftBoxMessage: PropTypes.string,
  giftBoxTitle: PropTypes.string,
  giftBoxReceiptMessage: PropTypes.string,
  giftBoxPrice: PropTypes.number,
  giftInclude: PropTypes.bool,
  giftNoteTitle: PropTypes.string,
  giftNoteMessage: PropTypes.string,
  giftMessage: PropTypes.string,
  giftHeaderMessage: PropTypes.string
}



/**
 * Class
 * @extends React.Component
 */
class GiftBox extends Component{

  /**
   * Create a GiftBox
   */
  constructor( props ){
    super( props );
    this.giftBoxStatus = this.giftBoxStatus.bind( this );
    this.toggleTextAreaDisplay = this.toggleTextAreaDisplay.bind( this )
  }

  /**
   * Renders the GiftBox component
   */
  componentDidMount(){
    this.props.setGiftMessage( this.props.giftMessage );
  }
  toggleTextAreaDisplay(){
    this.props.focusGiftBox();
  }
  setGiftText( e ){
    this.props.setGiftMessage( e.target.value );
  }

  setGiftTextByServiceCall( e ){
    if( this.props.giftTextChange ){
      this.props.setGiftMessage( e.target.value );
      this.props.setGiftWrapGiftNoteService( e.target.value, this.props.history );
    }
    if( this.props.giftBoxActiveFlag ){
      this.props.blurGiftBox();
    }
  }


  giftBoxStatus( value ){
    this.props.setGiftWrapGiftBoxService( value, this.props.history );
    this.props.setGiftBoxToggleStatus( value );
  }


  render(){
    const {
      setCartRightPanelCollapse,
      cartRightPanelCollapse
    } = this.props;

    let textAreaCount = 250;

    return (
      <div className='GiftBox'>
        { ( () => {
          try {

            return (
              <div className={ classNames(
                { 'GiftOptions__selectedMixedNavDetailsLink': ( this.props.giftHeaderMessage || this.props.giftBoxToggle  ) }
              ) }
              >
                <MixedMenuButton
                  label={ formatMessage( messages.giftOptions ) }
                  details={ this.props.giftHeaderMessage }
                  pointerType='collapse'
                  onClick={ e => {
                    e.preventDefault();
                    setCartRightPanelCollapse( 'gifts' );

                  } }
                  pointerMinus={ cartRightPanelCollapse.gifts }

                />

                <Collapse in={ cartRightPanelCollapse.gifts }>
                  <div className='GiftBox__Content'>
                    <div className='GiftBox__container'>
                      <div className='GiftBox__collapse__giftBox'>
                        <div className='GiftNote__Panel'>
                          <div className='GiftNote__noteMessage'>
                            { this.props.giftNoteMessage }
                          </div>
                          <div className='GiftNote__giftNoteTextArea'>
                            <label
                              className={
                                classNames(
                                  'TextAreaField__label', {
                                    'TextAreaField__label--active': this.props.giftBoxActiveFlag || !this.props.giftBoxActiveFlag && ( this.props.giftText && this.props.giftText !== '' )
                                  }
                                )
                              }
                              htmlFor='giftMessageTextArea'
                            >
                              { this.props.giftNoteTitle }
                            </label>
                            <textarea
                              id='giftMessageTextArea'
                              name='giftMessageTextArea'
                              className={
                                classNames(
                                  'GiftNote__textArea', {
                                    'GiftNote__textArea--active': this.props.giftBoxActiveFlag || !this.props.giftBoxActiveFlag && ( this.props.giftText && this.props.giftText !== '' )
                                  }
                                )
                              }
                              type='text'
                              value={ this.props.giftText === null ? '' : this.props.giftText }
                              onChange={ this.setGiftText.bind( this ) }
                              onBlur={ this.setGiftTextByServiceCall.bind( this ) }
                              onClick={ this.toggleTextAreaDisplay }
                              onFocus={ this.toggleTextAreaDisplay }
                              maxLength={ textAreaCount }
                            />
                          </div>
                          <div className='GiftNote__remainingChars'>
                            { ( ()=>{
                              if( this.props.giftText!==null ){
                                return (
                                  formatNumber( textAreaCount - this.props.giftText.length )
                                );
                              }
                              else {
                                return (
                                  formatNumber( textAreaCount )
                                );
                              }
                            } )() }
                            { formatMessage( messages.remainingCharacters ) }
                          </div>
                        </div>

                        <div className='GiftBox__Divider'>
                          <Divider dividerType={ 'gray' }/>
                        </div>
                        <div className='GiftBox__Panel'>
                          <div className='GiftBox__cardPanel'>
                            <ProductDescriptionCard
                              isSVG={ true }
                              displayName={ this.props.giftBoxMessage }
                              brandName={ this.props.giftBoxTitle + ( new Intl.NumberFormat( 'en-US', {
                                style: 'currency',
                                currency: 'USD'
                              } ).format( this.props.giftBoxPrice ) ) }
                              svgComponent={ <GiftBoxSVG/> }
                            />
                          </div>
                          <div className='GiftBox__togglePanel'>
                            <label htmlFor='giftBoxCheckBox' className='sr-only' >
                              { formatMessage( messages.giftOptions ) }
                            </label>
                            { ( ()=>{
                              try {
                                return (
                                  <form>
                                    <ToggleButton
                                      id='giftBoxCheckBox'
                                      name='giftBox'
                                      label={ '' }
                                      onClick={ this.giftBoxStatus }
                                      isChecked={ this.props.giftBoxToggle }
                                    />
                                  </form>
                                )
                              }
                              catch ( e ){

                              }
                            } )() }
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Collapse>


              </div>
            )
          }
          catch ( e ){
          }
        } )() }


      </div>
    );
  }
}
const mapStateToProps = ( state ) => {
  return {
    formData: state.form.gift
  };
}

GiftBox.propTypes = propTypes;

export default
reduxForm( {
  form: 'gift'
} )( connect( mapStateToProps )( GiftBox ) );
