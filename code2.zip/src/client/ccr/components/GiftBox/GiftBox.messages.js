/*
 * GiftBox Messages
 *
 * This contains all the text for the GiftBox component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.GiftBox.header',
    defaultMessage: 'This is the GiftBox component !'
  },
  remainingCharacters: {
    id: 'i18n.GiftBox.remainingCharacters',
    defaultMessage: ' characters remaining'
  },
  giftOptions: {
    id: 'i18n.GiftBox.giftOptions',
    defaultMessage: 'Make This Order a Gift'
  }
} );
