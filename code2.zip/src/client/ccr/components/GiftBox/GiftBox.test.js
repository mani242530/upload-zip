import React from 'react';
import ReactDOM from 'react-dom';
import GiftBox from './GiftBox';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from '../GiftBox/GiftBox.messages';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import { IntlProvider } from 'react-intl';

describe( 'GiftWrap CardPanel ', () => {
  let component;
  const store = configureStore( {}, CONFIG );
  let setGiftWrapGiftBoxServiceMock = jest.fn();
  let focusGiftBoxMock =jest.fn();
  let blurGiftBoxMock =jest.fn();
  let props = {
    setGiftWrapGiftBoxService: setGiftWrapGiftBoxServiceMock,
    setGiftWrapGiftNoteService: jest.fn(),
    setGiftBoxToggleStatus :jest.fn(),
    setGiftMessage: jest.fn(),
    blurGiftBox: blurGiftBoxMock,
    focusGiftBox:focusGiftBoxMock,
    giftTextChange:jest.fn(),
    giftBoxMessage: 'Make it fancy! All wrapped up and topped with an Italian silk bow.',
    giftBoxTitle: 'Gift Box - ',
    giftBoxReceiptMessage: '',
    giftBoxPrice: 3.99,
    giftInclude: false,
    giftNoteTitle: 'Gift Note - FREE',
    giftNoteMessage: 'Prices will be hidden on the receipt',
    giftMessage: '',
    cartRightPanelCollapse: {},
    setCartRightPanelCollapse: jest.fn(),
    giftText: 'Happy Birthday',
    giftBoxToggle: false,
    giftBoxActiveFlag:true

  }
  component = mountWithIntl(
    <Provider store={ store }>
      <GiftBox { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {

    expect( component.find( 'GiftBox' ).length ).toBe( 1 );
  } );
  it( 'Should contain gift box note panel inside GiftWrap component', () => {
    expect( component.find( 'GiftBox .GiftBox__Panel .GiftBox__cardPanel' ).length ).toBe( 1 );
  } );
  it( 'Should contain gift note panel inside GiftWrap component', () => {
    expect( component.find( 'GiftBox .GiftNote__Panel' ).length ).toBe( 1 );
  } );
  it( 'Should contain gift note label if textarea field is active', () => {
    expect( component.find( '.GiftNote__giftNoteTextArea .TextAreaField__label .TextAreaField__label--active' ).length ).toBe( 1 );
  } );
  it( 'Should not contain gift note active label if textarea field doesnot have any value', () => {
    const store = configureStore( {}, CONFIG );
    const props1 = {
      setGiftWrapGiftBoxService: jest.fn(),
      setGiftWrapGiftNoteService: jest.fn(),
      setGiftMessage: jest.fn(),
      giftBoxMessage: 'Make it fancy! All wrapped up and topped with an Italian silk bow.',
      giftBoxTitle: 'Gift Box - ',
      giftBoxReceiptMessage: '',
      giftBoxPrice: 3.99,
      giftInclude: false,
      giftNoteTitle: 'Gift Note - FREE',
      giftNoteMessage: 'Prices will be hidden on the receipt',
      giftMessage: '',
      cartRightPanelCollapse: {},
      setCartRightPanelCollapse: jest.fn(),
      giftBoxToggle: false

    }
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <GiftBox { ...props1 }/>
      </Provider>
    );
    expect( component1.find( '.GiftNote__giftNoteTextArea .TextAreaField__label .TextAreaField__label--active' ).length ).toBe( 0 );
  } );

  it( 'Should contain gift note label', () => {
    expect( component.find( '.GiftNote__Panel .GiftNote__noteMessage' ).length ).toBe( 1 );
  } );

  it( 'Should contain gift note label text', () => {
    expect( component.find( 'GiftBox .GiftNote__Panel .GiftNote__noteMessage' ).text() ).toBe( props.giftNoteMessage );
  } );

  it( 'Should contain gift note text area', () => {
    expect( component.find( 'GiftBox .GiftNote__Panel .GiftNote__giftNoteTextArea' ).length ).toBe( 1 );
  } );

  it( 'Should contain gift note text area field', () => {
    let maxCharCount = 250;
    let mockTextCharLength = maxCharCount - ( component.find( 'GiftBox .GiftNote__Panel .GiftNote__giftNoteTextArea textarea' ).text() ).length;
    let mockCharCountText = mockTextCharLength + '' + messages.remainingCharacters.defaultMessage;
    expect( component.find( 'GiftBox .GiftNote__Panel .GiftNote__remainingChars' ).text() ).toBe( mockCharCountText );
    expect( component.find( 'GiftBox .GiftNote__Panel .GiftNote__giftNoteTextArea textarea' ).length ).toBe( 1 );
  } );

  it( 'Should contain active gift note text area field if textarea field have value', () => {
    expect( component.find( 'GiftBox .GiftNote__Panel .GiftNote__giftNoteTextArea .GiftNote__textArea .GiftNote__textArea--active' ).length ).toBe( 1 );
  } );

  it( 'Should display remaining characters count field below the textarea field ', () => { // check this
    expect( component.find( 'GiftBox .GiftNote__Panel .GiftNote__remainingChars' ).length ).toBe( 1 );
  } );

  it( 'Should invoke setGiftWrapGiftBoxService method on click of the toogle button', () => {
    component.find( '.ToggleButton__checkbox' ).simulate( 'click' );
    expect( setGiftWrapGiftBoxServiceMock ).toBeCalled();
  } );

  it( 'Should invoke focusGiftBox method on click of the text area', () => {
    component.find( 'GiftBox .GiftNote__Panel .GiftNote__giftNoteTextArea .GiftNote__textArea .GiftNote__textArea--active' ).simulate( 'click' );
    expect( focusGiftBoxMock ).toBeCalled( );
  } );

  it( 'Should invoke blurGiftBox method on blur of the text area', () => {
    component.find( 'GiftBox .GiftNote__Panel .GiftNote__giftNoteTextArea .GiftNote__textArea .GiftNote__textArea--active' ).simulate( 'blur' );
    expect( blurGiftBoxMock ).toBeCalled( );
  } );


} );

describe( 'GiftWrap NotePanel ', () => {
  let component;
  let props = {
    setGiftWrapGiftBoxService: jest.fn(),
    setGiftWrapGiftNoteService: jest.fn(),
    setGiftMessage: jest.fn(),
    giftBoxMessage: 'Make it fancy! All wrapped up and topped with an Italian silk bow.',
    giftBoxTitle: 'Gift Box - ',
    giftBoxReceiptMessage: '',
    giftBoxPrice: 3.99,
    giftInclude: false,
    giftNoteTitle: 'Gift Note - FREE',
    giftNoteMessage: 'Prices will be hidden on the receipt',
    giftMessage: '',
    cartRightPanelCollapse: {},
    setCartRightPanelCollapse: jest.fn(),
    giftText: 'Happy Birthday',
    giftBoxToggle: false,
    giftHeaderMessage:'Hello'
  }
  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <GiftBox { ...props }/>
    </Provider>
  );

  it( 'Should contain ProductDescriptionCard component', () => {
    expect( component.find( 'ProductDescriptionCard' ).length ).toBe( 1 );
  } );

  it( 'Should contain GiftBox__togglePanel layout', () => {
    expect( component.find( '.GiftBox__togglePanel' ).length ).toBe( 1 );
  } );

  it( 'Should contain ToggleButton component', () => {
    expect( component.find( 'ToggleButton' ).length ).toBe( 1 );
  } );

  it( 'Should have class GiftOptions__selectedMixedNavDetailsLink when there is a gift text', () => {
    expect( component.find( '.GiftOptions__selectedMixedNavDetailsLink' ).length ).toBe( 1 );
  } );

  let props1 = {
    setGiftWrapGiftBoxService: jest.fn(),
    setGiftWrapGiftNoteService: jest.fn(),
    setGiftMessage: jest.fn(),
    giftBoxMessage: 'Make it fancy! All wrapped up and topped with an Italian silk bow.',
    giftBoxTitle: 'Gift Box - ',
    giftBoxReceiptMessage: '',
    giftBoxPrice: 3.99,
    giftInclude: false,
    giftNoteTitle: 'Gift Note - FREE',
    giftNoteMessage: 'Prices will be hidden on the receipt',
    giftMessage: '',
    cartRightPanelCollapse: {},
    setCartRightPanelCollapse: jest.fn(),
    giftText: 'Happy Birthday',
    giftBoxToggle: false
  }
  let component1 = mountWithIntl(
    <Provider store={ store }>
      <GiftBox { ...props1 }/>
    </Provider>
  );
  it( 'Should not have class GiftOptions__selectedMixedNavDetailsLink class when there is no gift text', () => {
    expect( component1.find( '.GiftOptions__selectedMixedNavDetailsLink' ).length ).toBe( 0 );
  } );

  it( 'Toggle Button should have id and aria-labelledby fields', () => {
    expect( component1.find( '.GiftBox__togglePanel label' ).at( 0 ).text() ).toBe( messages.giftOptions.defaultMessage )
    expect( component1.find( '.GiftBox__togglePanel ToggleButton' ).at( 0 ).props()['aria-labelledby'] ).toBe( component1.find( '.GiftBox__togglePanel label' ).at( 0 ).props().id )
  } );

  const props2 = {
    setGiftWrapGiftBoxService: jest.fn(),
    setGiftWrapGiftNoteService: jest.fn(),
    setGiftMessage: jest.fn(),
    giftBoxMessage: 'Make it fancy! All wrapped up and topped with an Italian silk bow.',
    giftBoxTitle: 'Gift Box - ',
    giftBoxReceiptMessage: '',
    giftBoxPrice: 3.99,
    giftInclude: false,
    giftNoteTitle: 'Gift Note - FREE',
    giftNoteMessage: 'Prices will be hidden on the receipt',
    giftMessage: '',
    cartRightPanelCollapse: {},
    setCartRightPanelCollapse: jest.fn(),
    giftBoxToggle: false
  }
  const component2 = mountWithIntl(
    <Provider store={ store }>
      <GiftBox { ...props2 }/>
    </Provider>
  );

  it( 'Should not contain active gift note text area field if textarea field doesnot have any value', () => {
    expect( component2.find( 'GiftBox .GiftNote__Panel .GiftNote__giftNoteTextArea .GiftNote__textArea .GiftNote__textArea--active' ).length ).toBe( 0 );
  } );

} );
