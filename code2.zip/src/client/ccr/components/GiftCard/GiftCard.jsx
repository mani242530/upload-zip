/**
 * GiftCard
 */

import React, { Component } from 'react';
import './GiftCard.css';
import MixedMenuButton from 'shared/components/MixedMenuButton/MixedMenuButton';
import { Collapse } from 'react-bootstrap';
import messages from './GiftCard.messages';
import InputField from 'shared/components/InputField/InputField';
import { Field, reduxForm, change, untouch, reset } from 'redux-form';
import Spinner from 'shared/components/Icons/spinner';
import classNames from 'classnames';
import Anchor from 'shared/components/Anchor/Anchor';
import { connect } from 'react-redux';
import { isEmpty, isUndefined, has, keys, omitBy, isNil, find } from 'lodash';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import {
  validate as validationMethod,
  validationKeys
} from 'utils/FormValidations/FormValidations';
import FormValidationMessages from 'utils/FormValidations/FormValidations.messages';
import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';
import { formatMessage } from 'shared/components/Global/Global';
import {
  checkIfAndroidChrome
} from 'utils/DeviceDetection/deviceDetection';
import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';
import PropTypes from 'prop-types'
/**
 * Class
 * @extends React.Component
 */
const propTypes={
  giftCardDetails: PropTypes.object,
  setCartRightPanelCollapse: PropTypes.func,
  removePaymentService:PropTypes.func,
  cartRightPanelCollapse: PropTypes.object,
  giftCardApplying: PropTypes.bool,
  updatePaymentServiceResponse: PropTypes.func
}
export const mapStateToProps = ( state ) => {
  return {
    user: state.user,
    giftCard: ( state.form.giftCard )
  };
}

class GiftCard extends Component{

  /**
   * Create a GiftCard
   */
  constructor( props ){
    super( props );
    this.state = {
      value: false,
      tempGiftCardNumber: 0,
      tempGiftCardPin:0
    };
    this.updateState = this.updateState.bind( this );
    this.validateCard = this.validateCard.bind( this );
    this.removeCard = this.removeCard.bind( this );
    this.validateGiftCardForm = this.validateGiftCardForm.bind( this );
  }

  // a reference to th removeGiftCard Anchor Element
  removeGiftCardAnchor = undefined;

  updateState(){
    this.setState( { value: !this.state.value } )
  }

  removeCard(){
    this.props.change( 'giftCardNumber', '' );
    this.props.change( 'giftCardPin', '' );
    if( !isUndefined( this.props.giftCard.values ) ){
      delete this.props.giftCard.values.giftCardNumber;
      delete this.props.giftCard.values.giftCardPin;
    }
    let data = {
      values: {
        paymentType: 'giftCard'
      }
    }
    this.props.removePaymentService( data );
  }
  validateCard( value ){
  // this function is invoked on change in giftCard number and pin, checks whether the GiftcardNumber and pin are filled completely and makes a service call.
  // We need two if conditions because the user may fill the giftcard number first, followed by pin and vice-versa.
    const {
      values,
      syncErrors,
      active
    } = this.props.giftCard;

    if( value.replace( / /g, '' ).length>15&&active==='giftCardNumber'&& !this.props.giftCardApplying ){
      this.setState( { tempGiftCardNumber:value } );
      if( this.state.tempGiftCardPin.length>0 && isUndefined( syncErrors.giftCardPin ) ){
        let data = {
          values: {
            paymentType: 'giftCard',
            giftcardNumber: value.replace( / /g, '' ),
            giftCardPin: this.state.tempGiftCardPin
          }
        }
        // we are broadCasting an empty message because the screen reader sometimes will not read the same message which is populated in the gloabalAssertive div( which is in index.html). This will be done only before the service call.
        this.props.broadcastMessage( '' );
        this.props.updatePaymentServiceResponse( data );
      }
    }

    if( value.length>7&&active==='giftCardPin'&& !this.props.giftCardApplying ){
      this.setState( { tempGiftCardPin:value } );
      if( this.state.tempGiftCardNumber.length>0 && isUndefined( syncErrors.giftCardNumber ) ){
        let data = {
          values: {
            paymentType: 'giftCard',
            giftcardNumber: this.state.tempGiftCardNumber.replace( / /g, '' ),
            giftCardPin: value
          }
        }
        // we are broadCasting an empty message because the screen reader sometimes will not read the same message which is populated in the gloabalAssertive div( whihc is in index.html). This will be done only before the service call.
        this.props.broadcastMessage( '' );
        this.props.updatePaymentServiceResponse( data );
      }
    }
  }
  componentDidUpdate( prevProps ){
    const {
      isGiftCardRemoved
    } = this.props;
    if( prevProps.giftCardDetails!==this.props.giftCardDetails && has( this.props.giftCardDetails, 'messages' ) ){
      if( !this.props.giftCardError ){
        this.setState( { tempGiftCardPin:'' } );
        this.setState( { tempGiftCardNumber:'' } );
      }
    }
    if( prevProps.giftCardDetails!==this.props.giftCardDetails ){
      this.props.untouch( 'giftCard', 'giftCardNumber' );
      this.props.untouch( 'giftCard', 'giftCardPin' );
    }
    if( ( has( this.props, 'giftCardDetails.paymentInfo.paymentDetails' ) && !isEmpty( this.props.giftCardDetails.paymentInfo.paymentDetails ) ) &&
        ( !has( prevProps, 'giftCardDetails.paymentInfo.paymentDetails' ) || isEmpty( prevProps.giftCardDetails.paymentInfo.paymentDetails ) ) ){
      let isGiftCardErrorPresent = false;
      if( has( this.props.giftCardDetails, 'messages' || !isEmpty( this.props.giftCardDetails.messages ) ) ){
        isGiftCardErrorPresent = !!find( this.props.giftCardDetails.messages, { messageType:'Error' } )
      }

      if( !isGiftCardErrorPresent ){
        let giftAmount = Intl.NumberFormat( 'en-US', {
          style: 'currency',
          currency: 'USD'
        } ).format( this.props.giftCardDetails.paymentInfo.amount );
        let cardBalance = Intl.NumberFormat( 'en-US', {
          style: 'currency',
          currency: 'USD'
        } ).format( this.props.giftCardDetails.paymentInfo.paymentDetails.giftcardBalance );
        this.removeGiftCardAnchor.focus(); // as per requirement we need focus on `remove` link after the giftCard was applied.
        this.props.broadcastMessage( `${ formatMessage( messages.giftCardLabel, { amount: giftAmount, number: this.props.giftCardDetails.paymentInfo.paymentDetails.giftcardNumber } ) } ${ formatMessage( messages.giftCardBal, { number: cardBalance } ) }` );
      }
      else {
        ( this.props.giftCardDetails.messages ).map( ( message, index ) => {
          if( message.messageDesc ){
            this.props.broadcastMessage( message.messageDesc );
          }
        } );
      }
    }
    if( isGiftCardRemoved && !prevProps.isGiftCardRemoved ){
      this.props.broadcastMessage( formatMessage( messages.giftCardRemovedAriaLabel ) );
    }
  }

  validateGiftCardForm(){
    this.props.touch( 'giftCard', 'giftCardNumber' );
    this.props.touch( 'giftCard', 'giftCardPin' );
  }

  /**
   *  Renders the GiftCard component
   */
  render(){
    const {
      paymentInfo
    } = this.props.giftCardDetails;
    let giftAmount;
    let cardBalance;
    let isNotHavingData=true;
    if( !isUndefined( paymentInfo ) && !isEmpty( paymentInfo ) ){
      if( !isUndefined( paymentInfo.paymentDetails ) ){
        isNotHavingData=false;
        giftAmount = Intl.NumberFormat( 'en-US', {
          style: 'currency',
          currency: 'USD'
        } ).format( paymentInfo.amount );
        cardBalance = Intl.NumberFormat( 'en-US', {
          style: 'currency',
          currency: 'USD'
        } ).format( paymentInfo.paymentDetails.giftcardBalance );
      }
    }
    if( has( this.props.giftCardDetails, 'messages' ) ){
      if( this.props.giftCardDetails.messages.length>0 ){
        this.props.giftCardDetails.messages.map( val => {
          isNotHavingData=( val.messageType==='Error' );
        } )
      }
    }

    if( this.props.giftCardError === true ){
      isNotHavingData = true;
    }
    return (
      <div className='GiftCard'>
        <div
          className={
            classNames( {
              'GiftCard__fontWeight': isNotHavingData
            } )
          }
        >
          <MixedMenuButton
            label={ isNotHavingData ?
              formatMessage( messages.applyLabel ) :
              formatMessage( messages.giftCardLabel, { amount: giftAmount, number: paymentInfo.paymentDetails.giftcardNumber } )
            }
            details={ isNotHavingData ? '' :
              formatMessage( messages.giftCardBal, { number: cardBalance } )
            }
            pointerType='collapse'
            onClick={ e => {
              e.preventDefault();
              this.props.setCartRightPanelCollapse( 'giftCard' );
            } }
            pointerMinus={ this.props.cartRightPanelCollapse.giftCard }
          />
        </div>
        { ( () => {
          if( !isNotHavingData ){
            return (
              <div className='GiftCard__Remove'>
                <Anchor
                  url='#'
                  ariaLabel={ formatMessage( messages.removeGiftCardAriaLabel ) }
                  title={ formatMessage( messages.remove ) }
                  clickHandler={ this.removeCard }
                  analyticsEvent={ {
                    eventName: 'trackRemoveGiftCard'
                  } }
                  ref={ ( el ) => {
                    this.removeGiftCardAnchor = el;
                  } }
                >
                  { formatMessage( messages.remove ) }
                </Anchor>
              </div>
            )
          }
        } )() }
        <Collapse in={ isNotHavingData && this.props.cartRightPanelCollapse.giftCard }>
          <form onBlur={ this.validateGiftCardForm } aria-hidden={ !isNotHavingData } >
            <div className={
              classNames( 'GiftCard__Input', {
                'GiftCard__Input--removing': this.props.giftCardApplying
              } )
            }
            >
              <div className='GiftCard__Input--Number'>
                <InputField
                  label={ formatMessage( messages.giftcardNumber ) }
                  formatter={ { pattern: '9999 9999 9999 9999' } }
                  type='tel'
                  name={ 'giftCardNumber' }
                  autoComplete='off'
                  handleChange={ this.validateCard }
                  formName='giftcard'
                  trackAnalytics={ true }
                  value={ ( has( this.props, 'giftCardDetails.paymentInfo.paymentDetails.giftcardNumber' ) ) ? this.props.giftCardDetails.paymentInfo.paymentDetails.giftcardNumber : '' }
                />
              </div>
              <div className='GiftCard__Input--Pin'>
                <InputField
                  label={ formatMessage( messages.giftcardPin ) }
                  formatter={ { pattern: '99999999' } }
                  type='tel'
                  name={ 'giftCardPin' }
                  autoComplete='off'
                  handleChange={ this.validateCard }
                  formName='giftcard'
                  trackAnalytics={ true }
                />
              </div>

              { ( ()=>{
                if( !isUndefined( this.props.giftCardDetails.messages ) && !isEmpty( this.props.giftCardDetails.messages ) ){
                  return ( this.props.giftCardDetails.messages ).map( ( message, index ) => {
                    if( message.messageType === 'Error' ){
                      return (
                        <div
                          className='GiftCard__Input--Error'
                          key={ index }
                        >
                          <ResponseMessages
                            messageType={ message.messageType }
                            message={ message.messageDesc }
                          />
                        </div>
                      )
                    }
                  } )
                }
              } )() }
            </div>
            <div
              className={
                classNames( 'GiftCard__apply', {
                  'showRemoved': this.props.giftCardApplying,
                  'hideRemoved': !this.props.giftCardApplying
                } )
              }
            >
              <Spinner />
              <span className='applyText'>{ formatMessage( messages.apply ) }</span>
            </div>
          </form>
        </Collapse>
      </div>
    );
  }
}


export const validate = ( values ) => {
  const errors = {};

  if( values.formType === 'anonymous' || isUndefined( values.formType ) ){
    errors.giftCardNumber = validationMethod( values.giftCardNumber, validationKeys.requiredGiftCard, FormValidationMessages.requiredGiftCard );
    errors.giftCardPin = validationMethod( values.giftCardPin, validationKeys.requiredCardPin, FormValidationMessages.requiredCardPin );
  }

  if( !isUndefined( values.giftCardNumber ) ){

    errors.giftCardNumber = validationMethod( values.giftCardNumber, validationKeys.validateGiftCard, FormValidationMessages.validateGiftCard );

  }
  if( values.giftCardPin ){

    errors.giftCardPin = validationMethod( values.giftCardPin, validationKeys.validateCardPin, FormValidationMessages.validateCardPin );

  }

  return errors;
}

export const onSubmitFail = ( errors, dispatch ) => {
  let analyticErrors = [];
  analyticErrors.push( { 'GiftCardFormErrors':  omitBy( errors, isNil ) } );

  let evt = {
    'name': 'trackErrorDisplayed',
    'data': analyticErrors
  }
  dispatch( analyticActions.triggerAnalyticsEvent( evt ) );

}
export const mapDispatchToProps = ( dispatch ) => {
  return {
    changeFieldValue: function( field, value ){
      dispatch( change( 'giftCard', field, value ) )
    },
    broadcastMessage : function( message ){
      dispatch( globalActions.setBroadcastMessage( message ) )
    }
  };
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return reduxForm( {
    form: 'giftCard',
    validate,
    onSubmitFail
  } )( connect( mapStateToProps, mapDispatchToProps )( GiftCard ) );
};

GiftCard.propTypes = propTypes;

export default connectFunction( mapStateToProps, mapDispatchToProps );