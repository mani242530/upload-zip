/*
 * GiftCard Messages
 *
 * This contains all the text for the GiftCard component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {

  giftCardLabel: {
    id: 'i18n.GiftCard.giftCardLabel',
    defaultMessage: '{amount} Gift Card (****{number}) Applied!'
  },
  giftCardBal: {
    id: 'i18n.GiftCard.giftCardBal',
    defaultMessage: 'Gift Card Balance: {number}'
  },
  applyLabel: {
    id: 'i18n.GiftCard.applyLabel',
    defaultMessage: 'Apply Gift Card'
  },
  giftcardNumber: {
    id: 'i18n.GiftCard.giftcardNumber',
    defaultMessage: 'Gift Card Number'
  },
  giftcardPin: {
    id: 'i18n.GiftCard.giftcardPin',
    defaultMessage: 'PIN'
  },
  apply: {
    id: 'i18n.GiftCard.apply',
    defaultMessage: 'Applying...'
  },
  remove: {
    id: 'i18n.GiftCard.remove',
    defaultMessage: 'Remove'
  },
  removeGiftCardAriaLabel: {
    id: 'i18n.GiftCard.removeGiftCardAriaLabel',
    defaultMessage: 'Remove gift card'
  },
  giftCardRemovedAriaLabel: {
    id: 'i18n.GiftCard.giftCardRemovedAriaLabel',
    defaultMessage: 'Gift Card Removed'
  }
} );
