import React from 'react';
import ReactDOM from 'react-dom';
import GiftCard, { validate, connectFunction, mapDispatchToProps, mapStateToProps } from './GiftCard';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import messages from './GiftCard.messages';
import device from 'utils/DeviceDetection/deviceDetection';

jest.mock( 'utils/DeviceDetection/deviceDetection', () =>{
  return {
    checkIfAndroidChrome: jest.fn( () => true ),
    isServer: jest.fn( ()=> false )
  }
} );
import FormValidationMessages from 'utils/FormValidations/FormValidations.messages';

describe( '<GiftCard />', () => {
  let component;
  const broadcastMessageMock = jest.fn();
  const store = configureStore( {}, CONFIG );
  let props = {
    giftCardDetails:{},
    giftCard:{
      values:{
        giftCardNumber:3213132131,
        giftCardPin:32132
      }
    },
    cartRightPanelCollapse:{
      giftCard:true
    },
    giftCardApplying:false
  }
  let props1 = {
    isGiftCardRemoved:true,
    giftCardDetails:{
      paymentInfo:{
        paymentType:'giftCard',
        amount:25.55,
        paymentDetails:{
          giftcardBalance:350.12,
          currencyCode:'USD',
          giftcardNumber:'1234'
        }
      },
      messages:[
        {
          messageKey:'giftcardbalance',
          messageType:'Info',
          messageDesc:'Your gift card has been applied. You have $9,830.00 remaining on this card.',
          messageField:'paymentInfo.payemntDetails.amount'
        }
      ]
    },
    cartRightPanelCollapse:{
      giftCard:true
    },
    giftCardApplying:true
  }

  let component1 ;
  component = mountWithIntl(
    <Provider store={ store }>
      <GiftCard { ...props }/>
    </Provider>
  );
  const mapDispatchToPropsMock =()=>{
    return {
      broadcastMessage:broadcastMessageMock
    }
  }

  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <GiftCard { ...props }/>
      </Provider>
    );
    expect( component.find( 'GiftCard' ).length ).toBe( 1 );
  } );
  it( 'should not displays remove link', () => {
    expect( component.find( 'GiftCard' ).instance().removeGiftCardAnchor ).toBeFalsy();
    expect( component.find( '.GiftCard__Remove' ).length ).toBe( 0 );
  } );
  it( 'Mixed Menu Button component', () => {
    expect( component.find( 'MixedMenuButton' ).length ).toBe( 1 );
    expect( component.find( 'MixedMenuButton' ).props().label ).toBe( messages.applyLabel.defaultMessage );
    expect( component.find( 'MixedMenuButton' ).props().details ).toBe( '' );
  } );
  it( 'Mixed Menu Button component when gift card is applied', () => {
    component1 = mountWithIntl(
      <Provider store={ store }>
        <GiftCard { ...props1 }/>
      </Provider>
    )
    messages.giftCardLabel.defaultMessage=messages.giftCardLabel.defaultMessage.replace( '{amount}', '$'+props1.giftCardDetails.paymentInfo.amount );

    messages.giftCardLabel.defaultMessage=messages.giftCardLabel.defaultMessage.replace( '{number}', props1.giftCardDetails.paymentInfo.paymentDetails.giftcardNumber );

    messages.giftCardBal.defaultMessage=messages.giftCardBal.defaultMessage.replace( '{number}', '$'+props1.giftCardDetails.paymentInfo.paymentDetails.giftcardBalance );

    expect( component1.find( 'MixedMenuButton' ).props().label ).toBe( messages.giftCardLabel.defaultMessage );
    expect( component1.find( 'MixedMenuButton' ).props().details ).toBe( messages.giftCardBal.defaultMessage );
  } );

  it( 'renders anchor component when gift card is applied', () => {
    expect( component1.find( 'GiftCard' ).instance().removeGiftCardAnchor ).toBeTruthy();
    expect( component1.find( '.GiftCard__Remove' ).length ).toBe( 1 );
  } );

  it( 'Should have an ariaLabel corresponding to the Remove link', () => {
    expect( component1.find( '.GiftCard__Remove a' ).props()['aria-label'] ).toBe( messages.removeGiftCardAriaLabel.defaultMessage );
  } );

  it( 'renders collapse', () => {
    expect( component.find( 'Collapse' ).length ).toBe( 1 );
  } );
  it( 'renders both input components without crashing', () => {
    expect( component.find( '.GiftCard__Input' ).find( 'InputField' ).length ).toBe( 2 );
    expect( component.find( '.GiftCard__Input' ).find( 'InputField' ).at( 0 ).props().label ).toBe( messages.giftcardNumber.defaultMessage );
    expect( component1.find( '.GiftCard__Input' ).find( 'InputField' ).at( 0 ).props().value ).toBe( props1.giftCardDetails.paymentInfo.paymentDetails.giftcardNumber );
    expect( component.find( '.GiftCard__Input' ).find( 'InputField' ).at( 1 ).props().label ).toBe( messages.giftcardPin.defaultMessage );
  } );

  it( 'spinner renders without crashing', () => {
    expect( component1.find( 'SVG' ).length ).toBe( 1 );
    expect( component1.find( '.showRemoved' ).length ).toBe( 1 );
    expect( component1.find( '.hideRemoved' ).length ).toBe( 0 );
    expect( component1.find( '.applyText' ).text() ).toBe( messages.apply.defaultMessage );
  } );

  it( 'Should not render anchor component when gift error exist after clearing the error mesage', () => {
    let props2 = {
      giftCardDetails:{
        paymentInfo:{
          paymentType:'giftCard',
          amount:25.55,
          paymentDetails:{
            giftcardBalance:350.12,
            currencyCode:'USD',
            giftcardNumber:'1234'
          }
        },
        messages:[]
      },
      cartRightPanelCollapse:{
        giftCard:true
      },
      giftCardError: true,
      broadcastMessage: jest.fn()
    }
    let component2 = mountWithIntl(
      <Provider store={ store }>
        <GiftCard { ...props2 }/>
      </Provider>
    );

    expect( component2.find( '.GiftCard__Remove' ).length ).toBe( 0 );
  } );

  it( 'should invoke updatePaymentServiceResponse when validateCard is invoked', () => {
    const props2 = {
      giftCardDetails:{},
      giftCard:{
        values:{
          giftCardNumber:'4111111111111111',
          giftCardPin:32132
        },
        syncErrors: {},
        active: 'giftCardNumber'
      },
      cartRightPanelCollapse:{
        giftCard:true
      },
      giftCardApplying:false,
      updatePaymentServiceResponse: jest.fn(),
      broadcastMessage: jest.fn()
    }
    store.getState().form={
      giftCard:{
        active:'giftCardNumber',
        values:
          {
            'giftCardPin':'12312312'
          }
      }
    }

    const component2 = mountWithIntl(
      <Provider store={ store }>
        <GiftCard { ...props2 }/>
      </Provider>
    );
    const node = component2.find( 'GiftCard' ).instance();
    component2.find( 'GiftCard' ).instance().state.tempGiftCardPin = '12345678';
    node.validateCard( '4111 1111 1111 1111' );
    expect( props2.updatePaymentServiceResponse ).toBeCalled();
  } );

  it( 'should invoke updatePaymentServiceResponse for non android when validateCard is invoked', () => {
    device.checkIfAndroidChrome = jest.fn( () => false );
    const props2 = {
      giftCardDetails:{},
      giftCard:{
        values:{
          giftCardNumber:'4111111111111111',
          giftCardPin:32132
        },
        syncErrors: {},
        active: 'giftCardNumber'
      },
      cartRightPanelCollapse:{
        giftCard:true
      },
      giftCardApplying:false,
      updatePaymentServiceResponse: jest.fn()
    }
    store.getState().form={
      giftCard:{
        active:'giftCardNumber',
        values:
          {
            'giftCardPin':'12312312'
          }
      }
    }

    const component2 = mountWithIntl(
      <Provider store={ store }>
        <GiftCard { ...props2 }/>
      </Provider>
    );
    const node = component2.find( 'GiftCard' ).instance();
    component2.find( 'GiftCard' ).instance().state.tempGiftCardPin = '12345678';
    node.validateCard( '4111 1111 1111 1111' );
    expect( props2.updatePaymentServiceResponse ).toBeCalled();
  } );

  it( 'should invoke updatePaymentServiceResponse when 15 digits are entered for giftcard', () => {
    const updatePaymentServiceResponse =  jest.fn();
    const props4 = {
      updatePaymentServiceResponse : updatePaymentServiceResponse,
      giftCardDetails : {
        paymentInfo : {
          paymentDetails: {
            giftcardNumber : '1111 2222 3333 4444'
          }
        }
      },
      cartRightPanelCollapse:{},
      giftCard: {
        active : 'giftCardNumber'
      }
    }

    const component4 = mountWithIntl(
      <Provider store={ store }>
        <GiftCard { ...props4 }/>
      </Provider>
    );
    store.getState().form = {
      giftCard : {
        active:'giftCardPin'
      }
    }
    component4.find( 'GiftCard' ).instance().props.change( 'giftCardPin', '12345678' );
    component4.find( '#giftCardPin' ).simulate( 'change' );
    store.getState().form.giftCard.active ='giftCardNumber';
    component4.find( 'GiftCard' ).instance().props.change( 'giftCardNumber', '1111 2222 3333 4444' );
    component4.find( '#giftCardNumber' ).simulate( 'change' );
    expect( updatePaymentServiceResponse ).toHaveBeenCalledTimes( 1 );
    component4.find( 'GiftCard' ).instance().props.change( 'giftCardNumber', '1111222233334444' );
    component4.find( '#giftCardNumber' ).simulate( 'change' );
    expect( updatePaymentServiceResponse ).toHaveBeenCalledTimes( 2 );
    component4.find( 'GiftCard' ).instance().props.change( 'giftCardNumber', '111122223333444' );
    component4.find( '#giftCardNumber' ).simulate( 'change' );
    expect( updatePaymentServiceResponse ).toHaveBeenCalledTimes( 2 );
  } );

  it( 'should get a proper error message when less than 15 digits are entered for giftcard', () => {
    const updatePaymentServiceResponse =  jest.fn();
    const props4 = {
      updatePaymentServiceResponse : updatePaymentServiceResponse,
      giftCardDetails : {
        paymentInfo : {
          paymentDetails: {
            giftcardNumber : ''
          }
        }
      },
      cartRightPanelCollapse:{}
    }
    store.getState().form.giftCard = {
      values:{
        giftCardNumber: '',
        giftCardPin: '12345678'
      },
      active : 'giftCardNumber'
    }
    const component4 = mountWithIntl(
      <Provider store={ store }>
        <GiftCard { ...props4 }/>
      </Provider>
    );
    component4.find( 'GiftCard' ).find( 'form' ).simulate( 'blur' );
    expect( component4.find( 'ResponseMessages' ).props().message ).toBe( FormValidationMessages.validateGiftCard.defaultMessage );
  } );

  it( 'Should call broadcastMessage when a Gift Card is applied.', () => {
    const GiftCardMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    component1 = mountWithIntl(
      <Provider store={ store }>
        <GiftCardMock { ...props1 }/>
      </Provider>
    );
    const prevProps = {
      giftCardDetails:{},
      giftCard:{
        values:{
          giftCardNumber:3213132131,
          giftCardPin:32132
        }
      },
      cartRightPanelCollapse:{
        giftCard:true
      },
      giftCardApplying:false
    }
    const componentNode = component1.find( 'GiftCard' ).instance();
    const focusMock = jest.fn();
    componentNode.removeGiftCardAnchor.focus = focusMock;
    componentNode.removeGiftCardAnchor.focus = jest.fn();
    componentNode.componentDidUpdate( prevProps );
    componentNode.props.change( 'giftCardNumber', '' );
    component1.find( '#giftCardNumber' ).simulate( 'change' );
    componentNode.props.change( 'giftCardPin', '' );
    component1.find( '#giftCardPin' ).simulate( 'change' );
    expect( componentNode.removeGiftCardAnchor.focus ).toBeCalled();
    expect( broadcastMessageMock ).toHaveBeenCalledWith( '$25.55 Gift Card (****1234) Applied! Gift Card Balance: $350.12' );
    expect( componentNode.removeGiftCardAnchor.focus ).toBeCalled();
    expect( component1.find( '#giftCardNumber' ).get( 0 ).props.value ).toBe( '' );
    expect( component1.find( '#giftCardPin' ).get( 0 ).props.value ).toBe( '' );
  } );

  it( 'Should call broadcastMessage when a Gift Card is removed.', () => {
    expect( broadcastMessageMock ).toHaveBeenCalledWith( messages.giftCardRemovedAriaLabel.defaultMessage );
  } );

  it( 'Should call broadcastMessage when a Gift Card has zero balance.', () => {
    const GiftCardMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    const props5 = {
      giftCardDetails: {
        paymentInfo: {
          paymentType: 'giftCard',
          amount: 0,
          paymentDetails: {
            giftcardBalance: 0,
            currencyCode: 'USD',
            giftcardNumber: '1234'
          }
        },
        messages: [
          {
            messageKey: 'giftCardZeroBalance',
            messageType: 'Error',
            messageDesc: 'Your gift card has a zero balance',
            messageRef: 'paymentInfo.paymentDetails.giftCardNumber'
          }
        ]
      },
      cartRightPanelCollapse: {
        giftCard: false
      },
      giftCardApplying: true
    }
    const prevProps = {
      giftCardDetails: {},
      cartRightPanelCollapse: {
        giftCard: true
      },
      giftCardApplying: false
    }
    const component5 = mountWithIntl(
      <Provider store={ store }>
        <GiftCardMock { ...props5 } />
      </Provider>
    );
    component5.find( 'GiftCard' ).instance().componentDidUpdate( prevProps );
    expect( broadcastMessageMock ).toHaveBeenCalledWith( props5.giftCardDetails.messages[0].messageDesc );
  } );

  it( 'Should check the validate function', () => {
    let values = {
      giftCardNumber: ''
    }

    let errros = validate( values );
    expect( errros.giftCardNumber ).toBe( FormValidationMessages.validateGiftCard.defaultMessage );
    expect( errros.giftCardPin ).toBe( FormValidationMessages.requiredCardPin.defaultMessage );

    values = {
      giftCardNumber: '333333333',
      giftCardPin: '333'
    }

    errros = validate( values );
    expect( errros.giftCardNumber ).toBe( FormValidationMessages.validateGiftCard.defaultMessage );
    expect( errros.giftCardPin ).toBe( FormValidationMessages.validateCardPin.defaultMessage );

    values = {
      giftCardNumber: '3333 4444 5555 6666',
      giftCardPin: '12345678'
    }

    errros = validate( values );
    expect( errros.giftCardNumber ).toBeUndefined()
    expect( errros.giftCardPin ).toBeUndefined()

  } );

  it( 'should set to broadcastMessage blank function when validateCard is invoked if Giftcard pin field is active', () => {
    const props3 = {
      giftCardDetails:{},
      giftCard:{
        values:{
          giftCardNumber:'4111111111111111',
          giftCardPin:32132
        },
        syncErrors: {},
        active: 'giftCardPin'
      },
      cartRightPanelCollapse:{
        giftCard:true
      },
      giftCardApplying:false,
      updatePaymentServiceResponse: jest.fn(),
      broadcastMessage: jest.fn()
    }
    store.getState().form={
      giftCard:{
        active:'giftCardPin',
        values:
          {
            'giftCardNumber':'4111 1111 1111 1111'
          }
      }
    }

    const GiftCardMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    let component3 = mountWithIntl(
      <Provider store={ store }>
        <GiftCardMock { ...props3 }/>
      </Provider>
    );
    const node = component3.find( 'GiftCard' ).instance();
    component3.find( 'GiftCard' ).instance().state.tempGiftCardNumber = '4111 1111 1111 1111';
    node.validateCard( '12345678' );
    expect( broadcastMessageMock ).toHaveBeenCalledWith( '' );
  } );

  it( 'should set to broadcastMessage blank function when validateCard is invoked if Giftcard number field is active', () => {
    const props3 = {
      giftCardDetails:{},
      giftCard:{
        values:{
          giftCardNumber:'4111111111111111',
          giftCardPin:32132
        },
        syncErrors: {},
        active: 'giftCardNumber'
      },
      cartRightPanelCollapse:{
        giftCard:true
      },
      giftCardApplying:false,
      updatePaymentServiceResponse: jest.fn(),
      broadcastMessage: jest.fn()
    }
    store.getState().form={
      giftCard:{
        active:'giftCardNumber',
        values:
          {
            'giftCardPin':'12345678'
          }
      }
    }

    const GiftCardMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    let component3 = mountWithIntl(
      <Provider store={ store }>
        <GiftCardMock { ...props3 }/>
      </Provider>
    );
    const node = component3.find( 'GiftCard' ).instance();
    component3.find( 'GiftCard' ).instance().state.giftCardPin = '12345678';
    node.validateCard( '4111 1111 1111 1111' );
    expect( broadcastMessageMock ).toHaveBeenCalledWith( '' );
  } );
} );
