/**
 * HeaderBagSummary
 */

import React from 'react';
import PropTypes from 'prop-types';
import './HeaderBagSummary.css';
import { formatMessage } from 'shared/components/Global/Global';
import classNames from 'classnames';
import messages from './HeaderBagSummary.messages';
import ChevronDownSVG from 'shared/components/Icons/chevrondown';

const propTypes = {
  bagCount: PropTypes.number,
  chevronStatus: PropTypes.bool, // Required to match chevron position with HeaderBagSummary component toggle
  toggleChevronFunction: PropTypes.func,
  chevronDisplay: PropTypes.string,
  estimatedTotal: PropTypes.number
}

const HeaderBagSummary = ( props ) => {

  const toggleChevron = ( status ) => {
    props.toggleChevronFunction( !status );
  }



  return (
    <div className='HeaderBagSummary'>
      <div className='BagSummaryItems BagSummaryItems--bagSummaryHeader'>
        <h1>{ formatMessage( messages.bag ) }</h1>
        <div
          className={
            classNames( 'BagSummaryItems__rightSide', {
              'BagSummaryItems--bagHeaderChevronDown': props.chevronStatus,
              'BagSummaryItems--bagHeaderChevronUp': !props.chevronStatus
            } )
          }
          onClick={ ()=>toggleChevron( props.chevronStatus ) }
        >

          <div className='BagSummaryItems__estimate-label' >
            { formatMessage( messages.estimateLabel ) }
            <span> </span> { /* This span is here to provide a space between label and amount */ }
            <span className='BagSummaryItems__estimate-amount' >
              { new Intl.NumberFormat( 'en-US', {
                style: 'currency',
                currency: 'USD'
              } ).format( props.estimatedTotal ) }
            </span>

          </div>
          { ( () => {
            if( props.chevronDisplay !== 'desktop' ){

              return (
                <ChevronDownSVG />
              );
            }
          } )() }

        </div>

      </div>

    </div>
  );
}

HeaderBagSummary.propTypes = propTypes;

export default HeaderBagSummary;
