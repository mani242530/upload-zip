/*
 * HeaderBagSummary Messages
 *
 * This contains all the text for the HeaderBagSummary component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  bag: {
    id: 'i18n.HeaderBagSummary.bag',
    defaultMessage: 'Bag'
  },
  estimateLabel: {
    id: 'i18n.HeaderBagSummary.bag',
    defaultMessage: 'Est. Total:'
  },
  estimateAmount: {
    id: 'i18n.HeaderBagSummary.bag',
    defaultMessage: '$426.73'
  }
} );
