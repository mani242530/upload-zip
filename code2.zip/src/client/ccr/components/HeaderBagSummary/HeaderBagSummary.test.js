import React from 'react';
import ReactDOM from 'react-dom';
import HeaderBagSummary from './HeaderBagSummary';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './HeaderBagSummary.messages';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';

describe( '<HeaderBagSummary />', () => {
  let component;
  let props = {
    bagCount:1,
    chevronStatus:true,
    toggleChevronFunction:jest.fn(),
    chevronDisplay:'mobile',
    estimatedTotal:5
  };
  it( 'renders without crashing', () => {
    component = mountWithIntl( <HeaderBagSummary { ...props } /> );
    expect( component.find( 'HeaderBagSummary' ).length ).toBe( 1 );
  } );

  it( 'should contain bag header', () => {
    expect( component.find( 'HeaderBagSummary' ).find( '.BagSummaryItems--bagSummaryHeader' ).length ).toBe( 1 );
  } );

  it( 'should contain \'Est Total:\' ', () => {
    expect( component.find( '.BagSummaryItems__estimate-label' ).length ).toBe( 1 );
  } );

  it( 'should not contain chevron down component in desktop view', () => {
    expect( component.find( '.BagSummaryItems--bagHeaderChevronUp' ).find( 'SVG' ).length ).toBe( 0 );
  } );

  it( 'should contain chevron down component', () => {
    props.chevronDisplay='mobile';
    component = mountWithIntl( <HeaderBagSummary { ...props } /> );
    expect( component.find( '.BagSummaryItems--bagHeaderChevronDown' ).find( 'SVG' ).length ).toBe( 1 );
  } );

  it( 'should switch to chevron up when props set to false', () => {
    let props = { chevronStatus: false };
    component = mountWithIntl( <HeaderBagSummary { ...props } /> );
    expect( component.find( '.BagSummaryItems' ).find( '.BagSummaryItems--bagHeaderChevronUp' ).length ).toBe( 1 );
  } );

  it( 'should switch to chevron down when props set to true', () => {
    let props = { chevronStatus: true };
    component = mountWithIntl( <HeaderBagSummary { ...props } /> );
    expect( component.find( '.BagSummaryItems' ).find( '.BagSummaryItems--bagHeaderChevronDown' ).length ).toBe( 1 );
  } );

  it( 'should contain bag header', () => {
    let component1;
    let props1 = {
      bagCount:1,
      chevronStatus:true,
      toggleChevronFunction:jest.fn(),
      chevronDisplay:'mobile',
      estimatedTotal:5.00
    };
    component1 = mountWithIntl( <HeaderBagSummary { ...props } /> );
    messages.bag.defaultMessage=messages.bag.defaultMessage.replace( '{bagCount}', props1.bagCount );
    expect( component1.find( 'HeaderBagSummary' ).find( '.BagSummaryItems--bagSummaryHeader' ).text() ).toBe( messages.bag.defaultMessage+messages.estimateLabel.defaultMessage+'  $'+props.estimatedTotal+'.00' );
  } );

  it( 'should call the addNewCreditCard method', () => {
    component = mountWithIntl( <HeaderBagSummary { ...props } /> );
    const instance = component.find( '.HeaderBagSummary' ).instance();
    component.find( '.HeaderBagSummary' ).find( '.BagSummaryItems__rightSide .BagSummaryItems--bagHeaderChevronDown' ).simulate( 'click', instance.toggleChevron );
    expect( props.toggleChevronFunction ).toHaveBeenCalledWith( !props.chevronStatus );
  } );

} );
