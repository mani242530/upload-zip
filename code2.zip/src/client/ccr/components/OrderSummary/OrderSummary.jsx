/**
 * OrderSummary
 */

import React, { Component } from 'react';
import { formatMessage } from 'shared/components/Global/Global';
import { connect } from 'react-redux';
import OrderSummaryItem from 'ccr/components/OrderSummaryItem/OrderSummaryItem';


/**
 * Class
 * @extends React.Component
 */
export class OrderSummary extends Component{

  /**
   * Renders the OrderSummary component
   */
  render(){

    return (
      <div className='OrderSummary'>
        <OrderSummaryItem />
      </div>
    );
  }
}


export default OrderSummary;
