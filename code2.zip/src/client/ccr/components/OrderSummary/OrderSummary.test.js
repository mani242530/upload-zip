import React from 'react';
import ReactDOM from 'react-dom';
import OrderSummary from './OrderSummary';
import { Provider } from 'react-redux';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
let store = configureStore( {}, CONFIG );
describe( '<OrderSummary />', () => {
  it( 'renders without crashing', () => {
    const component  = mountWithIntl(
      <Provider store={ store }>
        <OrderSummary />
      </Provider>
    );

  } );
} );
