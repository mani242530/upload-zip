/**
 * OrderSummaryItem
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './OrderSummaryItem.css';
import OrderSummary, { orderSummaryItemsData } from 'ccr/components/OrderSummary/OrderSummary';
import QuestionMark from 'shared/components/Icons/questionmark.js';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './OrderSummaryItem.messages';
import Divider from 'shared/components/Divider/Divider';
import { has, isUndefined } from 'lodash';


const propTypes = {
  itemCount: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ).isRequired,
  giftBoxPrice: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  giftCard: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  couponDiscountPrice: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  promotionalDiscountPrice: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  rewardPointsDiscount: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  shippingCost: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  estimatedTax: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  estimatedTotal: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  subTotalPrice: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  totalDiscount: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  showBagSummary: PropTypes.bool,
  displayProductInfo: PropTypes.bool,
  orderId: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] )
}
const defaultProps = {
  displayEstimatedTotal:true
}
/**
 * Class
 * @extends React.Component
 */
class OrderSummaryItem extends Component{

  /**
   * Renders the OrderSummaryItem component
   */
  render(){


    return (
      <div className='OrderSummaryItem'>
        { ( () => {
          if( ! this.props.showBagSummary ){
            return (
              <div>
                { ( () => {
                  /* The following if is added for a11y compliance. Cart <h1,h2 tags
                   *  out of order on cart page
                   */
                  if( this.props.displayEstimatedTotal ){
                    return (
                      <h2>{ formatMessage( messages.orderSummary ) }</h2>
                    )
                  }
                  else {
                    return (
                      <h3>{ formatMessage( messages.orderSummary ) }</h3>
                    )
                  }
                } )() }
                <Divider
                  dividerType='gray'
                />
              </div>
            )
          }
        } )() }
        <div className='OrderSummary__container'>

          { ( () => {
            if( this.props.itemCount !== null || this.props.estimatedTotal !== null ){
              return (
                <div className='OrderSummaryRow'>
                  <div className='OrderSummaryRow__label'>
                    { formatMessage( messages.items ) }
                  </div>
                  <div className='OrderSummaryRow__value'>
                    { new Intl.NumberFormat( 'en-US', {
                      style: 'currency',
                      currency: 'USD'
                    } ).format( this.props.subTotalPrice ) }
                  </div>
                </div>
              )
            }
          } )() }

          { ( () => {
            if( this.props.giftBoxPrice !== null ){
              if( this.props.giftBoxPrice !== 0 ){
                return (
                  <div className='OrderSummaryRow'>
                    <div className='OrderSummaryRow__label'>
                      { formatMessage( messages.giftBox ) }
                    </div>
                    <div className='OrderSummaryRow__value'>
                      { new Intl.NumberFormat( 'en-US', {
                        style: 'currency',
                        currency: 'USD'
                      } ).format( this.props.giftBoxPrice ) }
                    </div>
                  </div>
                )
              }
            }
          } )() }

          { ( () => {
            if( this.props.couponDiscountPrice !== null ){
              if( this.props.couponDiscountPrice !== 0 ){
                return (
                  <div className='OrderSummaryRow'>
                    <div className='OrderSummaryRow--discount'>
                      <div className='OrderSummaryRow__label'>
                        { formatMessage( messages.couponDiscount ) }
                      </div>
                      <div className='OrderSummaryRow__value'>
                        { new Intl.NumberFormat( 'en-US', {
                          style: 'currency',
                          currency: 'USD'
                        } ).format( this.props.couponDiscountPrice ) }
                      </div>
                    </div>
                  </div>
                )
              }
            }
          } )() }

          { ( () => {
            if( !isUndefined( this.props.rewardPointsDiscount ) && this.props.rewardPointsDiscount !== null ){
              return (
                <div className='OrderSummaryRow'>
                  <div className='OrderSummaryRow--discount'>
                    <div className='OrderSummaryRow__label'>
                      { formatMessage( messages.rewardPointsDiscount ) }
                    </div>
                    <div className='OrderSummaryRow__value'>
                      <spam>{ formatMessage( messages.minus ) }</spam>
                      { new Intl.NumberFormat( 'en-US', {
                        style: 'currency',
                        currency: 'USD'
                      } ).format( this.props.rewardPointsDiscount ) }
                    </div>
                  </div>
                </div>
              )
            }
          } )() }

          { ( () => {
            if( !isUndefined( this.props.giftCard ) && this.props.giftCard !== null ){
              return (
                <div className='OrderSummaryRow'>
                  <div className='OrderSummaryRow--discount'>
                    <div className='OrderSummaryRow__label'>
                      { formatMessage( messages.giftCard ) }
                    </div>
                    <div className='OrderSummaryRow__value'>
                      <spam>{ formatMessage( messages.minus ) }</spam>
                      { new Intl.NumberFormat( 'en-US', {
                        style: 'currency',
                        currency: 'USD'
                      } ).format( this.props.giftCard ) }
                    </div>
                  </div>
                </div>
              )
            }
          } )() }

          { ( () => {
            if( this.props.promotionalDiscountPrice !== null ){
              return (
                <div className='OrderSummaryRow'>
                  <div className='OrderSummaryRow--discount'>
                    <div className='OrderSummaryRow__label'>
                      { formatMessage( messages.promotionalDiscount ) }
                    </div>
                    <div className='OrderSummaryRow__value'>
                      { new Intl.NumberFormat( 'en-US', {
                        style: 'currency',
                        currency: 'USD'
                      } ).format( this.props.promotionalDiscountPrice ) }
                    </div>
                  </div>
                </div>
              )
            }
          } )() }

          { ( () => {
            if( this.props.shippingCost !== null ){
              return (
                <div className='OrderSummaryRow'>
                  <div className='OrderSummaryRow__label'>
                    { formatMessage( messages.shipping ) }
                  </div>
                  <div className='OrderSummaryRow__value'>
                    { ( () => {
                      if( this.props.shippingCost === 'FREE' || this.props.shippingCost === 'TBD' ){
                        return (
                          this.props.shippingCost
                        );
                      }
                      else if( this.props.shippingCost !== null ){
                        return (
                          new Intl.NumberFormat( 'en-US', {
                            style: 'currency',
                            currency: 'USD'
                          } ).format( this.props.shippingCost )
                        );
                      }
                    } )() }
                  </div>
                </div>
              )
            }
          } )() }

          { ( () => {
            if( this.props.estimatedTax !== null ){
              return (
                <div className='OrderSummaryRow'>
                  <div className='OrderSummaryRow__label'>
                    { formatMessage( messages.tax ) } <span className='sr-only'>{ formatMessage( messages.taxMessage ) }</span>
                    <QuestionMark description={ formatMessage( messages.taxMessage ) }/>
                    <div className='OrderSummary__hide' role='tooltip'>
                      { formatMessage( messages.taxMessage ) }
                    </div>
                  </div>
                  <div className='OrderSummaryRow__value'>
                    { ( () => {
                      if( this.props.estimatedTax === 'TBD' ){
                        return (
                          this.props.estimatedTax
                        );
                      }
                      else {
                        let estimatedTax = parseFloat( this.props.estimatedTax );
                        return (
                          new Intl.NumberFormat( 'en-US', {
                            style: 'currency',
                            currency: 'USD'
                          } ).format( estimatedTax )
                        );
                      }
                    } )() }
                  </div>
                </div>
              )
            }
          } )() }

          { ( () => {
            if( this.props.estimatedTotal !== null ){
              return (
                <div className='OrderSummaryRow'>
                  <div className='OrderSummaryRow--bold'>
                    <div className='OrderSummaryRow__label'>
                      { formatMessage( this.props.displayEstimatedTotal? messages.estimatedTotal: messages.total ) }
                    </div>
                    <div className='OrderSummaryRow__value'>
                      { new Intl.NumberFormat( 'en-US', {
                        style: 'currency',
                        currency: 'USD'
                      } ).format( this.props.estimatedTotal ) }
                    </div>
                  </div>
                </div>
              )
            }
          } )() }


          { ( () => {
            if( this.props.displayProductInfo ){
              /*
                Global Shipping - Implmentation of divs to be consumed by BorderFree.
                The following divs should be hidden always.
                BorderFree will process divs starting with 'bfx-' and these should not be visible.
              */
              let classNameBfxOrderSummaryItem = 'orderDetails hidden bfx-order OrderSummaryItem__hideDiv';
              return (
                <div className={ classNameBfxOrderSummaryItem }>
                  <span className='bfx-order-id'>{ this.props.orderId }</span>
                  <span className='bfx-shipping-charge'>{ this.props.shippingCost }</span>
                </div>
              );
            }
          } )() }
        </div>
        <Divider
          dividerType='gray'
        />
      </div>
    );
  }
}

OrderSummaryItem.propTypes = propTypes;

export default OrderSummaryItem;
