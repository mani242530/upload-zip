/*
 * OrderSummaryItem Messages
 *
 * This contains all the text for the OrderSummaryItem component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  orderSummary: {
    id: 'i18n.OrderSummaryItem.orderSummary',
    defaultMessage: 'Order Summary'
  },
  items: {
    id: 'i18n.OrderSummaryItem.items',
    defaultMessage: 'Items'
  },
  giftBox: {
    id: 'i18n.OrderSummaryItem.giftBox',
    defaultMessage: 'Gift Box'
  },
  couponDiscount: {
    id: 'i18n.OrderSummaryItem.couponDiscount',
    defaultMessage: 'Coupon Discount'
  },
  promotionalDiscount: {
    id: 'i18n.OrderSummaryItem.promotionalDiscount',
    defaultMessage: 'Promotional Discount'
  },
  rewardPointsDiscount: {
    id: 'i18n.OrderSummaryItem.rewardPointsDiscount',
    defaultMessage: 'Reward Points Applied'
  },
  shipping: {
    id: 'i18n.OrderSummaryItem.shipping',
    defaultMessage: 'Shipping & Handling'
  },
  minus: {
    id: 'i18n.OrderSummaryItem.minus',
    defaultMessage: '-'
  },
  estimatedTotal: {
    id: 'i18n.OrderSummaryItem.estimatedTotal',
    defaultMessage: 'Estimated Total'
  },
  total: {
    id: 'i18n.OrderSummaryItem.total',
    defaultMessage: 'Total'
  },
  taxMessage: {
    id: 'i18n.OrderSummaryItem.taxMessage',
    defaultMessage: 'Actual sales tax will be calculated based upon your shipping address.'
  },
  saved: {
    id: 'i18n.OrderSummaryItem.saved',
    defaultMessage: 'You Saved'
  },
  giftCard: {
    id: 'i18n.OrderSummaryItem.giftCard',
    defaultMessage: 'Gift Card'
  },
  tax: {
    id:'i18n.OrderSummaryItem.tax',
    defaultMessage: 'Tax'
  }
} );


