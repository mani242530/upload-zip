import React from 'react';
import ReactDOM from 'react-dom';
import OrderSummaryItem from './OrderSummaryItem';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './OrderSummaryItem.messages';
import { IntlProvider } from 'react-intl';

describe( '<OrderSummaryItem />', () => {
  let component;
  let props = {
    shippingCost: 0,
    subTotalPrice: 6,
    itemCount: '6',
    giftBoxPrice: 6,
    promotionalDiscountPrice: 12,
    couponDiscountPrice: 6,
    estimatedTax: 12.22,
    estimatedTotal: 6,
    showBagSummary: false

  }
  component = mountWithIntl( <OrderSummaryItem { ...props } /> );
  it( 'renders without crashing', () => {

    expect( component.find( 'OrderSummaryItem' ).length ).toBe( 1 );
  } );

  it( 'Should contain Order Summary Container', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummary__container' ).length ).toBe( 1 );
  } );

  it( 'Should contain 7 OrderSummaryRow ', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow' ).length ).toBe( 7 );
  } );

  it( 'Should contain two Divider components', () => {
    expect( component.find( 'OrderSummaryItem Divider' ).length ).toBe( 2 );
  } );

} );

describe( 'OrderSummaryItem Labels Container', () => {
  let component;
  let props = {
    shippingCost: 0,
    subTotalPrice: 6,
    itemCount: '6',
    giftBoxPrice: 6,
    rewardPointsDiscount: 0,
    promotionalDiscountPrice: 12,
    couponDiscountPrice: 6,
    estimatedTax: 12.22,
    estimatedTotal: 6,
    showBagSummary: false

  }
  component = mountWithIntl( <OrderSummaryItem { ...props } /> );

  it( 'Should always contain one row with an ItemCount label', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow .OrderSummaryRow__label' ).at( 0 ).text() ).toBe( messages.items.defaultMessage.replace( '{itemCount}', props.itemCount ) );
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow .OrderSummaryRow__value' ).at( 0 ).text() ).toBe( '$'+props.subTotalPrice+'.00' );
  } );

  it( 'Should contain GiftBox row if giftbox is applied', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__label' ).at( 1 ).text() ).toBe( messages.giftBox.defaultMessage );
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__value' ).at( 1 ).text() ).toBe( '$'+props.giftBoxPrice+'.00' );
  } );

  it( 'Should contain Coupon row if coupon is applied', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__label' ).at( 2 ).text() ).toBe( messages.couponDiscount.defaultMessage );
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__value' ).at( 2 ).text() ).toBe( '$'+props.couponDiscountPrice+'.00' );
  } );
  it( 'Should contain Reward points Discount row if rewards points are applied', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__label' ).at( 3 ).text() ).toBe( messages.rewardPointsDiscount.defaultMessage );
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__value' ).at( 3 ).text() ).toBe( '-$'+props.rewardPointsDiscount+'.00' );
  } );
  it( 'Should contain Promotional Discount row if a promotional discount was applied', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__label' ).at( 4 ).text() ).toBe( messages.promotionalDiscount.defaultMessage );
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__value' ).at( 4 ).text() ).toBe( '$'+props.promotionalDiscountPrice+'.00' );
  } );
  it( 'Should always contain Shipping row', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__label' ).at( 5 ).text() ).toBe( messages.shipping.defaultMessage );
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__value' ).at( 5 ).text() ).toBe( '$'+props.shippingCost+'.00' );
  } );

  it( 'Should contain Estimated label as Tax in the Order Summary labels container when it is rendered from checkout', () => {
    let message = component.find( 'OrderSummaryItem .OrderSummaryRow__label' ).at( 6 ).text();
    expect( message.slice( 0, 3 ) ).toBe( messages.tax.defaultMessage );
  } );

  it( 'Should contain an screen reader only span with tax message', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__label' ).at( 6 ).find( 'span' ).props().className ).toBe( 'sr-only' );
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__label' ).at( 6 ).find( 'span' ).props().children ).toBe( messages.taxMessage.defaultMessage );

  } );
  it( 'Should have aria role tooltip for the tax message', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__label .OrderSummary__hide' ).props().role ).toBe( 'tooltip' );
  } );

  it( 'Should contain an Estimate Total row', () => {
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__label' ).at( 7 ).text() ).toBe( messages.total.defaultMessage );
    expect( component.find( 'OrderSummaryItem .OrderSummaryRow__value' ).at( 7 ).text() ).toBe( '$'+props.estimatedTotal+'.00' );
  } );

} );