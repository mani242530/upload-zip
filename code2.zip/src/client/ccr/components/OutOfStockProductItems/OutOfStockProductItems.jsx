/**
 * OutOfStockProductItems
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './OutOfStockProductItems.css';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './OutOfStockProductItems.messages';
import Image from 'shared/components/Image/Image';
import RemovedItemsList from 'ccr/components/RemovedItemsList/RemovedItemsList';
import classNames from 'classnames';
import Closesvg from 'shared/components/Icons/closecircle';
import Divider from 'shared/components/Divider/Divider';
import isEmpty from 'lodash/isEmpty';
import has from 'lodash/has';
import find from 'lodash/find';
import concat from 'lodash/concat';

const propTypes = {
  messagesData:PropTypes.array,
  removedItems:PropTypes.array,
  updatedItems:PropTypes.array,
  showHeaderMessage: PropTypes.bool,
  handleOutOfStock: PropTypes.func,
  showPanel: PropTypes.bool
}

const defaultProps = {
  showHeaderMessage: true
};


/**
 * Class
 * @extends React.Component
 */
class OutOfStockProductItems extends Component{

  constructor( props ){
    super( props );
    this.closeOutOfStockSection = this.closeOutOfStockSection.bind( this );

  }
  closeOutOfStockSection(){
    this.props.handleOutOfStock( this );

  }


  /**
   * Renders the OutOfStockProductItems component
   */
  render(){



    return (
      <div
        className={
          classNames(
            'OutOfStockProductItems', {
              'OutOfStockProductItemsVisibiliy': this.props.showPanel
            } )
        }
        role='alert'
      >
        <div className='OutOfStockProductItems__Background'>
          <div className='OutOfStockProductItems__Header'>
            <div className='OutOfStockProductItems__Title'>
              { ( () => {
                if( this.props.showHeaderMessage ){
                  return (
                    <div className='OutOfStockProductItems__Title--header'>
                      { formatMessage( messages.header ) }
                    </div>
                  );
                }
              } )() }
            </div>
            <div
              className='OutOfStockProductItems__CloseButton OutOfStockProductItems__CloseButton--Button'
              onClick={ this.closeOutOfStockSection }
            >
              <Closesvg />
            </div>
          </div>
          { ( ()=>{
            return (
              <div className='OutOfStockProductItems__Messages'>
                {
                  this.props.messagesData && this.props.messagesData.map( ( messages, index ) => {
                    return (
                      <div
                        key={ index }
                        className='OutOfStockProductItems__headerText'
                      >
                        <div className='OutOfStockProductItems__Title__MergeCart'>
                          { messages.message }
                        </div>
                        {
                          ( messages.length > 1 ||
                          ( this.props.removedItems || this.props.updatedItems ) ) &&
                          <Divider dividerType={ 'gray' }></Divider>
                        }
                      </div>
                    )
                  } )
                }
                { ( ()=>{
                  if( this.props.updatedItems ){
                    return (
                      this.props.updatedItems.map( ( updatedItem, index ) => {

                        return (
                          <div
                            className='OutOfStockProductItems__headerText'
                          >
                            <div className='OutOfStockProductItems__Title__text'>
                              { updatedItem.quantity.messages.items[0].message }
                            </div>

                            <RemovedItemsList
                              removedList={ [updatedItem] }
                            />
                          </div>
                        )
                      } ) )
                  }
                } )() }

                { ( ()=>{
                  if( this.props.removedItems ){
                    return (

                      <div
                        className='OutOfStockProductItems__headerText'
                      >
                        <div className='OutOfStockProductItems__Title__text'>
                          { formatMessage( messages.headerTitle ) }
                        </div>

                        <RemovedItemsList
                          removedList={ this.props.removedItems }
                        />
                      </div>
                    )
                  }
                } )() }
              </div>
            );
          } )() }
        </div>
      </div>
    );
  }
}

OutOfStockProductItems.propTypes = propTypes;
OutOfStockProductItems.defaultProps = defaultProps;

export default OutOfStockProductItems;
