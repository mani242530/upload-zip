/*
 * OutOfStockProductItems Messages
 *
 * This contains all the text for the OutOfStockProductItems component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  headerTitle: {
    id: 'i18n.OutOfStockProductItems.headerTitle',
    defaultMessage: 'Below Item(s) were removed.'
  },
  header: {
    id: 'i18n.OutOfStockProductItems.header',
    defaultMessage: 'BAG UPDATES'
  }
} );
