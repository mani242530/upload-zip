import React from 'react';
import ReactDOM from 'react-dom';
import OutOfStockProductItems from './OutOfStockProductItems';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './OutOfStockProductItems.messages';

const data = {
  'messages': {
    'items': [
      {
        'type': 'Info',
        'message': 'Looks like you have items in your bag from before. They\'ve been added below.'
      }
    ]
  },
  'removedItems':[
    {
      'couponApplied': false,
      'brandName': 'OPI',
      'quantity': null,
      'productId': 'xlsImpprod5180311',
      'excludedFromCoupon': false,
      'adbugMessageMap': null,
      'catalogRefId': '2056976',
      'categoryName': null,
      'commerceItemid': null,
      'priceInfo': {
        'salePrice': null,
        'regularPrice': '$10',
        'unitPriceMessage': null,
        'bfxPriceMap': null
      },
      'productDisplayName': 'Soft Shades Nail Lacquer Collection',
      'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
      'variantInfo': {
        'Color': 'Bubble Bath'
      },
      'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
      'shippingRestriction': null,
      'maxQty': null,
      'productURL': null,
      'messages': {
        'items': [
          {
            'type': 'Info',
            'message': 'Selected items is out of stock'
          }
        ]
      }
    }
  ],
  'updatedItems':[
    {
      'couponApplied': false,
      'brandName': 'OPI',
      'quantity': {
        'messages': {
          'items': [
            {
              'type': 'Info',
              'message': 'Selected items is out of stock'
            }
          ]
        }
      },
      'productId': 'xlsImpprod5180311',
      'excludedFromCoupon': false,
      'adbugMessageMap': null,
      'catalogRefId': '2056976',
      'categoryName': null,
      'commerceItemid': null,
      'priceInfo': {
        'salePrice': null,
        'regularPrice': '$10',
        'unitPriceMessage': null,
        'bfxPriceMap': null
      },
      'productDisplayName': 'Soft Shades Nail Lacquer Collection',
      'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
      'variantInfo': {
        'Color': 'Bubble Bath'
      },
      'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
      'shippingRestriction': null,
      'maxQty': null,
      'productURL': null
    }
  ],
  'showShippingRestrictionMsg': true
};

describe( '<OutOfStockProductItems />', () => {
  let component;
  let props;
  component = mountWithIntl(
    <OutOfStockProductItems
      messagesData={ data.messages.items }
      removedItems={ data.removedItems }
    /> );
  it( 'renders without crashing', () => {
    expect( component.find( 'OutOfStockProductItems' ).length ).toBe( 1 );
  } );

  it( 'doesnot render the header title if the showHeaderMessage prop is set to false', () => {
    let component1 = mountWithIntl(
      <OutOfStockProductItems
        messagesData={ data.messages.items }
        showHeaderMessage={ false }
      />
    );
    expect( component1.find( '.OutOfStockProductItems__Title--header' ).length ).toBe( 0 );
  } );

  it( 'it renders the header title if the showHeaderMessage prop is set to true', () => {
    let component2 = mountWithIntl(
      <OutOfStockProductItems
        messagesData={ data.messages.items }
        removedItems={ data.removedItems }
        showHeaderMessage={ true }
      />
    );
    expect( component2.find( '.OutOfStockProductItems__Title--header' ).length ).toBe( 1 );
  } );

  it( 'Displays header title message', () => {
    expect( component.find( '.OutOfStockProductItems__Title--header' ).text() ).toBe( messages.header.defaultMessage );
  } );

  it( 'Displays header message', () => {
    expect( component.find( '.OutOfStockProductItems__Title__text' ).at( 0 ).text() ).toBe( messages.headerTitle.defaultMessage );
  } );

  it( 'Displays header messages for the removed items', () => {
    expect( component.find( '.OutOfStockProductItems__Title__text' ).length ).toBe( 1 );
  } );

  it( 'Renders close button', () => {
    expect( component.find( '.OutOfStockProductItems__Background .OutOfStockProductItems__Header .OutOfStockProductItems__CloseButton' ).length ).toBe( 1 );
  } );

  it( 'make sure that the div is visible', () =>{
    expect( component.find( '.OutOfStockProductItemsVisibiliy' ).length ).toBe( 0 );
  } );

  it( 'make sure that the div has a role alert associated with it', () =>{
    expect( component.find( '.OutOfStockProductItems' ).props().role ).toBe( 'alert' );
  } );

  it( 'Hides the div when clicked on the close button', () => {
    let props={
      showPanel:true,
      handleOutOfStock: jest.fn()
    };
    component = mountWithIntl(
      <OutOfStockProductItems
        messagesData={ data.messages.items }
        removedItems={ data.removedItems }
        { ...props }
      /> );
    component.find( '.OutOfStockProductItems__Background .OutOfStockProductItems__Header .OutOfStockProductItems__CloseButton' ).simulate( 'click' );
    expect( component.find( '.OutOfStockProductItemsVisibiliy' ).length ).toBe( 1 );
  } );
  describe( 'OutOfStockProductItems When there is an updated item in the cart', () => {
    let component3 = mountWithIntl(
      <OutOfStockProductItems
        messagesData={ data.messages.items }
        updatedItems={ data.updatedItems }
      /> );

    it( 'renders without crashing', () => {
      expect( component3.find( 'OutOfStockProductItems' ).length ).toBe( 1 );
    } );

    it( 'Displays header title message', () => {
      expect( component3.find( '.OutOfStockProductItems__Title--header' ).length ).toBe( 1 );
    } );

    it( 'Displays header message', () => {
      expect( component3.find( '.OutOfStockProductItems__Title__text' ).at( 0 ).text() ).toBe( data.updatedItems[0].quantity.messages.items[0].message );
    } );

    it( 'Displays header messages for the removed items', () => {
      expect( component3.find( '.OutOfStockProductItems__Title__text' ).length ).toBe( 1 );
    } );

    it( 'Renders close button', () => {
      expect( component3.find( '.OutOfStockProductItems__Background .OutOfStockProductItems__Header .OutOfStockProductItems__CloseButton' ).length ).toBe( 1 );
    } );

  } );

} );
