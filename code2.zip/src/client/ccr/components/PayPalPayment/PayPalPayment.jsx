/**
 * PayPalPayment
 */

import React, { Component } from 'react';
import './PayPalPayment.css';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './PayPalPayment.messages';


const PayPalPayment = ( props ) => {

  return (
    <div className='PayPalPayment'>
      <span>{ formatMessage( messages.header ) }</span>
    </div>
  );
}

export default PayPalPayment;
