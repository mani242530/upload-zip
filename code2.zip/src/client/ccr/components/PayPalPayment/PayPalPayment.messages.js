/*
 * PayPalPayment Messages
 *
 * This contains all the text for the PayPalPayment component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.PayPalPayment.header',
    defaultMessage: 'This is the PayPalPayment component !'
  }
} );
