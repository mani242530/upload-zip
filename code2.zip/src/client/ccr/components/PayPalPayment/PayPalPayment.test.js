import React from 'react';
import ReactDOM from 'react-dom';
import PayPalPayment from './PayPalPayment';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';

describe( '<PayPalPayment />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <PayPalPayment /> );
    expect( component.find( 'PayPalPayment' ).length ).toBe( 1 );
  } );
} );
