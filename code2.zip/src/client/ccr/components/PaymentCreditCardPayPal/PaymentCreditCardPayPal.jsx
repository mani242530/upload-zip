/**
 * PaymentCreditCardPayPal
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import './PaymentCreditCardPayPal.css';
import classNames from 'classnames';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './PaymentCreditCardPayPal.messages';
import Button from 'shared/components/Button/Button';
import PayPalSVG from 'shared/components/Icons/paypal';
import { Collapse } from 'react-bootstrap';
import PaymentForm from 'ccr/components/PaymentForm/PaymentForm';
import UltamateRewardsCreditCard from 'ccr/components/UltamateRewardsCreditCard/UltamateRewardsCreditCard';
import PaypalCheckoutButton from 'ccr/components/PaypalCheckoutButton/PaypalCheckoutButton';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';
import isUndefined from 'lodash/isUndefined';
import isEmpty from 'lodash/isEmpty';
import isEqual from 'lodash/isEqual';
import has from 'lodash/has';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import { fireAnalyticsEvent } from 'utils/Omniture/Omniture';
import {
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import 'shared/components/Gutter/Gutter.css';
import PropTypes from 'prop-types';
/**
 * Class
 * @extends React.Component
 */
const propTypes={
  isAddressInFocus: PropTypes.bool,
  paymentError: PropTypes.array || PropTypes.bool,
  enterUnitNumber: PropTypes.bool,
  cardInfoOpen: PropTypes.bool,
  addEditCreditCard: PropTypes.oneOf( ['yes', 'no', ''] ),
  handleCancelAddCreditCard: PropTypes.func,
  handleAddNewCreditCard: PropTypes.func,
  setCCPaymentFormSubmit: PropTypes.func,
  checkoutFormAddress2Open: PropTypes.object,
  toggleInputFieldPaymentDisplay: PropTypes.func,
  setTempPaymentCCVNumber: PropTypes.func,
  setCreditCardPaymentType: PropTypes.func,
  isSignedIn: PropTypes.bool,
  isAddCreditCard: PropTypes.bool,
  editCreditCardData: PropTypes.object,
  setEditCreditCardData: PropTypes.func,
  setEditAddressData: PropTypes.func,
  submitShippingAddressForm: PropTypes.func,
  handleScrollView: PropTypes.func,
  updatePaymentStatus: PropTypes.func,
  paymentValid: PropTypes.bool,
  updatePaymentServiceResponse: PropTypes.func,
  editCCData: PropTypes.object,
  isSetCCPaymentFormSubmit: PropTypes.bool,
  creditCardDetails: PropTypes.object,
  previousPaymentType: PropTypes.string,
  toggleSecurityCode: PropTypes.func,
  displayType: PropTypes.string,
  fieldShowHideToggleData: PropTypes.object,
  addDoneButton: PropTypes.bool,
  showSecurityIcon: PropTypes.bool,
  showCVV: PropTypes.bool,
  checkoutFormConfig: PropTypes.object,
  shippingInfo: PropTypes.object,
  isSameAsShipping: PropTypes.bool,
  enableExpressPaypalCheckout: PropTypes.bool,
  paypalEnvironment: PropTypes.string,
  handleScrollToFormError: PropTypes.func,
  editAddressData: PropTypes.object,
  toggleAddressFieldDisplayPaymentForm: PropTypes.func,
  getPaypalToken: PropTypes.func,
  getPaypalResponse: PropTypes.func,
  applyPayment: PropTypes.func,
  cartSummary: PropTypes.object,
  handleAddCreditCard: PropTypes.func,
  ultamateRewardsCCInfo: PropTypes.object,
  paymentType: PropTypes.string,
  setPaymentType: PropTypes.func,
  payPalClientToken: PropTypes.string
}
class PaymentCreditCardPayPal extends Component{

  /**
   * Create a PaymentCreditCardPayPal
   */
  constructor( props ){
    super( props );
    this.state = {
      showPaypalButton: false
    }
    this.toggleTab = this.toggleTab.bind( this );// to switch between creditcards and paypal tab.
    this.ChangePaypalAccount = this.ChangePaypalAccount.bind( this );
    this.onSuccessPaypalPayment = this.onSuccessPaypalPayment.bind( this );
  }

  toggleTab( tabName ){
    if( this.props.paymentType !== tabName ){
      this.props.setPaymentType( tabName );
    }
  }

  ChangePaypalAccount( e ){
    e.preventDefault();
    this.setState( {
      showPaypalButton: true
    } );
  }

  onSuccessPaypalPayment(){
    this.setState( {
      showPaypalButton: false
    } );
  }

  componentDidUpdate( prevProps ){
    // Focus to error panel generated for creditCardDetails messages (props.creditCardDetails.messages)
    if( !isEmpty( this.props.creditCardDetails.messages ) &&
      isEmpty( this.props.paymentError ) &&
      !isEqual( prevProps.creditCardDetails.messages, this.props.creditCardDetails.messages )
    ){
      this.errorPanelCreditCardDetailsMessage.focus();
    }
    // Focus to error panel generated for paymentError props (props.paymentError)
    if( !isEmpty( this.props.paymentError ) && !isEqual( prevProps.paymentError, this.props.paymentError ) ){
      this.errorPanelPaymentErrorMessage.focus();
    }
  }

  /**
   * Renders the PaymentCreditCardPayPal component
   */
  render(){

    const {
      creditCardDetails
    } = this.props;
    const {
      addEditCreditCard
    } = this.props;

    return (
      <div className='PaymentCreditCardPayPal'>

        { ( () =>{
          if( !this.props.isSignedIn || ( isUndefined( this.props.editCreditCardData.contactInfo ) && isUndefined( addEditCreditCard ) || addEditCreditCard !== 'yes' ) ){
            return (
              <div
                className='PaymentForm__ButtonContainer Gutter'
                role='tablist'
                aria-orientation='horizontal'
              >
                <div className='PaymentForm__creditButton'>
                  <Button
                    clickEventHandler={ () => this.toggleTab( 'creditCard' ) }
                    inputTag='button'
                    btnType='button'
                    btnOption='single'
                    btnBlock={ true }
                    btnOutLine={ this.props.paymentType !== 'creditCard' }
                    role='tab'
                    ariaSelected={ `${this.props.paymentType === 'creditCard'}` }
                    id='creditcardsTab'
                    ariaControls='creditcardsContentPanel'
                  >
                    { formatMessage( messages.creditCard ) }
                  </Button>
                </div>
                <div className='PaymentForm__paypalButton'>
                  <Button
                    clickEventHandler={ () => this.toggleTab( 'paypal' ) }
                    inputTag='button'
                    btnType='button'
                    btnOption='single'
                    btnOutLine={ this.props.paymentType !== 'paypal' }
                    btnBlock={ true }
                    role='tab'
                    ariaSelected={ `${this.props.paymentType === 'paypal'}` }
                    id='paypalTab'
                    ariaControls='paypalContentPanel'
                  >
                    { formatMessage( messages.paypal ) }
                  </Button>


                  { /*
                    TODO need if have to switch back to show paypal button as tab commit #
                    3330c7413c8
                  */ }
                </div>
              </div>
            );
          }
        } )() }

        { ( () =>{
          if( this.props.paymentType === 'creditCard' && ( isUndefined( addEditCreditCard ) || addEditCreditCard !== 'yes' ) ){
            return (
              <UltamateRewardsCreditCard
                handleAddCreditCard={ this.props.handleAddCreditCard }
                isSignedIn={ this.props.isSignedIn }
                ultamateRewardsCCInfo={ this.props.ultamateRewardsCCInfo }
              />
            );
          }
        } )() }
        <div
          className={
            classNames( {
              'PaymentCreditCardPayPal__hide': has( this.props, 'creditCardDetails.paymentInfo.paymentType' ) && this.props.paymentType !== creditCardDetails.paymentInfo.paymentType,
              'PaymentPayPal__update': this.props.paymentType === 'paypal'
            } )
          }
        >
          { ( () =>{
            if( has( creditCardDetails, 'messages' ) && !isEmpty( creditCardDetails.messages ) ){
              if( has( creditCardDetails, 'messages' ) && isEmpty( this.props.paymentError ) ){
                return (
                  <div
                    className='PaymentInformation__errorMessagesPanel'
                    tabIndex='-1'
                    ref={ ( el )=>{
                      this.errorPanelCreditCardDetailsMessage=el
                    } }
                  >
                    { ( () =>{
                      return creditCardDetails.messages.map( ( message, index1 ) =>{
                        return (
                          <ResponseMessages
                            messageType={ message.messageType }
                            message={ message.messageDesc }
                            key={ index1 }
                            broadCastAdaMessage={ true }
                          />
                        );
                      } );
                    } )() }

                  </div>
                )
              }
            }

            if( !isEmpty( this.props.paymentError ) ){
              let analyticsEvent =
                {
                  eventName: 'trackErrorDisplayed',
                  data: {
                    'errorType': 'form',
                    'errorLabel': 'payment',
                    'errorDescription': this.props.paymentError
                  }
                };

              fireAnalyticsEvent( analyticsEvent.name, analyticsEvent.data );

              return (
                <div
                  className='PaymentInformation__errorMessagesPanel'
                  tabIndex='-1'
                  ref={ ( el )=>{
                    this.errorPanelPaymentErrorMessage=el
                  } }
                >
                  { ( () =>{
                    return ( this.props.paymentError.map( ( message, index ) =>{
                      return (
                        <ResponseMessages
                          messageType={ message.messageType }
                          message={ message.messageDesc }
                          key={ index }
                          broadCastAdaMessage={ true }
                        />
                      )
                    } ) )
                  } )() }
                </div>
              )
            }
          } )() }
        </div>

        <div
          className={
            classNames( {
              'PaymentCreditCardPayPal__hide': this.props.paymentType !== 'creditCard'
            } )
          }
          id='creditcardsContentPanel'
          role='tabpanel'
          aria-labelledby='creditcardsTab'
        >
          <PaymentForm
            setCCPaymentFormSubmit={ this.props.setCCPaymentFormSubmit }
            checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
            toggleInputFieldPaymentDisplay={ this.props.toggleInputFieldPaymentDisplay }
            handleCancelAddCreditCard={ this.props.handleCancelAddCreditCard }
            setTempPaymentCCVNumber={ this.props.setTempPaymentCCVNumber }
            handleAddNewCreditCard={ this.props.handleAddNewCreditCard }
            setCreditCardPaymentType={ this.props.setCreditCardPaymentType }
            isSignedIn={ this.props.isSignedIn }
            isAddCreditCard={ this.props.isAddCreditCard }
            editCreditCardData={ this.props.editCreditCardData }
            setEditCreditCardData={ this.props.setEditCreditCardData }
            setEditAddressData={ this.props.setEditAddressData }
            submitShippingAddressForm={ this.props.submitShippingAddressForm }
            handleScrollView={ this.props.handleScrollView }
            addEditCreditCard={ this.props.addEditCreditCard }
            updatePaymentStatus={ this.props.updatePaymentStatus }
            paymentValid={ this.props.paymentValid }
            updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
            editCCData={ this.props.editCCData }
            isSetCCPaymentFormSubmit={ this.props.isSetCCPaymentFormSubmit }
            creditCardDetails={ this.props.creditCardDetails }
            previousPaymentType={ this.props.previousPaymentType }
            toggleSecurityCode={ this.props.toggleSecurityCode }
            displayType={ this.props.displayType }
            isAddressInFocus={ this.props.isAddressInFocus }
            paymentError={ this.props.paymentError }
            enterUnitNumber={ this.props.enterUnitNumber }
            cardInfoOpen={ this.props.cardInfoOpen }
            fieldShowHideToggleData={ this.props.fieldShowHideToggleData }
            addDoneButton={ this.props.addDoneButton }
            showSecurityIcon={ this.props.showSecurityIcon }
            showCVV={ this.props.showCVV }
            checkoutFormConfig={ this.props.checkoutFormConfig }
            shippingInfo={ this.props.shippingInfo }
            handleScrollToFormError={ this.props.handleScrollToFormError }
            editAddressData={ this.props.editAddressData }
            checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
            toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
            isSameAsShipping={ this.props.isSameAsShipping }
          />
        </div>
        { ( () => {
          const token = this.props.payPalClientToken;
          const enableExpressPaypalCheckout = this.props.enableExpressPaypalCheckout;
          if( this.props.paymentType !== 'creditCard' ){
            if( ( this.props.paymentType === 'paypal' && this.props.previousPaymentType === 'paypal' ) || ( has( this.props, 'creditCardDetails' ) && !isEmpty( this.props.creditCardDetails ) && this.props.creditCardDetails.paymentInfo.paymentType === 'paypal' ) ){
              return (
                <div
                  className='PaypalAccount'
                  id='paypalContentPanel'
                  role='tabpanel'
                  aria-labelledby='paypalTab'
                >
                  <div className='PaypalWithPaypalAccount'>
                    <div className='PaypalWithPaypalAccount__Image'>
                      <PayPalSVG/>
                    </div>

                    <div className='PaypalWithPaypalAccount__Text'>
                      <div className='PaypalWithPaypalAccount__Text__line1'>{ formatMessage( messages.payWithPaypal ) }</div>
                      { ( () => {
                        if( has( this.props, 'creditCardDetails.paymentInfo' ) ){
                          return (
                            <div className='PaypalWithPaypalAccount__Text__line2'>
                              { this.props.creditCardDetails.paymentInfo.paymentDetails.emailAddress }
                            </div>
                          );
                        }
                        else {
                          return (
                            <div className='PaypalWithPaypalAccount__Text__line2'>
                              { has( this.props, 'paypalResponse.details' )? this.props.paypalResponse.details.email:'' }
                            </div>
                          );
                        }
                      } )() }
                    </div>
                  </div>

                  <div className='clear'></div>
                  <Divider dividerType={ 'gray' } />

                  { ( () => {
                    if( this.state.showPaypalButton ){
                      return (
                        <PaypalCheckoutButton
                          payPalClientToken={ token }
                          getPaypalToken={ this.props.getPaypalToken }
                          getPaypalResponse={ this.props.getPaypalResponse }
                          applyPayment={ this.props.applyPayment }
                          amount={ has( this.props, 'cartSummary' ) ? this.props.cartSummary.estimatedTotal: '' }
                          currency={ has( this.props, 'cartSummary' ) ? this.props.cartSummary.currencyCode: '' }
                          displayMode={ 'tabView' }
                          onSuccessPaypalPayment={ this.onSuccessPaypalPayment }
                          paypalEnvironment={ this.props.paypalEnvironment }
                          enablePaypalButton={ enableExpressPaypalCheckout }
                        />
                      );
                    }
                    else {
                      return (
                        <Anchor
                          url='#'
                          clickHandler={ this.ChangePaypalAccount }
                          ariaLabel={ formatMessage( messages.ChangePaypalAccount ) }
                          title={ formatMessage( messages.ChangePaypalAccount ) }
                        >
                          { formatMessage( messages.ChangePaypalAccount ) }
                        </Anchor>
                      );
                    }
                  } )() }
                </div>
              )
            }
            else {
              return (
                <div
                  className='PaymentCreditCardPayPal__payPalButton Gutter'
                  id='paypalContentPanel'
                  role='tabpanel'
                  aria-labelledby='paypalTab'
                >
                  { ( () => {
                    if( !isUndefined( enableExpressPaypalCheckout ) && enableExpressPaypalCheckout ){
                      return (
                        <PaypalCheckoutButton
                          payPalClientToken={ token }
                          getPaypalToken={ this.props.getPaypalToken }
                          getPaypalResponse={ this.props.getPaypalResponse }
                          applyPayment={ this.props.applyPayment }
                          amount={ has( this.props, 'cartSummary' ) ? this.props.cartSummary.estimatedTotal: '' }
                          currency={ has( this.props, 'cartSummary' ) ? this.props.cartSummary.currencyCode: '' }
                          displayMode={ 'tabView' }
                          paypalEnvironment={ this.props.paypalEnvironment }
                          enablePaypalButton={ enableExpressPaypalCheckout }
                        />
                      );
                    }
                    else {
                      return (
                        <p className='PaymentCreditCardPayPal__payPalButton--disablePaypalMsg'>
                          { formatMessage( messages.disablePaypalButtonMsg ) }
                        </p>
                      );
                    }
                  } )() }
                </div>
              )
            }
          }
        } )() }
      </div>
    );
  }
}

export const mapDispatchToProps = ( dispatch ) => {
  return {
    postPaypalObject: ( paypalObject ) => {
      dispatch( getActionDefinition( 'applyPayment', 'requested' )( paypalObject ) )
    }
  }
}

PaymentCreditCardPayPal.propTypes = propTypes;

export const connectFunction = ( mapDispatchToProps ) => {
  return ( connect( null, mapDispatchToProps )( PaymentCreditCardPayPal ) );
};
export default connectFunction( mapDispatchToProps );

