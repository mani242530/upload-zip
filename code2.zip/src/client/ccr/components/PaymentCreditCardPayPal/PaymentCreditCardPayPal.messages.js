/*
 * PaymentCreditCardPayPal Messages
 *
 * This contains all the text for the PaymentCreditCardPayPal component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  creditCard: {
    id: 'i18n.PaymentCreditCardPayPal.creditCard',
    defaultMessage: 'Credit Card'
  },
  paypal: {
    id: 'i18n.PaymentCreditCardPayPal.paypal',
    defaultMessage: 'Paypal'
  },
  payWithPaypal: {
    id: 'i18n.PaymentCreditCardPayPal.payWithPaypal',
    defaultMessage: 'PAY WITH PAYPAL ACCOUNT'
  },
  ChangePaypalAccount: {
    id: 'i18n.PaymentCreditCardPayPal.ChangePaypalAccount',
    defaultMessage: 'Change PayPal Account'
  },
  saveToMyAccount: {
    id: 'i18n.PaymentCreditCardPayPal.saveToMyAccount',
    defaultMessage: 'Save to my account'
  },
  disablePaypalButtonMsg: {
    id: 'i18n.PaymentCreditCardPayPal.disablePaypalButtonMsg',
    defaultMessage: 'Sorry! you can\'t use PayPal right now. Use another payment method.'
  }
} );
