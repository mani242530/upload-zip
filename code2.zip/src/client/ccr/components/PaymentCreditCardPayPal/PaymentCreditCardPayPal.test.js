import React from 'react';
import ReactDOM from 'react-dom';
import PaymentCreditCardPayPal, { mapDispatchToProps, connectFunction } from './PaymentCreditCardPayPal';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';

import {
  getActionDefinition,
  registerServiceName
} from 'shared/actions/Services/Services.actions';

describe( '<PaymentCreditCardPayPal />', () => {
  let component;
  const store = configureStore( {}, CONFIG );
  store.getState().checkoutPage.creditCardDetails.paymentInfo = { paymentDetails : {} };
  let props = {
    setCreditCardPaymentType:jest.fn(),
    payPalClientToken: jest.fn(),
    paypalEnvironment : jest.fn(),
    editCreditCardData:{
      creditCardNumber : jest.fn()
    },
    cartSummary:{
      estimatedTotal:'12.00'
    },
    creditCardDetails: {}
  };
  window.braintree = { client:{ create:jest.fn() } };

  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <PaymentCreditCardPayPal
          { ...props }
        />
      </Provider>
    );
    expect( component.find( 'PaymentCreditCardPayPal' ).length ).toBe( 1 );
  } );

  it( 'should render the attributes for accessibility when the credit card tab is selected', () => {
    props.paymentType = 'creditCard';
    component = mountWithIntl(
      <Provider store={ store }>
        <PaymentCreditCardPayPal
          { ...props }
        />
      </Provider>
    );
    expect( component.find( '.PaymentForm__ButtonContainer' ).length ).toBe( 1 );
    expect( component.find( '.PaymentForm__ButtonContainer' ).at( 0 ).props().role ).toBe( 'tablist' );
    expect( component.find( '.PaymentForm__ButtonContainer' ).at( 0 ).props()['aria-orientation'] ).toBe( 'horizontal' );
    expect( component.find( '#creditcardsTab' ).at( 0 ).props().role ).toBe( 'tab' );
    expect( component.find( '#creditcardsTab' ).at( 0 ).props().ariaSelected ).toBe( 'true' );
    expect( component.find( '#creditcardsTab' ).at( 0 ).props().ariaControls ).toBe( 'creditcardsContentPanel' );
    expect( component.find( '#paypalTab' ).at( 0 ).props().role ).toBe( 'tab' );
    expect( component.find( '#paypalTab' ).at( 0 ).props().ariaSelected ).toBe( 'false' );
    expect( component.find( '#paypalTab' ).at( 0 ).props().ariaControls ).toBe( 'paypalContentPanel' );
    expect( component.find( '#creditcardsContentPanel' ).length ).toBe( 1 );
    expect( component.find( '#creditcardsContentPanel' ).at( 0 ).props().role ).toBe( 'tabpanel' );
    expect( component.find( '#creditcardsContentPanel' ).at( 0 ).props()['aria-labelledby'] ).toBe( 'creditcardsTab' );
  } );

  it( 'should render the attributes for accessibility when the paypal tab is selected', () => {
    props.paymentType = 'paypal';
    component = mountWithIntl(
      <Provider store={ store }>
        <PaymentCreditCardPayPal
          { ...props }
        />
      </Provider>
    );
    expect( component.find( '.PaymentForm__ButtonContainer' ).length ).toBe( 1 );
    expect( component.find( '.PaymentForm__ButtonContainer' ).at( 0 ).props().role ).toBe( 'tablist' );
    expect( component.find( '.PaymentForm__ButtonContainer' ).at( 0 ).props()['aria-orientation'] ).toBe( 'horizontal' );
    expect( component.find( '#creditcardsTab' ).at( 0 ).props().role ).toBe( 'tab' );
    expect( component.find( '#creditcardsTab' ).at( 0 ).props().ariaSelected ).toBe( 'false' );
    expect( component.find( '#creditcardsTab' ).at( 0 ).props().ariaControls ).toBe( 'creditcardsContentPanel' );
    expect( component.find( '#paypalTab' ).at( 0 ).props().role ).toBe( 'tab' );
    expect( component.find( '#paypalTab' ).at( 0 ).props().ariaSelected ).toBe( 'true' );
    expect( component.find( '#paypalTab' ).at( 0 ).props().ariaControls ).toBe( 'paypalContentPanel' );
    expect( component.find( '#paypalContentPanel' ).length ).toBe( 1 );
    expect( component.find( '#paypalContentPanel' ).at( 0 ).props().role ).toBe( 'tabpanel' );
    expect( component.find( '#paypalContentPanel' ).at( 0 ).props()['aria-labelledby'] ).toBe( 'paypalTab' );
  } );

  props.paymentType = 'paypal';
  props.setPaymentType = jest.fn();
  component = mountWithIntl(
    <Provider store={ store }>
      <PaymentCreditCardPayPal
        { ...props }
      />
    </Provider>
  );
  const instance = component.find( 'PaymentCreditCardPayPal' ).instance();

  it( 'should call the toggleTab method if paymentType is creditcard', () => {
    component.find( 'Button' ).at( 0 ).simulate( 'click', instance.toggleTab( 'creditCard' ) );
    expect( props.setPaymentType ).toHaveBeenCalledWith( 'creditCard' );
  } );

  it( 'should call the toggleTab method if paymentType is paypal', () => {
    component.find( 'Button' ).at( 1 ).simulate( 'click', instance.toggleTab( 'paypal' ) );
    expect( props.setPaymentType ).toHaveBeenCalledWith( 'creditCard' );
  } );

  it( 'should call the onSuccessPaypalPayment method', () => {
    expect( instance.state.showPaypalButton ).toEqual( false );
    instance.onSuccessPaypalPayment( );
    expect( instance.state.showPaypalButton ).toEqual( false );
  } );

  it( 'should focus on error message div if credit card payment response has error', () => {
    const focusMock = jest.fn();
    const prevProps = {
      paymentError: [],
      creditCardDetails: {
        messages: []
      },
      paymentType:'creditCard'
    }
    // Test focus to error panel generated for paymentError props (props.paymentError)
    const propsWithPaymentError = {
      ...props,
      paymentError: [
        {
          'messageKey': 'creditCardError',
          'messageType': 'Error',
          'messageDesc': 'Credit card error message description'
        }
      ],
      paymentType:'creditCard'
    }
    let componentWithPaymentError = mountWithIntl(
      <Provider store={ store }>
        <PaymentCreditCardPayPal { ...propsWithPaymentError } />
      </Provider> );
    componentWithPaymentError.find( 'PaymentCreditCardPayPal' ).instance().errorPanelPaymentErrorMessage.focus = focusMock;
    componentWithPaymentError.find( 'PaymentCreditCardPayPal' ).instance().componentDidUpdate( prevProps );
    expect( componentWithPaymentError.find( 'PaymentCreditCardPayPal' ).instance().errorPanelPaymentErrorMessage.focus ).toBeCalled();
    // Test focus to error panel generated for creditCardDetails messages (props.creditCardDetails.messages)
    const propsWithcreditCardDetailsErrorMessage = {
      ...props,
      paymentError: [],
      creditCardDetails: {
        messages: [
          {
            'messageKey': 'creditCardError',
            'messageType': 'Error',
            'messageDesc': 'Credit card error message description'
          }
        ]
      },
      paymentType:'creditCard'
    }
    let componentWithcreditCardDetailsError = mountWithIntl(
      <Provider store={ store }>
        <PaymentCreditCardPayPal { ...propsWithcreditCardDetailsErrorMessage } />
      </Provider> );
    componentWithcreditCardDetailsError.find( 'PaymentCreditCardPayPal' ).instance().errorPanelCreditCardDetailsMessage.focus = focusMock;
    componentWithcreditCardDetailsError.find( 'PaymentCreditCardPayPal' ).instance().componentDidUpdate( prevProps );
    expect( componentWithcreditCardDetailsError.find( 'PaymentCreditCardPayPal' ).instance().errorPanelCreditCardDetailsMessage.focus ).toBeCalled();
  } );

  it( 'should call the ChangePaypalAccount method', () => {
    let props1 = {
      setCreditCardPaymentType:jest.fn(),
      payPalClientToken: jest.fn(),
      paypalEnvironment : jest.fn(),
      editCreditCardData:{
        creditCardNumber : jest.fn()
      },
      cartSummary:{
        estimatedTotal:'12.00'
      },
      paymentType : 'paypal',
      previousPaymentType: 'paypal',
      creditCardDetails: {}
    };
    component = mountWithIntl(
      <Provider store={ store }>
        <PaymentCreditCardPayPal
          { ...props1 }
        />
      </Provider>
    );
    const instance = component.find( 'PaymentCreditCardPayPal' ).instance();
    expect( instance.state.showPaypalButton ).toEqual( false );
    component.find( 'Anchor' ).simulate( 'click', { preventDefault(){} } );
    expect( instance.state.showPaypalButton ).toEqual( true );
  } );

} );

describe( '<PaymentCreditCardPayPal /> - MapDispatchToProps', () => {
  const store = configureStore( {}, CONFIG );
  const props = {
    setCreditCardPaymentType:jest.fn(),
    payPalClientToken: jest.fn(),
    paypalEnvironment : jest.fn(),
    editCreditCardData:{
      creditCardNumber : jest.fn()
    },
    cartSummary:{
      estimatedTotal:'12.00'
    }
  };
  const component = mountWithIntl(
    <Provider store={ store }>
      <PaymentCreditCardPayPal { ...props } />
    </Provider>
  );
  const dispatch = jest.fn();
  beforeEach( ()=> {
    dispatch.mockClear();
  } )
  const mdp  = mapDispatchToProps( dispatch );

  it( 'applyPayment should dispatch the proper action', () => {
    const paypalObject = jest.fn();
    registerServiceName( 'applyPayment' );
    mdp.postPaypalObject( paypalObject );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'applyPayment', 'requested' )( paypalObject )
    );
  } );
} );



