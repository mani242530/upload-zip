/**
 * PaymentDefaultCreditCard
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './PaymentDefaultCreditCard.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './PaymentDefaultCreditCard.messages';
import isUndefined from 'lodash/isUndefined';
import isEmpty from 'lodash/isEmpty';
import Exclamation from 'shared/components/Icons/exclamationcircle';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';
import PayPalSVG from 'shared/components/Icons/paypal';
import AmexSVG from 'shared/components/Icons/americanexpress';
import DiscoverSVG from 'shared/components/Icons/discover';
import MasterCardSVG from 'shared/components/Icons/mastercard';
import VisaSVG from 'shared/components/Icons/visa';
import URCCSVG from 'shared/components/Icons/ultamaterewardscreditcard';
import URMCSVG from 'shared/components/Icons/ultamaterewardsmastercard';
import classNames from 'classnames';
import PaymentSecurityCode from 'ccr/components/PaymentSecurityCode/PaymentSecurityCode';

const propTypes = {
  handleChangeCreditCardPaypal: PropTypes.func,
  showSecurityIcon: PropTypes.bool,
  toggleSecurityCode: PropTypes.func,
  displayType: PropTypes.string,
  tabIndex: PropTypes.number,
  editCCData: PropTypes.object,
  showSecurityCodeMaskedValue: PropTypes.string,
  creditCardDetails: PropTypes.object,
  tempPaymentCCVNumber: PropTypes.string,
  updatePaymentServiceResponse: PropTypes.func,
  checkoutFormConfig: PropTypes.object
}

/**
 * Class
 * @extends React.Component
 */
class PaymentDefaultCreditCard extends Component{

  /**
   * Create a PaymentDefaultCreditCard
   */
  constructor( props ){
    super( props );
    this.changeCreditCard = this.changeCreditCard.bind( this );
  }

  changeCreditCard( e ){
    e.preventDefault();
    if( this.props.handleChangeCreditCardPaypal ){
      this.props.handleChangeCreditCardPaypal();
    }
  }

  /**
   * Renders the PaymentDefaultCreditCard component
   */
  render(){


    const {
      creditCardDetails,
      fieldShowHideToggleData
    } = this.props;
    return (
      <div className='PaymentDefaultCreditCard'>
        <h4
          className='sr-only'
          ref={ this.props.selectedPaymentRef }
          tabIndex='-1'
        >
          { formatMessage( messages.selectedPaymentDetails ) }
        </h4>
        <div className='PaymentInformation__container'>
          { ( () =>{
            if( creditCardDetails ){
              if( creditCardDetails.paymentInfo.paymentType === 'paypal' ){
                const {
                  paymentDetails
                } = creditCardDetails.paymentInfo;
                return (
                  <div className='PaymentDefaultCreditCard__Paypal'>
                    <div className='PaypalWithPaypalAccount'>
                      <div className='PaypalWithPaypalAccount__Image'>
                        <PayPalSVG/>
                      </div>

                      <div className='PaypalWithPaypalAccount__Text'>
                        <div
                          className='PaypalWithPaypalAccount__Text__line1'
                        >{ formatMessage( messages.payWithPaypal ) }</div>
                        <div className='PaypalWithPaypalAccount__Text__line2'>
                          { paymentDetails.emailAddress }
                        </div>
                      </div>
                    </div>
                    <div className='clear'></div>
                    <Divider dividerType={ 'gray' } />
                    <Anchor
                      url='#'
                      clickHandler={ this.changeCreditCard }
                      ariaLabel={ formatMessage( messages.ChangePaypalUseCC ) }
                      title={ formatMessage( messages.ChangePaypalUseCC ) }
                      tabIndex={ this.props.tabIndex + 1 }
                    >
                      { formatMessage( messages.ChangePaypalUseCC ) }
                    </Anchor>
                  </div>
                );
              }
              else {
                const {
                  nickName,
                  paymentDetails,
                  contactInfo
                } = creditCardDetails.paymentInfo;
                let creditCardIcon;
                if( paymentDetails.creditCardType === 'Visa' ){
                  creditCardIcon = <VisaSVG/>
                }
                else if( paymentDetails.creditCardType === 'Mastercard' ){
                  creditCardIcon = <MasterCardSVG/>
                }
                else if( paymentDetails.creditCardType === 'Discover' ){
                  creditCardIcon = <DiscoverSVG/>
                }
                else if( paymentDetails.creditCardType === 'AmericanExpress' ){
                  creditCardIcon = <AmexSVG/>
                }
                else if( paymentDetails.creditCardType === 'Ultamate Rewards MasterCard' ){
                  creditCardIcon = <URMCSVG/>
                }
                else if( paymentDetails.creditCardType === 'Ultamate Rewards Credit Card' ){
                  creditCardIcon = <URCCSVG/>
                }
                return (
                  <div className='PaymentInformation__CreditCard'>
                    <div className='PaymentInformation__CreditCard--card'>
                      <label
                        id='PaymentInformationCreditCardLabel'
                        className='sr-only'
                      >
                        { formatMessage( messages.savedCreditCard ) }
                      </label>
                      <div className={
                        classNames(
                          'PaymentInformation__CreditCard--card--details', {
                            'PaymentInformation__CreditCard--card--details--full': ( ( nickName === 'tempCBCC' ) || paymentDetails.creditCardType === 'Ultamate Rewards Credit Card' )
                          }
                        )
                      }
                      >
                        <div className='PaymentInformation__CreditCard--card--details--type'>
                          <span className='icon'>
                            { creditCardIcon }
                          </span>
                        </div>
                        <div className='PaymentInformation__CreditCard--card--details--type'>
                          <div className='CardName'>
                            { ( () =>{
                              if( paymentDetails.creditCardType === 'Ultamate Rewards MasterCard' ){
                                return (
                                  <div>
                                    { formatMessage( messages.ultamateRewards ) }
                                    <div>
                                      { formatMessage( messages.masterCard ) }
                                    </div>
                                  </div>
                                )
                              }
                              else {
                                return (
                                  paymentDetails.creditCardType
                                )

                              }
                            } )() }

                          </div>
                          <div className='CardDetails'>
                            <span className='creditCardNumber'>
                              ****{ paymentDetails.creditCardNumber }
                            </span>
                            { ( () =>{
                              if( !isUndefined( paymentDetails.expirationMonth ) && !isEmpty( paymentDetails.expirationMonth ) && !isUndefined( paymentDetails.expirationYear ) && !isEmpty( paymentDetails.expirationYear ) ){
                                return (
                                  <span className='Expiration'>
                                    { paymentDetails.expirationMonth }/{ paymentDetails.expirationYear }
                                  </span>
                                );
                              }
                            } )() }
                          </div>

                        </div>
                      </div>

                      { ( () => {
                        if( paymentDetails.creditCardType !== 'Ultamate Rewards Credit Card' && nickName !== 'tempCBCC' ){
                          return (
                            <PaymentSecurityCode
                              showSecurityIcon={ this.props.showSecurityIcon }
                              toggleSecurityCode={ this.props.toggleSecurityCode }
                              displayType={ this.props.displayType }
                              tabIndex={ this.props.tabIndex +2 }
                              paymentDetails={ paymentDetails }
                              editCCData={ this.props.editCCData }
                              showSecurityCodeMaskedValue={ this.props.checkoutFormConfig.showHideCheckoutToggleData.ccSecurityCode }
                              creditCardDetails={ this.props.creditCardDetails }
                              tempPaymentCCVNumber={ this.props.tempPaymentCCVNumber }
                              updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
                              handleChangeCreditCardPaypal={ this.props.handleChangeCreditCardPaypal }
                            />

                          );
                        }
                      } )() }
                    </div>
                    <div className='PaymentInformation__CreditCard--header Gutter'>
                      { formatMessage( messages.billingAddress ) }
                    </div>
                    <div className='PaymentInformation__CreditCard--address Gutter'>
                      <div className='name'>
                        <span>{ contactInfo.firstName }</span>
                        <span> { contactInfo.lastName }</span>
                      </div>
                      <div className='address'>
                        <span>{ contactInfo.address1 }</span>
                        { ( () => {
                          if( contactInfo.address2 !== null && contactInfo.address2 !== '' ){
                            return (
                              <span> { contactInfo.address2 }</span>
                            );
                          }
                        } )() }
                        { ( () =>{
                          if( contactInfo.city && contactInfo.city.length > 0 ){
                            return (
                              <span>, { contactInfo.city }</span>
                            );
                          }
                        } )() }

                        <span> { contactInfo.state }</span>
                        <span> { contactInfo.postalCode }</span>
                      </div>
                      <div>{ contactInfo.phoneNumber }</div>
                    </div>

                    <Divider
                      className='Gutter'
                      dividerType={ 'gray' }
                    />
                    <Anchor
                      url='#'
                      className='Gutter'
                      clickHandler={ this.changeCreditCard }
                      ariaLabel={ formatMessage( messages.ChangeCCPaypal ) }
                      title={ formatMessage( messages.ChangeCCPaypal ) }
                      tabIndex={ this.props.tabIndex + 4 }
                    >
                      { formatMessage( messages.ChangeCCPaypal ) }
                    </Anchor>
                  </div>
                );
              }
            }
          } )() }
        </div>
      </div>

    );
  }
}

PaymentDefaultCreditCard.propTypes = propTypes;

export default PaymentDefaultCreditCard;
