/*
 * PaymentDefaultCreditCard Messages
 *
 * This contains all the text for the PaymentDefaultCreditCard component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  billingAddress: {
    id: 'i18n.PaymentDefaultCreditCard.billingAddress',
    defaultMessage: 'Billing Address'
  },
  ChangeCCPaypal: {
    id: 'i18n.PaymentDefaultCreditCard.ChangeCCPaypal',
    defaultMessage: 'Change Credit Card Or Use PayPal'
  },
  payWithPaypal: {
    id: 'i18n.PaymentDefaultCreditCard.payWithPaypal',
    defaultMessage: 'PAY WITH PAYPAL ACCOUNT'
  },
  ChangePaypalUseCC: {
    id: 'i18n.PaymentDefaultCreditCard.ChangePaypalUseCC',
    defaultMessage: 'Change PayPal Account Or Use Credit Card'
  },
  ultamateRewards: {
    id: 'i18n.PaymentDefaultCreditCard.ultamateRewards',
    defaultMessage: 'Ultamate Rewards '
  },
  masterCard: {
    id: 'i18n.PaymentDefaultCreditCard.masterCard',
    defaultMessage: 'MasterCard '
  },
  savedCreditCard: {
    id: 'i18n.PaymentDefaultCreditCard.savedCreditCard',
    defaultMessage: 'Saved Credit Card'
  },
  selectedPaymentDetails: {
    id: 'i18n.PaymentDefaultCreditCard.selectedPaymentDetails',
    defaultMessage: 'Selected payment details'
  }
} );
