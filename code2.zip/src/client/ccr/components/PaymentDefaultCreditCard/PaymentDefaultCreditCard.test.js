import React from 'react';
import ReactDOM from 'react-dom';
import PaymentDefaultCreditCard from './PaymentDefaultCreditCard';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import messages from './PaymentDefaultCreditCard.messages';

describe( '<PaymentDefaultCreditCard />', () => {
  let component;
  let props = {
    creditCardDetails: {
      paymentInfo: {
        paymentType: 'creditCard',
        paymentDetails: {
          expirationMonth: '09',
          expirationYear: '2021',
          creditCardNumber: '1111',
          creditCardType: 'Visa'
        },
        amount: 46.18,
        currencyCode: 'USD',
        contactInfo: {
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          email: 'pkabdaula@ulta.com',
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city: 'Boolingbrook',
          state: 'IL',
          postalCode: '07105',
          country: 'US'
        }
      }
    },
    checkoutFormConfig:{ showHideCheckoutToggleData:{} }
  };
  let paymentDetails = props.creditCardDetails.paymentInfo.paymentDetails;
  let contactInfo = props.creditCardDetails.paymentInfo.contactInfo;

  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <PaymentDefaultCreditCard { ...props }/>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'PaymentDefaultCreditCard' ).length ).toBe( 1 );
  } );

  it( 'renders Field components', () => {
    expect( component.find( '.PaymentDefaultCreditCard' ).find( 'InputField' ).length ).toBe( 1 );
  } );

  it( 'Should contain Credit Card Default Details', () => {
    let name = contactInfo.firstName+' '+contactInfo.lastName;
    let address = contactInfo.address1+' '+contactInfo.address2+', '+contactInfo.city+' '+contactInfo.state+' '+contactInfo.postalCode;

    expect( component.find( '.PaymentDefaultCreditCard .PaymentInformation__CreditCard--address .name' ).text() ).toBe( name );
    expect( component.find( '.PaymentDefaultCreditCard .PaymentInformation__CreditCard--address .address' ).text() ).toBe( address );
    expect( component.find( '.PaymentDefaultCreditCard .CardName' ).text() ).toBe( paymentDetails.creditCardType );
    expect( component.find( '.PaymentDefaultCreditCard .CardDetails .creditCardNumber' ).text() ).toBe( '****'+paymentDetails.creditCardNumber );
    expect( component.find( '.PaymentDefaultCreditCard .CardDetails .Expiration' ).text() ).toBe( paymentDetails.expirationMonth+'/'+paymentDetails.expirationYear );
  } );

  it( 'should render correct Text for Change Credit Card or Paypal', () => {
    expect( component.find( '.PaymentDefaultCreditCard .Anchor' ).text() ).toEqual( messages.ChangeCCPaypal.defaultMessage );
  } );

  it( 'should render correct URL for Change Credit Card or Paypal', () => {
    expect( component.find( '.PaymentDefaultCreditCard .Anchor' ).props().href ).toBe( '#' );
  } );

  it( 'should alert the label for the Saved Credit Card section', () => {
    expect( component.find( '.PaymentInformation__CreditCard--card label' ).at( 0 ).text() ).toBe( messages.savedCreditCard.defaultMessage );
  } );

  it( 'h4 should have tabIndex of -1 and selectedPaymentDetails defaultMessage', () => {
    expect( component.find( '.PaymentDefaultCreditCard' ).find( 'h4' ).instance().tabIndex ).toBe( -1 );
    expect( component.find( '.PaymentDefaultCreditCard' ).find( 'h4' ).text() ).toBe( messages.selectedPaymentDetails.defaultMessage );
  } );

} );
