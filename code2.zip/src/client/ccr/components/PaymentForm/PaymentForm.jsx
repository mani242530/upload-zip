import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './PaymentForm.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './PaymentForm.messages';

import Button from 'shared/components/Button/Button';
import { Field, reduxForm, formValueSelector, isValid, change, untouch, getFormValues } from 'redux-form';
import InputField from 'shared/components/InputField/InputField';
import ToggleButton from 'shared/components/ToggleButton/ToggleButton';
import Exclamation from 'shared/components/Icons/exclamationcircle';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';
import CheckoutAddressForm from 'ccr/components/CheckoutAddressForm/CheckoutAddressForm';
import { Collapse } from 'react-bootstrap';
import { connect } from 'react-redux';
import Visa from 'shared/components/Icons/visa';
import Discover from 'shared/components/Icons/discover';
import Mastercard from 'shared/components/Icons/mastercard';
import Amex from 'shared/components/Icons/americanexpress';
import UltamateRewardsCC from 'shared/components/Icons/ultamaterewardscreditcard';
import UltamateRewardsMC from 'shared/components/Icons/ultamaterewardsmastercard';
import DefaultCreditCard from 'shared/components/Icons/creditcarddefault';
import CreditCardBackView from 'shared/components/Icons/creditcardback';
import CreditCardAmexFrontView from 'shared/components/Icons/creditcardamexfront';
import { isEmpty, has, find, keys, size, values, isEqual, pull, isUndefined, pick, identity, delay } from 'lodash';
import classNames from 'classnames';
import VMasker from 'vanilla-masker';
import {
  validateSecurityCode
} from 'utils/FormValidations/FormValidations';
import FormValidationMessages from 'utils/FormValidations/FormValidations.messages';
import {
  removeSpecialCharacters
} from 'utils/Formatters/formatters';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';
import 'shared/components/Gutter/Gutter.css';


const propTypes = {
  isAddressInFocus: PropTypes.bool,
  paymentError: PropTypes.array || PropTypes.bool,
  enterUnitNumber: PropTypes.bool,
  cardInfoOpen: PropTypes.bool,
  addEditCreditCard: PropTypes.oneOf( ['yes', 'no', ''] ),
  handleCancelAddCreditCard: PropTypes.func,
  handleAddNewCreditCard: PropTypes.func,
  setCCPaymentFormSubmit: PropTypes.func,
  checkoutFormAddress2Open: PropTypes.object,
  toggleInputFieldPaymentDisplay: PropTypes.func,
  setTempPaymentCCVNumber: PropTypes.func,
  setCreditCardPaymentType: PropTypes.func,
  isSignedIn: PropTypes.bool,
  isAddCreditCard: PropTypes.bool,
  editCreditCardData: PropTypes.object,
  setEditCreditCardData: PropTypes.func,
  setEditAddressData: PropTypes.func,
  submitShippingAddressForm: PropTypes.func,
  handleScrollView: PropTypes.func,
  updatePaymentStatus: PropTypes.func,
  updatePaymentServiceResponse: PropTypes.func,
  editCCData: PropTypes.object,
  isSetCCPaymentFormSubmit: PropTypes.bool,
  creditCardDetails: PropTypes.object,
  previousPaymentType: PropTypes.string,
  toggleSecurityCode: PropTypes.func,
  displayType: PropTypes.string,
  fieldShowHideToggleData: PropTypes.object,
  addDoneButton: PropTypes.bool,
  showSecurityIcon: PropTypes.bool,
  showCVV: PropTypes.bool,
  checkoutFormConfig: PropTypes.object,
  shippingInfo: PropTypes.object,
  editAddressData: PropTypes.object,
  checkoutFormAddressOpen: PropTypes.object,
  address2Open: PropTypes.object,
  toggleAddressFieldDisplayPaymentForm: PropTypes.func,
  handleScrollToFormError: PropTypes.func
}

const initialState = {
  cardInfoOpen: false,
  isSameAsShipping: true,
  cardType: ( <DefaultCreditCard/> ),
  isPrimaryPaymentMethod: false,
  securityCode: '',
  saveToMyAccount: false,
  loadMaskCreditcard: false,
  showHintText:false,
  initialPaymentData:{},
  initialPaymentAddress:{},
  showSecurityIcon: false
};

export const required = ( val ) => {
  let message = formatMessage( FormValidationMessages.required );
  return val && val.length > 0 ? undefined : message;
}

export const validateEmail = ( val ) => {
  let re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test( val ) ? undefined : formatMessage( FormValidationMessages.invalidEmail );
}

export const validateCreditCardExpiry = val => {
  var re = /^(?:(0[1-9]|1[012])[\/.][1-9]{1}[0-9]{3})$/;
  let currentYear = parseInt( new Date().getFullYear().toString(), 10 );
  let currentMonth = parseInt( new Date().getMonth().toString(), 10 );
  let givenYear = parseInt( val.toString().substr( -4 ), 10 );
  let givenMonth = parseInt( val.toString().substring(), 10 );
  if( val.length < 7 ){
    return formatMessage( FormValidationMessages.validateCCExpiryOnLessDigit );
  }
  let testdate=( givenYear !== currentYear ) ? givenYear > currentYear : ( currentMonth < givenMonth );
  return ( re.test( val ) && testdate ) ? undefined : formatMessage( FormValidationMessages.validateCreditCardExpiry );
}

export const validatePhone = ( val ) => {
  return removeSpecialCharacters( val ).length === 10 ? undefined : formatMessage( FormValidationMessages.invalidPhoneNumber );
}

export const validateZipCode = val => {
  let re= /(\d{5})$/;
  return re.test( val ) ? undefined : formatMessage( FormValidationMessages.invalidZipCode );
}

export const validateCreditCard = val => {
  var re ;
  if( val.match( /^3[47]/ ) ){
    re = /([0-9]{4}\s[0-9]{6}\s[0-9]{5}\s*)$/;
  }
  else {
    re = /([0-9]{4}\s[0-9]{4}\s[0-9]{4}\s[0-9]{4}\s*)$/;
  }
  return re.test( val ) ? undefined : formatMessage( FormValidationMessages.validateCreditCard ) ;
}
/**
 * Class
 * @extends React.Component
 */
class PaymentForm extends Component{

  /**
   * Create a PaymentForm
   */
  constructor( props ){
    super( props );
    this.state = initialState;
    this.getCCIcon = this.getCCIcon.bind( this );
    this.assignPaymentAddress = this.assignPaymentAddress.bind( this );
    this.savePaymentDetails = this.savePaymentDetails.bind( this );
    this.handleSubmitCreditCard = this.handleSubmitCreditCard.bind( this );
    this.sameAsShippingToggle = this.sameAsShippingToggle.bind( this );
    this.makePrimaryCCToggle = this.makePrimaryCCToggle.bind( this );
    this.cancelAddCreditCard = this.cancelAddCreditCard.bind( this );
    this.addNewPaymentMethod = this.addNewPaymentMethod.bind( this );
    this.activateCreditCardField = this.activateCreditCardField.bind( this );
    this.toggleAddress2Validation = this.toggleAddress2Validation.bind( this );
    this.toggleSecurityIcon = this.toggleSecurityIcon.bind( this );
  }

  componentDidComponent(){
    this.props.setCCPaymentFormSubmit( false );
  }

  toggleAddress2Validation(){
    if( this.props.checkoutFormAddress2Open.paymentAddressForm ){
      this.props.toggleInputFieldPaymentDisplay();
    }
  }

  makePrimaryCCToggle(){
    this.setState( { isPrimaryPaymentMethod: !this.state.isPrimaryPaymentMethod } )
  }

  cancelAddCreditCard( e ){
    if( this.props.handleCancelAddCreditCard ){
      this.props.setTempPaymentCCVNumber( null );
      this.props.handleCancelAddCreditCard();
    }
  }

  addNewPaymentMethod( e ){
    if( this.props.formData ){
      if( this.props.handleAddNewCreditCard ){
        this.handleSubmitCreditCard( e );
      }
    }
    return false;
  }

  activateCreditCardField( e ){
    this.setState( {
      loadMaskCreditcard: false
    }, () =>{
      this.getCCIcon( e || '' )
    } );
  }

  getCCIcon( val ){
    let newVal = val.replace( ' ', '' ), cardType = 'defaultCreditCard';

    if( newVal ){
      if( newVal && newVal.match( /^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)/ ) ){
        cardType = 'Discover';
      }
      else if( newVal.match( /^5780|9710[5-9]/ ) ){
        cardType = 'Ultamate Rewards Credit Card';
      }
      else if( newVal.match( /^3[47]/ ) ){
        cardType = 'AmericanExpress';
      }
      else if( newVal.match( /^536817/ ) ){
        cardType = 'Ultamate Rewards MasterCard';
      }
      else if( newVal.match( /^(5([1-6][0-9][0-9][0-9][0-9])|22([2-9][1-9][0-9][0-9])|23([0-9][0-9][0-9][0-9])|24([0-9][0-9][0-9][0-9])|25([0-9][0-9][0-9][0-9])|26([0-9][0-9][0-9][0-9])|27([0-2]0[0-9][0-9]))/ ) ){
        cardType = 'Mastercard';
      }
      else if( newVal.match( /^4[0-9]/ ) ){
        cardType = 'Visa';
      }
      else {
        cardType = 'defaultCreditCard';
      }
    }
    this.setState( { cardType }, () =>{
      this.props.setCreditCardPaymentType( cardType );
      if( !this.isCardTypeValid() ){
        this.setState( { expirationDate: '', securityCode: '' } )
        this.props.change( 'expirationDate', '' );
        this.props.change( 'securityCode', '' );
        this.props.untouch( 'paymentForm', 'expirationDate' );
        this.props.untouch( 'paymentForm', 'securityCode' );
      }
    } );
  }

  isCardTypeValid(){
    return (
      this.state.cardType === 'Discover' || this.state.cardType === 'AmericanExpress' || this.state.cardType === 'Mastercard' || this.state.cardType === 'Visa' || ( this.state.cardType === 'Ultamate Rewards MasterCard' && this.state.nickName !== 'tempCBCC' )
    );
  }

  sameAsShippingToggle(){
    const {
      shippingInfo
    } = this.props;

    this.setState( {
      isSameAsShipping: !this.state.isSameAsShipping
    } );

    // Clear address form fields when toggled from 'on' to 'off' based on 2 conditions
    // 1. If a user is Guest.
    // 2. If user wants to add a new billing address.
    if( this.state.isSameAsShipping && ( !this.props.isSignedIn || this.props.isAddCreditCard ) ){
      let values = Object.assign( {}, this.props.editCreditCardData );
      values.contactInfo = null;
      this.props.setEditCreditCardData( values );
      this.props.setEditAddressData( {} );
    }

    if( !this.state.isSameAsShipping && ( isUndefined( shippingInfo ) || isUndefined( shippingInfo.shippingAddress ) ) ){
      this.setState( {
        isSameAsShipping: false
      } );
      this.props.submitShippingAddressForm();
      delay( ()=>{
        if( this.props.shippingValid ){
          this.setState( {
            isSameAsShipping: true
          } );
        }
        else {
          this.props.handleScrollView( 'checkoutShippingHeader' );
        }
      }, 100 );
    }

    if( !this.state.isSameAsShipping && !this.props.shippingValid ){
      this.setState( {
        isSameAsShipping: false
      } );
      this.props.handleScrollView( 'checkoutShippingHeader' );
    }
  }

  handleSubmitCreditCard( e ){

    const {
      formData,
      editCreditCardData
    } = this.props;
    const {
      shippingInfo
    } = this.props;
    const currentTarget = e.currentTarget || null;
    let formValues = this.props.formData.values;
    let syncErrors = this.props.formData.syncErrors;
    let ccvalue = '';
    if( !isUndefined( editCreditCardData ) ){
      ccvalue = '****' + editCreditCardData.creditCardNumber;
    }
    if( this.state.isSameAsShipping === true ){
      if( this.state.cardType === 'Ultamate Rewards Credit Card' ){
        if( formValues && formValues.creditCardNumber ){
          if( ( !isUndefined( shippingInfo ) && !isUndefined( shippingInfo.shippingAddress ) ) ){
            if( isUndefined( syncErrors.creditCardNumber ) && !isEqual( this.state.initialPaymentData, formValues ) ){
              let values = {
                creditCardNumber: ( ccvalue === formValues.creditCardNumber ) ? editCreditCardData.creditCardNumber.replace( / /g, '' ).trim() : formValues.creditCardNumber.replace( / /g, '' ).trim(),
                sameAsShipping: true,
                creditCardType: this.state.cardType.trim()
              }

              this.setState( {
                initialPaymentData: {
                  creditCardNumber: formValues.creditCardNumber,
                  expirationDate: formValues.expirationDate,
                  securityCode: formValues.securityCode
                }
              } );
              this.setState( {
                initialPaymentAddress: {
                  creditCardNumber: formValues.creditCardNumber,
                  expirationDate: formValues.expirationDate,
                  securityCode: formValues.securityCode,
                  firstNamepaymentAddressForm: this.state.initialPaymentAddress.firstNamepaymentAddressForm,
                  lastNamepaymentAddressForm: this.state.initialPaymentAddress.lastNamepaymentAddressForm,
                  address1paymentAddressForm: this.state.initialPaymentAddress.address1paymentAddressForm,
                  postalCodepaymentAddressForm: this.state.initialPaymentAddress.postalCodepaymentAddressForm,
                  citypaymentAddressForm: this.state.initialPaymentAddress.citypaymentAddressForm,
                  state: this.state.initialPaymentAddress.state,
                  phoneNumberpaymentAddressForm: this.state.initialPaymentAddress.phoneNumberpaymentAddressForm
                }
              } );
              setTimeout( function(){
                if( !( currentTarget && currentTarget.contains( document.activeElement ) ) ){
                  this.props.setCreditCardPaymentType( values.creditCardType );
                  this.savePaymentDetails( values );
                }
              }.bind( this ), 0 )
            }
          }
        }
      }
      else if( formValues && formValues.creditCardNumber && formValues.expirationDate && formValues.securityCode ){
        if( ( !isUndefined( shippingInfo ) && !isUndefined( shippingInfo.shippingAddress ) ) ){
          if( isUndefined( syncErrors.creditCardNumber ) && isUndefined( syncErrors.expirationDate ) && isUndefined( syncErrors.securityCode )
            && ( !isEqual( this.state.initialPaymentData, formValues ) || has( this.props, 'creditCardDetails.isPaymentErrorCleared' ) ) ){
            let values = {
              expirationMonth: formValues.expirationDate.substring( 0, 2 ).trim(),
              expirationYear:  formValues.expirationDate.substring( 3, 7 ).trim(),
              creditCardNumber: ( ccvalue === formValues.creditCardNumber ) ? editCreditCardData.creditCardNumber.replace( / /g, '' ).trim() : formValues.creditCardNumber.replace( / /g, '' ).trim(),
              cardVerificationNumber: formValues.securityCode.trim(),
              sameAsShipping: true,
              creditCardType: this.state.cardType.trim()
            }

            this.setState( {
              initialPaymentData: {
                creditCardNumber: formValues.creditCardNumber,
                expirationDate: formValues.expirationDate,
                securityCode: formValues.securityCode
              }
            } );
            this.setState( {
              initialPaymentAddress: {
                creditCardNumber: formValues.creditCardNumber,
                expirationDate: formValues.expirationDate,
                securityCode: formValues.securityCode,
                firstNamepaymentAddressForm: this.state.initialPaymentAddress.firstNamepaymentAddressForm,
                lastNamepaymentAddressForm: this.state.initialPaymentAddress.lastNamepaymentAddressForm,
                address1paymentAddressForm: this.state.initialPaymentAddress.address1paymentAddressForm,
                postalCodepaymentAddressForm: this.state.initialPaymentAddress.postalCodepaymentAddressForm,
                citypaymentAddressForm: this.state.initialPaymentAddress.citypaymentAddressForm,
                state: this.state.initialPaymentAddress.state,
                phoneNumberpaymentAddressForm: this.state.initialPaymentAddress.phoneNumberpaymentAddressForm
              }
            } );
            setTimeout( function(){
              if( !( currentTarget && currentTarget.contains( document.activeElement ) ) ){
                this.props.setTempPaymentCCVNumber( values.cardVerificationNumber );
                this.props.setCreditCardPaymentType( values.creditCardType );
                this.savePaymentDetails( values );
              }
            }.bind( this ), 0 )
          }
        }
      }
    }
    else if( this.state.cardType === 'Ultamate Rewards Credit Card' ){
      if( formValues
        && formValues.firstNamepaymentAddressForm
        && formValues.lastNamepaymentAddressForm
        && formValues.address1paymentAddressForm
        && formValues.postalCodepaymentAddressForm
        && formValues.citypaymentAddressForm
        && formValues.state
        && formValues.phoneNumberpaymentAddressForm
        && formValues.creditCardNumber ){
        if( isUndefined( syncErrors.firstNamepaymentAddressForm )
          && isUndefined( syncErrors.lastNamepaymentAddressForm )
          && isUndefined( syncErrors.address1paymentAddressForm )
          && isUndefined( syncErrors.postalCodepaymentAddressForm )
          && isUndefined( syncErrors.citypaymentAddressForm )
          && isUndefined( syncErrors.phoneNumberpaymentAddressForm )
          && isUndefined( syncErrors.creditCardNumber )
          && !isEqual( this.state.initialPaymentAddress, formValues ) ){
          let phNumber = VMasker.toPattern( formValues.phoneNumberpaymentAddressForm, '999-999-9999' );

          let values;
          values = {
            firstName: formValues.firstNamepaymentAddressForm.trim(),
            lastName: formValues.lastNamepaymentAddressForm.trim(),
            address2: ( formValues.address2paymentAddressForm ) ? formValues.address2paymentAddressForm.trim() : '',
            address1: formValues.address1paymentAddressForm.trim(),
            postalCode: formValues.postalCodepaymentAddressForm.trim(),
            city: formValues.citypaymentAddressForm.trim(),
            state: formValues.state,
            creditCardNumber: ( ccvalue === formValues.creditCardNumber ) ? editCreditCardData.creditCardNumber.replace( / /g, '' ).trim() : formValues.creditCardNumber.replace( / /g, '' ).trim(),
            phoneNumber: phNumber.trim(),
            sameAsShipping: false,
            creditCardType: this.state.cardType.trim()
          }
          this.setState( {
            initialPaymentData: {
              creditCardNumber: formValues.creditCardNumber,
              expirationDate: formValues.expirationDate,
              securityCode: formValues.securityCode
            }
          } );
          this.setState( { initialPaymentAddress: formValues } );
          setTimeout( function(){
            if( !( currentTarget && currentTarget.contains( document.activeElement ) ) ){
              this.props.setCreditCardPaymentType( values.creditCardType );
              this.savePaymentDetails( values );
            }
          }.bind( this ), 0 )
        }
      }
    }
    else if( formValues
      && formValues.firstNamepaymentAddressForm
      && formValues.lastNamepaymentAddressForm
      && formValues.address1paymentAddressForm
      && formValues.postalCodepaymentAddressForm
      && formValues.citypaymentAddressForm
      && formValues.state
      && formValues.phoneNumberpaymentAddressForm
      && formValues.creditCardNumber
      && formValues.expirationDate
      && formValues.securityCode ){
      if( isUndefined( syncErrors.firstNamepaymentAddressForm )
        && isUndefined( syncErrors.lastNamepaymentAddressForm )
        && isUndefined( syncErrors.address1paymentAddressForm )
        && isUndefined( syncErrors.postalCodepaymentAddressForm )
        && isUndefined( syncErrors.citypaymentAddressForm )
        && isUndefined( syncErrors.phoneNumberpaymentAddressForm )
        && isUndefined( syncErrors.creditCardNumber )
        && isUndefined( syncErrors.expirationDate )
        && isUndefined( syncErrors.securityCode )
        && ( !isEqual( this.state.initialPaymentAddress, formValues ) ||
            has( this.props, 'creditCardDetails.isPaymentErrorCleared' ) ) ){
        let phNumber = VMasker.toPattern( formValues.phoneNumberpaymentAddressForm, '999-999-9999' );
        let values;
        values = {
          firstName: formValues.firstNamepaymentAddressForm.trim(),
          lastName: formValues.lastNamepaymentAddressForm.trim(),
          address2: ( formValues.address2paymentAddressForm ) ? formValues.address2paymentAddressForm.trim() : '',
          address1: formValues.address1paymentAddressForm.trim(),
          postalCode: formValues.postalCodepaymentAddressForm.trim(),
          city: formValues.citypaymentAddressForm.trim(),
          state: formValues.state.trim(),
          creditCardNumber: ( ccvalue === formValues.creditCardNumber ) ? editCreditCardData.creditCardNumber.replace( / /g, '' ).trim() : formValues.creditCardNumber.replace( / /g, '' ).trim(),
          expirationMonth: formValues.expirationDate.substring( 0, 2 ).trim(),
          expirationYear: formValues.expirationDate.substring( 3, 7 ).trim(),
          cardVerificationNumber: formValues.securityCode.trim(),
          phoneNumber: phNumber.trim(),
          sameAsShipping: false,
          creditCardType: this.state.cardType.trim()
        }
        this.setState( {
          initialPaymentData: {
            creditCardNumber: formValues.creditCardNumber,
            expirationDate: formValues.expirationDate,
            securityCode: formValues.securityCode
          }
        } );
        this.setState( { initialPaymentAddress: formValues } );
        setTimeout( function(){
          if( !( currentTarget && currentTarget.contains( document.activeElement ) ) ){
            this.props.setTempPaymentCCVNumber( values.cardVerificationNumber );
            this.props.setCreditCardPaymentType( values.creditCardType );
            this.savePaymentDetails( values );
          }
        }.bind( this ), 0 )
      }
    }
  }

  savePaymentDetails( values ){
    let _values = values;
    if( this.props.addEditCreditCard === 'yes' ){
      _values.primary = this.state.isPrimaryPaymentMethod
    }
    if( !isUndefined( this.props.editCreditCardData.nickName ) ){
      _values.nickName = this.props.editCreditCardData.nickName
    }
    _values.paymentType = 'creditCard';
    this.props.updatePaymentStatus( !this.props.paymentValid );

    this.props.updatePaymentServiceResponse( { values: _values } );
  }

  assignPaymentAddress(){
    if( !isUndefined( this.props.editCreditCardData.creditCardNumber ) ){
      this.setState( {
        nickName: this.props.editCreditCardData.nickName,
        cardType: this.props.editCreditCardData.creditCardType,
        creditCardNumber: this.props.editCreditCardData.creditCardNumber,
        maskCreditCardNumber: '****' + this.props.editCreditCardData.creditCardNumber,
        expirationDate: '',
        isPrimaryPaymentMethod: this.props.editCreditCardData.isPrimary,
        loadMaskCreditcard: true
      }, () => {
        this.props.setCreditCardPaymentType( this.props.editCreditCardData.creditCardType );
        this.props.change( 'creditCardNumber', this.state.maskCreditCardNumber );
      } );
    }
    if( !isUndefined( this.props.editCreditCardData.expirationMonth ) && !isEmpty( this.props.editCreditCardData.expirationMonth ) && !isUndefined( this.props.editCreditCardData.expirationYear ) && !isEmpty( this.props.editCreditCardData.expirationYear ) ){
      this.setState( {
        expirationDate: this.props.editCreditCardData.expirationMonth + '/' + this.props.editCreditCardData.expirationYear
      } )
    }
  }

  componentWillMount(){
    this.assignPaymentAddress();
    const {
      shippingInfo,
      editCCData,
      editCreditCardData
    } = this.props;
    if( !isEmpty( editCCData ) ){
      if( has( this.props, 'shippingInfo.shippingAddress.postalCode' ) &&
        editCCData.postalCode !== shippingInfo.shippingAddress.postalCode ){

        this.setState( { isSameAsShipping: false } );
      }
      else {
        this.setState( { isSameAsShipping: true } );

      }
    }
    if( !isEmpty( editCreditCardData ) ){
      if( has( this.props, 'shippingInfo.shippingAddress.postalCode' ) && editCreditCardData.contactInfo &&
        !isUndefined( editCreditCardData.contactInfo.addressData ) &&
        editCreditCardData.contactInfo.addressData.postalCode !== shippingInfo.shippingAddress.postalCode ||
        ( has( this.props, 'editCreditCardData.contactInfo.addressData.postalCode' ) && !has( this.props, 'shippingInfo.shippingAddress.postalCode' ) ) ||
        this.props.addDoneButton ){
        this.setState( { isSameAsShipping: false } );
      }
      else {
        this.setState( { isSameAsShipping: true } );

      }
    }
  }

  componentDidUpdate( prevProps ){
    if( this.props.isSetCCPaymentFormSubmit && !prevProps.isSetCCPaymentFormSubmit && this.props.handleAddNewCreditCard && has( this.props.creditCardDetails, 'messages' ) && isEmpty( this.props.creditCardDetails.messages ) ){
      this.props.handleAddNewCreditCard();
    }
    if( this.props.isSetCCPaymentFormSubmit && !prevProps.isSetCCPaymentFormSubmit && has( this.props.creditCardDetails, 'messages' ) && !isEmpty( this.props.creditCardDetails.messages ) ){
      this.props.handleScrollView( 'checkoutPaymentHeader' );
    }
    if( has( this.props, 'editCreditCardData' ) && !isEqual( this.props.editCreditCardData, prevProps.editCreditCardData ) && ( !has( this.props, 'creditCardDetails.isPaymentErrorCleared' ) ) && this.props.previousPaymentType !== 'paypal' ){
      this.assignPaymentAddress();
    }
    if( prevProps !== this.props && ( prevProps.formData !== this.props.formData ) && isUndefined( this.props.formData.values ) && isUndefined( this.props.formData.active ) && this.props.previousPaymentType !== 'paypal' ){
      if( !isUndefined( prevProps.formData.values ) ){
        this.props.change( 'creditCardNumber', prevProps.formData.values.creditCardNumber );
        this.props.change( 'expirationDate', prevProps.formData.values.expirationDate );
        this.props.change( 'securityCode', prevProps.formData.values.securityCode );
      }
    }
    if( prevProps!==this.porps && prevProps.previousPaymentType !== this.props.previousPaymentType && this.props.previousPaymentType === 'paypal' ){
      this.props.change( 'creditCardNumber', '' );
      this.props.change( 'expirationDate', '' );
      this.props.change( 'securityCode', '' );
      this.props.untouch( 'paymentForm', 'creditCardNumber' );
      this.setState( {
        isSameAsShipping: true,
        cardType: ( <DefaultCreditCard/> )
      } );
    }
  }

  toggleHinttext(){
    this.setState( { showHintText:true } );
    this.props.toggleSecurityCode( true, this.props.displayType );
  }

  toggleSecurityIcon(){
    this.props.toggleSecurityCode( false, this.props.displayType );
  }
  /**
   * Renders the PaymentForm component
   */
  render(){



    const {
      paymentError,
      addEditCreditCard,
      handleSubmit
    } = this.props;

    const isRequired = ( val ) =>{
      return ( required( formatMessage )( val ) );
    }
    let creditCardValue;
    if( has( this.props, 'editCreditCardData.creditCardNumber' ) ){
      creditCardValue = this.props.editCreditCardData.creditCardNumber
    }

    if( has( this.props, 'formData.values.creditCardNumber' ) ){
      creditCardValue = this.props.formData.values.creditCardNumber
    }

    return (
      <div className='PaymentForm'>
        { ( () =>{
          return (
            <div
              id='paymentContainer'
              className='PaymentForm__FormContainer'
              { ...( ( addEditCreditCard !== 'yes' && ( isUndefined( this.props.addDoneButton ) || !this.props.addDoneButton ) ) && { onBlur: this.handleSubmitCreditCard } ) }
            >
              <form
                onSubmit={ handleSubmit( this.addNewPaymentMethod ) }
              >
                <div>
                  <div className='PaymentForm__field PaymentForm__field--creditCard'>

                    { ( () =>{
                      if( paymentError ){
                        return (
                          <div className='PaymentForm__errorMessages'>

                          </div>
                        )
                      }
                    } )() }
                    <div className='PaymentForm__cardType'>

                      { ( () =>{
                        if( this.state.cardType === 'Discover' ){
                          return ( <Discover/> );
                        }

                        else if( this.state.cardType === 'AmericanExpress' ){
                          return ( <Amex/> );
                        }

                        else if( this.state.cardType === 'Mastercard' ){
                          return ( <Mastercard/> );
                        }

                        else if( this.state.cardType === 'Ultamate Rewards Credit Card' ){
                          return ( <UltamateRewardsCC/> );
                        }
                        else if( this.state.cardType === 'Ultamate Rewards MasterCard' ){
                          return ( <UltamateRewardsMC/> );
                        }
                        else if( this.state.cardType === 'Visa' ){
                          return ( <Visa/> );
                        }
                        else {
                          return ( <DefaultCreditCard/> );
                        }
                      } )() }
                    </div>
                    <div
                      className='PaymentForm__creditCardCollapseControl'
                    >
                      <div className='PaymentForm__creditCardField'>
                        { ( () =>{
                          if( this.state.loadMaskCreditcard ){
                            return (
                              <InputField
                                name='creditCardNumber'
                                type='tel'
                                formatter={ { creditcard: {} } }
                                label={ formatMessage( messages.creditCardNumber ) }
                                handleChange={ this.activateCreditCardField }
                                svg={ this.state.cardType }
                                value={ this.state.maskCreditCardNumber }
                                formName={ 'payment & billing' }
                                trackAnalytics={ true }
                                autoComplete='cc-number'
                              >
                              </InputField>
                            );
                          }
                          else {
                            return (
                              <InputField
                                name='creditCardNumber'
                                type='tel'
                                formatter={ { creditcard: {} } }
                                formater=''
                                handleChange={ this.getCCIcon }
                                label={ formatMessage( messages.creditCardNumber ) }
                                svg={ this.state.cardType }
                                value={ this.state.creditCardNumber }
                                formName={ 'payment & billing' }
                                autoComplete='cc-number'
                                trackAnalytics={ true }
                              >
                              </InputField>
                            );
                          }
                        } )() }
                      </div>

                    </div>
                    { ( () =>{
                      if( this.state.cardType === 'defaultCreditCard' && ( !isEmpty( creditCardValue ) && creditCardValue.length > 11 ) ){
                        return (
                          <ResponseMessages
                            message={ formatMessage( messages.DefaultCard ) }
                          />
                        );
                      }
                    } )() }
                    { /* TODO: when validations are complete, this should open after the credit card value is validated as acceptable */ }
                    <div>
                      { ( () =>{
                        if( this.state.cardType === 'Discover' || this.state.cardType === 'AmericanExpress' || this.state.cardType === 'Mastercard' || this.state.cardType === 'Visa' || ( this.state.cardType === 'Ultamate Rewards MasterCard' && this.state.nickName !== 'tempCBCC' ) ){
                          return (
                            <Collapse in={ !isEmpty( creditCardValue ) }>

                              <div className='PaymentForm__dualFieldContainer'>
                                <div className='PaymentForm__field PaymentForm__field--expirationDate'>
                                  <InputField
                                    name='expirationDate'
                                    type='tel'
                                    formatter={ { pattern: '99/9999' } }
                                    placeholder={ formatMessage( messages.expFormat ) }
                                    label={ formatMessage( messages.expirationDate ) }
                                    value={ this.state.expirationDate }
                                    formName={ 'payment & billing' }
                                    trackAnalytics={ true }
                                    autoComplete='cc-exp'
                                  />
                                </div>
                                <div className='PaymentForm__field PaymentForm__field--securityCode'>
                                  { ( ()=>{
                                    if( ( ( has( this.props, 'formData.values.securityCode' ) && this.props.formData.values.securityCode !== '' ) || this.props.showSecurityIcon ) ){
                                      return (
                                        <div className='PaymentForm__field--securityCode--icon'>
                                          <span>
                                            { ( () =>{
                                              if( this.state.cardType === 'AmericanExpress' ){
                                                return ( <CreditCardAmexFrontView/> );
                                              }
                                              else {
                                                return ( <CreditCardBackView/> );
                                              }
                                            } )() }
                                          </span>
                                        </div>
                                      )
                                    }
                                  } )() }
                                  <InputField
                                    name='securityCode'
                                    type='tel'
                                    autoComplete='off'
                                    formatter={ ( this.state.cardType === 'AmericanExpress' ) ? { pattern: '9999' } : { pattern: '999' } }
                                    label={ formatMessage( messages.securityCode ) }
                                    value={ ( this.props.showCVV ) ? this.state.securityCode : '' }
                                    formName={ 'payment & billing' }
                                    trackAnalytics={ true }
                                    maskedToggleTarget='securityCode'
                                    showMaskedValue={ this.props.checkoutFormConfig.showHideCheckoutToggleData.securityCode }
                                    onFocus={ this.toggleHinttext.bind( this ) }
                                    handleBlur={ this.toggleSecurityIcon }
                                  >
                                  </InputField>
                                  { ( () =>{
                                    if( this.state.showHintText ){
                                      return (
                                        <div className='hinttext'>
                                          { this.state.cardType === 'AmericanExpress' ? formatMessage( messages.SecurityCodeHintTextAmex ) : formatMessage( messages.SecurityCodeHintText ) }
                                        </div>
                                      )
                                    }
                                  } )() }

                                </div>
                              </div>
                            </Collapse>
                          );
                        }
                        else {
                          return null;
                        }
                      } )() }
                    </div>
                  </div>

                  <div className='PaymentForm__billingAddressContainer'>

                    <div className='PaymentForm__paymentFOrmSameasShippingPanel Gutter'>
                      <div className='PaymentForm__billingHeader '>
                        <div className='PaymentForm__billingTitle'>
                          { formatMessage( messages.billingAddress ) }
                        </div>
                        <div className='PaymentForm__toggleButtonContainer'>
                          <p className='PaymentForm__sameShippingMessage'>
                            { formatMessage( messages.sameAsShipping ) }
                          </p>
                          <div className='PaymentForm__toggleButton'>
                            <label htmlFor='paymentFormToggleButtonId' className='sr-only'>{ formatMessage( messages.sameAsShipping ) }</label>
                            <ToggleButton
                              id='paymentFormToggleButtonId'
                              name='paymentAddressFormToggle'
                              value={ this.state.isSameAsShipping }
                              isChecked={ this.state.isSameAsShipping }
                              onClick={ this.sameAsShippingToggle }
                            />
                          </div>
                        </div>
                      </div>

                      { ( () =>{
                        if( this.state.isSameAsShipping ){
                          if( this.props.shippingInfo && this.props.shippingInfo.shippingAddress ){
                            const shippingInformation = this.props.shippingInfo.shippingAddress;
                            let address2Data = '';
                            if( shippingInformation.address2 !== null ){
                              address2Data = shippingInformation.address2;
                            }
                            this.toggleAddress2Validation();
                            return (
                              <div className='PaymentForm__SameAsShipping'>
                                <p>
                                  { shippingInformation.firstName } { shippingInformation.lastName }
                                </p>
                                <p>
                                  { shippingInformation.address1 } { address2Data } { shippingInformation.city } { shippingInformation.state } { shippingInformation.postalCode }
                                </p>
                                <p>
                                  { shippingInformation.phoneNumber }
                                </p>
                              </div>
                            )
                          }
                        }
                        else {
                          return (
                            <div className='PaymentForm__BillingAddressForm'>
                              <CheckoutAddressForm
                                formName='paymentAddressForm'
                                form={ this.props.form }
                                validate={ this.props.validate }
                                isAddFormTag='no'
                                editCreditCardData={ this.props.editCreditCardData }
                                address2Open={ this.props.checkoutFormAddress2Open.paymentAddressForm }
                                toggleAddress2FieldDisplay={ this.props.toggleInputFieldPaymentDisplay }
                                handleScrollView={ this.props.handleScrollView }
                                checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                                editAddressData={ this.props.editAddressData }
                                checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                                changeShippingAddressView={ this.changeShippingAddressView }
                                toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                                addressOpen={ this.props.addressOpen }
                                toggleAddressFieldDisplay={ this.props.toggleAddressFieldDisplay }
                                handleSubmit={ this.props.handleSubmit }
                                setEditCreditCardData={ this.props.setEditCreditCardData }
                              />
                            </div>
                          )
                        }
                      } )() }
                    </div>

                    { ( () =>{
                      if( addEditCreditCard === 'yes' || this.props.addDoneButton ){
                        return (
                          <div className='PaymentForm__billingAddressContainer PaymentForm__addEditCreditCard'>
                            { ( ()=>{
                              if( !this.props.editCreditCardData.isPrimary ){
                                return (
                                  <div className='PaymentForm__toggleSection'>
                                    <Divider dividerType={ 'gray' }/>
                                    <div className='PaymentForm__toggleButtonContainer Gutter'>
                                      <div className='PaymentForm__makePrimaryAddress'>
                                        { formatMessage( messages.makePrimaryCCText ) }
                                      </div>
                                      <div className='PaymentForm__toggleButton'>
                                        <label htmlFor='isPrimary' className='sr-only'>{ formatMessage( messages.makePrimaryCCText ) }</label>
                                        <ToggleButton
                                          name='isPrimary'
                                          isChecked={ this.state.isPrimaryPaymentMethod }
                                          onClick={ this.makePrimaryCCToggle }
                                        />
                                      </div>
                                    </div>
                                  </div>
                                )
                              }
                            } )() }
                            <div className='PaymentForm__cancelDone'>
                              <Divider dividerType={ 'gray' }/>
                              <div className='PaymentForm__creditCardFooterMessage Gutter'>
                                { formatMessage( messages.creditCardFooterMessage ) }
                              </div>
                              <div className='PaymentForm__cancelAndDone Gutter'>
                                { ( ()=>{
                                  if( !this.props.addDoneButton ){
                                    return (
                                      <div className='PaymentForm__cancelAndDone--cancel'>
                                        <Anchor
                                          url='#'
                                          ariaLabel={ formatMessage( messages.cancelAriaLabel ) }
                                          title={ formatMessage( messages.cancelAriaLabel ) }
                                          clickHandler={ this.cancelAddCreditCard }
                                        >
                                          { formatMessage( messages.cancel ) }
                                        </Anchor>
                                        <span className='PaymentForm__cancelDone--space'>\</span>
                                      </div>
                                    )
                                  }
                                } )() }

                                <Button
                                  inputTag='button'
                                  btnType='submit'
                                  btnSize='xs'
                                  btnOption='link'
                                  btnOutLine={ false }
                                  title={ formatMessage( messages.doneAriaLabel ) }
                                >
                                  { formatMessage( messages.save ) }
                                </Button>
                              </div>
                            </div>
                          </div>
                        );
                      }
                    } )() }

                  </div>

                </div>
              </form>
            </div>
          );
        } )() }
      </div>
    );
  }
}

PaymentForm.propTypes = propTypes;

const mapStateToProps = ( state ) =>{
  return {
    formData: state.form.paymentForm,
    shippingForm: state.form.Shipping,
    paymentValid: isValid( 'paymentForm' )( state ),
    paymentDirty: getFormValues( 'paymentForm' )( state ),
    shippingValid: isValid( 'Shipping' )( state )
  };
}
const mapDispatchToProps = ( dispatch ) =>{
  return {

    changeFieldValue: function( field, value ){
      dispatch( change( 'paymentForm', field, value ) )
    }
  };
}
export const validate = ( values, props ) =>{
  const errors = {};
  let requiredFields = [];

  let isValidSecurityCode = validateSecurityCode( has( props, 'values.creditCardNumber' ) ? props.values.creditCardNumber : '' );

  if( props.editCreditCardData ){
    let ccvalue = '****' + props.editCreditCardData.creditCardNumber;
    if( props.values.creditCardNumber && props.values.creditCardNumber === ccvalue ){
      isValidSecurityCode = validateSecurityCode( props.editCreditCardData.creditCardType );
    }
  }

  // validate the anonymous usecase
  if( values.formType === 'anonymous' || isUndefined( values.formType ) ){
    requiredFields = ['creditCardNumber', 'expirationDate', 'securityCode', 'emailaddresspaymentAddressForm', 'firstNamepaymentAddressForm', 'lastNamepaymentAddressForm', 'address1paymentAddressForm',
      'citypaymentAddressForm', 'state', 'postalCodepaymentAddressForm', 'phoneNumberpaymentAddressForm'];
  }

  // This is added so that we do not validate against a hidden fields otherwise they get tracked as an error in Omniture.
  // Here we simply look if the billinaddressform div is present if not we remove the fields.
  if( document.querySelector( 'div.PaymentForm__BillingAddressForm' ) === null ){
    pull( requiredFields, 'emailaddresspaymentAddressForm', 'firstNamepaymentAddressForm', 'lastNamepaymentAddressForm', 'address1paymentAddressForm',
      'citypaymentAddressForm', 'state', 'postalCodepaymentAddressForm', 'phoneNumberpaymentAddressForm' );
  }

  requiredFields.map(
    field =>{
      if( !values[field] ){

        errors[field] = required( values[field] );
      }

    }
  );


  if( props.editCreditCardData ){
    let ccvalue = '****' + props.editCreditCardData.creditCardNumber;
    if( values.creditCardNumber && values.creditCardNumber !== ccvalue ){
      errors.creditCardNumber = validateCreditCard( values.creditCardNumber );
    }
  }
  else if( values.creditCardNumber ){
    errors.creditCardNumber = validateCreditCard( values.creditCardNumber );
  }


  if( values.expirationDate ){
    errors.expirationDate = validateCreditCardExpiry( values.expirationDate );
  }

  // securityCode
  if( values.securityCode ){
    errors.securityCode = isValidSecurityCode( values.securityCode );
  }
  if( values.emailaddress ){
    errors.emailaddress = validateEmail( values.emailaddress );
  }

  if( values.phoneNumber ){

    errors.phoneNumber = validatePhone( values.phoneNumber );
  }


  if( values.postalCode ){
    errors.postalCode = validateZipCode( values.postalCode );
  }

  return errors;
}

export const onSubmitFail = ( errors, dispatch, submitError, props ) =>{
  let errorFields = keys( errors );
  let evt = {
    'name': 'trackErrorDisplayed',
    'data': errorFields
  }
  dispatch( analyticActions.triggerAnalyticsEvent( evt ) );

  // handle scroll to error fields
  props.handleScrollToFormError( errors );
}

PaymentForm.propTypes = propTypes;

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return reduxForm( {
    form: 'paymentForm',
    validate,
    onSubmitFail
  } )( connect( mapStateToProps, mapDispatchToProps )( PaymentForm ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );