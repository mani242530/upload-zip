/*
 * PaymentForm Messages
 *
 * This contains all the text for the PaymentForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  globalPaymentError: {
    id: 'i18n.PaymentForm.globalPaymentError',
    defaultMessage: 'Payment error messages go here see JIRA'
  },
  creditCardNumber: {
    id: 'i18n.PaymentForm.creditCardNumber',
    defaultMessage: 'Credit Card Number'
  },
  expirationDate: {
    id: 'i18n.PaymentForm.expirationDate',
    defaultMessage: 'Expiration Date'
  },
  securityCode: {
    id: 'i18n.PaymentForm.securityCode',
    defaultMessage: 'Security Code'
  },
  billingAddress: {
    id: 'i18n.PaymentForm.billingAddress',
    defaultMessage: 'Billing Address'
  },
  sameAsShipping: {
    id: 'i18n.PaymentForm.sameAsShipping',
    defaultMessage: 'Same as Shipping'
  },
  firstName: {
    id: 'i18n.PaymentForm.firstName',
    defaultMessage: 'First Name'
  },
  lastName: {
    id: 'i18n.PaymentForm.lastName',
    defaultMessage: 'Last Name'
  },
  address: {
    id: 'i18n.PaymentForm.address',
    defaultMessage: 'Address'
  },
  unitNumberButton: {
    id: 'i18n.PaymentForm.unitNumberButton',
    defaultMessage: 'Add an apartment, suite, unit, building, floor, etc.'
  },
  unitNumber: {
    id: 'i18n.PaymentForm.unitNumber',
    defaultMessage: 'Apt/Suite Number'
  },
  zipCode: {
    id: 'i18n.PaymentForm.zipCode',
    defaultMessage: 'ZIP Code'
  },
  city: {
    id: 'i18n.PaymentForm.city',
    defaultMessage: 'City'
  },
  state: {
    id: 'i18n.PaymentForm.state',
    defaultMessage: 'State'
  },
  email: {
    id: 'i18n.PaymentForm.email',
    defaultMessage: 'Email Address'
  },
  phoneNumber: {
    id: 'i18n.PaymentForm.phoneNumber',
    defaultMessage: 'Phone Number'
  },
  expFormat:{
    id: 'i18n.PaymentForm.expFormat',
    defaultMessage: 'MM/YYYY'
  },
  makePrimaryCCText: {
    id: 'i18n.PaymentForm.makePrimaryCCText',
    defaultMessage: 'Make this my primary payment method'
  },
  save: {
    id: 'i18n.PaymentForm.save',
    defaultMessage: 'Save'
  },
  doneAriaLabel: {
    id: 'i18n.PaymentForm.doneAriaLabel',
    defaultMessage: 'Click or enter to add a new payment method'
  },
  cancel: {
    id: 'i18n.PaymentForm.cancel',
    defaultMessage: 'Cancel'
  },
  cancelAriaLabel: {
    id: 'i18n.PaymentForm.cancelAriaLabel',
    defaultMessage: 'Click to cancel the changes'
  },
  SecurityCodeHintText: {
    id: 'i18n.PaymentInformation.ChangeCCPaypal',
    defaultMessage: '3 digit code on card back'
  },
  SecurityCodeHintTextAmex: {
    id: 'i18n.PaymentInformation.ChangeCCPaypal',
    defaultMessage: '4 digit code on card front'
  },
  DefaultCard: {
    id: 'i18n.PaymentInformation.DefaultCard',
    defaultMessage: 'Sorry, we cannot accept this credit card type.'
  },
  creditCardFooterMessage:{
    id: 'i18n.PaymentInformation.creditCardFooterMessage',
    defaultMessage: 'Your credit card will be saved to your account.'

  }
} );
