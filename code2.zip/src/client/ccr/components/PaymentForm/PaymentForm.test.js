import React from 'react';
import ReactDOM from 'react-dom';
import PaymentForm, { connectFunction, mapStateToProps,
  validateEmail,
  validatePhone,
  validateZipCode,
  validateCreditCard,
  validateCreditCardExpiry,
  required } from './PaymentForm';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import FormValidationMessages from 'utils/FormValidations/FormValidations.messages';
import { formatMessage } from 'shared/components/Global/Global';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import messages from './PaymentForm.messages';
let store = configureStore( {}, CONFIG );
store.getState().checkoutPage.creditCardDetails.paymentInfo = { paymentDetails : {} };
jest.mock( 'utils/FormValidations/FormValidations', ()=>{
  return {
    requiredValidation:()=>jest.fn(),
    required: () => jest.fn(),
    validateEmail:()=>jest.fn(),
    validatePhone:()=>jest.fn(),
    validateZipCode:()=>jest.fn(),
    validateCreditCard:()=>jest.fn(),
    validateCreditCardExpiry:()=>jest.fn(),
    validateSecurityCode:()=>jest.fn(),
    validate: () => jest.fn(),
    validationKeys: {}
  }
} );

describe( '<PaymentForm />', () =>{
  let component;
  let props = {
    submitShippingAddressForm: jest.fn(),
    toggleAddressFieldDisplayPaymentForm: jest.fn(),
    setCreditCardPaymentType: jest.fn(),
    handleScrollToFormError: jest.fn(),
    onSubmitFail: jest.fn(),
    showCVV:false,
    isAddCreditCard: false,
    checkoutFormAddressOpen: {
      paymentAddressForm: false,
      shippingAddressForm: true
    },
    addEditCreditCard: 'yes',
    setEditCreditCardData: jest.fn(),
    setEditAddressData: jest.fn(),
    checkoutFormAddress2Open:{},
    editCreditCardData: {
      creditCardNumber:'4111111111112224',
      expirationDate:'09/21',
      firstNamepaymentAddressForm:'Pushpendra',
      lastNamepaymentAddressForm:'Kabdaula',
      address1paymentAddressForm:'1000 remngton blvd',
      postalCodepaymentAddressForm:'07105',
      citypaymentAddressForm:'Boolingbrook',
      state:'IL',
      phoneNumberpaymentAddressForm:'(123) 456-7890',
      firstNameshippingAddressForm:'Jane',
      lastNameshippingAddressForm:'Doe',
      phoneNumbershippingAddressForm:'(510)-213-8347',
      address1shippingAddressForm:'1000 Remington Boulevard',
      address2shippingAddressForm:'Suite # 120',
      cityshippingAddressForm:'Bolingbrook',
      postalCodeshippingAddressForm:'60564',
      isPrimary:false
    },
    checkoutFormConfig:{
      showHideCheckoutToggleData:{
        securityCode: true
      }
    },
    shippingInfo: {
      shippingAddress:{
        firstName: 'abc'
      }
    },
    showSecurityIcon: false,
    handleScrollView: jest.fn()
  }

  it( 'renders without crashing and scrolls to errors fields', () => {
    props.paymentError = true;
    let paymentcomponent = mountPaymentForm( props );
    expect( paymentcomponent.find( 'PaymentForm' ).length ).toBe( 1 );
    paymentcomponent.onSubmitFail = jest.fn();
    paymentcomponent.find( 'PaymentForm' ).find( 'form' ).simulate( 'submit' );
    expect( paymentcomponent.find( '.PaymentForm__errorMessages' ).length ).toBe( 1 );
  } );

  it( 'renders without crashing', () =>{
    component = mountPaymentForm( props );
    expect( component.find( 'PaymentForm' ).length ).toBe( 1 );
  } );

  it( 'should NOT render an error if \'paymentError\' is false', () =>{
    props.paymentError = false;
    component = mountPaymentForm( props );

    expect( component.find( '.PaymentForm__errorMessages' ).length ).toBe( 0 );
  } );

  it( 'should render an error if \'paymentError\' is true', () =>{
    props.paymentError = true;
    component = mountPaymentForm( props );

    expect( component.find( '.PaymentForm__errorMessages' ).length ).toBe( 1 );
  } );

  props.paymentError = true;
  props.cardInfoOpen = true;
  let component2 = mountPaymentForm( props );
  it( 'should render an error if \'paymentError\' is true', () =>{
    expect( component2.find( '.PaymentForm__errorMessages' ).length ).toBe( 1 );
  } );
  let props1 = {
    toggleAddressFieldDisplayPaymentForm: jest.fn(),
    checkoutFormAddressOpen: {
      paymentAddressForm: false,
      shippingAddressForm: true
    },
    setCreditCardPaymentType: jest.fn(),
    checkoutFormAddress2Open:{},
    editCreditCardData:{},
    formData: {
      values: { creditCardNumber: '6011334455667788' }
    },
    shippingInfo: {
      firstName: 'abc'
    },
    addDoneButton: false,
    paymentError:false,
    checkoutFormConfig:{
      showHideCheckoutToggleData:{
        securityCode: false
      }

    },
    handleScrollView: jest.fn()
  };


  let component3 = mountPaymentForm( props1 );
  it( 'should render fields for expiration date and security code if the card number has been entered', () =>{
    expect( component3.find( '.PaymentForm__creditCardField' ).length ).toBe( 1 );
    component3.isCardTypeValid = jest.fn( () => true );
    component3.find( '#creditCardNumber' ).simulate( 'change', { target: { value: '411111111111' } } )
    expect( component3.find( '.PaymentForm__field--expirationDate' ).length ).toBe( 1 );
    expect( component3.find( '.PaymentForm__field--securityCode' ).length ).toBe( 1 );
    expect( component3.find( '.PaymentForm__field--securityCode InputField' ).props().value ).toBe( '' );
  } );

  it( 'check for onblur event tigger when addDoneButton addDoneButton props passed as false', () =>{
    let props5 = {
      toggleAddressFieldDisplayPaymentForm: jest.fn(),
      handleSubmitCreditCard: jest.fn(),
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      checkoutFormAddress2Open:{},
      editCreditCardData:{},
      formData: {
        values: { creditCardNumber: '6011334455667788' }
      },
      shippingInfo: {
        firstName: 'abc',
        shippingAddress: {}
      },
      addDoneButton: false,
      addEditCreditCard:'no',
      paymentError:false,
      checkoutFormConfig:{
        showHideCheckoutToggleData:{
          securityCode: false
        }
      },
      handleScrollView: jest.fn()
    };

    let PaymentFormMock = connectFunction( mapStateToProps );
    let component3 = mountWithIntl(
      <Provider store={ store }>
        <PaymentFormMock { ...props5 }/>
      </Provider>
    );

    // Check that onBlur attribute is available
    expect( component3.find( '#paymentContainer' ).prop( 'onBlur' ) ).toBeTruthy( );

    let mock3vent = jest.fn();
    let node = component3.find( 'PaymentForm' ).instance();
    node.handleSubmitCreditCard = mock3vent;
    node.forceUpdate();
    component3.find( '#paymentContainer' ).simulate( 'blur' );
    expect( mock3vent ).toBeCalled();
  } );

  it( 'check for onblur event not to tigger when addDoneButton props passed as true', () =>{
    let props5 = {
      toggleAddressFieldDisplayPaymentForm: jest.fn(),
      handleSubmitCreditCard: jest.fn(),
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      checkoutFormAddress2Open:{},
      editCreditCardData:{},
      formData: {
        values: { creditCardNumber: '6011334455667788' }
      },
      shippingInfo: {
        firstName: 'abc',
        shippingAddress: {}
      },
      addDoneButton: true,
      addEditCreditCard:'yes',
      paymentError:false,
      checkoutFormConfig:{
        showHideCheckoutToggleData:{
          securityCode: false
        }
      },
      handleScrollView: jest.fn()
    };

    let PaymentFormMock = connectFunction( mapStateToProps );
    let component3 = mountWithIntl(
      <Provider store={ store }>
        <PaymentFormMock { ...props5 }/>
      </Provider>
    );

    // Check that onBlur attribute is not available
    expect( component3.find( '#paymentContainer' ).prop( 'onBlur' ) ).toBeFalsy( );

    let mock3vent = jest.fn();
    let node = component3.find( 'PaymentForm' ).instance();
    node.handleSubmitCreditCard = mock3vent;
    node.forceUpdate();
    component3.find( '#paymentContainer' ).simulate( 'blur' );
    expect( mock3vent ).not.toBeCalled();
  } );

  props.editAddressData = {};
  let component5 = mountPaymentForm( props );

  it( 'should NOT render non-editable text for shipping address if \'isSameAsShipping\' is set to false', () =>{
    component5.setState( { isSameAsShipping: false } );
    component5.find( { name:'paymentAddressFormToggle' } ).at( 4 ).simulate( 'click' );
    expect( component5.find( '.PaymentForm__SameAsShipping' ).length ).toBe( 0 );
  } );

  it( 'should have security code field with type tel', () => {
    expect( component3.find( '#securityCode' ).props().type ).toBe( 'tel' );
  } );

  it( 'should have auto complete flags on the credit card and expiry', () => {
    component = mountPaymentForm( props );
    component.find( 'PaymentForm' ).instance().state.cardType = 'Discover';
    component = mountPaymentForm( props );
    let rendered = component.find( 'InputField' );
    expect( rendered.at( 0 ).props().autoComplete ).toBe( 'cc-number' );
  } );

  it( 'should have security code field with autocomplete off', () => {
    expect( component3.find( '#securityCode' ).props().autoComplete ).toBe( 'off' );
  } );

  it( 'should make service calls when onblur functionality', () => {
    store.getState().form.paymentForm= {
      values: {
        cardType : 'Visa',
        creditCardNumber: '4111 1111 1111 2224',
        expirationDate: '11/23',
        securityCode: '123'
      }
    }
    let props1 = {
      toggleAddressFieldDisplayPaymentForm: jest.fn(),
      setCreditCardPaymentType : jest.fn(),
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      checkoutFormAddress2Open:{},
      editCreditCardData:{},
      shippingInfo: {
        shippingAddress: {
          firstName: 'Jane',
          lastName: 'Doe',
          address1: '1000 Remington Boulevard',
          address2: 'Suite # 120',
          city: 'Bolingbrook',
          state: 'IL',
          postalCode: '60564',
          phoneNumber: '(510)-213-8347'
        }
      },
      handleScrollView: jest.fn()
    };
    let component3 = mountPaymentForm( props1 );
    let node1 = component3.find( 'PaymentForm' ).instance();
    node1.state.isSameAsShipping = true;
    node1.state.cardType='Ultamate Rewards Credit Card';
    node1.state.initialPaymentData = {
      values: {
        creditCardNumber: '4111 1111 1111 2223',
        expirationDate: '11/23',
        securityCode: '123'
      }
    };
    node1.savePaymentDetails=jest.fn();
    jest.useFakeTimers();
    component3.find( '#paymentContainer' ).simulate( 'focus' );
    component3.find( '#paymentContainer' ).simulate( 'blur' );
    jest.runAllTimers();
    expect( node1.savePaymentDetails ).toBeCalled();
    node1.handleSubmitCreditCard=jest.fn();
    node1.forceUpdate();
    component3.find( '#paymentContainer' ).simulate( 'focus' );
    component3.find( '#paymentContainer' ).simulate( 'blur' );
    expect( node1.handleSubmitCreditCard ).toBeCalled();
  } );

  it( 'should make service calls on click of save option with the same data after clearing the error message -submit form functionality -BillingAddress same as ShippindAddress ', () => {
    let updatePaymentServiceResponse =jest.fn();
    store.getState().form.paymentForm= {
      values: {
        cardType : 'Visa',
        creditCardNumber: '4111 1111 1111 1111',
        expirationDate: '11/2022',
        securityCode: '111'
      }
    }
    let props1 = {
      toggleAddressFieldDisplayPaymentForm: jest.fn(),
      setCreditCardPaymentType : jest.fn(),
      handleAddNewCreditCard :jest.fn(),
      setTempPaymentCCVNumber:jest.fn(),
      updatePaymentStatus:jest.fn(),
      updatePaymentServiceResponse:updatePaymentServiceResponse,
      formData: {
        values: { creditCardNumber: '4111111111111111', securityCode:'111' }
      },
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      checkoutFormConfig:{
        showHideCheckoutToggleData:{
          securityCode: true
        }
      },
      creditCardDetails:{
        isPaymentErrorCleared:true
      },
      checkoutFormAddress2Open:{},
      editCreditCardData:{},
      paymentError:[],
      shippingInfo: {
        shippingAddress: {
          firstName: 'Jane',
          lastName: 'Doe',
          address1: '1000 Remington Boulevard',
          address2: 'Suite # 120',
          city: 'Bolingbrook',
          state: 'IL',
          postalCode: '60564',
          phoneNumber: '(510)-213-8347'
        }
      },
      handleScrollView: jest.fn()
    };
    let component3 = mountPaymentForm( props1 );
    let node1 = component3.find( 'PaymentForm' );
    node1.instance().state.isSameAsShipping = true;
    node1.instance().state.cardType='Visa';
    node1.instance().state.initialPaymentData = {
      cardType : 'Visa',
      creditCardNumber: '4111 1111 1111 1111',
      expirationDate: '11/2022',
      securityCode: '111'
    };
    node1.instance().addNewPaymentMethod=jest.fn();
    node1.instance().updatePaymentServiceResponse=jest.fn();
    jest.useFakeTimers();
    component3.find( 'PaymentForm' ).find( 'form' ).simulate( 'submit' );
    jest.runAllTimers();
    node1.instance().forceUpdate();
    expect( updatePaymentServiceResponse ).toBeCalled();
  } );
  it( 'should not invoke assignPaymentAddress() on update if there is an error and the error have been cleared on edit of paymentform fields ', () => {
    let assignPaymentAddressMock =jest.fn();
    store.getState().form.paymentForm= {
      values: {
        cardType : 'Visa',
        creditCardNumber: '4111 1111 1111 1122',
        expirationDate: '11/2022',
        securityCode: '111'
      }
    }
    let props1 = {
      toggleAddressFieldDisplayPaymentForm: jest.fn(),
      setCreditCardPaymentType : jest.fn(),
      handleAddNewCreditCard :jest.fn(),
      setTempPaymentCCVNumber:jest.fn(),
      updatePaymentStatus:jest.fn(),
      updatePaymentServiceResponse:jest.fn(),
      formData: {
        values: { creditCardNumber: '411111111111112', securityCode:'111' }
      },
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      checkoutFormConfig:{
        showHideCheckoutToggleData:{
          securityCode: true
        }
      },
      creditCardDetails:{
        paymentInfo:{
          paymentDetails:{
            creditCardNumber : '9887',
            creditCardType : 'AmericanExpress',
            expirationMonth : '11',
            expirationYear: '3333'
          }
        },
        isPaymentErrorCleared:true
      },
      checkoutFormAddress2Open:{},
      editCreditCardData:{},
      paymentError:[],
      shippingInfo: {
        shippingAddress: {
          firstName: 'Jane',
          lastName: 'Doe',
          address1: '1000 Remington Boulevard',
          address2: 'Suite # 120',
          city: 'Bolingbrook',
          state: 'IL',
          postalCode: '60564',
          phoneNumber: '(510)-213-8347'
        }
      },
      handleScrollView: jest.fn()
    };
    let props2 = {
      toggleAddressFieldDisplayPaymentForm: jest.fn(),
      setCreditCardPaymentType : jest.fn(),
      handleAddNewCreditCard :jest.fn(),
      setTempPaymentCCVNumber:jest.fn(),
      updatePaymentStatus:jest.fn(),
      updatePaymentServiceResponse:jest.fn(),
      formData: {
        values: { creditCardNumber: '411111111111112', securityCode:'111' }
      },
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      checkoutFormConfig:{
        showHideCheckoutToggleData:{
          securityCode: true
        }
      },
      creditCardDetails:{
        paymentInfo:{
          paymentDetails:{
            creditCardNumber : '9887',
            creditCardType : 'AmericanExpress',
            expirationMonth : '11',
            expirationYear: '3333'
          }
        }
      },
      checkoutFormAddress2Open:{},
      editCreditCardData:{
        creditCardNumber : '111111'
      },
      paymentError:[],
      shippingInfo: {
        shippingAddress: {
          firstName: 'Jane',
          lastName: 'Doe',
          address1: '1000 Remington Boulevard',
          address2: 'Suite # 120',
          city: 'Bolingbrook',
          state: 'IL',
          postalCode: '60564',
          phoneNumber: '(510)-213-8347'
        }
      },
      handleScrollView: jest.fn()
    };
    let component3 = mountPaymentForm( props1 );
    component3.find( 'PaymentForm' ).instance().assignPaymentAddress = assignPaymentAddressMock;
    component3.find( 'PaymentForm' ).instance().componentDidUpdate( props1 );
    expect( assignPaymentAddressMock ).not.toBeCalled();
    component3.find( 'PaymentForm' ).instance().componentDidUpdate( props2 );
    expect( assignPaymentAddressMock ).not.toBeCalled();
  } );
  it( 'should render toggle button component when primary address flag is false', () => {
    let component = mountPaymentForm( props );
    expect( component.find( '.PaymentForm__toggleSection' ).length ).toBe( 1 );
    expect( component.find( '.PaymentForm__toggleSection .PaymentForm__toggleButtonContainer ToggleButton' ).length ).toBe( 1 );
  } );

  it( 'should not render toggle button component when primary address flag is true', () => {
    props.editCreditCardData.isPrimary=true;
    let component2 = mountPaymentForm( props );
    expect( component2.find( '.PaymentForm__toggleSection' ).length ).toBe( 0 );
    expect( component2.find( '.PaymentForm__toggleSection .PaymentForm__toggleButtonContainer ToggleButton' ).length ).toBe( 0 );
  } );

  it( 'should clear fields when we toggle for a guest user', () => {
    // If user is a guest, on toggle to off, we should clear all fields.
    props.isSignedIn = false;
    props.editCreditCardData.isPrimary = false;
    let component4 = mountPaymentForm( props );
    let node4 = component4.find( 'PaymentForm' ).instance();
    node4.state.isSameAsShipping = true;
    component4.find( '.PaymentForm__toggleSection' ).simulate( 'click' );
    expect( component4.find( 'PaymentForm' ).at( 0 ).props().editAddressData ).toEqual( {} ); // Address object should be empty
  } );

  it( 'should test validateEmail', () => {
    expect( validateEmail( 'test@TEST.COM' ) ).toBeUndefined();
    expect( validateEmail( 'test@TESTcOM' ) ).toBe( formatMessage( FormValidationMessages.invalidEmail ) );
  } );

  it( 'should test required', () => {
    expect( required( 't' ) ).toBeUndefined();
    expect( required( '' ) ).toBe( formatMessage( FormValidationMessages.required ) );
  } );

  it( 'should test validatePhone', () => {
    expect( validatePhone( '123-456-7890' ) ).toBeUndefined();
    expect( validatePhone( '123-456-saf' ) ).toBe( formatMessage( FormValidationMessages.invalidPhoneNumber ) );
  } );

  it( 'should test validateZipCode', () => {
    expect( validateZipCode( '12345' ) ).toBeUndefined();
    expect( validateZipCode( '1256' ) ).toBe( formatMessage( FormValidationMessages.invalidZipCode ) );
  } );

  it( 'should test validateCreditCard', () => {
    expect( validateCreditCard( '1234 5678 9012 3456' ) ).toBeUndefined();
    expect( validateCreditCard( '3474 567890 23456' ) ).toBeUndefined();
    expect( validateCreditCard( '1256' ) ).toBe( formatMessage( FormValidationMessages.validateCreditCard ) );
  } );

  it( 'should test validateCreditCardExpiry', () => {
    expect( validateCreditCardExpiry( '12/2018' ) ).toBeUndefined();
    expect( validateCreditCardExpiry( '1/2007' ) ).toBe( formatMessage( FormValidationMessages.validateCCExpiryOnLessDigit ) );
    expect( validateCreditCardExpiry( '12/2007' ) ).toBe( formatMessage( FormValidationMessages.validateCreditCardExpiry ) );
  } );

  it( 'should test getCCIcon', () => {
    const node = component.find( 'PaymentForm' ).instance();
    node.getCCIcon( '1234544456565676' );
    expect( node.state.cardType ).toBe( 'defaultCreditCard' );
    node.getCCIcon( '6011544456565676' );
    expect( node.state.cardType ).toBe( 'Discover' );
    node.getCCIcon( '5780544456565676' );
    expect( node.state.cardType ).toBe( 'Ultamate Rewards Credit Card' );
    node.getCCIcon( '3780544456565676' );
    expect( node.state.cardType ).toBe( 'AmericanExpress' );
    node.getCCIcon( '536817' );
    expect( node.state.cardType ).toBe( 'Ultamate Rewards MasterCard' );
    node.getCCIcon( '52899996817' );
    expect( node.state.cardType ).toBe( 'Mastercard' );
    node.getCCIcon( '42899996817' );
    expect( node.state.cardType ).toBe( 'Visa' );
  } );

  props.setCCPaymentFormSubmit = jest.fn();
  props.checkoutFormAddress2Open = {
    paymentAddressForm : 'true' };
  props.toggleInputFieldPaymentDisplay = jest.fn();
  props.handleCancelAddCreditCard = jest.fn();
  props.setTempPaymentCCVNumber = jest.fn();
  props.toggleSecurityCode = jest.fn();
  props.displayType = 'mobile'
  const component1 = mountPaymentForm( props );
  const instance = component1.find( 'PaymentForm' ).instance();

  it( 'should call the componentDidComponent', () => {
    instance.componentDidComponent();
    expect( props.setCCPaymentFormSubmit ).toHaveBeenCalledWith( false );
  } );

  it( 'should call the toggleAddress2Validation method', () => {
    instance.toggleAddress2Validation();
    expect( props.toggleInputFieldPaymentDisplay ).toHaveBeenCalled( );
  } );

  it( 'should call the makePrimaryCCToggle method', () => {
    expect( instance.state.isPrimaryPaymentMethod ).toEqual( false );
    instance.makePrimaryCCToggle();
    expect( instance.state.isPrimaryPaymentMethod ).toEqual( true );
  } );

  it( 'should call the cancelAddCreditCard method', () => {
    instance.cancelAddCreditCard();
    expect( props.setTempPaymentCCVNumber ).toHaveBeenCalledWith( null );
    expect( props.handleCancelAddCreditCard ).toHaveBeenCalled( );
  } );

  it( 'should call the cancelAddCreditCard method', () => {
    instance.cancelAddCreditCard();
    expect( props.setTempPaymentCCVNumber ).toHaveBeenCalledWith( null );
    expect( props.handleCancelAddCreditCard ).toHaveBeenCalled( );
  } );

  it( 'should call the toggleHinttext method', () => {
    instance.toggleHinttext();
    expect( props.setTempPaymentCCVNumber ).toHaveBeenCalledWith( null );
    expect( props.toggleSecurityCode ).toHaveBeenCalledWith( true, props.displayType );
  } );

  it( 'should call the toggleSecurityIcon method', () => {
    instance.toggleSecurityIcon();
    expect( props.toggleSecurityCode ).toHaveBeenCalledWith( false, props.displayType );
  } );

  describe( 'Test Cases related to Payment Form Billing Address Toggle', () => {
    it( 'should clear fields when we toggle', () => {
      props.isSignedIn = false;
      props.isAddCreditCard = false;
      props.setEditCreditCardData = jest.fn();
      const component1 = mountPaymentForm( props );
      const node1 = component1.find( 'PaymentForm' ).instance();
      node1.state.isSameAsShipping = false;
      expect( component1.find( 'PaymentForm' ).at( 0 ).props().setEditCreditCardData ).not.toBeCalled();
      node1.sameAsShippingToggle();
      expect( component1.find( 'PaymentForm' ).at( 0 ).props().setEditCreditCardData ).toBeCalled();
    } );

    it( 'should ensure redux form props are passed to the checkoutaddressform component', () => {
      props.isSignedIn = true;
      props.isAddCreditCard = true;
      props.setEditCreditCardData = jest.fn();
      props.editAddressData={};
      const component2 = mountPaymentForm( props );
      const currState = component2.find( 'PaymentForm' ).instance().state;
      currState.isSameAsShipping = false;
      component2.find( 'PaymentForm' ).instance().setState( currState )
      component2.update();
      expect( component2.find( 'CheckoutAddressForm' ).props().form ).toBe( 'paymentForm' );
      expect( component2.find( 'CheckoutAddressForm' ).instance().props.validate ).toBeTruthy();
    } );

    it( 'should call setEditCreditCardData if user is a signed in user and trying to add a new card', () => {
      props.isSignedIn = true;
      props.isAddCreditCard = true;
      props.setEditCreditCardData = jest.fn();
      const component2 = mountPaymentForm( props );
      const node2 = component2.find( 'PaymentForm' ).instance();
      node2.state.isSameAsShipping = false;
      node2.sameAsShippingToggle();
      expect( component2.find( 'PaymentForm' ).at( 0 ).props().setEditCreditCardData ).toBeCalled();
    } );

    it( 'should not call setEditCreditCardData If user signed in and editing a existing card', () => {
      props.isSignedIn = true;
      props.setEditCreditCardData = jest.fn();
      props.isAddCreditCard = false;
      const component3 = mountPaymentForm( props );
      const node3 = component3.find( 'PaymentForm' ).instance();
      node3.sameAsShippingToggle();
      expect( component3.find( 'PaymentForm' ).at( 0 ).props().setEditCreditCardData ).not.toBeCalled();
    } );

    it( 'should not render security code icon if there is no value in the field and `showSecurityIcon` is false', () => {
      store.getState().form.paymentForm= {
        values: {
          securityCode: ''
        }
      }
      let props1 = {
        toggleAddressFieldDisplayPaymentForm: jest.fn(),
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        setCreditCardPaymentType: jest.fn(),
        checkoutFormAddress2Open:{},
        editCreditCardData:{},
        shippingInfo: {
          firstName: 'abc'
        },
        addDoneButton: false,
        paymentError:false,
        checkoutFormConfig:{
          showHideCheckoutToggleData:{
            securityCode: false
          }

        },
        showSecurityIcon: false,
        handleScrollView: jest.fn()
      };
      const component5 = mountPaymentForm( props1 );
      component5.find( '#creditCardNumber' ).simulate( 'change', { target: { value: '411111111111' } } )
      expect( component5.find( '.PaymentForm__field--securityCode--icon' ).length ).toBe( 0 );
    } );

    it( 'should render security code icon if there is value in the field', () => {
      store.getState().form.paymentForm= {
        values: {
          securityCode: '123'
        }
      }
      let props1 = {
        toggleAddressFieldDisplayPaymentForm: jest.fn(),
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        setCreditCardPaymentType: jest.fn(),
        checkoutFormAddress2Open:{},
        editCreditCardData:{},
        shippingInfo: {
          firstName: 'abc'
        },
        addDoneButton: false,
        paymentError:false,
        checkoutFormConfig:{
          showHideCheckoutToggleData:{
            securityCode: false
          }

        },
        showSecurityIcon: false,
        handleScrollView: jest.fn()
      };
      const component5 = mountPaymentForm( props1 );
      component5.find( '#creditCardNumber' ).simulate( 'change', { target: { value: '411111111111' } } )
      expect( component5.find( '.PaymentForm__field--securityCode--icon' ).length ).toBe( 1 );
    } );
    it( 'should render security code icon if there is no value in the field and `showSecurityIcon` is true', () => {
      store.getState().form.paymentForm= {
        values: {
          securityCode: ''
        }
      }
      let props1 = {
        toggleAddressFieldDisplayPaymentForm: jest.fn(),
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        setCreditCardPaymentType: jest.fn(),
        checkoutFormAddress2Open:{},
        editCreditCardData:{},
        shippingInfo: {
          firstName: 'abc'
        },
        addDoneButton: false,
        paymentError:false,
        checkoutFormConfig:{
          showHideCheckoutToggleData:{
            securityCode: false
          }

        },
        showSecurityIcon: true,
        handleScrollView: jest.fn()
      };
      const component5 = mountPaymentForm( props1 );
      component5.find( '#creditCardNumber' ).simulate( 'change', { target: { value: '411111111111' } } )
      expect( component5.find( '.PaymentForm__field--securityCode--icon' ).length ).toBe( 1 );
    } );
    it( 'The id of the toggle button and the htmlFor of the label element should match', () => {
      const props = {
        toggleAddressFieldDisplayPaymentForm: jest.fn(),
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        setCreditCardPaymentType: jest.fn(),
        checkoutFormAddress2Open:{},
        editCreditCardData:{},
        shippingInfo: {
          firstName: 'abc'
        },
        addDoneButton: false,
        paymentError:false,
        checkoutFormConfig:{
          showHideCheckoutToggleData:{
            securityCode: false
          }

        },
        showSecurityIcon: true
      };
      const component = mountPaymentForm( props );
      expect( component.find( '.PaymentForm__toggleButton' ).children( 'label' ).text() ).toBe( messages.sameAsShipping.defaultMessage );
      expect( component.find( '.ToggleButton__checkbox' ).props()['id'] ).toBe( component.find( '.PaymentForm__toggleButton' ).children( 'label' ).props()['htmlFor'] );
    } );
  } );
} );


function mountPaymentForm( props ){
  return mountWithIntl(
    <Provider store={ store }>
      <PaymentForm
        { ...props }
      />
    </Provider>
  );
}
