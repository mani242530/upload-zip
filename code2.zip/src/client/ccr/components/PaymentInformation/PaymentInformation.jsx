/**
 * PaymentInformation
 */

import React, { Component } from 'react';
import './PaymentInformation.css';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './PaymentInformation.messages';
import PaymentCreditCardPayPal from 'ccr/components/PaymentCreditCardPayPal/PaymentCreditCardPayPal';
import PaymentDefaultCreditCard from 'ccr/components/PaymentDefaultCreditCard/PaymentDefaultCreditCard';
import ProfileCreditCardList from 'ccr/components/ProfileCreditCardList/ProfileCreditCardList';
import UltamateRewardsCreditCard from 'ccr/components/UltamateRewardsCreditCard/UltamateRewardsCreditCard';
import { isEmpty, find, isUndefined, has, isEqual } from 'lodash';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import { fireAnalyticsEvent } from 'utils/Omniture/Omniture';
import PropTypes from 'prop-types';
import Spinner from 'shared/components/Icons/spinner';
import classNames from 'classnames';

const propTypes={
  tabIndex: PropTypes.number,
  cardInfoOpen: PropTypes.bool,
  setPaymentType: PropTypes.func,
  creditCardDetails: PropTypes.object,
  isSignedIn: PropTypes.bool,
  ultamateRewardsCCInfo: PropTypes.object,
  paymentError: PropTypes.array,
  paypalResponse: PropTypes.object,
  getPaypalToken: PropTypes.func,
  getPaypalResponse: PropTypes.func,
  applyPayment: PropTypes.func,
  cartSummary: PropTypes.object,
  setCCPaymentFormSubmit: PropTypes.func,
  checkoutFormAddress2Open: PropTypes.object,
  toggleInputFieldPaymentDisplay: PropTypes.func,
  setTempPaymentCCVNumber: PropTypes.func,
  setCreditCardPaymentType: PropTypes.func,
  editCreditCardData: PropTypes.object,
  setEditCreditCardData: PropTypes.func,
  setEditAddressData: PropTypes.func,
  submitShippingAddressForm: PropTypes.func,
  handleScrollView: PropTypes.func,
  updatePaymentStatus: PropTypes.func,
  updatePaymentServiceResponse: PropTypes.func,
  editCCData: PropTypes.object,
  isSetCCPaymentFormSubmit: PropTypes.bool,
  previousPaymentType: PropTypes.string,
  toggleSecurityCode: PropTypes.func,
  displayType: PropTypes.string,
  fieldShowHideToggleData: PropTypes.object,
  showSecurityIcon: PropTypes.bool,
  checkoutFormConfig: PropTypes.object,
  shippingInfo: PropTypes.object,
  enableExpressPaypalCheckout: PropTypes.bool,
  paypalEnvironment: PropTypes.string,
  editAddressData: PropTypes.object,
  toggleAddressFieldDisplayPaymentForm: PropTypes.func,
  checkoutFormAddressOpen: PropTypes.object,
  handleScrollToFormError: PropTypes.func,
  getProfileCreditCardList: PropTypes.func,
  payPalClientToken: PropTypes.string,
  profileCreditCardList: PropTypes.object,
  tempPaymentCCVNumber: PropTypes.string,
  paymentDetails: PropTypes.array,
  showProfileCreditCardsSpinner: PropTypes.bool
}
/**
 * Class
 * @extends React.Component
 */
const initialState = {
  showDefaultCreditCard: true,
  showAddCreditCard: false,
  isAddCreditCard: false,
  cancelFlag: false,
  paymentCCData: {}
}

class PaymentInformation extends Component{

  /**
   * Create a PaymentInformation
   */
  constructor( props ){
    super( props );
    this.state = initialState;
    this.assignPaymentAddress = this.assignPaymentAddress.bind( this );
    this.handleChangeCreditCardPaypal = this.handleChangeCreditCardPaypal.bind( this );
    this.handleChangeCreditCard = this.handleChangeCreditCard.bind( this );
    this.handleAddCreditCard = this.handleAddCreditCard.bind( this );
    this.handleCancelAddCreditCard = this.handleCancelAddCreditCard.bind( this );
    this.handleCancelErrorCreditCard = this.handleCancelErrorCreditCard.bind( this );
    this.handleAddNewCreditCard = this.handleAddNewCreditCard.bind( this );
    this.handleEditCreditCard = this.handleEditCreditCard.bind( this );
    this.handleChangePaypalAccount = this.handleChangePaypalAccount.bind( this );
  }

  selectedPayment = undefined;

  handleChangeCreditCardPaypal( e ){
    this.props.getProfileCreditCardList( ); /* making a sevice call to get the profile credit card list */
    this.setState( {
      showDefaultCreditCard: false
    } );
    this.props.broadcastMessage( '' );
    this.props.handleScrollView( 'checkoutPaymentHeader' );
  }

  handleChangePaypalAccount( e ){
    this.setState( {
      showDefaultCreditCard: true
    } );
    this.props.handleScrollView( 'checkoutPaymentHeader' );
    this.handleAccessibility();
  }

  handleAccessibility(){
    this.props.broadcastMessage( formatMessage( messages.paymentMethodSelected ) );

    // there is a time out provided for setting the focus, to give enough time for the view payment
    // section to be active i.e for the card list view to disapper or the paypal overlay to disapper
    // once the selection is made
    setTimeout( () => {
      this.selectedPayment.focus();
    }, 2000 );
  }

  handleAddCreditCard( val ){
    this.props.setEditCreditCardData( {} );
    this.props.setEditAddressData( {} );
    this.setState( {
      showAddCreditCard: true,
      isAddCreditCard: true
    } );
    if( val === 'default' ){
      this.setState( {
        cancelFlag: false
      } );
    }
    else {
      this.setState( {
        cancelFlag: true
      } );
    }
    this.props.handleScrollView( 'checkoutPaymentHeader' );
  }

  handleEditCreditCard( editCreditCardObj ){
    let editCCObj = {
      nickName: editCreditCardObj.nickName,
      creditCardType: editCreditCardObj.creditCardType,
      creditCardNumber: editCreditCardObj.creditCardNumber,
      expirationMonth: editCreditCardObj.expirationMonth,
      expirationYear: editCreditCardObj.expirationYear,
      firstName: ( editCreditCardObj.contactInfo ) ? editCreditCardObj.contactInfo.firstName : '',
      lastName: ( editCreditCardObj.contactInfo ) ? editCreditCardObj.contactInfo.lastName : '',
      phoneNumber: ( editCreditCardObj.contactInfo ) ? editCreditCardObj.contactInfo.phoneNumber : '',
      isPrimary: editCreditCardObj.isPrimary,
      addressData: {
        address1: ( editCreditCardObj.contactInfo ) ? editCreditCardObj.contactInfo.address1 : '',
        address2: ( editCreditCardObj.contactInfo ) ? editCreditCardObj.contactInfo.address2 : '',
        city: ( editCreditCardObj.contactInfo ) ? editCreditCardObj.contactInfo.city : '',
        state: ( editCreditCardObj.contactInfo ) ? editCreditCardObj.contactInfo.state : '',
        postalCode: ( editCreditCardObj.contactInfo ) ? editCreditCardObj.contactInfo.postalCode : ''
      }
    }
    this.props.setEditCreditCardData( editCCObj );
    this.props.setEditAddressData( {} );
    this.setState( {
      showAddCreditCard: true
    } );
    this.props.handleScrollView( 'checkoutPaymentHeader' );
  }

  handleCancelAddCreditCard( e ){
    this.setState( {
      showDefaultCreditCard: !( this.state.cancelFlag ),
      showAddCreditCard: false,
      isAddCreditCard: false
    } );
    this.props.handleScrollView( 'checkoutPaymentHeader' );
  }

  handleCancelErrorCreditCard( e ){
    this.setState( {
      showDefaultCreditCard: false,
      showAddCreditCard: false,
      isAddCreditCard: false
    } );
    this.props.handleScrollView( 'checkoutPaymentHeader' );
  }

  handleAddNewCreditCard( e ){
    this.setState( {
      showDefaultCreditCard: true,
      showAddCreditCard: false
    } );
    this.props.handleScrollView( 'checkoutPaymentHeader' );
  }

  handleChangeCreditCard( updateCCValue ){
    if( updateCCValue !== null && updateCCValue !== '' && updateCCValue !== undefined ){
      if( updateCCValue !== 'PayPal' ){
        const postData = {
          values: {
            paymentType: 'creditCard',
            creditCardNumber: updateCCValue.creditCardNumber,
            expirationMonth: updateCCValue.expirationMonth,
            expirationYear: updateCCValue.expirationYear,
            creditCardType: updateCCValue.creditCardType,
            nickName: updateCCValue.nickName,
            firstName: ( updateCCValue.contactInfo ) ? updateCCValue.contactInfo.firstName : '',
            lastName: ( updateCCValue.contactInfo ) ? updateCCValue.contactInfo.lastName : '',
            phoneNumber: ( updateCCValue.contactInfo ) ? updateCCValue.contactInfo.phoneNumber : '',
            address1: ( updateCCValue.contactInfo ) ? updateCCValue.contactInfo.address1 : '',
            address2: ( updateCCValue.contactInfo && updateCCValue.contactInfo.address2 ) ? updateCCValue.contactInfo.address2 : '',
            city: ( updateCCValue.contactInfo ) ? updateCCValue.contactInfo.city : '',
            state: ( updateCCValue.contactInfo ) ? updateCCValue.contactInfo.state : '',
            postalCode: ( updateCCValue.contactInfo ) ? updateCCValue.contactInfo.postalCode : '',
            country: ( updateCCValue.contactInfo ) ? updateCCValue.contactInfo.country : ''
          }
        }
        this.props.updatePaymentServiceResponse( postData );
      }
    }
    this.setState( {
      showDefaultCreditCard: true
    } );
    this.props.handleScrollView( 'checkoutPaymentHeader' );
    this.handleAccessibility();
  }

  assignPaymentAddress(){
    if( has( this.props, 'creditCardDetails' ) && !isEmpty( this.props.creditCardDetails ) && this.props.creditCardDetails.paymentInfo.paymentType === 'creditCard' ){
      let creditCardDetails = this.props.creditCardDetails;
      let tempCCDetailsObj = {
        nickName: creditCardDetails.paymentInfo.nickName,
        creditCardType: creditCardDetails.paymentInfo.paymentDetails.creditCardType,
        creditCardNumber: creditCardDetails.paymentInfo.paymentDetails.creditCardNumber,
        expirationMonth: creditCardDetails.paymentInfo.paymentDetails.expirationMonth,
        expirationYear: creditCardDetails.paymentInfo.paymentDetails.expirationYear,
        contactInfo: ( creditCardDetails.paymentInfo.contactInfo && this.props.isSignedIn ) ? {
          firstName: creditCardDetails.paymentInfo.contactInfo.firstName,
          lastName: creditCardDetails.paymentInfo.contactInfo.lastName,
          phoneNumber: creditCardDetails.paymentInfo.contactInfo.phoneNumber,
          addressData: {
            address1: creditCardDetails.paymentInfo.contactInfo.address1,
            address2: creditCardDetails.paymentInfo.contactInfo.address2,
            city: creditCardDetails.paymentInfo.contactInfo.city,
            state: creditCardDetails.paymentInfo.contactInfo.state,
            postalCode: creditCardDetails.paymentInfo.contactInfo.postalCode
          }
        } : null
      }

      this.setState( { paymentCCData: tempCCDetailsObj } );
      if( !this.state.showAddCreditCard ){
        this.props.setEditCreditCardData( tempCCDetailsObj );
      }
    }
  }
  componentWillReceiveProps( nextProps ){
    if( isEmpty( this.props.editCreditCardData ) && !isEmpty( nextProps.profileCreditCardList ) ){

      const profileCreditCards = nextProps.profileCreditCardList.profileCreditCards;
      if( !isEmpty( profileCreditCards ) ){
        const creditCard = profileCreditCards[0];
        const tempCCDetailsObj = {
          nickName: creditCard.nickName,
          creditCardType: creditCard.creditCardType,
          creditCardNumber: creditCard.creditCardNumber,
          expirationMonth: creditCard.expirationMonth,
          expirationYear: creditCard.expirationYear,
          contactInfo: ( creditCard.contactInfo ) ? {
            firstName: creditCard.contactInfo.firstName,
            lastName: creditCard.contactInfo.lastName,
            phoneNumber: creditCard.contactInfo.phoneNumber,
            addressData: {
              address1: creditCard.contactInfo.address1,
              address2: creditCard.contactInfo.address2,
              city: creditCard.contactInfo.city,
              state: creditCard.contactInfo.state,
              postalCode: ccreditCard.contactInfo.postalCode
            }
          } : null
        }
        this.props.setEditCreditCardData( tempCCDetailsObj );
      }

    }

  }
  componentWillMount(){
    if( has( this.props, 'creditCardDetails' ) && !isEmpty( this.props.creditCardDetails ) ){
      this.assignPaymentAddress();
    }
  }

  componentDidMount(){
    if( this.props.isSignedIn === true && this.props.paymentType === 'paypal' && isEmpty( this.props.profileCreditCardList ) ){
      this.props.getProfileCreditCardList( );
    }
  }

  componentDidUpdate( prevProps ){
    if( has( this.props, 'creditCardDetails' )&& this.props.creditCardDetails !== prevProps.creditCardDetails && isEmpty( this.props.creditCardDetails.messages ) ){
      this.assignPaymentAddress();
    }
    if( this.props.isSignedIn ){
      // Focus to error panel generated for creditCardDetails messages (props.creditCardDetails.messages)
      if( !isEmpty( this.props.creditCardDetails.messages ) &&
          ( !isUndefined( find( this.props.creditCardDetails.messages, { 'messageKey': 'errorCvvCode' } ) ) ) &&
          isEmpty( this.props.paymentError ) &&
          !isEqual( prevProps.creditCardDetails.messages, this.props.creditCardDetails.messages )
      ){
        this.errorPanelCreditCardDetailsMessage.focus();
      }
      // Focus to error panel generated for paymentError (props.paymentError)
      if( !isEmpty( this.props.paymentError ) && !isEqual( prevProps.paymentError, this.props.paymentError ) ){
        this.errorPanelPaymentErrorMessage.focus();
      }
    }
  }

  /**
   * Renders the PaymentInformation component
   */
  render(){


    const {
      creditCardDetails
    } = this.props;

    const {
      showDefaultCreditCard,
      showAddCreditCard
    } = this.state;

    return (
      <div className='PaymentInformation'>
        { ( () =>{
          // Below component gets render if we click on `Add New CreditCard`
          if( this.props.isSignedIn ){
            if( showAddCreditCard ){
              return (
                <PaymentCreditCardPayPal
                  tabIndex={ this.props.tabIndex + 1 }
                  isSameAsShipping={ false }
                  isAddressInFocus={ true }
                  enterUnitNumber={ true }
                  cardInfoOpen={ true }
                  addEditCreditCard='yes'
                  paymentType='creditCard'
                  handleCancelAddCreditCard={ this.handleCancelAddCreditCard }
                  handleAddNewCreditCard={ this.handleAddNewCreditCard }
                  showCVV={ ( !isEmpty( find( creditCardDetails.messages ), { 'messageType': 'Error' } ) ) }
                  setPaymentType={ this.props.setPaymentType }
                  creditCardDetails={ this.props.creditCardDetails }
                  isSignedIn={ this.props.isSignedIn }
                  handleAddCreditCard={ this.handleAddCreditCard }
                  ultamateRewardsCCInfo={ this.props.ultamateRewardsCCInfo }
                  paymentError={ this.props.paymentError }
                  paypalResponse={ this.props.paypalResponse }
                  getPaypalToken={ this.props.getPaypalToken }
                  getPaypalResponse={ this.props.getPaypalResponse }
                  applyPayment={ this.props.applyPayment }
                  cartSummary={ this.props.cartSummary }
                  setCCPaymentFormSubmit={ this.props.setCCPaymentFormSubmit }
                  checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                  toggleInputFieldPaymentDisplay={ this.props.toggleInputFieldPaymentDisplay }
                  setTempPaymentCCVNumber={ this.props.setTempPaymentCCVNumber }
                  setCreditCardPaymentType={ this.props.setCreditCardPaymentType }
                  editCreditCardData={ this.props.editCreditCardData }
                  setEditCreditCardData={ this.props.setEditCreditCardData }
                  setEditAddressData={ this.props.setEditAddressData }
                  submitShippingAddressForm={ this.props.submitShippingAddressForm }
                  handleScrollView={ this.props.handleScrollView }
                  updatePaymentStatus={ this.props.updatePaymentStatus }
                  updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
                  editCCData={ this.props.editCCData }
                  isSetCCPaymentFormSubmit={ this.props.isSetCCPaymentFormSubmit }
                  previousPaymentType={ this.props.previousPaymentType }
                  toggleSecurityCode={ this.props.toggleSecurityCode }
                  displayType={ this.props.displayType }
                  fieldShowHideToggleData={ this.props.fieldShowHideToggleData }
                  showSecurityIcon={ this.props.showSecurityIcon }
                  checkoutFormConfig={ this.props.checkoutFormConfig }
                  shippingInfo={ this.props.shippingInfo }
                  enableExpressPaypalCheckout={ this.props.enableExpressPaypalCheckout }
                  paypalEnvironment={ this.props.paypalEnvironment }
                  editAddressData={ this.props.editAddressData }
                  toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                  checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                  handleScrollToFormError={ this.props.handleScrollToFormError }
                  payPalClientToken={ this.props.payPalClientToken }
                />
              );
            }
            else if( this.props.creditCardDetails && this.props.creditCardDetails.paymentInfo && !this.props.creditCardDetails.paymentInfo.contactInfo && !isUndefined( find( creditCardDetails.messages, { 'messageKey': 'errBillingFirstName' } ) ) ){
              // Below component gets render if we get contact info null in paymentInfo (readCart data response)
              return (
                <PaymentCreditCardPayPal
                  tabIndex={ this.props.tabIndex + 1 }
                  isSameAsShipping={ false }
                  isAddressInFocus={ true }
                  enterUnitNumber={ true }
                  addDoneButton={ true }
                  cardInfoOpen={ true }
                  paymentType={ this.props.paymentType }
                  handleAddNewCreditCard={ this.handleAddNewCreditCard }
                  editCreditCardData={ this.state.paymentCCData }
                  isAddCreditCard={ this.state.isAddCreditCard }
                  showCVV={ ( ( has( creditCardDetails, 'messages' ) ) && ( !isEmpty( find( creditCardDetails.messages ), { 'messageType': 'Error' } ) ) ) }
                  handleCancelAddCreditCard={ this.handleCancelAddCreditCard }
                  setPaymentType={ this.props.setPaymentType }
                  creditCardDetails={ this.props.creditCardDetails }
                  isSignedIn={ this.props.isSignedIn }
                  handleAddCreditCard={ this.handleAddCreditCard }
                  ultamateRewardsCCInfo={ this.props.ultamateRewardsCCInfo }
                  paymentError={ this.props.paymentError }
                  paypalResponse={ this.props.paypalResponse }
                  getPaypalToken={ this.props.getPaypalToken }
                  getPaypalResponse={ this.props.getPaypalResponse }
                  applyPayment={ this.props.applyPayment }
                  cartSummary={ this.props.cartSummary }
                  setCCPaymentFormSubmit={ this.props.setCCPaymentFormSubmit }
                  checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                  toggleInputFieldPaymentDisplay={ this.props.toggleInputFieldPaymentDisplay }
                  setTempPaymentCCVNumber={ this.props.setTempPaymentCCVNumber }
                  setCreditCardPaymentType={ this.props.setCreditCardPaymentType }
                  setEditCreditCardData={ this.props.setEditCreditCardData }
                  setEditAddressData={ this.props.setEditAddressData }
                  submitShippingAddressForm={ this.props.submitShippingAddressForm }
                  handleScrollView={ this.props.handleScrollView }
                  updatePaymentStatus={ this.props.updatePaymentStatus }
                  updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
                  editCCData={ this.props.editCCData }
                  isSetCCPaymentFormSubmit={ this.props.isSetCCPaymentFormSubmit }
                  previousPaymentType={ this.props.previousPaymentType }
                  toggleSecurityCode={ this.props.toggleSecurityCode }
                  displayType={ this.props.displayType }
                  fieldShowHideToggleData={ this.props.fieldShowHideToggleData }
                  showSecurityIcon={ this.props.showSecurityIcon }
                  checkoutFormConfig={ this.props.checkoutFormConfig }
                  shippingInfo={ this.props.shippingInfo }
                  enableExpressPaypalCheckout={ this.props.enableExpressPaypalCheckout }
                  paypalEnvironment={ this.props.paypalEnvironment }
                  editAddressData={ this.props.editAddressData }
                  toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                  checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                  handleScrollToFormError={ this.props.handleScrollToFormError }
                  payPalClientToken={ this.props.payPalClientToken }
                />
              );
            }
            else if( !isUndefined( creditCardDetails.paymentInfo ) && !isEmpty( creditCardDetails, 'messages' ) && !isEmpty( this.props.editCreditCardData ) ){
              return (
                <div className='PaymentInformation__paymentContainer'>
                  <UltamateRewardsCreditCard
                    isSignedIn={ this.props.isSignedIn }
                    ultamateRewardsCCInfo={ this.props.ultamateRewardsCCInfo }
                    handleAddCreditCard={ this.handleAddCreditCard }
                  />
                  { ( () =>{
                    if( this.props.isSignedIn ){
                      // To show error message only CCV related error message and for remaining error message with shown under PaymentCreditCardPayPal component
                      if( has( creditCardDetails, 'messages' ) && !isEmpty( creditCardDetails.messages ) && ( !isUndefined( find( creditCardDetails.messages, { 'messageKey': 'errorCvvCode' } ) ) ) ){
                        if( has( creditCardDetails, 'messages' ) && isEmpty( this.props.paymentError ) ){
                          return (
                            <div
                              className='PaymentInformation__errorMessagesPanel'
                              tabIndex='-1'
                              ref={ ( el )=>{
                                this.errorPanelCreditCardDetailsMessage=el
                              } }
                            >
                              { ( () =>{
                                return creditCardDetails.messages.map( ( message, index1 ) =>{
                                  return (
                                    <ResponseMessages
                                      messageType={ message.messageType }
                                      message={ message.messageDesc }
                                      key={ index1 }
                                      broadCastAdaMessage={ true }
                                    />
                                  );
                                } );
                              } )() }

                            </div>
                          )
                        }
                      }


                      if( !isEmpty( this.props.paymentError ) ){
                        let analyticsEvent =
                          {
                            eventName: 'trackErrorDisplayed',
                            data: {
                              'errorType': 'form',
                              'errorLabel': 'payment',
                              'errorDescription': this.props.paymentError
                            }
                          };

                        fireAnalyticsEvent( analyticsEvent.name, analyticsEvent.data );

                        return (
                          <div
                            className='PaymentInformation__errorMessagesPanel'
                            tabIndex='-1'
                            ref={ ( el )=>{
                              this.errorPanelPaymentErrorMessage=el
                            } }
                          >
                            { ( () =>{
                              return ( this.props.paymentError.map( ( message, index ) =>{
                                return (
                                  <ResponseMessages
                                    messageType={ message.messageType }
                                    message={ message.messageDesc }
                                    key={ index }
                                    broadCastAdaMessage={ true }
                                  />
                                )
                              } ) )
                            } )() }
                          </div>
                        )
                      }

                    }
                  } )() }
                  { ( ()=>{
                    /* Below condition is to show spinner when there is no profile creditcard list data  */
                    if( this.props.showProfileCreditCardsSpinner ){
                      return (
                        <div className='PaymentInformation__spinner'>
                          <Spinner/>
                        </div>
                      )
                    }
                  } )() }
                  <div className={
                    classNames( 'PaymentInformation__creditCardPaypalContainer', {
                      'PaymentInformation__changeCreditcardPayPal': this.props.showProfileCreditCardsSpinner /* Adding `PaymentInformation__changeCreditcardPayPal` class to change opacity to 50% */
                    } )
                  }
                  >
                    { ( () =>{
                      if( showDefaultCreditCard || this.props.showProfileCreditCardsSpinner ){
                        // Show default creditCard view only when no error message or CCV related error message
                        // For other related creditCard errors, need to show creditCard edit mode to update the creditCard detailds
                        // On cancel, we need to show list view by default, so created to new function 'handleCancelErrorCreditCard'
                        if( this.props.paymentType === 'creditCard' &&
                            ( ( has( creditCardDetails, 'messages' ) && !isEmpty( creditCardDetails.messages ) && ( isUndefined( find( creditCardDetails.messages, { 'messageKey': 'errorCvvCode' } ) ) ) ) ||
                              has( creditCardDetails, 'isPaymentErrorCleared' ) ) ){
                          return (
                            <PaymentCreditCardPayPal
                              tabIndex={ this.props.tabIndex + 1 }
                              isSameAsShipping={ false }
                              isAddressInFocus={ true }
                              enterUnitNumber={ true }
                              cardInfoOpen={ true }
                              addEditCreditCard='yes'
                              isAddCreditCard={ this.state.isAddCreditCard }
                              paymentType='creditCard'
                              handleCancelAddCreditCard={ this.handleCancelErrorCreditCard }
                              handleAddNewCreditCard={ this.handleAddNewCreditCard }
                              showCVV={ ( !isEmpty( find( creditCardDetails.messages ), { 'messageType': 'Error' } ) ) }
                              editCreditCardData={ this.props.editCreditCardData }
                              setPaymentType={ this.props.setPaymentType }
                              creditCardDetails={ this.props.creditCardDetails }
                              isSignedIn={ this.props.isSignedIn }
                              handleAddCreditCard={ this.handleAddCreditCard }
                              ultamateRewardsCCInfo={ this.props.ultamateRewardsCCInfo }
                              paymentError={ this.props.paymentError }
                              paypalResponse={ this.props.paypalResponse }
                              getPaypalToken={ this.props.getPaypalToken }
                              getPaypalResponse={ this.props.getPaypalResponse }
                              applyPayment={ this.props.applyPayment }
                              cartSummary={ this.props.cartSummary }
                              setCCPaymentFormSubmit={ this.props.setCCPaymentFormSubmit }
                              checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                              toggleInputFieldPaymentDisplay={ this.props.toggleInputFieldPaymentDisplay }
                              setTempPaymentCCVNumber={ this.props.setTempPaymentCCVNumber }
                              setCreditCardPaymentType={ this.props.setCreditCardPaymentType }
                              setEditCreditCardData={ this.props.setEditCreditCardData }
                              setEditAddressData={ this.props.setEditAddressData }
                              submitShippingAddressForm={ this.props.submitShippingAddressForm }
                              handleScrollView={ this.props.handleScrollView }
                              updatePaymentStatus={ this.props.updatePaymentStatus }
                              updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
                              editCCData={ this.props.editCCData }
                              isSetCCPaymentFormSubmit={ this.props.isSetCCPaymentFormSubmit }
                              previousPaymentType={ this.props.previousPaymentType }
                              toggleSecurityCode={ this.props.toggleSecurityCode }
                              displayType={ this.props.displayType }
                              fieldShowHideToggleData={ this.props.fieldShowHideToggleData }
                              showSecurityIcon={ this.props.showSecurityIcon }
                              checkoutFormConfig={ this.props.checkoutFormConfig }
                              shippingInfo={ this.props.shippingInfo }
                              enableExpressPaypalCheckout={ this.props.enableExpressPaypalCheckout }
                              paypalEnvironment={ this.props.paypalEnvironment }
                              editAddressData={ this.props.editAddressData }
                              toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                              checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                              handleScrollToFormError={ this.props.handleScrollToFormError }
                              payPalClientToken={ this.props.payPalClientToken }
                            />
                          );
                        }
                        else {
                          return (
                            <PaymentDefaultCreditCard
                              handleChangeCreditCardPaypal={ this.handleChangeCreditCardPaypal }
                              showSecurityIcon={ this.props.showSecurityIcon }
                              toggleSecurityCode={ this.props.toggleSecurityCode }
                              displayType={ this.props.displayType }
                              tabIndex={ this.props.tabIndex +2 }
                              editCCData={ this.props.editCCData }
                              checkoutFormConfig={ this.props.checkoutFormConfig }
                              creditCardDetails={ this.props.creditCardDetails }
                              tempPaymentCCVNumber={ this.props.tempPaymentCCVNumber }
                              updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
                              selectedPaymentRef={ ( el )=>{
                                this.selectedPayment=el
                              } }
                            />
                          );
                        }
                      }
                      else {
                        return (
                          <ProfileCreditCardList
                            handleChangeCreditCard={ this.handleChangeCreditCard }
                            handleAddCreditCard={ this.handleAddCreditCard }
                            handleEditCreditCard={ this.handleEditCreditCard }
                            handleChangePaypalAccount={ this.handleChangePaypalAccount }
                            getProfileCreditCardList={ this.props.getProfileCreditCardList }
                            handleScrollView={ this.props.handleScrollView }
                            setTempPaymentCCVNumber={ this.props.setTempPaymentCCVNumber }
                            payPalClientToken={ this.props.payPalClientToken }
                            enableExpressPaypalCheckout={ this.props.enableExpressPaypalCheckout }
                            tabIndex={ this.props.tabIndex }
                            getPaypalToken={ this.props.getPaypalToken }
                            applyPayment={ this.props.applyPayment }
                            cartSummary={ this.props.cartSummary }
                            paypalEnvironment={ this.props.paypalEnvironment }
                            creditCardDetails={ this.props.creditCardDetails }
                            profileCreditCardList={ this.props.profileCreditCardList }
                            getPaypalResponse={ this.props.getPaypalResponse }
                          />
                        );
                      }
                    } )() }
                  </div>
                </div>
              );
            }
            else {
              // Below component gets render for logged-in user no saved creditcards
              return (
                <PaymentCreditCardPayPal
                  tabIndex={ this.props.tabIndex + 1 }
                  isSameAsShipping={ false }
                  isAddressInFocus={ true }
                  enterUnitNumber={ true }
                  cardInfoOpen={ true }
                  editCreditCardData={ this.state.paymentCCData }
                  showCVV={ ( ( has( creditCardDetails, 'messages' ) ) && ( !isEmpty( find( creditCardDetails.messages ), { 'messageType': 'Error' } ) ) ) }
                  setPaymentType={ this.props.setPaymentType }
                  paymentType={ this.props.paymentType }
                  creditCardDetails={ this.props.creditCardDetails }
                  isSignedIn={ this.props.isSignedIn }
                  handleAddCreditCard={ this.handleAddCreditCard }
                  ultamateRewardsCCInfo={ this.props.ultamateRewardsCCInfo }
                  paymentError={ this.props.paymentError }
                  paypalResponse={ this.props.paypalResponse }
                  getPaypalToken={ this.props.getPaypalToken }
                  getPaypalResponse={ this.props.getPaypalResponse }
                  applyPayment={ this.props.applyPayment }
                  cartSummary={ this.props.cartSummary }
                  setCCPaymentFormSubmit={ this.props.setCCPaymentFormSubmit }
                  checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                  toggleInputFieldPaymentDisplay={ this.props.toggleInputFieldPaymentDisplay }
                  setTempPaymentCCVNumber={ this.props.setTempPaymentCCVNumber }
                  setCreditCardPaymentType={ this.props.setCreditCardPaymentType }
                  setEditCreditCardData={ this.props.setEditCreditCardData }
                  setEditAddressData={ this.props.setEditAddressData }
                  submitShippingAddressForm={ this.props.submitShippingAddressForm }
                  handleScrollView={ this.props.handleScrollView }
                  updatePaymentStatus={ this.props.updatePaymentStatus }
                  updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
                  editCCData={ this.props.editCCData }
                  isSetCCPaymentFormSubmit={ this.props.isSetCCPaymentFormSubmit }
                  previousPaymentType={ this.props.previousPaymentType }
                  toggleSecurityCode={ this.props.toggleSecurityCode }
                  displayType={ this.props.displayType }
                  fieldShowHideToggleData={ this.props.fieldShowHideToggleData }
                  showSecurityIcon={ this.props.showSecurityIcon }
                  checkoutFormConfig={ this.props.checkoutFormConfig }
                  shippingInfo={ this.props.shippingInfo }
                  enableExpressPaypalCheckout={ this.props.enableExpressPaypalCheckout }
                  paypalEnvironment={ this.props.paypalEnvironment }
                  editAddressData={ this.props.editAddressData }
                  toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                  checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                  handleScrollToFormError={ this.props.handleScrollToFormError }
                  payPalClientToken={ this.props.payPalClientToken }
                />
              );
            }
          }
          else {
            // Below component gets render for anonymous user
            return (
              <PaymentCreditCardPayPal
                tabIndex={ this.props.tabIndex + 1 }
                isSameAsShipping={ false }
                isAddressInFocus={ true }
                enterUnitNumber={ true }
                cardInfoOpen={ true }
                paymentType={ this.props.paymentType }
                editCreditCardData={ this.state.paymentCCData }
                showCVV={ ( !isEmpty( find( creditCardDetails.messages ), { 'messageType': 'Error' } ) ) }
                setPaymentType={ this.props.setPaymentType }
                creditCardDetails={ this.props.creditCardDetails }
                isSignedIn={ this.props.isSignedIn }
                handleAddCreditCard={ this.handleAddCreditCard }
                ultamateRewardsCCInfo={ this.props.ultamateRewardsCCInfo }
                paymentError={ this.props.paymentError }
                paypalResponse={ this.props.paypalResponse }
                getPaypalToken={ this.props.getPaypalToken }
                getPaypalResponse={ this.props.getPaypalResponse }
                applyPayment={ this.props.applyPayment }
                cartSummary={ this.props.cartSummary }
                setCCPaymentFormSubmit={ this.props.setCCPaymentFormSubmit }
                checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                toggleInputFieldPaymentDisplay={ this.props.toggleInputFieldPaymentDisplay }
                setTempPaymentCCVNumber={ this.props.setTempPaymentCCVNumber }
                setCreditCardPaymentType={ this.props.setCreditCardPaymentType }
                setEditCreditCardData={ this.props.setEditCreditCardData }
                setEditAddressData={ this.props.setEditAddressData }
                submitShippingAddressForm={ this.props.submitShippingAddressForm }
                handleScrollView={ this.props.handleScrollView }
                updatePaymentStatus={ this.props.updatePaymentStatus }
                updatePaymentServiceResponse={ this.props.updatePaymentServiceResponse }
                editCCData={ this.props.editCCData }
                isSetCCPaymentFormSubmit={ this.props.isSetCCPaymentFormSubmit }
                previousPaymentType={ this.props.previousPaymentType }
                toggleSecurityCode={ this.props.toggleSecurityCode }
                displayType={ this.props.displayType }
                fieldShowHideToggleData={ this.props.fieldShowHideToggleData }
                showSecurityIcon={ this.props.showSecurityIcon }
                checkoutFormConfig={ this.props.checkoutFormConfig }
                shippingInfo={ this.props.shippingInfo }
                enableExpressPaypalCheckout={ this.props.enableExpressPaypalCheckout }
                paypalEnvironment={ this.props.paypalEnvironment }
                editAddressData={ this.props.editAddressData }
                toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                handleScrollToFormError={ this.props.handleScrollToFormError }
                payPalClientToken={ this.props.payPalClientToken }
              />
            );
          }
        } )() }
      </div>
    );
  }
}

PaymentInformation.propTypes = propTypes;

export default PaymentInformation;
