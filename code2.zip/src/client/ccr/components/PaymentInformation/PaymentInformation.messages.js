
/*
 * PaymentInformation Messages
 *
 * This contains all the text for the PaymentInformation component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.PaymentInformation.header',
    defaultMessage: 'This is the PaymentInformation component !'
  },
  paymentMethodSelected: {
    id: 'i18n.PaymentInformation.paymentMethodSelected',
    defaultMessage: 'Payment method Selected'
  }
} );
