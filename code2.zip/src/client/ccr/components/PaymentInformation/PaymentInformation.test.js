import React from 'react';
import ReactDOM from 'react-dom';
import PaymentInformation from './PaymentInformation';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import { IntlProvider } from 'react-intl';
import messages from '../PaymentCreditCardPayPal/PaymentCreditCardPayPal.messages'

describe( '<PaymentInformation />', () => {
  let component;
  let props = {
    isSignedIn: jest.fn(),
    setCreditCardPaymentType:jest.fn(),
    setEditCreditCardData:jest.fn(),
    checkoutFormConfig : { showHideCheckoutToggleData:{} },
    handleScrollView : jest.fn(),
    profileCreditCardList : {},
    getProfileCreditCardList :jest.fn(),
    cartSummary:{
      estimatedTotal:'12.00'
    },
    payPalClientToken: jest.fn(),
    paypalEnvironment : jest.fn(),
    editCreditCardData : {
      contactInfo: jest.fn()
    },
    creditCardDetails: {
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      paymentInfo: {
        paymentType: 'creditCard',
        paymentDetails: {
          expirationMonth: '09',
          expirationYear: '2021',
          creditCardNumber: '1111',
          creditCardType: 'Visa'
        },
        amount: 46.18,
        currencyCode: 'USD',
        contactInfo: {
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          email: 'pkabdaula@ulta.com',
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city: 'Boolingbrook',
          state: 'IL',
          postalCode: '07105',
          country: 'US'
        }
      }
    }
  };
  global.braintree = { client:{ create:jest.fn() } };

  const initialState={
    showDefaultCreditCard: true,
    showAddCreditCard: false
  }
  const store = configureStore( {}, CONFIG );
  store.getState().checkoutPage.creditCardDetails.paymentInfo = { paymentDetails : {} };
  component = mountWithIntl(
    <Provider store={ store }>
      <PaymentInformation { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'PaymentInformation' ).length ).toBe( 1 );
  } );

  it( 'renders Payment Default CreditCard Component without crashing', () => {
    expect( component.find( '.PaymentDefaultCreditCard' ).length ).toBe( 1 );
  } );

  it( 'renders Payment Default CreditCard Component without crashing when error message related to CCV', () => {
    let props = {
      isSignedIn: true,
      paymentType: 'creditCard',
      setCreditCardPaymentType:jest.fn(),
      setEditCreditCardData:jest.fn(),
      setEditAddressData:jest.fn(),
      handleChangeCreditCardPaypal:jest.fn(),
      handleChangePaypalAccount:jest.fn(),
      handleScrollView:jest.fn(),
      getProfileCreditCardList:jest.fn(),
      handleCancelAddCreditCard:jest.fn(),
      handleEditCreditCard:jest.fn(),
      handleChangeCreditCard:jest.fn(),
      cartSummary:{
        estimatedTotal:'12.00'
      },
      checkoutFormConfig:{ showHideCheckoutToggleData:{} },
      updatePaymentServiceResponse:jest.fn(),
      payPalClientToken: jest.fn(),
      profileCreditCardList: {
        profileCreditCards: []
      },
      paypalEnvironment : jest.fn(),
      broadcastMessage:jest.fn(),
      editCreditCardData : {
        contactInfo: jest.fn()
      },
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: { },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: { }
        },
        messages: [
          {
            messageDesc:'Enter security code',
            messageKey:'errorCvvCode',
            messageRef:'paymentInfo.paymentDetails.cardVerificationNumber',
            messageType:'Error'
          }
        ]
      }
    };

    let component = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props }/>
      </Provider>
    );
    expect( component.find( '.PaymentDefaultCreditCard' ).length ).toBe( 1 );
    expect( component.find( '.PaymentCreditCardPayPal' ).length ).toBe( 0 );
    expect( component.find( 'PaymentDefaultCreditCard' ).instance().props.selectedPaymentRef ).toBeTruthy();

    var node = component.find( 'PaymentInformation' ).instance();
    node.handleChangeCreditCardPaypal();
    expect( node.state.showDefaultCreditCard ).toBe( false );
    expect( props.handleScrollView ).toBeCalled();

    node.handleCancelAddCreditCard();
    expect( node.state.showAddCreditCard ).toBe( false );
    expect( props.handleScrollView ).toBeCalled();

    jest.useFakeTimers( );

    node.handleAccessibility();
    node.selectedPayment.focus = jest.fn();
    jest.runAllTimers();
    expect( props.broadcastMessage ).toBeCalled();
    expect( node.selectedPayment.focus ).toBeCalled();
    // The function was called exactly once
    expect( setTimeout.mock.calls.length ).toBe( 1 );
    // The second arg of the first call to the function was 2000( delay in ms )
    expect( setTimeout.mock.calls[0][1] ).toBe( 2000 );

    node.handleAccessibility = jest.fn();
    node.handleChangePaypalAccount();
    expect( node.state.showDefaultCreditCard ).toBe( true );
    expect( props.handleScrollView ).toBeCalled();
    expect( node.handleAccessibility ).toBeCalled();

    node.handleChangeCreditCard( {
      creditCardNumber: '1111',
      contactInfo:{
        firstName: 'Test',
        address2: 'test'
      }
    } );
    expect( props.updatePaymentServiceResponse ).toBeCalled();
    expect( node.state.showDefaultCreditCard ).toBe( true );
    expect( props.handleScrollView ).toBeCalled();
    expect( node.handleAccessibility ).toBeCalled();
  } );

  it( 'renders Payment Form Component without crashing when have error messages but not related to CCV', () => {
    let props = {
      isSignedIn: true,
      paymentType: 'creditCard',
      setCreditCardPaymentType:jest.fn(),
      setEditCreditCardData:jest.fn(),
      handleCancelErrorCreditCard:jest.fn(),
      handleAddNewCreditCard:jest.fn(),
      handleScrollView:jest.fn(),
      cartSummary:{
        estimatedTotal:'12.00'
      },
      checkoutFormConfig:{ showHideCheckoutToggleData:{} },
      getProfileCreditCardList:jest.fn(),
      profileCreditCardList: {
        profileCreditCards: []
      },
      payPalClientToken: jest.fn(),
      paypalEnvironment : jest.fn(),
      editCreditCardData : {
        contactInfo: jest.fn()
      },
      paymentDetails: [
        {
          messages: [
            {
              messageDesc:'Enter a valid credit card numbe',
              messageKey:'CARD_NUMBER_NOT_VALID',
              messageRef:'paymentInfo.paymentDetails.creditCardNumber',
              messageType:'Error'
            }
          ],
          paymentInfo: {
            paymentType: 'creditCard',
            paymentDetails: { },
            amount: 46.18,
            currencyCode: 'USD',
            contactInfo: { }
          }
        }
      ],
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: { },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: { }
        },
        messages: [
          {
            messageDesc:'Enter a valid credit card numbe',
            messageKey:'CARD_NUMBER_NOT_VALID',
            messageRef:'paymentInfo.paymentDetails.creditCardNumber',
            messageType:'Error'
          }
        ]
      }
    };

    const component = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props }/>
      </Provider>
    );
    expect( component.find( '.PaymentDefaultCreditCard' ).length ).toBe( 0 );
    expect( component.find( '.PaymentCreditCardPayPal' ).length ).toBe( 1 );
    expect( component.find( '.PaymentForm' ).length ).toBe( 1 );

    var node = component.find( 'PaymentInformation' ).instance();
    node.handleCancelErrorCreditCard();
    expect( node.state.showDefaultCreditCard ).toBe( false );
    expect( props.handleScrollView ).toBeCalled();

    node.handleAddNewCreditCard();
    expect( node.state.showDefaultCreditCard ).toBe( true );
    expect( props.handleScrollView ).toBeCalled();
  } );

  it( 'renders PaymentDefaultCreditCard Component without crashing when get payment Error from submit order ', () => {
    let props = {
      isSignedIn: true,
      paymentType: 'creditCard',
      setCreditCardPaymentType:jest.fn(),
      setEditCreditCardData:jest.fn(),
      payPalClientToken: jest.fn(),
      paypalEnvironment : jest.fn(),
      cartSummary:{
        estimatedTotal:'12.00'
      },
      checkoutFormConfig:{ showHideCheckoutToggleData:{} },
      editCreditCardData : {
        contactInfo: jest.fn()
      },
      paymentError: [
        {
          messageDesc:'Enter a valid credit card number',
          messageKey:'CARD_NUMBER_NOT_VALID',
          messageRef:'paymentInfo.paymentDetails.creditCardNumber',
          messageType:'Error'
        }
      ],
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: { },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: { }
        },
        messages:[]
      }
    };

    const component = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props }/>
      </Provider>
    );
    expect( component.find( '.PaymentInformation__errorMessagesPanel' ).length ).toBe( 1 );
  } );

  it( 'should focus on error message div if credit card payment response has error', () => {
    const propsWithPaymentError = {
      isSignedIn: true,
      paymentType: 'creditCard',
      setCreditCardPaymentType:jest.fn(),
      setEditCreditCardData:jest.fn(),
      payPalClientToken: jest.fn(),
      paypalEnvironment : jest.fn(),
      cartSummary:{
        estimatedTotal:'12.00'
      },
      checkoutFormConfig:{ showHideCheckoutToggleData:{} },
      editCreditCardData : {
        contactInfo: jest.fn()
      },
      paymentError: [
        {
          messageDesc:'Enter a valid credit card number',
          messageKey:'CARD_NUMBER_NOT_VALID',
          messageRef:'paymentInfo.paymentDetails.creditCardNumber',
          messageType:'Error'
        }
      ],
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: { },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: { }
        },
        messages:[]
      }
    };
    const prevProps = {
      paymentError: [],
      creditCardDetails: {
        messages: []
      }
    }
    const componentWithPaymentError = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...propsWithPaymentError } />
      </Provider> );
    const focusMock = jest.fn();
    componentWithPaymentError.find( 'PaymentInformation' ).instance().errorPanelPaymentErrorMessage.focus = focusMock;
    componentWithPaymentError.find( 'PaymentInformation' ).instance().componentDidUpdate( prevProps );
    expect( componentWithPaymentError.find( 'PaymentInformation' ).instance().errorPanelPaymentErrorMessage.focus ).toBeCalled();
  } );

  it( 'renders UltamateRewardsCreditCard Component without crashing when ultamateRewardsCCInfo data passed ', () => {
    let props = {
      isSignedIn: true,
      paymentType: 'creditCard',
      handleAddCreditCard:jest.fn(),
      setCreditCardPaymentType:jest.fn(),
      setEditCreditCardData:jest.fn(),
      setEditAddressData:jest.fn(),
      cartSummary:{
        estimatedTotal:'12.00'
      },
      checkoutFormConfig:{ showHideCheckoutToggleData:{} },
      handleScrollView:jest.fn(),
      ultamateRewardsCCInfo: {
        hasUltaCC: true,
        appliedToProfile: false,
        msgHeader: 'Save 20% on this order! Plus start earning 2 points per dollar!',
        msgTxt: 'Get the Ultamate Rewards Credit Card',
        action: 'add'
      },
      paypalEnvironment : jest.fn(),
      editCreditCardData : {
        paymentType: 'creditCard',
        paymentDetails: { },
        amount: 46.18,
        currencyCode: 'USD',
        contactInfo: { }
      },
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: { },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: { }
        },
        messages:[
          {
            messageDesc:'Enter a valid credit card numbe',
            messageKey:'CARD_NUMBER_NOT_VALID',
            messageRef:'paymentInfo.paymentDetails.creditCardNumber',
            messageType:'Error'
          }
        ]
      }
    };

    store.getState().form.paymentForm = {
      values: {
        creditCardNumber: '1111',
        expirationDate: '09/2021',
        creditCardType: 'Visa',
        securityCode: 123,
        firstName: 'Test',
        lastName: 'Test'
      }
    }

    const component = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props }/>
      </Provider>
    );
    expect( component.find( '.UltamateRewardsCreditCard' ).length ).toBe( 1 );
    var node = component.find( 'PaymentInformation' ).instance();
    node.handleAddCreditCard( 'default' );
    expect( props.setEditCreditCardData ).toBeCalled();
    expect( props.setEditAddressData ).toBeCalled();
    expect( node.state.cancelFlag ).toBe( false );
    expect( props.handleScrollView ).toBeCalled();
    node.handleAddCreditCard( 'add' );
    expect( node.state.cancelFlag ).toBe( true );
  } );

  it( 'renders Payment Form Component without crashing', () => {
    let props1 = {
      cartAndCheckout: {
        multiFormAddressOpen: true
      },
      payPalClientToken: 'abcd1234',
      paypalEnvironment : '',
      creditCardDetails: {},
      cartSummary:{
        estimatedTotal:'12.00'
      },
      checkoutFormConfig:{ showHideCheckoutToggleData:{} }
    };
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props1 }/>
      </Provider>
    );
    expect( component1.find( '.PaymentForm' ).length ).toBe( 1 );
  } );

  it( 'renders PaymentCreditCardPayPal Component without crashing', () => {
    let props1 = {
      cartAndCheckout: {
        multiFormAddressOpen: true
      },
      payPalClientToken:'',
      paypalEnvironment : '',
      creditCardDetails: {},
      cartSummary:{
        estimatedTotal:'12.00'
      },
      checkoutFormConfig:{ showHideCheckoutToggleData:{} }
    };
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props1 }/>
      </Provider>
    );
    expect( component1.find( 'PaymentCreditCardPayPal' ).length ).toBe( 1 );
  } );

  // Test Cases for verifying form when billing address is null
  it( 'renders Payment Form when billing address is null', () => {
    let props2 = {
      isSignedIn: true,
      setCreditCardPaymentType:jest.fn(),
      setEditCreditCardData:jest.fn(),
      paymentType :'creditCard',
      payPalClientToken: jest.fn(),
      checkoutFormAddress2Open:{
        paymentAddressForm:{}
      },
      cartSummary:{
        estimatedTotal:'12.00'
      },
      checkoutFormConfig:{ showHideCheckoutToggleData:{} },
      paypalEnvironment : jest.fn(),
      editCreditCardData : {
        contactInfo: jest.fn()
      },
      editAddressData:{
        refId:''
      },
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: true
      },
      creditCardDetails: {
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: null
        },
        messages: [
          {
            messageDesc:'Enter first name',
            messageKey:'errBillingFirstName',
            messageRef:'paymentInfo.contactInfo.firstName',
            messageType:'Error'
          }
        ]
      }
    };
    let component3 = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props2 }/>
      </Provider>
    );
    expect( component3.find( '.PaymentForm' ).length ).toBe( 1 );
    expect( component3.find( '.PaymentForm__cancelAndDone--cancel' ).length ).toBe( 0 );
  } );

  it( 'not to renders Payment Form in PaymentInformation component when billing address is null but no error object', () => {
    let props7 = {
      isSignedIn: true,
      setCreditCardPaymentType:jest.fn(),
      setEditCreditCardData:jest.fn(),
      paymentType :'creditCard',
      checkoutFormAddress2Open:{
        paymentAddressForm:{}
      },
      payPalClientToken: jest.fn(),
      cartSummary:{
        estimatedTotal:'12.00'
      },
      checkoutFormConfig:{ showHideCheckoutToggleData:{} },
      paypalEnvironment : jest.fn(),
      editCreditCardData : {
        contactInfo: jest.fn()
      },
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        checkoutFormAddress2Open:{
          paymentAddressForm:{}
        },
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        },
        messages: []
      }
    };
    let component7 = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props7 }/>
      </Provider>
    );
    expect( component7.find( '.PaymentForm' ).length ).toBe( 0 );
  } );

  describe( 'Test Cases for verifying form when payment Type is paypal', () => {
    const props3 = {
      isSignedIn: true,
      setCreditCardPaymentType:jest.fn(),
      setEditCreditCardData:jest.fn(),
      paymentType :'paypal',
      showDefaultCreditCard:true,
      getProfileCreditCardList:jest.fn(),
      payPalClientToken: jest.fn(),
      paypalEnvironment : jest.fn(),
      editCreditCardData :{
        contactInfo: jest.fn()
      },
      creditCardDetails:{
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        paymentInfo: {
          paymentType: 'paypal',
          paymentDetails: {
            emailAddress: 'ecomqaoffshore@ulta.com'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: null
        }
      }
    };
    const component4 = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props3 }/>
      </Provider>
    );
    it( 'renders Default credit card when payment type is selected as paypal', () => {
      expect( component4.find( '.PaymentDefaultCreditCard' ).length ).toBe( 1 );
      expect( component4.find( '.PaymentDefaultCreditCard__Paypal' ).length ).toBe( 1 );
      expect( component4.find( '.PaypalWithPaypalAccount__Image' ).length ).toBe( 1 );
      expect( component4.find( '.PaypalWithPaypalAccount__Text' ).length ).toBe( 1 );
      expect( component4.find( '.PaypalWithPaypalAccount__Text__line1' ).text() ).toBe( messages.payWithPaypal.defaultMessage );
      expect( component4.find( '.PaypalWithPaypalAccount__Text__line2' ).text() ).toBe( 'ecomqaoffshore@ulta.com' );
    } );

    it( 'getProfileCreditCardList action gets triggerred when a logged in user have payment type is selected as paypal', () => {
      expect( component4.find( 'PaymentInformation' ).at( 0 ).props().getProfileCreditCardList ).toBeCalled();
    } );

  } );

  describe( 'Test cases for Handle change events', () => {

    let component5;
    let props5 = {
      isSignedIn: jest.fn(),
      showDefaultCreditCard: false,
      setCreditCardPaymentType: jest.fn(),
      setEditAddressData:jest.fn(),
      setEditCreditCardData: jest.fn(),
      checkoutFormConfig: { showHideCheckoutToggleData: {} },
      handleScrollView: jest.fn(),
      cartSummary:{
        estimatedTotal:'12.00'
      },
      profileCreditCardList: {
        profileCreditCards: [
          {
            creditCard: {
              expirationYear: '2025',
              contactInfo: {
                lastName: 'Ambula',
                country: 'US',
                address2: 'Apt 312',
                city: 'Naperville',
                address1: '724 Greenwood Cir',
                postalCode: '60563',
                firstName: 'Anup',
                phoneNumber: '123-456-7890',
                state: 'IL'
              },
              nickName: 'Visa - 1111',
              creditCardType: 'Visa',
              expirationMonth: '09',
              isEditable: true,
              creditCardNumber: '1111',
              isPrimary: true
            }
          },
          {
            creditCard: {
              expirationYear: '2023',
              contactInfo: {
                lastName: 'Ambula',
                country: 'US',
                address2: 'Apt 312',
                city: 'Naperville',
                address1: '724 Greenwood Cir',
                postalCode: '60563',
                firstName: 'Anup Sharan',
                phoneNumber: '123-456-7890',
                state: 'IL'
              },
              nickName: 'Mastercard - 4444',
              creditCardType: 'Mastercard',
              expirationMonth: '08',
              isEditable: true,
              creditCardNumber: '4444',
              isPrimary: false
            }
          }
        ]
      },
      getPaypalToken: jest.fn(),
      getProfileCreditCardList: jest.fn(),
      payPalClientToken: jest.fn(),
      paypalEnvironment: jest.fn(),
      enableExpressPaypalCheckout: true,
      broadcastMessage:jest.fn(),
      editCreditCardData: {
        contactInfo: jest.fn()
      },
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        },
        messages: [{
          type: 'success'
        }

        ]
      }
    };


    const store = configureStore( {}, CONFIG );
    component5 = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props5 } />
      </Provider>
    );

    it( 'handles  CreditCard change event', () => {
      const handleChangeCreditCard = jest.fn();
      const node1 = component5.find( 'PaymentInformation' );
      component5.find( 'PaymentInformation .PaymentDefaultCreditCard .Anchor' ).simulate( 'click' );
      component5.find( 'PaymentInformation .ProfileCreditCardList .ProfileCreditCardList__container--section--done .Anchor' ).simulate( 'click' );
      expect( node1.at( 0 ).props().handleScrollView ).toBeCalled();
    } );

    it( 'handles Add CreditCard  event', () => {
      const handleAddCreditCard = jest.fn();
      const node1 = component5.find( 'PaymentInformation' );
      component5.find( 'PaymentInformation .PaymentDefaultCreditCard .Anchor' ).simulate( 'click' );
      component5.find( 'PaymentInformation .ProfileCreditCardList .ProfileCreditCardList__container--section--newcard .Anchor' ).simulate( 'click' );
      expect( node1.at( 0 ).props().handleScrollView ).toBeCalled();
    } );

    it( 'handles Edit CreditCard  event', () => {
      let component6;
      component6 = mountWithIntl(
        <Provider store={ store }>
          <PaymentInformation { ...props5 } />
        </Provider>
      );
      const handleEditCreditCard = jest.fn();
      const node1 = component5.find( 'PaymentInformation' );
      component6.find( 'PaymentInformation .PaymentDefaultCreditCard .Anchor' ).simulate( 'click' );
      component6.find( 'PaymentInformation .ProfileCreditCardList .ProfileCreditCardList__container--link' ).at( 0 ).find( '.Anchor' ).simulate( 'click' );
      expect( node1.at( 0 ).props().handleScrollView ).toBeCalled();
    } );


  } );

  describe( 'Test Cases for Error Messages Panel', () => {
    let component7;
    let props7 = {
      isSignedIn: jest.fn(),
      showDefaultCreditCard: false,
      setCreditCardPaymentType: jest.fn(),
      setEditAddressData:jest.fn(),
      setEditCreditCardData: jest.fn(),
      checkoutFormConfig: { showHideCheckoutToggleData: {} },
      handleScrollView: jest.fn(),
      cartSummary:{
        estimatedTotal:'12.00'
      },
      profileCreditCardList: {
        profileCreditCards: [
          {}
        ]
      },
      paymentError:[
        {
          messageKey :'invalidCreditCardVerificationNumber',
          messageType: 'Error',
          messageDesc: 'Please enter a valid credit card verification number.',
          messageRef:'payment'
        }
      ],
      getPaypalToken: jest.fn(),
      getProfileCreditCardList: jest.fn(),
      payPalClientToken: jest.fn(),
      paypalEnvironment: jest.fn(),
      enableExpressPaypalCheckout: true,
      editCreditCardData: {
        contactInfo: jest.fn()
      },
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {},
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {}
        },
        messages: [{
          type: 'success'
        }

        ]
      }
    };
    const store = configureStore( {}, CONFIG );
    component7 = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props7 } />
      </Provider>
    );

    it( 'renders PaymentInformation__errorMessagesPanel', () => {
      expect( component7.find( '.PaymentInformation .PaymentInformation__errorMessagesPanel' ).length ).toBe( 1 );
    } );

    it( 'renders PaymentCreditCardPayPal', () => {
      let props8= {
        isSignedIn: jest.fn(),
        showDefaultCreditCard: false,
        checkoutFormAddress2Open:{
          paymentAddressForm:{}
        },
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        editAddressData:{
          refId:''
        },
        setCreditCardPaymentType: jest.fn(),
        setEditAddressData:jest.fn(),
        setEditCreditCardData: jest.fn(),
        cartSummary:{
          estimatedTotal:'12.00'
        },
        checkoutFormConfig: { showHideCheckoutToggleData: {} },
        handleScrollView: jest.fn(),
        profileCreditCardList: {
          profileCreditCards: [{}]
        },
        paymentError:[
          {
            messageKey :'invalidCreditCardVerificationNumber',
            messageType: 'Error',
            messageDesc: 'Please enter a valid credit card verification number.',
            messageRef:'payment'
          }
        ],
        getPaypalToken: jest.fn(),
        getProfileCreditCardList: jest.fn(),
        payPalClientToken: jest.fn(),
        paypalEnvironment: jest.fn(),
        enableExpressPaypalCheckout: true,
        creditCardDetails: {
          checkoutFormAddressOpen: {
            paymentAddressForm: false,
            shippingAddressForm: true
          },
          paymentInfo: {
            paymentType: 'creditCard',
            paymentDetails: {},
            amount: 46.18,
            currencyCode: 'USD',
            contactInfo: {}
          },
          messages: [{
            type: 'success'
          }
          ]
        }
      };

      const store = configureStore( {}, CONFIG );
      const component8 = mountWithIntl(
        <Provider store={ store }>
          <PaymentInformation { ...props8 } />
        </Provider>
      );
      expect( component8.find( '.PaymentInformation .PaymentCreditCardPayPal' ).length ).toBe( 1 );
    } );


  } );

  describe( '<PaymentInformtion />', ( ) => {
    var props = {
      isSignedIn: true,
      paymentType: 'creditCard',
      setEditCreditCardData:jest.fn(),
      assignPaymentAddress:jest.fn(),
      ultamateRewardsCCInfo: { },
      paypalEnvironment : jest.fn(),
      cartSummary:{
        estimatedTotal:'12.00'
      },
      checkoutFormConfig:{ showHideCheckoutToggleData:{} },
      editCreditCardData : {
        paymentType: 'creditCard',
        nickName: 'nickName-VISA',
        paymentDetails: {
          expirationMonth: '09',
          expirationYear: '2021',
          creditCardNumber: '1111',
          creditCardType: 'Visa'
        },
        amount: 46.18,
        currencyCode: 'USD',
        contactInfo: { }
      },
      broadcastMessage:jest.fn(),
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        paymentInfo: {
          paymentType: 'creditCard',
          nickName: 'nickName-VISA',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: { }
        },
        messages:[]
      },
      showProfileCreditCardsSpinner: true,
      getProfileCreditCardList: jest.fn(),
      handleScrollView: jest.fn()
    };

    var props1 = {
      isSignedIn: true,
      paymentType: 'creditCard',
      setEditCreditCardData:jest.fn(),
      assignPaymentAddress:jest.fn(),
      checkoutFormConfig:{ showHideCheckoutToggleData:{} },
      ultamateRewardsCCInfo: { },
      paypalEnvironment : jest.fn(),
      editCreditCardData : {
        paymentType: 'creditCard',
        nickName: 'nickName-VISA',
        cartSummary:{
          estimatedTotal:'12.00'
        },
        checkoutFormConfig:{ showHideCheckoutToggleData:{} },
        paymentDetails: {
          expirationMonth: '09',
          expirationYear: '2021',
          creditCardNumber: '2222',
          creditCardType: 'Visa'
        },
        amount: 50.18,
        currencyCode: 'USD',
        contactInfo: { }
      },
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        paymentInfo: {
          paymentType: 'creditCard',
          nickName: 'nickName-VISA',
          paymentDetails: { },
          amount: 50.18,
          currencyCode: 'USD',
          contactInfo: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '2222',
            creditCardType: 'Visa'
          }
        },
        messages:[]
      }
    };

    var node = document.createElement( 'div' );
    global.braintree = { client:{ create:jest.fn() } };
    const initialState={
      showDefaultCreditCard: true,
      showAddCreditCard: false
    }
    const store = configureStore( {}, CONFIG );

    component = mountWithIntl(
      <Provider store={ store }>
        <PaymentInformation { ...props }/>
      </Provider>
    );

    ReactDOM.render(
      <IntlProvider locale='en'>
        <Provider store={ store }>
          <PaymentInformation { ...props }/>
        </Provider >
      </IntlProvider>, node
    );
    it( 'calls someFunction()', ( ) => {
      ReactDOM.render(
        <IntlProvider locale='en'>
          <Provider store={ store }>
            <PaymentInformation { ...props1 }/>
          </Provider >
        </IntlProvider>, node
      );

      var nodes = component.find( 'PaymentInformation' ).instance();
      expect( nodes.state.paymentCCData.nickName ).toBe( 'nickName-VISA' );
    } );

    it( 'calls setEditCreditCardData() if showAddCreditCard value is false', ( ) => {

      expect( props.setEditCreditCardData ).toBeCalled();
    } );

    it( 'should not call setEditCreditCardData() if showAddCreditCard value is true', ( ) => {
      props.handleScrollView = jest.fn();
      props.setEditCreditCardData = jest.fn();
      props.setEditAddressData = jest.fn();
      let componenet6 = mountWithIntl(
        <Provider store={ store }>
          <PaymentInformation { ...props }/>
        </Provider>
      );
      // handleAddCreditCard method will set showAddCreditCard to true
      var node = componenet6.find( 'PaymentInformation' ).instance();
      node.handleAddCreditCard();
      let prevVal = props.setEditCreditCardData.mock.calls.length;
      node.assignPaymentAddress();
      let nextVal = props.setEditCreditCardData.mock.calls.length;
      // If showAddCreditCard is true then setEditCreditCardDatawill not be invoked when assignPaymentAddress method is called
      expect( prevVal ).toBe( nextVal );
    } );

    it( 'calls setEditCreditCardData() if showAddCreditCard value is true', ( ) => {
      props.handleScrollView = jest.fn();
      props.setEditCreditCardData = jest.fn();
      props.setEditAddressData = jest.fn();
      let componenet6 = mountWithIntl(
        <Provider store={ store }>
          <PaymentInformation { ...props }/>
        </Provider>
      );
      var node = componenet6.find( 'PaymentInformation' ).instance();
      let prevVal = props.setEditCreditCardData.mock.calls.length;
      node.assignPaymentAddress();
      let nextVal = props.setEditCreditCardData.mock.calls.length;
      // If showAddCreditCard is false then setEditCreditCardDatawill will be invoked when assignPaymentAddress method is called
      expect( prevVal ).not.toBe( nextVal );
    } );

    it( 'it should show spinner if the creditcards list data is still loading', ( ) => {
      expect( component.find( '.PaymentInformation__spinner' ).length ).toBe( 1 );
    } );

    it( 'it should make opacity to 70% if there is a spinner on the default credit card view', ( ) => {
      expect( component.find( '.PaymentInformation__creditCardPaypalContainer .PaymentInformation__changeCreditcardPayPal' ).length ).toBe( 1 );
    } );

    it( 'Should call the profile creditcards service on click of `changeCredit card or use paypal` link', () => {
      const handleAddCreditCard = jest.fn();
      const node1 = component.find( 'PaymentInformation' );
      component.find( 'PaymentInformation .PaymentDefaultCreditCard .Anchor' ).simulate( 'click' );
      expect( node1.at( 0 ).props().getProfileCreditCardList ).toBeCalled();
    } );

    it( 'should call assignPaymentAddress() on update of paymentDetails', ( ) => {

      let props1 = {
        cartAndCheckout: {
          multiFormAddressOpen: true
        },
        payPalClientToken: jest.fn(),
        creditCardDetails: {
          paymentInfo: {
            paymentDetails:{}
          }
        },
        cartSummary:{
          estimatedTotal:'12.00'
        },
        checkoutFormConfig:{ showHideCheckoutToggleData:{} }
      };
      let props2 = {
        paymentType: 'creditCard',
        setEditCreditCardData:jest.fn(),
        ultamateRewardsCCInfo: { },
        cartSummary:{
          estimatedTotal:'12.00'
        },
        checkoutFormConfig:{ showHideCheckoutToggleData:{} },
        editCreditCardData : {
          paymentType: 'creditCard',
          nickName: 'nickName-VISA',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: { }
        },
        creditCardDetails: {
          checkoutFormAddressOpen: {
            paymentAddressForm: false,
            shippingAddressForm: true
          },
          paymentInfo: {
            paymentType: 'creditCard',
            nickName: 'nickName-VISA',
            paymentDetails: {
              expirationMonth: '09',
              expirationYear: '2021',
              creditCardNumber: '1111',
              creditCardType: 'Visa'
            },
            amount: 46.18,
            currencyCode: 'USD',
            contactInfo: { }
          },
          messages:[]
        }
      };
      let componenet6 = mountWithIntl(
        <Provider store={ store }>
          <PaymentInformation { ...props1 }/>
        </Provider>
      );
      const assignPaymentAddressMock = jest.fn();
      componenet6.find( 'PaymentInformation' ).instance().assignPaymentAddress = assignPaymentAddressMock;
      componenet6.find( 'PaymentInformation' ).instance().componentDidUpdate( props1 );
      expect( assignPaymentAddressMock ).not.toBeCalled();
      componenet6.find( 'PaymentInformation' ).instance().componentDidUpdate( props2 );
      expect( assignPaymentAddressMock ).toBeCalled();
    } );

  } );

} );
