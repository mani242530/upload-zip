/**
 * PaymentSecurityCode
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Field, reduxForm } from 'redux-form';
import { connect } from 'react-redux';
import './PaymentSecurityCode.css';
import messages from './PaymentSecurityCode.messages';
import { isEqual, isUndefined, has } from 'lodash';
import InputField from 'shared/components/InputField/InputField';
import CreditCardBackView from 'shared/components/Icons/creditcardback';
import CreditCardAmexFrontView from 'shared/components/Icons/creditcardamexfront';
import { formatMessage } from 'shared/components/Global/Global';
import {
  requiredValidation,
  validateSecurityCode
} from 'utils/FormValidations/FormValidations';

const propTypes = {
  handleChangeCreditCardPaypal: PropTypes.func,
  showSecurityIcon: PropTypes.bool,
  toggleSecurityCode: PropTypes.func,
  displayType: PropTypes.string,
  tabIndex: PropTypes.number,
  paymentDetails: PropTypes.object,
  editCCData: PropTypes.object,
  showSecurityCodeMaskedValue: PropTypes.string,
  creditCardDetails: PropTypes.object,
  tempPaymentCCVNumber: PropTypes.string,
  updatePaymentServiceResponse: PropTypes.func
}

export const mapStateToProps = ( state ) => {
  return {
    PaymentCCSecurityCodeForm: state.form.PaymentCCSecurityCode
  };
}

/**
 * Class
 * @extends React.Component
 */
class PaymentSecurityCode extends Component{

  /**
   * Create a PaymentSecurityCode
   */
  constructor( props ){
    super( props );
    this.state = {
      initialSecurityCode: '',
      showHintText:false
    }
    this.updateCreditCard = this.updateCreditCard.bind( this );
    this.toggleSecurityIcon = this.toggleSecurityIcon.bind( this );
  }

  updateCreditCard( e ){
    const {
      values,
      syncErrors
    } = this.props.PaymentCCSecurityCodeForm;

    if( e.target.value !== '' ){
      const data = {
        values:{
          ...this.props.editCCData,
          cardVerificationNumber: e.target.value
        }
      }

      if(
        values &&
        !isEqual( this.state.initialSecurityCode, data.values.cardVerificationNumber ) &&
        isUndefined( syncErrors.ccSecurityCode )
      ){
        this.setState( {
          initialSecurityCode: data.values.cardVerificationNumber
        } );
        this.props.updatePaymentServiceResponse( data );
      }
    }
  }
  toggleHinttext(){
    this.setState( { showHintText:true } );
    this.props.toggleSecurityCode( true, this.props.displayType );
  }

  toggleSecurityIcon(){
    this.props.toggleSecurityCode( false, this.props.displayType );
  }

  /**
   * Renders the PaymentSecurityCode component
   */
  render(){

    const {
      paymentDetails
    } = this.props;

    let paymentDefaultForHTML = ( <div className='PaymentSecurityCode'>
      <div className='PaymentSecurityCode--securitycode'>
        { ( ()=>{
          if( ( ( has( this.props, 'PaymentCCSecurityCodeForm.values.ccSecurityCode' ) && this.props.PaymentCCSecurityCodeForm.values.ccSecurityCode !== '' ) || this.props.showSecurityIcon ) ){
            return (
              <div className='PaymentSecurityCode--securitycode--cardback'>
                <span>
                  { ( () =>{
                    if( this.state.cardType === 'AmericanExpress' ){
                      return ( <CreditCardAmexFrontView/> );
                    }
                    else {
                      return ( <CreditCardBackView/> );
                    }
                  } )() }
                </span>
              </div>
            )
          }
        } )() }

        <InputField
          label={ formatMessage( messages.SecurityCode ) }
          type='tel'
          name='ccSecurityCode'
          autoComplete='off'
          formatter={ { pattern: ( paymentDetails.creditCardType === 'AmericanExpress' ) ? '9999' : '999' } }
          value={ ( this.props.tempPaymentCCVNumber ) ? this.props.tempPaymentCCVNumber : '' }
          formName={ 'payment & billing' }
          trackAnalytics={ true }
          maskedToggleTarget='ccSecurityCode'
          showMaskedValue={ this.props.showSecurityCodeMaskedValue }
          onFocus={ this.toggleHinttext.bind( this ) }
          handleBlur={ this.toggleSecurityIcon }
          tabIndex={ this.props.tabIndex+1 }
        />
        { ( () =>{
          if( this.state.showHintText ){
            return (
              <div className='hinttext'>
                { paymentDetails.creditCardType === 'AmericanExpress' ? formatMessage( messages.SecurityCodeHintTextAmex ) : formatMessage( messages.SecurityCodeHintText ) }
              </div>
            )
          }
        } )() }
      </div>
    </div> )
    return (
      <form onBlur={ this.updateCreditCard }>
        { paymentDefaultForHTML }
      </form>
    );
  }
}

PaymentSecurityCode.propTypes = propTypes;

export const validate = ( values, props ) => {
  const errors = {};
  let requiredFields = [];
  const isValidateSecurityCode = validateSecurityCode( props.creditCardDetails.paymentInfo.paymentDetails.creditCardType );
  requiredFields = ['ccSecurityCode'];

  requiredFields.map(
    field => {
      if( !values[field] ){
        errors[field] = requiredValidation( values[field] );
      }
    }
  );

  if( values.ccSecurityCode ){
    errors.ccSecurityCode = isValidateSecurityCode( values.ccSecurityCode );
  }

  return errors;
};

export default reduxForm( {
  form: 'PaymentCCSecurityCode',
  validate
} )( connect( mapStateToProps )( PaymentSecurityCode ) );