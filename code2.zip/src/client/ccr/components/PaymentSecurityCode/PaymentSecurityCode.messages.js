/*
 * PaymentSecurityCode Messages
 *
 * This contains all the text for the PaymentSecurityCode component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  SecurityCode: {
    id: 'i18n.PaymentDefaultCreditCard.SecurityCode',
    defaultMessage: 'Security Code'
  },
  SecurityCodeHintText: {
    id: 'i18n.PaymentDefaultCreditCard.ChangeCCPaypal',
    defaultMessage: '3 digit code on card back'
  },
  SecurityCodeHintTextAmex: {
    id: 'i18n.PaymentInformation.ChangeCCPaypal',
    defaultMessage: '4 digit code on card front'
  }
} );
