import React from 'react';
import ReactDOM from 'react-dom';
import PaymentSecurityCode from './PaymentSecurityCode';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';

describe( '<PaymentSecurityCode />', () => {

  let component;

  let props = {

    creditCardDetails: {

      paymentInfo: {
        paymentType: 'creditCard',
        paymentDetails: {
          expirationMonth: '09',
          expirationYear: '2021',
          creditCardNumber: '1111',
          creditCardType: 'Visa'
        },
        amount: 46.18,
        currencyCode: 'USD',
        contactInfo: {
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          email: 'pkabdaula@ulta.com',
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city: 'Boolingbrook',
          state: 'IL',
          postalCode: '07105',
          country: 'US'
        }
      }
    },
    paymentDetails: {
      expirationMonth: '09',
      expirationYear: '2021',
      creditCardNumber: '1111',
      creditCardType: 'Visa'
    },
    showSecurityIcon: true
  };

  const store = configureStore( {}, CONFIG );

  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <Provider store={ store } >
        <PaymentSecurityCode { ...props }/>
      </Provider>
    );
    expect( component.find( 'PaymentSecurityCode' ).length ).toBe( 1 );
  } );

  it( 'should have security code field with type tel', () => {
    component = mountWithIntl(
      <Provider store={ store } >
        <PaymentSecurityCode { ...props }/>
      </Provider>
    );
    expect( component.find( '#ccSecurityCode' ).props().type ).toBe( 'tel' );
  } );

  it( 'should have security code field with autocomplete off', () => {

    component = mountWithIntl(
      <Provider store={ store } >
        <PaymentSecurityCode { ...props }/>
      </Provider>
    );
    expect( component.find( '#ccSecurityCode' ).props().autoComplete ).toBe( 'off' );
  } );

  it( 'should render securrity code icon if there is value in the security code field', () => {
    store.getState().form.PaymentCCSecurityCodeForm= {
      values: {
        ccSecurityCode: '123'
      }
    }
    component = mountWithIntl(
      <Provider store={ store } >
        <PaymentSecurityCode { ...props }/>
      </Provider>
    );
    expect( component.find( '.PaymentSecurityCode--securitycode--cardback' ).length ).toBe( 1 ) ;
  } );

  it( 'should not render security code icon if there is no value in the security code field', () => {
    let props = {

      creditCardDetails: {

        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        }
      },
      paymentDetails: {
        expirationMonth: '09',
        expirationYear: '2021',
        creditCardNumber: '1111',
        creditCardType: 'Visa'
      },
      showSecurityIcon: false
    };
    store.getState().form.PaymentCCSecurityCodeForm= {
      values: {
        ccSecurityCode: ''
      }
    }
    let component1 = mountWithIntl(
      <Provider store={ store } >
        <PaymentSecurityCode { ...props }/>
      </Provider>
    );
    expect( component1.find( '.PaymentSecurityCode--securitycode--cardback' ).length ).toBe( 0 ) ;
  } );

  it( 'should  render securrity code icon if there is value in the security code field and showSecurityIcon flag is true', () => {
    let props = {

      creditCardDetails: {

        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        }
      },
      paymentDetails: {
        expirationMonth: '09',
        expirationYear: '2021',
        creditCardNumber: '1111',
        creditCardType: 'Visa'
      },
      showSecurityIcon: true
    };
    store.getState().form.PaymentCCSecurityCodeForm= {
      values: {
        ccSecurityCode: ''
      }
    }
    let component1 = mountWithIntl(
      <Provider store={ store } >
        <PaymentSecurityCode { ...props }/>
      </Provider>
    );
    expect( component1.find( '.PaymentSecurityCode--securitycode--cardback' ).length ).toBe( 1 ) ;
  } );

  it( 'Should invoke updatePaymentServiceRespons on blur of paymentSecurityCode', () => {
    store.getState().form.PaymentCCSecurityCode= {
      values: {
        ccSecurityCode: '123'
      }
    }
    let updatePaymentServiceResponseMock =jest.fn()
    let props1 = {
      updatePaymentServiceResponse:updatePaymentServiceResponseMock,
      creditCardDetails: {

        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        }
      },
      paymentDetails: {
        expirationMonth: '09',
        expirationYear: '2021',
        creditCardNumber: '111',
        creditCardType: 'Visa'
      },
      editCCData:{
        expirationMonth: '09',
        expirationYear: '2021',
        creditCardNumber: '111',
        creditCardType: 'Visa'
      },
      showSecurityIcon: true
    };

    let component1 = mountWithIntl(
      <Provider store={ store } >
        <PaymentSecurityCode { ...props1 }/>
      </Provider>
    );
    let node1 = component1.find( 'PaymentSecurityCode' ).instance();
    node1.state.initialSecurityCode = '1111';
    component1.update();
    component1.find( 'PaymentSecurityCode' ).simulate( 'blur', { target: { value: '111' } } );
    expect( updatePaymentServiceResponseMock ).toBeCalled();
  } );

} );
