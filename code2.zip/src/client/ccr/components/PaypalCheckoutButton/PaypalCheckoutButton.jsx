/**
 * PaypalCheckoutButton
 */

import React, { Component } from 'react';
import './PaypalCheckoutButton.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './PaypalCheckoutButton.messages';
import Button from 'shared/components/Button/Button';
import SVG from 'shared/components/Icons/paypalcheckout';
import isUndefined from 'lodash/isUndefined';
import has from 'lodash/has';


/**
 * Class
 * @extends React.Component
 */
class PaypalCheckoutButton extends Component{

  /**
   * Create a PaypalCheckoutButton
   */
  constructor( props ){
    super( props );
    this.renderPaypalButton = this.renderPaypalButton.bind( this );
  }

  componentDidMount(){
    if( !isUndefined( this.props.enablePaypalButton ) && this.props.enablePaypalButton ){
      this.props.getPaypalToken();
    }
  }

  componentDidUpdate( prevProps ){
    if( has( this.props, 'payPalClientToken' ) && !isUndefined( this.props.payPalClientToken ) && ( this.props.payPalClientToken !== prevProps.payPalClientToken ) ){
      this.renderPaypalButton();
    }
  }

  renderPaypalButton(){
    const braintree = global.braintree;

    const {
      getPaypalResponse,
      applyPayment,
      amount,
      currency,
      displayMode,
      onSuccessPaypalPayment,
      paypalEnvironment,
      history
    } = this.props;

    const isShippingEditable = displayMode !== 'tabView';
    braintree.client.create( {
      authorization: this.props.payPalClientToken
    }, function( clientErr, clientInstance ){
      if( clientErr ){
        getPaypalResponse( clientErr );
      }
      braintree.paypalCheckout.create( {
        client: clientInstance
      }, function( paypalCheckoutErr, paypalCheckoutInstance ){
        if( paypalCheckoutErr ){
          getPaypalResponse( paypalCheckoutErr );
        }
        global.paypal.Button.render( {
          env: ( paypalEnvironment || 'sandbox' ),
          style:{
            label: 'pay',
            size: 'responsive',
            color:'silver',
            shape: 'rect',
            tagline: false
          },
          payment: function(){
            return paypalCheckoutInstance.createPayment( {
              flow: 'vault', // Required
              currency: currency, // Required
              locale: 'en_US',
              enableShippingAddress: ( displayMode === 'button' ),
              enableBillingAddress: true,
              shippingAddressEditable: isShippingEditable
            } );
          },

          onError: function( err ){
            getPaypalResponse( err );
          },

          onAuthorize: function( data, actions ){
            return paypalCheckoutInstance.tokenizePayment( data )
              .then( function( payload ){
                let _payload = payload;
                getPaypalResponse( _payload );

                if( _payload.nonce ){
                  if( !isUndefined( history ) ){
                    _payload.history = history;
                  }
                  applyPayment( _payload );
                  if( !isUndefined( onSuccessPaypalPayment ) ){
                    onSuccessPaypalPayment();
                  }
                }
              } );
          }

        }, '#paypal-button' );

      } );

    } );
  }

  /**
   * Renders the PaypalCheckoutButton component
   */
  render(){


    return (
      <div id='paypal-button-iframe'>
        { ( () => {
          if( !isUndefined( this.props.enablePaypalButton ) && this.props.enablePaypalButton && this.props.payPalClientToken ){
            return (
              <div className='PaypalCheckoutButton paypal-button-container'>
                <div id='paypal-button'></div>
                <div className='text'>
                  { formatMessage( messages.paypalHintText ) }
                </div>
              </div>
            );
          }
        } )() }
      </div>
    );
  }
}

export default PaypalCheckoutButton;
