/*
 * PaypalCheckoutButton Messages
 *
 * This contains all the text for the PaypalCheckoutButton component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  paypalHintText: {
    id: 'i18n.PaypalCheckoutButton.paypalHintText',
    defaultMessage: 'You\'ll return to ulta.com to review and place your order.'
  }
} );
