import React from 'react';
import ReactDOM from 'react-dom';
import PaypalCheckoutButton from './PaypalCheckoutButton';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

describe( '<PaypalCheckoutButton />', () => {
  let component;
  const paypalCheckoutInstance = {
    createPayment:jest.fn(),
    tokenizePayment:jest.fn( () => new Promise( ( resolve, reject ) => {
      process.nextTick( () => resolve( { nonce:'12321321' } ) );

    } ) )
  }
  const createMock =  jest.fn( ( config, method ) => {
    method()
  } );
  window.braintree = {
    client:{
      create:createMock
    },
    paypalCheckout:{
      create:jest.fn( ( config, method ) => {
        method( null, paypalCheckoutInstance )
      } )
    }
  };
  window.paypal={
    Button:{
      render:jest.fn( ( input ) => {
        input.payment();
        input.onAuthorize();
      } )
    }
  }

  it( 'renders without crashing', () => {
    component = mountWithIntl( <PaypalCheckoutButton /> );

    expect( component.find( 'PaypalCheckoutButton' ).length ).toBe( 1 );
  } );

  it( 'should invoke create method of window.braintree when renderPaypalButton method is invoked', () => {
    const getPaypalResponseMock = jest.fn();
    const props = {
      payPalClientToken:'1232131232',
      history:{},
      getPaypalResponse:getPaypalResponseMock,
      applyPayment:jest.fn(),
      onSuccessPaypalPayment:jest.fn()
    }
    component = mountWithIntl( <PaypalCheckoutButton { ...props }/> );
    component.find( 'PaypalCheckoutButton' ).instance().renderPaypalButton();
    expect( createMock ).toBeCalled();
  } );

  it( 'should invoke renderPaypalButton method on componentDidUpdate', () => {
    const props = {
      payPalClientToken:'1232131232',
      history:{},
      getPaypalResponse:jest.fn()
    }
    component = mountWithIntl( <PaypalCheckoutButton { ...props }/> );
    const renderPaypalButtonMock = jest.fn();
    component.find( 'PaypalCheckoutButton' ).instance().renderPaypalButton=renderPaypalButtonMock;
    component.find( 'PaypalCheckoutButton' ).instance().componentDidUpdate( {} );
    expect( renderPaypalButtonMock ).toBeCalled();
  } );

} );