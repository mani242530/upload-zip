/**
 * PlaceOrderComponent
 */

import React, { Component } from 'react';
import './PlaceOrderComponent.css';
import { connect } from 'react-redux';
import { Field, reduxForm, touch, isValid } from 'redux-form';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './PlaceOrderComponent.messages';
import isUndefined from 'lodash/isUndefined';
import Button from 'shared/components/Button/Button';
import SVG from 'shared/components/Icons/lock';
import { find, has, isEmpty, omitBy, isNil, keys } from 'lodash';
import { fireAnalyticsEvent } from 'utils/Omniture/Omniture';
import VMasker from 'vanilla-masker';
import { actions } from 'shared/actions/Forms/Forms.actions'

export const mapStateToProps = ( state ) => {
  return {
    shippingValid: isValid( 'Shipping' )( state ),
    addEditShippingValid: isValid( 'shippingAddressList' )( state ),
    paymentValid: isValid( 'paymentForm' )( state ),
    paymentCardDetailsValid: isValid( 'PaymentCCSecurityCode' )( state ),
    shippingForm: ( state.form.Shipping ),
    paymentForm: ( state.form.paymentForm ),
    CouponForm: ( state.form.Coupon ),
    PaymentCCSecurityCode: ( state.form.PaymentCCSecurityCode ),
    addEditShippingForm: ( state.form.shippingAddressList ),
    submitOrderSpinner: state.checkoutPage.submitOrderSpinner
  };
}
export const mapDispatchToProps = ( dispatch ) => {
  return {
    setCouponErrorMessage: ( errorMessege ) => {
      dispatch( actions.setCouponErrorMessage( errorMessege ) )
    }
  };
}
/**
 * Class
 * @extends React.Component
 */
class PlaceOrderComponent extends Component{

  /**
   * Create a PlaceOrderComponent
   */
  constructor( props ){
    super( props );
    this.submitForms = this.submitForms.bind( this );
    this.isAddressFormDirty = this.isAddressFormDirty.bind( this );
  }

  componentDidUpdate( prevProps ){
    if( !isUndefined( this.props.isErrorBeforeSubmitOrder ) && isUndefined( prevProps.isErrorBeforeSubmitOrder ) ){
      if( this.props.isErrorBeforeSubmitOrder === 'payment' && this.props.paymentType === 'creditCard' ){
        this.props.handleScrollView( 'checkoutPaymentHeader' );
      }
      else if( this.props.isErrorBeforeSubmitOrder === 'shipping' ){
        this.props.handleScrollView( 'checkoutShippingHeader' );
      }
      else if( this.props.isErrorBeforeSubmitOrder === 'header' ){
        this.props.handleScrollView( 'js-global' );
      }
    }
    // If there is any error form submit order service response then user is anchored to the respective section depending anchorAfterSubmitServiceCall flag
    if( !isUndefined( this.props.anchorAfterSubmitServiceCall ) && isUndefined( prevProps.anchorAfterSubmitServiceCall ) ){
      if( this.props.anchorAfterSubmitServiceCall === 'payment' && this.props.paymentType === 'creditCard' ){
        this.props.handleScrollView( 'checkoutPaymentHeader' );
      }
      else if( this.props.anchorAfterSubmitServiceCall === 'shipping' ){
        this.props.handleScrollView( 'checkoutShippingHeader' );
      }
      else if( this.props.anchorAfterSubmitServiceCall === 'header' ){
        this.props.handleScrollView( 'js-global' );
      }
    }
  }
  // this method will check if the address form is dirty
  isAddressFormDirty = ( shippingAddress, formValues ) => {
    let phNumber =  !isUndefined( formValues.phoneNumbershippingAddressForm )?VMasker.toPattern( formValues.phoneNumbershippingAddressForm, '999-999-9999' ): '';
    if( ( formValues.firstNameshippingAddressForm && formValues.firstNameshippingAddressForm !== shippingAddress.firstName ) ||
      ( formValues.lastNameshippingAddressForm && formValues.lastNameshippingAddressForm !== shippingAddress.lastName ) ||
      ( formValues.address1shippingAddressForm && formValues.address1shippingAddressForm !== shippingAddress.address1 ) ||
      ( formValues.address2shippingAddressForm && formValues.address2shippingAddressForm !== shippingAddress.address2 ) ||
      ( formValues.cityshippingAddressForm && formValues.cityshippingAddressForm !== shippingAddress.city ) ||
      ( formValues.stateshippingAddressForm && formValues.stateshippingAddressForm !== shippingAddress.state ) ||
      ( formValues.countryshippingAddressForm && formValues.countryshippingAddressForm !== shippingAddress.country ) ||
      ( formValues.emailaddressshippingAddressForm && formValues.emailaddressshippingAddressForm !== shippingAddress.email ) ||
      ( formValues.phoneNumbershippingAddressForm && phNumber !== shippingAddress.phoneNumber ) ||
      ( formValues.postalCodeshippingAddressForm && formValues.postalCodeshippingAddressForm !== shippingAddress.postalCode ) ){
      return true;
    }
    else {
      return false;
    }
  }

  submitForms(){
    // Track form errors on submit for analytics
    let analyticErrors = [];

    if( has( this.props.shippingForm, 'syncErrors' ) ){
      analyticErrors.push( { 'shippingErrors':  omitBy( this.props.shippingForm.syncErrors, isNil ) } );
    }

    if( has( this.props.paymentForm, 'syncErrors' ) ){
      analyticErrors.push( { 'paymentErrors': omitBy( this.props.paymentForm.syncErrors, isNil ) } );
    }
    if( has( this.props, 'addEditShippingForm.syncErrors' ) ){
      analyticErrors.push( { 'addEditShippingErrors': omitBy( this.props.addEditShippingForm.syncErrors, isNil ) } );
    }
    if( has( this.props, 'PaymentCCSecurityCode.syncErrors' ) ){
      analyticErrors.push( { 'paymentErrors': omitBy( this.props.PaymentCCSecurityCode.syncErrors, isNil ) } );
    }

    if( analyticErrors.length > 0 ){
      fireAnalyticsEvent( 'trackErrorDisplayed', analyticErrors );
    }
    // End track errors
    if( this.props.holdDavPopUp ){
      this.props.updateDavPopup();
    }
    let isSubmit=false;
    if( !this.props.shippingValid ||
      !this.props.addEditShippingValid ||
      ( !isUndefined( find( this.props.readCartData.shippingInfo.messages, { 'messageType': 'Error' } ) ) ) ||
      ( !isUndefined( find( this.props.shippingError.messages, { 'messageType': 'Error' } ) ) ) ){
      this.props.validateShippingForm();
      this.props.submitShippingAddressForm();

      isSubmit=true;
      this.props.handleScrollView( 'checkoutShippingHeader' );
    }
    let estimatedTotal = this.props.readCartData.cartSummary.estimatedTotal;
    if( !isEmpty( this.props.paymentServiceResponse ) && !isEmpty( this.props.paymentServiceResponse.cartSummary ) ){
      estimatedTotal = this.props.paymentServiceResponse.cartSummary.estimatedTotal
    }
    this.props.submitPaymentForm( estimatedTotal );
    this.props.submitPaymentFormCvv( estimatedTotal );
    if( this.props.paymentType === 'creditCard' &&
      ( !this.props.paymentValid ||
       !this.props.paymentCardDetailsValid ) ){
      if( this.props.readCartData.cartSummary.estimatedTotal > 0 ){
        if( !isSubmit ){
          this.props.handleScrollView( 'checkoutPaymentHeader' );
        }
        isSubmit=true;
      }
    }

    if( ( this.props.isSignedIn && this.props.paymentType === 'paypal' && !has( this.props.paymentForm, 'syncErrors' ) ) &&
      ( !this.props.paymentValid ||
       !this.props.paymentCardDetailsValid ) ){
      if( this.props.readCartData.cartSummary.estimatedTotal > 0 ){
        if( !isSubmit ){
          this.props.handleScrollView( 'checkoutPaymentHeader' );
        }
        isSubmit=true;
      }
    }

    if( this.props.paymentType === 'paypal' && isUndefined( find( this.props.creditCardDetails, { 'paymentType': 'paypal' } ) ) ){
      isSubmit=true;
      this.props.handleScrollView( 'checkoutPaymentHeader' );
    }
    // if there is any modifications made in the address fields and if the user is directly clicking place order button,
    // then we are making the isSubmit = true, so that the shipping update call as a result of the blur will be made and placer order call will not be invoked.
    // In this case the user will have to click the place order one more time to actually place the order
    if( !has( this.props, 'readCartData.shippingInfo.shippingAddress' ) ||
      ( has( this.props, 'readCartData.shippingInfo.shippingAddress' ) &&
        !this.props.isSignedIn &&
        !isEmpty( this.props.shippingForm ) &&
        this.isAddressFormDirty( this.props.readCartData.shippingInfo.shippingAddress, this.props.shippingForm.values ) ) ){
      isSubmit = true;
    }

    if( !isSubmit ){
      let paymentSuccess = false;
      let shippingSuccess = ( has( this.props, 'readCartData.shippingInfo.shippingAddress' ) ) &&
                              this.props.readCartData.shippingInfo.shippingStatus === 'Complete' &&
                              isUndefined( find( this.props.readCartData.shippingInfo.messages, { 'messageType': 'Error' } ) ) &&
                              !( has( this.props, 'addEditShippingForm.values' ) );
      let paymentFormValues = {};
      let shippingFormValues = {};
      let shippingResponse = {};
      let paymentResponse = {};

      if( this.props.paymentType === 'creditCard' ){
        if( has( this.props.creditCardDetails, 'paymentInfo' ) && this.props.creditCardDetails.paymentInfo.paymentType === 'creditCard' ){
          paymentSuccess = has( this.props.creditCardDetails, 'paymentInfo' ) && has( this.props.creditCardDetails, 'messages' ) && isEmpty( this.props.creditCardDetails.messages ) && this.props.isSetCCPaymentFormSubmit && !has( this.props.paymentForm, 'values' );
        }
        else {
          paymentSuccess = has( this.props.creditCardDetails, 'paymentInfo' ) && has( this.props.creditCardDetails, 'messages' ) && isEmpty( this.props.creditCardDetails.messages ) && !has( this.props.paymentForm, 'values' );
        }
      }
      else if( has( this.props.creditCardDetails, 'paymentInfo' ) && this.props.creditCardDetails.paymentInfo.paymentType === 'paypal' ){
        paymentSuccess = has( this.props.creditCardDetails, 'paymentInfo' ) && has( this.props.creditCardDetails, 'messages' ) && isEmpty( this.props.creditCardDetails.messages ) && !has( this.props.paymentForm, 'values' );
      }

      if( has( this.props, 'readCartData.shippingInfo.shippingAddress' ) ){
        shippingResponse = this.props.readCartData.shippingInfo;
      }

      if( has( this.props.creditCardDetails, 'paymentInfo' ) ){
        paymentResponse = this.props.creditCardDetails;
      }

      if( !shippingSuccess && has( this.props, 'shippingForm.values' ) || ( has( this.props, 'addEditShippingForm.values' ) ) ){
        let values = has( this.props, 'addEditShippingForm.values' ) ? this.props.addEditShippingForm.values :this.props.shippingForm.values;
        let phNumber =  VMasker.toPattern( values.phoneNumbershippingAddressForm, '999-999-9999' );
        shippingFormValues = {
          firstName: values.firstNameshippingAddressForm,
          lastName: values.lastNameshippingAddressForm,
          address1:  values.address1shippingAddressForm,
          city: values.cityshippingAddressForm,
          phoneNumber: phNumber,
          email:values.emailaddressshippingAddressForm,
          postalCode : values.postalCodeshippingAddressForm,
          state: values.state,
          ...( values.address2shippingAddressForm && { address2: values.address2shippingAddressForm } )
        }
      }

      if( !paymentSuccess && this.props.paymentType === 'creditCard' ){
        if( has( this.props, 'paymentForm.values' ) ){
          let formValues = this.props.paymentForm.values;
          if( !has( this.props.paymentForm.values, 'firstNamepaymentAddressForm' ) ){
            paymentFormValues = {
              creditCardNumber: ( formValues.creditCardNumber ) ? formValues.creditCardNumber.replace( / /g, '' ).replace( /\*/g, '' ).trim() : formValues.creditCardNumber,
              creditCardType: this.props.creditCardPaymentType,
              nickName: !isUndefined( this.props.editCreditCardData.nickName )?this.props.editCreditCardData.nickName:'',
              sameAsShipping: true,
              paymentType: 'creditCard'
            };
          }
          else {
            let phNumber =  VMasker.toPattern( formValues.phoneNumberpaymentAddressForm, '999-999-9999' );
            paymentFormValues = {
              firstName: formValues.firstNamepaymentAddressForm.trim(),
              lastName: formValues.lastNamepaymentAddressForm.trim(),
              address2: ( formValues.address2paymentAddressForm ) ? formValues.address2paymentAddressForm.trim() : '',
              address1: formValues.address1paymentAddressForm.trim(),
              postalCode: formValues.postalCodepaymentAddressForm.trim(),
              city: formValues.citypaymentAddressForm.trim(),
              state: formValues.state,
              phoneNumber: phNumber.trim(),
              creditCardNumber: ( formValues.creditCardNumber ) ? formValues.creditCardNumber.replace( / /g, '' ).replace( /\*/g, '' ).trim() : formValues.creditCardNumber,
              creditCardType: this.props.creditCardPaymentType,
              nickName: !isUndefined( this.props.editCreditCardData.nickName )?this.props.editCreditCardData.nickName:'',
              sameAsShipping: false,
              paymentType: 'creditCard'
            };
          }
          if( this.props.creditCardPaymentType !== 'Ultamate Rewards Credit Card' ){
            paymentFormValues.expirationMonth = ( formValues.expirationDate )? formValues.expirationDate.substring( 0, 2 ).trim() : formValues.expirationDate;
            paymentFormValues.expirationYear = ( formValues.expirationDate ) ? formValues.expirationDate.substring( 3, 7 ).trim() : formValues.expirationDate;
            paymentFormValues.cardVerificationNumber = ( formValues.securityCode ) ? formValues.securityCode.trim() : formValues.securityCode;
          }
        }
        else if( has( this.props.creditCardDetails, 'paymentInfo' ) && this.props.creditCardDetails.paymentInfo.paymentType === 'creditCard' ){
          paymentFormValues = {
            ...this.props.editCCData
          }
          if( this.props.creditCardDetails.paymentInfo.paymentDetails.creditCardType !== 'Ultamate Rewards Credit Card' ){
            paymentFormValues.cardVerificationNumber = has( this.props, 'PaymentCCSecurityCode.values' ) ? this.props.PaymentCCSecurityCode.values.ccSecurityCode : this.props.tempPaymentCCVNumber
          }
        }
      }

      if( !paymentSuccess && this.props.paymentType === 'paypal' && has( this.props, 'paymentForm.values' ) ){
        let formValues = this.props.paymentForm.values;
        if( !has( this.props.paymentForm.values, 'firstNamepaymentAddressForm' ) ){
          paymentFormValues = {
            creditCardNumber: ( formValues.creditCardNumber ) ? formValues.creditCardNumber.replace( / /g, '' ).replace( /\*/g, '' ).trim() : formValues.creditCardNumber,
            creditCardType: this.props.creditCardPaymentType,
            nickName: !isUndefined( this.props.editCreditCardData.nickName )?this.props.editCreditCardData.nickName:'',
            sameAsShipping: true,
            paymentType: 'creditCard'
          };
        }
        else {
          let phNumber =  VMasker.toPattern( formValues.phoneNumberpaymentAddressForm, '999-999-9999' );
          paymentFormValues = {
            firstName: formValues.firstNamepaymentAddressForm.trim(),
            lastName: formValues.lastNamepaymentAddressForm.trim(),
            address2: ( formValues.address2paymentAddressForm ) ? formValues.address2paymentAddressForm.trim() : '',
            address1: formValues.address1paymentAddressForm.trim(),
            postalCode: formValues.postalCodepaymentAddressForm.trim(),
            city: formValues.citypaymentAddressForm.trim(),
            state: formValues.state,
            phoneNumber: phNumber.trim(),
            creditCardNumber: ( formValues.creditCardNumber ) ? formValues.creditCardNumber.replace( / /g, '' ).replace( /\*/g, '' ).trim() : formValues.creditCardNumber,
            creditCardType: this.props.creditCardPaymentType,
            nickName: !isUndefined( this.props.editCreditCardData.nickName )?this.props.editCreditCardData.nickName:'',
            sameAsShipping: false,
            paymentType: 'creditCard'
          };
        }
        if( this.props.creditCardPaymentType !== 'Ultamate Rewards Credit Card' ){
          paymentFormValues.expirationMonth = ( formValues.expirationDate )? formValues.expirationDate.substring( 0, 2 ).trim() : formValues.expirationDate;
          paymentFormValues.expirationYear = ( formValues.expirationDate ) ? formValues.expirationDate.substring( 3, 7 ).trim() : formValues.expirationDate;
          paymentFormValues.cardVerificationNumber = ( formValues.securityCode ) ? formValues.securityCode.trim() : formValues.securityCode;
        }
      }

      if( !paymentSuccess ){
        this.props.setTempPaymentCCVNumber( paymentFormValues.cardVerificationNumber );
      }

      let values = {
        shippingData: shippingFormValues,
        paymentData: paymentFormValues,
        paymentSuccess: paymentSuccess,
        amountDue: this.props.readCartData.cartSummary.estimatedTotal,
        shippingSuccess: shippingSuccess,
        shippingResponse: shippingResponse,
        paymentResponse: paymentResponse,
        guestUserEmailOptIn:this.props.signUpLetterFlag

      };
      this.props.updateSubmitOrder( values );
    }
  }
  /**
   * Renders the PlaceOrderComponent component
   */
  render(){


    const {
      submitOrderSpinner
    } = this.props;

    return (
      <div className='PlaceOrderComponent'>
        <Button
          showLoader={ submitOrderSpinner }
          className='CheckoutPage__Button--placeorder'
          btnOption='single'
          inputTag='button'
          btnSize='lg'
          clickEventHandler={
            e => {
              e.stopPropagation();
              this.submitForms();
            }
          }
        >
          <div className='CheckoutPage__Button--placeorder--img'>
            <SVG />
          </div>
          <div className='CheckoutPage__Button--placeorder--msg'>
            { formatMessage( messages.placeOrder ) }
          </div>
        </Button>
      </div>
    );
  }
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( PlaceOrderComponent ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );
