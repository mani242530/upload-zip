/*
 * PlaceOrderComponent Messages
 *
 * This contains all the text for the PlaceOrderComponent component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  placeOrder: {
    id: 'i18n.PlaceOrderComponent.placeOrder',
    defaultMessage: 'Place Order'
  },
  applyCouponMessage: {
    id: 'i18n.PlaceOrderComponent.placeOrder',
    defaultMessage: 'Please click on apply'
  }

} );
