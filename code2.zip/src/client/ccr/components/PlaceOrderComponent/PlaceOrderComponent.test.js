import React from 'react';
import ReactDOM from 'react-dom';
import PlaceOrderComponent, { connectFunction, mapDispatchToProps, mapStateToProps } from './PlaceOrderComponent';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './PlaceOrderComponent.messages';
import { IntlProvider } from 'react-intl';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';

describe( '<PlaceOrderComponent />', () => {
  let component;
  let props={
    shippingAddressList:{
      shippingStatus: 'Corrected',
      shippingAddress: {
        firstName: 'Jane',
        lastName: 'Doe',
        address1: '1000 Remington Boulevard',
        address2: 'Suite # 120',
        city: 'Bolingbrook',
        state: 'IL',
        postalCode: '60564',
        phoneNumber: '(510)-213-8347'
      }
    },
    readCartData:{
      shippingInfo:{
        shippingAddress:{}
      }
    },
    paymentForm:{
      paymentType: 'creditCard',
      paymentDetails: {
        expirationMonth: '09',
        expirationYear: '2021',
        creditCardNumber: '',
        creditCardType: 'Visa'
      },
      amount: 46.18,
      currencyCode: 'USD',
      contactInfo: {
        firstName: 'Pushpendra',
        lastName: 'Kabdaula',
        phoneNumber: '123-456-7890',
        email: 'pkabdaula@ulta.com',
        address1: '1000 remngton blvd',
        address2: 'Ste 200',
        city: 'Boolingbrook',
        state: 'IL',
        postalCode: '07105',
        country: 'US'
      }
    }

  };

  const setCouponErrorMessageMock = jest.fn();
  const handleScrollViewMock = jest.fn();
  let mapDispatchToPropsMock = ( dispatch ) =>{
    return {
      setCouponErrorMessage: setCouponErrorMessageMock,
      handleScrollView: handleScrollViewMock
    }
  }

  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <PlaceOrderComponent { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'PlaceOrderComponent' ).length ).toBe( 1 );
  } );

  it( 'Button component renders without crashing', () => {
    expect( component.find( 'Button' ).length ).toBe( 1 );
  } );

  it( 'Button component renders without crashing', () => {
    expect( component.find( '.CheckoutPage__Button--placeorder--msg' ).text() ).toBe( messages.placeOrder.defaultMessage );
  } );

  it( 'handles Button click event', () => {
    let m1 = jest.fn()
    let m2 = jest.fn()
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponent
          { ...props }
          updateSubmitOrder={ m1 }
          handleScrollView={ m2 }
        />
      </Provider>
    );
    let node = component1.find( 'PlaceOrderComponent' ).instance();
    node.submitForms = jest.fn();
    node.submitPaymentForm = jest.fn();

    // show errors when credit payment form validation is called
    component1.find( 'Button' ).simulate( 'click' );
    expect( node.submitPaymentForm ).not.toBeCalled();

    component1.find( 'Button' ).simulate( 'click' );
    expect( node.submitForms ).toBeCalled();
    expect( node.props.handleScrollView ).not.toBeCalled();
    expect( node.props.updateSubmitOrder ).not.toBeCalled();
  } );

  it( 'handles Button click event With syncErrors and DAV Popup', () => {
    const store = configureStore( {}, CONFIG );
    let props1 = {
      submitForms: jest.fn(),
      handleScrollView: jest.fn(),
      validateShippingForm: jest.fn(),
      submitShippingAddressForm: jest.fn(),
      submitPaymentForm: jest.fn(),
      submitPaymentFormCvv: jest.fn(),
      setTempPaymentCCVNumber: jest.fn(),
      updateSubmitOrder: jest.fn(),
      updateDavPopup: jest.fn(),
      holdDavPopUp: true,
      paymentType: 'creditCard',
      readCartData:{
        cartSummary: {
          estimatedTotal: 12.04
        },
        shippingInfo:{
          shippingAddress:{},
          messages:[
            { 'messageType': 'Error' }
          ]
        }
      },
      shippingError: {
        messages:[
          { 'messageType': 'Error' }
        ]
      }
    };

    store.getState().form = {
      Shipping: {
        syncErrors: {
          firstNameshippingAddressForm: 'Required'
        },
        values:[]
      },
      paymentForm: {
        syncErrors: {
          creditCardNumber: 'Required',
          expirationDate: 'Required'
        }
      },
      shippingAddressList: {
        syncErrors: {
          firstNameshippingAddressForm: 'Required'
        }
      },
      PaymentCCSecurityCode: {
        syncErrors: {
          ccSecurityCode: 'Required'
        }
      }
    };

    let PlaceOrderComponentMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props1 }/>
      </Provider>
    );
    component1.find( 'Button' ).simulate( 'click' );
    expect( component1.find( 'PlaceOrderComponent' ).at( 0 ).props().updateDavPopup ).toBeCalled();
    expect( component1.find( 'PlaceOrderComponent' ).at( 0 ).props().validateShippingForm ).toBeCalled();
    expect( component1.find( 'PlaceOrderComponent' ).at( 0 ).props().submitShippingAddressForm ).toBeCalled();
    expect( component1.find( 'PlaceOrderComponent' ).at( 0 ).props().handleScrollView ).toBeCalled();
    expect( component1.find( 'PlaceOrderComponent' ).at( 0 ).props().submitPaymentForm ).toBeCalled();
    expect( component1.find( 'PlaceOrderComponent' ).at( 0 ).props().submitPaymentFormCvv ).toBeCalled();
  } );

  it( 'should place order on Button click event With Paypal and coupon Error', () => {
    const store = configureStore( {}, CONFIG );
    let props2 = {
      submitForms: jest.fn(),
      handleScrollView: jest.fn(),
      validateShippingForm: jest.fn(),
      submitShippingAddressForm: jest.fn(),
      submitPaymentForm: jest.fn(),
      submitPaymentFormCvv: jest.fn(),
      setTempPaymentCCVNumber: jest.fn(),
      updateSubmitOrder: jest.fn(),
      setCouponErrorMessage: jest.fn(),
      holdDavPopUp: false,
      paymentType: 'paypal',
      readCartData:{
        cartSummary: {
          estimatedTotal: 12.04
        },
        shippingInfo:{
          shippingStatus: 'Corrected',
          shippingAddress:{},
          messages:[]
        }
      },
      shippingError: {
        messages:[]
      },
      cartRightPanelCollapse:{ coupons:true },
      isCouponButtonClicked: false,
      creditCardDetails: {
        paymentInfo: {
          paymentType: 'paypal',
          paymentDetails: {
            emailAddress: 'ecomqaoffshore@ulta.com'
          },
          amount: 46.18
        },
        messages: []
      }
    };
    store.getState().form = {
      paymentForm: {
        values: {
          creditCardNumber: '4111111111111111',
          expirationDate: '12/2020',
          securityCode: '123',
          firstNamepaymentAddressForm: 'test',
          lastNamepaymentAddressForm: 'test',
          address1paymentAddressForm: '1000 remngton blvd',
          address2paymentAddressForm: 'Ste 200',
          citypaymentAddressForm: 'Boolingbrook',
          state: 'IL',
          postalCodepaymentAddressForm: '07105',
          phoneNumberpaymentAddressForm: '(510)-213-8347'
        }
      },
      Shipping: {
        syncErrors: {
          firstNameshippingAddressForm: 'Required'
        },
        values:[]
      }
    };
    store.getState().form = {
      Coupon: {
        values: {
          couponName: 'ABC'
        }
      },
      Shipping: {
        syncErrors: {
          firstNameshippingAddressForm: 'Required'
        },
        values:{
          phoneNumbershippingAddressForm: '(510)-213-8347'
        }
      }
    };

    let PlaceOrderComponentMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let component2 = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props2 } />
      </Provider>
    );
    component2.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty = jest.fn( ()=>false );
    component2.find( 'Button' ).simulate( 'click' );
    expect( component2.find( 'PlaceOrderComponent' ).instance().props.updateSubmitOrder ).toBeCalled();
    expect( component2.find( 'PlaceOrderComponent' ).instance().props.updateSubmitOrder ).toBeCalledWith( {
      shippingData: {
        'address1': undefined,
        'city': undefined,
        'email':undefined,
        'firstName': undefined,
        'lastName': undefined,
        'phoneNumber': '510-213-8347',
        'postalCode': undefined,
        'state': undefined
      },
      paymentData: {},
      paymentSuccess: true,
      amountDue: 12.04,
      shippingSuccess: false,
      shippingResponse: {
        'messages': [],
        'shippingAddress': {},
        'shippingStatus': 'Corrected'
      },
      paymentResponse: {
        'messages': [],
        'paymentInfo': {
          'amount': 46.18,
          'paymentDetails': { 'emailAddress': 'ecomqaoffshore@ulta.com' },
          'paymentType': 'paypal'
        }
      },
      guestUserEmailOptIn:undefined
    } );
  } );

  it( 'should place order on Button click if shippingStatus is complete', () => {
    const store = configureStore( {}, CONFIG );
    let props2 = {
      submitForms: jest.fn(),
      handleScrollView: jest.fn(),
      validateShippingForm: jest.fn(),
      submitShippingAddressForm: jest.fn(),
      submitPaymentForm: jest.fn(),
      submitPaymentFormCvv: jest.fn(),
      setTempPaymentCCVNumber: jest.fn(),
      updateSubmitOrder: jest.fn(),
      setCouponErrorMessage: jest.fn(),
      holdDavPopUp: false,
      paymentType: 'paypal',
      readCartData:{
        cartSummary: {
          estimatedTotal: 12.04
        },
        shippingInfo:{
          shippingStatus: 'Complete',
          shippingAddress:{},
          messages:[]
        }
      },
      shippingError: {
        messages:[]
      },
      cartRightPanelCollapse:{ coupons:true },
      isCouponButtonClicked: false,
      creditCardDetails: {
        paymentInfo: {
          paymentType: 'paypal',
          paymentDetails: {
            emailAddress: 'ecomqaoffshore@ulta.com'
          },
          amount: 46.18
        },
        messages: []
      }
    };
    store.getState().form = {
      paymentForm: {
        values: {
          creditCardNumber: '4111111111111111',
          expirationDate: '12/2020',
          securityCode: '123',
          firstNamepaymentAddressForm: 'test',
          lastNamepaymentAddressForm: 'test',
          address1paymentAddressForm: '1000 remngton blvd',
          address2paymentAddressForm: 'Ste 200',
          citypaymentAddressForm: 'Boolingbrook',
          state: 'IL',
          postalCodepaymentAddressForm: '07105',
          phoneNumberpaymentAddressForm: '(510)-213-8347'
        }
      },
      Shipping: {
        syncErrors: {
          firstNameshippingAddressForm: 'Required'
        },
        values:[]
      }
    };
    store.getState().form = {
      Coupon: {
        values: {
          couponName: 'ABC'
        }
      },
      Shipping: {
        syncErrors: {
          firstNameshippingAddressForm: 'Required'
        },
        values:{
          phoneNumbershippingAddressForm: '(510)-213-8347'
        }
      }
    };

    let PlaceOrderComponentMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let component2 = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props2 } />
      </Provider>
    );
    component2.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty = jest.fn( ()=>false );
    component2.find( 'Button' ).simulate( 'click' );
    expect( component2.find( 'PlaceOrderComponent' ).instance().props.updateSubmitOrder ).toBeCalledWith( {
      shippingData: {},
      paymentData: {},
      paymentSuccess: true,
      amountDue: 12.04,
      shippingSuccess: true,
      shippingResponse: {
        'messages': [],
        'shippingAddress': {},
        'shippingStatus': 'Complete'
      },
      paymentResponse: {
        'messages': [],
        'paymentInfo': {
          'amount': 46.18,
          'paymentDetails': { 'emailAddress': 'ecomqaoffshore@ulta.com' },
          'paymentType': 'paypal'
        }
      },
      guestUserEmailOptIn:undefined
    } );
  } );

  it( 'handles Button click event With correct form data', () => {
    const store = configureStore( {}, CONFIG );
    let props3 = {
      submitForms: jest.fn(),
      handleScrollView: jest.fn(),
      validateShippingForm: jest.fn(),
      submitShippingAddressForm: jest.fn(),
      submitPaymentForm: jest.fn(),
      submitPaymentFormCvv: jest.fn(),
      setTempPaymentCCVNumber: jest.fn(),
      updateSubmitOrder: jest.fn(),
      setCouponErrorMessage: jest.fn(),
      holdDavPopUp: false,
      paymentType: 'creditCard',
      readCartData:{
        cartSummary: {
          estimatedTotal: 12.04
        },
        shippingInfo:{
          shippingStatus: 'Corrected',
          messages:[],
          shippingAddress : {}
        }
      },
      shippingError: {
        messages:[]
      },
      editCreditCardData: {},
      creditCardDetails: {
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {}
        },
        messages: []
      },
      isSetCCPaymentFormSubmit: true,
      creditCardPaymentType: 'VISA'
    };

    store.getState().form = {
      Shipping: {
        values: {
          firstNameshippingAddressForm: 'test',
          lastNameshippingAddressForm: 'test',
          address1shippingAddressForm: '1000 remngton blvd',
          address2shippingAddressForm: 'Ste 200',
          cityshippingAddressForm: 'Boolingbrook',
          emailaddressshippingAddressForm: 'test@test.com',
          state: 'IL',
          postalCodeshippingAddressForm: '07105',
          phoneNumbershippingAddressForm: '(510)-213-8347'
        }
      },
      shippingAddressList: {},
      paymentForm: {
        values: {
          creditCardNumber: '4111111111111111',
          expirationDate: '12/2020',
          securityCode: '123'
        }
      }
    };

    let PlaceOrderComponentMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let component3 = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props3 } />
      </Provider>
    );
    component3.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty = jest.fn( ()=>false );
    component3.find( 'Button' ).simulate( 'click' );
    expect( component3.find( 'PlaceOrderComponent' ).at( 0 ).props().updateSubmitOrder ).toBeCalled();

    let props4 = {
      ...props3,
      readCartData:{
        cartSummary: {
          estimatedTotal: 12.04
        },
        shippingInfo:{
          shippingStatus: 'Corrected',
          shippingAddress: {},
          messages:[]
        }
      },
      paymentType:'paypal',
      creditCardDetails: {
        paymentInfo: {
          paymentType: 'paypal',
          paymentDetails: {
            emailAddress: 'ecomqaoffshore@ulta.com'
          },
          amount: 46.18
        },
        messages: []
      }
    };
    store.getState().form = {
      paymentForm: {
        values: {
          creditCardNumber: '4111111111111111',
          expirationDate: '12/2020',
          securityCode: '123',
          firstNamepaymentAddressForm: 'test',
          lastNamepaymentAddressForm: 'test',
          address1paymentAddressForm: '1000 remngton blvd',
          address2paymentAddressForm: 'Ste 200',
          citypaymentAddressForm: 'Boolingbrook',
          state: 'IL',
          postalCodepaymentAddressForm: '07105',
          phoneNumberpaymentAddressForm: '(510)-213-8347'
        }
      },
      Shipping:{}
    };
    let component4 = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props4 } />
      </Provider>
    );
    component4.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty = jest.fn( ()=>false );
    component4.find( 'Button' ).simulate( 'click' );
    expect( component4.find( 'PlaceOrderComponent' ).at( 0 ).props().updateSubmitOrder ).toBeCalled();

    let props5 = {
      ...props3,
      readCartData:{
        cartSummary: {
          estimatedTotal: 12.04
        },
        shippingInfo:{
          shippingStatus: 'Corrected',
          shippingAddress: {},
          messages:[]
        }
      },
      paymentType:'creditCard',
      creditCardDetails: {}
    };

    store.getState().form = {
      paymentForm: {
        values: {
          creditCardNumber: '4111111111111111',
          expirationDate: '12/2020',
          securityCode: '123',
          firstNamepaymentAddressForm: 'test',
          lastNamepaymentAddressForm: 'test',
          address1paymentAddressForm: '1000 remngton blvd',
          address2paymentAddressForm: 'Ste 200',
          citypaymentAddressForm: 'Boolingbrook',
          state: 'IL',
          postalCodepaymentAddressForm: '07105',
          phoneNumberpaymentAddressForm: '(510)-213-8347'
        }
      },
      Shipping:{}
    };

    let component5 = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props5 } />
      </Provider>
    );
    component5.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty = jest.fn( ()=>false );
    component5.find( 'Button' ).simulate( 'click' );
    expect( component5.find( 'PlaceOrderComponent' ).at( 0 ).props().updateSubmitOrder ).toBeCalled();

    let props6 = {
      ...props3,
      readCartData:{
        cartSummary: {
          estimatedTotal: 12.04
        },
        shippingInfo:{
          shippingStatus: 'Corrected',
          shippingAddress: {},
          messages:[]
        }
      },
      paymentType:'creditCard',
      isSetCCPaymentFormSubmit: false,
      editCreditCardData: {
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {}
        }
      }
    };

    store.getState().form = {
      paymentForm: {},
      Shipping:{}
    };

    let component6 = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props6 } />
      </Provider>
    );
    component6.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty = jest.fn( ()=>false );
    component6.find( 'Button' ).simulate( 'click' );
    expect( component6.find( 'PlaceOrderComponent' ).at( 0 ).props().updateSubmitOrder ).toBeCalled();
  } );

  it( 'Should invoke submitPaymentForm and submitPaymentFormCvv method on submit, with estimated total from cartSummary of readCart data', () => {

    const props1 = {
      submitForms: jest.fn(),
      handleScrollView: jest.fn(),
      validateShippingForm: jest.fn(),
      submitShippingAddressForm: jest.fn(),
      submitPaymentForm: jest.fn(),
      submitPaymentFormCvv: jest.fn(),
      setTempPaymentCCVNumber: jest.fn(),
      updateSubmitOrder: jest.fn(),
      updateDavPopup: jest.fn(),
      holdDavPopUp: true,
      paymentType: 'creditCard',
      readCartData:{
        cartSummary: {
          estimatedTotal: 12.04
        },
        shippingInfo:{
          shippingAddress:{}
        }
      },
      shippingError: { }
    };

    const PlaceOrderComponentMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    store.getState().form = {
      paymentForm: {},
      Shipping:{}
    };

    const component2 = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props1 }/>
      </Provider>
    );
    component2.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty = jest.fn( ()=>false );
    component2.find( 'Button' ).simulate( 'click' );
    expect( component2.find( 'PlaceOrderComponent' ).at( 0 ).props().submitPaymentForm ).toBeCalledWith( 12.04 );
    expect( component2.find( 'PlaceOrderComponent' ).at( 0 ).props().submitPaymentFormCvv ).toBeCalledWith( 12.04 );
  } );

  it( 'Should invoke submitPaymentForm and submitPaymentFormCvv method on submit, with estimated total from cartSummary of paymentServiceResponse', () => {

    const props1 = {
      submitForms: jest.fn(),
      handleScrollView: jest.fn(),
      validateShippingForm: jest.fn(),
      submitShippingAddressForm: jest.fn(),
      submitPaymentForm: jest.fn(),
      submitPaymentFormCvv: jest.fn(),
      setTempPaymentCCVNumber: jest.fn(),
      updateSubmitOrder: jest.fn(),
      updateDavPopup: jest.fn(),
      holdDavPopUp: true,
      paymentType: 'creditCard',
      readCartData:{
        cartSummary: {
          estimatedTotal: 12.04
        },
        shippingInfo:{
          shippingAddress:{}
        }
      },
      paymentServiceResponse:{
        cartSummary: {
          estimatedTotal: 10
        }
      },
      shippingError: { }
    };

    const PlaceOrderComponentMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    const component2 = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props1 }/>
      </Provider>
    );
    component2.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty = jest.fn( ()=>false );
    component2.find( 'Button' ).simulate( 'click' );
    expect( component2.find( 'PlaceOrderComponent' ).at( 0 ).props().submitPaymentForm ).toBeCalledWith( 10 );
    expect( component2.find( 'PlaceOrderComponent' ).at( 0 ).props().submitPaymentFormCvv ).toBeCalledWith( 10 );
  } );

  describe( 'Anchor to errors before submit', ( ) => {
    let props = {
      handleScrollView:jest.fn(),
      shippingAddressList:{},
      readCartData:{
        shippingInfo:{
          shippingAddress:{}
        }
      },
      paymentForm:{},
      paymentType: 'creditCard',
      isErrorBeforeSubmitOrder: 'payment',
      anchorAfterSubmitServiceCall: undefined
    };

    let props1 = {
      handleScrollView:jest.fn(),
      shippingAddressList:{},
      readCartData:{
        shippingInfo:{
          shippingAddress:{}
        }
      },
      paymentForm:{},
      paymentType: 'creditCard',
      isErrorBeforeSubmitOrder: undefined,
      anchorAfterSubmitServiceCall: undefined
    };

    var node = document.createElement( 'div' );
    const store = configureStore( {}, CONFIG );

    let PlaceOrderComponentMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    component = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props }/>
      </Provider>
    );

    it( 'check componentDidUpdate function with isErrorBeforeSubmitOrder as payment', () => {
      component.find( 'PlaceOrderComponent' ).instance().componentDidUpdate( props1 );
      expect( component.find( 'PlaceOrderComponent' ).at( 0 ).props().handleScrollView ).toBeCalled();
    } );

    it( 'check componentDidUpdate function with isErrorBeforeSubmitOrder as shipping', () => {
      let props = {
        handleScrollView:jest.fn(),
        shippingAddressList:{},
        readCartData:{
          shippingInfo:{
            shippingAddress:{}
          }
        },
        paymentForm:{},
        paymentType: 'creditCard',
        isErrorBeforeSubmitOrder: 'shipping',
        anchorAfterSubmitServiceCall: undefined
      };
      let component = mountWithIntl(
        <Provider store={ store }>
          <PlaceOrderComponentMock { ...props }/>
        </Provider>
      );
      component.find( 'PlaceOrderComponent' ).instance().componentDidUpdate( props1 );
      expect( component.find( 'PlaceOrderComponent' ).at( 0 ).props().handleScrollView ).toBeCalled();
    } );

    it( 'check componentDidUpdate function with isErrorBeforeSubmitOrder as header', () => {
      let props = {
        handleScrollView:jest.fn(),
        shippingAddressList:{},
        readCartData:{
          shippingInfo:{
            shippingAddress:{}
          }
        },
        paymentForm:{},
        paymentType: 'creditCard',
        isErrorBeforeSubmitOrder: 'header',
        anchorAfterSubmitServiceCall: undefined
      };
      let component = mountWithIntl(
        <Provider store={ store }>
          <PlaceOrderComponentMock { ...props }/>
        </Provider>
      );
      component.find( 'PlaceOrderComponent' ).instance().componentDidUpdate( props1 );
      expect( component.find( 'PlaceOrderComponent' ).at( 0 ).props().handleScrollView ).toBeCalled();
    } );

  } );

  describe( 'Anchor to errors after submit', ( ) => {
    let props = {
      handleScrollView:jest.fn(),
      shippingAddressList:{},
      readCartData:{
        shippingInfo:{
          shippingAddress:{}
        }
      },
      paymentForm:{},
      paymentType: 'creditCard',
      isErrorBeforeSubmitOrder: undefined,
      anchorAfterSubmitServiceCall:  'payment'
    };

    let props1 = {
      handleScrollView:jest.fn(),
      shippingAddressList:{},
      readCartData:{
        shippingInfo:{
          shippingAddress:{}
        }
      },
      paymentForm:{},
      paymentType: 'creditCard',
      isErrorBeforeSubmitOrder: undefined,
      anchorAfterSubmitServiceCall: undefined
    };

    var node = document.createElement( 'div' );
    const store = configureStore( {}, CONFIG );

    let PlaceOrderComponentMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    component = mountWithIntl(
      <Provider store={ store }>
        <PlaceOrderComponentMock { ...props }/>
      </Provider>
    );

    it( 'check componentDidUpdate function with anchorAfterSubmitServiceCall as payment', () => {
      component.find( 'PlaceOrderComponent' ).instance().componentDidUpdate( props1 );
      expect( component.find( 'PlaceOrderComponent' ).at( 0 ).props().handleScrollView ).toBeCalled();
    } );

    it( 'check componentDidUpdate function with anchorAfterSubmitServiceCall as shipping', () => {
      let props = {
        handleScrollView:jest.fn(),
        shippingAddressList:{},
        readCartData:{
          shippingInfo:{
            shippingAddress:{}
          }
        },
        paymentForm:{},
        paymentType: 'creditCard',
        isErrorBeforeSubmitOrder: undefined,
        anchorAfterSubmitServiceCall:  'shipping'
      };
      let component = mountWithIntl(
        <Provider store={ store }>
          <PlaceOrderComponentMock { ...props }/>
        </Provider>
      );
      component.find( 'PlaceOrderComponent' ).instance().componentDidUpdate( props1 );
      expect( component.find( 'PlaceOrderComponent' ).at( 0 ).props().handleScrollView ).toBeCalled();
    } );

    it( 'check componentDidUpdate function with anchorAfterSubmitServiceCall as header', () => {
      let props = {
        handleScrollView:jest.fn(),
        shippingAddressList:{},
        readCartData:{
          shippingInfo:{
            shippingAddress:{}
          }
        },
        paymentForm:{},
        paymentType: 'creditCard',
        isErrorBeforeSubmitOrder: undefined,
        anchorAfterSubmitServiceCall:  'header'
      };
      let component = mountWithIntl(
        <Provider store={ store }>
          <PlaceOrderComponentMock { ...props }/>
        </Provider>
      );
      component.find( 'PlaceOrderComponent' ).instance().componentDidUpdate( props1 );
      expect( component.find( 'PlaceOrderComponent' ).at( 0 ).props().handleScrollView ).toBeCalled();
    } );

    it( 'Should invoke isAddressFormDirty and return true and the form should not be submitted', () => {
      const props = {
        submitForms: jest.fn(),
        handleScrollView: jest.fn(),
        validateShippingForm: jest.fn(),
        submitShippingAddressForm: jest.fn(),
        submitPaymentForm: jest.fn(),
        submitPaymentFormCvv: jest.fn(),
        setTempPaymentCCVNumber: jest.fn(),
        updateSubmitOrder: jest.fn(),
        updateDavPopup: jest.fn(),
        holdDavPopUp: true,
        paymentType: 'creditCard',
        readCartData:{
          cartSummary: {
            estimatedTotal: 12.04
          },
          shippingInfo:{
            shippingAddress:{},
            messages:[]
          }
        },
        shippingError: {
          messages:[]
        }
      };
      const PlaceOrderComponentMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
      store.getState().form = {
        paymentForm: {},
        Shipping:{
          'firstNameShippingAddressForm':'John'
        }
      };

      const component = mountWithIntl(
        <Provider store={ store }>
          <PlaceOrderComponentMock { ...props }/>
        </Provider>
      );
      component.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty = jest.fn( ()=>true );
      component.find( 'Button' ).simulate( 'click' );
      expect( component.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty ).toBeCalled();
      expect( component.find( 'PlaceOrderComponent' ).at( 0 ).props().updateSubmitOrder ).not.toBeCalled();
    } );

    it( 'Should not invoke isAddressFormDirty  if the form doesnt exist on the page', () => {
      const props = {
        submitForms: jest.fn(),
        handleScrollView: jest.fn(),
        validateShippingForm: jest.fn(),
        submitShippingAddressForm: jest.fn(),
        submitPaymentForm: jest.fn(),
        submitPaymentFormCvv: jest.fn(),
        setTempPaymentCCVNumber: jest.fn(),
        updateSubmitOrder: jest.fn(),
        updateDavPopup: jest.fn(),
        holdDavPopUp: true,
        paymentType: 'creditCard',
        readCartData:{
          cartSummary: {
            estimatedTotal: 12.04
          },
          shippingInfo:{
            shippingAddress:{},
            messages:[]
          }
        },
        shippingError: {
          messages:[]
        }
      };
      const PlaceOrderComponentMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
      store.getState().form = {
        paymentForm: {}
      };

      const component = mountWithIntl(
        <Provider store={ store }>
          <PlaceOrderComponentMock { ...props }/>
        </Provider>
      );
      component.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty = jest.fn( ()=>true );
      component.find( 'Button' ).simulate( 'click' );
      expect( component.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty ).not.toBeCalled();
    } );

    it( 'isAddressFormDirty should return false when the data is not matching', () => {

      const formValues = {
        firstNameshippingAddressForm: 'Jane',
        lastNameshippingAddressForm: 'Doe',
        address1shippingAddressForm: '1000 Remington Boulevard',
        cityshippingAddressForm: 'Bolingbrook',
        emailaddressshippingAddressForm: 'test@test.com',
        state: 'IL',
        postalCodeshippingAddressForm: '60564',
        phoneNumbershippingAddressForm: '(510)-213-8347'
      }

      const shippingAddress = {
        firstName: 'Jane',
        lastName: 'Doe',
        address1: '1000 Remington Boulevard',
        address2: null,
        city: 'Bolingbrook',
        email:'test@test.com',
        state: 'IL',
        postalCode: '60564',
        phoneNumber: '510-213-8347'
      }
      expect( component.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty( shippingAddress, formValues ) ).toBe( false );
    } );

    it( 'isAddressFormDirty should return true when the data is not matching', () => {
      const formValues = {
        firstNameshippingAddressForm: 'Jane',
        lastNameshippingAddressForm: 'Doe',
        address1shippingAddressForm: '1000 Remington Boulevard',
        cityshippingAddressForm: 'Bolingbrook',
        emailaddressshippingAddressForm: 'test@test.com',
        state: 'IL',
        postalCodeshippingAddressForm: '60564',
        phoneNumbershippingAddressForm: '(510)-213-8346'
      }

      // the last digit of the phone number is different
      const shippingAddress = {
        firstName: 'Jane',
        lastName: 'Doe',
        address1: '1000 Remington Boulevard',
        address2: null,
        city: 'Bolingbrook',
        email:'test@test.com',
        state: 'IL',
        postalCode: '60564',
        phoneNumber: '510-213-8347'
      }
      expect( component.find( 'PlaceOrderComponent' ).instance().isAddressFormDirty( shippingAddress, formValues ) ).toBe( true );
    } );


  } );
} );
