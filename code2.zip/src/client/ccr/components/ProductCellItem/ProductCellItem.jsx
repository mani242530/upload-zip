import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './ProductCellItem.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './ProductCellItem.messages';
import ProductDescriptionCard from 'ccr/components/ProductDescriptionCard/ProductDescriptionCard';
import ChevronDownSVG from 'shared/components/Icons/chevrondown';
import Anchor from 'shared/components/Anchor/Anchor';
import classNames from 'classnames';
import Spinner from 'shared/components/Icons/spinner';
import Exclamationcircle from 'shared/components/Icons/exclamationcircle';
import Divider from 'shared/components/Divider/Divider';
import has from 'lodash/has';
import find from 'lodash/find';
import isNull from 'lodash/isNull';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';

const propTypes = {
  productItem: PropTypes.object.isRequired,
  index: PropTypes.number,
  remove: PropTypes.object,
  removeFromCart: PropTypes.func,
  updateCart: PropTypes.func,
  showShippingRestrictionMsg: PropTypes.bool,
  errorRemoving: PropTypes.string,
  removingItem: PropTypes.string,
  commerceItemid: PropTypes.string,
  displayProductInfo: PropTypes.bool,
  removeItem: PropTypes.bool
}
const defaultProps = {
  displayProductInfo: true
}

class ProductCellItem extends Component{

  constructor( props ){
    super( props );
    this.removeItemFunction = this.removeItemFunction.bind( this );
    this.changeQuantity = this.changeQuantity.bind( this );
  }
  quantityDropdown = undefined;

  removeItemFunction( e, item ){
    e.preventDefault();
    let _item = item;
    _item.history = this.props.history;
    this.props.removeFromCart( _item );
  }

  changeQuantity( newValue ){
    this.props.updateCart( this.props.productItem.commerceItemid, newValue, this.props.history );
  }

  componentDidMount( ){
    this.setProductQuantity( this.props.productItem.quantity.value );
  }

  componentDidUpdate( prevProps ){
    if( this.props.productItem.quantity.value !== prevProps.productItem.quantity.value &&
        this.props.productItem.quantity.value !== parseInt( this.quantityDropdown.value, 10 ) ){
      this.setProductQuantity( this.props.productItem.quantity.value );
    }
  }

  setProductQuantity( quantity ){
    this.quantityDropdown.value = quantity;
  }

  render(){
    const productItem = this.props.productItem;


    return (
      <div className='ProductCellItem'>
        { ( () =>{
          try {
            if( this.props.showShippingRestrictionMsg ){
              if( productItem.shippingRestriction && productItem.shippingRestriction !== '' ){
                return (
                  <ResponseMessages
                    message={ productItem.shippingRestriction }
                  />
                )
              }
            }
          }
          catch ( e ){

          }
        } )() }
        { ( () =>{
          try {
            if( this.props.showShippingRestrictionMsg ){
              if( productItem.shippingRestriction !== '' && productItem.excludedFromCoupon && productItem.shipRestrictionMsg ){
                return (
                  <div>
                    <Divider dividerType={ 'gray' }/>
                  </div>
                )
              }
            }
          }
          catch ( e ){

          }
        } )() }
        { ( () =>{
          try {
            if( productItem.excludedFromCoupon ){
              return (
                <ResponseMessages
                  message={ formatMessage( messages.excludedItem ) }
                />
              )
            }
          }
          catch ( e ){

          }
        } )() }

        { ( () =>{
          if( ( this.props.errorRemoving || this.props.errorRemoving !== '' ) && ( this.props.removingItem === productItem.commerceItemid ) ){
            return (
              <div className='ProductCellItem__removal__error'>
                <Exclamationcircle/>
                <span className='ProductCellItem__removal__error--text'>{ this.props.errorRemoving }</span>
              </div>
            )
          }
        } )() }
        <div
          className={
            classNames( 'ProductCellItem__product', {
              'removedItem': ( this.props.errorRemoving === '' && productItem.commerceItemid === this.props.removingItem )
            } )
          }
          id={ `ProductCellItem${this.props.index}` }
        >
          <div className='ProductCellItem__content'>
            <div
              className='ProductCellItem__content ProductCellItem__content--card'
            >
              <ProductDescriptionCard
                imageURL={ productItem.imageURL }
                brandName={ productItem.brandName }
                displayName={ productItem.skuDisplayName }
                PDPUrl={ productItem.productURL }
                variant={ productItem.variantInfo }
                displayProductInfo={ this.props.displayProductInfo }
                quantity={ productItem.quantity.value }
              />
            </div>
            <div
              className='ProductCellItem__content ProductCellItem__content--variants'
            >
              <div
                className='ProductCellItem__content ProductCellItem__content--dropdown'
              >

                { /* TODO comment from here when switching to react-select implementation  */ }
                <select
                  className='ProductCellItem__dropdown'
                  onChange={ ( e ) => this.changeQuantity( ( e.target ).value, productItem.commerceItemid ) }
                  aria-label={ formatMessage( messages.quantityariaLabel ) }
                  ref={ ( select ) => {
                    this.quantityDropdown=select;
                  } }
                >
                  {
                    [...Array( productItem.maxQty )].map( ( x, i ) =>{
                      return (
                        <option key={ i } value={ i + 1 }>
                          { i + 1 }
                        </option>
                      )
                    } )
                  }
                </select>
                { /* TILL here  */ }
                { ( () =>{
                  if( !isNull( productItem.quantity.messages ) ){
                    return (
                      <div className='ProductCellItem__dropdown--text'>
                        { ( () => {
                          return (
                            productItem.quantity.messages.items.map( ( msgItem, index ) => {
                              {
                                return (
                                  <div className='ProductCellItem__dropdown--errorMsg' role='alert' key={ index }>
                                    { msgItem.message }
                                  </div>

                                )
                              }
                            } )
                          )
                        } )() }
                      </div>
                    )
                  }
                } )() }
                <div className='removeButton'>
                  <Anchor clickHandler={ ( e ) => this.removeItemFunction( e, { 'commerceItemid':productItem.commerceItemid, 'catalogRefId': productItem.catalogRefId } ) } >
                    { formatMessage( messages.remove ) }
                  </Anchor>
                </div>
                <div className='ProductCellItem__Chevron'>
                  <ChevronDownSVG/>
                </div>
              </div>
              <div className='ProductCellItem__content ProductCellItem__content--price'>
                <div className='ProductCellItem__price'>
                  <span
                    className={
                      classNames(
                        'ProductCellItem__price ProductCellItem__price--regular', {
                          'ProductCellItem_price__noSale': productItem.priceInfo.salePrice === undefined || productItem.priceInfo.salePrice === null
                        }
                      )
                    }
                  >
                    <label className='sr-only'>
                      { productItem.priceInfo.salePrice? formatMessage( messages.originalPriceAriaLabel ) : formatMessage( messages.priceAriaLabel ) }
                    </label>
                    { productItem.priceInfo.regularPrice }
                  </span>
                  <span className='ProductCellItem__price ProductCellItem__price--sale'>
                    { ( () =>{
                      if( productItem.priceInfo.salePrice ){
                        return (
                          <label className='sr-only'>
                            { formatMessage( messages.salePriceAriaLabel ) }
                          </label>
                        )
                      }
                    } )() }
                    { productItem.priceInfo.salePrice }
                  </span>
                </div>
                <div className='ProductCellItem__unitmessage'>
                  { productItem.priceInfo.unitPriceMessage }
                </div>
                <div className='ProductCellItem__messages'>
                  { ( () =>{
                    if( productItem.adbugMessageMap && productItem.adbugMessageMap.adbugMessage ){
                      return (
                        <div className='ProductCellItem__footer--adBugMsg'>
                          <Anchor url={ productItem.adbugMessageMap.promoUrl }>
                            { productItem.adbugMessageMap.adbugMessage }
                          </Anchor>
                        </div>
                      )
                    }
                  } )() }
                  { ( ()=>{
                    if( productItem.priceInfo.messages || productItem.couponApplied ){
                      const discountMessage = productItem.priceInfo.messages && productItem.priceInfo.messages.items[0].message;
                      return (
                        <div className={ classNames( {
                          'ProductCellItem__footer--discountApplied' :( discountMessage && discountMessage.toUpperCase() === 'DISCOUNT APPLIED' ),
                          'ProductCellItem__footer--discountAppliedOnLeastPrice':( !discountMessage || discountMessage.toUpperCase() !== 'DISCOUNT APPLIED' )
                        } ) }
                        >
                          <span>
                            { discountMessage }
                          </span>
                          <span className={
                            classNames( 'comma', {
                              'discountAppliedHide': ( !discountMessage || !productItem.couponApplied )
                            } )
                          }
                          >, </span>
                          <span
                            className={
                              classNames( 'couponApplied', {
                                'discountAppliedHide': !productItem.couponApplied
                              } )
                            }
                          >
                            { formatMessage( messages.couponApplied ) }
                          </span>
                        </div>
                      )
                    }
                  } )() }

                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          className={
            classNames( 'ProductCellItem__product__removed', {
              'showRemoved': ( this.props.errorRemoving === '' && productItem.commerceItemid === this.props.removingItem ),
              'hideRemoved': ( this.props.errorRemoving !== '' || productItem.commerceItemid !== this.props.removingItem )
            } )
          }
        >

        </div>
        { this.props.removeItem && ( productItem.commerceItemid === ( this.props.removingItem || {} ).commerceItemid ) &&<div className='ProductCellItem__spinner' >
          <Spinner/>
        </div> }
      </div>
    );
  }
}

ProductCellItem.propTypes = propTypes;

export default ProductCellItem;
