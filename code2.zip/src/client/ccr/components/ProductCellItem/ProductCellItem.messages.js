import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.ProductCellItem.header',
    defaultMessage: 'This is the ProductCellItem component !'
  },
  remove: {
    id: 'i18n.ProductCellItem.remove',
    defaultMessage: 'Remove'
  },
  saveForLater: {
    id: 'i18n.ProductCellItem.saveForLater',
    defaultMessage: 'Save For Later'
  },
  discountApplied: {
    id: 'i18n.ProductCellItem.discountApplied',
    defaultMessage: 'Discount Applied!'
  },
  quantityLabel: {
    id: 'i18n.ProductCellItem.quantityLabel',
    defaultMessage: 'Qty: '
  },
  couponApplied: {
    id: 'i18n.ProductCellItem.couponApplied',
    defaultMessage: 'Coupon Applied!'
  },
  removedText:{
    id: 'i18n.ProductCellItem.removedText',
    defaultMessage: 'Removing...'
  },
  excludedItem: {
    id: 'i18n.ProductDescriptionCard.excludedItem',
    defaultMessage: 'Excluded from coupon'
  },
  quantityariaLabel: {
    id: 'i18n.ProductCellItem.quantityariaLabel',
    defaultMessage: 'Quantity'
  },
  originalPriceAriaLabel: {
    id: 'i18n.ProductCellItem.originalPriceAriaLabel',
    defaultMessage: 'Original Price'
  },
  salePriceAriaLabel: {
    id: 'i18n.ProductCellItem.salePriceAriaLabel',
    defaultMessage: 'Sale Price'
  },
  priceAriaLabel: {
    id: 'i18n.ProductCellItem.priceAriaLabel',
    defaultMessage: 'Price'
  }
} );
