import React from 'react';
import ReactDOM from 'react-dom';
import ProductCellItem from './ProductCellItem';
import { mountWithIntl, shallowWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './ProductCellItem.messages';
import { shallow } from 'enzyme';
import configureStore from 'ccr/ccr.store';
import { Provider } from 'react-redux';
import CONFIG from 'ccr/ccr.config';

const cartPageData = {
  'messages': {
    'items': [
      {
        'type': 'Info',
        'message': 'Looks like you have items in your bag from before. They\'ve been added below.'
      }
    ]
  },
  'cartSummary': {
    'shippingCost': 5.95,
    'subTotal': 21,
    'itemCount': 1,
    'orderGiftWrapAmt': 0,
    'additionalDiscount': null,
    'couponDiscount': 0,
    'estimatedTax': 'TBD',
    'estimatedTotal': 26.95,
    'currencyCode': 'USD',
    'couponCode': null
  },
  'giftOptions': {
    'giftBoxProductId': 'prod9990099',
    'giftBoxPrice': 3.99,
    'messages': {
      'items': [
        {
          'type': 'Info',
          'message': 'Message and Gift Box Added'
        }
      ]
    },
    'giftBoxSelected': true,
    'giftBoxSkuId': '9990099',
    'giftBoxDesc': 'Make it very special! In a gift box and topped with a bow!!!',
    'giftBoxImageURL': 'https://images.ulta.com/is/image/Ulta/9990099?$md$',
    'giftNote': 'Happy Birthday'
  },
  'freeSamplesInfo': {
    'items': [
      {
        'catalogRefId': '2252998',
        'sampleDesc': 'Fragrance',
        'shippingRestriction': 'Cannot ship to selected address',
        'selected': true
      },
      {
        'catalogRefId': '2252999',
        'sampleDesc': 'Skincare',
        'shippingRestriction': null,
        'selected': false
      },
      {
        'catalogRefId': '2253000',
        'sampleDesc': 'Variety',
        'shippingRestriction': null,
        'selected': false
      }
    ],
    'messages': {
      'items': [
        {
          'type': 'info',
          'message': 'Fragrance Added'
        }
      ]
    }
  },
  'giftHeaderMessage': 'See',
  'orderId': 'U467725401',
  'appliedCouponSummary': {
    'couponAppliedStatus': false,
    'couponCode': 'HSHHSSS',
    'messages': {
      'items': [
        {
          'type': 'error',
          'message': 'Entered coupon code is not valid'
        }
      ]
    }
  },
  'removedItems': {
    'messages': {
      'items': [
        {
          'type': 'Info',
          'message': 'The below item is no longer available and has been removed from your bag'
        }
      ]
    },
    'items': [
      {
        'couponApplied': false,
        'brandName': 'OPI',
        'quantity': null,
        'productId': 'xlsImpprod5180311',
        'excludedFromCoupon': false,
        'adbugMessageMap': null,
        'catalogRefId': '2056976',
        'categoryName': null,
        'commerceItemid': null,
        'priceInfo': {
          'salePrice': null,
          'regularPrice': '$10',
          'unitPriceMessage': null,
          'bfxPriceMap': null
        },
        'productDisplayName': 'Soft Shades Nail Lacquer Collection',
        'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
        'variantInfo': {
          'Color': 'Bubble Bath'
        },
        'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
        'shippingRestriction': null,
        'maxQty': null,
        'productURL': null,
        'messages': {
          'items': [
            {
              'type': 'Info',
              'message': 'Selected items is out of stock'
            }
          ]
        }
      },
      {
        'couponApplied': false,
        'brandName': 'OPI',
        'quantity': null,
        'productId': 'xlsImpprod5180311',
        'excludedFromCoupon': false,
        'adbugMessageMap': null,
        'categoryName': null,
        'commerceItemid': null,
        'catalogRefId': '2056976',
        'priceInfo': {
          'salePrice': null,
          'regularPrice': '$10',
          'unitPriceMessage': null,
          'bfxPriceMap': null
        },
        'productDisplayName': 'Soft Shades Nail Lacquer Collection',
        'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
        'variantInfo': {
          'Color': 'Bubble Bath'
        },
        'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
        'shippingRestriction': null,
        'maxQty': null,
        'productURL': null,
        'messages': {
          'items': [
            {
              'type': 'Info',
              'message': 'Nolongerqualifiesforthisfreegift'
            }
          ]
        }
      },
      {
        'couponApplied': false,
        'brandName': 'ULTA',
        'quantity': null,
        'productId': 'xlsImpprod3570051',
        'excludedFromCoupon': false,
        'adbugMessageMap': null,
        'categoryName': null,
        'commerceItemid': null,
        'catalogRefId': '2275711',
        'priceInfo': {
          'salePrice': null,
          'regularPrice': '$10',
          'unitPriceMessage': null,
          'bfxPriceMap': null
        },
        'productDisplayName': 'SalonFormulaNailLacquer',
        'imageURL': 'http: //images.ulta.com/is/image/Ulta/2154759?$md$',
        'variantInfo': {
          'Color': 'BubbleBath'
        },
        'skuDisplayName': 'SalonFormulaNailLacquer',
        'shippingRestriction': null,
        'maxQty': null,
        'productURL': null,
        'messages': {
          'items': [
            {
              'type': 'Info',
              'message': 'SelectedItemisOutofstock'
            }
          ]
        }
      }
    ]
  },
  'banner': {
    'messages': {
      'items': [
        {
          'type': 'info',
          'message': 'You\'re $29.00 away from FREE shipping'
        }
      ]
    }
  },
  'ultamateRewardsCCInfo': {},
  'giftItems': {
    'items': [
      {
        'bfxPriceMap': null,
        'freeGifts': {
          'items': [
            {
              'giftVariant': 'Rhubarb',
              'giftProductId': 'VP11651',
              'giftPDPUrl': '/lip-shimmer?productId=VP11651&sku=2133425',
              'giftCatalogRefId': '2133425',
              'giftDisplayName': 'Lip Shimmer',
              'giftCategoryName': 'Lip Care',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2133425?$md$',
              'selected': 'false',
              'giftBrandName': 'Burt\'s Bees'
            },
            {
              'giftProductId': 'xlsImpprod1040288',
              'giftPDPUrl': '/un-wrinkle-night?productId=xlsImpprod1040288&sku=2160848',
              'giftCatalogRefId': '2160848',
              'giftDisplayName': 'Un-Wrinkle Night',
              'giftCategoryName': 'Moisturizers',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2160848?$md$',
              'selected': 'false',
              'giftBrandName': 'Peter Thomas Roth'
            },
            {
              'giftVariant': 'Parfait',
              'giftProductId': 'xlsImpprod5770357',
              'giftPDPUrl': '/butter-lip-balm?productId=xlsImpprod5770357&sku=2262487',
              'giftCatalogRefId': '2262487',
              'giftDisplayName': 'Butter Lip Balm',
              'giftCategoryName': 'Lip Care',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2262487?$md$',
              'selected': 'false',
              'giftBrandName': 'Nyx Cosmetics'
            },
            {
              'giftDisplayName': 'QATEST_SINGLE GWP-MULTIPLE GIFTS (DOUBLE G)',
              'giftImageURL': 'https://images.ulta.com/is/image/Ulta/2210998?$md$',
              'selected': 'default'
            }
          ]
        },
        'promoId': '0000124096',
        'induldge': true,
        'promoValidity': 'offer valid 01/22/2015-02/28/2018 or while supplies last'
      },
      {
        'bfxPriceMap': null,
        'freeGifts': {
          'items': [
            {
              'giftVariant': 'Rhubarb',
              'giftProductId': 'VP11651',
              'giftPDPUrl': '/lip-shimmer?productId=VP11651&sku=2133425',
              'giftCatalogRefId': '2133425',
              'giftDisplayName': 'Lip Shimmer',
              'giftCategoryName': 'Lip Care',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2133425?$md$',
              'selected': 'false',
              'giftBrandName': 'Burt\'s Bees'
            },
            {
              'giftProductId': 'xlsImpprod1040288',
              'giftPDPUrl': '/un-wrinkle-night?productId=xlsImpprod1040288&sku=2160848',
              'giftCatalogRefId': '2160848',
              'giftDisplayName': 'Un-Wrinkle Night',
              'giftCategoryName': 'Moisturizers',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2160848?$md$',
              'selected': 'false',
              'giftBrandName': 'Peter Thomas Roth'
            },
            {
              'giftVariant': 'Parfait',
              'giftProductId': 'xlsImpprod5770357',
              'giftPDPUrl': '/butter-lip-balm?productId=xlsImpprod5770357&sku=2262487',
              'giftCatalogRefId': '2262487',
              'giftDisplayName': 'Butter Lip Balm',
              'giftCategoryName': 'Lip Care',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2262487?$md$',
              'selected': 'false',
              'giftBrandName': 'Nyx Cosmetics'
            },
            {
              'giftDisplayName': 'QATEST_SINGLE GWP-MULTIPLE GIFTS (DOUBLE G)',
              'giftImageURL': 'https://images.ulta.com/is/image/Ulta/2210998?$md$',
              'selected': 'default'
            }
          ]
        },
        'promoId': '0000124096',
        'induldge': true,
        'promoValidity': 'offer valid 01/22/2015-02/28/2018 or while supplies last'
      }
    ]
  },
  'cartItems': {
    'items': [
      {
        'commerceItemId': 'ci108397018736',
        'brandName': 'Laura Geller Beauty',
        'quantity': {
          'value': 9,
          messages: null
        },
        'productId': 'xlsImpprod2240027',
        'displayName': 'Balance N Brighten',
        'catalogRefId': '2218588',
        'priceInfo': {
          'regularPrice': '$19.98',
          'salePrice': null,
          'unitPriceMessage': '1 @ $5,1 @ $9.99',
          'messages':{
            'items':[
              {
                'type':'Info',
                'message':'Discount Applied!'
              }
            ]
          }
        },
        'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$',
        'maxQty': 10,
        'adbugMessageMap': {
          'adbugMessage': 'Buy 1, get 1 at 50% off! ',
          'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
        },
        'hazmatCode': '',
        'excludedFromCoupon': true,
        'discountMessage': 'Discount Applied!',
        'couponApplied': true,
        'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
        'variantInfo': {
          'color': 'Red',
          'size': '7oz'
        },
        'errorMsg': ''
      },
      {
        'commerceItemId': 'ci108397018736',
        'brandName': 'Laura Geller Beauty',
        'quantity': {
          'value': 2
        },
        'productId': 'xlsImpprod2240027',
        'displayName': 'Balance N Brighten',
        'catalogRefId': '2218588',
        'priceInfo': {
          'regularPrice': '$19.98',
          'salePrice': '$14.99',
          'unitPriceMessage': '1 @ $5,1 @ $9.99'
        },
        'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
        'maxQty': 10,
        'hazmatCode': 'Can\'t be shipped via air',
        'excludedFromCoupon': true,
        'dicountApplied': false,
        'couponApplied': true,
        'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
        'variantInfo': {
          'size': '7oz'
        },
        'errorMsg': ''
      },
      {
        'commerceItemId': 'ci108397018736',
        'brandName': 'Laura Geller Beauty',
        'quantity': {
          'value': 5
        },
        'productId': 'xlsImpprod2240027',
        'displayName': 'Balance N Brighten',
        'catalogRefId': '2218588',
        'priceInfo':{
          'regularPrice': '$19.98',
          'unitPriceMessage': '2 @ 35.00',
          'messages':{
            'items':[
              {
                'type':'Info',
                'message':'Discount Applied!'
              }
            ]
          }
        },
        'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/22185888?$md$',
        'maxQty': 10,
        'hazmatCode': 'Can\'t be shipped via air',
        'excludedFromCoupon': false,
        'discountMessage': 'discount applied!',
        'couponApplied': false,
        'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
        'variantInfo': {
        },
        'adbugMessageMap': {
          'adbugMessage': 'Buy 1, get 1 at 50% off! ',
          'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
        },
        'errorMsg': ''
      },
      {
        'commerceItemId': 'ci108397018736',
        'brandName': 'Laura Geller Beauty',
        'quantity': {
          'value': 10,
          'messages': {
            'items': [
              {
                'type': 'Info',
                'message': 'Selected Quantity not available'
              }
            ]
          }
        },
        'productId': 'xlsImpprod2240027',
        'displayName': 'Balance N Brighten',
        'catalogRefId': '2218588',
        'priceInfo':{
          'regularPrice': '$19.98',
          'salePrice': '$14.99',
          'unitPriceMessage': '1 @ $5,1 @ $9.99'
        },
        'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2257743?$md$',
        'maxQty': 5,
        'hazmatCode': 'Can\'t be shipped via air',
        'excludedFromCoupon': false,
        'dicountApplied': false,
        'couponApplied': false,
        'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
        'variantInfo': {
          'color': 'Red'
        },
        'adbugMessageMap': null
      },
      {
        'commerceItemId': 'ci108397018736',
        'brandName': 'Laura Geller Beauty',
        'quantity': {
          'value': 12
        },
        'productId': 'xlsImpprod2240027',
        'displayName': 'Balance N Brighten',
        'catalogRefId': '2218588',
        'priceInfo':{
          'regularPrice': '$19.98',
          'salePrice': '$14.99',
          'unitPriceMessage': '1 @ $5,1 @ $9.99'
        },
        'imageURL': 'http://images.ulta.com/is/image/Ulta/2023775?$md$',
        'maxQty': 10,
        'hazmatCode': 'Can\'t be shipped via air',
        'excludedFromCoupon': true,
        'dicountApplied': true,
        'couponApplied': true,
        'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
        'variantInfo': {
          'color': 'Green',
          'size': '7oz'
        },
        'adbugMessageMap': {
          'adbugMessage': 'Buy 1, get 1 at 50% off! ',
          'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
        },
        'errorMsg': ''
      }
    ]
  },
  'showShippingRestrictionMsg': true
};

describe( '<ProductCellItem />', () => {
  const store = configureStore( {}, CONFIG );
  let component;

  let data = {
    'couponApplied': false,
    'brandName': 'Benefit Cosmetics',
    'quantity': {
      'value': 6,
      'messages':null
    },
    'productId': 'xlsImpprod820326',
    'excludedFromCoupon': false,
    'adbugMessageMap': {
      'adbugMessage': null,
      'promoUrl': 'https://qa2.ulta.com/ulta/promotion/buy-more-save-more/detail/0000153130'
    },
    'catalogRefId': '2160252',
    'categoryName': 'Highlighter',
    'discountMessage': 'Discount Applied',
    'errorMsg': '',
    'commerceItemid': 'ci15633002744',
    'priceInfo': {
      'salePrice': null,
      'regularPrice': '$156.00',
      'bfxPriceMap': [{ 'bfxQty': '6', 'bfxPrice': '$26.00' }],
      'unitPriceMessage': '6 @ $26.00',
      'messages':{
        'items':[
          {
            'type':'Info',
            'message':'Discount Applied'
          }
        ]
      }
    },
    'productDisplayName': 'High Beam Liquid Face Highlighter',
    'imageURL': 'https://images.ulta.com/is/image/Ulta/2160252?$md$',
    'variantInfo': { 'Color': 'Pink' },
    'skuDisplayName': 'High Beam Liquid Face Highlighter',
    'shippingRestriction': null,
    'maxQty': 10,
    'productURL': '/high-beam-liquid-face-highlighter?productId=xlsImpprod820326&sku=2160252'
  };
  const productQuantity = 6;
  let props = {
    currentPage: 'checkout',
    showShippingRestrictionMsg: true,
    quantity : {
      value:productQuantity,
      messages:null
    }
  }
  component = mountWithIntl(
    <Provider store={ store }>
      <ProductCellItem
        productItem={ data }
        { ...props }
      />
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'ProductCellItem' ).length ).toBe( 1 );
  } );

  it( 'renders the proper label string for the ProductCellItem__dropdown', () => {
    expect( component.find( 'select' ).props()['aria-label'] ).toBe( messages.quantityariaLabel.defaultMessage );
  } );

  it( 'inovking setProductQuantity should set the value to quantityDropdown', () => {
    let node = component.find( 'ProductCellItem' ).instance();
    const quantity = '10';
    node.setProductQuantity( quantity );
    expect( node.quantityDropdown.value ).toBe( quantity );
  } );

  it( 'quantityDropdown should be truthy and refer to the select child item', () => {
    let node = component.find( 'ProductCellItem' ).instance();
    expect( node.quantityDropdown ).toBeTruthy();
    const setProductQuantityMock = jest.fn();
    node.setProductQuantity = setProductQuantityMock;
    node.componentDidMount();
    expect( setProductQuantityMock ).toHaveBeenCalledWith( productQuantity );
  } );

  it( 'should invoke setProductQuantity when component is mounted', () => {
    let node = component.find( 'ProductCellItem' ).instance();
    const setProductQuantityMock = jest.fn();
    node.setProductQuantity = setProductQuantityMock;
    node.componentDidMount();
    expect( setProductQuantityMock ).toHaveBeenCalledWith( productQuantity );
  } );

  it( 'should invoke setProductQuantity if there is a change in value', () => {
    const setProductQuantityMock = jest.fn();
    const props = {
      quantity : 6
    }
    const component6 = mountWithIntl(
      <Provider store={ store }>
        <ProductCellItem
          productItem={ data }
          { ...props }
        />
      </Provider>
    );
    let node = component6.find( 'ProductCellItem' ).instance();

    const prevProps = {
      productItem : {
        quantity : 8
      }
    }
    node.setProductQuantity( 8 );
    node.setProductQuantity = setProductQuantityMock;
    node.componentDidUpdate( prevProps );
    expect( setProductQuantityMock ).toHaveBeenCalledWith( 6 );
  } );

  it( 'coupon ecxluded msg', () => {
    const testdata4 = {
      'commerceItemId': 'ci108397018736',
      'brandName': 'Laura Geller Beauty',
      'quantity': {
        'value': 2,
        'messages':null
      },
      'productId': 'xlsImpprod2240027',
      'displayName': 'Balance N Brighten',
      'catalogRefId': '2218588',
      'priceInfo': {
        'regularPrice': '$19.98',
        'salePrice': '$14.99',
        'unitPriceMessage': '1 @ $5,1 @ $9.99'
      },
      'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
      'maxQty': 10,
      'hazmatCode': 'Can\'t be shipped via air',
      'excludedFromCoupon': true,
      'dicountApplied': false,
      'couponApplied': true,
      'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
      'variantInfo': {
        'size': '7oz'
      },
      'errorMsg': ''
    };
    let componentForMessage = mountWithIntl(
      <Provider store={ store }>
        <ProductCellItem productItem={ testdata4 } />
      </Provider>
    );
    expect( componentForMessage.find( '.ResponseMessages' ).length ).toBe( 1 );
  } );


  // Test Case for verifying green color text if the discount message is given
  it( 'Verify green text for discount applied', () => {
    expect( component.find( '.ProductCellItem__footer--discountApplied' ).length ).toBe( 1 );
  } );

  // Test Case for verifying gray color text if the discount message is not recieved
  it( 'Verify gray color if discount not applied', () => {
    const testdata4 = {
      'commerceItemId': 'ci108397018736',
      'brandName': 'Laura Geller Beauty',
      'quantity': {
        'value': 1,
        'messages':null
      },
      'productId': 'xlsImpprod2240027',
      'displayName': 'Balance N Brighten',
      'catalogRefId': '2218588',
      'priceInfo': {
        'regularPrice': '$19.98',
        'salePrice': '$14.99',
        'unitPriceMessage': '1 @ $5,1 @ $9.99',
        'messages':{
          'items':[
            {
              'type':'Info',
              'message':'Discount not Applied'
            }
          ]
        }
      },
      'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
      'maxQty': 10,
      'hazmatCode': 'Can\'t be shipped via air',
      'excludedFromCoupon': true,
      'dicountApplied': false,
      'discountMessage': 'discount not applied',
      'couponApplied': true,
      'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
      'variantInfo': {
        'size': '7oz'
      },
      'errorMsg': ''
    };
    let componentForMessage = mountWithIntl(
      <Provider store={ store }>
        <ProductCellItem productItem={ testdata4 } />
      </Provider>
    );
    expect( componentForMessage.find( '.ProductCellItem__footer--discountAppliedOnLeastPrice' ).length ).toBe( 1 )
  } );


  it( 'renders the select box', () => {
    expect( component.find( '.ProductCellItem__content .ProductCellItem__content--dropdown' ).length ).toBe( 1 );
  } );

  it( 'renders the options according to the data from the service', () => {
    expect( component.find( 'option' ).length ).toBe( parseInt( data.maxQty, 10 ) );
  } );
  it( 'displays error message when quantity greater than max quantity', () => {
    data = cartPageData.cartItems.items[3];
    component = mountWithIntl( <ProductCellItem productItem={ data } /> );
    expect( ( component.find( '.ProductCellItem__content--variants' ).find( '.ProductCellItem__dropdown--errorMsg' ) ).text() ).toBe( data.quantity.messages.items[0].message );
  } );

  it( 'renders the product description card component', () => {
    data = cartPageData.cartItems.items[0];
    component = mountWithIntl(
      <Provider store={ store }>
        <ProductCellItem productItem={ data } />
      </Provider>
    );
    expect( component.find( '.ProductDescriptionCard' ).length ).toBe( 1 );
  } );

  it( 'renders the price ', () => {
    expect( component.find( '.ProductCellItem__content--price' ).length ).toBe( 1 );
  } );

  it( 'renders the sale Price', () => {
    expect( component.find( '.ProductCellItem__price--sale' ).length ).toBe( 1 );
  } );

  it( 'renders the correct sale Price', () => {
    expect( component.find( '.ProductCellItem__price--sale' ).text() ).toBe( '' );
  } );

  it( 'renders the aria-label for sale Price', () => {
    expect( component.find( '.ProductCellItem__price--sale label' ).length ).toBeFalsy();
  } );

  it( 'renders the regular Price', () => {
    expect( component.find( '.ProductCellItem__price--regular' ).length ).toBe( 1 );
  } );

  it( 'renders the correct regular Price', () => {
    expect( component.find( '.ProductCellItem__price--regular' ).text() ).toBe( messages.priceAriaLabel.defaultMessage + data.priceInfo.regularPrice );
  } );

  it( 'renders the aria-label for regular Price', () => {
    expect( component.find( '.ProductCellItem__price--regular label' ).text() ).toBe( messages.priceAriaLabel.defaultMessage );
  } );

  it( 'renders the unit message', () => {
    expect( component.find( '.ProductCellItem__unitmessage' ).length ).toBe( 1 );
  } );

  it( 'renders the correct unit message', () => {
    expect( component.find( '.ProductCellItem__unitmessage' ).text() ).toBe( data.priceInfo.unitPriceMessage );
  } );

  it( 'renders the remove and save for later buttons', () => {
    expect( component.find( '.removeButton' ).length ).toBe( 1 );
  } );

  it( 'renders both the discount applied and couponApplied message', () => {
    expect( component.find( '.ProductCellItem__footer--discountAppliedOnLeastPrice span' ).length ).toBe( 3 );
  } );

  it( 'does not hides the right footer', () => {
    expect( component.find( '.ProductCellItem__footer__right__hide' ).length ).toBe( 0 );
  } );

  it( 'renders the correct message when coupon applied', () => {
    expect( component.find( '.couponApplied' ).text() ).toBe( messages.couponApplied.defaultMessage );
  } );

  let testData = {
    'couponApplied': false,
    'brandName': 'Benefit Cosmetics',
    'quantity': {
      'value': 6,
      messages:null
    },
    'productId': 'xlsImpprod820326',
    'excludedFromCoupon': false,
    'adbugMessageMap': {
      'adbugMessage': null,
      'promoUrl': 'https://qa2.ulta.com/ulta/promotion/buy-more-save-more/detail/0000153130'
    },
    'catalogRefId': '2160252',
    'categoryName': 'Highlighter',
    'discountMessage': 'Discount Applied',
    'errorMsg': '',
    'commerceItemid': 'ci15633002744',
    'priceInfo': {
      'salePrice': null,
      'regularPrice': '$156.00',
      'bfxPriceMap': [{ 'bfxQty': '6', 'bfxPrice': '$26.00' }],
      'unitPriceMessage': '6 @ $26.00',
      'messages':{
        'items':[
          {
            'type':'Info',
            'message':'Discount Applied!'
          }
        ]
      }
    },
    'productDisplayName': 'High Beam Liquid Face Highlighter',
    'imageURL': 'https://images.ulta.com/is/image/Ulta/2160252?$md$',
    'variantInfo': { 'Color': 'Pink' },
    'skuDisplayName': 'High Beam Liquid Face Highlighter',
    'shippingRestriction': true,
    'maxQty': 10,
    'productURL': '/high-beam-liquid-face-highlighter?productId=xlsImpprod820326&sku=2160252'
  };

  props = {
    currentPage: 'checkout',
    showShippingRestrictionMsg: true
  }

  let component1 = mountWithIntl(
    <Provider store={ store }>
      <ProductCellItem productItem={ testData } { ...props }/>
    </Provider>
  );

  it( 'does not render the discount applied messages', () => {
    expect( component1.find( '.comma .discountAppliedHide' ).length ).toBe( 1 );
  } );

  it( 'renders Hazmat message if the showShippingRestrictionMsg is true', () => {
    expect( component1.find( 'ResponseMessages' ).length ).toBe( 1 );
  } );

  it( 'does not hides the right footer', () => {
    expect( component1.find( '.ProductCellItem__footer__right__hide' ).length ).toBe( 0 );
  } );

  it( 'does not render the comma', () => {
    expect( component1.find( '.comma .discountAppliedHide' ).length ).toBe( 1 );
  } );

  it( 'renders the correct message when coupon applied', () => {
    expect( component1.find( '.couponApplied' ).text() ).toBe( messages.couponApplied.defaultMessage );
  } );

  let testData1 = {
    'couponApplied': false,
    'brandName': 'Benefit Cosmetics',
    'quantity': {
      'value': 6,
      messages:null
    },
    'productId': 'xlsImpprod820326',
    'excludedFromCoupon': false,
    'adbugMessageMap': {
      'adbugMessage': null,
      'promoUrl': 'https://qa2.ulta.com/ulta/promotion/buy-more-save-more/detail/0000153130'
    },
    'catalogRefId': '2160252',
    'categoryName': 'Highlighter',
    'discountMessage': 'Discount Applied',
    'errorMsg': '',
    'commerceItemid': 'ci15633002744',
    'priceInfo': {
      'salePrice': null,
      'regularPrice': '$156.00',
      'bfxPriceMap': [{ 'bfxQty': '6', 'bfxPrice': '$26.00' }],
      'unitPriceMessage': '6 @ $26.00',
      'messages':{
        'items':[
          {
            'type':'Info',
            'message':'Discount Applied!'
          }
        ]
      }
    },
    'productDisplayName': 'High Beam Liquid Face Highlighter',
    'imageURL': 'https://images.ulta.com/is/image/Ulta/2160252?$md$',
    'variantInfo': { 'Color': 'Pink' },
    'skuDisplayName': 'High Beam Liquid Face Highlighter',
    'shippingRestriction': true,
    'maxQty': 10,
    'productURL': '/high-beam-liquid-face-highlighter?productId=xlsImpprod820326&sku=2160252'
  };

  let component2 = mountWithIntl(
    <Provider store={ store }>
      <ProductCellItem productItem={ testData1 } { ...props }/>
    </Provider>
  );

  it( 'does not render the coupon applied messages', () => {
    expect( component2.find( '.couponApplied .discountAppliedHide' ).length ).toBe( 1 );
  } );

  it( 'does not render the comma', () => {
    expect( component2.find( '.comma .discountAppliedHide' ).length ).toBe( 1 );
  } );

  it( 'does not hides the right footer', () => {
    expect( component2.find( '.ProductCellItem__footer__right__hide' ).length ).toBe( 0 );
  } );

  it( 'does not render the sale price', () => {
    expect( component2.find( '.ProductCellItem__price--sale' ).text() ).toBe( '' );
  } );

  let testData3 = {
    'couponApplied': false,
    'brandName': 'Benefit Cosmetics',
    'quantity': {
      'value': 6,
      'messages':null
    },
    'productId': 'xlsImpprod820326',
    'excludedFromCoupon': false,
    'adbugMessageMap': {
      'adbugMessage': null,
      'promoUrl': 'https://qa2.ulta.com/ulta/promotion/buy-more-save-more/detail/0000153130'
    },
    'catalogRefId': '2160252',
    'categoryName': 'Highlighter',
    'discountMessage': 'Discount Applied',
    'errorMsg': '',
    'commerceItemid': 'ci15633002744',
    'priceInfo': {
      'salePrice': null,
      'regularPrice': '$156.00',
      'bfxPriceMap': [{ 'bfxQty': '6', 'bfxPrice': '$26.00' }],
      'unitPriceMessage': '6 @ $26.00',
      'messages':{
        'items':[
          {
            'type':'Info',
            'message':'Discount Applied'
          }
        ]
      }
    },
    'productDisplayName': 'High Beam Liquid Face Highlighter',
    'imageURL': 'https://images.ulta.com/is/image/Ulta/2160252?$md$',
    'variantInfo': { 'Color': 'Pink' },
    'skuDisplayName': 'High Beam Liquid Face Highlighter',
    'shippingRestriction': true,
    'maxQty': 10,
    'productURL': '/high-beam-liquid-face-highlighter?productId=xlsImpprod820326&sku=2160252'
  };

  props = {
    currentPage: 'checkout',
    showShippingRestrictionMsg: true
  }

  let component3 = mountWithIntl(
    <Provider store={ store }>
      <ProductCellItem productItem={ testData3 } { ...props }/>
    </Provider>
  );

  it( 'renders the correct message when discount applied', () => {
    expect( component3.find( '.ProductCellItem__footer--discountApplied' ).text() ).toBe( testData3.discountMessage + ', '+messages.couponApplied.defaultMessage );
  } );

  it( 'does not render the coupon applied messages', () => {
    expect( component3.find( '.couponApplied .discountAppliedHide' ).length ).toBe( 1 );
  } );

  it( 'does not render the comma', () => {
    expect( component3.find( '.comma .discountAppliedHide' ).length ).toBe( 1 );
  } );

  it( 'does not render the discount applied message', () => {
    expect( component3.find( '.comma .discountAppliedHide' ).length ).toBe( 1 );
  } );


  it( 'invokes the function removeItemFunction', () => {
    let node1 = component3.find( 'ProductCellItem' ).instance();
    node1.removeItemFunction = jest.fn();
    node1.removeItemFunction.mockClear();
    component3.find( '.removeButton .Anchor' ).simulate( 'click' );
    expect( node1.removeItemFunction ).toHaveBeenCalled();
  } );

  props = {
    currentPage: 'checkout',
    showShippingRestrictionMsg: true
  }
  let component4 = mountWithIntl(
    <Provider store={ store }>
      <ProductCellItem productItem={ testData3 } { ...props } />
    </Provider>
  );

  it( 'should render the different variants section', () => {
    expect( component4.find( '.ProductCellItem__content--variants' ).length ).toBe( 1 );
  } );

  it( 'should render the different cards section', () => {
    expect( component4.find( '.ProductCellItem__content.ProductCellItem__content--card' ).length ).toBe( 1 );
  } );

  const testdata4 =  {
    'commerceItemId': 'ci108397018736',
    'brandName': 'Laura Geller Beauty',
    'quantity': {
      'value': 2,
      'messages':null
    },
    'productId': 'xlsImpprod2240027',
    'displayName': 'Balance N Brighten',
    'catalogRefId': '2218588',
    'priceInfo': {
      'regularPrice': '$19.98',
      'salePrice': '$14.99',
      'unitPriceMessage': '1 @ $5,1 @ $9.99'
    },
    'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2218588?$md$',
    'maxQty': 10,
    'hazmatCode': 'Can\'t be shipped via air',
    'excludedFromCoupon': true,
    'dicountApplied': false,
    'couponApplied': true,
    'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
    'variantInfo': {
      'size': '7oz'
    },
    'errorMsg': ''
  };
  let component5 = mountWithIntl(
    <Provider store={ store }>
      <ProductCellItem productItem={ testdata4 } />
    </Provider>
  );

  it( 'items doesnot qualify for the coupon we will get the applied message', () => {
    expect( component5.find( '.ResponseMessages' ).text() ).toBe( messages.excludedItem.defaultMessage );
  } );

  it( 'renders the aria-label for sale Price with the reduced price info', () => {
    expect( component5.find( '.ProductCellItem__price--sale label' ).text() ).toBe( messages.salePriceAriaLabel.defaultMessage );
  } );

  it( 'renders the aria-label for regular Price with the reduced price info', () => {
    expect( component5.find( '.ProductCellItem__price--regular label' ).text() ).toBe( messages.originalPriceAriaLabel.defaultMessage );
  } );
} );
