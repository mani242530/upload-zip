/**
 * ProductCellList
 */

import React, { Component } from 'react';
import { formatMessage } from 'shared/components/Global/Global';
import PropTypes from 'prop-types';
import './ProductCellList.css';
import messages from './ProductCellList.messages';
import ProductCellItem from 'ccr/components/ProductCellItem/ProductCellItem';
import BfxProductCellItem from 'ccr/components/BfxProductCellItem/BfxProductCellItem';
import Divider from 'shared/components/Divider/Divider';
import classNames from 'classnames';
import CheckoutItemList from 'ccr/components/CheckoutItemList/CheckoutItemList';
import has from 'lodash/has';
import Gutter from 'shared/components/Gutter/Gutter';

const propTypes = {
  productData: PropTypes.array.isRequired,
  removeItem: PropTypes.bool,
  removingItem: PropTypes.string,
  displayProductInfo: PropTypes.bool,
  removeFromCart: PropTypes.func,
  updateCart: PropTypes.func,
  showShippingRestrictionMsg: PropTypes.bool,
  errorRemoving: PropTypes.string
}

const defaultProps = {
  displayProductInfo: true
}

/**
 * Class
 * @extends React.Component
 */
class ProductCellList extends Component{

  /**
   * Renders the ProductCellList component
   */
  render(){

    const productData = this.props.productData;
    return (
      <div className='ProductCellList'>
        <div className='ProductCellList__cartPageProductCell Gutter'>
          { ( () => {
            return productData.map( ( section, index ) => {
              return (
                <div
                  className='ProductCellList__item'
                  key={ index }
                >
                  <div className='ProductCellList__item--wrapper'>
                    <div className={
                      classNames( {
                        'ProductCellList__item--overlay': ( this.props.removeItem && ( section.commerceItemid === ( this.props.removingItem || {} ).commerceItemid ) )
                      } )
                    }
                    > </div>
                    { ( () => {
                      if( this.props.displayProductInfo ){
                        return (
                          <div
                            key={ index }
                          >
                            { ( () => {
                              if( index > 0 ){
                                return (
                                  <div className='productCellList__border'>
                                    <Divider dividerType={ 'gray' } />
                                  </div>
                                );
                              }
                            } )() }
                            <ProductCellItem
                              productItem={ section }
                              index={ index }
                              remove={ this.props.removeItem }
                              removeFromCart={ this.props.removeFromCart }
                              updateCart={ this.props.updateCart }
                              showShippingRestrictionMsg={ this.props.showShippingRestrictionMsg }
                              errorRemoving={ this.props.errorRemoving }
                              removingItem={ this.props.removingItem }
                              displayProductInfo={ this.props.displayProductInfo }
                              removeItem={ this.props.removeItem }
                              history={ this.props.history }
                            />
                            { ( () => {
                              if( this.props.displayProductInfo &&
                                section.priceInfo &&
                                section.priceInfo.bfxPriceMap ){
                                return (
                                  <div className='BfxProductCellItem'>
                                    { ( ()=>{
                                      return section.priceInfo.bfxPriceMap.map( ( bfxPriceInfo, index ) => {
                                        return (
                                          <BfxProductCellItem
                                            index={ index }
                                            skuId={ section.catalogRefId }
                                            productName={ section.productDisplayName }
                                            productImageUrl={ section.imageURL }
                                            productURL={ section.productURL }
                                            quantity={ bfxPriceInfo.bfxQty }
                                            price={ bfxPriceInfo.bfxPrice }
                                            variantInfo={ section.variantInfo }
                                            key={ index }
                                          />
                                        );
                                      } );
                                    } )() }
                                  </div>
                                );
                              }
                            } )() }
                          </div>
                        )
                      }
                    } )() }
                    { ( () => {
                      if( !this.props.displayProductInfo ){
                        return (
                          <CheckoutItemList
                            image={ section.imageURL }
                            quantity={ section.quantity }
                            brandName={ section.brandName }
                            productName={ section.productDisplayName }
                            variantInfo={ section.variantInfo }
                          />
                        )
                      }
                    } )() }
                  </div>

                </div>

              )
            } )
          } )() }
        </div>
        { ( () => {
          if( !this.props.displayProductInfo ){
            return null;
          }
          else {
            return (
              <div id='GiftAnchor' className='ProductCellListList__border'>
                <Divider dividerType={ 'gray' } />
              </div>
            )
          }
        } )() }

      </div>
    );

  }
}

ProductCellList.propTypes = propTypes;

export default ProductCellList;