/*
 * ProductCellList Messages
 *
 * This contains all the text for the ProductCellList component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.ProductCellList.header',
    defaultMessage: 'This is the ProductCellList component !'
  },
  quantityariaLabel: {
    id: 'i18n.ProductCellItem.quantityariaLabel',
    defaultMessage: 'Quantity'
  }
} );
