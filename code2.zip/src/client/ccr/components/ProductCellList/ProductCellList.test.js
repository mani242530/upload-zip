import React from 'react';
import ReactDOM from 'react-dom';
import ProductCellList from './ProductCellList';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './ProductCellList.messages';
import configureStore from 'ccr/ccr.store';
import { Provider } from 'react-redux';
import CONFIG from 'ccr/ccr.config';

describe( '<ProductCellList />', () => {
  const store = configureStore( {}, CONFIG );
  let cartItems = {
    'items': [
      {
        'commerceItemId': 'ci108397018736',
        'brandName': 'Laura Geller Beauty',
        'quantity': {
          value:9,
          messages:null
        },
        'productId': 'xlsImpprod2240027',
        'displayName': 'Balance N Brighten',
        'catalogRefId': '2218588',
        'priceInfo': {
          'regularPrice': '$19.98',
          'salePrice': null,
          'unitPriceMessage': '1 @ $5,1 @ $9.99'
        },
        'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$',
        'maxQty': 10,
        'adbugMessageMap': {
          'adbugMessage': 'Buy 1, get 1 at 50% off! ',
          'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
        },
        'hazmatCode': '',
        'excludedFromCoupon': true,
        'discountMessage': 'Discount Applied!',
        'couponApplied': true,
        'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
        'variantInfo': {
          'color': 'Red',
          'size': '7oz'
        },
        'errorMsg': ''
      }
    ]
  }
  let props1 = {
    productData: cartItems.items,
    showShippingRestrictionMsg: true
  }
  let component;
  component = mountWithIntl(
    <Provider store={ store }>
      <ProductCellList { ...props1 } />
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'ProductCellList' ).length ).toBe( 1 );
  } );

  let props2 = {
    productData: cartItems.items,
    displayProductInfo: true
  }
  let component1 = mountWithIntl(
    <Provider store={ store }>
      <ProductCellList { ...props2 } />
    </Provider>
  );

  it( 'renders Divider component', () => {
    expect( component.find( 'ProductCellList .productCellList__border' ).length ).toBe( cartItems.items.length - 1 );
  } );

  it( 'renders ProductCellItem component', () => {
    expect( component.find( '.ProductCellList__item' ).length ).toBe( cartItems.items.length );
  } );

  let component2 = mountWithIntl(
    <Provider store={ store }>
      <ProductCellList productData={ [] } />
    </Provider>
  );

  it( 'renders the component ProductCellItem only if the cartItems are present', () => {
    expect( component2.find( 'ProductCellItem' ).length ).toBe( 0 );
  } );

  it( 'renders the component Divider only if the cartItems are present', () => {
    expect( component2.find( '.productCellList__border' ).length ).toBe( 0 );
  } );

  let props3 = {
    productData: cartItems.items,
    displayProductInfo: true
  }
  let component3 = mountWithIntl(
    <Provider store={ store }>
      <ProductCellList { ...props3 } />
    </Provider>
  );
  it( 'does not render checkoutItemList for other pages', () => {
    expect( component3.find( 'CheckoutItemList' ).length ).toBe( 0 );
  } );

  it( 'renders ProductCellList__item component', () => {
    expect( component.find( '.ProductCellList__item' ).length ).toBe( cartItems.items.length );
  } );

  it( 'renders ProductCellList__item--overlay component', () => {
    const props4 = {
      productData: cartItems.items,
      displayProductInfo: true,
      removeItem:true,
      removingItem:cartItems.items[0],
      showShippingRestrictionMsg: false
    }
    const component4 = mountWithIntl(
      <Provider store={ store }>
        <ProductCellList { ...props4 } />
      </Provider>
    );
    expect( component4.find( '.ProductCellList__item--overlay' ).length ).toBe( 1 );
  } );

  describe( 'global.innerWidth below 1000px', () => {
    global.innerWidth = 900;
    let cartItems = {
      'items': [
        {
          'commerceItemId': 'ci108397018736',
          'brandName': 'Laura Geller Beauty',
          'quantity': {
            value:9,
            messages:null
          },
          'productId': 'xlsImpprod2240027',
          'displayName': 'Balance N Brighten',
          'productDisplayName': 'Balance N Brighten',
          'catalogRefId': '2218588',
          'priceInfo': {
            'regularPrice': '$19.98',
            'salePrice': null,
            'unitPriceMessage': '1 @ $5,1 @ $9.99'
          },
          'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$',
          'maxQty': 10,
          'adbugMessageMap': {
            'adbugMessage': 'Buy 1, get 1 at 50% off! ',
            'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
          },
          'hazmatCode': '',
          'excludedFromCoupon': true,
          'discountMessage': 'Discount Applied!',
          'couponApplied': true,
          'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
          'variantInfo': {
            'color': 'Red',
            'size': '7oz'
          },
          'errorMsg': ''
        },
        {
          'commerceItemId': 'ci108397018737',
          'brandName': 'Laura Geller Beauty',
          'quantity': {
            value:9,
            messages:null
          },
          'productId': 'xlsImpprod2240027',
          'displayName': 'Balance N Brighten',
          'catalogRefId': '2218588',
          'priceInfo': {
            'regularPrice': '$19.98',
            'salePrice': null,
            'unitPriceMessage': '1 @ $5,1 @ $9.99'
          },
          'imageURL': 'http://s7d5.scene7.com/is/image/Ulta/2151611?$md$',
          'maxQty': 10,
          'adbugMessageMap': {
            'adbugMessage': 'Buy 1, get 1 at 50% off! ',
            'promoUrl': 'http://local.ulta.com/ulta/promotion/buy-more-save-more/detail/0000154551'
          },
          'hazmatCode': '',
          'excludedFromCoupon': true,
          'discountMessage': 'Discount Applied!',
          'couponApplied': true,
          'pdpUrl': 'http://www.ulta.com/balance-n-brighten-baked-color-correcting-foundation?productId=xlsImpprod2240027&sku=2218588',
          'variantInfo': {
            'color': 'Red',
            'size': '7oz'
          },
          'errorMsg': ''
        }
      ]
    }
    let props4 = {
      productData: cartItems.items
    }
    let componentx = mountWithIntl(
      <Provider store={ store }>
        <ProductCellList { ...props4 } />
      </Provider>
    );

    it( 'renders new component checkoutItemList', () => {
      expect( componentx.find( 'CheckoutItemList' ).length ).toBe( cartItems.items.length );

      expect( componentx.find( 'CheckoutItemList' ).first().props().image ).toBe( cartItems.items[0].imageURL );
      expect( componentx.find( 'CheckoutItemList' ).first().props().quantity ).toBe( cartItems.items[0].quantity );
      expect( componentx.find( 'CheckoutItemList' ).first().props().brandName ).toBe( cartItems.items[0].brandName );
      expect( componentx.find( 'CheckoutItemList' ).first().props().productName ).toBe( cartItems.items[0].productDisplayName );
      expect( componentx.find( 'CheckoutItemList' ).first().props().variantInfo ).toBe( cartItems.items[0].variantInfo );
    } );

    it( 'renders checkoutItemList component', () => {
      expect( componentx.find( 'CheckoutItemList' ).length ).toBeDefined();
    } );

    let props5 = {
      productData: cartItems.items,
      displayProductInfo: true
    }
    let componenty = mountWithIntl(
      <Provider store={ store }>
        <ProductCellList { ...props5 } />
      </Provider>
    );
    it( 'does not render checkoutItemList', () => {
      expect( componenty.find( 'CheckoutItemList' ).length ).toBe( 0 );
    } );

    let props6 = {
      productData: cartItems.items,
      displayProductInfo: false
    }
    let componentz = mountWithIntl( <ProductCellList { ...props6 } /> );
    it( 'renders ProductCellList__item component same as number of cartItems', () => {
      expect( componentz.find( '.ProductCellList__item' ).length ).toBe( cartItems.items.length );
    } );


  } );

} );
