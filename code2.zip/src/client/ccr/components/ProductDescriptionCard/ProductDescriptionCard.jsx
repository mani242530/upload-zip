/**
 * ProductDescriptionCard
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './ProductDescriptionCard.css';
import Image from 'shared/components/Image/Image';
import Anchor from 'shared/components/Anchor/Anchor';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './ProductDescriptionCard.messages';
import { findKey, values, isEmpty, isNull } from 'lodash';
import Exclamation_Circle from 'shared/components/Icons/exclamationcircle';
import classNames from 'classnames';

const propTypes = {
  imageURL: PropTypes.string,
  brandName: PropTypes.string,
  displayName: PropTypes.string,
  messages: PropTypes.object,
  variant: PropTypes.object,
  isSVG: PropTypes.bool,
  svgComponent: PropTypes.object,
  productURL: PropTypes.string,
  displayProductInfo: PropTypes.bool,
  quantity: PropTypes.number
}

/**
 * Class
 * @extends React.Component
 */
class ProductDescriptionCard extends Component{

  /**
   * Renders the ProductDescriptionCard component
   */
  render(){

    let variantName = findKey( this.props.variant );
    let variantValue;

    try {
      variantValue = values( this.props.variant, variantValue )[ 0 ];
    }
    catch ( e ){

    }

    return (
      <div className='ProductDescriptionCard'>
        <div className='ProductDescriptionCard__ProductDescriptionContent'>
          <div className='ProductDescriptionCard__ProdContainer'>
            <div className='ProductDescriptionCard__ProductImage ProductDescriptionCard__ProductImage--image'>

              { ( () => {
                {

                  if( ! this.props.isSVG ){
                    return (
                      <Anchor url={ this.props.PDPUrl }>
                        <Image
                          className=''
                          src={ this.props.imageURL }
                          alt={ `${this.props.brandName} ${this.props.displayName} ${ variantName ? formatMessage( messages.variantInfo, { variantName: variantName, variantValue:variantValue } ) : '' }` }
                        />
                      </Anchor>
                    );
                  }
                  else {
                    return (
                      this.props.svgComponent
                    );
                  }
                }
              } )() }

            </div>
            <div
              className='ProductDescriptionCard__ProductDescription ProductDescriptionCard__ProductDescription--info'
            >
              <Anchor url={ this.props.PDPUrl }>
                <div className='ProductDescriptionCard__ProdName ProductDescriptionCard__ProdName--info'>
                  { this.props.brandName }
                </div>
                <div
                  className='ProductDescriptionCard__ProductDescriptionText ProductDescriptionCard__ProductDescriptionText--info'
                >
                  { this.props.displayName }
                </div>

                { ( () => {

                  if( this.props.variant !== undefined && !isEmpty( this.props.variant ) ){

                    return (
                      <div className='ProductDescriptionCard__ProductSize ProductDescriptionCard__ProductSize--info'>
                        { ( ()=>{
                          try {
                            return (
                              formatMessage( messages.variantInfo, { variantName: variantName, variantValue:variantValue } )
                            )
                          }
                          catch ( e ){

                          }
                        } )() }
                      </div>
                    );
                  }
                } )() }
                { ( () => {
                  if( this.props.quantity !== undefined && !this.props.displayProductInfo ){
                    return (
                      <div className='forCheckout'>
                        { formatMessage( messages.quantity ) }{ this.props.quantity }
                      </div>
                    );
                  }
                } )() }
              </Anchor>
              { ( () => {
                if( this.props.messages ){
                  return (
                    this.props.messages.items.map( ( msgItem, index ) => {
                      {
                        return (
                          <div
                            className='ProductDescriptionCard__ProductMsgDecription ProductDescriptionCard__ProductMsgDecription--info'
                            key={ index }
                          >
                            { msgItem.message }
                          </div>

                        )
                      }
                    } )
                  )
                }
              } )() }
            </div>
          </div>
        </div>
      </div>
    );
  }
}

ProductDescriptionCard.propTypes = propTypes;

export default ProductDescriptionCard;
