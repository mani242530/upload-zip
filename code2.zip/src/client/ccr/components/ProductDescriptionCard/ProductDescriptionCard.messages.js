/*
 * ProductDescriptionCard Messages
 *
 * This contains all the text for the ProductDescriptionCard component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  variantInfo: {
    id: 'i18n.ProductDescriptionCard.variantInfo',
    defaultMessage: '{variantName}: {variantValue}'
  },
  productSize: {
    id: 'i18n.ProductDescriptionCard.productSize',
    defaultMessage: 'Size: '
  },
  quantity: {
    id: 'i18n.ProductDescriptionCard.quantity',
    defaultMessage: 'Qty: '
  }

} );
