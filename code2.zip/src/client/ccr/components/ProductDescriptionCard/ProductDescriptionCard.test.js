import React from 'react';
import ReactDOM from 'react-dom';
import ProductDescriptionCard from './ProductDescriptionCard';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import data from 'ccr/components/CartPage/CartPageData';
import messages from './ProductDescriptionCard.messages';


describe( '<ProductDescriptionCard />', () => {
  let component;
  let MockData={
    'imageURL':'http://s7d5.scene7.com/is/image/Ulta/2257743?$sm$',
    'brandName':'Nars',
    'displayName':'Balance N Brighten',
    'color':'yellow',
    'messageDesc':'Promotion ended',
    'size':'10'
  }
  let props={
    'imageURL':'http://s7d5.scene7.com/is/image/Ulta/2257743?$sm$',
    'brandName':'Nars',
    'displayName':'Balance N Brighten',
    'variant':{ 'color':'yellow' },
    'messageDesc':'Promotion ended'
  }
  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <ProductDescriptionCard
        imageURL='http://s7d5.scene7.com/is/image/Ulta/2257743?$sm$'
        brandName='Nars'
        displayName='Balance N Brighten'
        color='yellow'
        messageDesc='Promotion ended'
        variant={ '' }
        hazmatMsg='cannot be shipped'
        excludedFromCouponItem='true'
        { ...props }
      />
    );

    expect( component.find( 'ProductDescriptionCard' ).length ).toBe( 1 );
  } );

  it( 'renders correct name for the brand name', () => {
    expect( component.find( '.ProductDescriptionCard__ProdContainer .ProductDescriptionCard__ProductDescription--info .ProductDescriptionCard__ProdName' ).text() ).toBe( MockData.brandName );
  } );

  it( 'renders correct name for the display name', () => {
    expect( component.find( '.ProductDescriptionCard__ProdContainer .ProductDescriptionCard__ProductDescription--info .ProductDescriptionCard__ProductDescriptionText' ).text() ).toBe( MockData.displayName );
  } );

  it( 'renders correct variant for the variant name', () => {
    let variantName ='color';
    let variantValue = 'yellow';
    expect( component.find( '.ProductDescriptionCard__ProdContainer .ProductDescriptionCard__ProductDescription--info .ProductDescriptionCard__ProductSize' ).text() ).toBe( variantName+': '+variantValue );
  } );


  it( 'renders only if color is available for the product', () => {
    component = mountWithIntl(
      <ProductDescriptionCard
        imageURL='http://s7d5.scene7.com/is/image/Ulta/2257743?$sm$'
        brandName='Nars'
        displayName='Balance N Brighten'
        messageDesc='Promotion ended'
        hazmatMsg='cannot be shipped'
      />
    );
    expect( component.find( '.ProductDescriptionCard__ProdContainer .ProductDescriptionCard__ProductDescription--info .ProductDescriptionCard__ProductColor' ).length ).toBe( 0 );
  } );
  it( 'renders only if color is available for the product', () => {
    component = mountWithIntl(
      <ProductDescriptionCard
        imageURL='http://s7d5.scene7.com/is/image/Ulta/2257743?$sm$'
        brandName='Nars'
        displayName='Balance N Brighten'
        messageDesc='Promotion ended'
        excludedFromCouponItem='true'
      />
    );
    expect( component.find( '.ProductDescriptionCard__ProdContainer .ProductDescriptionCard__ProductDescription--info .ProductDescriptionCard__ProductSize' ).length ).toBe( 0 );
  } );
  const messages={
    items:[
      {
        type:'Info',
        message: 'Promotion ended'
      }
    ]
  }
  it( 'doesnot render the error messages', () => {
    component = mountWithIntl(
      <ProductDescriptionCard
        imageURL='http://s7d5.scene7.com/is/image/Ulta/2257743?$sm$'
        brandName='Nars'
        displayName='Balance N Brighten'
        messages={ messages }
      />
    );
    expect( component.find( '.ProductDescriptionCard__alertMessage' ).length ).toBe( 0 );
  } );

  it( 'renders correct reason for removing the item from cart', () => {
    expect( component.find( '.ProductDescriptionCard__ProdContainer .ProductDescriptionCard__ProductDescription--info .ProductDescriptionCard__ProductMsgDecription' ).text() ).toBe( MockData.messageDesc );
  } );

  let componentFromCheckout = mountWithIntl(
    <ProductDescriptionCard
      imageURL='http://s7d5.scene7.com/is/image/Ulta/2257743?$sm$'
      brandName='Nars'
      displayName='Balance N Brighten'
      color='yellow'
      messageDesc='Promotion ended'
      size='10'
      hazmatMsg='cannot be shipped'
      excludedFromCouponItem='true'
      pageName='/checkout'
      quantity={ 9 }
      isSVG={ false }
    />
  );

  it( 'renders without crashing for checkout page', () => {
    expect( componentFromCheckout.find( 'ProductDescriptionCard' ).length ).toBe( 1 );
  } );

  it( 'renders quantity in the card component', () => {
    expect( componentFromCheckout.find( '.ProductDescriptionCard__ProductDescription--info .forCheckout' ).length ).toBe( 1 );
  } );

  it( 'should add alt text to <img> when isSVG is passed in props as false', () => {
    const variantName ='color';
    const variantValue = 'yellow';
    const component1 = mountWithIntl(
      <ProductDescriptionCard
        isSVG={ false }
        { ...props }
      />
    );
    expect( component1.find( 'ProductDescriptionCard .Anchor .Image .Loader__content' ).find( 'img' ).props().alt ).toBe( `${props.brandName} ${props.displayName} ${variantName}: ${variantValue}` );
  } );

  it( 'should add alt text to <img> even when no variants', () => {
    const props = {
      'imageURL':'http://s7d5.scene7.com/is/image/Ulta/2257743?$sm$',
      'brandName':'Nars',
      'displayName':'Balance N Brighten',
      'messageDesc':'Promotion ended'
    }
    const component2 = mountWithIntl(
      <ProductDescriptionCard
        isSVG={ false }
        { ...props }
      />
    );
    expect( component2.find( 'ProductDescriptionCard .Anchor .Image .Loader__content' ).find( 'img' ).props().alt ).toBe( `${props.brandName} ${props.displayName} ` );
  } );

} );
