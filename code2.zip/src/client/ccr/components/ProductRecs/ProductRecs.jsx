/**
 * ProductRecs
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './ProductRecs.css';
import classNames from 'classnames';
import DesktopProductsList from 'shared/components/ProductsLists/desktop/DesktopProductsList/DesktopProductsList';
import ProductsList from 'shared/components/ProductsLists/mobile/ProductsList/ProductsList';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './ProductRecs.messages';
import {
  isMobileDevice
} from 'utils/DeviceDetection/deviceDetection';
import Gutter from 'shared/components/Gutter/Gutter';
import Divider from 'shared/components/Divider/Divider';
import Right from 'shared/components/Icons/chevron_right';
import Left from 'shared/components/Icons/chevronleft';
import isEmpty from 'lodash/isEmpty'

const propTypes = {
  productRecList: PropTypes.object.isRequired
}

export const ArrowChevron = ( props ) => {
  return (
    <div className='ArrowChevron'>
      <div
        onClick={ props.onClick }
        className={ props.className }
      >
        { props.children }
      </div>
    </div>
  )
}

/**
 * Class
 * @extends React.Component
 */
class ProductRecs extends Component{

  /**
   * Renders the ProductRecs component
   */
  render(){
    const {
      productRecList,
      showOnlyListPrice,
      productCount
    } = this.props;

    const defaultProductCount = this.props.isMobileDevice ? 2 :3; // 2 this is the default value for prodrecs for mobile and 3 for desktop
    const slidesToShow_value = productCount || defaultProductCount; // if the count is passed as a prop, it will be used over the default values

    return (
      <div className='ProductRecs'>

        {
          ( () =>{
            if( productRecList !== undefined ){
              return productRecList.recommendedProducts.productItems.map( ( section, index ) =>{

                if( !isEmpty( section.productItemsList ) ){

                  // sending shopAllLink as an empty object is essential here as
                  // <ProductsList /> component will break if it does not exist
                  const recordList = {
                    records: section.productItemsList,
                    shopAllLink: {}
                  }

                  let productProps = {
                    productData: this.props.isMobileDevice ? recordList : section.productItemsList,
                    settings: {
                      dots: false,
                      infinite: false,
                      speed: 500,
                      slidesToShow: slidesToShow_value,
                      slidesToScroll: 1,
                      arrows: ( section.productItemsList.length > slidesToShow_value ),
                      swipe: ( section.productItemsList.length > slidesToShow_value ),
                      nextArrow: <ArrowChevron> <Right/> </ArrowChevron>,
                      prevArrow: <ArrowChevron> <Left/> </ArrowChevron>
                    },
                    section: section.strategyMesssage,
                    showTitle: true,
                    showOnlyListPrice: ( showOnlyListPrice ) || false
                  }

                  return (

                    <div
                      key={ index }
                      className={
                        classNames( {
                          'ProductRecs__Container': true,
                          'ProductRecs__Container--secondary': index > 0
                        } )
                      }
                    >

                      { ( () =>{

                        return (
                          <div className='ProductRecs__Header Gutter'>
                            <h3>
                              { section.strategyMesssage }
                            </h3>
                            <Divider dividerType={ 'gray' }/>
                          </div>
                        )

                      } )() }
                      { ( () =>{

                        if( this.props.isMobileDevice ){
                          return (
                            <ProductsList
                              { ...productProps }
                              displayShopall={ false }
                            />
                          )
                        }
                        else {
                          return ( <DesktopProductsList { ...productProps } /> )
                        }

                      } )() }

                    </div>
                  )
                }
              } )
            }
          } )()
        }

      </div>
    );
  }
}

ProductRecs.propTypes = propTypes;

export default ProductRecs;
