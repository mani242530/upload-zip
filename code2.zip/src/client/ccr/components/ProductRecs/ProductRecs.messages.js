/*
 * ProductRecs Messages
 *
 * This contains all the text for the ProductRecs component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.ProductRecs.header',
    defaultMessage: 'You Might Also Like...'
  }
} );
