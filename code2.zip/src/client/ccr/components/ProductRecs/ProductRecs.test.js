import React from 'react';
import ReactDOM from 'react-dom';
import ProductRecs from './ProductRecs';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
import ProductsListData from 'ccr/components/CartPage/ProductRecommendationsData.json';
import messages from './ProductRecs.messages';
import { IntlProvider } from 'react-intl';
import { Provider } from 'react-redux';


describe( '<ProductRecs />', () => {
  let component;
  let props = {
    productRecList: {}
  };

  props.productRecList = ProductsListData;
  props.productRecHeaderTitle = messages.header.defaultMessage;
  it( 'renders without crashing', () => {

    component = mountProductList( props );
    expect( component.find( 'ProductRecs' ).length ).toBe( 1 );
  } );

  it( 'Should contain ProductsList component', () => {
    expect( component.find( 'ProductRecs' ).find( 'DesktopProductsList' ).length ).toBe( 2 );
  } );

  it( 'Should contain ProductsList Header text', () => {
    expect( component.find( '.ProductRecs__Header' ).length ).toBe( 2 );
  } );

  it( 'should display 3 products in a list for desktop by default', () => {
    expect( component.find( 'DesktopProductsList' ).at( 0 ).props().settings.slidesToShow ).toBe( 3 );
  } );

  it( 'should display 2 products in a list for mobile by default', () => {
    props.isMobileDevice = true;
    const componentMobile = mountProductList( props );
    expect( componentMobile.find( 'ProductsList' ).at( 0 ).props().settings.slidesToShow ).toBe( 2 );
  } );

  let component1;
  let props1;
  it( 'should render the productrecs container when the productitems list is not empty', () => {
    props1={
      'productCount':4,
      'productRecList': {
        'recommendedProducts':{
          'errorMessage':null,
          'errorCode':null,
          'pageId':null,
          'productItems':[
            {
              'strategyMesssage':'People Also Viewed',
              'productItemsList':[
                {
                  'clickURL':'http://integration.richrelevance.com/rrserver/apiclick?a=f42e6dcbc17086cd&cak=17a88ce787db5c27&ct=http%3A%2F%2Fda3.ulta.com%2Fguilty-intense-pour-homme-eau-de-toilette-spray%3FproductId%3DxlsImpprod3820319&vg=07883b00-3366-452f-ff2b-55580dcfd51a&stid=80&pti=3&pa=7589&pos=1&p=xlsImpprod3820319&channelId=17a88ce787db5c27&s=640609053509381376&u=640609053509381376',
                  'skuImageUrl':null,
                  'childSkuId':null,
                  'numReviews':'33',
                  'rating':null,
                  'productBrandName':null,
                  'isGwp':0,
                  'adbugMessage':null,
                  'showListRange':true,
                  'lowRangeListPrice':78,
                  'reviewCount':null,
                  'showListAndSaleRange':false,
                  'highRangeSalePrice':0,
                  'onSale':false,
                  'multiSku':true,
                  'productImageUrl':'//images.ulta.com/is/image/Ulta/2238352?$md$',
                  'prodParentCatId':'cat100032',
                  'brandName':'Gucci',
                  'activeSkusCount':2,
                  'productId':'xlsImpprod3820319',
                  'dfltSkuId':'2238351',
                  'salePrice':0,
                  'parentCatDispName':'Cologne',
                  'badges':[],
                  'badge':null,
                  'powerReviewRating':'4.5',
                  'productDisplayName':'Guilty Intense Pour Homme Eau de Toilette Spray',
                  'lowRangeSalePrice':0,
                  'skuDisplayName':null,
                  'ratingDecimal':null,
                  'highRangeListPrice':97,
                  'listPrice':78,
                  'promotionDO':null,
                  'varaintDispName':'Sizes'
                }
              ],
              'placmentName':'cart_page.horizontal'
            }
          ],
          'productIds':null,
          'success':true,
          'trackingId':null
        }
      }
    }
    component1 = mountProductList( props1 );
    expect( component1.find( '.ProductRecs__Container' ).length ).toBe( 1 );
  } )

  it( 'should display products equal to the value of productCount property passed to the component', () => {
    expect( component1.find( 'DesktopProductsList' ).props().settings.slidesToShow ).toBe( props1.productCount );
  } )

  it( 'should not render the productrecs container when the productitems list is empty', () => {
    let props2={
      'productRecList':{
        'recommendedProducts':{
          '@class':'com.ulta.dataobject.UltaRecommendedProductsDO',
          'errorCode':null,
          'errorMessage':null,
          'pageId':null,
          'productIds':null,
          'productItems':[
            {
              '@class':'com.ulta.dataobject.PlacementResponseDO',
              'placmentName':'cart_page.horizontal',
              'productItemsList':[],
              'strategyMesssage':'People Also Viewed'
            }
          ],
          'success':true,
          'trackingId':null
        }
      }
    }
    const component2 = mountProductList( props2 );
    expect( component2.find( '.ProductRecs__Container' ).length ).toBe( 0 );
  } )
} );

function mountProductList( props ){
  return mountWithIntl( <ProductRecs { ...props } /> );
}
