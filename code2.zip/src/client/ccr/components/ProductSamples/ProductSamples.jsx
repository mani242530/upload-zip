/**
 * ProductSamples
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './ProductSamples.css';
import { Collapse } from 'react-bootstrap';
import ordersSVG from 'shared/components/Icons/orders';
import { formatMessage } from 'shared/components/Global/Global';
import MixedMenuButton from 'shared/components/MixedMenuButton/MixedMenuButton';
import messages from './ProductSamples.messages';
import SamplesList from 'ccr/components/SamplesList/SamplesList';
import classNames from 'classnames';
import Button from 'shared/components/Button/Button';
import { find, isEmpty, replace, has } from 'lodash';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';

const propTypes = {
  samplesListItems: PropTypes.array.isRequired,
  sampleSelectionDefaultMessage: PropTypes.string
};


/**
 * Class
 * @extends React.Component
 */
class ProductSamples extends Component{

  /**
   * Create a ProductSamples
   */
  constructor( props ){
    super( props );
    this.setSelectedSample = this.setSelectedSample.bind( this );
  }

  /**
   * Renders the ProductSamples component
   */

  componentDidMount(){
    try {
      {
        ( () => {
          this.props.samplesListItems.map( ( samples, index ) => {
            {
              if( samples.selected ){

                this.props.setProductSample( samples.catalogRefId )
              }
            }
          } )
        } )()
      }
    }
    catch ( exception ){

    }
  }

  componentDidUpdate( prevProps ){
    if( prevProps.samplesListItems !== this.props.samplesListItems ){
      this.props.samplesListItems.map( ( samples, index ) => {
        {
          if( samples.selected ){
            this.props.setProductSample( samples.catalogRefId )
          }
        }
      } )
    }
  }

  setSelectedSample( catalogRefId ){
    if( catalogRefId!=='-1' ){
      this.props.selectProductSampleService( catalogRefId, 1, this.props.history );
    }
    else {
      this.props.removeProductSampleService( this.props.history );
    }
    this.props.setProductSample( catalogRefId );
  }


  render(){
    const {
      setCartRightPanelCollapse,
      appliedCouponSummary,
      cartRightPanelCollapse
    } = this.props;

    return (
      ( () => {
        return (
          <div className='ProductSamples'>
            <div className={ classNames(
              { 'ProductSamples__selectedMixedNavDetailsLink': ( this.props.productSampleCatalogID !== '-1' ) }
            ) }
            >
              <MixedMenuButton
                label={ formatMessage( messages.sampleTitle ) }
                details={ this.props.sampleSelectionDefaultMessage }
                pointerType='collapse'
                onClick={ e => {
                  e.preventDefault();
                  setCartRightPanelCollapse( 'samples' );
                } }
                pointerMinus={ cartRightPanelCollapse.samples }
              />
              <Collapse in={ cartRightPanelCollapse.samples }>
                <div className='ProductSamples__collapse'>
                  <div
                    className='collapseElements'
                    role='radiogroup'
                  >
                    { ( () =>{
                      return (
                        this.props.samplesListItems.map( ( samples, index ) => {
                          {
                            if( samples.selected && ! isEmpty( samples.shippingRestriction )
                              && this.props.cartPageData.showShippingRestrictionMsg ){
                              return (
                                <ResponseMessages
                                  message={ samples.shippingRestriction }
                                  messageType='warning-alert'
                                />
                              )
                            }
                          }
                        } )
                      )
                    } )() }

                    { ( () => {
                      {
                        return (
                          <div
                            className='leftSample'
                            key={ '-1' }
                            onClick={ e => {
                              this.setSelectedSample( '-1' );
                            } }
                            role='radio'
                            aria-checked={ this.props.productSampleCatalogID === '-1' }
                            tabIndex='0'
                          >
                            <SamplesList
                              id={ '-1' }
                              sampleName={ formatMessage( messages.noneSampleLabel ) }
                              selectedButton={ this.props.productSampleCatalogID }
                            />
                          </div>
                        )
                      }
                    } )() }
                    { ( () => {
                      return ( this.props.samplesListItems.map( ( sample, index ) => {
                        return (
                          <div
                            className={
                              classNames( {
                                'leftSample': ( ( index % 2 ) !== 0 ),
                                'rightSample': ( ( index % 2 ) === 0 )

                              } )
                            }
                            key={ index }
                            id={ `${ sample.catalogRefId }_${ index }` }
                            onClick={ e => {
                              this.setSelectedSample( sample.catalogRefId );
                            } }
                            role='radio'
                            aria-checked={ sample.catalogRefId === this.props.productSampleCatalogID }
                            tabIndex='0'
                          >
                            <SamplesList
                              id={ sample.catalogRefId }
                              sampleName={ sample.sampleDesc }
                              selectedButton={ this.props.productSampleCatalogID }
                            />
                          </div>
                        )
                      } ) )
                    } )() }
                  </div>
                </div>
              </Collapse>
            </div>
          </div>
        )
      } )()

    );

  }

  catch( e ){
  }


}

ProductSamples.propTypes = propTypes;

export default ProductSamples;
