/*
 * ProductSamples Messages
 *
 * This contains all the text for the ProductSamples component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  sampleTitle: {
    id: 'i18n.ProductSamples.sampleTitle',
    defaultMessage: 'Pick One Free Sample'
  },
  chooseSample: {
    id: 'i18n.ProductSamples.chooseSample',
    defaultMessage: 'Choose Your Free Sample'
  },
  giftOptionMessage: {
    id: 'i18n.ProductSamples.giftOptionMessage',
    defaultMessage: 'Add Gift Box & A Personal Message'
  },
  coupon: {
    id: 'i18n.ProductSamples.coupon',
    defaultMessage: 'Coupon'
  },
  couponMessage: {
    id: 'i18n.ProductSamples.couponMessage',
    defaultMessage: '20% Off Any One Qualifying Item'
  },
  noneSampleLabel: {
    id: 'i18n.ProductSamples.noneSampleLabel',
    defaultMessage: 'None'
  },
  giftBoxReceiptMessage: {
    id: 'i18n.ProductSamples.giftBoxReceiptMessage',
    defaultMessage: 'Gift Receipt Included'
  }

} );
