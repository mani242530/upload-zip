import React from 'react';
import ReactDOM from 'react-dom';
import ProductSamples from './ProductSamples';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import messages from './ProductSamples.messages';

describe( '<ProductSamples />', () => {
  let component;
  let props = {
    cartRightPanelCollapse: {},
    removeProductSampleService: jest.fn(),
    selectProductSampleService: jest.fn(),
    samplesListItems: [
      {
        'catalogRefId': '2252998',
        'sampleDesc': 'Fragrance',
        'selected': false
      },
      {
        'catalogRefId': '2252999',
        'sampleDesc': 'Skincare',
        'selected': false
      },
      {
        'catalogRefId': '2253000',
        'sampleDesc': 'Variety',
        'selected': false
      }
    ],
    sampleSelectionDefaultMessage: 'Choose Your Free Sample',
    setProductSample: jest.fn(),
    productSampleCatalogID: '-1'
  }

  const store = configureStore( {}, CONFIG );
  it( 'renders without crashing', () => {

    component = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props }/>
      </Provider>
    );
    expect( component.find( 'ProductSamples' ).length ).toBe( 1 );
  } );
  it( 'Should contain 3 MixedMenuButton components', () => {
    expect( component.find( 'ProductSamples MixedMenuButton' ).length ).toBe( 1 );
  } );
  it( 'MixedMenuButton component Should contain MixedMenuButton label', () => {
    expect( component.find( 'ProductSamples MixedMenuButton' ).at( 0 ).props().label ).toBe( messages.sampleTitle.defaultMessage );
  } );
  it( 'collapseElements should contain the role of radiogroup', () => {
    expect( component.find( '.collapseElements' ).props()['role'] ).toBe( 'radiogroup' );
  } );
  it( 'leftSample should contain the role of radio', () => {
    expect( component.find( '.leftSample' ).at( 0 ).props()['role'] ).toBe( 'radio' );
  } );
  it( 'rightSample should contain the role of radio', () => {
    expect( component.find( '.rightSample' ).at( 0 ).props()['role'] ).toBe( 'radio' );
  } );
  it( 'leftSample should have the prop aria-checked as true', () => {
    expect( component.find( '.leftSample' ).at( 0 ).props()['aria-checked'] ).toBe( true );
  } );
  it( 'rightSample should have the prop aria-checked as false', () => {
    expect( component.find( '.rightSample' ).at( 0 ).props()['aria-checked'] ).toBe( false );
  } );

  it( 'MixedMenuButton component Should contain MixedMenuButton message', () => {

    component = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props }/>
      </Provider>
    );
    expect( component.find( 'ProductSamples MixedMenuButton' ).props().details ).toBe( props.sampleSelectionDefaultMessage );
  } );

  it( 'Should render ResponseMessages if showShippingRestrictionMsg is true and selected sample have shipping restriction message', () => {
    const props1 = {
      cartRightPanelCollapse: {},
      removeProductSampleService: jest.fn(),
      selectProductSampleService: jest.fn(),
      cartPageData:{
        showShippingRestrictionMsg:true
      },
      samplesListItems: [
        {
          'catalogRefId': '2252998',
          'sampleDesc': 'Fragrance',
          'selected': true,
          'shippingRestriction':'Cannot ship to your selected address. Please select a different free sample'
        },
        {
          'catalogRefId': '2252999',
          'sampleDesc': 'Skincare',
          'selected': false
        },
        {
          'catalogRefId': '2253000',
          'sampleDesc': 'Variety',
          'selected': false
        }
      ],
      sampleSelectionDefaultMessage: 'Choose Your Free Sample',
      setProductSample: jest.fn(),
      productSampleCatalogID: '-1'
    }

    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props1 }/>
      </Provider>
    );
    expect( component1.find( '.ResponseMessages__message.ResponseMessages__message--warning-alert' ).length ).toBe( 1 );
  } );
  it( 'Should NOT render ResponseMessages if showShippingRestrictionMsg is false', () => {

    component = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props }
          cartPageData={ { showShippingRestrictionMsg: false } }
        />
      </Provider>
    );
    expect( component.find( '.ResponseMessages__message.ResponseMessages__message--warning-alert' ).length ).toBe( 0 );
  } );

} );

describe( 'MixedMenuButton Component', () => {
  let component1;
  let props = {
    selectProductSampleService: jest.fn(),
    removeProductSampleService: jest.fn(),
    cartRightPanelCollapse: {},
    samplesListItems: [
      {
        'catalogRefId': '2252998',
        'sampleDesc': 'Fragrance',
        'selected': false
      },
      {
        'catalogRefId': '2252999',
        'sampleDesc': 'Skincare',
        'selected': false
      },
      {
        'catalogRefId': '2253000',
        'sampleDesc': 'Variety',
        'selected': false
      }
    ],
    sampleSelectionDefaultMessage: 'Choose Your Free Sample',
    setProductSample: jest.fn(),
    productSampleCatalogID: '-1'
  }
  const store = configureStore( {}, CONFIG );

  component1 = mountWithIntl(
    <Provider store={ store }>
      <ProductSamples { ...props }/>
    </Provider>
  );
  it( 'MixedMenuButton components Should contain  leftSample and rightSample divs', () => {
    expect( component1.find( 'ProductSamples Collapse .ProductSamples__collapse .leftSample' ).length ).toBe( 2 );
    expect( component1.find( 'ProductSamples Collapse .ProductSamples__collapse .rightSample' ).length ).toBe( 2 );

  } );

  it( 'MixedMenuButton components Should contain SampleList component in leftSample and rightSample divs', () => {
    expect( component1.find( 'ProductSamples Collapse .ProductSamples__collapse .leftSample SamplesList' ).length ).toBe( 2 );
    expect( component1.find( 'ProductSamples Collapse .ProductSamples__collapse .rightSample SamplesList' ).length ).toBe( 2 );
  } );

  it( ' `selectedButton` prop of SamplesList should be changed when there is a click operation on the samples in the leftSample div', () => {
    expect( component1.find( 'ProductSamples Collapse .ProductSamples__collapse .leftSample' ).at( 0 ).simulate( 'click' ).find( 'SamplesList' ).props().selectedButton ).toBe( '-1' );
    let component2;
    let props1 = {
      cartRightPanelCollapse: {},
      selectProductSampleService: jest.fn(),
      removeProductSampleService: jest.fn(),
      samplesListItems: [
        {
          'catalogRefId': '2252998',
          'sampleDesc': 'Fragrance',
          'selected': false
        },
        {
          'catalogRefId': '2252999',
          'sampleDesc': 'Skincare',
          'selected': true
        },
        {
          'catalogRefId': '2253000',
          'sampleDesc': 'Variety',
          'selected': false
        }
      ],
      sampleSelectionDefaultMessage: 'Skincare',
      setProductSample: jest.fn(),
      productSampleCatalogID: '2252999'
    }
    const store = configureStore( {}, CONFIG );

    component2 = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props1 }/>
      </Provider>
    );
    expect( component2.find( 'ProductSamples Collapse .ProductSamples__collapse .leftSample' ).at( 1 ).simulate( 'click' ).find( 'SamplesList' ).props().selectedButton ).toBe( '2252999' );
  } );

  it( ' Should contain ProductSamples__selectedMixedNavDetailsLink function if the sampleSelected state variable is true', () => {
    let setSelectedSample = jest.fn();

    let props = {
      removeProductSampleService: jest.fn(),
      selectProductSampleService: jest.fn(),
      cartRightPanelCollapse: {},
      samplesListItems: [
        {
          'catalogRefId': '2252998',
          'sampleDesc': 'Fragrance',
          'selected': false
        },
        {
          'catalogRefId': '2252999',
          'sampleDesc': 'Skincare',
          'selected': true
        },
        {
          'catalogRefId': '2253000',
          'sampleDesc': 'Variety',
          'selected': false
        }
      ],
      sampleSelectionDefaultMessage: 'Skincare',
      setProductSample: jest.fn(),
      productSampleCatalogID: '2252999'
    }
    component1 = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props }/>
      </Provider>
    );

    component1.find( 'ProductSamples Collapse .ProductSamples__collapse .leftSample' ).at( 1 ).simulate( 'click' );
    expect( component1.find( '.ProductSamples__selectedMixedNavDetailsLink' ).length ).toBe( 1 );
  } );

  it( ' Should not contain ProductSamples__selectedMixedNavDetailsLink class if the sampleSelected state variable is false', () => {
    let setSelectedSample = jest.fn();
    let props = {
      removeProductSampleService: jest.fn(),
      selectProductSampleService: jest.fn(),
      cartRightPanelCollapse: {},
      samplesListItems: [
        {
          'catalogRefId': '2252998',
          'sampleDesc': 'Fragrance',
          'selected': false
        },
        {
          'catalogRefId': '2252999',
          'sampleDesc': 'Skincare',
          'selected': false
        },
        {
          'catalogRefId': '2253000',
          'sampleDesc': 'Variety',
          'selected': false
        }
      ],
      sampleSelectionDefaultMessage: 'Choose Your Free Sample',
      setProductSample: jest.fn(),
      productSampleCatalogID: '-1'
    }
    component1 = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props }/>
      </Provider>
    );
    expect( component1.find( '.ProductSamples__selectedMixedNavDetailsLink' ).length ).toBe( 0 );
  } );

  it( ' Should change the `detail`prop of MixedMenuButton to `Fragrance` if we perform click on `Fragrance` sample', () => {
    let setSelectedSample = jest.fn();
    let props = {
      removeProductSampleService: jest.fn(),
      selectProductSampleService: jest.fn(),
      cartRightPanelCollapse: {},
      samplesListItems: [
        {
          'catalogRefId': '2252998',
          'sampleDesc': 'Fragrance',
          'selected': true
        },
        {
          'catalogRefId': '2252999',
          'sampleDesc': 'Skincare',
          'selected': false
        },
        {
          'catalogRefId': '2253000',
          'sampleDesc': 'Variety',
          'selected': false
        }
      ],
      sampleSelectionDefaultMessage: 'Fragrance',
      setProductSample: jest.fn(),
      productSampleCatalogID: '-1'
    }
    component1 = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props }/>
      </Provider>
    );

    component1.find( 'ProductSamples Collapse .ProductSamples__collapse .rightSample' ).at( 0 ).simulate( 'click' );
    expect( component1.find( 'MixedMenuButton' ).at( 0 ).props().details ).toBe( props.samplesListItems[ 0 ].sampleDesc );
  } );

  it( ' Should change the `detail`prop of MixedMenuButton to `Variety` if we perform click on `Variety` sample', () => {
    let setSelectedSample = jest.fn();
    let props = {
      removeProductSampleService: jest.fn(),
      selectProductSampleService: jest.fn(),
      cartRightPanelCollapse: {},
      samplesListItems: [
        {
          'catalogRefId': '2252998',
          'sampleDesc': 'Fragrance',
          'selected': false
        },
        {
          'catalogRefId': '2252999',
          'sampleDesc': 'Skincare',
          'selected': false
        },
        {
          'catalogRefId': '2253000',
          'sampleDesc': 'Variety',
          'selected': true
        }
      ],
      sampleSelectionDefaultMessage: 'Variety',
      setProductSample: jest.fn(),
      productSampleCatalogID: '-1'
    }
    component1 = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props }/>
      </Provider>
    );

    component1.find( 'ProductSamples Collapse .ProductSamples__collapse .collapseElements .rightSample' ).at( 1 ).simulate( 'click' );
    expect( component1.find( 'MixedMenuButton' ).props().details ).toBe( props.samplesListItems[ 2 ].sampleDesc );
  } );

  it( ' Should change the `detail`prop of MixedMenuButton to `Choose Your Free Sample` if we perform click on `None` sample', () => {
    let setSelectedSample = jest.fn();
    let props = {
      removeProductSampleService: jest.fn(),
      selectProductSampleService: jest.fn(),
      cartRightPanelCollapse: {},
      samplesListItems: [
        {
          'catalogRefId': '2252998',
          'sampleDesc': 'Fragrance',
          'selected': false
        },
        {
          'catalogRefId': '2252999',
          'sampleDesc': 'Skincare',
          'selected': false
        },
        {
          'catalogRefId': '2253000',
          'sampleDesc': 'Variety',
          'selected': false
        }
      ],
      sampleSelectionDefaultMessage: 'Choose Your Free Sample',
      setProductSample: jest.fn(),
      productSampleCatalogID: '-1'
    }
    component1 = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props }/>
      </Provider>
    );
    component1.find( 'ProductSamples Collapse .ProductSamples__collapse .leftSample' ).at( 0 ).simulate( 'click' );
    expect( component1.find( 'MixedMenuButton' ).at( 0 ).props().details ).toBe( messages.chooseSample.defaultMessage );
  } );

  it( ' Should change the `detail`prop of MixedMenuButton to `skincare` if we perform click on `skincare` sample', () => {
    let setSelectedSample = jest.fn();
    props = {
      removeProductSampleService: jest.fn(),
      selectProductSampleService: jest.fn(),
      cartRightPanelCollapse: {},
      samplesListItems: [
        {
          'catalogRefId': '2252998',
          'sampleDesc': 'Fragrance',
          'selected': false
        },
        {
          'catalogRefId': '2252999',
          'sampleDesc': 'Skincare',
          'selected': true
        },
        {
          'catalogRefId': '2253000',
          'sampleDesc': 'Variety',
          'selected': false
        }
      ],
      sampleSelectionDefaultMessage: 'Skincare',
      setProductSample: jest.fn(),
      productSampleCatalogID: '2252999'
    }
    component1 = mountWithIntl(
      <Provider store={ store }>
        <ProductSamples { ...props }/>
      </Provider>
    );

    component1.find( 'ProductSamples Collapse .ProductSamples__collapse .leftSample' ).at( 1 ).simulate( 'click' );
    expect( component1.find( 'MixedMenuButton' ).at( 0 ).props().details ).toBe( props.samplesListItems[ 1 ].sampleDesc );
  } );

  it( ' Sample Id should not be equal to Button Id ', () => {
    const node1=component1.find( 'Button' ).at( 1 ).props().id;
    const node2=component1.find( 'ProductSamples Collapse .ProductSamples__collapse .leftSample SamplesList' ).at( 1 ).props().id;
    expect( node1 ).not.toBe( node2 );
  } );

} );
