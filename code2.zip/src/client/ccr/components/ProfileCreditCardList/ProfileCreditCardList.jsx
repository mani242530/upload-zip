/**
 * ProfileCreditCardList
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { reduxForm } from 'redux-form';
import './ProfileCreditCardList.css';

import { formatMessage } from 'shared/components/Global/Global';
import { connect } from 'react-redux';
import messages from './ProfileCreditCardList.messages';
import RadioButton from 'shared/components/RadioButton/RadioButton';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';
import Button from 'shared/components/Button/Button';
import Exclamation from 'shared/components/Icons/exclamationcircle';
import SVG from 'shared/components/Icons/PlusCircle';
import PayPalSVG from 'shared/components/Icons/paypal';
import AmexSVG from 'shared/components/Icons/americanexpress';
import DiscoverSVG from 'shared/components/Icons/discover';
import MasterCardSVG from 'shared/components/Icons/mastercard';
import VisaSVG from 'shared/components/Icons/visa';
import URCCSVG from 'shared/components/Icons/ultamaterewardscreditcard';
import URMCSVG from 'shared/components/Icons/ultamaterewardsmastercard';
import PaypalCheckoutButton from 'ccr/components/PaypalCheckoutButton/PaypalCheckoutButton';
import isUndefined from 'lodash/isUndefined';
import isEmpty from 'lodash/isEmpty';
import has from 'lodash/has';
import 'shared/components/Gutter/Gutter.css';
import classNames from 'classnames';

const propTypes = {
  handleChangeCreditCard: PropTypes.func,
  handleAddCreditCard: PropTypes.func,
  handleEditCreditCard: PropTypes.func,
  handleChangePaypalAccount: PropTypes.func,
  getProfileCreditCardList: PropTypes.func,
  handleScrollView: PropTypes.func,
  setTempPaymentCCVNumber: PropTypes.func,
  payPalClientToken: PropTypes.string,
  enableExpressPaypalCheckout: PropTypes.bool,
  getPaypalToken: PropTypes.func,
  applyPayment: PropTypes.func,
  cartSummary: PropTypes.object,
  paypalEnvironment: PropTypes.string,
  creditCardDetails: PropTypes.object,
  profileCreditCardList: PropTypes.object
}

/**
 * Class
 * @extends React.Component
 */
class ProfileCreditCardList extends Component{

  /**
   * Create a ProfileCreditCardList
   */
  constructor( props ){
    super( props );
    this.state = {
      updateCCObject: {}
    };

    this.changeCreditCard = this.changeCreditCard.bind( this );
    this.updateCreditCardValue = this.updateCreditCardValue.bind( this );
    this.submitUpdateCreditCardValue = this.submitUpdateCreditCardValue.bind( this );
    this.addNewCreditCard = this.addNewCreditCard.bind( this );
    this.onSuccessPaypalPayment = this.onSuccessPaypalPayment.bind( this );
  }

  savedCardsHeading = undefined;
  changeCreditCard( e ){
    e.preventDefault();
    if( this.props.handleChangeCreditCard ){
      this.props.handleChangeCreditCard( this.state.updateCCValue );
    }
  }

  addNewCreditCard( e ){
    e.preventDefault();
    if( this.props.handleAddCreditCard ){
      this.props.handleAddCreditCard( 'list' );
    }
  }

  componentDidMount(){
    this.savedCardsHeading.focus();
  }

  onSuccessPaypalPayment(){
    if( this.props.handleChangePaypalAccount ){
      this.props.handleChangePaypalAccount();
    }
    this.props.handleScrollView( 'checkoutPaymentHeader' );
  }

  editCreditCard( editCreditCardObj, e ){
    e.preventDefault();
    if( this.props.handleEditCreditCard ){
      this.props.handleEditCreditCard( editCreditCardObj );
    }
  }

  updateCreditCardValue( e, cardValue ){
    const {
      profileCreditCardList
    } = this.props;
    let paymentInfo = this.props.creditCardDetails.paymentInfo;
    let selectedCC = profileCreditCardList.profileCreditCards[cardValue].creditCard;

    this.setState( {
      updateCCValue: selectedCC
    } );
    this.props.setTempPaymentCCVNumber( '' );
    this.props.handleChangeCreditCard( selectedCC );
  }

  submitUpdateCreditCardValue( e ){
    if( this.props.handleChangeCreditCard && this.state.updateCCValue ){
      this.props.handleChangeCreditCard( this.state.updateCCValue );
    }
  }

  /**
   * Renders the ProfileCreditCardList component
   */
  render(){

    let paymentInfo = this.props.creditCardDetails.paymentInfo;
    const token = this.props.payPalClientToken;
    const enableExpressPaypalCheckout = this.props.enableExpressPaypalCheckout;
    const {
      profileCreditCardList,
      handleSubmit
    } = this.props;

    return (
      <div className='ProfileCreditCardList'>
        <h4
          tabIndex='-1'
          className='sr-only'
          ref={ ( el )=>{
            this.savedCardsHeading=el
          } }
        >
          { formatMessage( messages.savedCreditCards ) }
        </h4>
        <Divider dividerType={ 'gray' }/>
        { ( () =>{
          if( profileCreditCardList.profileCreditCards ){
            return (
              <form onSubmit={ handleSubmit( this.submitUpdateCreditCardValue ) }>
                <div className='ProfileCreditCardList__container'>
                  { ( () =>{
                    return ( profileCreditCardList.profileCreditCards ).map( ( profileCreditCard, index ) =>{
                      let creditCard = profileCreditCard.creditCard;
                      let boundEditClickEvent = this.editCreditCard.bind( this, creditCard );
                      let errorMsgHtml;
                      let creditCardIcon;
                      if( creditCard.creditCardType === 'Visa' ){
                        creditCardIcon = <VisaSVG/>
                      }
                      else if( creditCard.creditCardType === 'Mastercard' ){
                        creditCardIcon = <MasterCardSVG/>
                      }
                      else if( creditCard.creditCardType === 'Discover' ){
                        creditCardIcon = <DiscoverSVG/>
                      }
                      else if( creditCard.creditCardType === 'AmericanExpress' ){
                        creditCardIcon = <AmexSVG/>
                      }
                      else if( creditCard.creditCardType === 'Ultamate Rewards MasterCard' ){
                        creditCardIcon = <URMCSVG/>
                      }
                      else if( creditCard.creditCardType === 'Ultamate Rewards Credit Card' ){
                        creditCardIcon = <URCCSVG/>
                      }
                      if( profileCreditCard.messages && profileCreditCard.messages.length > 0 ){
                        errorMsgHtml =
                          ( <div className='PaymentInformation__errorMessages Gutter'>
                            { ( () =>{
                              return profileCreditCard.messages.map( ( message, index1 ) =>{
                                return (
                                  <div key={ index1 }>
                                    <Exclamation/> { message.messageDesc }
                                  </div>
                                );
                              } );
                            } )() }
                          </div> );
                      }
                      return (
                        <div
                          className='ProfileCreditCardList__container--section'
                          key={ index }
                        >
                          { errorMsgHtml }
                          <div className='ProfileCreditCardList__container--cell Gutter'>
                            <div onClick={ creditCard.contactInfo !== null ? ( e ) =>{
                              this.updateCreditCardValue( e, index )
                            } : '' }
                            >
                              <RadioButton
                                id={ creditCard.nickName + '-' + index }
                                name='changeCreditCardData'
                                value={ index }
                                isChecked={ creditCard.nickName === paymentInfo.nickName }
                                onChange={ creditCard.contactInfo !== null ? ( e ) =>{
                                  this.updateCreditCardValue( e, index )
                                } : '' }
                                isDisabled={ creditCard.contactInfo === null }

                              >
                                <div className='ProfileCreditCardList__Item--carddetails'>
                                  <div className='ProfileCreditCardList__Item--bold'>
                                    <span>{ creditCard.creditCardType }</span>
                                    { ( () =>{
                                      if( creditCard.isPrimary ){
                                        return (
                                          <span> (Primary)</span>
                                        );
                                      }
                                    } )() }
                                  </div>
                                  <div
                                    className='ProfileCreditCardList__Item--bold ProfileCreditCardList__Item--card'
                                  >
                                    <span className='creditCardNumber'>
                                      ****{ creditCard.creditCardNumber }
                                    </span>
                                    { ( () =>{
                                      if( !isUndefined( creditCard.expirationMonth ) && !isEmpty( creditCard.expirationMonth ) && !isUndefined( creditCard.expirationYear ) && !isEmpty( creditCard.expirationYear ) ){
                                        return (
                                          <span className='Expiration'>
                                            { creditCard.expirationMonth }/{ creditCard.expirationYear }
                                          </span>
                                        )
                                      }
                                    } )() }
                                  </div>
                                </div>
                                <div className='ProfileCreditCardList__Item--cardlogo'>
                                  <span className='icon'>
                                    { creditCardIcon }
                                  </span>
                                </div>
                                <div className='ProfileCreditCardList__Item--normal'>
                                  { ( () =>{

                                    if( creditCard.contactInfo !== null ){
                                      return (
                                        <div>
                                          <div className='name'>
                                            <span>{ creditCard.contactInfo && creditCard.contactInfo.firstName }</span>
                                            <span> { creditCard.contactInfo && creditCard.contactInfo.lastName }</span>
                                          </div>
                                          <div className='address'>
                                            <span>{ creditCard.contactInfo && creditCard.contactInfo.address1 }</span>
                                            { ( () =>{
                                              if( creditCard.contactInfo && ( creditCard.contactInfo.address2 !== null || creditCard.contactInfo.address2 !== '' ) ){
                                                return (
                                                  <span> { creditCard.contactInfo && creditCard.contactInfo.address2 }</span>
                                                );
                                              }

                                            } )() }
                                          </div>
                                          <div className='city'>
                                            <span>{ creditCard.contactInfo && creditCard.contactInfo.city }</span>
                                            <span> { creditCard.contactInfo && creditCard.contactInfo.state }</span>
                                            <span> { creditCard.contactInfo && creditCard.contactInfo.postalCode }</span>
                                          </div>
                                          <div>{ creditCard.contactInfo && creditCard.contactInfo.phoneNumber }</div>
                                        </div>

                                      )
                                    }
                                  } )() }
                                </div>

                              </RadioButton>
                            </div>
                            { ( () =>{
                              if( creditCard.isEditable ){
                                return (
                                  <div className='ProfileCreditCardList__container--link'>
                                    <Divider dividerType={ 'gray' }/>
                                    <Anchor
                                      url='#'
                                      clickHandler={ boundEditClickEvent }
                                      ariaLabel={ formatMessage( messages.edit ) + ' ' + creditCard.nickName + ' ' + formatMessage( messages.creditCard ) }
                                      title={ formatMessage( messages.edit ) + ' ' + creditCard.nickName + ' ' + formatMessage( messages.creditCard ) }
                                    >
                                      { formatMessage( messages.edit ) }
                                    </Anchor>
                                  </div>
                                );
                              }
                            } )() }
                          </div>
                          <Divider dividerType={ 'gray' }/>
                        </div>
                      );
                    } );
                  } )() }
                  <div className='ProfileCreditCardList__container--section'>
                    <div className='ProfileCreditCardList__container--section--newcard Gutter'>
                      <Anchor
                        url='#'
                        clickHandler={ this.addNewCreditCard }
                        ariaLabel={ formatMessage( messages.addANewCard ) }
                        title={ formatMessage( messages.addANewCard ) }
                      >
                        <span><SVG/></span>
                        { formatMessage( messages.addANewCard ) }
                      </Anchor>
                    </div>

                    { ( () =>{
                      if( !isUndefined( enableExpressPaypalCheckout ) && enableExpressPaypalCheckout ){
                        return (
                          <div className='ProfileCreditCardList__payPalSection'>
                            <Divider dividerType={ 'gray' }/>
                            <div className='ProfileCreditCardList__payPalDivider'>
                              { formatMessage( messages.or ) }
                            </div>

                            <div className='ProfileCreditCardList__container--cell Gutter'>
                              <PaypalCheckoutButton
                                payPalClientToken={ token }
                                getPaypalToken={ this.props.getPaypalToken }
                                getPaypalResponse={ this.props.getPaypalResponse }
                                applyPayment={ this.props.applyPayment }
                                amount={ ( this.props.cartSummary ) ? this.props.cartSummary.estimatedTotal : '' }
                                currency={ has( this.props.cartSummary ) ? this.props.cartSummary.currencyCode : '' }
                                displayMode={ 'tabView' }
                                onSuccessPaypalPayment={ this.onSuccessPaypalPayment }
                                paypalEnvironment={ this.props.paypalEnvironment }
                                enablePaypalButton={ enableExpressPaypalCheckout }
                              />
                            </div>
                          </div>
                        );
                      }
                    } )() }

                    <div className='ProfileCreditCardList__AddCardDivider'>
                      <Divider dividerType={ 'gray' } />
                    </div>

                    <div className='ProfileCreditCardList__container--section--done Gutter'>
                      <Anchor
                        url='#'
                        clickHandler={ this.changeCreditCard }
                        ariaLabel={ formatMessage( messages.DoneAriaLabel ) }
                        title={ formatMessage( messages.DoneAriaLabel ) }
                      >
                        { formatMessage( messages.Done ) }
                      </Anchor>
                      <Button
                        inputTag='button'
                        btnType='submit'
                        btnOutLine={ false }
                        title={ formatMessage( messages.DoneAriaLabel ) }
                      >
                        { formatMessage( messages.Done ) }
                      </Button>
                    </div>
                  </div>
                </div>
              </form>
            );
          }
          else {
            return (
              <div className='ProfileCreditCardList__container'>
                <div className='ProfileCreditCardList__container--shell'>
                  <div className='ProfileCreditCardList__Item--shell'></div>
                  <div className='ProfileCreditCardList__Item--shell'></div>
                  <Divider dividerType={ 'gray' }/>
                </div>
                <div className='ProfileCreditCardList__container--shell'>
                  <div className='ProfileCreditCardList__Item--shell'></div>
                  <div className='ProfileCreditCardList__Item--shell'></div>
                  <Divider dividerType={ 'gray' }/>
                </div>
                <div className='ProfileCreditCardList__container--shell'>
                  <div className='ProfileCreditCardList__Item--shell'></div>
                  <div className='ProfileCreditCardList__Item--shell'></div>
                  <Divider dividerType={ 'gray' }/>
                </div>
                <div className='ProfileCreditCardList__Item__Button--shell'></div>
              </div>
            );
          }
        } )() }
      </div>
    );
  }
}

const mapStateToProps = ( state ) =>{
  return {
    formData: state.form.profileCreditCardList
  };
}

ProfileCreditCardList.propTypes = propTypes;

export default
reduxForm( {
  form: 'profileCreditCardList'
} )( connect( mapStateToProps )( ProfileCreditCardList ) );

