/*
 * ProfileCreditCardList Messages
 *
 * This contains all the text for the ProfileCreditCardList component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  edit: {
    id: 'i18n.ProfileCreditCardList.edit',
    defaultMessage: 'Edit'
  },
  Done: {
    id: 'i18n.ProfileCreditCardList.Done',
    defaultMessage: 'Done'
  },
  DoneAriaLabel: {
    id: 'i18n.QualifiedShippingMethodList.DoneAriaLabel',
    defaultMessage: 'Click or enter to select the credit card'
  },
  creditCard: {
    id: 'i18n.ProfileCreditCardList.creditCard',
    defaultMessage: 'credit card'
  },
  addANewCard: {
    id: 'i18n.ProfileCreditCardList.addANewCard',
    defaultMessage: 'Add a New Card'
  },
  or:{
    id: 'i18n.ProfileCreditCardList.or',
    defaultMessage: 'or'
  },
  savedCreditCards:{
    id: 'i18n.ProfileCreditCardList.savedCreditCards',
    defaultMessage: 'Saved Credit Cards'
  }
} );
