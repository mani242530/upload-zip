import React from 'react';
import ReactDOM from 'react-dom';
import ProfileCreditCardList from './ProfileCreditCardList';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import messages from './ProfileCreditCardList.messages';

global.requestAnimationFrame = jest.fn();
describe( '<ProfileCreditCardList />', () => {
  let component;
  let props = {
    payPalClientToken: jest.fn(),
    paypalEnvironment : jest.fn(),
    enableExpressPaypalCheckout : true,
    getPaypalToken:jest.fn(),
    getProfileCreditCardList: jest.fn(),
    handleChangeCreditCard: jest.fn(),
    setTempPaymentCCVNumber: jest.fn(),
    creditCardDetails: {
      paymentInfo: {
        paymentType: 'creditCard',
        paymentDetails: {
          expirationMonth: '09',
          expirationYear: '2021',
          creditCardNumber: '1111',
          creditCardType: 'Visa'
        },
        amount: 46.18,
        currencyCode: 'USD',
        contactInfo: {
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          email: 'pkabdaula@ulta.com',
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city: 'Boolingbrook',
          state: 'IL',
          postalCode: '07105',
          country: 'US'
        }
      }
    },
    profileCreditCardList: {
      profileCreditCards: [
        {
          creditCard: {
            expirationYear: '2021',
            creditCardType: 'Visa',
            expirationMonth: '09',
            creditCardNumber: '2311',
            nickName: 'Visa-2311',
            isPrimary: true,
            isEditable: true,
            contactInfo: {
              firstName: 'Pushpendra',
              lastName: 'Kabdaula',
              phoneNumber: '123-456-7890',
              address1: '1000 remngton blvd',
              address2: 'Ste 200',
              city: 'Boolingbrook',
              state: 'IL',
              postalCode: '07105',
              country: 'US'
            }
          },
          messages: [
            {
              messageDesc: 'Credit card is expired',
              messageKey: 'CREDIT_CARD_NOT_valid',
              messageType: 'Error'
            }
          ]
        }
      ]
    }
  };

  let paymentDetails = props.profileCreditCardList.profileCreditCards[0].creditCard;
  let errorMsg = props.profileCreditCardList.profileCreditCards[0].messages[0];
  let contactInfo = props.profileCreditCardList.profileCreditCards[0].creditCard.contactInfo;
  global.braintree = { client:{ create:jest.fn() } };

  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <ProfileCreditCardList { ...props }/>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'ProfileCreditCardList' ).length ).toBe( 1 );
  } );

  it( 'Click on credit card should send a request to service and reset the temp CVV data', () => {
    component.find( '.ProfileCreditCardList__Item--carddetails' ).simulate( 'click' );
    expect( props.setTempPaymentCCVNumber ).toBeCalled();
    expect( props.handleChangeCreditCard ).toBeCalled();
  } );

  // Verify credit card updation on click of a payment cell
  it( 'verify cc selection on click', () => {
    var node = component.find( 'ProfileCreditCardList' ).instance();
    node.updateCreditCardValue = jest.fn();
    component.find( '.ProfileCreditCardList__container--cell' ).first().find( 'div[onClick]' ).simulate( 'click' );
    expect( node.updateCreditCardValue ).toBeCalled();
  } );

  it( 'should display the data', () => {
    expect( component.find( '.ProfileCreditCardList__container' ).length ).toBe( 1 );
  } );

  it( 'should call mapping function', () => {
    expect( component.find( '.ProfileCreditCardList__container--cell' ).length ).toBe( 2 );
  } );

  // handle click on credit card cell
  it( 'select credit card based on click', () => {
    component.find( '.ProfileCreditCardList__container--cell' ).at( 0 ).simulate( 'click' );
    expect( component.find( '.ProfileCreditCardList__Item--carddetails' ).length ).toBe( 1 );
  } );

  it( 'renders radiobutton', () => {
    expect( component.find( '.RadioButton' ).length ).toBe( 1 );
  } );

  it( 'renders Anchor component', () => {
    expect( component.find( '.Anchor' ).length ).toBe( 3 );
  } );

  it( 'renders Divider component', () => {
    expect( component.find( '.Divider' ).length ).toBe( 5 );
  } );

  it( 'Should contain Credit Card Error Message', () => {
    expect( component.find( '.ProfileCreditCardList .PaymentInformation__errorMessages' ).text() ).toBe( ' ' + errorMsg.messageDesc );
  } );

  it( 'Should contain Credit Card Default Details', () => {
    let name = contactInfo.firstName+' '+contactInfo.lastName;
    let address = contactInfo.address1+' '+contactInfo.address2;
    let city = contactInfo.city+' '+contactInfo.state+' '+contactInfo.postalCode;

    expect( component.find( '.ProfileCreditCardList .ProfileCreditCardList__Item--normal .name' ).text() ).toBe( name );
    expect( component.find( '.ProfileCreditCardList .ProfileCreditCardList__Item--normal .address' ).text() ).toBe( address );
    expect( component.find( '.ProfileCreditCardList .ProfileCreditCardList__Item--normal .city' ).text() ).toBe( city );
    expect( component.find( '.ProfileCreditCardList .ProfileCreditCardList__Item--card .creditCardNumber' ).text() ).toBe( '****'+paymentDetails.creditCardNumber );
    expect( component.find( '.ProfileCreditCardList .ProfileCreditCardList__Item--card .Expiration' ).text() ).toBe( paymentDetails.expirationMonth+'/'+paymentDetails.expirationYear );
  } );

  it( 'should render Add a new card', () => {
    expect( component.find( '.ProfileCreditCardList .ProfileCreditCardList__container--section--newcard .Anchor' ).text() ).toEqual( messages.addANewCard.defaultMessage );
    expect( component.find( '.ProfileCreditCardList .ProfileCreditCardList__container--section--newcard .Anchor' ).props().href ).toBe( '#' );
  } );

  it( 'h4 should have tabIndex of -1 and savedCreditCards defaultMessage', () => {
    expect( component.find( '.ProfileCreditCardList' ).find( 'h4' ).instance().tabIndex ).toBe( -1 );
    expect( component.find( '.ProfileCreditCardList' ).find( 'h4' ).text() ).toBe( messages.savedCreditCards.defaultMessage );
  } );
  it( 'the component should have a reference to it child element', ()=> {
    const componentNode = component.find( 'ProfileCreditCardList' ).instance();
    componentNode.savedCardsHeading.focus = jest.fn();
    componentNode.componentDidMount();
    expect( componentNode.savedCardsHeading.focus ).toBeCalled();
  } );
} );
