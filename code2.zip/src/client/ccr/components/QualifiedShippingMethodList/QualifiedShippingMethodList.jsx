import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { reduxForm } from 'redux-form';
import './QualifiedShippingMethodList.css';

import { formatMessage } from 'shared/components/Global/Global';
import { connect } from 'react-redux';
import messages from './QualifiedShippingMethodList.messages';
import RadioButton from 'shared/components/RadioButton/RadioButton';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';

import 'shared/components/Gutter/Gutter.css';

const propTypes = {
  handleDoneShippingMethod: PropTypes.func,
  getShipMethod: PropTypes.func,
  shippingInfo: PropTypes.object,
  holdDavPopUp: PropTypes.bool,
  getQualifiedShipMethod: PropTypes.object,
  updateDavPopup: PropTypes.func
}

/**
 * Class
 * @extends React.Component
 */
class QualifiedShippingMethodList extends Component{

  /**
   * Create a QualifiedShippingMethodList
   */
  constructor( props ){
    super( props );
    this.props.getShipMethod( );
    this.selectShippingMethod = this.selectShippingMethod.bind( this );
    this.updateShippingValue = this.updateShippingValue.bind( this );
    this.state = {
      currentMethod: this.props.shippingInfo.shipMethodInfo.shipMethod,
      isSelected: false
    };
  }

  selectShippingMethod( e ){
    if( this.props.handleDoneShippingMethod ){
      if( !this.state.isSelected ){
        this.props.handleDoneShippingMethod( '' );
      }
      else {
        this.props.handleDoneShippingMethod( this.state.currentMethod );
      }
    }
  }

  updateShippingValue( e ){
    this.setState( {
      currentMethod: e.target.value,
      isSelected: true
    } );
    if( this.props.handleDoneShippingMethod ){
      this.props.handleDoneShippingMethod( e.target.value );
    }
  }

  componentWillMount(){
    if( this.props.holdDavPopUp ){
      this.props.updateDavPopup();
    }
  }

  render(){

    let shipMethodInfo = this.props.shippingInfo.shipMethodInfo;
    const {
      qualifiedShipMethodListResponse
    } = this.props.getQualifiedShipMethod;

    return (
      <div className='QualifiedShippingMethodList'>
        { ( ()=>{
          if( qualifiedShipMethodListResponse ){
            const shipMethodListRes = qualifiedShipMethodListResponse;
            if( shipMethodListRes && shipMethodListRes.shipMethodList ){
              return (
                <form>
                  <div className='QualifiedShippingMethodList__container'>
                    { ( ()=>{
                      try {
                        return shipMethodListRes.shipMethodList.map( ( shipMethodData, index ) => {
                          return (
                            <div className='QualifiedShippingMethodList__container--cell' key={ index }>
                              <div className='Gutter'>
                                <RadioButton
                                  id={ shipMethodData.shipMethod+'-'+index }
                                  name='changeShippingMethod'
                                  value={ shipMethodData.shipMethod }
                                  isChecked={ shipMethodInfo.shipMethod === shipMethodData.shipMethod }
                                  onClick={ this.updateShippingValue }
                                >
                                  <div className='ShippingInformation__Item--bold'>
                                    <span>{ shipMethodData.displayName }</span>
                                    <span> - { shipMethodData.cost }</span>
                                  </div>

                                  <div className='ShippingInformation__Item--normal'>
                                    { shipMethodData.estimatedDelivery }
                                  </div>
                                </RadioButton>
                              </div>
                              <Divider dividerType={ 'gray' } />
                            </div>
                          );
                        } );
                      }
                      catch ( e ){

                      }
                    } )() }
                    <Anchor
                      url='#'
                      className='Gutter'
                      clickHandler={ this.selectShippingMethod }
                      ariaLabel={ formatMessage( messages.DoneAriaLabel ) }
                      title={ formatMessage( messages.DoneAriaLabel ) }
                    >
                      { formatMessage( messages.Done ) }
                    </Anchor>
                    { ( ()=>{
                      if( this.props.isMobileDevice ){
                        return (
                          <Divider dividerType={ 'gray' } />
                        )
                      }
                    } )() }

                  </div>
                </form>
              );
            }
          }
          else {
            return (
              <div className='QualifiedShippingMethodList__container'>
                <div className='QualifiedShippingMethodList__container--shell'>
                  <div className='ShippingInformation__Item--shell'></div>
                  <div className='ShippingInformation__Item--shell'></div>
                  <Divider dividerType={ 'gray' } />
                </div>
                <div className='QualifiedShippingMethodList__container--shell'>
                  <div className='ShippingInformation__Item--shell'></div>
                  <div className='ShippingInformation__Item--shell'></div>
                  <Divider dividerType={ 'gray' } />
                </div>
                <div className='QualifiedShippingMethodList__container--shell'>
                  <div className='ShippingInformation__Item--shell'></div>
                  <div className='ShippingInformation__Item--shell'></div>
                  <Divider dividerType={ 'gray' } />
                </div>
                <div className='ShippingInformation__Item__Button--shell'></div>
                <Divider dividerType={ 'gray' } />
              </div>
            );
          }
        } )() }
      </div>
    );
  }
}

const mapStateToProps = ( state ) => {
  return {
    formData: state.form.shippingMethodList
  };
}

QualifiedShippingMethodList.propTypes = propTypes;

export default
reduxForm( {
  form: 'shippingMethodList'
} )( connect( mapStateToProps )( QualifiedShippingMethodList ) );
