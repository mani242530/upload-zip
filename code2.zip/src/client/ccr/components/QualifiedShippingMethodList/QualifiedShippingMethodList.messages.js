/*
 * QualifiedShippingMethodList Messages
 *
 * This contains all the text for the QualifiedShippingMethodList component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.QualifiedShippingMethodList.header',
    defaultMessage: 'This is the QualifiedShippingMethodList component !'
  },
  Done: {
    id: 'i18n.QualifiedShippingMethodList.Done',
    defaultMessage: 'Done'
  },
  DoneAriaLabel: {
    id: 'i18n.QualifiedShippingMethodList.DoneAriaLabel',
    defaultMessage: 'Click or enter to update the selected shipping method'
  }
} );
