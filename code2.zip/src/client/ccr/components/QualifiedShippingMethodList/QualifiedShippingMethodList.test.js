import React from 'react';
import ReactDOM from 'react-dom';
import QualifiedShippingMethodList from './QualifiedShippingMethodList';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import messages from './QualifiedShippingMethodList.messages';


describe( '<QualifiedShippingMethodList />', () => {
  let component;
  let props = {
    isMobileDevice: true,
    shippingInfo: {
      shipMethodInfo: {
        shipMethod: 'ups_ground',
        estimatedDelivery: 'Within 3 to 8 business days',
        cost: '$5.95',
        displayName: 'Standard Ground Shipping'
      }
    },
    getQualifiedShipMethod: {
      qualifiedShipMethodListResponse: {
        shipMethodList: [{
          cost:'$5.95',
          displayName:'Standard Ground Shipping',
          estimatedDelivery:'Within 3 to 8 business days',
          shipMethod:'ups_ground'
        }]
      }
    },
    getShipMethod: jest.fn()
  };
  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <QualifiedShippingMethodList { ...props }/>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'QualifiedShippingMethodList' ).length ).toBe( 1 );
  } );
  it( 'should call service to get data', () => {
    expect( props.getShipMethod ).toBeCalled();
  } );
  it( 'should display the data', () => {
    expect( component.find( '.QualifiedShippingMethodList__container' ).length ).toBe( 1 );
  } );
  it( 'should call mapping function', () => {
    expect( component.find( '.QualifiedShippingMethodList__container--cell' ).length ).toBe( 1 );
  } );
  it( 'renders radiobutton', () => {
    expect( component.find( '.RadioButton' ).length ).toBe( 1 );
  } );
  it( 'renders Anchor component', () => {
    expect( component.find( '.Anchor' ).length ).toBe( 1 );
  } );
  it( 'renders Divider component', () => {
    expect( component.find( '.Divider' ).length ).toBe( 2 );
  } );
  it( 'display text in bold', () => {
    expect( component.find( '.ShippingInformation__Item--bold' ).length ).toBe( 1 );
    expect( component.find( '.ShippingInformation__Item--bold' ).text() ).toBe( props.getQualifiedShipMethod.qualifiedShipMethodListResponse.shipMethodList[0].displayName+' - '+props.getQualifiedShipMethod.qualifiedShipMethodListResponse.shipMethodList[0].cost );
  } );
  it( 'should display text in normal font', () => {
    expect( component.find( '.ShippingInformation__Item--normal' ).length ).toBe( 1 );
    expect( component.find( '.ShippingInformation__Item--normal' ).text() ).toBe( props.getQualifiedShipMethod.qualifiedShipMethodListResponse.shipMethodList[0].estimatedDelivery );
  } );

  it( 'show when no data is loaded', () => {
    let props1 = {
      isMobileDevice: true,
      shippingInfo: {
        shipMethodInfo: {
          shipMethod: 'ups_ground',
          estimatedDelivery: 'Within 3 to 8 business days',
          cost: '$5.95',
          displayName: 'Standard Ground Shipping'
        }
      },
      getQualifiedShipMethod: {
      },
      getShipMethod: jest.fn()
    };
    const store = configureStore( {}, CONFIG );
    component = mountWithIntl(
      <Provider store={ store }>
        <QualifiedShippingMethodList { ...props1 }/>
      </Provider>
    );
    expect( component.find( '.QualifiedShippingMethodList__container--shell' ).length ).toBeGreaterThan( 0 );
  } );

  it( 'rederes divider component when no data is loaded', () => {
    expect( component.find( '.Divider' ).length ).toBe( 4 );
  } );

  props.holdDavPopUp = true;
  props.updateDavPopup = jest.fn();
  props.handleDoneShippingMethod = jest.fn();
  component = mountWithIntl(
    <Provider store={ store }>
      <QualifiedShippingMethodList { ...props }/>
    </Provider>
  );
  const instance = component.find( 'QualifiedShippingMethodList' ).instance();

  it( 'should call the componentWillMount', () => {
    instance.state.isSelected = true;
    instance.componentWillMount();
    expect( props.updateDavPopup ).toHaveBeenCalled( );
  } );

  it( 'should call the selectShippingMethod method with state.isSelected is true', () => {
    instance.selectShippingMethod();
    expect( props.handleDoneShippingMethod ).toHaveBeenCalledWith( instance.state.currentMethod );
  } );

  it( 'should call the selectShippingMethod method with state.isSelected is false', () => {
    instance.state.isSelected = false;
    instance.selectShippingMethod();
    expect( props.handleDoneShippingMethod ).toHaveBeenCalledWith( instance.state.currentMethod );
  } );

} );
