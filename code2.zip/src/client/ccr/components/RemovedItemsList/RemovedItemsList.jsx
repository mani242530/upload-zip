/**
 * RemovedItemsList
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './RemovedItemsList.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './RemovedItemsList.messages';
import has from 'lodash/has';
import find from 'lodash/find';
import ProductDescriptionCard from 'ccr/components/ProductDescriptionCard/ProductDescriptionCard';
import classNames from 'classnames';

const propTypes = {
  removedList:PropTypes.array
}


/**
 * Class
 * @extends React.Component
 */
class RemovedItemsList extends Component{

  /**
   * Renders the RemovedItemsList component
   */
  render(){
    return (
      <div className='RemovedItemsList'>
        { ( ()=>{
          return ( this.props.removedList.map( ( removedItem, index ) => {
            return (
              <ProductDescriptionCard
                key={ index }
                imageURL={ removedItem.imageURL }
                brandName={ removedItem.brandName }
                displayName={ removedItem.skuDisplayName }
                variant={ removedItem.variantInfo }
                { ...( removedItem.messages && { 'messages' : removedItem.messages } ) }
              />
            );
          } ) );
        } )() }
      </div>
    );
  }
}

RemovedItemsList.propTypes = propTypes;

export default RemovedItemsList;
