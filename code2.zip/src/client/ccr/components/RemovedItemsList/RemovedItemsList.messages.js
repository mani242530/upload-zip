/*
 * RemovedItemsList Messages
 *
 * This contains all the text for the RemovedItemsList component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.RemovedItemsList.header',
    defaultMessage: 'This is the RemovedItemsList component !'
  }
} );
