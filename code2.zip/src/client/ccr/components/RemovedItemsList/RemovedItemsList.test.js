import React from 'react';
import ReactDOM from 'react-dom';
import RemovedItemsList from './RemovedItemsList';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

const data = {
  'messages': {
    'items': [
      {
        'type': 'Info',
        'message': 'Looks like you have items in your bag from before. They\'ve been added below.'
      }
    ]
  },
  'cartSummary': {
    'shippingCost': 5.95,
    'subTotal': 21,
    'itemCount': 1,
    'orderGiftWrapAmt': 0,
    'additionalDiscount': null,
    'couponDiscount': 0,
    'estimatedTax': 'TBD',
    'estimatedTotal': 26.95,
    'currencyCode': 'USD',
    'couponCode': null
  },
  'giftOptions': {
    'giftBoxProductId': 'prod9990099',
    'giftBoxPrice': 3.99,
    'messages': {
      'items': [
        {
          'type': 'Info',
          'message': 'Message and Gift Box Added'
        }
      ]
    },
    'giftBoxSelected': true,
    'giftBoxSkuId': '9990099',
    'giftBoxDesc': 'Make it very special! In a gift box and topped with a bow!!!',
    'giftBoxImageURL': 'https://images.ulta.com/is/image/Ulta/9990099?$md$',
    'giftNote': 'Happy Birthday'
  },
  'freeSamplesInfo': {
    'items': [
      {
        'catalogRefId': '2252998',
        'sampleDesc': 'Fragrance',
        'shippingRestriction': 'Cannot ship to selected address',
        'selected': true
      },
      {
        'catalogRefId': '2252999',
        'sampleDesc': 'Skincare',
        'shippingRestriction': null,
        'selected': false
      },
      {
        'catalogRefId': '2253000',
        'sampleDesc': 'Variety',
        'shippingRestriction': null,
        'selected': false
      }
    ],
    'messages': {
      'items': [
        {
          'type': 'info',
          'message': 'Fragrance Added'
        }
      ]
    }
  },
  'giftHeaderMessage': 'See',
  'orderId': 'U467725401',
  'appliedCouponSummary': {
    'couponAppliedStatus': false,
    'couponCode': 'HSHHSSS',
    'messages': {
      'items': [
        {
          'type': 'error',
          'message': 'Entered coupon code is not valid'
        }
      ]
    }
  },
  'removedItems': [
    {
      'couponApplied': false,
      'brandName': 'OPI',
      'quantity': null,
      'productId': 'xlsImpprod5180311',
      'excludedFromCoupon': false,
      'adbugMessageMap': null,
      'catalogRefId': '2056976',
      'categoryName': null,
      'commerceItemid': null,
      'priceInfo': {
        'salePrice': null,
        'regularPrice': '$10',
        'unitPriceMessage': null,
        'bfxPriceMap': null
      },
      'productDisplayName': 'Soft Shades Nail Lacquer Collection',
      'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
      'variantInfo': {
        'Color': 'Bubble Bath'
      },
      'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
      'shippingRestriction': null,
      'maxQty': null,
      'productURL': null,
      'messages': {
        'items': [
          {
            'type': 'Info',
            'message': 'Selected items is out of stock'
          }
        ]
      }
    },
    {
      'couponApplied': false,
      'brandName': 'OPI',
      'quantity': null,
      'productId': 'xlsImpprod5180311',
      'excludedFromCoupon': false,
      'adbugMessageMap': null,
      'categoryName': null,
      'commerceItemid': null,
      'catalogRefId': '2056976',
      'priceInfo': {
        'salePrice': null,
        'regularPrice': '$10',
        'unitPriceMessage': null,
        'bfxPriceMap': null
      },
      'productDisplayName': 'Soft Shades Nail Lacquer Collection',
      'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
      'variantInfo': {
        'Color': 'Bubble Bath'
      },
      'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
      'shippingRestriction': null,
      'maxQty': null,
      'productURL': null,
      'messages': {
        'items': [
          {
            'type': 'Info',
            'message': 'Nolongerqualifiesforthisfreegift'
          }
        ]
      }
    },
    {
      'couponApplied': false,
      'brandName': 'ULTA',
      'quantity': null,
      'productId': 'xlsImpprod3570051',
      'excludedFromCoupon': false,
      'adbugMessageMap': null,
      'categoryName': null,
      'commerceItemid': null,
      'catalogRefId': '2275711',
      'priceInfo': {
        'salePrice': null,
        'regularPrice': '$10',
        'unitPriceMessage': null,
        'bfxPriceMap': null
      },
      'productDisplayName': 'SalonFormulaNailLacquer',
      'imageURL': 'http: //images.ulta.com/is/image/Ulta/2154759?$md$',
      'variantInfo': {
        'Color': 'BubbleBath'
      },
      'skuDisplayName': 'SalonFormulaNailLacquer',
      'shippingRestriction': null,
      'maxQty': null,
      'productURL': null,
      'messages': {
        'items': [
          {
            'type': 'Info',
            'message': 'SelectedItemisOutofstock'
          }
        ]
      }
    }
  ],
  'banner': {
    'messages': {
      'items': [
        {
          'type': 'info',
          'message': 'You\'re $29.00 away from FREE shipping'
        }
      ]
    }
  },
  'ultamateRewardsCCInfo': {},
  'giftItems': {
    'items': [
      {
        'bfxPriceMap': null,
        'freeGifts': {
          'items': [
            {
              'giftVariant': 'Rhubarb',
              'giftProductId': 'VP11651',
              'giftPDPUrl': '/lip-shimmer?productId=VP11651&sku=2133425',
              'giftCatalogRefId': '2133425',
              'giftDisplayName': 'Lip Shimmer',
              'giftCategoryName': 'Lip Care',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2133425?$md$',
              'selected': 'false',
              'giftBrandName': 'Burt\'s Bees'
            },
            {
              'giftProductId': 'xlsImpprod1040288',
              'giftPDPUrl': '/un-wrinkle-night?productId=xlsImpprod1040288&sku=2160848',
              'giftCatalogRefId': '2160848',
              'giftDisplayName': 'Un-Wrinkle Night',
              'giftCategoryName': 'Moisturizers',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2160848?$md$',
              'selected': 'false',
              'giftBrandName': 'Peter Thomas Roth'
            },
            {
              'giftVariant': 'Parfait',
              'giftProductId': 'xlsImpprod5770357',
              'giftPDPUrl': '/butter-lip-balm?productId=xlsImpprod5770357&sku=2262487',
              'giftCatalogRefId': '2262487',
              'giftDisplayName': 'Butter Lip Balm',
              'giftCategoryName': 'Lip Care',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2262487?$md$',
              'selected': 'false',
              'giftBrandName': 'Nyx Cosmetics'
            },
            {
              'giftDisplayName': 'QATEST_SINGLE GWP-MULTIPLE GIFTS (DOUBLE G)',
              'giftImageURL': 'https://images.ulta.com/is/image/Ulta/2210998?$md$',
              'selected': 'default'
            }
          ]
        },
        'promoId': '0000124096',
        'induldge': true,
        'promoValidity': 'offer valid 01/22/2015-02/28/2018 or while supplies last'
      },
      {
        'bfxPriceMap': null,
        'freeGifts': {
          'items': [
            {
              'giftVariant': 'Rhubarb',
              'giftProductId': 'VP11651',
              'giftPDPUrl': '/lip-shimmer?productId=VP11651&sku=2133425',
              'giftCatalogRefId': '2133425',
              'giftDisplayName': 'Lip Shimmer',
              'giftCategoryName': 'Lip Care',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2133425?$md$',
              'selected': 'false',
              'giftBrandName': 'Burt\'s Bees'
            },
            {
              'giftProductId': 'xlsImpprod1040288',
              'giftPDPUrl': '/un-wrinkle-night?productId=xlsImpprod1040288&sku=2160848',
              'giftCatalogRefId': '2160848',
              'giftDisplayName': 'Un-Wrinkle Night',
              'giftCategoryName': 'Moisturizers',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2160848?$md$',
              'selected': 'false',
              'giftBrandName': 'Peter Thomas Roth'
            },
            {
              'giftVariant': 'Parfait',
              'giftProductId': 'xlsImpprod5770357',
              'giftPDPUrl': '/butter-lip-balm?productId=xlsImpprod5770357&sku=2262487',
              'giftCatalogRefId': '2262487',
              'giftDisplayName': 'Butter Lip Balm',
              'giftCategoryName': 'Lip Care',
              'giftImageURL': 'https://s7d5.scene7.com/is/image/Ulta/2262487?$md$',
              'selected': 'false',
              'giftBrandName': 'Nyx Cosmetics'
            },
            {
              'giftDisplayName': 'QATEST_SINGLE GWP-MULTIPLE GIFTS (DOUBLE G)',
              'giftImageURL': 'https://images.ulta.com/is/image/Ulta/2210998?$md$',
              'selected': 'default'
            }
          ]
        },
        'promoId': '0000124096',
        'induldge': true,
        'promoValidity': 'offer valid 01/22/2015-02/28/2018 or while supplies last'
      }
    ]
  },
  'cartItems': {
    'items': [
      {
        'couponApplied': false,
        'brandName': 'Clinique',
        'quantity': {
          'value': 1,
          'messages': {
            'items': [
              {
                'type': 'Info',
                'message': 'Selected Quantity not available'
              }
            ]
          }
        },
        'productId': 'prod2140590',
        'excludedFromCoupon': false,
        'adbugMessageMap': null,
        'catalogRefId': '2140590',
        'categoryName': 'Exfoliators & Scrubs',
        'commerceItemid': 'ci15759000076',
        'priceInfo': {
          'salePrice': null,
          'regularPrice': '$21.00',
          'bfxPriceMap': [
            {
              'bfxQty': '1',
              'bfxPrice': '$21.00'
            }
          ],
          'unitPriceDesc': null,
          'messages': {
            'items': [
              {
                'type': 'Info',
                'message': 'Discount Applied'
              }
            ]
          }
        },
        'productDisplayName': 'Clinique For Men Face Scrub',
        'imageURL': 'https://images.ulta.com/is/image/Ulta/2140590?$md$',
        'variantInfo': {
        },
        'skuDisplayName': 'Skin Supplies For Men Face Scrub',
        'shippingRestriction': null,
        'maxQty': 10,
        'productURL': '/clinique-men-face-scrub?productId=prod2140590&sku=2140590'
      }
    ]
  },
  'showShippingRestrictionMsg': true
};

describe( '<RemovedItemsList />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <RemovedItemsList removedList={ data.removedItems }/> );
    expect( component.find( 'RemovedItemsList' ).length ).toBe( 1 );
  } );
  it( 'renders product description card component', () => {
    let component1 = mountWithIntl( <RemovedItemsList removedList={ data.removedItems }/> );
    expect( component1.find( 'RemovedItemsList' ).length ).toBe( 1 );
    expect( component1.find( '.ProductDescriptionCard' ).length ).toBe( 3 );
  } )
} );
