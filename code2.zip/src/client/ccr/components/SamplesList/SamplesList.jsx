import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './SamplesList.css';
import { formatMessage } from 'shared/components/Global/Global';
import Button from 'shared/components/Button/Button';
import classNames from 'classnames';
import SelectedIcon from 'shared/components/Icons/checkmarkcircle';

const propTypes = {
  id:PropTypes.string.isRequired,
  sampleName:PropTypes.string.isRequired,
  selectedButton:PropTypes.string
}
export const initialState={ selectedSample:'-1' };


/**
 * Class
 * @extends React.Component
 */
class SamplesList extends Component{

  /**
   * Create a SamplesList
   */
  constructor( props ){
    super( props );
    this.state = initialState;
  }



  /**
   * Renders the SamplesList component
   */
  render(){

    return (
      <div className='SamplesList'>

        <div className='SamplesPanelItem'>
          <Button
            id={ this.props.id }
            className={
              classNames( {
                'UnselectedSample': ( this.props.id !== this.props.selectedButton ),
                'SelectedSample': ( this.props.id === this.props.selectedButton )
              } )
            }
            btnOption='single'
            inputTag='button'
            btnSize='xs'
            btnOutLine={ true }
          >
            { ( () => {
              {
                return (
                  <div className='checkedSampleIcon'>

                    <SelectedIcon/>
                  </div>

                )
              }
            } )()
            }{ this.props.sampleName }
          </Button>
        </div>
      </div>
    );
  }
}

SamplesList.propTypes = propTypes;

export default SamplesList;

