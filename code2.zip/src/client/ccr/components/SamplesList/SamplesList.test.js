import React from 'react';
import ReactDOM from 'react-dom';
import SamplesList from './SamplesList';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';
describe( '<SamplesList />', () => {
  let component;
  let props={
    id:0,
    sampleName:'Fragrance',
    selectedButton:0
  }
  it( 'renders without crashing', () => {
    component = mountWithIntl( <SamplesList { ...props } /> );
    expect( component.find( 'SamplesList' ).length ).toBe( 1 );

  } );
} );


describe( 'SampleList Button and Image components', () => {
  let component;
  let props={
    id:0,
    sampleName:'Fragrance',
    selectedButton:0
  }
  component = mountWithIntl( <SamplesList { ...props }/> );
  it( 'Should contain Buutton Components', () => {
    expect( component.find( 'SamplesList .SamplesPanelItem' ).length ).toBe( 1 );
  } );

  it( 'Should contain Button Component', () => {
    expect( component.find( 'SamplesList .SamplesPanelItem Button' ).length ).toBe( 1 );
  } );

  it( 'Should contain Image Components', () => {
    let component1;
    let props={
      id:0,
      sampleName:'Fragrance',
      selectedButton:0
    }
    component1 = mountWithIntl( <SamplesList { ...props }/> );
    expect( component1.find( 'SamplesList .SamplesPanelItem .SelectedSample .checkedSampleIcon SVG' ).length ).toBe( 1 );
  } );

  it( 'Should not contain Image Components if Id is not matched with selectedSample prop', () => {
    let component1;
    let props={
      id:1,
      sampleName:'Fragrance',
      selectedButton:0
    }
    component1 = mountWithIntl( <SamplesList { ...props }/> );
    expect( component1.find( 'SamplesList .SamplesPanelItem .SelectedSample .checkedSampleIcon SVG' ).length ).toBe( 0 );
  } );

  it( 'Should Button Size to be `xs` when width is more than 768px', () => {
    expect( component.find( 'SamplesList .SamplesPanelItem Button' ).props().btnSize ).toBe( 'xs' );
  } );

} );

