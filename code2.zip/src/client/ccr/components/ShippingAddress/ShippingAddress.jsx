/**
 * ShippingAddress
 */

import React, { Component } from 'react';
import { reduxForm } from 'redux-form';
import './ShippingAddress.css';

import { formatMessage } from 'shared/components/Global/Global';
import { connect } from 'react-redux';
import messages from './ShippingAddress.messages';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';
import AddressCard from 'ccr/components/AddressCard/AddressCard';
import SVG from 'shared/components/Icons/PlusCircle';
import CheckoutAddressForm from 'ccr/components/CheckoutAddressForm/CheckoutAddressForm';
import { isEmpty, omitBy, isNil } from 'lodash';
import 'shared/components/Gutter/Gutter.css';
import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';
import PropTypes from 'prop-types';
/**
 * Class
 * @extends React.Component
 */

const propTypes={
  shippingSuccess: PropTypes.bool,
  updateShippingStatus: PropTypes.func,
  getAddressBook: PropTypes.func,
  setShippingErrorMessage: PropTypes.func,
  setEditAddressData: PropTypes.func,
  handleScrollView: PropTypes.func,
  updateShipMethod: PropTypes.func,
  toggleInputFieldShippingDisplay: PropTypes.func,
  checkoutFormAddress2Open: PropTypes.object,
  checkoutFormAddressOpen: PropTypes.object,
  addressbook: PropTypes.object,
  address2Open: PropTypes.bool,
  editAddressData: PropTypes.object,
  shippingValid: PropTypes.bool,
  toggleAddressFieldDisplayPaymentForm: PropTypes.func,
  addressOpen: PropTypes.bool,
  toggleAddressFieldDisplay: PropTypes.func,
  lpsFlag: PropTypes.bool,
  handleSubmit: PropTypes.func,
  setEditCreditCardData: PropTypes.func,
  shippingInfo: PropTypes.object,
  shippingAddress: PropTypes.object
}
export const initialState = {
  addANewAddress: false,
  addressChange: false,
  selectedAddress: ''
};

class ShippingAddress extends Component{

  /**
   * Create a ShippingAddress
   */
  constructor( props ){
    super( props );
    this.state = initialState;
    this.setShippingAddress = this.setShippingAddress.bind( this );
    this.selectShippingMethod = this.selectShippingMethod.bind( this );
    this.editShippingAddress = this.editShippingAddress.bind( this );
    this.handleDoneShippingAddress = this.handleDoneShippingAddress.bind( this );
    this.handleCancelAddShippingAddress = this.handleCancelAddShippingAddress.bind( this );
    this.handleAddNewShippingAddress = this.handleAddNewShippingAddress.bind( this );
    this.addANewAddressLink = this.addANewAddressLink.bind( this );
    this.changeShippingAddressView = this.changeShippingAddressView.bind( this );
  }

  setShippingAddress(){
    if( this.props.shippingSuccess ){
      this.props.updateShippingStatus( this.props.shippingSuccess );
    }
    this.setState( { addressChange: !this.state.addressChange } )
    this.props.getAddressBook();
    this.props.setShippingErrorMessage( [] );
  }

  selectShippingMethod( selAddress ){
    this.props.setEditAddressData( selAddress );
    this.setState( {
      selectedAddress: selAddress
    } )
    this.props.handleScrollView( 'checkoutShippingHeader' );

    if( selAddress !== null && selAddress !== '' ){
      const postData = {
        values: {
          shipAddrNickName: selAddress
        }
      }
      this.props.updateShipMethod( postData );
    }
    this.setState( { addressChange: !this.state.addressChange } );

  }

  editShippingAddress( selAddressData ){
    this.props.setEditAddressData( selAddressData );
    if( !isEmpty( selAddressData.address2 ) ){
      this.props.toggleInputFieldShippingDisplay();
    }
    this.setState( {
      addANewAddress: !this.state.addANewAddress
    } );
    this.props.handleScrollView( 'checkoutShippingHeader' );
  }

  handleDoneShippingAddress(){
    if( this.state.selectedAddress !== null && this.state.selectedAddress !== '' ){
      const postData = {
        values: {
          shipAddrNickName: this.state.selectedAddress
        }
      }
      this.props.updateShipMethod( postData );
    }
    this.changeShippingAddressView();
  }

  changeShippingAddressView(){
    if( this.props.checkoutFormAddress2Open.shippingAddressForm ){
      this.props.toggleInputFieldShippingDisplay();
    }
    this.setState( { addressChange: false } );
    this.props.handleScrollView( 'checkoutShippingHeader' );
  }

  addANewAddressLink(){
    if( this.props.checkoutFormAddressOpen.shippingAddressForm ){
      this.props.toggleAddressFieldDisplayPaymentForm( 'shippingAddressForm' );
    }
    this.props.setEditAddressData( {} );
    this.props.setEditCreditCardData( {} );
    this.setState( {
      addANewAddress: !this.state.addANewAddress
    } );
    this.props.handleScrollView( 'checkoutShippingHeader' );
  }

  handleCancelAddShippingAddress(){

    this.props.handleScrollView( 'checkoutShippingHeader' );
    if( this.props.shippingSuccess ){
      this.props.updateShippingStatus( this.props.shippingSuccess );
    }
    else {
      this.setState( {
        addANewAddress: false,
        addressChange: true
      } );
    }

    if( this.props.shippingInfo && this.props.shippingInfo.shippingStatus === 'InvalidAddress' ){
      this.props.getAddressBook();
      this.props.setShippingErrorMessage( [] );
    }

  }

  handleAddNewShippingAddress(){
    this.setState( {
      addressChange: true,
      addANewAddress: false
    } );
    this.props.handleScrollView( 'checkoutShippingHeader' );
  }


  componentDidUpdate( prevProps ){
    if( prevProps.hazmatAddressChange!== this.props.hazmatAddressChange && !this.props.hazmatAddressChange ){
      this.setState( { addressChange: true } )
    }
  }

  componentWillMount(){
    if( this.props.shippingInfo && this.props.shippingInfo.shippingStatus === 'invalid' ){
      this.setState( {
        addANewAddress: true,
        addressChange: true
      } );
      this.props.setEditAddressData( this.props.shippingAddress );
    }

    if( this.props.changeAddress ){
      this.setState( {
        addANewAddress: false,
        addressChange: true
      } );
    }
  }

  /**
   * Renders the ShippingAddress component
   */
  render(){


    let shippingAddress = this.props.shippingAddress;
    let shippingStatus = this.props.shippingStatus;
    const {
      addressbook,
      address2Open,
      hazmatAddressChange,
      handleHazmatChange
    } = this.props;

    return (
      <div className='ShippingAddress ShippingInformation__Item'>
        { ( () => {
          if( !isEmpty( this.props.shippingAddress ) ){
            if( !this.state.addressChange || this.props.showAddressBookSpinner ){
              return (
                <div>
                  { ( ()=>{
                    if( shippingStatus === 'InvalidAddress' && !this.props.shippingSuccess ){
                      return (
                        <CheckoutAddressForm
                          form='shippingAddressList'
                          formName={ 'shippingAddressForm' }
                          addEditAddress='yes'
                          isAddFormTag='yes'
                          handleCancelAddShippingAddress={ this.handleCancelAddShippingAddress }
                          handleAddNewShippingAddress={ this.handleAddNewShippingAddress }
                          selectShippingMethod={ this.selectShippingMethod }
                          address2Open={ this.props.checkoutFormAddress2Open.shippingAddressForm }
                          toggleAddress2FieldDisplay={ this.props.toggleInputFieldShippingDisplay }
                          changeShippingAddressView={ this.changeShippingAddressView }
                          toggleInputFieldShippingDisplay={ this.props.toggleInputFieldShippingDisplay }
                          editAddressData={ this.props.editAddressData }
                          shippingValid={ this.props.shippingValid }
                          updateShipMethod={ this.props.updateShipMethod }
                          toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                          shippingSuccess={ this.props.shippingSuccess }
                          addressOpen={ this.props.addressOpen }
                          toggleAddressFieldDisplay={ this.props.toggleAddressFieldDisplay }
                          lpsFlag={ this.props.lpsFlag }
                          handleSubmit={ this.props.handleSubmit }
                          updateShippingStatus={ this.props.updateShippingStatus }
                          getAddressBook={ this.props.getAddressBook }
                          setShippingErrorMessage={ this.props.setShippingErrorMessage }
                          setEditAddressData={ this.props.setEditAddressData }
                          handleScrollView={ this.props.handleScrollView }
                          checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                          addressbook={ this.props.addressbook }
                          shippingInfo={ this.props.shippingInfo }
                          checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                          setEditCreditCardData={ this.props.setEditCreditCardData }
                        />
                      );
                    }
                    else {
                      return (
                        <div className='ShippingAddress__defaultView'>
                          <div className='ShippingInformation__Item--bold Gutter'>
                            <span>{ shippingAddress.firstName }</span>
                            <span> { shippingAddress.lastName }</span>
                          </div>

                          <div className='ShippingInformation__Item--normal Gutter'>
                            <span>{ shippingAddress.address1 }</span>
                            { ( () => {
                              try {
                                if( shippingAddress.address2 !== null && shippingAddress.address2 !== '' ){
                                  return (
                                    <span> { shippingAddress.address2 }</span>
                                  );
                                }
                              }
                              catch ( e ){

                              }
                            } )() }
                            <span>, { shippingAddress.city }</span>
                            <span> { shippingAddress.state }</span>
                            <span> { shippingAddress.postalCode }</span>
                          </div>

                          { ( ()=>{
                            if( !this.props.modal ){
                              return (
                                <div className='ShippingAddress__changeShippingAddress Gutter'>
                                  <Divider dividerType={ 'gray' } />
                                  <Anchor
                                    url='#'
                                    ariaLabel={ formatMessage( messages.changeShippingAddress ) }
                                    title={ formatMessage( messages.changeShippingAddress ) }
                                    clickHandler={ this.setShippingAddress }
                                  >
                                    { formatMessage( messages.changeShippingAddress ) }
                                  </Anchor>
                                </div>
                              )
                            }
                          } )() }

                        </div>
                      );
                    }
                  } )() }
                </div>
              )
            }
            else if( this.state.addANewAddress || this.props.shippingSuccess ){
              return (
                <CheckoutAddressForm
                  formName={ 'shippingAddressForm' }
                  form='shippingAddressList'
                  addEditAddress='yes'
                  isAddFormTag='yes'
                  handleCancelAddShippingAddress={ this.handleCancelAddShippingAddress }
                  handleAddNewShippingAddress={ this.handleAddNewShippingAddress }
                  selectShippingMethod={ this.selectShippingMethod }
                  address2Open={ this.props.checkoutFormAddress2Open.shippingAddressForm }
                  toggleAddress2FieldDisplay={ this.props.toggleInputFieldShippingDisplay }
                  changeShippingAddressView={ this.changeShippingAddressView }
                  toggleInputFieldShippingDisplay={ this.props.toggleInputFieldShippingDisplay }
                  editAddressData={ this.props.editAddressData }
                  shippingValid={ this.props.shippingValid }
                  updateShipMethod={ this.props.updateShipMethod }
                  toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                  shippingSuccess={ this.props.shippingSuccess }
                  addressOpen={ this.props.addressOpen }
                  toggleAddressFieldDisplay={ this.props.toggleAddressFieldDisplay }
                  lpsFlag={ this.props.lpsFlag }
                  handleSubmit={ this.props.handleSubmit }
                  shippingAddress={ this.props.shippingInfo.shippingAddress }
                  shippingStatus={ this.props.shippingInfo.shippingStatus }
                  modal={ false }
                  changeAddress={ this.state.changeAddress }
                  errorMsg={ this.state.errorMsg }
                  hazmatAddressChange={ this.state.hazmatAddressChange }
                  handleHazmatChange={ this.handleHazmatChange }
                  updateShippingStatus={ this.props.updateShippingStatus }
                  getAddressBook={ this.props.getAddressBook }
                  setShippingErrorMessage={ this.props.setShippingErrorMessage }
                  setEditAddressData={ this.props.setEditAddressData }
                  handleScrollView={ this.props.handleScrollView }
                  checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                  addressbook={ this.props.addressbook }
                  shippingInfo={ this.props.shippingInfo }
                  checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                  setEditCreditCardData={ this.props.setEditCreditCardData }
                />
              );
            }
            else {
              return (
                <form>
                  <div className='ShippingAddress__AddressList'>
                    { ( ()=>{
                      if( addressbook.addressBookResponse ){
                        this.props.handleHazmatChange();
                        return ( addressbook.addressBookResponse ).map( ( address, index ) => {
                          return (
                            <div key={ index } >
                              <AddressCard
                                index={ index }
                                refId={ address.refId }
                                isDefault={ address.isDefault }
                                isSelected={ address.isSelected }
                                isPaypal={ address.isPaypal }
                                firstName={ address.contactInfo.firstName }
                                lastName={ address.contactInfo.lastName }
                                address1={ address.contactInfo.address1 }
                                address2={ address.contactInfo.address2 }
                                city={ address.contactInfo.city }
                                state={ address.contactInfo.state }
                                phoneNumber={ address.contactInfo.phoneNumber }
                                postalCode={ address.contactInfo.postalCode }
                                selectShippingMethod={ this.selectShippingMethod }
                                editShippingAddress={ this.editShippingAddress }
                                handleDoneShippingAddress={ this.handleDoneShippingAddress }
                              />
                              <div className='ShippingAddress__Footer--bottom'>
                                <Divider dividerType={ 'gray' } />
                              </div>

                            </div>
                          )
                        } )
                      }
                    } )() }
                    <div className='ShippingAddress__AddressList--newaddress Gutter'>
                      <Anchor
                        url='#'
                        clickHandler={ this.addANewAddressLink }
                        ariaLabel={ formatMessage( messages.addNewShippingAddress ) }
                        title={ formatMessage( messages.addNewShippingAddress ) }
                      >
                        <span><SVG /></span>
                        { formatMessage( messages.addNewShippingAddress ) }
                      </Anchor>
                    </div>
                    <div className='ShippingAddress__AddressList--bottom'>
                      <Divider dividerType={ 'gray' } />
                    </div>
                    <Anchor
                      className='Gutter'
                      url='#'
                      clickHandler={ this.handleDoneShippingAddress }
                      ariaLabel={ formatMessage( messages.done ) }
                      title={ formatMessage( messages.done ) }
                    >
                      { formatMessage( messages.done ) }
                    </Anchor>
                  </div>
                </form>
              )
            }
          }
        } )() }

      </div>
    );
  }
}

const mapStateToProps = ( state ) =>{
  return {
    formData: state.form.shippingAddressList
  };
}

export const onSubmitFail = ( errors, dispatch, submitError, props ) => {
  let analyticErrors = [];
  analyticErrors.push( { 'CheckoutAddressFormErrors':  omitBy( errors, isNil ) } );

  let evt = {
    'name': 'trackErrorDisplayed',
    'data': analyticErrors
  }
  dispatch( analyticActions.triggerAnalyticsEvent( evt ) );

  // handle scroll to error fields
  props.handleScrollToFormError( errors );
}

export default
reduxForm( {
  form: 'shippingAddressList',
  onSubmitFail
} )( connect( mapStateToProps )( ShippingAddress ) );
