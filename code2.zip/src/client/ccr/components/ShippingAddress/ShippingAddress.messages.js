/*
 * ShippingAddress Messages
 *
 * This contains all the text for the ShippingAddress component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.ShippingAddress.header',
    defaultMessage: 'This is the ShippingAddress component !'
  },
  changeShippingAddress: {
    id: 'i18n.ShippingAddress.changeShippingAddress',
    defaultMessage: 'Change Shipping Address'
  },
  addNewShippingAddress: {
    id: 'i18n.ShippingAddress.changeShippingAddress',
    defaultMessage: 'Add a New Address'
  },
  done: {
    id: 'i18n.ShippingAddress.done',
    defaultMessage: 'Done'
  }
} );
