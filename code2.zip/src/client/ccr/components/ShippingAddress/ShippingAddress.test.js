import React from 'react';
import ReactDOM from 'react-dom';
import ShippingAddress from './ShippingAddress';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import { IntlProvider } from 'react-intl';
import messages from './ShippingAddress.messages';

describe( '<ShippingAddress />', () => {
  let props = {
    isSignedIn: true,
    shippingInfo: {
      shippingStatus: 'Complete',
      shippingAddress: {
        lastName: 'Bharadwaj',
        country: 'US',
        address2: 'Apt 113',
        city: 'Naperville',
        address1: '1908 Continental Ave',
        postalCode: '60563',
        firstName: 'Teja',
        phoneNumber: '281-854-5360',
        state: 'IL',
        email: '9002970@ulta.com'
      },
      shipMethodInfo: {
        cost: 'FREE',
        displayName: 'Standard Shipping',
        shipMethod: 'free_shipping',
        estimatedDelivery: null
      }
    },
    shippingAddress: {
      firstName: 'Jane',
      lastName: 'Doe',
      address1: '1000 Remington Boulevard',
      address2: 'Suite # 120',
      city: 'Bolingbrook',
      state: 'IL',
      postalCode: '60564',
      phoneNumber: '(510)-213-8347'
    },
    showAddressBookSpinner: true
  };

  describe( '<ShippingAddress />', () => {
    let shippingInfoAddress = { ...props.shippingAddress };
    let component = mountComponent( props );
    it( 'renders without crashing', () => {
      expect( component.find( 'ShippingAddress' ).length ).toBe( 1 );
    } );

    it( 'Should contain Values in the Shipping Address Main Container', () => {
      expect( component.find( '.ShippingInformation__Item .ShippingInformation__Item--bold' ).length ).toBe( 1 );
    } );

    it( 'Should contain Values in the Shipping Address Sub Container', () => {
      expect( component.find( '.ShippingInformation__Item .ShippingInformation__Item--normal' ).length ).toBe( 1 );
    } );

    it( 'Should contain Logged In User First & Last Name in Preferred Shipping Address', () => {
      let name = shippingInfoAddress.firstName + ' ' + shippingInfoAddress.lastName;
      expect( component.find( '.ShippingInformation__Item .ShippingInformation__Item--bold' ).text() ).toBe( name );
    } );

    it( 'Should contain Logged In User Preferred Shipping Address', () => {
      let address = shippingInfoAddress.address1 + ' ' + shippingInfoAddress.address2 + ', ' + shippingInfoAddress.city + ' ' + shippingInfoAddress.state + ' ' + shippingInfoAddress.postalCode;
      expect( component.find( '.ShippingInformation__Item .ShippingInformation__Item--normal' ).text() ).toBe( address );
    } );

    it( 'should render correct Text for Change Shipping Address', () => {
      expect( component.find( '.ShippingInformation__Item .ShippingInformation__Item .Anchor' ).text() ).toEqual( messages.changeShippingAddress.defaultMessage );
    } );

    it( 'should render correct URL for Change Shipping Address', () => {
      expect( component.find( '.ShippingInformation__Item .ShippingInformation__Item .Anchor' ).props().href ).toBe( '#' );
    } );

  } );

  describe( '<ShippingAddress Address 2 empty/>', () => {
    let tempProps = { ...props }
    tempProps.shippingAddress.address2 = '';
    let shippingInfoAddress = tempProps.shippingAddress;
    let component1 = mountComponent( tempProps );

    it( 'Should contain Logged In User Preferred Shipping Address without Address2', () => {
      let address = shippingInfoAddress.address1 + ', ' + shippingInfoAddress.city + ' ' + shippingInfoAddress.state + ' ' + shippingInfoAddress.postalCode;
      expect( component1.find( '.ShippingInformation__Item .ShippingInformation__Item--normal' ).text() ).toBe( address );
    } );
  } );

} );


describe( '<ShippingAddress />', () => {
  let props = {
    isSignedIn: true,
    shippingInfo: {
      shippingStatus: 'Complete',
      shippingAddress: {
        lastName: 'Bharadwaj',
        country: 'US',
        address2: 'Apt 113',
        city: 'Naperville',
        address1: '1908 Continental Ave',
        postalCode: '60563',
        firstName: 'Teja',
        phoneNumber: '281-854-5360',
        state: 'IL',
        email: '9002970@ulta.com'
      },
      shipMethodInfo: {
        cost: 'FREE',
        displayName: 'Standard Shipping',
        shipMethod: 'free_shipping',
        estimatedDelivery: null
      }
    },
    editAddressData: {
      firstName: 'Jane',
      lastName: 'Doe',
      phoneNumber: '(510)-213-8347',
      refId: '1000RemingtonBlvd',
      isPaypalFlag: true,
      isPrimaryAddress: false,
      addressData: {
        address1: '1000 Remington Blvd',
        address2: null,
        city: 'Naperville',
        state: 'IL',
        postalCode: '60540'
      }
    },
    shippingAddress: {
      refId: '1000 Remington Blvd',
      firstName: 'Will',
      lastName: 'Smith',
      address1: '137 Pomeroon St',
      address2: null,
      city: 'Naperville',
      state: 'IL',
      postalCode: '60540',
      phoneNumber: '(510)-213-8347'
    },
    checkoutFormAddressOpen: {
      shippingAddressForm: true
    },
    checkoutFormAddress2Open: {
      shippingAddressForm: true
    },
    addressbook: {
      addressBookResponse: [{
        contactInfo: {
          country: 'US',
          lastName: 'test',
          address2: null,
          city: 'Bolingbrook',
          address1: '1000 Remington Blvd',
          postalCode: '60440',
          firstName: 'test',
          phoneNumber: '322-123-2131',
          state: 'IL',
          email: null
        },
        isPaypal: false,
        isDefault: false,
        isSelected: false,
        messages: null,
        refId: '1000 Remington Blvd'
      }]
    },
    toggleInputFieldShippingDisplay: jest.fn(),
    handleHazmatChange: jest.fn(),
    hazmatAddressChange: false,
    handleScrollView: jest.fn(),
    getAddressBook: jest.fn(),
    updateShippingStatus: jest.fn(),
    handleScrollToFormError: jest.fn()
  };

  describe( 'Shipping Address Tests', () => {
    let component1 = mountComponent( props );

    let node1 = component1.find( 'ShippingAddress' ).instance();
    node1.state.addressChange = true;
    node1.state.addANewAddress = true;

    component1 = mountComponent( props );

    it( 'should render checkout address form when editting', () => {
      expect( component1.find( '.CheckoutAddressForm' ).length ).toBe( 1 );
    } );

    it( 'should render Address card component', () => {
      let node1 = component1.find( 'ShippingAddress' ).instance();
      node1.state.addANewAddress = false;
      component1 = mountComponent( props );
      expect( component1.find( 'AddressCard' ).length ).toBe( 1 );
    } );

    it( 'Should render three Anchor componet ', () => {
      expect( component1.find( '.Anchor' ).length ).toBe( 3 );
    } );

    it( 'Should render three Anchor componet ', () => {
      expect( component1.find( '.ShippingAddress__AddressList--newaddress Anchor' ).length ).toBe( 1 );
      expect( component1.find( '.ShippingAddress__AddressList--newaddress Anchor' ).text() ).toBe( messages.addNewShippingAddress.defaultMessage );
    } );

    it( 'Should display save text', () => {
      let node = component1.find( 'ShippingAddress' ).instance();
      let anchor = component1.find( 'Anchor' ).at( 2 );
      expect( anchor.at( 0 ).props().clickHandler ).toBe( node.handleDoneShippingAddress );
    } );

    it( 'Should scroll to top on Onsubmitfail', () => {
      component1.find( 'ShippingAddress' ).at( 0 ).props().onSubmitFail( [], jest.fn(), undefined, props );
      expect( props.handleScrollToFormError ).toBeCalled();
    } );

  } );

  describe( 'Shipping Address Functional Tests', () => {

    let tempProps = {
      ...props,
      setShippingErrorMessage: jest.fn(),
      updateShippingStatus: jest.fn(),
      toggleAddressFieldDisplayPaymentForm: jest.fn(),
      setEditAddressData: jest.fn(),
      setEditCreditCardData: jest.fn(),
      handleScrollView: jest.fn(),
      shippingInfo:{
        shippingStatus: 'InvalidAddress'
      },
      shippingSuccess: true,
      changeAddress: true,
      showAddressBookSpinner: true
    };
    let component = mountComponent( tempProps );

    it( 'handle click to set address', () => {
      let node = component.find( 'ShippingAddress' ).instance();
      node.setShippingAddress();
      expect( tempProps.getAddressBook ).toBeCalled();
      expect( tempProps.updateShippingStatus ).toBeCalled();
    } );

    it( 'handle add/cancel functionality in checkout address form', () => {
      let node = component.find( 'ShippingAddress' ).instance();
      node.handleCancelAddShippingAddress();
      expect( tempProps.getAddressBook ).toBeCalled();
      expect( tempProps.updateShippingStatus ).toBeCalled();
      node.handleAddNewShippingAddress();
      expect( tempProps.handleScrollView ).toBeCalled();
    } );

    it( 'should show default shipping address view if the `showAddressBookSpinner` is true', () => {
      let node1 = component.find( 'ShippingAddress' ).instance();
      node1.state.addressChange = true;
      expect( component.find( '.ShippingAddress__defaultView' ).length ).toBe( 1 );
    } );

    it( 'add a new address click on link', () => {
      let node = component.find( 'ShippingAddress' ).instance();
      node.addANewAddressLink();
      expect( tempProps.toggleAddressFieldDisplayPaymentForm ).toBeCalled();
      expect( tempProps.setEditAddressData ).toBeCalled();
    } );

  } );

  describe( 'Shipping Address List Related Tests', () => {

    let tempProps = {
      ...props,
      setShippingErrorMessage: jest.fn(),
      updateShippingStatus: jest.fn(),
      updateShipMethod: jest.fn(),
      setEditAddressData: jest.fn(),
      toggleInputFieldShippingDisplay: jest.fn(),
      shippingInfo:{
        shippingStatus: 'invalid'
      },
      shippingSuccess: true,
      changeAddress: true
    };
    let component = mountComponent( tempProps );

    it( 'handle select ship method from ship method component', () => {
      let selectedAddress = 'Dave';
      let node = component.find( 'ShippingAddress' ).instance();
      node.selectShippingMethod( selectedAddress );
      expect( tempProps.setEditAddressData ).toBeCalled();
      expect( tempProps.updateShipMethod ).toBeCalled();
    } );

    it( 'handle edit shipping method', () => {
      let data = {
        address1: '3 Penn Plz E',
        address2: 'Suite 200',
        city: 'Newark'
      }
      let node = component.find( 'ShippingAddress' ).instance();
      node.editShippingAddress( data );
      expect( tempProps.setEditAddressData ).toBeCalled();
      expect( tempProps.toggleInputFieldShippingDisplay ).toBeCalled();
    } );

    it( 'handle done in shipping address list', () => {
      let node = component.find( 'ShippingAddress' ).instance();
      node.handleDoneShippingAddress();
      expect( tempProps.updateShipMethod ).toBeCalled();
      expect( tempProps.toggleInputFieldShippingDisplay ).toBeCalled();
    } );

    it( 'renders without crashing and scrolls to errors fields', () => {
      expect( component.find( 'ShippingAddress' ).length ).toBe( 1 );
      component.onSubmitFail = jest.fn();
      component.onSubmitFail( [], jest.fn(), true, tempProps );
      expect( tempProps.handleScrollToFormError ).toBeCalled();
    } );

  } );

} );



function mountComponent( props ){
  const store = configureStore( {}, CONFIG );
  return mountWithIntl(
    <Provider store={ store }>
      <ShippingAddress { ...props } />
    </Provider>
  );
}
