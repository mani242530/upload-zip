/**
 * ShippingInformation
 */

import React, { Component } from 'react';
import './ShippingInformation.css';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './ShippingInformation.messages';
import ShippingAddress from 'ccr/components/ShippingAddress/ShippingAddress';
import CheckoutAddressForm from 'ccr/components/CheckoutAddressForm/CheckoutAddressForm';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';
import { isUndefined, isEmpty, has, find, isEqual } from 'lodash';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import CheckoutModal from 'ccr/components/CheckoutModal/CheckoutModal';
import { fireAnalyticsEvent } from 'utils/Omniture/Omniture';
import Button from 'shared/components/Button/Button';
import 'shared/components/Gutter/Gutter.css';
import PropTypes from 'prop-types';
import Spinner from 'shared/components/Icons/spinner';
import classNames from 'classnames';
import QualifiedShippingMethodList from 'ccr/components/QualifiedShippingMethodList/QualifiedShippingMethodList';

const propTypes = {
  shippingSuccess: PropTypes.bool,
  isSignedIn: PropTypes.bool,
  getAddressBook: PropTypes.func,
  handleScrollView: PropTypes.func,
  setEditAddressData: PropTypes.func,
  shippingError: PropTypes.array,
  holdDavPopUp: PropTypes.bool,
  editAddressData: PropTypes.object,
  checkoutFormAddress2Open: PropTypes.object,
  toggleInputFieldShippingDisplay: PropTypes.func,
  shippingInfo:PropTypes.object,
  updateShipMethod: PropTypes.func,
  updateShippingStatus: PropTypes.func,
  setShippingErrorMessage: PropTypes.func,
  addressbook: PropTypes.object,
  address2Open: PropTypes.bool,
  shippingAddress: PropTypes.object,
  shippingStatus: PropTypes.string,
  changeAddress: PropTypes.bool,
  errorMsg: PropTypes.string,
  hazmatAddressChange: PropTypes.bool,
  handleHazmatChange: PropTypes.func,
  getEstimatedDelivery: PropTypes.func,
  getQualifiedShipMethod: PropTypes.object,
  getShipMethod: PropTypes.func,
  checkoutFormAddressOpen:PropTypes.object,
  toggleAddressFieldDisplayPaymentForm: PropTypes.func,
  setEditCreditCardData: PropTypes.func,
  updateDavPopup: PropTypes.func,
  showAddressBookSpinner: PropTypes.bool
}
/**
 * Class
 * @extends React.Component
 */
class ShippingInformation extends Component{

  /**
   * Create a ShippingInformation
   */
  constructor( props ){
    super( props );
    this.setShippingAddress = this.setShippingAddress.bind( this );
    this.assignShippingAddress = this.assignShippingAddress.bind( this );
    this.handleChangeShippingMethod = this.handleChangeShippingMethod.bind( this );
    this.handleDoneShippingMethod = this.handleDoneShippingMethod.bind( this );
    this.setErrorMsg = this.setErrorMsg.bind( this );
    this.handleHazmatChange = this.handleHazmatChange.bind( this );
    this.state = {
      showDefaultShippingMethod: true,
      changeAddress: false,
      errorMsg: false,
      hazmatAddressChange: true
    }
  }
  /**
   * Renders the ShippingInformation component
   */


  changeShippingMethodBtn = undefined;


  setErrorMsg(){
    this.setState( { errorMsg: true } );
  }

  handleHazmatChange(){
    this.setState( { hazmatAddressChange:true } );
  }

  setShippingAddress(){
    if( this.props.shippingSuccess ){
      this.props.updateShippingStatus( this.props.shippingSuccess );
    }
    this.setState( { changeAddress: true } );
    if( this.props.isSignedIn ){
      this.props.getAddressBook();
      this.setState( { hazmatAddressChange: false } );
    }

    this.props.handleScrollView( 'checkoutShippingHeader' );
  }
  assignShippingAddress(){
    let shippingAddress = this.props.shippingInfo.shippingAddress;
    let tempAddress = {
      firstName: shippingAddress.firstName,
      lastName: shippingAddress.lastName,
      phoneNumber: shippingAddress.phoneNumber,
      email: shippingAddress.email,
      isPrimaryAddress: false,
      isPaypalFlag: false,
      address1: shippingAddress.address1,
      address2: shippingAddress.address2,
      city: shippingAddress.city,
      state: shippingAddress.state,
      postalCode: shippingAddress.postalCode
    }
    this.props.setEditAddressData( tempAddress );
  }
  componentWillMount(){
    if( has( this.props.shippingInfo, 'shippingAddress' ) ){
      this.assignShippingAddress();
    }

    if( has( this.props, 'shippingInfo.shipMethodInfo' ) && this.props.shippingInfo.shipMethodInfo.estimatedDelivery === null ){
      this.props.getEstimatedDelivery();
    }
  }
  componentDidUpdate( prevProps ){
    if( has( this.props.shippingInfo, 'shippingAddress' )&& this.props.shippingInfo !== prevProps.shippingInfo ){
      this.assignShippingAddress();
    }

    // this will ensure that the screen is scrolled to the info message, the first time it is displayed
    // the below condition checks if the message was not present in the prevprops and is present in the current props
    if( has( this.props, 'shippingInfo.messages' ) &&
      find( this.props.shippingInfo.messages, { 'messageType': 'Info' } ) &&
      find( this.props.shippingInfo.messages, { 'messageRef': 'shipMethodInfo' } ) &&
      ( !has( prevProps, 'shippingInfo.messages' ) ||
        !isEqual( this.props.shippingInfo.messages, prevProps.shippingInfo.messages ) ) ){
      this.props.handleScrollView( 'shipMethodInfoSection' );
    }
  }

  handleChangeShippingMethod( e ){
    e.preventDefault();
    this.setState( {
      showDefaultShippingMethod: false
    } );
    this.props.handleScrollViewShippingMethod( 'checkoutShippingMethod' );
  }

  handleDoneShippingMethod( currentMethod ){
    if( currentMethod !== null && currentMethod !== '' ){
      const postData = {
        values: {
          shipMethodName: currentMethod
        }
      }
      this.props.updateShipMethod( postData );
    }
    this.setState( {
      showDefaultShippingMethod: true
    } );
    this.props.handleScrollViewShippingMethod( 'checkoutShippingMethod' );
  }

  // Filter dav popup messages
  filterDavPopupMesssages = ( messages ) => {
    return messages.filter( function( message ){
      if( message.messageType !== 'Info' ){
        return message;
      }
    } );
  }

  render(){
    const {
      shippingInfo
    } = this.props;



    let shippingmessages = ( shippingInfo.messages ) ? this.filterDavPopupMesssages( shippingInfo.messages ) : shippingInfo.messages;
    return (
      <div className='ShippingInformation'>


        { ( () => {
          if( !isUndefined( shippingInfo ) && !this.state.changeAddress && isEmpty( this.props.shippingError ) ){
            if( !isUndefined( shippingmessages ) && shippingInfo.shippingStatus !== 'IncompatibleShipping' && ( shippingmessages && shippingmessages.length > 0 ) ){
              return (
                <div className='ShippingInformation__messages'>
                  { ( () => {
                    return ( shippingmessages.map( ( message, index ) => {
                      if( message.messageType === 'Error' ){
                        this.setErrorMsg.bind( this );
                      }
                      return (
                        <ResponseMessages
                          messageType={ message.messageType }
                          message={ message.messageDesc }
                          key={ index }
                        />
                      )
                    } ) )
                  } )() }
                </div>
              )

            }
          }
        } )() }
        { ( () => {
          if( !isEmpty( this.props.shippingError ) ){
            return (
              <div className='ShippingInformation__messages ShippingInformation__messages--text'>
                { ( () => {
                  return ( this.props.shippingError.map( ( message, index ) => {
                    return (
                      <ResponseMessages
                        messageType={ message.messageType }
                        message={ message.messageDesc }
                        key={ index }
                      />
                    )
                  } ) )
                } )() }
              </div>
            )

          }
        } )() }
        <div className='ShippingInformation__ShipMethod'>
          { ( () => {
            if( this.props.isSignedIn ){
              return (
                <div className='ShippingInformation__shippingFormAnonymousFlow'>
                  { ( ()=>{
                    if( !this.props.holdDavPopUp && shippingInfo.shippingStatus === 'CorrectedAddress' ){
                      return (
                        <CheckoutModal
                          focusOnModalClose={ this.changeShippingMethodBtn }
                          updateShipMethod={ this.props.updateShipMethod }
                          shippingInfo={ this.props.shippingInfo }
                        />
                      );
                    }
                  } )() }
                  { ( ()=>{
                    /* Below condition is to show spinner when there is no addressBook data */
                    if( this.props.showAddressBookSpinner ){
                      return (
                        <div className='ShippingInformation__spinner'>
                          <Spinner/>
                        </div>
                      )
                    }
                  } )() }
                  <div className={
                    classNames(
                      {
                        'ShippingInformation__showShipMethodSpinner': this.props.showAddressBookSpinner /* Adding `ShippingInformation__showShipMethodSpinner` class to change opacity to 50% */
                      }
                    ) }
                  >
                    <ShippingAddress
                      showAddressBookSpinner={ this.props.showAddressBookSpinner }
                      shippingAddress={ shippingInfo.shippingAddress }
                      shippingStatus={ shippingInfo.shippingStatus }
                      modal={ false }
                      changeAddress={ this.state.changeAddress }
                      errorMsg={ this.state.errorMsg }
                      hazmatAddressChange={ this.state.hazmatAddressChange }
                      handleHazmatChange={ this.handleHazmatChange }
                      shippingSuccess={ this.props.shippingSuccess }
                      updateShippingStatus={ this.props.updateShippingStatus }
                      getAddressBook={ this.props.getAddressBook }
                      setShippingErrorMessage={ this.props.setShippingErrorMessage }
                      setEditAddressData={ this.props.setEditAddressData }
                      handleScrollView={ this.props.handleScrollView }
                      updateShipMethod={ this.props.updateShipMethod }
                      toggleInputFieldShippingDisplay={ this.props.toggleInputFieldShippingDisplay }
                      checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                      addressbook={ this.props.addressbook }
                      address2Open={ this.props.checkoutFormAddress2Open.shippingAddressForm }
                      shippingInfo={ this.props.shippingInfo }
                      checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                      toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                      setEditCreditCardData={ this.props.setEditCreditCardData }
                      editAddressData={ this.props.editAddressData }
                    />
                  </div>
                </div>
              )
            }
            else if( has( shippingInfo, 'shippingAddress' ) ){
              if( ( has( this.props.editAddressData, 'firstName' ) ) ){
                return (
                  <div>
                    { ( ()=>{
                      if( !this.props.holdDavPopUp && shippingInfo.shippingStatus === 'CorrectedAddress' ){
                        return (
                          <CheckoutModal
                            focusOnModalClose={ this.changeShippingMethodBtn }
                            updateShipMethod={ this.props.updateShipMethod }
                            shippingInfo={ this.props.shippingInfo }
                          />
                        );
                      }
                    } )() }
                    <CheckoutAddressForm
                      formName={ 'shippingAddressForm' }
                      isAddFormTag='yes'
                      address2Open={ this.props.checkoutFormAddress2Open.shippingAddressForm }
                      toggleAddress2FieldDisplay={ this.props.toggleInputFieldShippingDisplay }
                      shippingSuccess={ this.props.shippingSuccess }
                      updateShippingStatus={ this.props.updateShippingStatus }
                      getAddressBook={ this.props.getAddressBook }
                      setShippingErrorMessage={ this.props.setShippingErrorMessage }
                      setEditAddressData={ this.props.setEditAddressData }
                      handleScrollView={ this.props.handleScrollView }
                      updateShipMethod={ this.props.updateShipMethod }
                      toggleInputFieldShippingDisplay={ this.props.toggleInputFieldShippingDisplay }
                      checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                      addressbook={ this.props.addressbook }
                      editAddressData={ this.props.editAddressData }
                      checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                      toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                      shippingInfo={ this.props.shippingInfo }
                    />
                  </div>
                )
              }
            }
            else {
              return (
                <div>
                  { ( ()=>{
                    if( !this.props.holdDavPopUp && shippingInfo.shippingStatus === 'CorrectedAddress' ){
                      return (
                        <CheckoutModal
                          focusOnModalClose={ this.changeShippingMethodBtn }
                          updateShipMethod={ this.props.updateShipMethod }
                          shippingInfo={ this.props.shippingInfo }
                        />
                      );
                    }
                  } )() }
                  <CheckoutAddressForm
                    formName={ 'shippingAddressForm' }
                    isAddFormTag='yes'
                    address2Open={ this.props.checkoutFormAddress2Open.shippingAddressForm }
                    toggleAddress2FieldDisplay={ this.props.toggleInputFieldShippingDisplay }
                    shippingSuccess={ this.props.shippingSuccess }
                    updateShippingStatus={ this.props.updateShippingStatus }
                    getAddressBook={ this.props.getAddressBook }
                    setShippingErrorMessage={ this.props.setShippingErrorMessage }
                    setEditAddressData={ this.props.setEditAddressData }
                    handleScrollView={ this.props.handleScrollView }
                    updateShipMethod={ this.props.updateShipMethod }
                    toggleInputFieldShippingDisplay={ this.props.toggleInputFieldShippingDisplay }
                    checkoutFormAddress2Open={ this.props.checkoutFormAddress2Open }
                    addressbook={ this.props.addressbook }
                    editAddressData={ this.props.editAddressData }
                    checkoutFormAddressOpen={ this.props.checkoutFormAddressOpen }
                    toggleAddressFieldDisplayPaymentForm={ this.props.toggleAddressFieldDisplayPaymentForm }
                    shippingInfo={ this.props.shippingInfo }
                  />
                </div>
              )
            }
          } )() }

          { ( () => {
            if( shippingInfo.shippingStatus === 'IncompatibleShipping' ){

              return (
                <div className='ShippingInformation__messages'>
                  { ( () => {
                    return ( shippingmessages.map( ( message, index ) => {
                      if( message.messageType === 'Error' ){
                        this.setErrorMsg.bind( this );
                        let analyticsEvent =
                          {
                            eventName: 'trackErrorDisplayed',
                            data: {
                              'errorType':'form',
                              'errorLabel':'shipping',
                              'errorDescription': shippingmessages
                            }
                          };

                        fireAnalyticsEvent( analyticsEvent.name, analyticsEvent.data );
                      }
                      return (
                        <div key={ index }>
                          <ResponseMessages
                            messageType={ message.messageType }
                            message={ message.messageDesc }
                            key={ index }
                          />
                          <div className='ShippingInformation__messages--info'>
                            { formatMessage( messages.methodInfo ) }
                          </div>
                          <div className='ShippingInformation__messages--info'>
                            { formatMessage( messages.addressError ) }
                          </div>
                          <span className='ShippingInformation__Item'>
                            <Divider dividerType={ 'gray' } />
                          </span>
                          <div>
                            <Anchor
                              url='#'
                              ariaLabel={ formatMessage( messages.changeShipping ) }
                              title={ formatMessage( messages.changeShipping ) }
                              clickHandler={ this.setShippingAddress }
                            >
                              { formatMessage( messages.changeShipping ) }
                            </Anchor>
                            <span className='ShippingInformation__messages--links'> \ </span>
                            <Anchor url={ '/bag' }>
                              { formatMessage( messages.editBag ) }
                            </Anchor>
                          </div>
                        </div>
                      )
                    } ) );
                  } )() }
                </div>
              );
            }
          } )() }

          { ( () => {
            // the below section displays the shipmethod selected for the order, and if there is an info
            // message present which is related to shipmethods the same will be displayed here
            if( shippingInfo.shipMethodInfo ){
              return (
                <div className='ShippingInformtion__shipMethod'>
                  <Divider dividerType={ 'gray' } />
                  <div id='shipMethodInfoSection'>
                    { shippingInfo.messages &&
                      shippingInfo.messages
                        .filter( message =>
                          message.messageType === 'Info' && message.messageRef === 'shipMethodInfo' )
                        .map( ( message, index ) => {
                          return (
                            <ResponseMessages
                              messageType='warning-alert'
                              message={ message.messageDesc }
                              key={ index }
                            /> )
                        } )
                    }
                  </div>
                  <div id='checkoutShippingMethod'>
                    { ( ()=>{
                      if( this.state.showDefaultShippingMethod ){
                        return (
                          <div className='ShippingMethod ShippingInformation__Item Gutter'>
                            <div className='ShippingInformation__Item--bold'>
                              <span>{ shippingInfo.shipMethodInfo.displayName }</span>
                              <span> - { shippingInfo.shipMethodInfo.cost }</span>
                            </div>

                            <div className='ShippingInformation__Item--normal'>
                              { shippingInfo.shipMethodInfo.estimatedDelivery }
                            </div>

                            <Divider dividerType={ 'gray' } />

                            <Button
                              inputTag='button'
                              btnType='button'
                              btnSize='xs'
                              btnOption='no-style'
                              btnOutLine={ false }
                              title={ formatMessage( messages.changeShippingMethod ) }
                              clickEventHandler={ this.handleChangeShippingMethod }
                              ref={ ( button ) => {
                                this.changeShippingMethodBtn = button;
                              } }
                            >
                              { formatMessage( messages.changeShippingMethod ) }
                            </Button>


                          </div>
                        );
                      }
                      else {
                        return (
                          <QualifiedShippingMethodList
                            isMobileDevice={ this.props.isMobileDevice }
                            handleDoneShippingMethod={ this.handleDoneShippingMethod }
                            getShipMethod={ this.props.getShipMethod }
                            shippingInfo={ this.props.shippingInfo }
                            holdDavPopUp={ this.props.holdDavPopUp }
                            getQualifiedShipMethod={ this.props.getQualifiedShipMethod }
                            updateDavPopup={ this.props.updateDavPopup }
                          />
                        );
                      }
                    } )() }
                  </div>
                </div>
              );
            }
          } )() }
        </div>
      </div>
    );
  }
}

ShippingInformation.propTypes = propTypes;

export default ShippingInformation;
