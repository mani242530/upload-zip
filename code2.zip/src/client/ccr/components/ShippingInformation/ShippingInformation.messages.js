/*
 * ShippingInformation Messages
 *
 * This contains all the text for the ShippingInformation component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  changeShippingMethod: {
    id: 'i18n.ShippingMethod.changeShippingMethod',
    defaultMessage: 'Change Shipping Method'
  },
  methodInfo: {
    id: 'i18n.ShippingInformation.methodInfo',
    defaultMessage: 'To place your order please change your shipping address or edit your bag, removing those items.'
  },
  addressError: {
    id: 'i18n.ShippingInformation.addressError',
    defaultMessage: 'The items that cannot be shipped will be indicated in the bag.'
  },
  changeShipping: {
    id: 'i18n.ShippingInformation.changeShipping',
    defaultMessage: 'Change Shipping Address'
  },
  editBag: {
    id: 'i18n.ShippingInformation.editBag',
    defaultMessage: 'Edit Bag'
  }
} );
