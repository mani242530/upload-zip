import React from 'react';
import ReactDOM from 'react-dom';
import ShippingInformation from './ShippingInformation';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';

import { IntlProvider } from 'react-intl';
import messages from './ShippingInformation.messages';

const intlProvider = new IntlProvider( { locale: 'en', messages }, {} );
const { intl } = intlProvider.getChildContext();

let appElement = document.createElement( 'div' );
appElement.id='js-cartpage';
document.body.appendChild( appElement );
jest.useFakeTimers( );

describe( '<ShippingInformation />', () => {
  let component;
  let props = {
    isSignedIn: true,
    holdDavPopUp:true,
    getAddressBook: jest.fn(),
    updateShipMethod: jest.fn(),
    focusOnModalClose: {},
    checkoutFormAddress2Open: {
      paymentAddressForm: false,
      shippingAddressForm: false
    },
    shippingInfo: {
      shippingStatus: 'Corrected',
      shippingAddress: {
        firstName: 'Jane',
        lastName: 'Doe',
        address1: '1000 Remington Boulevard',
        address2: 'Suite # 120',
        city: 'Bolingbrook',
        state: 'IL',
        postalCode: '60564',
        phoneNumber: '(510)-213-8347'
      },
      correctedShippingAddress: {
        firstName: 'Jane',
        lastName: 'Doe',
        address1: '1000 Remington Blvd',
        address2: 'Suite # 120',
        city: 'Bolingbrook',
        state: 'IL',
        postalCode: '60440',
        phoneNumber: '(510)-213-8347'
      },
      shipMethodInfo: {
        shipMethod: 'ups_ground',
        estimatedDelivery: 'Within 3 to 8 business days',
        cost: '$5.95',
        displayName: 'Standard Ground Shipping'
      },
      messages:
          [{
            messageDesc: 'A correction available for the specified shipping address.',
            messageKey: 'SHIP_ADDRESS_CORRECTION',
            messageType: 'Error'
          }]

    },
    showAddressBookSpinner: true
  };
  props.setEditAddressData=jest.fn();
  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <ShippingInformation { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'ShippingInformation' ).length ).toBe( 1 );
  } );

  it( 'renders Shipping Address Component without crashing', () => {
    expect( component.find( '.ShippingAddress' ).length ).toBe( 1 );
  } );


  it( 'renders without crashing', () => {
    expect( component.find( '#checkoutShippingMethod' ).length ).toBe( 1 );
  } );

  it( 'Should contain Values in the Shipping Method Main Container', () => {
    expect( component.find( '#checkoutShippingMethod .ShippingInformation__Item .ShippingInformation__Item--bold' ).length ).toBe( 1 );
  } );

  it( 'Should contain Values in the Shipping Method Sub Container', () => {
    expect( component.find( '#checkoutShippingMethod .ShippingInformation__Item .ShippingInformation__Item--normal' ).length ).toBe( 1 );
  } );

  it( 'Should contain Shipping Method Estimated Delivery with Cost Details', () => {
    let estimatedText = props.shippingInfo.shipMethodInfo.displayName+' - '+props.shippingInfo.shipMethodInfo.cost;
    expect( component.find( '.ShippingInformation__Item--bold' ).at( 1 ).text() ).toBe( estimatedText );
  } );

  it( 'Should contain Shipping Method Display Name', () => {
    expect( component.find( '.ShippingInformation__Item--normal' ).at( 1 ).text() ).toBe( props.shippingInfo.shipMethodInfo.estimatedDelivery );
  } );

  it( 'should render correct Text for Change Shipping Method', () => {
    expect( component.find( '.ShippingInformation__Item .ShippingInformation__Item .btn' ).text() ).toEqual( messages.changeShippingMethod.defaultMessage );
  } );


  it( 'Should not renders Shipping Address Form Component when User Logged In', () => {
    expect( component.find( '.CheckoutAddressForm' ).length ).toBe( 0 );
  } );

  it( 'renders error messages', () => {
    expect( component.find( '.ShippingInformation__messages' ).length ).toBe( 1 );
    expect( component.find( 'ResponseMessages' ).length ).toBe( 1 );
  } );

  it( 'Should not renders modal', () => {
    expect( component.find( '.CheckoutModal' ).length ).toBe( 0 );
  } );

  it( 'renders modal Component and after modal is closed it sets focus to change shipping method', () => {

    props.shippingInfo.shippingStatus='CorrectedAddress';
    props.holdDavPopUp=false;

    let componentCheckoutModal = mountWithIntl(
      <Provider store={ store }>
        <ShippingInformation { ...props }/>
      </Provider>
    );
    expect( componentCheckoutModal.find( 'CheckoutModal' ).length ).toBe( 1 );
    expect( componentCheckoutModal.find( 'ShippingAddress' ).length ).toBe( 1 );

    componentCheckoutModal.find( 'ShippingInformation' ).instance().state.showDefaultShippingMethod = true;
    componentCheckoutModal.find( 'ShippingInformation' ).instance().forceUpdate();

    let nodeTest = componentCheckoutModal.find( 'CheckoutModal' );
    nodeTest.instance().state.isModalOpen = true;
    nodeTest.instance().toogleModal();
    jest.runAllTimers();
    expect( document.activeElement.innerHTML ).toBe( messages.changeShippingMethod.defaultMessage );


  } );


  it( 'should show the spinner if the addressBook data is still loading', () => {
    expect( component.find( '.ShippingInformation__spinner' ).length ).toBe( 1 );
  } );

  it( 'should make opacity to 70% on default shipping address view if the addressbook data is still in loading state', () => {
    expect( component.find( '.ShippingInformation__showShipMethodSpinner' ).length ).toBe( 1 );
  } );

  props.shippingSuccess = true;
  props.updateShippingStatus = jest.fn();
  props.handleScrollView=jest.fn();
  props.isSignedIn = true;
  props.getAddressBook= jest.fn();
  const component1 = mountWithIntl(
    <Provider store={ store }>
      <ShippingInformation { ...props }/>
    </Provider>
  );
  const instance = component1.find( 'ShippingInformation' ).instance();
  it( 'should change the errorMsg value', () => {
    expect( instance.state.errorMsg ).toEqual( false );
    instance.setErrorMsg();
    expect( instance.state.errorMsg ).toEqual( true );
  } );

  it( 'should change the hazmatAddressChange value', () => {
    instance.handleHazmatChange();
    expect( instance.state.hazmatAddressChange ).toEqual( true );
  } );

  it( 'should change the setShippingAddress value', () => {
    expect( instance.state.changeAddress ).toEqual( false );
    expect( instance.state.hazmatAddressChange ).toEqual( true );
    instance.setShippingAddress();
    expect( props.updateShippingStatus ).toHaveBeenCalledWith( props.shippingSuccess );
    expect( instance.state.changeAddress ).toEqual( true );
    expect( props.getAddressBook ).toHaveBeenCalled();
    expect( instance.state.hazmatAddressChange ).toEqual( false );
    expect( props.handleScrollView ).toHaveBeenCalledWith( 'checkoutShippingHeader' );
  } );

  describe( 'error messages for shipping', () => {
    props.shippingInfo.shippingStatus='IncompatibleShipping';

    let component2 = mountWithIntl(
      <Provider store={ store }>
        <ShippingInformation { ...props }/>
      </Provider>
    );
    it( 'renders error message contents', () => {
      expect( component2.find( '.ShippingInformation__messages--info' ).length ).toBe( 2 );
      expect( component2.find( '.ShippingInformation__messages--info' ).at( 0 ).text() ).toBe( messages.methodInfo.defaultMessage );
      expect( component2.find( '.ShippingInformation__messages--info' ).at( 1 ).text() ).toBe( messages.addressError.defaultMessage );
    } );

    it( 'renders anchor href', () => {
      expect( component2.find( '.ShippingInformation__messages .Anchor' ).at( 0 ).props().href ).toContain( '#' );
      expect( component2.find( '.ShippingInformation__messages .Anchor' ).at( 1 ).props().href ).toContain( '/bag' );
    } );
    it( 'renders response message component', () => {
      expect( component2.find( 'ResponseMessages' ).length ).toBe( 1 );
    } );


  } );

} );

describe( '<ShippingInformation />', () => {
  let component3;
  let props = {
    isSignedIn: false,
    shippingInfo: {
      shippingStatus : 'complete',
      shippingAddress:{},
      checkoutFormAddress2Open: {
        paymentAddressForm: false,
        shippingAddressForm: false
      },
      correctedShippingAddress: {
        firstName: 'Jane',
        lastName: 'Doe',
        address1: '1000 Remington Blvd',
        address2: 'Suite # 120',
        city: 'Bolingbrook',
        state: 'IL',
        postalCode: '60440',
        phoneNumber: '(510)-213-8347'
      },
      messages: [{
        messageDesc: 'A correction available for the specified shipping address.',
        messageKey: 'SHIP_ADDRESS_CORRECTION',
        messageType: 'Error'
      }]
    },
    editAddressData:{
      firstName: 'Jane',
      lastName: 'Doe',
      address1: '1000 Remington Blvd',
      address2: 'Suite # 120',
      city: 'Bolingbrook',
      state: 'IL',
      postalCode: '60440',
      phoneNumber: '(510)-213-8347'
    },
    cartAndCheckout: {
      multiFormAddressOpen: false
    },
    tabIndex: 10,
    toggleInputFieldShippingDisplay : jest.fn(),
    setEditAddressData: jest.fn(),
    checkoutFormAddressOpen: {
      shippingAddressForm: true
    },
    checkoutFormAddress2Open: {
      shippingAddressForm: true
    }
  };

  const store = configureStore( {}, CONFIG );
  component3 = mountWithIntl(
    <Provider store={ store }>
      <ShippingInformation { ...props }/>
    </Provider>
  );

  it( 'Should not renders Shipping Address Component for Guest User', () => {
    expect( component3.find( '.ShippingAddress' ).length ).toBe( 0 );
  } );

  it( 'Should not renders Shipping Method Component for Guest User when shipping status is incompatable', () => {
    props.shippingInfo.shippingStatus='IncompatibleShipping';
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <ShippingInformation { ...props }/>
      </Provider>
    );
    expect( component1.find( '.ShippingMethod' ).length ).toBe( 0 );
  } );
  it( 'renders saved Shipping Address Form Component without crashing for Guest User', () => {
    expect( component3.find( 'CheckoutAddressForm' ).length ).toBe( 1 );
    expect( component3.find( 'CheckoutModal' ).length ).toBe( 0 );
  } );
  it( 'renders empty checkout Address Form Component without crashing for Guest User', () => {
    props.shippingInfo.shippingStatus='CorrectedAddress';
    props.holdDavPopUp=false;
    let component4 = mountWithIntl(
      <Provider store={ store }>
        <ShippingInformation { ...props }/>
      </Provider>
    );
    expect( component4.find( 'CheckoutAddressForm' ).length ).toBe( 1 );
    expect( component4.find( 'CheckoutModal' ).length ).toBe( 1 );
  } );

  it( 'renders shippingmethod Info alert for Guest User upon page load', () => {
    let props5 = {
      isSignedIn: false,
      holdDavPopUp:false,
      getAddressBook: jest.fn(),
      setEditAddressData: jest.fn(),
      handleScrollView: jest.fn(),
      toggleShipMethodInfoFlag: jest.fn(),
      getEstimatedDelivery: jest.fn(),
      checkoutFormAddressOpen: {
        shippingAddressForm: true
      },
      checkoutFormAddress2Open: {
        shippingAddressForm: true
      },
      shippingInfo: {
        shippingStatus: 'Corrected',
        shippingAddress: {
          lastName: 'last',
          country: 'US',
          address2: null,
          city: 'APO',
          address1: 'PSC3 box 7263',
          postalCode: '96266',
          firstName: 'test',
          phoneNumber: '469-901-4395',
          state: 'AP',
          email: 'tst@ulta.com'
        },
        messages: [
          {
            messageKey: 'ERR_SHIP_PRICE_CHANGED',
            messageType: 'Info',
            messageRef: 'shipMethodInfo',
            messageDesc: 'Free or discounted shipping is available in the Continental U.S. only and excludes PO Boxes, APO/FPO addresses.'
          }
        ],
        shipMethodInfo: {
          cost: '$5.95',
          displayName: 'Standard Shipping',
          shipMethod: 'ups_ground',
          estimatedDelivery: null
        }
      }
    };
    let component5 = mountWithIntl(
      <Provider store={ store }>
        <ShippingInformation { ...props5 }/>
      </Provider>
    );
    expect( component5.find( 'ResponseMessages' ).length ).toBe( 1 );
    expect( component5.find( '.ResponseMessages__message--warning-alert' ).length ).toBe( 1 );
    expect( props5.handleScrollView ).not.toBeCalledWith( 'shipMethodInfoSection' );
  } );

  it( 'should invoke handleScrollView with  shipMethodInfoSection on componentDidUpdate if the condition is satisfied ', () => {
    let props5 = {
      isSignedIn: false,
      holdDavPopUp:false,
      getAddressBook: jest.fn(),
      setEditAddressData: jest.fn(),
      handleScrollView: jest.fn(),
      toggleShipMethodInfoFlag: jest.fn(),
      getEstimatedDelivery: jest.fn(),
      checkoutFormAddressOpen: {
        shippingAddressForm: true
      },
      checkoutFormAddress2Open: {
        shippingAddressForm: true
      },
      shippingInfo : {
        shippingStatus: 'Complete',
        shippingAddress: {
          lastName: 'last',
          country: 'US',
          address2: null,
          city: 'APO',
          address1: 'PSC3 box 7263',
          postalCode: '96266',
          firstName: 'test',
          phoneNumber: '469-901-4395',
          state: 'AP',
          email: 'tst@ulta.com'
        },
        messages: [
          {
            messageKey: 'ERR_SHIP_PRICE_CHANGED',
            messageType: 'Info',
            messageRef: 'shipMethodInfo',
            messageDesc: 'Free or discounted shipping is available in the Continental U.S. only and excludes PO Boxes, APO/FPO addresses.'
          }
        ],
        shipMethodInfo: {
          cost: '$5.95',
          displayName: 'Standard Shipping',
          shipMethod: 'ups_ground',
          estimatedDelivery: null
        }
      }
    };
    let component5 = mountWithIntl(
      <Provider store={ store }>
        <ShippingInformation { ...props5 }/>
      </Provider>
    );

    const prevProp = { ...props,
      shippingInfo: {
        shippingStatus: 'Complete',
        shippingAddress: {
          firstName: 'Jane',
          lastName: 'Doe',
          address1: '1000 Remington Boulevard',
          address2: 'Suite # 120',
          city: 'Bolingbrook',
          state: 'IL',
          postalCode: '60564',
          phoneNumber: '(510)-213-8347'
        },
        shipMethodInfo:{
          cost: 'FREE',
          displayName: null,
          shipMethod: 'free_shipping',
          estimatedDelivery: null
        }
      }
    };
    const wrapper = component5.find( 'ShippingInformation' ).instance()
    wrapper.componentDidUpdate( prevProp );
    expect( component5.find( 'ResponseMessages' ).length ).toBe( 1 );
    expect( component5.find( '.ResponseMessages__message--warning-alert' ).length ).toBe( 1 );
    expect( props5.handleScrollView ).toBeCalledWith( 'shipMethodInfoSection' );
  } );

} );
