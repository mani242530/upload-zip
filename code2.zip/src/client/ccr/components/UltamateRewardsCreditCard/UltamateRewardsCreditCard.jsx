import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './UltamateRewardsCreditCard.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './UltamateRewardsCreditCard.messages';
import ChevronRightSVG from 'shared/components/Icons/chevron_right';
import rewardsCC_footer from 'static/rewardsCC_footer.png';
import Anchor from 'shared/components/Anchor/Anchor';
import Image from 'shared/components/Image/Image';
import isEmpty from 'lodash/isEmpty';
import 'shared/components/Gutter/Gutter.css';
const propTypes = {
  handleAddCreditCard: PropTypes.func
}

class UltamateRewardsCreditCard extends Component{

  constructor( props ){
    super( props );
    this.addNewCreditCard = this.addNewCreditCard.bind( this );
  }

  addNewCreditCard( e ){
    e.preventDefault();
    if( this.props.handleAddCreditCard ){
      this.props.handleAddCreditCard( 'default' );
    }
    const el = document.getElementById( 'creditCardNumber' );
    if( el ){
      el.focus();
    }
  }

  render(){

    const {
      ultamateRewardsCCInfo,
      isSignedIn
    } = this.props;



    return (
      <div className='UltamateRewardsCreditCard Gutter'>
        { ( () => {
          try {
            if( ultamateRewardsCCInfo && !isEmpty( ultamateRewardsCCInfo ) ){
              return (
                <div className='UltamateRewardsCreditCard--applynow'>
                  <div className='UltamateRewardsCreditCard--applynow--card'>
                    <Image
                      src={ rewardsCC_footer }
                      alt={ formatMessage( messages.learnmore ) }
                      lazyLoad={ true }
                      width={ 100 }
                    />
                  </div>
                  <div className='UltamateRewardsCreditCard--applynow--link'>
                    <div>
                      { ultamateRewardsCCInfo.msgHeader }
                    </div>
                    <div className='msgTxt'>
                      { ultamateRewardsCCInfo.msgTxt }
                    </div>
                    <div className='link'>
                      { ( () => {
                        let analyticsEvent =
                        {
                          eventName: 'trackCreditCardBanner',
                          'data': {
                            'data-credit-card-promo':ultamateRewardsCCInfo.action
                          }
                        };

                        if( ultamateRewardsCCInfo.hasUltaCC && !ultamateRewardsCCInfo.appliedToProfile ){
                          return (
                            <Anchor
                              url='#'
                              clickHandler={ this.addNewCreditCard }
                              ariaLabel={ ultamateRewardsCCInfo.action +' '+ formatMessage( messages.applyNowAriaLabel ) }
                              title={ ultamateRewardsCCInfo.action +' '+ formatMessage( messages.applyNowAriaLabel ) }
                              analyticsEvent={ analyticsEvent }
                              tabIndex={ this.props.tabIndex + 1 }
                            >
                              { formatMessage( messages.addNowLabel ) }
                              <span><ChevronRightSVG /></span>
                            </Anchor>
                          );
                        }
                        else if( ultamateRewardsCCInfo.preScreenId && ultamateRewardsCCInfo.action === 'get' ){
                          return (
                            <Anchor
                              url={ `/creditcards/c/offer?id=${ultamateRewardsCCInfo.preScreenId}` }
                              ariaLabel={ ultamateRewardsCCInfo.action +' '+ formatMessage( messages.applyNowAriaLabel ) }
                              title={ ultamateRewardsCCInfo.action +' '+ formatMessage( messages.applyNowAriaLabel ) }
                              analyticsEvent={ analyticsEvent }
                              tabIndex={ this.props.tabIndex + 2 }
                            >
                              { formatMessage( messages.getItNowLabel ) }
                              <span><ChevronRightSVG /></span>
                            </Anchor>
                          );
                        }
                        else if( ultamateRewardsCCInfo.action === 'apply' && isSignedIn === true ){
                          return (
                            <Anchor
                              url='/creditcards/c/application'
                              ariaLabel={ ultamateRewardsCCInfo.action +' '+ formatMessage( messages.applyNowAriaLabel ) }
                              title={ ultamateRewardsCCInfo.action +' '+ formatMessage( messages.applyNowAriaLabel ) }
                              analyticsEvent={ analyticsEvent }
                              tabIndex={ this.props.tabIndex + 3 }
                            >
                              { formatMessage( messages.applyNowLabel ) }
                              <span><ChevronRightSVG /></span>
                            </Anchor>
                          );
                        }
                        else if( ultamateRewardsCCInfo.action === 'apply' && !isSignedIn ){
                          return (
                            <Anchor
                              url='/creditcards/apply'
                              ariaLabel={ ultamateRewardsCCInfo.action +' '+ formatMessage( messages.applyNowAriaLabel ) }
                              title={ ultamateRewardsCCInfo.action +' '+ formatMessage( messages.applyNowAriaLabel ) }
                              analyticsEvent={ analyticsEvent }
                              tabIndex={ this.props.tabIndex + 4 }
                            >
                              { formatMessage( messages.applyNowLabel ) }
                              <span><ChevronRightSVG /></span>
                            </Anchor>
                          );
                        }
                      } )() }
                    </div>
                  </div>
                </div>
              );
            }
          }
          catch ( e ){
          }
        } )() }
      </div>
    );
  }
}

UltamateRewardsCreditCard.propTypes = propTypes;

export default UltamateRewardsCreditCard;
