/*
 * UltamateRewardsCreditCard Messages
 *
 * This contains all the text for the UltamateRewardsCreditCard component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  learnmore: {
    id: 'i18n.MobileFooterUltamateRewards.learnmore',
    defaultMessage: 'Learn More & Apply or Add'
  },
  applyNowAriaLabel: {
    id: 'i18n.QualifiedShippingMethodList.DoneAriaLabel',
    defaultMessage: 'Ulta Ultamate Rewards Credit Card'
  },
  applyNowLabel: {
    id: 'i18n.UltamateRewards.ApplyNowLabel',
    defaultMessage: 'Apply Now'
  },
  getItNowLabel: {
    id: 'i18n.UltamateRewards.GetItNowLabel',
    defaultMessage: 'Get It Now'
  },
  addNowLabel: {
    id: 'i18n.UltamateRewards.AddNowLabel',
    defaultMessage: 'Add Now'
  }

} );
