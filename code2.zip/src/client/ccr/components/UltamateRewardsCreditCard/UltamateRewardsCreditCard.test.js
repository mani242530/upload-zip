import React from 'react';
import ReactDOM from 'react-dom';
import UltamateRewardsCreditCard from './UltamateRewardsCreditCard';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';
import messages from './UltamateRewardsCreditCard.messages';

describe( '<UltamateRewardsCreditCard />', () => {
  let component;
  let props = {
    ultamateRewardsCCInfo: {
      hasUltaCC: true,
      appliedToProfile: false,
      msgHeader: 'Save 20% on this order! Plus start earning 2 points per dollar!',
      msgTxt: 'Get the Ultamate Rewards Credit Card',
      action: 'add'
    }
  };

  let rewardsCCInfo = props.ultamateRewardsCCInfo;
  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <UltamateRewardsCreditCard { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'UltamateRewardsCreditCard' ).length ).toBe( 1 );
  } );

  it( 'should render Ultamate Rewards Credit Card message text', () => {
    expect( component.find( '.UltamateRewardsCreditCard .UltamateRewardsCreditCard--applynow--link .msgTxt' ).text() ).toEqual( rewardsCCInfo.msgTxt );
  } );

  it( 'should render Ulta Ultamate Rewards Credit Card Add Now action', () => {
    expect( component.find( '.UltamateRewardsCreditCard .UltamateRewardsCreditCard--applynow--link .Anchor' ).text() ).toEqual( messages.addNowLabel.defaultMessage );
    expect( component.find( '.UltamateRewardsCreditCard .UltamateRewardsCreditCard--applynow--link .Anchor' ).props().href ).toBe( '#' );
  } );

  it( 'should render Ulta Ultamate Rewards Credit Card Apply Now action for anonymous user', () => {
    let component1;
    let props1 = {
      isSignedIn:false,
      ultamateRewardsCCInfo: {
        hasUltaCC: false,
        msgHeader: 'Save 20% on this order! Plus start earning 2 points per dollar!',
        appliedToProfile: false,
        action: 'apply',
        msgTxt: 'Get the Ultamate Rewards Credit Card'
      }
    };

    let rewardsCCInfo1 = props1.ultamateRewardsCCInfo;
    const store1 = configureStore( {}, CONFIG );
    component1 = mountWithIntl(
      <Provider store={ store1 }>
        <UltamateRewardsCreditCard { ...props1 }/>
      </Provider>
    );

    expect( component1.find( '.UltamateRewardsCreditCard .UltamateRewardsCreditCard--applynow--link .Anchor' ).text() ).toEqual( messages.applyNowLabel.defaultMessage );
    expect( component1.find( '.UltamateRewardsCreditCard .UltamateRewardsCreditCard--applynow--link .Anchor' ).props().href ).toBe( '//www.ulta.com/creditcards/apply' );
  } );

  it( 'should render Ulta Ultamate Rewards Credit Card Apply Now action for signed In user', () => {
    let component1;
    let props1 = {
      isSignedIn:true,
      ultamateRewardsCCInfo: {
        hasUltaCC: false,
        msgHeader: 'Save 20% on this order! Plus start earning 2 points per dollar!',
        appliedToProfile: false,
        action: 'apply',
        msgTxt: 'Get the Ultamate Rewards Credit Card'
      }

    };

    let rewardsCCInfo1 = props1.ultamateRewardsCCInfo;
    const store1 = configureStore( {}, CONFIG );
    component1 = mountWithIntl(
      <Provider store={ store1 }>
        <UltamateRewardsCreditCard { ...props1 }/>
      </Provider>
    );

    expect( component1.find( '.UltamateRewardsCreditCard .UltamateRewardsCreditCard--applynow--link .Anchor' ).text() ).toEqual( messages.applyNowLabel.defaultMessage );
    expect( component1.find( '.UltamateRewardsCreditCard .UltamateRewardsCreditCard--applynow--link .Anchor' ).props().href ).toBe( '//www.ulta.com/creditcards/c/application' );
  } );

  it( 'should render Ulta Ultamate Rewards Credit Card Get it Now action', () => {
    let component1;
    let props1 = {
      ultamateRewardsCCInfo: {
        hasUltaCC: false,
        msgHeader: 'Save 20% on this order! Plus start earning 2 points per dollar!',
        cardType: 'Ultamate Rewards Credit Card',
        appliedToProfile: false,
        action: 'get',
        msgTxt: 'Sasha, you\'re pre-approved for the Ultamate Rewards Credit Card!',
        preScreenId: '100000000001'
      }
    };

    let rewardsCCInfo1 = props1.ultamateRewardsCCInfo;
    const store1 = configureStore( {}, CONFIG );
    component1 = mountWithIntl(
      <Provider store={ store1 }>
        <UltamateRewardsCreditCard { ...props1 }/>
      </Provider>
    );

    expect( component1.find( '.UltamateRewardsCreditCard .UltamateRewardsCreditCard--applynow--link .Anchor' ).text() ).toEqual( messages.getItNowLabel.defaultMessage );
    expect( component1.find( '.UltamateRewardsCreditCard .UltamateRewardsCreditCard--applynow--link .Anchor' ).props().href ).toBe( '//www.ulta.com/creditcards/c/offer?id=100000000001' );
  } );

  props.handleAddCreditCard =jest.fn();
  component = mountWithIntl(
    <Provider store={ store }>
      <UltamateRewardsCreditCard { ...props }/>
    </Provider>
  );

  it( 'should call the addNewCreditCard method', () => {
    component.find( 'Anchor' ).simulate( 'click', { preventDefault(){} } );
    expect( props.handleAddCreditCard ).toHaveBeenCalledWith( 'default' );
  } );

} );
