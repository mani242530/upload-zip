/**
 * UserRewardsLookup
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './UserRewardsLookup.css';
import { Field, reduxForm } from 'redux-form';
import { Collapse } from 'react-bootstrap';
import MixedMenuButton from 'shared/components/MixedMenuButton/MixedMenuButton';
import messages from './UserRewardsLookup.messages';
import Anchor from 'shared/components/Anchor/Anchor';
import InputField from 'shared/components/InputField/InputField';
import UltamateRewardsMemberId from 'abuy/components/UltamateRewards/UltamateRewardsMemberId/UltamateRewardsMemberId';

import {
  checkoutPageMemberIdLengthValidation
} from 'utils/FormValidations/FormValidations';
import ChevronRightSVG from 'shared/components/Icons/chevron_right';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import Divider from 'shared/components/Divider/Divider';
import { has, isUndefined, isEmpty } from 'lodash';
import { formatMessage } from 'shared/components/Global/Global';

const propTypes = {
  isModalOpen: PropTypes.bool,
  modalStatus: PropTypes.func,
  getRewardsLookup: PropTypes.func,
  setCartRightPanelCollapse: PropTypes.func,
  cartRightPanelCollapse: PropTypes.object,
  creditCardDetails: PropTypes.object,
  user: PropTypes.object,
  isSignedIn: PropTypes.bool,
  preScreenBeautyClubNumber: PropTypes.string,
  rewardPointsEarned: PropTypes.string,
  joinNowRewardsError: PropTypes.array,
  isRewardsMember: PropTypes.bool,
  lpsTurnOff: PropTypes.bool,
  joinNowRewards: PropTypes.func,
  broadcastMessage: PropTypes.func
}

const defaultProps = {}

const initialState = {
  isModalOpen: false
};


/**
 * Class
 * @extends React.Component
 */
class UserRewardsLookup extends Component{

  /**
   * Create a UserRewardsLookup
   */
  constructor( props ){
    super( props );
    this.handleOpenPopup = this.handleOpenPopup.bind( this );
    this.rewardPointLookup = this.rewardPointLookup.bind( this );
  }

  handleOpenPopup( e ){
    this.props.modalStatus();
  }

  rewardPointLookup( value ){
    if( value.length !== 13 ){
      return;
    }
    const input = {
      loyaltyMemberId: value
    }
    this.props.getRewardsLookup( input )
  }

  componentDidUpdate( prevProps ){
    // Below logic is for screen reader to read out the error message when ever the user enters invalid Member Id
    if( prevProps.user.rewardsLookup !== this.props.user.rewardsLookup ){
      if( this.props.user.rewardsLookup && !this.props.user.rewardsLookup.success ){
        this.props.broadcastMessage( this.props.user.rewardsLookup.messages[0].messageDesc );
      }
      else {
        this.props.broadcastMessage( '' );
      }
    }
  }

  /**
   * Renders the UserRewardsLookup component
   */
  render(){

    const {
      setCartRightPanelCollapse,
      cartRightPanelCollapse,
      creditCardDetails
    } = this.props;


    let errorMessage = null;

    if( this.props.user.rewardsLookup && !this.props.user.rewardsLookup.success ){
      errorMessage=this.props.user.rewardsLookup.messages[0].messageDesc
    }
    let textAreaCount = 13;

    return (
      <div className='UserRewardsLookup'>
        { ( () =>{

          if( !this.props.isSignedIn ){
            if( this.props.preScreenBeautyClubNumber && this.props.preScreenBeautyClubNumber !== null
              && this.props.preScreenBeautyClubNumber !== '' ){
              let successMessage = formatMessage( messages.userRewardsMessage );
              const rewards = this.props.rewardPointsEarned;

              if( this.props.user.rewardsLookup && this.props.user.rewardsLookup.success ){
                const rewardsEarned = this.props.user.rewardsLookup.rewardPointEarned

                if( rewardsEarned > 0 ){
                  successMessage = formatMessage( messages.userRewards, { rewardsEarned } )
                }

              }
              return (
                <div>
                  <span className='UserRewardsLookup__pointEarned'>
                    { formatMessage( messages.pointEarned, { rewards } ) }
                  </span>
                  <span className='UserRewardsLookup__pointOrder'>
                    { formatMessage( messages.pointOrder ) }
                  </span>
                  <div className='UserRewardsLookup__creditCard'>
                    { formatMessage( messages.creditCard ) }
                  </div>
                </div>
              );
            }
            else {
              let successMessage = formatMessage( messages.userRewardsMessage );

              if( this.props.user.rewardsLookup && this.props.user.rewardsLookup.success ){
                const rewardsEarned = this.props.user.rewardsLookup.rewardPointEarned

                if( rewardsEarned > 0 ){
                  successMessage = formatMessage( messages.userRewards, { rewardsEarned } )
                }

              }
              return (
                <div>
                  <MixedMenuButton
                    label={ formatMessage( messages.userRewardsTitle ) }
                    details={ successMessage }
                    pointerType='collapse'
                    onClick={ e =>{
                      e.preventDefault();
                      setCartRightPanelCollapse( 'userRewards' );
                    } }
                    pointerMinus={ cartRightPanelCollapse.userRewards }
                  />
                  <Collapse in={ cartRightPanelCollapse.userRewards }>
                    <div>
                      <div className='UserRewardsLookup__CollapseContainer'>

                        <div className='UserRewardsLookup__inputField'>

                          <InputField
                            name='memberID'
                            formatter={ { pattern: '9999999999999' } }
                            type='tel'
                            label={ formatMessage( messages.placeholderText ) }
                            validate={ checkoutPageMemberIdLengthValidation }
                            handleChange={ this.rewardPointLookup }
                            maxLength={ textAreaCount }
                            formName={ 'rewards' }
                            trackAnalytics={ true }

                          />
                          { ( ()=>{
                            if( errorMessage ){
                              return (
                                <div className='UserRewardsLookup__errors'>
                                  <ResponseMessages
                                    message={ errorMessage }
                                  />
                                </div>
                              )
                            }
                          } )() }

                          { ( () => {
                            if( has( this.props.user, 'rewardsLookup.success' ) && has( creditCardDetails, 'paymentInfo.paymentDetails' ) && this.props.user.rewardsLookup.success ){
                              if( creditCardDetails.paymentInfo.paymentDetails.creditCardType === 'Ultamate Rewards MasterCard' || creditCardDetails.paymentInfo.paymentDetails.creditCardType === 'Ultamate Rewards Credit Card' ){
                                return (
                                  <div className='UserRewardsLookup__creditCard'>
                                    { formatMessage( messages.creditCard ) }
                                  </div>
                                );
                              }
                            }
                          } )() }

                          <UltamateRewardsMemberId
                            { ...this.props }
                            loadModelContainerId='#js-cartpage'
                          />


                        </div>
                        <div className='UserRewardsLookup__forgotField'>
                          <Anchor
                            url='#'
                            clickHandler={ this.handleOpenPopup }
                          >
                            { formatMessage( messages.findMemberID ) }
                          </Anchor>
                        </div>
                      </div>
                    </div>
                  </Collapse>
                </div>
              );
            }

          }
          else {
            return (
              <div className='UserRewardsLookup__rewardPointsContainer'>
                { ( () =>{
                  const rewards = this.props.rewardPointsEarned;
                  if( rewards !== null && rewards !== 0 ){
                    return (
                      <div>
                        <span className='UserRewardsLookup__pointEarned'>
                          { formatMessage( messages.pointEarned, { rewards } ) }
                        </span>
                        <span className='UserRewardsLookup__pointOrder'>
                          { formatMessage( messages.pointOrder ) }
                        </span>
                      </div>
                    )
                  }
                } )() }
                <div className='UserRewardsLookup__reviewOrder'>
                  { ( () =>{
                    if( !isEmpty( this.props.joinNowRewardsError ) && this.props.joinNowRewardsError.length > 0 && !this.props.isRewardsMember ){
                      return (
                        <ResponseMessages
                          message={ this.props.joinNowRewardsError[0].messageDesc }
                        />
                      )
                    }
                  } )() }
                  { ( () =>{
                    if( !isEmpty( this.props.joinNowRewardsError ) && this.props.joinNowRewardsError.length > 0 && this.props.isRewardsMember ){
                      return (
                        this.props.joinNowRewardsError[0].messageDesc
                      )
                    }
                    else {
                      return (

                        <div>

                          { ( () =>{
                            if( isUndefined( this.props.isRewardsMember ) || !this.props.isRewardsMember && !this.props.lpsTurnOff ){
                              return (
                                <div className='UserRewardsLookup__message'>
                                  <span className='UserRewardsLookup__pointEarned'>
                                    { formatMessage( messages.pointEarnedUserRewardsMessage ) }
                                  </span>
                                  <span className='UserRewardsLookup__pointOrder'>
                                    { formatMessage( messages.pointOrderUserRewardsMessage ) }
                                  </span>
                                  <Anchor
                                    url='#'
                                    clickHandler={ this.props.joinNowRewards }
                                  >
                                    <div className='UserRewardsLookup__rewardsJoinNow'>
                                      { formatMessage( messages.earnRewards ) }
                                      <div className='UserRewardsLookup__joinNow'>
                                        { formatMessage( messages.joinNow ) }
                                        <span><ChevronRightSVG /></span>
                                      </div>
                                    </div>
                                  </Anchor>
                                </div>
                              )
                            }

                          } )() }


                        </div>
                      )
                    }

                  } )() }
                </div>
                { ( () =>{
                  if( has( creditCardDetails, 'paymentInfo.paymentDetails' ) ){
                    if( has( creditCardDetails, 'paymentInfo.paymentDetails.creditCardType' ) && ( creditCardDetails.paymentInfo.paymentDetails.creditCardType === 'Ultamate Rewards MasterCard' || creditCardDetails.paymentInfo.paymentDetails.creditCardType === 'Ultamate Rewards Credit Card' ) ){
                      return (
                        <div className='UserRewardsLookup__creditCard'>
                          { formatMessage( messages.creditCard ) }
                        </div>
                      );
                    }
                  }
                } )() }
              </div>
            )
          }
        } )() }
        <div className='UserRewardsLookup__divider'>
          <Divider dividerType={ 'gray' }/>
        </div>


      </div>
    );
  }
}

UserRewardsLookup.propTypes = propTypes;
UserRewardsLookup.defaultProps = defaultProps;

export default reduxForm( {
  form: 'UserRewardsLookup'
} )( UserRewardsLookup );