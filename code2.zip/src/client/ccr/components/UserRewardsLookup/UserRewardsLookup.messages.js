/*
 * UserRewardsLookup Messages
 *
 * This contains all the text for the UserRewardsLookup component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  userRewardsTitle: {
    id: 'i18n.UserRewardsLookup.userRewardsTitle',
    defaultMessage: 'Add Your Ultamate Rewards MemberID'
  },
  userRewardsMessage: {
    id: 'i18n.UserRewardsLookup.userRewardsMessage',
    defaultMessage: 'Earn  points with order!'
  },
  userRewards: {
    id: 'i18n.UserRewardsLookup.userRewards',
    defaultMessage: 'Earn {rewardsEarned} points with order!'
  },
  findMemberID: {
    id: 'i18n.UserRewardsLookup.findMemberID',
    defaultMessage: 'Need to find your Member ID?'
  },
  placeholderText: {
    id: 'i18n.UserRewardsLookup.placeholderText',
    defaultMessage: 'Member ID'
  },
  continueMessage: {
    id: 'i18n.UserRewardsLookup.continueMessage',
    defaultMessage: 'CONTINUE APPLICATION'
  },
  pointEarned: {
    id: 'i18n.UserRewardsLookup.pointEarned',
    defaultMessage: '{rewards} points '
  },
  pointOrder: {
    id: 'i18n.UserRewardsLookup.pointOrder',
    defaultMessage: 'earned with order!'
  },
  creditCard: {
    id: 'i18n.UserRewardsLookup.creditCard',
    defaultMessage: 'Credit card points will be awarded to your account once your monthly billing statement has closed.'
  },
  earnRewards:{
    id: 'i18n.UserRewardsLookup.earnRewards',
    defaultMessage: 'Sign up for Ultamate Rewards to earn points with every purchase!'
  },
  joinNow:{
    id: 'i18n.UserRewardsLookup.joiNow',
    defaultMessage: ' Join Now'
  },
  pointEarnedUserRewardsMessage: {
    id: 'i18n.UserRewardsLookup.pointEarnedUserRewardsMessage',
    defaultMessage: 'Earn points '
  },
  pointOrderUserRewardsMessage: {
    id: 'i18n.UserRewardsLookup.pointOrderUserRewardsMessage',
    defaultMessage: 'with this order!'
  }

} );
