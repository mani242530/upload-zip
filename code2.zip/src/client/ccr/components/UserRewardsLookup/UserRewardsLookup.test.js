import React from 'react';
import ReactDOM from 'react-dom';
import UserRewardsLookup from './UserRewardsLookup';
import messages from './UserRewardsLookup.messages';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store'
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';

let appElement = document.createElement( 'div' );
appElement.id='js-cartpage';
document.body.appendChild( appElement );

describe( '<UserRewardsLookup />', () =>{

  describe( 'UserRewardsLookup for Signed in user', () =>{
    let component;
    let props = {
      setCartRightPanelCollapse: jest.fn(),
      cartRightPanelCollapse: {
        userRewards: false
      },
      user: {
        rewardsLookup: false,
        isSignedIn: true,
        isRewardsMember: false
      },
      preScreenBeautyClubNumber: 'sdsd',
      rewardPointsEarned: 0,
      isSignedIn: true,
      isRewardsMember: false,
      joinNowRewardsError: [],
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        editCreditCardData: {},
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        }
      },
      joinNowRewards: jest.fn(),
      lpsTurnOff: false
    }
    const store = configureStore( {}, CONFIG );
    component = mountWithIntl(
      <Provider store={ store }>
        <UserRewardsLookup { ...props } />
      </Provider> );
    it( 'renders without crashing', () =>{
      expect( component.find( 'UserRewardsLookup' ).length ).toBe( 1 );
    } );
    it( 'should show the rewrdslookup Earn points message for user not signed up for Rewards program', () =>{
      expect( component.find( '.UserRewardsLookup__message' ).length ).toBe( 1 );
      expect( component.find( '.UserRewardsLookup__pointEarned' ).at( 0 ).text() ).toBe( messages.pointEarnedUserRewardsMessage.defaultMessage );
    } )
    it( 'should show the rewrdslookup message for user not signed up for Rewards program', () =>{
      expect( component.find( '.UserRewardsLookup__pointOrder' ).text() ).toBe( messages.pointOrderUserRewardsMessage.defaultMessage );
    } )
    it( 'Should contain Join Now message if the user is not signed up for Rewards program', () =>{
      expect( component.find( '.UserRewardsLookup__rewardsJoinNow' ).length ).toBe( 1 );
    } );

    it( 'Should show Join Now message if the user is not signed up for Rewards program', () =>{
      expect( component.find( '.UserRewardsLookup__rewardsJoinNow' ).text() ).toBe( messages.earnRewards.defaultMessage+messages.joinNow.defaultMessage );
    } );

    it( 'Should contain Join Now message and ChevronRightSVG If the user is not signed up for Rewards program', () =>{
      expect( component.find( '.UserRewardsLookup__rewardsJoinNow' ).find( 'svg' ).length ).toBe( 1 );
    } );

    it( 'Should contain Join Now link if the user is not signed up for Rewards program', () =>{
      expect( component.find( 'Anchor' ).props().clickHandler ).toBe( props.joinNowRewards );
    } );

    it( 'Should not contain Join Now link if the lpsTurnOff flag is true', () =>{
      props.lpsTurnOff = true;
      const store = configureStore( {}, CONFIG );
      component = mountWithIntl(
        <Provider store={ store }>
          <UserRewardsLookup { ...props } />
        </Provider> );
      expect( component.find( '.UserRewardsLookup__rewardsJoinNow' ).length ).toBe( 0 );
    } );

    it( 'should show the rewrdslookup points earned message for an exisitng reward member user', () =>{
      props.rewardPointsEarned = 100;
      props.user.isRewardsMember =true;
      const store = configureStore( {}, CONFIG );
      component = mountWithIntl(
        <Provider store={ store }>
          <UserRewardsLookup { ...props } />
        </Provider> );
      expect( component.find( '.UserRewardsLookup__pointOrder' ).text() ).toBe( messages.pointOrder.defaultMessage );
    } );
  } );

  describe( 'UserRewardsLookup for Anonymous user', () =>{
    let component;
    let modalStatusMock=jest.fn();
    let setCartRightPanelCollapseMock=jest.fn();
    let props = {
      modalStatus :modalStatusMock,
      setCartRightPanelCollapse: setCartRightPanelCollapseMock,
      cartRightPanelCollapse: {
        userRewards: false
      },
      user: {
        rewardsLookup: false,
        isSignedIn: false,
        isRewardsMember: false
      },
      preScreenBeautyClubNumber: null,
      rewardPointsEarned: 100,
      isSignedIn: false,
      isRewardsMember: false,
      joinNowRewardsError: [],
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        editCreditCardData: {},
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        }
      },
      joinNowRewards: jest.fn(),
      isModalOpen:true,
      switchData:{
        switches: {
          lpsTurnOff: false
        }
      },
      lpsTurnOff: false
    }
    const store = configureStore( {}, CONFIG );

    component = mountWithIntl(
      <Provider store={ store }>
        <UserRewardsLookup { ...props } />
      </Provider> )

    it( 'Should contain MixedMenuButton component', () =>{
      expect( component.find( 'MixedMenuButton' ).length ).toBe( 1 );
    } );

    it( 'Should contain label MixedMenuButton component as ``Add Your Ultamate Rewards MemberID', () =>{
      expect( component.find( 'MixedMenuButton' ).props().label ).toBe( messages.userRewardsTitle.defaultMessage );
    } );

    it( 'Should contain MixedMenuButton component', () =>{
      expect( component.find( 'MixedMenuButton' ).length ).toBe( 1 );
    } );
    it( 'Should contain Collapse component', () =>{
      expect( component.find( 'Collapse' ).length ).toBe( 1 );
    } );
    it( 'Should contain Anchor component', () =>{
      expect( component.find( 'Anchor a' ).length ).toBe( 2 );
    } );
    it( 'Should contain input field', () =>{
      expect( component.find( 'input' ).length ).toBe( 1 );
    } );

    it( 'Should contain label MixedMenuButton component as ``Add Your Ultamate Rewards MemberID', () =>{
      expect( component.find( 'MixedMenuButton' ).props().details ).toBe( messages.userRewardsMessage.defaultMessage );
    } );

    it( 'Should invoke setCartRightPanelCollaps on click of MixedMenuButton', () =>{
      component.find( 'MixedMenuButton' ).simulate( 'click' );
      expect( setCartRightPanelCollapseMock ).toBeCalledWith( 'userRewards' );
    } );

    it( 'Should contain close Anchor tag in the Modal', () =>{
      expect( document.body.getElementsByClassName( 'UserRewardsLookup__closeModal' ).length ).toBe( 1 );
    } );

    it( 'Should render without crashing if state have creditcard detail and the error message is cleared (rewardsLookup will be null)', () =>{
      let props1 = {
        setCartRightPanelCollapse: jest.fn(),
        cartRightPanelCollapse: {
          userRewards: false
        },
        user: {
          rewardsLookup: null,
          isSignedIn: false,
          isRewardsMember: false
        },
        preScreenBeautyClubNumber: null,
        rewardPointsEarned: 100,
        isSignedIn: false,
        isRewardsMember: false,
        joinNowRewardsError: [],
        creditCardDetails: {
          checkoutFormAddressOpen: {
            paymentAddressForm: false,
            shippingAddressForm: true
          },
          editCreditCardData: {},
          paymentInfo: {
            paymentType: 'creditCard',
            paymentDetails: {
              expirationMonth: '09',
              expirationYear: '2021',
              creditCardNumber: '1111',
              creditCardType: 'Visa'
            },
            amount: 46.18,
            currencyCode: 'USD',
            contactInfo: {
              firstName: 'Pushpendra',
              lastName: 'Kabdaula',
              phoneNumber: '123-456-7890',
              email: 'pkabdaula@ulta.com',
              address1: '1000 remngton blvd',
              address2: 'Ste 200',
              city: 'Boolingbrook',
              state: 'IL',
              postalCode: '07105',
              country: 'US'
            }
          }
        },
        joinNowRewards: jest.fn(),
        modalStatus:jest.fn(),
        isModalOpen:true,
        switchData:{
          switches: {
            lpsTurnOff: false
          }
        },
        lpsTurnOff: false
      }
      let component1 = mountWithIntl(
        <Provider store={ store }>
          <UserRewardsLookup { ...props1 } />
        </Provider> )

      expect( component1.find( 'input' ).length ).toBe( 1 );
    } );

    it( 'Should invoke modalStatus on click of forgot field link', () =>{
      component.find( '.UserRewardsLookup__forgotField Anchor' ).simulate( 'click' );
      expect( modalStatusMock ).toBeCalled ;
    } );

    it( 'Should set rewards if preScreenBeautyClubNumber is not null', () =>{
      let props2 = {
        setCartRightPanelCollapse: jest.fn(),
        cartRightPanelCollapse: {
          userRewards: false
        },
        user: {
          rewardsLookup: {
            success: true,
            rewardPointEarned: 500
          },
          isSignedIn: false,
          isRewardsMember: false
        },
        preScreenBeautyClubNumber: 'sdsd',
        rewardPointsEarned: 200,
        isSignedIn: false,
        isRewardsMember: false,
        joinNowRewardsError: [],
        creditCardDetails: {
          checkoutFormAddressOpen: {
            paymentAddressForm: false,
            shippingAddressForm: true
          },
          editCreditCardData: {},
          paymentInfo: {
            paymentType: 'creditCard',
            paymentDetails: {
              expirationMonth: '09',
              expirationYear: '2021',
              creditCardNumber: '1111',
              creditCardType: 'Visa'
            },
            amount: 46.18,
            currencyCode: 'USD',
            contactInfo: {
              firstName: 'Pushpendra',
              lastName: 'Kabdaula',
              phoneNumber: '123-456-7890',
              email: 'pkabdaula@ulta.com',
              address1: '1000 remngton blvd',
              address2: 'Ste 200',
              city: 'Boolingbrook',
              state: 'IL',
              postalCode: '07105',
              country: 'US'
            }
          }
        },
        joinNowRewards: jest.fn(),
        modalStatus:jest.fn(),
        isModalOpen:true,
        switchData:{
          switches: {
            lpsTurnOff: false
          }
        },
        lpsTurnOff: false
      }
      let component2 = mountWithIntl(
        <Provider store={ store }>
          <UserRewardsLookup { ...props2 } />
        </Provider> )
      expect( component2.find( '.UserRewardsLookup__pointEarned' ).at( 0 ).length ).toBe( 1 );
    } );

  } );

  describe( 'Rewards Program Join Now', () =>{
    let props1 = {
      setCartRightPanelCollapse: jest.fn(),
      cartRightPanelCollapse: {
        userRewards: false
      },
      user: {
        rewardsLookup: false,
        isSignedIn: true,
        isRewardsMember: false
      },
      preScreenBeautyClubNumber: 'sdsd',
      rewardPointsEarned: 100,
      isSignedIn: true,
      isRewardsMember: false,
      joinNowRewardsError: [
        {
          'messageKey': 'unableToProcessMembershipError',
          'messageType': 'Error',
          'messageDesc': 'We \'re sorry. We are currently unable to process your Ultamate Rewards membership. Please \<a href=\'\/ulta\/common\/contactUs.jsp\'>Contact Us<\/a>.'
        }
      ],
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        editCreditCardData: {},
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        }
      },
      joinNowRewards: jest.fn(),
      lpsTurnOff: false
    }
    const store = configureStore( {}, CONFIG );

    let component = mountWithIntl(
      <Provider store={ store }>
        <UserRewardsLookup { ...props1 } />
      </Provider> );


    it( 'Should return error if the membership is not created', () =>{
      component.find( 'Anchor' ).simulate( 'click' );
      expect( component.find( 'ResponseMessages' ).length ).toBe( 1 );
    } );

    it( 'Should contain error message if the membership is not created', () =>{
      expect( component.find( 'ResponseMessages' ).props().message ).toBe( props1.joinNowRewardsError[0].messageDesc );
    } );

    let props2 = {
      setCartRightPanelCollapse: jest.fn(),
      cartRightPanelCollapse: {
        userRewards: false
      },
      user: {
        rewardsLookup: false,
        isSignedIn: true,
        isRewardsMember: false
      },
      preScreenBeautyClubNumber: 'sdsd',
      rewardPointsEarned: 100,
      isSignedIn: true,
      isRewardsMember: true,
      joinNowRewardsError: [
        {
          'messageKey': 'errorComputingPoints',
          'messageType': 'Error',
          'messageDesc': 'You will earn points with this order.'
        }
      ],
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        editCreditCardData: {},
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        }
      },
      joinNowRewards: jest.fn(),
      lpsTurnOff: false
    }


    let component2 = mountWithIntl(
      <Provider store={ store }>
        <UserRewardsLookup { ...props2 } />
      </Provider> );

    it( 'Should return error if the  Membership is created and order points not computed', () =>{
      expect( component2.find( '.UserRewardsLookup__reviewOrder' ).text() ).toBe( props2.joinNowRewardsError[0].messageDesc );
    } );
  } );

  describe( 'Error', () =>{
    let setCartRightPanelCollapseMock =jest.fn();
    let modalStatusMock =jest.fn();
    let getRewardsLookupMock = jest.fn()
    let props3 = {
      setCartRightPanelCollapse: setCartRightPanelCollapseMock,
      modalStatus :modalStatusMock,
      getRewardsLookup :getRewardsLookupMock,
      cartRightPanelCollapse: {
        userRewards: true
      },
      user: {
        rewardsLookup: {
          success:false,
          messages:[{
            type:'error',
            messageDesc:'error'
          }]
        },
        isSignedIn: false,
        isRewardsMember: false
      },
      preScreenBeautyClubNumber: null,
      rewardPointsEarned: 100,
      isSignedIn: false,
      isRewardsMember: true,
      joinNowRewardsError: [],
      creditCardDetails: {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: true
        },
        editCreditCardData: {},
        paymentInfo: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '1111',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        }
      },
      joinNowRewards: jest.fn(),
      lpsTurnOff: false
    }
    const store = configureStore( {}, CONFIG );

    let component5 = mountWithIntl(
      <Provider store={ store }>
        <UserRewardsLookup { ...props3 } />
      </Provider> );

    it( 'Should return error node if error message is returned in the reponse', () =>{
      expect( component5.find( '.UserRewardsLookup__errors ResponseMessages' ).length ).toBe( 1 );
    } );


    it( 'Should not invoke getRewardsLookup on invoking rewardPointLookup if the input length is equal to 13', () =>{
      let node = component5.find( 'UserRewardsLookup' ).instance();
      node.rewardPointLookup( '12345678911234' );
      const input = {
        loyaltyMemberId: '12345678911234'
      }
      expect( getRewardsLookupMock ).not.toBeCalledWith( input ) ;
    } );

    it( 'Should invoke getRewardsLookup on invoking rewardPointLookup if the input length is not equal to 13', () =>{
      let node = component5.find( 'UserRewardsLookup' ).instance();
      node.rewardPointLookup( '1234567891123' );
      const input = {
        loyaltyMemberId: '1234567891123'
      }
      expect( getRewardsLookupMock ).toBeCalledWith( input ) ;
    } );

    it( 'Should pass the element is as props to UltamateRewardsMemberId to load React Model', () =>{
      expect( component5.find( 'UltamateRewardsMemberId' ).props().loadModelContainerId ).toBeTruthy();
      expect( component5.find( 'UltamateRewardsMemberId' ).props().loadModelContainerId ).toBe( '#js-cartpage' );
    } );


    it( 'Broadcast message is invoked if error message is returned in the response of rewardPointLookup', () => {
      const broadcastMessageMock = jest.fn();
      const props6 = {
        ...props3,
        broadcastMessage:broadcastMessageMock
      }
      const prevProps = {
        user: {
          rewardsLookup: {
          }
        }
      }
      let component6 = mountWithIntl(
        <Provider store={ store }>
          <UserRewardsLookup { ...props6 } />
        </Provider> );
      component6.find( 'UserRewardsLookup' ).instance().componentDidUpdate( prevProps );
      expect( broadcastMessageMock ).toBeCalledWith( props6.user.rewardsLookup.messages[0].messageDesc );
    } );

  } );
} );
