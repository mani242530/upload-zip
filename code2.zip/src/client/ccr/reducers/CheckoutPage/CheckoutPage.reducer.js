/**
 * CheckoutPage Redux reducer Module
 *
 */

import { createSelector } from 'reselect';
import forIn from 'lodash/forIn';
import {
  types as CheckoutPageTypes,
  actions as CheckoutPageActions
} from 'ccr/actions/CheckoutPage/CheckoutPage.actions';
import isUndefined from 'lodash/isUndefined';
import {
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';
import {
  types as FormTypes
} from 'shared/actions/Forms/Forms.actions';
import { has, find, isEmpty } from 'lodash';
import {
  isMobileDevice
} from 'utils/DeviceDetection/deviceDetection';
import {
  types as GlobalTypes,
  actions as GlobalActions
} from 'shared/actions/Global/Global.actions';

import {
  actionTypes as ReduxActionType
} from 'redux-form';
/**
 * default state for the CheckoutPage reducer
 */


export const initialState = {
  signUpLetterFlag: true,
  stateDropdownValues: {
    billing: '',
    shipping: ''
  },
  checkoutFormAddressOpen: {
    paymentAddressForm: false,
    shippingAddressForm: false
  },
  checkoutFormAddress2Open: {
    paymentAddressForm: false,
    shippingAddressForm: false
  },
  getQualifiedShipMethod: {},
  paymentServiceResponse: {},
  readCartData: {},
  paypalResponse: {},
  callPaypalService: true,
  paypal: false,
  giftCardDetails: {},
  loyaltyCardDetails: {},
  creditCardDetails: {},
  giftCardApplying: false,
  editAddressData: {
    refId: undefined
  },
  editCreditCardData: {},
  submitOrderService: {},
  isSetCCPaymentFormSubmit: false,
  isCouponButtonClicked: false,
  isShippingError: false,
  shippingSuccess: false,
  paymentSuccess: false,
  shippingError: [],
  paymentError: [],
  joinNowRewardsError: [],
  holdDavPopUp: false,
  paymentType: 'creditCard',
  previousPaymentType: null,
  cartMerged: false,
  checkoutFormConfig: {
    showHideCheckoutToggleData: {
      securityCode: false,
      ccSecurityCode: false
    }
  },
  remainingPaymentDue: undefined,
  navigateToCartPage: false,
  giftCardError: undefined,
  checkoutError: [],
  orderSuccess: false,
  editCCData: {},
  orderId: undefined,
  isCheckoutDataAvailable: false,
  submitOrderSpinner: false,
  creditCardPaymentType: null,
  tempPaymentCCVNumber: null,
  isErrorBeforeSubmitOrder: undefined,
  payPalClientToken: undefined,
  profileCreditCardListCount: 0,
  showSecurityIcon: true,
  anchorAfterSubmitServiceCall: undefined,
  displayCheckoutLevelErrorMessage: false,
  activeField:'',
  isGiftCardRemoved: false,
  isRewardPointsRemoved: false
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now( ) or Math.random( ).
 */
export default function reducer( state = initialState, action ){

  switch ( action.type ){
    case CheckoutPageTypes.DEFAULT:
      return Object.assign(
        {},
        state,
        {
          arg: action.arg
        }
      )
    case CheckoutPageTypes.NEWSLETTER_SIGNUP_STATUS:
      return Object.assign(
        {},
        state, {
          signUpLetterFlag: action.status
        }
      )

    case CheckoutPageTypes.SET_PAYMENT_FORM_TYPE:
      return Object.assign(
        {},
        state, {
          paymentType: action.paymentType
        }
      )
    case ReduxActionType.FOCUS:
      return {
        ...state,
        activeField:action.meta.field
      }

    case ReduxActionType.CHANGE:

      if( ( action.meta.form === 'Shipping' || action.meta.form === 'shippingAddressList' )
           && ( state.activeField === action.meta.field || action.meta.field === 'state' )
           && isShippingErrorPresent( state )
           && isShippingFieldUpdated( state, action.meta.field, action.payload ) ){

        return {
          ...state,
          shippingError : [],
          readCartData: {
            ...state.readCartData,
            shippingInfo: {
              ...state.readCartData.shippingInfo,
              messages: [],
              isShippingAddressErrorCleared : true
            }
          }
        }

      }
      else if( action.meta.form === 'giftCard' && has( state, 'giftCardDetails.messages' ) &&
        !isEmpty( state.giftCardDetails.messages ) && isGiftCardFieldUpdated( state, action.meta.field, action.payload )
      ){
        return {
          ...state,
          giftCardDetails: { ...state.giftCardDetails, messages:[] }
        }
      }
      else if( action.meta.form === 'Coupon' && has( state, 'readCartData.appliedCouponSummary.couponAppliedErrorMsg' ) &&
        !isEmpty( state.readCartData.appliedCouponSummary.couponAppliedErrorMsg ) && isCouponFieldUpdated( state, action.meta.field, action.payload )
      ){
        return {
          ...state,
          readCartData: {
            ...state.readCartData,
            appliedCouponSummary:{
              ...state.readCartData.appliedCouponSummary,
              couponAppliedErrorMsg:undefined
            }
          }
        }
      }
      else if( !isUndefined( action.payload ) && action.meta.form === 'paymentForm' && isPaymentErrorPresent( state ) && state.activeField === action.meta.field &&
          isPaymentFieldUpdated( state, action.meta.field, action.payload ) ){

        return {
          ...state,
          paymentError : [],
          creditCardDetails: {
            ...state.creditCardDetails,
            isPaymentErrorCleared : true,
            messages: []
          }
        }

      }
      else if( !isUndefined( action.payload ) && action.meta.form === 'PaymentCCSecurityCode' && isPaymentErrorPresent( state ) && isPaymentFieldUpdated( state, action.meta.field, action.payload ) ){
        return {
          ...state,
          paymentError : [],
          creditCardDetails: {
            ...state.creditCardDetails,
            messages: []
          }
        }
      }
      else {
        return {
          ...state
        }
      }
    case getServiceType( 'getQualifiedShipMethod', 'success' ):
      try {
        if( action.data ){
          return {
            ...state,
            getQualifiedShipMethod: action.data
          }
        }

      }
      catch ( e ){

      }
    case getServiceType( 'shippingUpdate', 'loading' ):
      try {
        return {
          ...state,
          shippingSuccess: true,
          shippingError: []
        }
      }
      catch ( e ){
      }
    case getServiceType( 'shippingUpdate', 'success' ):
      try {
        let updatedGitCardState;
        let updatedLoyaltyState
        if( ( has( action.data.shippingInfo, 'shippingAddress' ) ) && ( action.data.shippingInfo.shippingAddress.address1 !== null || action.data.result === 'Success' ) ){
          if( has( action.data, 'paymentDetails' ) ){
            updatedGitCardState = loadStatePaymentDetails( action.data.paymentDetails, 'giftCard' );
            updatedLoyaltyState = loadStatePaymentDetails( action.data.paymentDetails, 'loyalty' );
          }
          return {
            ...state,
            ...updatedGitCardState,
            ...updatedLoyaltyState,
            shippingSuccess: false,
            readCartData: {
              ...state.readCartData,
              cartSummary: has( action.data, 'cartSummary' ) ? action.data.cartSummary : state.readCartData.cartSummary,
              shippingInfo: action.data.shippingInfo,
              paymentDetails: has( action.data, 'paymentDetails' ) ? action.data.paymentDetails : state.readCartData.paymentDetails
            },
            shippingError: [],
            holdDavPopUp: !!isUndefined( find( action.data, { 'shippingStatus': 'CorrectedAddress' } ) ),
            editAddressData: {
              refId: action.data.shippingInfo.shippingAddress.refId,
              firstName: action.data.shippingInfo.shippingAddress.firstName,
              lastName: action.data.shippingInfo.shippingAddress.lastName,
              phoneNumber: action.data.shippingInfo.shippingAddress.phoneNumber,
              isPrimaryAddress: false,
              emailaddress: action.data.shippingInfo.shippingAddress.email,
              isPaypalFlag: false,
              addressData: {
                address1: action.data.shippingInfo.shippingAddress.address1,
                address2: action.data.shippingInfo.shippingAddress.address2,
                city: action.data.shippingInfo.shippingAddress.city,
                state: action.data.shippingInfo.shippingAddress.state,
                postalCode: action.data.shippingInfo.shippingAddress.postalCode
              }
            }
          }
        }
        else if( has( action.data.shippingInfo, 'shippingAddress' ) && action.data.shippingInfo.shippingAddress.firstName === null ){
          return {
            ...state,
            shippingSuccess: false,
            readCartData: {
              ...state.readCartData,
              cartSummary: has( action.data, 'cartSummary' ) ? action.data.cartSummary : state.readCartData.cartSummary,
              shippingInfo: {
                shipMethodInfo:action.data.shippingInfo.shipMethodInfo
              },
              paymentDetails: has( action.data, 'paymentDetails' ) ? action.data.paymentDetails : state.readCartData.paymentDetails
            }
          }
        }
        else {

          return {

            ...state,
            shippingError: action.data.messages ? action.data.messages : [],
            shippingSuccess: true
          }
        }
      }
      catch ( e ){

      }

    case CheckoutPageTypes.UPDATE_DAV_POPUP:
      return {
        ...state,
        holdDavPopUp: false
      }

    case getServiceType( 'readCart', 'requested' ):
      return {
        ...state,
        isCheckoutDataAvailable: action.data.hideSpinner,
        shippingError: [],
        tempPaymentCCVNumber: ''
      }


    case getServiceType( 'readCart', 'loading' ):

      return {
        ...state,
        holdDavPopUp: true
      }

    // Data from service to populate the cart data
    case getServiceType( 'readCart', 'success' ):

      if( action.data ){
        let updatedRCState = toggleCardDetails( action.data.paymentDetails );
        return {
          ...state,
          ...updatedRCState,
          isCheckoutDataAvailable: true,
          readCartData: action.data,
          orderId: action.data.id,
          remainingPaymentDue: has( action.data, 'remainingPaymentDue' ) ? parseFloat( action.data.remainingPaymentDue ) : undefined
        }
      }

    case getServiceType( 'estimatedDeliveryDate', 'success' ) :
      try {
        return {
          ...state,
          readCartData: {
            ...state.readCartData,
            shippingInfo: {
              ...state.readCartData.shippingInfo,
              shipMethodInfo: {
                ...state.readCartData.shippingInfo.shipMethodInfo,
                estimatedDelivery: action.data.estDeliveryDateResponse.estimatedDelivery
              }
            }
          }
        }
      }
      catch ( e ){
      }

    case getServiceType( 'login', 'success' ) :
      try {
        if( has( action.data, 'cartMerged' ) ){
          if( action.data.cartMerged ){
            return {
              ...state,
              cartMerged: true
            }
          }
        }
      }
      catch ( e ){
      }

    case getServiceType( 'applycoupon', 'success' ):

      if( !has( action.data, 'cartSummary' ) ){
        return {
          ...state,
          readCartData:{
            ...state.readCartData,
            appliedCouponSummary:action.data
          },
          couponApplyingOnCheckout: false
        }
      }


    case getServiceType( 'applycoupon', 'failure' ):
      return {
        ...state,
        couponApplyingOnCheckout: false,
        isCouponButtonClicked: false
      }

    case getServiceType( 'removecoupon', 'success' ):
      if( !has( action.data, 'cartSummary' ) ){
        return {
          ...state,
          readCartData:{
            ...state.readCartData,
            appliedCouponSummary:action.data
          },
          couponApplyingOnCheckout: false
        }
      }

    case getServiceType( 'removecoupon', 'failure' ):
      return {
        ...state
      }
    case getServiceType( 'applycoupon', 'loading' ):
      try {
        return {
          ...state,
          couponApplyingOnCheckout: true,
          isCouponButtonClicked: false
        }
      }
      catch ( e ){

      }

    case FormTypes.SET_COUPON_ERROR:
      cartPageData = state.readCartData;
      delete cartPageData.appliedCouponSummary
      cartPageData.appliedCouponSummary = {
        couponAppliedErrorMsg: action.errorMessage
      }
      return {
        ...state,
        cartPageData
      }

    case FormTypes.CLEAR_COUPON_ERROR:
      let cartPageData = state.readCartData;
      delete cartPageData.appliedCouponSummary
      cartPageData.appliedCouponSummary = {
        couponAppliedStatus: 'Initial'
      }
      return {
        ...state,
        cartPageData
      }

    case FormTypes.RESET_COUPON_STATE:
      return {
        ...state,
        isCouponButtonClicked: false
      }

    case FormTypes.TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY:

      return {
        ...state,
        checkoutFormAddressOpen: toggleFormAddress( action.formName, state )
      }

    case CheckoutPageTypes.SET_EDIT_ADDRESS_DATA:

      return {
        ...state,
        editAddressData: {
          refId: action.data.refId,
          firstName: action.data.firstName,
          lastName: action.data.lastName,
          phoneNumber: action.data.phoneNumber,
          isPrimaryAddress: action.data.isPrimaryAddress,
          emailaddress: action.data.email,
          isPaypalFlag: action.data.isPaypalFlag,
          addressData: {
            address1: action.data.address1,
            address2: action.data.address2,
            city: action.data.city,
            state: action.data.state,
            postalCode: action.data.postalCode
          }
        }
      }
    case CheckoutPageTypes.UPDATE_SHIPPING_STATUS:

      return {
        ...state,
        shippingSuccess: !action.data
      }
    case CheckoutPageTypes.UPDATE_PAYMENT_STATUS:
      return {
        ...state,
        paymentSuccess: !action.data
      }

    case CheckoutPageTypes.SET_SHIPPING_ERROR_MESSAGE:
      return {
        ...state,
        readCartData: {
          ...state.readCartData,
          shippingInfo: {
            ...state.readCartData.shippingInfo,
            messages: action.data
          }
        }
      }

    case CheckoutPageTypes.SET_EDIT_CREDITCARD_DATA:

      return {
        ...state,
        editCreditCardData: {
          nickName: action.data.nickName,
          creditCardType: action.data.creditCardType,
          creditCardNumber: action.data.creditCardNumber,
          expirationMonth: action.data.expirationMonth,
          expirationYear: action.data.expirationYear,
          isPrimary: ( action.data.isPrimary ) ? action.data.isPrimary : '',
          contactInfo: {
            firstName: action.data.firstName,
            lastName: action.data.lastName,
            phoneNumber: action.data.phoneNumber,
            addressData: action.data.addressData
          }
        }
      }
    case CheckoutPageTypes.RESET_CART_MERGED:

      return {
        ...state,
        cartMerged: false
      }
    case CheckoutPageTypes.SET_CREDITCARD_PAYMENT_TYPE:
      return {
        ...state,
        creditCardPaymentType: action.data
      }
    case CheckoutPageTypes.SET_CC_PAYMENT_FORM_SUBMIT:
      return {
        ...state,
        isSetCCPaymentFormSubmit: action.data
      }
    case CheckoutPageTypes.SET_TEMP_PAYMENT_CCV_NUMBER:
      return {
        ...state,
        tempPaymentCCVNumber: action.data
      }
    case CheckoutPageTypes.RESET_CARTPAGE_NAVIGATION:
      return {
        ...state,
        navigateToCartPage: false
      }

    case CheckoutPageTypes.RESET_ORDER_STATUS:
      return {
        ...state,
        orderSuccess: false
      }

    case CheckoutPageTypes.UPDATE_STATE_DROPDOWN_VALUE:

      let newState = {};

      if( action.form === 'billing' ){
        newState = {
          billing: action.value,
          shipping: state.stateDropdownValues.shipping
        }
      }
      else if( action.form === 'shipping' ){
        newState = {
          billing: state.stateDropdownValues.billing,
          shipping: action.value
        }
      }

      return Object.assign(
        {},
        state,
        {
          stateDropdownValues: newState
        }
      )

    case getServiceType( 'submitCreditCard', 'loading' ):
      return {
        ...state,
        isSetCCPaymentFormSubmit: false
      }

    case getServiceType( 'submitCreditCard', 'success' ):
      let updatedSCCState = toggleCardDetails( action.data.paymentDetails );
      return {
        ...state,
        ...updatedSCCState,
        readCartData: {
          ...state.readCartData,
          cartSummary: action.data.cartSummary
        },
        isSetCCPaymentFormSubmit: true,
        previousPaymentType: 'creditCard',
        paymentServiceResponse: action.data,
        ...( ( action.data.messages && action.data.messages.length > 0 ) && { messages: action.data.messages } )
      }


    case getServiceType( 'redeemPoints', 'success' ):
      return {
        ...state,
        redeemPoints: action.data,
        ...( ( action.data.messages && action.data.messages.length > 0 ) && { messages: action.data.messages } )
      }

    case getServiceType( 'paymentServiceResponse', 'loading' ):
      let giftCardApplying = !!( action.data.giftcardNumber );
      return {
        ...state,
        ...( ( action.data.paymentType && action.data.paymentType === 'giftCard' ) && { isGiftCardRemoved: false } ),
        ...( ( action.data.paymentType && action.data.paymentType === 'loyalty' ) && { isRewardPointsRemoved:false } ),
        isSetCCPaymentFormSubmit: false,
        giftCardApplying
      }

    case getServiceType( 'paymentServiceResponse', 'success' ):
      if( state.paymentType === 'paypal' ){
        let updatedPaypalState = loadStatePaymentDetails( action.data.result.paymentDetails, action.data.paymentType );
        return {
          ...state,
          ...updatedPaypalState,
          paymentError: [],
          readCartData: {
            ...state.readCartData,
            cartSummary: action.data.result.cartSummary,
            paymentDetails: action.data.result.paymentDetails
          },
          previousPaymentType: 'creditCard',
          giftCardApplying: false,
          remainingPaymentDue: has( action.data.result, 'remainingPaymentDue' ) ? parseFloat( action.data.result.remainingPaymentDue ) : undefined,
          paymentServiceResponse: action.data.result,
          ...( ( state.profileCreditCardListCount <= 0 ) && { paymentType: 'paypal' } ),
          ...( ( action.data.result.messages && action.data.result.messages.length > 0 ) && { messages: action.data.result.messages } )
        }
      }
      else {
        let updatedPaymentState = loadStatePaymentDetails( action.data.result.paymentDetails, action.data.paymentType, state );
        return {
          ...state,
          ...updatedPaymentState,
          paymentError: [],
          readCartData: {
            ...state.readCartData,
            cartSummary: action.data.result.cartSummary,
            paymentDetails: action.data.result.paymentDetails
          },
          previousPaymentType: 'creditCard',
          giftCardApplying: false,
          remainingPaymentDue: has( action.data.result, 'remainingPaymentDue' ) ? parseFloat( action.data.result.remainingPaymentDue ) : undefined,
          paymentServiceResponse: action.data.result,
          ...( ( action.data.result.messages && action.data.result.messages.length > 0 ) && { messages: action.data.result.messages } )
        }
      }

    case getServiceType( 'profileCreditCards', 'success' ):
      return {
        ...state,
        profileCreditCardListCount: ( action.data.profileCreditCards ) ? action.data.profileCreditCards.length : 0,
        ...( ( action.data.profileCreditCards && action.data.profileCreditCards.length > 0 ) && { paymentType: 'creditCard' } )
      }
    case getServiceType( 'profileCreditCards', 'requested' ):
      if( isPaymentErrorPresent( state ) ){
        return {
          ...state,
          paymentError : [],
          creditCardDetails: {
            ...state.creditCardDetails,
            messages: []
          }
        }
      }
    case getServiceType( 'payPal', 'success' ):
      return {
        ...state,
        paypal: true
      };
    case getServiceType( 'removePaymentService', 'success' ):
      let updatedPaymentState = loadStatePaymentDetails( action.data.result.paymentDetails, action.data.paymentType );
      return {
        ...state,
        ...updatedPaymentState,
        ...( ( action.data.paymentType && action.data.paymentType === 'giftCard' ) && { isGiftCardRemoved: true } ),
        ...( ( action.data.paymentType && action.data.paymentType === 'loyalty' ) && { isRewardPointsRemoved:true } ),
        readCartData: {
          ...state.readCartData,
          cartSummary: action.data.result.cartSummary,
          paymentDetails: action.data.result.paymentDetails
        },
        paymentServiceResponse: action.data.result,
        remainingPaymentDue: has( action.data.result, 'remainingPaymentDue' )?parseFloat( action.data.result.remainingPaymentDue ):undefined,
        ...( ( action.data.result.messages && action.data.result.messages.length > 0 ) && { messages: action.data.result.messages } )
      }

    case getServiceType( 'submitOrderService', 'requested' ):
      return {
        ...state,
        submitOrderSpinner: true,
        isErrorBeforeSubmitOrder: undefined,
        anchorAfterSubmitServiceCall: undefined,
        displayCheckoutLevelErrorMessage: false
      }
    case getServiceType( 'submitOrderService', 'failure' ):
      return {
        ...state,
        submitOrderSpinner: false,
        displayCheckoutLevelErrorMessage: !( action.data.displayCheckoutLevelErrorMessage === 'false' ),
        isErrorBeforeSubmitOrder: ( action.data.setFocusTo ) ? action.data.setFocusTo : undefined
      }
    case getServiceType( 'submitOrderService', 'success' ):
      let updatedSOSState = {};
      let displayCheckoutLevelErrorMessage = false;
      if( !isUndefined( action.data.messages ) ){
        if( isUndefined( find( action.data.messages, { 'messageRef': 'checkout' } ) ) ){
          displayCheckoutLevelErrorMessage = true;
        }
        updatedSOSState = messageSort( action.data.messages );
      }
      if( has( action.data, 'success' ) ){
        return {
          ...state,
          ...updatedSOSState,
          orderSuccess: true,
          submitOrderSpinner: false
        }
      }
      else {
        let anchorAfterSubmitServiceCall;
        if( find( action.data.messages, { 'messageRef': 'payment' } ) ){
          anchorAfterSubmitServiceCall = 'payment';
        }
        else if( find( action.data.messages, { 'messageRef': 'shipping' } ) ){
          anchorAfterSubmitServiceCall = 'shipping';
        }
        else {
          anchorAfterSubmitServiceCall = 'header';
        }

        return {
          ...state,
          ...updatedSOSState,
          anchorAfterSubmitServiceCall,
          displayCheckoutLevelErrorMessage,
          submitOrderService: action.data.submitOrder,
          submitOrderSpinner: false
        }
      }

    case CheckoutPageTypes.PAYPAL_RESPONSE:
      return {
        ...state,
        paypalResponse: action.info
      }
    case getServiceType( 'applyPayment', 'success' ):
      let updatedAPState = toggleCardDetails( action.data.paymentDetails );
      return {
        ...state,
        ...updatedAPState,
        readCartData: {
          ...state.readCartData,
          cartSummary: action.data.cartSummary,
          // TODO need if have to switch back to show paypal button as tab commit #04e3d5317cc
          paymentDetails: action.data.paymentDetails
        },
        paymentType: 'paypal',
        previousPaymentType: 'paypal'
      }

    case getServiceType( 'applyExpressPayment', 'success' ):
      return {
        ...state,
        paymentType: 'paypal',
        previousPaymentType: 'paypal'
      }

    case getServiceType( 'applyExpressPaymentSameSession', 'success' ):
      return {
        ...state,
        paymentType: 'paypal',
        previousPaymentType: 'paypal'
      }

    case getServiceType( 'paypalToken', 'success' ):
      if( !isUndefined( action.data.result ) && action.data.result === 'Error' ){
        return {
          ...state
        }
      }
      else {
        return {
          ...state,
          payPalClientToken: action.data.payPalClientToken
        }
      }

    case getServiceType( 'paypalToken', 'loading' ):
      return {
        ...state,
        payPalClientToken: undefined
      }

    case getServiceType( 'userRewards', 'success' ):
      if( has( action.data, 'cartSummary' ) ){
        return {
          ...state,
          readCartData: {
            ...state.readCartData,
            cartSummary: action.data.cartSummary
          }

        }
      }
      else {
        return {
          ...state,
          joinNowRewardsError: action.data.messages

        }
      }


    case getServiceType( 'userRewards', 'requested' ):
      return {
        ...state,
        joinNowRewardsError: []
      }

    case CheckoutPageTypes.CHANGE_CREDIT_CARD:
      let ccData = {
        paymentDetails: {
          paymentInfo: {
            contactInfo: {
              address1: action.data.values.address1,
              address2: action.data.values.address2,
              city: action.data.values.city,
              country: action.data.values.country,
              firstName: action.data.values.firstName,
              lastName: action.data.values.lastName,
              phoneNumber: action.data.values.phoneNumber,
              postalCode: action.data.values.postalCode,
              state: action.data.values.state
            },
            paymentDetails: {
              creditCardNumber: action.data.values.creditCardNumber,
              creditCardType: action.data.values.creditCardType,
              expirationMonth: action.data.values.expirationMonth,
              expirationYear: action.data.values.expirationYear
            },
            paymentType: action.data.values.paymentType,
            nickName: action.data.values.nickName
          }
        }

      }
      let updatedCCDState = updateCreditCardDetails( ccData );
      return {
        ...state,
        ...updatedCCDState,
        editCCData: action.data.values
      }

    case FormTypes.TOGGLE_INPUTFIELD_DISPLAY:
      return {
        ...state,
        checkoutFormConfig: {
          ...state.checkoutFormConfig,
          showHideCheckoutToggleData: {
            ...state.checkoutFormConfig.showHideCheckoutToggleData,
            [ action.fieldName ]: !state.checkoutFormConfig.showHideCheckoutToggleData[ action.fieldName ]
          }
        }
      }
    case CheckoutPageTypes.TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY:
      return {
        ...state,
        checkoutFormAddress2Open: {
          shippingAddressForm: !state.checkoutFormAddress2Open.shippingAddressForm,
          paymentAddressForm: state.checkoutFormAddress2Open.paymentAddressForm
        }
      }
    case CheckoutPageTypes.TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY:
      return {
        ...state,
        checkoutFormAddress2Open: {
          shippingAddressForm: state.checkoutFormAddress2Open.shippingAddressForm,
          paymentAddressForm: !state.checkoutFormAddress2Open.paymentAddressForm
        }
      }
    case CheckoutPageTypes.SET_IS_COUPON_BUTTON_CLICKED:
      return {
        ...state,
        isCouponButtonClicked: action.data
      }

    case CheckoutPageTypes.TOGGLE_SECURITY_CODE_ICON:
      return {
        ...state,
        showSecurityIcon: window.innerWidth < 992 ? action.status : true
      }

    case GlobalTypes.ALERT_WINDOW_RESIZE:

      return {
        ...state,
        showSecurityIcon: action.screenWidth > 992
      }
    default:
      return state;

  }
}


export const toggleFormAddress = ( formName, state ) =>{
  let obj = {}
  forIn( state.checkoutFormAddressOpen, ( val, key ) =>{
    if( formName === key ){
      obj[key] = !val;

    }
    else {
      obj[key] = val;
    }
  } );

  return obj;
};

export const loadStatePaymentDetails = ( result, paymentType ) => {
  // we are using this method to store the paymentDetails in individual objects such as giftCardDetails, loyaltyCardDetails and creditCardDetails depending upon the response of the service.
  // we use a switch case to match the paymentType. We are also setting flags such as giftCardError if the response contains any error message.
  const tempState = {};
  switch ( paymentType ){
    case 'giftCard':
      tempState.giftCardDetails = {};
      tempState.giftCardError = undefined;
      forIn( result, ( val, key ) => {
        if( val.paymentInfo.paymentType === 'giftCard' ){
          tempState.giftCardDetails = val;
          if( has( val, 'messages' ) ){
            if( !isUndefined( find( val.messages, { 'messageType': 'Error' } ) ) ){
              tempState.giftCardError= true ;
              // if there is any error in the giftCard we are clearing the payment details in GiftCard paymentInfo (which are from service response) because the values are already present in UI i.e giftCard form.
              tempState.giftCardDetails.paymentInfo.paymentDetails=undefined;
            }
          }
        }
      } );
      return tempState;
    case 'loyalty':
      tempState.loyaltyCardDetails = {};
      forIn( result, ( val, key ) => {
        if( val.paymentInfo.paymentType === 'loyalty' ){
          tempState.loyaltyCardDetails = val;
        }
      } );
      return tempState;
    default:
      tempState.creditCardDetails = {};
      tempState.editCCData = {};
      tempState.paymentType = 'creditCard';
      forIn( result, ( val, key ) => {
        if( val.paymentInfo.paymentType === 'creditCard' ){
          tempState.creditCardDetails = val;
          tempState.creditCardDetails.paymentInfo.paymentDetails.expirationMonth = ( val.paymentInfo.paymentDetails.expirationMonth ) ? val.paymentInfo.paymentDetails.expirationMonth : '';
          tempState.creditCardDetails.paymentInfo.paymentDetails.expirationYear = ( val.paymentInfo.paymentDetails.expirationYear ) ? val.paymentInfo.paymentDetails.expirationYear : '';
          tempState.paymentType = 'creditCard';
          tempState.isSetCCPaymentFormSubmit = true;
          tempState.editCCData = {
            paymentType: 'creditCard',
            creditCardNumber: val.paymentInfo.paymentDetails.creditCardNumber,
            expirationMonth: val.paymentInfo.paymentDetails.expirationMonth,
            expirationYear: val.paymentInfo.paymentDetails.expirationYear,
            creditCardType: val.paymentInfo.paymentDetails.creditCardType,
            nickName: val.paymentInfo.nickName,
            firstName: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.firstName : '',
            lastName: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.lastName : '',
            phoneNumber: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.phoneNumber : '',
            address1: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.address1: '',
            address2: ( val.paymentInfo.contactInfo && val.paymentInfo.contactInfo.address2 ) ? val.paymentInfo.contactInfo.address2 : '',
            city: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.city : '',
            state: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.state : '',
            postalCode: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.postalCode : '',
            country: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.country : ''
          };
        }
        if( val.paymentInfo.paymentType === 'paypal' ){
          tempState.creditCardDetails = val;
          tempState.paymentType = 'paypal';
        }
      } );
      return tempState;
  }
};

export const toggleCardDetails = ( formName ) =>{
  const tempState = {};
  tempState.loyaltyCardDetails = {};
  tempState.giftCardDetails = {};
  tempState.creditCardDetails = {};
  tempState.editCCData = {};
  tempState.giftCardError = undefined;
  tempState.paymentType = 'creditCard';
  forIn( formName, ( val, key ) =>{
    if( val.paymentInfo.paymentType === 'loyalty' ){
      tempState.loyaltyCardDetails = val;
    }
    if( val.paymentInfo.paymentType === 'giftCard' ){
      tempState.giftCardDetails = val;
      if( has( val, 'messages' ) ){
        if( !isUndefined( find( val.messages, { 'messageType': 'Error' } ) ) ){
          tempState.giftCardError= true ;
          // if there is any error in the giftCard we are clearing the payment details in GiftCard paymentInfo (which are from service response) because the values are already present in UI i.e giftCard form.
          tempState.giftCardDetails.paymentInfo.paymentDetails=undefined;
        }
      }
    }
    if( val.paymentInfo.paymentType === 'creditCard' ){
      tempState.creditCardDetails = val;
      tempState.creditCardDetails.paymentInfo.paymentDetails.expirationMonth = ( val.paymentInfo.paymentDetails.expirationMonth ) ? val.paymentInfo.paymentDetails.expirationMonth : '';
      tempState.creditCardDetails.paymentInfo.paymentDetails.expirationYear = ( val.paymentInfo.paymentDetails.expirationYear ) ? val.paymentInfo.paymentDetails.expirationYear : '';
      tempState.paymentType = 'creditCard';
      tempState.editCCData = {
        paymentType: 'creditCard',
        creditCardNumber: val.paymentInfo.paymentDetails.creditCardNumber,
        expirationMonth: val.paymentInfo.paymentDetails.expirationMonth,
        expirationYear: val.paymentInfo.paymentDetails.expirationYear,
        creditCardType: val.paymentInfo.paymentDetails.creditCardType,
        nickName: val.paymentInfo.nickName,
        firstName: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.firstName : '',
        lastName: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.lastName : '',
        phoneNumber: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.phoneNumber : '',
        address1: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.address1: '',
        address2: ( val.paymentInfo.contactInfo && val.paymentInfo.contactInfo.address2 ) ? val.paymentInfo.contactInfo.address2 : '',
        city: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.city : '',
        state: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.state : '',
        postalCode: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.postalCode : '',
        country: ( val.paymentInfo.contactInfo ) ? val.paymentInfo.contactInfo.country : ''
      };
    }
    if( val.paymentInfo.paymentType === 'paypal' ){
      tempState.creditCardDetails = val;
      tempState.paymentType = 'paypal';
    }
  } );
  return tempState;
};
export const messageSort = ( formName ) =>{
  const tempState = {};
  tempState.shippingError = [];
  tempState.paymentError = [];
  tempState.checkoutError = [];
  forIn( formName, ( val, key ) =>{
    if( val.messageRef === 'shipping' ){
      tempState.shippingError.push( val );
    }
    if( val.messageRef === 'payment' ){
      tempState.paymentError.push( val );
    }
    if( val.messageRef === 'cart' ){
      tempState.navigateToCartPage = true;
    }
    if( val.messageRef === 'checkout' ){
      tempState.checkoutError.push( val );
    }
  } );
  return tempState;
};

export const updateCreditCardDetails = ( formName ) =>{
  const tempState = {};
  tempState.creditCardDetails = [];
  forIn( formName, ( val, key ) =>{
    if( val.paymentInfo.paymentType === 'creditCard' ){
      tempState.creditCardDetails = val;
    }
  } );
  return tempState;
};

export const isShippingFieldUpdated = ( state, fieldName, value ) =>{

  let changed = false;

  if( has( state, 'editAddressData.addressData' ) &&
      !isEmpty( state.editAddressData.addressData ) ){

    if( fieldName === 'address1shippingAddressForm' ){
      changed = state.editAddressData.addressData.address1 !== value;
    }
    else if( fieldName === 'address2shippingAddressForm' ){
      changed = state.editAddressData.addressData.address2 !== value;
    }
    else if( fieldName === 'postalCodeshippingAddressForm' ){
      changed = state.editAddressData.addressData.postalCode !== value;
    }
    else if( fieldName === 'cityshippingAddressForm' ){
      changed = state.editAddressData.addressData.city !== value;
    }
    else if( fieldName === 'state' ){
      changed = state.editAddressData.addressData.state !== value;
    }
  }
  return changed;
}

export const isGiftCardFieldUpdated = ( state, fieldName, value ) =>{
  let changed = false;
  let unformattedValue = value;
  while ( unformattedValue.indexOf( ' ' ) !== -1 ){
    unformattedValue = unformattedValue.replace( ' ', '' );
  }
  if( has( state, 'giftCardDetails.paymentInfo.paymentDetails.giftcardNumber' ) &&
    !isEmpty( state.giftCardDetails.paymentInfo.paymentDetails.giftcardNumber )
  ){
    if( fieldName === 'giftCardNumber' ){
      changed = state.giftCardDetails.paymentInfo.paymentDetails.giftcardNumber !== unformattedValue;
    }
    if( fieldName === 'giftCardPin' && value.length !== 8 ){
      changed = true;
    }
  }
  return changed;
}

export const isCouponFieldUpdated = ( state, fieldName, value ) =>{
  let changed = false;
  if( has( state, 'readCartData.appliedCouponSummary.couponCode' ) &&
    !isEmpty( state.readCartData.appliedCouponSummary.couponCode )
  ){
    if( fieldName === 'couponName' ){
      changed = state.readCartData.appliedCouponSummary.couponCode !== value;
    }
  }
  return changed;
}

export const isPaymentFieldUpdated = ( state, fieldName, value ) =>{

  let changed = false;
  const paymentDetails = state.creditCardDetails.paymentInfo.paymentDetails;

  if( fieldName === 'creditCardNumber' ){
    const creditCardNumber = paymentDetails.creditCardNumber ;
    let unformattedValue = value.replace( / /g, '' );
    if( ( creditCardNumber === value ) || ( creditCardNumber === value.replace( '****', '' ) ) ){
      changed = false;
    }
    else if( ( paymentDetails.creditCardType === 'AmericanExpress' && unformattedValue.length !== 15 ) ||
            ( paymentDetails.creditCardType !== 'AmericanExpress' && unformattedValue.length !== 16 ) ){
      changed = true;
    }
  }
  else if( fieldName === 'expirationDate' ){
    const dateVals = value.split( '/' );
    changed = ( paymentDetails.expirationMonth !== dateVals[0] ) || ( paymentDetails.expirationYear !== dateVals[1] );
  }
  else if( fieldName === 'securityCode' || fieldName === 'ccSecurityCode' ){
    changed = value.length >0 &&
              ( ( paymentDetails.creditCardType === 'AmericanExpress' && value.length < 4 )
                  || ( paymentDetails.creditCardType !== 'AmericanExpress' && value.length < 3 ) ) ;
  }
  return changed;
}

const isPaymentErrorPresent = ( state ) => {

  return ( has( state, 'creditCardDetails.messages' ) && !isEmpty( state.creditCardDetails.messages ) ) ||
           ( has( state, 'paymentError' ) && !isEmpty( state.paymentError ) ) ;
}

const isShippingErrorPresent = ( state ) => {
  return ( has( state, 'readCartData.shippingInfo.messages' ) && !isEmpty( state.readCartData.shippingInfo.messages ) ) ||
         ( has( state, 'shippingError' ) && !isEmpty( state.shippingError ) ) ;
}

export const getCheckoutPageState = state => state.checkoutPage;
