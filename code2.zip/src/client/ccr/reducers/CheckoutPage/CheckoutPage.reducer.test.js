import reducer, {
  initialState, loadStatePaymentDetails, toggleCardDetails
} from './CheckoutPage.reducer';

import {
  types
} from 'ccr/actions/CheckoutPage/CheckoutPage.actions';

import {
  types as formTypes
} from 'shared/actions/Forms/Forms.actions';
import {
  types as globalTypes
} from 'shared/actions/Global/Global.actions';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';
import _ from 'lodash';
import {
  actionTypes as ReduxActionType
} from 'redux-form';


describe( 'CheckoutPage reducer', () =>{

  registerServiceName( 'readCart' );
  registerServiceName( 'getQualifiedShipMethod' );
  registerServiceName( 'submitOrderService' );
  registerServiceName( 'estimatedDeliveryDate' );
  registerServiceName( 'payPal' );
  registerServiceName( 'submitCreditCard' );
  registerServiceName( 'shippingUpdate' );
  registerServiceName( 'applycoupon' );
  registerServiceName( 'login' );
  registerServiceName( 'removecoupon' );
  registerServiceName( 'paypalToken' );
  registerServiceName( 'applyExpressPayment' );
  registerServiceName( 'applyExpressPaymentSameSession' );
  registerServiceName( 'userRewards' );
  registerServiceName( 'redeemPoints' );
  registerServiceName( 'paymentServiceResponse' );
  registerServiceName( 'removePaymentService' );
  registerServiceName( 'profileCreditCards' );

  it( 'should have the proper default state', () =>{

    let expectedState = {
      signUpLetterFlag: true,
      stateDropdownValues: {
        billing: '',
        shipping: ''
      },
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: false
      },
      checkoutFormAddress2Open: {
        paymentAddressForm: false,
        shippingAddressForm: false
      },
      getQualifiedShipMethod: {},
      paymentServiceResponse: {},
      readCartData: {},
      paypalResponse: {},
      callPaypalService: true,
      paypal: false,
      giftCardDetails: {},
      loyaltyCardDetails: {},
      creditCardDetails: {},
      giftCardApplying: false,
      editAddressData: {
        refId: undefined
      },
      editCreditCardData: {},
      submitOrderService: {},
      isSetCCPaymentFormSubmit: false,
      isCouponButtonClicked: false,
      isShippingError: false,
      shippingSuccess: false,
      paymentSuccess: false,
      shippingError: [],
      paymentError: [],
      joinNowRewardsError: [],
      holdDavPopUp: false,
      paymentType: 'creditCard',
      previousPaymentType: null,
      cartMerged: false,
      checkoutFormConfig: {
        showHideCheckoutToggleData: {
          securityCode: false,
          ccSecurityCode: false
        }
      },
      remainingPaymentDue: undefined,
      navigateToCartPage: false,
      giftCardError: undefined,
      checkoutError: [],
      orderSuccess: false,
      editCCData: {},
      orderId: undefined,
      isCheckoutDataAvailable: false,
      submitOrderSpinner: false,
      creditCardPaymentType: null,
      tempPaymentCCVNumber: null,
      isErrorBeforeSubmitOrder: undefined,
      isGiftCardRemoved: false,
      isRewardPointsRemoved: false,
      payPalClientToken: undefined,
      showSecurityIcon: true,
      profileCreditCardListCount: 0,
      anchorAfterSubmitServiceCall: undefined,
      displayCheckoutLevelErrorMessage: false,
      activeField:''
    };

    expect( initialState ).toEqual( expectedState );
  } );

  it( 'should be a function', () =>{
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', () => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  describe( 'SET_EDIT_ADDRESS_DATA', ( ) => {

    let data={
      refId : 'checkoutaddress',
      firstName : 'joe',
      lastName:'joe',
      phoneNumber: '1234567876',
      isDefault: true,
      isPaypal: true,
      isPrimaryAddress: true,
      isPaypalFlag: true,
      email: 'test@ulta.com',
      address1: 'address',
      address2: '',
      city: 'chicago',
      state: 'IL',
      postalCode: 12345
    }
    let actionCreator = {
      type: types.SET_EDIT_ADDRESS_DATA,
      data
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        editAddressData: {
          refId: 'checkoutaddress',
          firstName: 'joe',
          lastName: 'joe',
          phoneNumber: '1234567876',
          isPrimaryAddress: true,
          emailaddress: 'test@ulta.com',
          isPaypalFlag: true,
          addressData: {
            address1: 'address',
            address2: '',
            city: 'chicago',
            state: 'IL',
            postalCode: 12345
          }
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should return the initial state', () =>{
      expect( reducer( undefined, {} ) ).toEqual( initialState );
    } );

  } );
  describe( 'READ_CART_CASES', () => {
    it( 'reset cart merged', () => {
      let actionCreator = {
        type: types.RESET_CART_MERGED
      }

      let excepted = {
        cartMerged: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
    it( 'reseting the cart page Navigation', () => {
      let actionCreator = {
        type: types.RESET_CARTPAGE_NAVIGATION
      }

      let excepted = {
        navigateToCartPage: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'read cart is requested', () => {
      let actionCreator = {
        type: getServiceType( 'readCart', 'requested' ),
        data:{
          hideSpinner:false
        }
      }

      let excepted = {
        isCheckoutDataAvailable: false,
        shippingError: [],
        tempPaymentCCVNumber: ''
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );

    } );

    it( 'read Cart request is loading', () => {
      let actionCreator = {
        type: getServiceType( 'readCart', 'loading' )
      }

      let excepted = {
        holdDavPopUp: true
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'update flag of the DAV popup', () => {
      let actionCreator = {
        type: types.UPDATE_DAV_POPUP
      }

      let excepted = {
        holdDavPopUp: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should set the readcart data', () => {

      let res = { 'cartSummary':{ 'shippingCost':'TBD', 'subTotal':27, 'itemCount':'2', 'orderGiftWrapAmt':0, 'additionalDiscount':null, 'couponDiscount':0, 'estimatedTax':'TBD', 'giftCard':null, 'rewardPointsDiscount':null, 'estimatedTotal':32.95, 'rewardPointsEarned':27, 'currencyCode':'USD' }, 'payPalClientToken':'eyJ2ZXJzaW9uIjoyLCJhdXRob3JpemF0aW9uRmluZ2VycHJpbnQiOiIyNmU1ZmY5MzU1Mjc4OTFkNDlhOGFhOWU0NTBjNmFkMTA3ZjdiOTcxNzQxZGJiOTliNzA2MDdmZGJiZGRjZGM0fGNsaWVudF9pZD1jbGllbnRfaWQkc2FuZGJveCQ0ZHByYmZjNnBoNTk1Y2NqXHUwMDI2Y3JlYXRlZF9hdD0yMDE3LTA4LTAyVDIyOjA5OjI0LjE4MzYxNzA2MyswMDAwXHUwMDI2bWVyY2hhbnRfaWQ9eXd3anpxbmNydHZoNDhrayIsImNvbmZpZ1VybCI6Imh0dHBzOi8vYXBpLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb206NDQzL21lcmNoYW50cy95d3dqenFuY3J0dmg0OGtrL2NsaWVudF9hcGkvdjEvY29uZmlndXJhdGlvbiIsImNoYWxsZW5nZXMiOltdLCJlbnZpcm9ubWVudCI6InNhbmRib3giLCJjbGllbnRBcGlVcmwiOiJodHRwczovL2FwaS5zYW5kYm94LmJyYWludHJlZWdhdGV3YXkuY29tOjQ0My9tZXJjaGFudHMveXd3anpxbmNydHZoNDhray9jbGllbnRfYXBpIiwiYXNzZXRzVXJsIjoiaHR0cHM6Ly9hc3NldHMuYnJhaW50cmVlZ2F0ZXdheS5jb20iLCJhdXRoVXJsIjoiaHR0cHM6Ly9hdXRoLnZlbm1vLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb20iLCJhbmFseXRpY3MiOnsidXJsIjoiaHR0cHM6Ly9jbGllbnQtYW5hbHl0aWNzLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb20veXd3anpxbmNydHZoNDhrayJ9LCJ0aHJlZURTZWN1cmVFbmFibGVkIjpmYWxzZSwicGF5cGFsRW5hYmxlZCI6dHJ1ZSwicGF5cGFsIjp7ImRpc3BsYXlOYW1lIjoiVUxUQSIsImNsaWVudElkIjoiQWZYQkxuSklvMXdrSlRvcm80YURnWUwyd3hxaHMxckJjQU5yektGc3hYMUtjdlVPbXhMT1YtcUZLdnFTTjJ6WDZmRjBnWkRBUTlpMzFPTHciLCJwcml2YWN5VXJsIjoiaHR0cHM6Ly9leGFtcGxlLmNvbSIsInVzZXJBZ3JlZW1lbnRVcmwiOiJodHRwczovL2V4YW1wbGUuY29tIiwiYmFzZVVybCI6Imh0dHBzOi8vYXNzZXRzLmJyYWludHJlZWdhdGV3YXkuY29tIiwiYXNzZXRzVXJsIjoiaHR0cHM6Ly9jaGVja291dC5wYXlwYWwuY29tIiwiZGlyZWN0QmFzZVVybCI6bnVsbCwiYWxsb3dIdHRwIjp0cnVlLCJlbnZpcm9ubWVudE5vTmV0d29yayI6ZmFsc2UsImVudmlyb25tZW50Ijoib2ZmbGluZSIsInVudmV0dGVkTWVyY2hhbnQiOmZhbHNlLCJicmFpbnRyZWVDbGllbnRJZCI6Im1hc3RlcmNsaWVudDMiLCJiaWxsaW5nQWdyZWVtZW50c0VuYWJsZWQiOnRydWUsIm1lcmNoYW50QWNjb3VudElkIjoiVVNEIiwiY3VycmVuY3lJc29Db2RlIjoiVVNEIn0sIm1lcmNoYW50SWQiOiJ5d3dqenFuY3J0dmg0OGtrIiwidmVubW8iOiJvZmYifQ==', 'cartItems':{ 'commerceItems':[{ 'brandName':'Matrix', 'itemType':'cartItem', 'quantity':1, 'productId':'xlsImpprod13031041', 'catalogRefId':'2290677', 'commerceItemid':'ci15600000150', 'priceInfo':{ 'salePrice':null, 'regularPrice':'$17.00' }, 'productDisplayName':'Biolage Waterless Clean & Full Dry Shampoo', 'imageURL':'https://images.ulta.com/is/image/Ulta/2290677?$md$', 'variantInfo':{}, 'skuDisplayName':'Biolage Waterless Clean & Full Dry Shampoo', 'shippingRestriction':'We can\'t ship to your selected address', 'productURL':'/biolage-waterless-clean-full-dry-shampoo?productId=xlsImpprod13031041&sku=2290677' }, { 'brandName':'Essie', 'itemType':'cartItem', 'quantity':1, 'productId':'xlsImpprod1320186', 'catalogRefId':'2091181', 'commerceItemid':'ci15600000151', 'priceInfo':{ 'salePrice':null, 'regularPrice':'$10.00' }, 'productDisplayName':'3-Way Glaze', 'imageURL':'https://images.ulta.com/is/image/Ulta/2091181?$md$', 'variantInfo':{}, 'skuDisplayName':'3-Way Glaze', 'shippingRestriction':'We can\'t ship to your selected address', 'productURL':'/3-way-glaze?productId=xlsImpprod1320186&sku=2091181' }] }, 'shippingInfo':{ 'shippingStatus':'IncompatibleShipping', 'shippingAddress':{ 'lastName':'Sharan', 'country':null, 'address2':null, 'city':'APO', 'address1':'PSC3 Box 7263', 'postalCode':'96266', 'firstName':'Anup', 'phoneNumber':'123-456-7809', 'state':'AP', 'email':'johncorner47@gmail.com' }, 'messages':[{ 'messageKey':'ERR_INCOMPATIBLE_SHIPPING', 'messageType':'Error', 'messageRef':'VRGMIL_HAZMATFRAG_NOTALLOWED', 'messageDesc':'Items in your Bag cannot be shipped to AP.' }] }, 'paymentDetails':[{ 'messages':[], 'paymentInfo':{ 'amount':32.95, 'contactInfo':{ 'lastName':'Sharan', 'country':'US', 'address2':'null', 'city':'Kansas', 'address1':'11108 College Avenue', 'postalCode':'64137', 'firstName':'Anup', 'phoneNumber':'123-456-7890', 'state':'MO', 'email':null }, 'nickName':'Visa - 1111', 'paymentType':'creditCard', 'paymentDetails':{ 'expirationYear':'2031', 'creditCardNumber':'1111', 'creditCardType':'Visa', 'expirationMonth':'06' }, 'currencyCode':'USD' } }], 'ultamateRewardsCCInfo':{}, 'paymentType':{ 'lastFetchedTime':'2017-08-07T17:34:08.079Z' } };

      let actionCreator = {
        type: getServiceType( 'readCart', 'success' ),
        data: res
      }

      let expectedOutput =  { 'cartSummary':{ 'shippingCost':'TBD', 'subTotal':27, 'itemCount':'2', 'orderGiftWrapAmt':0, 'additionalDiscount':null, 'couponDiscount':0, 'estimatedTax':'TBD', 'giftCard':null, 'rewardPointsDiscount':null, 'estimatedTotal':32.95, 'rewardPointsEarned':27, 'currencyCode':'USD' }, 'orderId': undefined, 'payPalClientToken':'eyJ2ZXJzaW9uIjoyLCJhdXRob3JpemF0aW9uRmluZ2VycHJpbnQiOiIyNmU1ZmY5MzU1Mjc4OTFkNDlhOGFhOWU0NTBjNmFkMTA3ZjdiOTcxNzQxZGJiOTliNzA2MDdmZGJiZGRjZGM0fGNsaWVudF9pZD1jbGllbnRfaWQkc2FuZGJveCQ0ZHByYmZjNnBoNTk1Y2NqXHUwMDI2Y3JlYXRlZF9hdD0yMDE3LTA4LTAyVDIyOjA5OjI0LjE4MzYxNzA2MyswMDAwXHUwMDI2bWVyY2hhbnRfaWQ9eXd3anpxbmNydHZoNDhrayIsImNvbmZpZ1VybCI6Imh0dHBzOi8vYXBpLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb206NDQzL21lcmNoYW50cy95d3dqenFuY3J0dmg0OGtrL2NsaWVudF9hcGkvdjEvY29uZmlndXJhdGlvbiIsImNoYWxsZW5nZXMiOltdLCJlbnZpcm9ubWVudCI6InNhbmRib3giLCJjbGllbnRBcGlVcmwiOiJodHRwczovL2FwaS5zYW5kYm94LmJyYWludHJlZWdhdGV3YXkuY29tOjQ0My9tZXJjaGFudHMveXd3anpxbmNydHZoNDhray9jbGllbnRfYXBpIiwiYXNzZXRzVXJsIjoiaHR0cHM6Ly9hc3NldHMuYnJhaW50cmVlZ2F0ZXdheS5jb20iLCJhdXRoVXJsIjoiaHR0cHM6Ly9hdXRoLnZlbm1vLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb20iLCJhbmFseXRpY3MiOnsidXJsIjoiaHR0cHM6Ly9jbGllbnQtYW5hbHl0aWNzLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb20veXd3anpxbmNydHZoNDhrayJ9LCJ0aHJlZURTZWN1cmVFbmFibGVkIjpmYWxzZSwicGF5cGFsRW5hYmxlZCI6dHJ1ZSwicGF5cGFsIjp7ImRpc3BsYXlOYW1lIjoiVUxUQSIsImNsaWVudElkIjoiQWZYQkxuSklvMXdrSlRvcm80YURnWUwyd3hxaHMxckJjQU5yektGc3hYMUtjdlVPbXhMT1YtcUZLdnFTTjJ6WDZmRjBnWkRBUTlpMzFPTHciLCJwcml2YWN5VXJsIjoiaHR0cHM6Ly9leGFtcGxlLmNvbSIsInVzZXJBZ3JlZW1lbnRVcmwiOiJodHRwczovL2V4YW1wbGUuY29tIiwiYmFzZVVybCI6Imh0dHBzOi8vYXNzZXRzLmJyYWludHJlZWdhdGV3YXkuY29tIiwiYXNzZXRzVXJsIjoiaHR0cHM6Ly9jaGVja291dC5wYXlwYWwuY29tIiwiZGlyZWN0QmFzZVVybCI6bnVsbCwiYWxsb3dIdHRwIjp0cnVlLCJlbnZpcm9ubWVudE5vTmV0d29yayI6ZmFsc2UsImVudmlyb25tZW50Ijoib2ZmbGluZSIsInVudmV0dGVkTWVyY2hhbnQiOmZhbHNlLCJicmFpbnRyZWVDbGllbnRJZCI6Im1hc3RlcmNsaWVudDMiLCJiaWxsaW5nQWdyZWVtZW50c0VuYWJsZWQiOnRydWUsIm1lcmNoYW50QWNjb3VudElkIjoiVVNEIiwiY3VycmVuY3lJc29Db2RlIjoiVVNEIn0sIm1lcmNoYW50SWQiOiJ5d3dqenFuY3J0dmg0OGtrIiwidmVubW8iOiJvZmYifQ==', 'cartItems':{ 'commerceItems':[{ 'brandName':'Matrix', 'itemType':'cartItem', 'quantity':1, 'productId':'xlsImpprod13031041', 'catalogRefId':'2290677', 'commerceItemid':'ci15600000150', 'priceInfo':{ 'salePrice':null, 'regularPrice':'$17.00' }, 'productDisplayName':'Biolage Waterless Clean & Full Dry Shampoo', 'imageURL':'https://images.ulta.com/is/image/Ulta/2290677?$md$', 'variantInfo':{}, 'skuDisplayName':'Biolage Waterless Clean & Full Dry Shampoo', 'shippingRestriction':'We can\'t ship to your selected address', 'productURL':'/biolage-waterless-clean-full-dry-shampoo?productId=xlsImpprod13031041&sku=2290677' }, { 'brandName':'Essie', 'itemType':'cartItem', 'quantity':1, 'productId':'xlsImpprod1320186', 'catalogRefId':'2091181', 'commerceItemid':'ci15600000151', 'priceInfo':{ 'salePrice':null, 'regularPrice':'$10.00' }, 'productDisplayName':'3-Way Glaze', 'imageURL':'https://images.ulta.com/is/image/Ulta/2091181?$md$', 'variantInfo':{}, 'skuDisplayName':'3-Way Glaze', 'shippingRestriction':'We can\'t ship to your selected address', 'productURL':'/3-way-glaze?productId=xlsImpprod1320186&sku=2091181' }] }, 'remainingPaymentDue': undefined, 'shippingInfo':{ 'shippingStatus':'IncompatibleShipping', 'shippingAddress':{ 'lastName':'Sharan', 'country':null, 'address2':null, 'city':'APO', 'address1':'PSC3 Box 7263', 'postalCode':'96266', 'firstName':'Anup', 'phoneNumber':'123-456-7809', 'state':'AP', 'email':'johncorner47@gmail.com' }, 'messages':[{ 'messageKey':'ERR_INCOMPATIBLE_SHIPPING', 'messageType':'Error', 'messageRef':'VRGMIL_HAZMATFRAG_NOTALLOWED', 'messageDesc':'Items in your Bag cannot be shipped to AP.' }] }, 'paymentDetails':[{ 'messages':[], 'paymentInfo':{ 'amount':32.95, 'contactInfo':{ 'lastName':'Sharan', 'country':'US', 'address2':'null', 'city':'Kansas', 'address1':'11108 College Avenue', 'postalCode':'64137', 'firstName':'Anup', 'phoneNumber':'123-456-7890', 'state':'MO', 'email':null }, 'nickName':'Visa - 1111', 'paymentType':'creditCard', 'paymentDetails':{ 'expirationYear':'2031', 'creditCardNumber':'1111', 'creditCardType':'Visa', 'expirationMonth':'06' }, 'currencyCode':'USD' } }], 'ultamateRewardsCCInfo':{}, 'paymentType':'creditCard', 'loyaltyCardDetails':{}, 'giftCardDetails':{}, 'giftCardError': undefined, 'creditCardDetails':{ 'messages':[], 'paymentInfo':{ 'amount':32.95, 'contactInfo':{ 'lastName':'Sharan', 'country':'US', 'address2':'null', 'city':'Kansas', 'address1':'11108 College Avenue', 'postalCode':'64137', 'firstName':'Anup', 'phoneNumber':'123-456-7890', 'state':'MO', 'email':null }, 'nickName':'Visa - 1111', 'paymentType':'creditCard', 'paymentDetails':{ 'expirationYear':'2031', 'creditCardNumber':'1111', 'creditCardType':'Visa', 'expirationMonth':'06' }, 'currencyCode':'USD' } }, 'editCCData':{ 'paymentType':'creditCard', 'creditCardNumber':'1111', 'expirationMonth':'06', 'expirationYear':'2031', 'creditCardType':'Visa', 'nickName':'Visa - 1111', 'firstName':'Anup', 'lastName':'Sharan', 'phoneNumber':'123-456-7890', 'address1':'11108 College Avenue', 'address2':'null', 'city':'Kansas', 'state':'MO', 'postalCode':'64137', 'country':'US' }, 'isCheckoutDataAvailable':true, 'readCartData':{ 'cartSummary':{ 'shippingCost':'TBD', 'subTotal':27, 'itemCount':'2', 'orderGiftWrapAmt':0, 'additionalDiscount':null, 'couponDiscount':0, 'estimatedTax':'TBD', 'giftCard':null, 'rewardPointsDiscount':null, 'estimatedTotal':32.95, 'rewardPointsEarned':27, 'currencyCode':'USD' }, 'payPalClientToken':'eyJ2ZXJzaW9uIjoyLCJhdXRob3JpemF0aW9uRmluZ2VycHJpbnQiOiIyNmU1ZmY5MzU1Mjc4OTFkNDlhOGFhOWU0NTBjNmFkMTA3ZjdiOTcxNzQxZGJiOTliNzA2MDdmZGJiZGRjZGM0fGNsaWVudF9pZD1jbGllbnRfaWQkc2FuZGJveCQ0ZHByYmZjNnBoNTk1Y2NqXHUwMDI2Y3JlYXRlZF9hdD0yMDE3LTA4LTAyVDIyOjA5OjI0LjE4MzYxNzA2MyswMDAwXHUwMDI2bWVyY2hhbnRfaWQ9eXd3anpxbmNydHZoNDhrayIsImNvbmZpZ1VybCI6Imh0dHBzOi8vYXBpLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb206NDQzL21lcmNoYW50cy95d3dqenFuY3J0dmg0OGtrL2NsaWVudF9hcGkvdjEvY29uZmlndXJhdGlvbiIsImNoYWxsZW5nZXMiOltdLCJlbnZpcm9ubWVudCI6InNhbmRib3giLCJjbGllbnRBcGlVcmwiOiJodHRwczovL2FwaS5zYW5kYm94LmJyYWludHJlZWdhdGV3YXkuY29tOjQ0My9tZXJjaGFudHMveXd3anpxbmNydHZoNDhray9jbGllbnRfYXBpIiwiYXNzZXRzVXJsIjoiaHR0cHM6Ly9hc3NldHMuYnJhaW50cmVlZ2F0ZXdheS5jb20iLCJhdXRoVXJsIjoiaHR0cHM6Ly9hdXRoLnZlbm1vLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb20iLCJhbmFseXRpY3MiOnsidXJsIjoiaHR0cHM6Ly9jbGllbnQtYW5hbHl0aWNzLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb20veXd3anpxbmNydHZoNDhrayJ9LCJ0aHJlZURTZWN1cmVFbmFibGVkIjpmYWxzZSwicGF5cGFsRW5hYmxlZCI6dHJ1ZSwicGF5cGFsIjp7ImRpc3BsYXlOYW1lIjoiVUxUQSIsImNsaWVudElkIjoiQWZYQkxuSklvMXdrSlRvcm80YURnWUwyd3hxaHMxckJjQU5yektGc3hYMUtjdlVPbXhMT1YtcUZLdnFTTjJ6WDZmRjBnWkRBUTlpMzFPTHciLCJwcml2YWN5VXJsIjoiaHR0cHM6Ly9leGFtcGxlLmNvbSIsInVzZXJBZ3JlZW1lbnRVcmwiOiJodHRwczovL2V4YW1wbGUuY29tIiwiYmFzZVVybCI6Imh0dHBzOi8vYXNzZXRzLmJyYWludHJlZWdhdGV3YXkuY29tIiwiYXNzZXRzVXJsIjoiaHR0cHM6Ly9jaGVja291dC5wYXlwYWwuY29tIiwiZGlyZWN0QmFzZVVybCI6bnVsbCwiYWxsb3dIdHRwIjp0cnVlLCJlbnZpcm9ubWVudE5vTmV0d29yayI6ZmFsc2UsImVudmlyb25tZW50Ijoib2ZmbGluZSIsInVudmV0dGVkTWVyY2hhbnQiOmZhbHNlLCJicmFpbnRyZWVDbGllbnRJZCI6Im1hc3RlcmNsaWVudDMiLCJiaWxsaW5nQWdyZWVtZW50c0VuYWJsZWQiOnRydWUsIm1lcmNoYW50QWNjb3VudElkIjoiVVNEIiwiY3VycmVuY3lJc29Db2RlIjoiVVNEIn0sIm1lcmNoYW50SWQiOiJ5d3dqenFuY3J0dmg0OGtrIiwidmVubW8iOiJvZmYifQ==', 'cartItems':{ 'commerceItems':[{ 'brandName':'Matrix', 'itemType':'cartItem', 'quantity':1, 'productId':'xlsImpprod13031041', 'catalogRefId':'2290677', 'commerceItemid':'ci15600000150', 'priceInfo':{ 'salePrice':null, 'regularPrice':'$17.00' }, 'productDisplayName':'Biolage Waterless Clean & Full Dry Shampoo', 'imageURL':'https://images.ulta.com/is/image/Ulta/2290677?$md$', 'variantInfo':{}, 'skuDisplayName':'Biolage Waterless Clean & Full Dry Shampoo', 'shippingRestriction':'We can\'t ship to your selected address', 'productURL':'/biolage-waterless-clean-full-dry-shampoo?productId=xlsImpprod13031041&sku=2290677' }, { 'brandName':'Essie', 'itemType':'cartItem', 'quantity':1, 'productId':'xlsImpprod1320186', 'catalogRefId':'2091181', 'commerceItemid':'ci15600000151', 'priceInfo':{ 'salePrice':null, 'regularPrice':'$10.00' }, 'productDisplayName':'3-Way Glaze', 'imageURL':'https://images.ulta.com/is/image/Ulta/2091181?$md$', 'variantInfo':{}, 'skuDisplayName':'3-Way Glaze', 'shippingRestriction':'We can\'t ship to your selected address', 'productURL':'/3-way-glaze?productId=xlsImpprod1320186&sku=2091181' }] }, 'shippingInfo':{ 'shippingStatus':'IncompatibleShipping', 'shippingAddress':{ 'lastName':'Sharan', 'country':null, 'address2':null, 'city':'APO', 'address1':'PSC3 Box 7263', 'postalCode':'96266', 'firstName':'Anup', 'phoneNumber':'123-456-7809', 'state':'AP', 'email':'johncorner47@gmail.com' }, 'messages':[{ 'messageKey':'ERR_INCOMPATIBLE_SHIPPING', 'messageType':'Error', 'messageRef':'VRGMIL_HAZMATFRAG_NOTALLOWED', 'messageDesc':'Items in your Bag cannot be shipped to AP.' }] }, 'paymentDetails':[{ 'messages':[], 'paymentInfo':{ 'amount':32.95, 'contactInfo':{ 'lastName':'Sharan', 'country':'US', 'address2':'null', 'city':'Kansas', 'address1':'11108 College Avenue', 'postalCode':'64137', 'firstName':'Anup', 'phoneNumber':'123-456-7890', 'state':'MO', 'email':null }, 'nickName':'Visa - 1111', 'paymentType':'creditCard', 'paymentDetails':{ 'expirationYear':'2031', 'creditCardNumber':'1111', 'creditCardType':'Visa', 'expirationMonth':'06' }, 'currencyCode':'USD' } }], 'ultamateRewardsCCInfo':{}, 'paymentType':{ 'lastFetchedTime':'2017-08-07T17:34:08.079Z' } } };

      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'addressBook data successfullly loaded', () =>{
    describe( 'should set the addressbook data', () =>{


      it( 'should read cart services on success', () =>{
        let actionCreator = {
          type: getServiceType( 'readCart', 'success' ),
          data: 123456
        }

        let expectedOutput = {
          loyaltyCardDetails:{},
          giftCardDetails:{},
          creditCardDetails:{},
          editCCData:{},
          paymentType:'creditCard',
          isCheckoutDataAvailable: true,
          readCartData: 123456
        }

        expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      } );

      it( 'should get qualified ShipMethod  services on success', () =>{
        let actionCreator = {
          type: getServiceType( 'getQualifiedShipMethod', 'success' ),
          data: 123456
        }

        let expectedOutput = {
          getQualifiedShipMethod: 123456

        }

        expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      } );
    } );

    it( 'should edit the address Book', () => {
      let data = {
        refId : 'D0003',
        firstName: 'Jane',
        lastName: 'Doe',
        phoneNumber: '123456789',
        email: 'test@gmail.com',
        isDefault: false,
        isPaypal: false,
        isPrimaryAddress: false,
        isPaypalFlag: false,
        address1: '724 Greenwood Circle',
        address2: 'Apt#102',
        city: 'Naperville',
        state: 'IL',
        postalCode: '92456'
      }

      let actionCreator = {
        type: types.SET_EDIT_ADDRESS_DATA,
        data: data
      }

      let excepted = {
        editAddressData: {
          refId: 'D0003',
          firstName: 'Jane',
          lastName: 'Doe',
          phoneNumber: '123456789',
          isPrimaryAddress: false,
          emailaddress: 'test@gmail.com',
          isPaypalFlag: false,
          addressData: {
            address1: '724 Greenwood Circle',
            address2: 'Apt#102',
            city: 'Naperville',
            state: 'IL',
            postalCode: '92456'
          }
        }
      }

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } )
  } );

  describe( 'NEWSLETTER_SIGNUP_STATUS', () =>{

    let status = true;
    let actionCreator = {
      type: types.NEWSLETTER_SIGNUP_STATUS,
      status
    }

    it( 'should handle the event and set the state', () =>{

      let expectedOutput = {
        signUpLetterFlag: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY', () =>{

    it( 'should handle the event and set the state', () =>{
      let formName = 'paymentAddressForm';
      let actionCreator = {
        type: formTypes.TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY,
        formName
      }
      let state = {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: false
        }
      }
      let expectedOutput = {
        checkoutFormAddressOpen: {
          paymentAddressForm: true,
          shippingAddressForm: false
        }
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );
  } );

  describe( 'TOGGLE_ADDRESS2', () => {
    it( 'Checking the toggle for checkout form', () => {
      let actionCreator = {
        type: formTypes.TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY
      }

      let state = {
        checkoutFormAddress2Open: {
          shippingAddressForm: true,
          paymentAddressForm: true
        }
      }

      let expectedOutput ={
        checkoutFormAddress2Open:{
          shippingAddressForm: true,
          paymentAddressForm: true
        }

      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'checking the toggle for the payment form', () => {
      let actionCreator = {
        type: formTypes.TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY
      }

      let state = {
        checkoutFormAddress2Open: {
          shippingAddressForm: true,
          paymentAddressForm: true
        }
      }

      let expectedOutput ={
        checkoutFormAddress2Open: {
          shippingAddressForm: true,
          paymentAddressForm: true
        }
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'SUBMIT_ADDRESS_CASE', () => {
    it( 'reset the order status', () => {
      let actionCreator = {
        type: types.RESET_ORDER_STATUS
      }

      let excepted = {
        orderSuccess: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
    it( 'If the sumbit order is requested', () => {
      let actionCreator = {
        type: getServiceType( 'submitOrderService', 'requested' )
      }

      let excepted = {
        submitOrderSpinner:true,
        isErrorBeforeSubmitOrder: undefined,
        anchorAfterSubmitServiceCall: undefined,
        displayCheckoutLevelErrorMessage: false
      }

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'If the submit order is successfull', () => {
      let data = { 'success':true }
      let actionCreator = {
        type: getServiceType( 'submitOrderService', 'success' ),
        data
      }

      let expected = {
        success: true,
        orderSuccess: true,
        submitOrderSpinner: false
      }

      expect( reducer( data, actionCreator ) ).toEqual( expected );
    } );

    it( 'If the submit order is failure', () => {
      let data = { 'messages': [{ 'messageKey': 'errorCommittingOrder', 'messageType': 'Error', 'messageDesc': 'We are experiencing difficulty processing your order.', 'messageRef': 'checkout' }, { 'messageKey': 'itemNoLongerActive', 'messageType': 'Error', 'messageDesc': 'Item no longer active.', 'messageRef': 'cart' }, { 'messageKey': 'MissingShippingFirstName', 'messageType': 'Error', 'messageDesc': 'The first name is missing in the shipping address', 'messageRef': 'shipping' }, { 'messageKey': 'invalidCreditCardVerificationNumber', 'messageType': 'Error', 'messageDesc': 'Please enter a valid credit card verification number.', 'messageRef': 'payment' }] };

      let actionCreator = {
        type: getServiceType( 'submitOrderService', 'success' ),
        data
      }

      let excepted = { 'messages': [{ 'messageKey': 'errorCommittingOrder', 'messageType': 'Error', 'messageDesc': 'We are experiencing difficulty processing your order.', 'messageRef': 'checkout' }, { 'messageKey': 'itemNoLongerActive', 'messageType': 'Error', 'messageDesc': 'Item no longer active.', 'messageRef': 'cart' }, { 'messageKey': 'MissingShippingFirstName', 'messageType': 'Error', 'messageDesc': 'The first name is missing in the shipping address', 'messageRef': 'shipping' }, { 'messageKey': 'invalidCreditCardVerificationNumber', 'messageType': 'Error', 'messageDesc': 'Please enter a valid credit card verification number.', 'messageRef': 'payment' }], 'shippingError': [{ 'messageKey': 'MissingShippingFirstName', 'messageType': 'Error', 'messageDesc': 'The first name is missing in the shipping address', 'messageRef': 'shipping' }], 'paymentError': [{ 'messageKey': 'invalidCreditCardVerificationNumber', 'messageType': 'Error', 'messageDesc': 'Please enter a valid credit card verification number.', 'messageRef': 'payment' }], 'checkoutError':[{ 'messageKey': 'errorCommittingOrder', 'messageType': 'Error', 'messageDesc': 'We are experiencing difficulty processing your order.', 'messageRef': 'checkout' }], 'navigateToCartPage': true, 'submitOrderService': undefined, 'submitOrderSpinner': false, 'anchorAfterSubmitServiceCall': 'payment', 'displayCheckoutLevelErrorMessage': false };

      expect( reducer( data, actionCreator ) ).toEqual( excepted );
    } );
    it( 'submit order is failure displayCheckoutLevelErrorMessage has to be false', () => {
      const data = { displayCheckoutLevelErrorMessage : 'false' };
      const actionCreator = {
        type: getServiceType( 'submitOrderService', 'failure' ),
        data
      }
      const excepted = { submitOrderSpinner: false, displayCheckoutLevelErrorMessage: false, isErrorBeforeSubmitOrder: undefined };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
    it( 'submit order is failure and  displayCheckoutLevelErrorMessage is not \'false\', then it has to be true', () => {
      const data = { displayCheckoutLevelErrorMessage : false };
      const actionCreator = {
        type: getServiceType( 'submitOrderService', 'failure' ),
        data
      }
      const excepted = { submitOrderSpinner: false, displayCheckoutLevelErrorMessage: true, isErrorBeforeSubmitOrder: undefined };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
  } );

  describe( 'PAYPAL_CASE', () => {
    it( 'Checking the paypal flag', () => {
      let actionCreator = {
        type: getServiceType( 'payPal', 'success' )
      }

      let excepted = { paypal: true };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'Checking the paypal token loading', () => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'loading' )
      }

      let expected = { payPalClientToken: undefined };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Checking the paypal client token success', () => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'success' ),
        data:{
          result:'success',
          payPalClientToken:'eyJ2ZXJzaW9uIjoyLCJhdXRob3J'
        }
      }

      let expected = { payPalClientToken: 'eyJ2ZXJzaW9uIjoyLCJhdXRob3J' }
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Checking whether the paypal client token error', () => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'success' ),
        data:{
          result:'Error'
        }
      }

      let expected = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Checking the paypal Response event', () => {
      let actionCreator = {
        type: types.PAYPAL_RESPONSE,
        info: 'eyJ2ZXJzaW9uIjoyLCJhdXRob3J'
      }

      let expected = { paypalResponse: 'eyJ2ZXJzaW9uIjoyLCJhdXRob3J' };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Checking applyExpressPayment success event', () => {
      let actionCreator = {
        type: getServiceType( 'applyExpressPayment', 'success' )
      }

      let expected = { paymentType: 'paypal', previousPaymentType: 'paypal' };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Checking applyExpressPaymentSameSession success event', () => {
      let actionCreator = {
        type: getServiceType( 'applyExpressPaymentSameSession', 'success' )
      }
      let expected = { paymentType: 'paypal', previousPaymentType: 'paypal' };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

  } );

  describe( 'PAYMENT_CASES', () => {
    it( 'setting the payment cvv number', () => {
      let data = '311';
      let actionCreator = {
        type: types.SET_TEMP_PAYMENT_CCV_NUMBER,
        data
      }

      let excepted = {
        tempPaymentCCVNumber: '311'
      }

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } )

    it( 'setting the credit card type', () => {
      let data = 'defaultCreditCard';
      let actionCreator = {
        type: types.SET_CREDITCARD_PAYMENT_TYPE,
        data
      }

      let excepted = {
        creditCardPaymentType: 'defaultCreditCard'
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'editing the credit card data', () => {
      let data = {
        nickName: 'Mastercard - 4444',
        creditCardType: 'Mastercard',
        creditCardNumber: '4444',
        expirationMonth: '06',
        expirationYear: '2031',
        firstName: 'Jane',
        lastName: 'Doe',
        phoneNumber: '123-456-7890',
        addressData: {
          address1: '724 Greenwood Circle',
          address2: 'Apt#102',
          city: 'Naperville',
          state: 'IL',
          postalCode: '92476'
        }
      }

      let actionCreator = {
        type: types.SET_EDIT_CREDITCARD_DATA,
        data
      }

      let excepted ={
        'nickName':'Mastercard - 4444',
        'creditCardType':'Mastercard',
        'creditCardNumber':'4444',
        'expirationMonth':'06',
        'expirationYear':'2031',
        'firstName':'Jane',
        'lastName':'Doe',
        'phoneNumber':'123-456-7890',
        'addressData':{
          'address1':'724 Greenwood Circle',
          'address2':'Apt#102',
          'city':'Naperville',
          'state':'IL',
          'postalCode':'92476'
        },
        'editCreditCardData':{
          'nickName':'Mastercard - 4444',
          'creditCardType':'Mastercard',
          'creditCardNumber':'4444',
          'expirationMonth':'06',
          'expirationYear':'2031',
          'isPrimary': '',
          'contactInfo':{
            'firstName':'Jane',
            'lastName':'Doe',
            'phoneNumber':'123-456-7890',
            'addressData':{
              'address1':'724 Greenwood Circle',
              'address2':'Apt#102',
              'city':'Naperville',
              'state':'IL',
              'postalCode':'92476'
            }
          }
        }
      }

      expect( reducer( data, actionCreator ) ).toEqual( excepted );
    } );
    it( 'submit credit card is loading ', () => {
      let actionCreator = {
        type: getServiceType( 'submitCreditCard', 'loading' )
      }

      let excepted = {
        isSetCCPaymentFormSubmit: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'checking the payment status', () => {
      let data = true;
      let actionCreator = {
        type: types.UPDATE_PAYMENT_STATUS,
        data
      }

      let excepted = {
        paymentSuccess: false
      }
      expect( reducer( data, actionCreator ) ).toEqual( excepted );
    } );

    it( 'setting the payment form type', ()=>{
      let actionCreator = {
        type: types.SET_PAYMENT_FORM_TYPE,
        paymentType: 'creditcard'
      }

      let excepted = {
        paymentType: 'creditcard'
      }

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'Submit Credit Card success ', () => {
      let actionCreator = {
        type: getServiceType( 'submitCreditCard', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95,
            subTotal: 26,
            itemCount: '1',
            orderGiftWrapAmt: 0,
            additionalDiscount: null,
            couponDiscount: 0,
            estimatedTax: 0.96,
            rewardPointsDiscount: null,
            estimatedTotal: 33.91,
            rewardPointsEarned: 208,
            currencyCode: 'USD'
          },
          paymentDetails:[
            {
              paymentInfo:{
                amount:52.57,
                paymentType:'giftCard',
                paymentDetails:{
                  giftcardNumber:'8818',
                  giftcardBalance:47.43,
                  currencyCode:'USD'
                }
              }
            }

          ]
        }
      }

      let excepted = { 'loyaltyCardDetails':{}, 'giftCardDetails':{ 'paymentInfo':{ 'amount':52.57, 'paymentType':'giftCard', 'paymentDetails':{ 'giftcardNumber':'8818', 'giftcardBalance':47.43, 'currencyCode':'USD' } } }, 'creditCardDetails':{}, 'editCCData':{}, 'paymentType':'creditCard', 'readCartData':{ 'cartSummary':{ 'shippingCost':6.95, 'subTotal':26, 'itemCount':'1', 'orderGiftWrapAmt':0, 'additionalDiscount':null, 'couponDiscount':0, 'estimatedTax':0.96, 'rewardPointsDiscount':null, 'estimatedTotal':33.91, 'rewardPointsEarned':208, 'currencyCode':'USD' } }, 'isSetCCPaymentFormSubmit':true, 'previousPaymentType':'creditCard', 'paymentServiceResponse':{ 'cartSummary':{ 'shippingCost':6.95, 'subTotal':26, 'itemCount':'1', 'orderGiftWrapAmt':0, 'additionalDiscount':null, 'couponDiscount':0, 'estimatedTax':0.96, 'rewardPointsDiscount':null, 'estimatedTotal':33.91, 'rewardPointsEarned':208, 'currencyCode':'USD' }, 'paymentDetails':[{ 'paymentInfo':{ 'amount':52.57, 'paymentType':'giftCard', 'paymentDetails':{ 'giftcardNumber':'8818', 'giftcardBalance':47.43, 'currencyCode':'USD' } } }] } };

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
  } );


  describe( 'SHIPPING_CASES', () => {
    it( 'updating shipping status', () => {
      let data=false;
      let actionCreator = {
        type: types.UPDATE_SHIPPING_STATUS,
        data
      }

      let excepted = {
        shippingSuccess: true
      }
      expect( reducer( data, actionCreator ) ).toEqual( excepted );
    } );
    it( 'updating shipping status with data', () => {
      let data={
        'cartSummary':{},
        'shippingInfo': {
          'shippingStatus': 'Complete',
          'shippingAddress': {
            'firstName': 'Jane',
            'lastName': 'Doe',
            'address1': '1000 Remington Boulevard',
            'address2': 'Suite # 120',
            'city': 'Bolingbrook',
            'state': 'IL',
            'postalCode': '60564',
            'phoneNumber': '(510)-213-8347'
          },
          'correctedShippingAddress': {
            'firstName': 'Jane',
            'lastName': 'Doe',
            'address1': '1000 Remington Blvd',
            'address2': 'Suite # 120',
            'city': 'Bolingbrook',
            'state': 'IL',
            'postalCode': '60440',
            'phoneNumber': '(510)-213-8347'
          },
          'shipMethodInfo': {
            'shipMethod': 'ups_ground',
            'estimatedDelivery': null,
            'cost': '$5.95',
            'displayName': 'Standard Ground Shipping'
          }
        },
        'paymentDetails':[
          {
            'paymentInfo': {
              'amount':52.57,
              'paymentType':'giftCard',
              'paymentDetails':{
                'giftcardNumber':'8818',
                'giftcardBalance':47.43,
                'currencyCode':'USD'
              }
            }
          }

        ]
      }

      let actionCreator = {
        type: getServiceType( 'shippingUpdate', 'success' ),
        data
      }

      let excepted={
        'editAddressData':{
          'addressData':{
            'address1':'1000 Remington Boulevard',
            'address2':'Suite # 120',
            'city':'Bolingbrook',
            'postalCode':'60564',
            'state':'IL'
          },
          'emailaddress':undefined,
          'firstName':'Jane',
          'isPaypalFlag':false,
          'isPrimaryAddress':false,
          'lastName':'Doe',
          'phoneNumber':'(510)-213-8347',
          'refId':undefined
        },
        'giftCardDetails':{
          'paymentInfo':{
            'amount':52.57,
            'paymentDetails':{
              'currencyCode':'USD',
              'giftcardBalance':47.43,
              'giftcardNumber':'8818'
            },
            'paymentType':'giftCard'
          }
        },
        'giftCardError':undefined,
        'holdDavPopUp':true,
        'loyaltyCardDetails':{
        },
        'readCartData':data,
        'shippingError':[
        ],
        'shippingSuccess':false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
    it( 'checking the estimated delivery date is called', () => {

      let res={
        'readCartData': {
          'shippingInfo': {
            'shippingAddress': {
            },
            'shipMethodInfo': {
              'shipMethod': 'ups_ground',
              'estimatedDelivery': null,
              'cost': '$5.95',
              'displayName': 'Standard Ground Shipping'
            }
          }
        }
      }
      let data={
        'estDeliveryDateResponse': {
          'estimatedDelivery':'Get it by Thu, August 10'
        }
      }
      let actionCreator = {
        type: getServiceType( 'estimatedDeliveryDate', 'success' ),
        data
      }

      let excepted = {
        'readCartData': {
          'shippingInfo': {
            'shippingAddress': {
            },
            'shipMethodInfo': {
              'shipMethod': 'ups_ground',
              'estimatedDelivery': 'Get it by Thu, August 10',
              'cost': '$5.95',
              'displayName': 'Standard Ground Shipping'
            }
          }
        }
      }
      expect( reducer( res, actionCreator ) ).toEqual( excepted );
    } )

    it( 'GetQualified shipping method on success', () => {
      let actionCreator = {
        type: getServiceType( 'getQualifiedShipMethod', 'success' ),
        data:{
          qualifiedShipMethodListResponse:{
            messages:[],
            shipMethodList:[{ cost:'$5.95', displayName:'Standard Shipping', shipMethod:'ups_ground', estimatedDelivery:null }]
          },
          serviceInfo:{ lastFetchedTime:'2017-09-11 13:35:24.233-05:00' }
        }
      }

      let excepted = {
        getQualifiedShipMethod:{
          qualifiedShipMethodListResponse:{
            messages:[],
            shipMethodList:[{ cost:'$5.95', displayName:'Standard Shipping', shipMethod:'ups_ground', estimatedDelivery:null }]
          },
          serviceInfo:{ lastFetchedTime:'2017-09-11 13:35:24.233-05:00' }
        } };

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'shipping update on loading', () => {
      let actionCreator = {
        type: getServiceType( 'shippingUpdate', 'loading' )
      }

      let expected = {
        shippingSuccess: true,
        shippingError: []
      };


      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Shipping update success event with failure', () => {
      let actionCreator = {
        type: getServiceType( 'shippingUpdate', 'success' ),
        data:{
          result: 'Error',
          messages: [
            {
              messageDesc: 'First name is invalid, please correct.',
              messageKey: 'ERR_SHIPPING_INVALID_FIRST_NAME',
              messageType: 'Error',
              messageRef : 'shippingInfo.shippingAddress.firstName'
            }
          ]
        }
      }

      let expected = {
        shippingError:[
          {
            messageDesc: 'First name is invalid, please correct.',
            messageKey: 'ERR_SHIPPING_INVALID_FIRST_NAME',
            messageType: 'Error',
            messageRef : 'shippingInfo.shippingAddress.firstName'
          }
        ],
        shippingSuccess: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

  } );

  describe( 'CHECKOUT_COUPON_CASES', () =>{
    it( 'Apply coupon loading case', () => {
      let actionCreator = {
        type: getServiceType( 'applycoupon', 'loading' )
      }

      let expected = {
        couponApplyingOnCheckout: true,
        isCouponButtonClicked: false
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Login should do the cart merge', () => {

      let actionCreator = {
        type: getServiceType( 'login', 'success' ),
        data:{
          cartMerged: true
        }
      }

      let expected = {
        cartMerged: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'apply coupon failure case', () => {
      let actionCreator = {
        type: getServiceType( 'applycoupon', 'failure' )
      }

      let expected = {
        couponApplyingOnCheckout: false,
        isCouponButtonClicked: false
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'remove coupon failure action', () => {
      let actionCreator = {
        type: getServiceType( 'removecoupon', 'failure' )
      }

      let expected = { }
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Apply Coupon success case', () => {
      let actionCreator = {
        type: getServiceType( 'applycoupon', 'success' ),
        data:{
          couponAppliedStatus: false,
          couponCode: 'CPN1234567',
          couponAppliedErrorMsg: 'Code is not valid'
        }
      }

      let expected = {
        readCartData: {
          appliedCouponSummary: {
            couponAppliedStatus: false,
            couponCode: 'CPN1234567',
            couponAppliedErrorMsg: 'Code is not valid'
          }
        },
        couponApplyingOnCheckout: false
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Remove coupon success case', () => {
      let actionCreator = {
        type: getServiceType( 'removecoupon', 'success' ),
        data:{
          couponAppliedStatus:false
        }
      }

      let expected = {
        readCartData: {
          appliedCouponSummary: {
            couponAppliedStatus:false
          }
        },
        couponApplyingOnCheckout: false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Reset the Coupon State', () => {
      let actionCreator = {
        type: formTypes.RESET_COUPON_STATE
      }

      let expected = {
        isCouponButtonClicked: false
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'JOIN_NOW_CASES', () => {
    it( 'User rewards requested events', () => {
      let actionCreator = {
        type: getServiceType( 'userRewards', 'requested' )
      }

      let expected = { joinNowRewardsError: [] };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'User rewards success event with success scenario', () => {
      let actionCreator = {
        type: getServiceType( 'userRewards', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95,
            subTotal: 26,
            itemCount: '1',
            orderGiftWrapAmt: 0,
            additionalDiscount: null,
            couponDiscount: 0,
            estimatedTax: 0.96,
            rewardPointsDiscount: null,
            estimatedTotal: 33.91,
            rewardPointsEarned: 208,
            currencyCode: 'USD'
          },
          isRewardsMember: true
        }
      }

      let expected = {
        readCartData:{
          cartSummary:{
            shippingCost: 6.95,
            subTotal: 26,
            itemCount: '1',
            orderGiftWrapAmt: 0,
            additionalDiscount: null,
            couponDiscount: 0,
            estimatedTax: 0.96,
            rewardPointsDiscount: null,
            estimatedTotal: 33.91,
            rewardPointsEarned: 208,
            currencyCode: 'USD'
          }
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'User rewards success event with error scenario', () => {
      let actionCreator = {
        type: getServiceType( 'userRewards', 'success' ),
        data:{
          isRewardsMember:true,
          messages: [
            {
              messageKey: 'errorComputingPoints',
              messageType: 'Error',
              messageDesc: 'You will earn points with this order.'
            }
          ]
        }
      }

      let expected={
        joinNowRewardsError: [
          {
            messageKey: 'errorComputingPoints',
            messageType: 'Error',
            messageDesc: 'You will earn points with this order.'
          }
        ]
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'REDEEM_POINTS', () => {
    it( 'Redeem Points success case', () => {
      let actionCreator = {
        type: getServiceType( 'redeemPoints', 'success' ),
        data:{
          profileRedeemLevels:[
            { value: '2', points:'50.0' },
            { value: '14', points: '450.0' },
            { value: '16', points: '500.0' },
            { value: '19.5', points: '550.0' },
            { value: '22.5', points: '650.0' }
          ]
        }
      }

      let expected = {
        redeemPoints: {
          profileRedeemLevels:[
            { value: '2', points:'50.0' },
            { value: '14', points: '450.0' },
            { value: '16', points: '500.0' },
            { value: '19.5', points: '550.0' },
            { value: '22.5', points: '650.0' }
          ]
        }
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'PAYMENT SERVICE RESPOSSE', () => {
    it( 'Payment Success Case With Payment Type as creditCard', () => {
      let actionCreator = {
        type: getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          result:{
            cartSummary:{
              shippingCost: 5.95,
              subTotal: 25,
              itemCount: 1,
              estimatedTotal: 32.89
            },
            remainingPaymentDue: 0,
            paymentDetails: [
              {
                messages: [],
                paymentInfo:{
                  amount: 32.89,
                  nickName: 'VISA - 1111',
                  paymentType: 'creditCard',
                  paymentDetails: {
                    expirationYear: 2020,
                    creditCardNumber: 1111,
                    creditCardType: 'Visa',
                    expirationMonth: 12
                  },
                  contactInfo: {
                    firstName: 'Test',
                    lastName: 'Test',
                    address1: '4583 Delaware St',
                    address2: '',
                    city: 'San Diego',
                    state: 'CA',
                    country: 'US',
                    postalCode: '92116',
                    phoneNumber: '435-647-8754',
                    email: null
                  }
                }
              }
            ]
          },
          paymentType: 'creditCard'
        }
      }

      let expected = {
        creditCardDetails: {
          messages: [],
          paymentInfo: {
            amount: 32.89,
            contactInfo: {
              address1: '4583 Delaware St',
              address2: '',
              city: 'San Diego',
              country: 'US',
              email: null,
              firstName: 'Test',
              lastName: 'Test',
              phoneNumber: '435-647-8754',
              postalCode: '92116',
              state: 'CA'
            },
            nickName: 'VISA - 1111',
            paymentDetails: {
              creditCardNumber: 1111,
              creditCardType: 'Visa',
              expirationMonth: 12,
              expirationYear: 2020
            },
            paymentType: 'creditCard'
          }
        },
        editCCData: {
          address1: '4583 Delaware St',
          address2: '',
          city: 'San Diego',
          country: 'US',
          creditCardNumber: 1111,
          creditCardType: 'Visa',
          expirationMonth: 12,
          expirationYear: 2020,
          firstName: 'Test',
          lastName: 'Test',
          nickName: 'VISA - 1111',
          paymentType: 'creditCard',
          phoneNumber: '435-647-8754',
          postalCode: '92116',
          state: 'CA'
        },
        giftCardApplying: false,
        isSetCCPaymentFormSubmit: true,
        paymentError: [],
        paymentServiceResponse: {
          cartSummary: {
            estimatedTotal: 32.89,
            itemCount: 1,
            shippingCost: 5.95,
            subTotal: 25
          },
          paymentDetails: [
            {
              messages: [],
              paymentInfo: {
                amount: 32.89,
                contactInfo: {
                  address1: '4583 Delaware St',
                  address2: '',
                  city: 'San Diego',
                  country: 'US',
                  email: null,
                  firstName: 'Test',
                  lastName: 'Test',
                  phoneNumber: '435-647-8754',
                  postalCode: '92116',
                  state: 'CA'
                },
                nickName: 'VISA - 1111',
                paymentDetails: {
                  creditCardNumber: 1111,
                  creditCardType: 'Visa',
                  expirationMonth: 12,
                  expirationYear: 2020
                },
                paymentType: 'creditCard'
              }
            }
          ],
          remainingPaymentDue: 0
        },
        paymentType: 'creditCard',
        previousPaymentType: 'creditCard',
        readCartData: {
          cartSummary: {
            estimatedTotal: 32.89,
            itemCount: 1,
            shippingCost: 5.95,
            subTotal: 25
          },
          paymentDetails: [
            {
              messages: [],
              paymentInfo: {
                amount: 32.89,
                contactInfo: {
                  address1: '4583 Delaware St',
                  address2: '',
                  city: 'San Diego',
                  country: 'US',
                  email: null,
                  firstName: 'Test',
                  lastName: 'Test',
                  phoneNumber: '435-647-8754',
                  postalCode: '92116',
                  state: 'CA'
                },
                nickName: 'VISA - 1111',
                paymentDetails: {
                  creditCardNumber: 1111,
                  creditCardType: 'Visa',
                  expirationMonth: 12,
                  expirationYear: 2020
                },
                paymentType: 'creditCard'
              }
            }
          ]
        },
        remainingPaymentDue: 0
      }
      expect( reducer( { paymentType: 'creditCard' }, actionCreator ) ).toEqual( expected );
    } );

    it( 'Payment Success Case With Credit Card but Payment Type as Paypal and Profile Credit Card Count as 0', () => {
      let actionCreator = {
        type: getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          result:{
            cartSummary:{
              shippingCost: 5.95,
              subTotal: 25,
              itemCount: 1,
              estimatedTotal: 32.89
            },
            remainingPaymentDue: 0,
            paymentDetails: [
              {
                messages: [],
                paymentInfo:{
                  amount: 32.89,
                  nickName: 'VISA - 1111',
                  paymentType: 'creditCard',
                  paymentDetails: {
                    expirationYear: 2020,
                    creditCardNumber: 1111,
                    creditCardType: 'Visa',
                    expirationMonth: 12
                  },
                  contactInfo: {
                    firstName: 'Test',
                    lastName: 'Test',
                    address1: '4583 Delaware St',
                    address2: '',
                    city: 'San Diego',
                    state: 'CA',
                    country: 'US',
                    postalCode: '92116',
                    phoneNumber: '435-647-8754',
                    email: null
                  }
                }
              }
            ]
          },
          paymentType: 'creditCard'
        }
      }

      let expected = {
        creditCardDetails: {
          messages: [],
          paymentInfo: {
            amount: 32.89,
            contactInfo: {
              address1: '4583 Delaware St',
              address2: '',
              city: 'San Diego',
              country: 'US',
              email: null,
              firstName: 'Test',
              lastName: 'Test',
              phoneNumber: '435-647-8754',
              postalCode: '92116',
              state: 'CA'
            },
            nickName: 'VISA - 1111',
            paymentDetails: {
              creditCardNumber: 1111,
              creditCardType: 'Visa',
              expirationMonth: 12,
              expirationYear: 2020
            },
            paymentType: 'creditCard'
          }
        },
        editCCData: {
          address1: '4583 Delaware St',
          address2: '',
          city: 'San Diego',
          country: 'US',
          creditCardNumber: 1111,
          creditCardType: 'Visa',
          expirationMonth: 12,
          expirationYear: 2020,
          firstName: 'Test',
          lastName: 'Test',
          nickName: 'VISA - 1111',
          paymentType: 'creditCard',
          phoneNumber: '435-647-8754',
          postalCode: '92116',
          state: 'CA'
        },
        giftCardApplying: false,
        isSetCCPaymentFormSubmit: true,
        paymentError: [],
        paymentServiceResponse: {
          cartSummary: {
            estimatedTotal: 32.89,
            itemCount: 1,
            shippingCost: 5.95,
            subTotal: 25
          },
          paymentDetails: [
            {
              messages: [],
              paymentInfo: {
                amount: 32.89,
                contactInfo: {
                  address1: '4583 Delaware St',
                  address2: '',
                  city: 'San Diego',
                  country: 'US',
                  email: null,
                  firstName: 'Test',
                  lastName: 'Test',
                  phoneNumber: '435-647-8754',
                  postalCode: '92116',
                  state: 'CA'
                },
                nickName: 'VISA - 1111',
                paymentDetails: {
                  creditCardNumber: 1111,
                  creditCardType: 'Visa',
                  expirationMonth: 12,
                  expirationYear: 2020
                },
                paymentType: 'creditCard'
              }
            }
          ],
          remainingPaymentDue: 0
        },
        paymentType: 'paypal',
        previousPaymentType: 'creditCard',
        profileCreditCardListCount: 0,
        readCartData: {
          cartSummary: {
            estimatedTotal: 32.89,
            itemCount: 1,
            shippingCost: 5.95,
            subTotal: 25
          },
          paymentDetails: [
            {
              messages: [],
              paymentInfo: {
                amount: 32.89,
                contactInfo: {
                  address1: '4583 Delaware St',
                  address2: '',
                  city: 'San Diego',
                  country: 'US',
                  email: null,
                  firstName: 'Test',
                  lastName: 'Test',
                  phoneNumber: '435-647-8754',
                  postalCode: '92116',
                  state: 'CA'
                },
                nickName: 'VISA - 1111',
                paymentDetails: {
                  creditCardNumber: 1111,
                  creditCardType: 'Visa',
                  expirationMonth: 12,
                  expirationYear: 2020
                },
                paymentType: 'creditCard'
              }
            }
          ]
        },
        remainingPaymentDue: 0
      }
      expect( reducer( { paymentType: 'paypal', profileCreditCardListCount: 0 }, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'PROFILE CREDIT CARDS COUNT', () => {
    it( 'Profile Credit Cards Success Case With No Credit Cards In File', () => {
      let actionCreator = {
        type: getServiceType( 'profileCreditCards', 'success' ),
        data:{
          profileCreditCards:[]
        }
      }

      let expected = {
        profileCreditCardListCount: 0
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Profile Credit Cards Success Case With Credit Cards In File', () => {
      let actionCreator = {
        type: getServiceType( 'profileCreditCards', 'success' ),
        data:{
          profileCreditCards:[
            {
              creditCard: {
                nickName: 'VISA - 4111',
                creditCardNumber: '4111',
                contactInfo: {}
              }
            },
            {
              creditCard: {
                nickName: 'VISA - 5433',
                creditCardNumber: '5433',
                contactInfo: {}
              }
            }
          ]
        }
      }

      let expected = {
        paymentType: 'creditCard',
        profileCreditCardListCount: 2
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );
  } );


  describe( 'ALERT_WINDOW_RESIZE', () => {

    let screenHeight = 700;
    let screenWidth = 700;

    let actionCreator = {
      type: globalTypes.ALERT_WINDOW_RESIZE,
      screenHeight,
      screenWidth
    }

    it( 'should set `showSecurityIcon` attribute to false if the screenWidth is below 992px', () => {
      window.innerWidth=991;
      let screenHeight = 768;
      let screenWidth = 991;
      let actionCreator1 = {
        type: globalTypes.ALERT_WINDOW_RESIZE,
        screenHeight,
        screenWidth
      }

      let expectedOutput1 = {
        'showSecurityIcon': false
      };
      expect( reducer( {}, actionCreator1 ) ).toEqual( expectedOutput1 );
    } );

    it( 'should set `showSecurityIcon` attribute to true if the screenWidth is above 992px', () => {
      let screenHeight = 768;
      let screenWidth = 993;
      let actionCreator1 = {
        type: globalTypes.ALERT_WINDOW_RESIZE,
        screenHeight,
        screenWidth
      }

      let expectedOutput1 = {
        'showSecurityIcon': true
      };
      expect( reducer( {}, actionCreator1 ) ).toEqual( expectedOutput1 );
    } );



  } );

  describe( 'TOGGLE_SECURITY_CODE_ICON', () => {
    it( 'should set `showSecurityIcon` attribute to true when the status is set to true', () => {
      let actionCreator = {
        type: types.TOGGLE_SECURITY_CODE_ICON,
        status: true
      }
      let expectedOutput1 = {
        'showSecurityIcon': true
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput1 );
    } );

  } )

  describe( 'Value check for isRewardPointsRemoved and isGiftCardRemoved during paymentService loading and removed', ( ) => {

    it( 'paymentServiceResponse loading should return isGiftCardRemoved as false when applying Gift Card', ( ) => {
      const res = {
        paymentType: 'giftCard'
      }
      const actionCreator2 = {
        type: getServiceType( 'paymentServiceResponse', 'loading' ),
        data: res,
        couponOfferReqNotMet: false
      }
      const expectedOutput = {
        giftCardApplying: false,
        isGiftCardRemoved: false,
        isSetCCPaymentFormSubmit: false
      }
      expect( reducer( {}, actionCreator2 ) ).toEqual( expectedOutput );

    } );

    it( 'paymentServiceResponse loading should return isRewardPointsRemoved as false when applying Rewards Points', ( ) => {
      const res = {
        paymentType: 'loyalty'
      }
      const actionCreator2 = {
        type: getServiceType( 'paymentServiceResponse', 'loading' ),
        data: res,
        couponOfferReqNotMet: false
      }
      const expectedOutput = {
        giftCardApplying: false,
        isRewardPointsRemoved: false,
        isSetCCPaymentFormSubmit: false
      }
      expect( reducer( {}, actionCreator2 ) ).toEqual( expectedOutput );

    } );

    it( 'removePaymentService success should return isRewardPointsRemoved as true when clicked on remove rewards points link', ( ) => {
      const res = {
        paymentType: 'loyalty',
        result: {
          paymentDetails: {}
        }
      };
      const actionCreator2 = {
        type: getServiceType( 'removePaymentService', 'success' ),
        data: res,
        couponOfferReqNotMet: false
      }
      const expectedOutput = {
        isRewardPointsRemoved: true,
        loyaltyCardDetails: {},
        paymentServiceResponse: {
          paymentDetails: {}
        },
        readCartData: {
          cartSummary: undefined,
          paymentDetails: {}
        },
        remainingPaymentDue: undefined
      }
      expect( reducer( {}, actionCreator2 ) ).toEqual( expectedOutput );
    } );

    it( 'removePaymentService success should return isGiftCardRemoved as true when clicked on remove rewards points link', ( ) => {
      const res = {
        paymentType: 'giftCard',
        result: {
          paymentDetails: {}
        }
      };
      const actionCreator2 = {
        type: getServiceType( 'removePaymentService', 'success' ),
        data: res,
        couponOfferReqNotMet: false
      }
      const expectedOutput = {
        giftCardDetails: {},
        giftCardError: undefined,
        isGiftCardRemoved: true,
        paymentServiceResponse: {
          paymentDetails: {}
        },
        readCartData: {
          cartSummary: undefined,
          paymentDetails: {}
        },
        remainingPaymentDue: undefined
      }
      expect( reducer( {}, actionCreator2 ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Clear server level error logs', ( ) => {

    describe( 'Coupon Form server level error logs', ( ) => {
      it( 'Coupon Form - should clear coupon error message upon change in coupon formdata', () => {
        let state = {
          readCartData:{
            appliedCouponSummary: {
              couponCode:'test',
              couponAppliedErrorMsg: 'code is invalid'
            }
          }
        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Coupon',
            field:'couponName'
          },
          payload: 'tes'
        }
        let expectedOutput ={
          readCartData:{
            appliedCouponSummary: {
              couponCode:'test',
              couponAppliedErrorMsg: undefined
            }
          }
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
    } );
    describe( 'Shipping Form server level error logs', ( ) => {

      let state = {
        shippingError : [{
          messageKey: 'ERR_SHIPPING_INVALID_ADDRESS',
          messageType: 'Error',
          messageRef: 'shipAddrInfo',
          messageDesc: 'Please enter a valid address and re-submit.'
        }],
        editAddressData:{
          addressData: {
            lastName: 'lastName',
            country: 'US',
            address2: null,
            city: 'city',
            address1: 'address1',
            postalCode: '99999',
            firstName: 'firstname',
            phoneNumber: '111-111-1111',
            state: 'AP',
            email: 'test@ulta.com'
          }
        },
        readCartData:{
          shippingInfo: {
            shippingAddress: {
              lastName: 'lastName',
              country: 'US',
              address2: null,
              city: 'city',
              address1: 'address1',
              postalCode: '99999',
              firstName: 'firstname',
              phoneNumber: '111-111-1111',
              state: 'AP',
              email: 'test@ulta.com'
            },
            messages: [
              {
                messageKey: 'ERR_SHIPPING_INVALID_ADDRESS',
                messageType: 'Error',
                messageRef: 'shipAddrInfo',
                messageDesc: 'Please enter a valid address and re-submit.'
              }
            ]
          }
        }
      }

      let expectedOutput ={
        shippingError : [],
        editAddressData:{
          addressData: {
            lastName: 'lastName',
            country: 'US',
            address2: null,
            city: 'city',
            address1: 'address1',
            postalCode: '99999',
            firstName: 'firstname',
            phoneNumber: '111-111-1111',
            state: 'AP',
            email: 'test@ulta.com'
          }
        },
        readCartData:{
          shippingInfo: {
            shippingAddress: {
              lastName: 'lastName',
              country: 'US',
              address2: null,
              city: 'city',
              address1: 'address1',
              postalCode: '99999',
              firstName: 'firstname',
              phoneNumber: '111-111-1111',
              state: 'AP',
              email: 'test@ulta.com'
            },
            messages: [],
            isShippingAddressErrorCleared : true
          }
        }
      }

      it( 'Shipping Form - should set activeField in the state on focus of addressline1', () => {
        const action = {
          type: ReduxActionType.FOCUS,
          meta:{
            form:'Shipping',
            field:'address1shippingAddressForm'
          },
          payload: 'addressLine1'
        }
        const tempState = { activeField:'' } ;
        const formFocusExpectedOutput={ activeField:'address1shippingAddressForm' };
        expect( reducer( tempState, action ) ).toEqual( formFocusExpectedOutput );
      } );

      it( 'Shipping Form - should clear Shipping error message upon change in addressline1 of Shippingform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'address1shippingAddressForm'
          },
          payload: 'addressLine1'
        }
        state.activeField = 'address1shippingAddressForm';
        expectedOutput.activeField = 'address1shippingAddressForm';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Shipping Form - should clear Shipping error message upon change in addressline2 of Shippingform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'address2shippingAddressForm'
          },
          payload: 'addressLine2'
        }
        state.activeField = 'address2shippingAddressForm';
        expectedOutput.activeField = 'address2shippingAddressForm';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Shipping Form - should clear Shipping error message upon change in postalCode of Shippingform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'postalCodeshippingAddressForm'
          },
          payload: '88888'
        }
        state.activeField = 'postalCodeshippingAddressForm';
        expectedOutput.activeField = 'postalCodeshippingAddressForm';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Shipping Form - should clear Shipping error message upon change in city of Shippingform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'cityshippingAddressForm'
          },
          payload: 'cit'
        }
        state.activeField = 'cityshippingAddressForm';
        expectedOutput.activeField = 'cityshippingAddressForm';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Shipping Form - should clear Shipping error message upon change in state of Shippingform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'state'
          },
          payload: 'A'
        }
        state.activeField = 'state';
        expectedOutput.activeField = 'state';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
      it( 'Shipping Form - should clear Shipping error message upon change in state of Shippingform data, even if activefield is not set for state', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'state'
          },
          payload: 'A'
        }
        state.activeField = '';
        expectedOutput.activeField = '';
        const actual = reducer( state, action );
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
    } );

    describe( 'Payment Form server level error logs', ( ) => {

      let state = {
        paymentError : [{
          messageKey: 'errorCardInvExpirationYear',
          messageType: 'Error',
          messageRef: 'paymentInfo.paymentDetails.expirationYear',
          messageDesc: 'Enter valid expiration date'
        }],
        creditCardDetails :{
          paymentInfo:{
            paymentDetails:{
              creditCardNumber : '9887',
              creditCardType : 'visa',
              expirationMonth : '11',
              expirationYear: '3333'
            }
          },
          messages:[{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }]
        }
      }
      let expectedOutput ={
        paymentError : [],
        creditCardDetails :{
          paymentInfo:{
            paymentDetails:{
              creditCardNumber : '9887',
              creditCardType : 'visa',
              expirationMonth : '11',
              expirationYear: '3333'
            }
          },
          messages:[],
          isPaymentErrorCleared : true
        }
      }

      it( 'Payment Form - should clear Payment error message upon change in creditcardnumber of paymentform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'paymentForm',
            field:'creditCardNumber'
          },
          payload: '****988'
        }
        state.activeField = 'creditCardNumber';
        expectedOutput.activeField = 'creditCardNumber';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Payment Form - should clear Payment error message upon change in expirationDate of paymentform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'paymentForm',
            field:'expirationDate'
          },
          payload: '11/2022'
        }
        state.activeField = 'expirationDate';
        expectedOutput.activeField = 'expirationDate';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Payment Form - should clear Payment error message upon change in securityCode of paymentform data -cardType :visa', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'paymentForm',
            field:'securityCode'
          },
          payload: '11'
        }
        state.activeField = 'securityCode';
        expectedOutput.activeField = 'securityCode';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Payment Form - should clear Payment error message upon change in securityCode of paymentform data -cardType :AmericanExpress', () => {
        state = {
          paymentError : [{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }],
          creditCardDetails :{
            paymentInfo:{
              paymentDetails:{
                creditCardNumber : '9887',
                creditCardType : 'AmericanExpress',
                expirationMonth : '11',
                expirationYear: '3333'
              }
            },
            messages:[{
              messageKey: 'errorCardInvExpirationYear',
              messageType: 'Error',
              messageRef: 'paymentInfo.paymentDetails.expirationYear',
              messageDesc: 'Enter valid expiration date'
            }]
          }
        }
        expectedOutput ={
          paymentError : [],
          creditCardDetails :{
            paymentInfo:{
              paymentDetails:{
                creditCardNumber : '9887',
                creditCardType : 'AmericanExpress',
                expirationMonth : '11',
                expirationYear: '3333'
              }
            },
            messages:[],
            isPaymentErrorCleared : true
          }
        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'paymentForm',
            field:'securityCode'
          },
          payload: '111'
        }
        state.activeField = 'securityCode';
        expectedOutput.activeField = 'securityCode';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
    } );

    describe( 'Gift card Form server level error logs', ( ) => {
      let state = {
        giftCardDetails:{
          messages:[{
            messageKey: 'invalidPin',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.giftCardPin',
            messageDesc: 'Enter valid pin number'
          }],
          paymentInfo: {
            amount: 0,
            paymentType: 'giftCard',
            paymentDetails: {
              giftcardNumber: '7777082394783534',
              giftcardBalance: 0,
              currencyCode: 'USD'
            }
          }
        }
      }
      let expectedOutput = {
        giftCardDetails:{
          messages:[],
          paymentInfo: {
            amount: 0,
            paymentType: 'giftCard',
            paymentDetails: {
              giftcardNumber: '7777082394783534',
              giftcardBalance: 0,
              currencyCode: 'USD'
            }
          }
        }
      }

      it( 'GiftCard Form - should clear error message upon change in giftcard number of giftCard form data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'giftCard',
            field:'giftCardNumber'
          },
          payload: '777708239478353'
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'GiftCard Form - should clear error message upon change in giftCardPin of giftCard form data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'giftCard',
            field:'giftCardPin'
          },
          payload: '1234567'
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'loadStatePaymentDetails method should remove and return giftCard Payment details if there is any error in the gift card response', () => {
        let res = {
          'cartSummary': {
            'shippingCost': 'FREE',
            'subTotal': 85,
            'itemCount': 1,
            'orderGiftWrapAmt': 0,
            'additionalDiscount': null,
            'couponDiscount': 0,
            'estimatedTax': 'TBD',
            'giftCard': null,
            'rewardPointsDiscount': null,
            'estimatedTotal': 85,
            'rewardPointsEarned': null,
            'currencyCode': 'USD'
          },
          'appliedCouponSummary': {
            'couponAppliedStatus': false
          },
          'remainingPaymentDue': 85,
          'id': 'D200854400',
          'paymentDetails': [
            {
              'messages': [
                {
                  'messageKey': 'unknownAccount',
                  'messageType': 'Error',
                  'messageRef': 'paymentInfo.paymentDetails.giftCardNumber',
                  'messageDesc': 'Enter valid gift card number'
                }
              ],
              'paymentInfo': {
                'amount': 0,
                'paymentType': 'giftCard',
                'paymentDetails': {
                  'giftcardNumber': '2323232323232323',
                  'giftcardBalance': 0,
                  'currencyCode': 'USD'
                }
              }
            }
          ]
        }
        let expectedOutput = {
          'giftCardDetails':
            {
              'messages': [
                {
                  'messageKey': 'unknownAccount',
                  'messageType': 'Error',
                  'messageRef': 'paymentInfo.paymentDetails.giftCardNumber',
                  'messageDesc': 'Enter valid gift card number'
                }
              ],
              'paymentInfo': {
                'amount': 0,
                'paymentType': 'giftCard',
                'paymentDetails': undefined
              }
            },
          giftCardError: true
        }
        expect( loadStatePaymentDetails( res.paymentDetails, 'giftCard' ) ).toEqual( expectedOutput );
      } );

      it( 'toggleCardDetails method should remove and return giftCard Payment details if there is any error in the gift card response ', () => {
        let res = {
          'cartSummary': {
            'shippingCost': 'FREE',
            'subTotal': 85,
            'itemCount': 1,
            'orderGiftWrapAmt': 0,
            'additionalDiscount': null,
            'couponDiscount': 0,
            'estimatedTax': 'TBD',
            'giftCard': null,
            'rewardPointsDiscount': null,
            'estimatedTotal': 85,
            'rewardPointsEarned': null,
            'currencyCode': 'USD'
          },
          'appliedCouponSummary': {
            'couponAppliedStatus': false
          },
          'remainingPaymentDue': 85,
          'id': 'D200854400',
          'paymentDetails': [
            {
              'messages': [
                {
                  'messageKey': 'unknownAccount',
                  'messageType': 'Error',
                  'messageRef': 'paymentInfo.paymentDetails.giftCardNumber',
                  'messageDesc': 'Enter valid gift card number'
                }
              ],
              'paymentInfo': {
                'amount': 0,
                'paymentType': 'giftCard',
                'paymentDetails': {
                  'giftcardNumber': '2323232323232323',
                  'giftcardBalance': 0,
                  'currencyCode': 'USD'
                }
              }
            }
          ]
        }
        let expectedOutput = {
          'giftCardDetails':
            {
              'messages': [
                {
                  'messageKey': 'unknownAccount',
                  'messageType': 'Error',
                  'messageRef': 'paymentInfo.paymentDetails.giftCardNumber',
                  'messageDesc': 'Enter valid gift card number'
                }
              ],
              'paymentInfo': {
                'amount': 0,
                'paymentType': 'giftCard',
                'paymentDetails': undefined
              }
            },
          giftCardError: true,
          loyaltyCardDetails: {},
          paymentType: 'creditCard',
          creditCardDetails: {},
          editCCData: {}
        }
        expect( toggleCardDetails( res.paymentDetails ) ).toEqual( expectedOutput );
      } );

    } );
    describe( 'clear server level error log when we click change creditcard option', ( )=> {
      let state = {
        paymentError : [{
          messageKey: 'errorCardInvExpirationYear',
          messageType: 'Error',
          messageRef: 'paymentInfo.paymentDetails.expirationYear',
          messageDesc: 'Enter valid expiration date'
        }],
        creditCardDetails :{
          paymentInfo:{
            paymentDetails:{
              creditCardNumber : '9887',
              creditCardType : 'visa',
              expirationMonth : '11',
              expirationYear: '3333'
            }
          },
          messages:[{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }]
        }
      }
      let expectedOutput ={
        paymentError : [],
        creditCardDetails :{
          paymentInfo:{
            paymentDetails:{
              creditCardNumber : '9887',
              creditCardType : 'visa',
              expirationMonth : '11',
              expirationYear: '3333'
            }
          },
          messages:[]
        }
      }
      it( 'Profile Credit Cards request Case', () => {
        let actionCreator = {
          type: getServiceType( 'profileCreditCards', 'requested' ),
          data:{
            profileCreditCards:[]
          }
        }
        expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
      } );
    } )
    describe( 'PaymentCCSecurityCode form clear server level ', ( )=> {
      let state = {
        paymentError : [{
          messageKey: 'errorCardInvExpirationYear',
          messageType: 'Error',
          messageRef: 'paymentInfo.paymentDetails.expirationYear',
          messageDesc: 'Enter valid expiration date'
        }],
        creditCardDetails :{
          paymentInfo:{
            paymentDetails:{
              creditCardNumber : '9887',
              creditCardType : 'visa',
              expirationMonth : '11',
              expirationYear: '3333'
            }
          },
          messages:[{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }]
        }
      }
      let expectedOutput ={
        paymentError : [],
        creditCardDetails :{
          paymentInfo:{
            paymentDetails:{
              creditCardNumber : '9887',
              creditCardType : 'visa',
              expirationMonth : '11',
              expirationYear: '3333'
            }
          },
          messages:[]
        }
      }
      it( 'Payment Form - should clear Payment error message upon change in securityCode of paymentform data -cardType :visa', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'PaymentCCSecurityCode',
            field:'ccSecurityCode'
          },
          payload: '11'
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
      it( 'Payment Form - should clear Payment error message upon change in securityCode of paymentform data -cardType :AmericanExpress', () => {
        state = {
          paymentError : [{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }],
          creditCardDetails :{
            paymentInfo:{
              paymentDetails:{
                creditCardNumber : '9887',
                creditCardType : 'AmericanExpress',
                expirationMonth : '11',
                expirationYear: '3333'
              }
            },
            messages:[{
              messageKey: 'errorCardInvExpirationYear',
              messageType: 'Error',
              messageRef: 'paymentInfo.paymentDetails.expirationYear',
              messageDesc: 'Enter valid expiration date'
            }]
          }
        }
        expectedOutput ={
          paymentError : [],
          creditCardDetails :{
            paymentInfo:{
              paymentDetails:{
                creditCardNumber : '9887',
                creditCardType : 'AmericanExpress',
                expirationMonth : '11',
                expirationYear: '3333'
              }
            },
            messages:[]
          }
        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'PaymentCCSecurityCode',
            field:'ccSecurityCode'
          },
          payload: '111'
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
    } );
  } );
} );
