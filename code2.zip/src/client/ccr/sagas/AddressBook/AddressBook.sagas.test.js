/**
 * Created by rush on 5/3/17.
 */

/**
 * LoadCart  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import saga, { listener } from './AddressBook.sagas';
import Cookies from 'js-cookie';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';



const sessionID = '12321';
const type = 'loadCart';
describe( 'defaultSaga Saga', () => {

  registerServiceName( type );

  describe( 'listener saga success path', () => {
    const listenerSaga = listener( type, { data: sessionID } );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor  = listenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( ajax, { type } ) );

    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        body: {
          title: 'test',
          status: 'ok'
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should throw the error', () => {

      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }

      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );

  } );


} );
