import { takeEvery, call, put } from 'redux-saga/effects';
import {
  actions as serviceActions,
  types as serviceActionTypes,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';
import isUndefined from 'lodash/isUndefined';
import has from 'lodash/has';
import {
  ajax
} from 'utils/Ajax/Ajax';

export const listenerSameSession = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let values = {
      paymentType: 'paypal'
    }
    const res = yield call(
      ajax, {
        type,
        method:'post',
        values
      }
    );
    yield put( getActionDefinition( type, 'success' )( res.body.data ) );

    if( res.body.data ){
      if( res.body.data.result ){
        const {
          pathname
        } = action.data.history.location;
        let checkoutPath = '/checkout';
        action.data.history.replace( checkoutPath );
        yield put( serviceActions.pageRedirect( pathname, checkoutPath ) );
      }
      else {
        const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
        const loadCartMessages = res.body.data.messages;
        yield put( serviceActions.checkoutRedirectListener( action.data.history, qty, loadCartMessages ) );
      }
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export const listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    let recipientName, reciepientFirstName, reciepientLastName;
    if( !isUndefined( action.data.details.shippingAddress.recipientName ) ){
      recipientName = action.data.details.shippingAddress.recipientName;
      reciepientFirstName = recipientName.substring( 0, recipientName.indexOf( ' ' ) );
      reciepientLastName = recipientName.substring( recipientName.indexOf( ' ' )+1 );
    }
    let values = {
      nonce: action.data.nonce,
      email: action.data.details.email,
      payerId: action.data.details.payerId,
      paymentType: 'paypal',
      firstName: action.data.details.firstName,
      lastName: action.data.details.lastName,
      address1: action.data.details.billingAddress.line1,
      address2: action.data.details.billingAddress.line2,
      city: action.data.details.billingAddress.city,
      state: action.data.details.billingAddress.state,
      country: action.data.details.billingAddress.countryCode,
      postalCode: action.data.details.billingAddress.postalCode,
      phoneNumber: action.data.details.phone,
      shipFirstName: reciepientFirstName,
      shipLastName: reciepientLastName,
      shipAddressLine1: action.data.details.shippingAddress.line1,
      shipAddressLine2: action.data.details.shippingAddress.line2,
      shipCity: action.data.details.shippingAddress.city,
      shipState: action.data.details.shippingAddress.state,
      shipCountry: action.data.details.shippingAddress.countryCode,
      shipPostalCode: action.data.details.shippingAddress.postalCode,
      shipPhoneNumber: action.data.details.phone
    }

    const res = yield call(
      ajax, {
        type,
        method:'post',
        values
      }
    );
    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data ){
      if( res.body.data.result ){
        const {
          pathname
        } = action.data.history.location;
        let checkoutPath = '/checkout';
        action.data.history.replace( checkoutPath );
        yield put( serviceActions.pageRedirect( pathname, checkoutPath ) );
      }
      else {
        const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
        const loadCartMessages = res.body.data.messages;
        yield put( serviceActions.checkoutRedirectListener( action.data.history, qty, loadCartMessages ) );
      }
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }
}

export default function*(){
  let serviceType = 'applyExpressPayment';
  registerServiceName( serviceType );
  let serviceTypeSameSession = 'applyExpressPaymentSameSession';
  registerServiceName( serviceTypeSameSession );
  yield [
    takeEvery( getServiceType( 'applyExpressPayment', 'requested' ), listener, serviceType ),
    takeEvery( getServiceType( 'applyExpressPaymentSameSession', 'requested' ), listenerSameSession, serviceType )
  ]
}
