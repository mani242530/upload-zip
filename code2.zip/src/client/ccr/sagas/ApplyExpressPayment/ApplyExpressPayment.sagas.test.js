import saga, { listener, listenerSameSession } from './ApplyExpressPayment.sagas';
import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import { ajax } from 'utils/Ajax/Ajax';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition,
  actions as serviceActions,
  types as serviceActionTypes
} from 'shared/actions/Services/Services.actions';


describe( 'ApplyExpressPayment Saga', () => {

  jest.mock( 'utils/Ajax/Ajax', ()=>{
    return { ajax:jest.fn() }
  } );
  const type = 'applyExpressPayment';
  registerServiceName( type );
  const typeApplyPaymentSameSession = 'applyExpressPaymentSameSession';
  registerServiceName( typeApplyPaymentSameSession );

  describe( 'default saga', () =>{

    const coreSaga = saga();

    it( 'should listen for the applyPayment requested method', () =>{

      const takeLatestDescriptor = coreSaga.next().value;

      expect( takeLatestDescriptor ).toEqual( [
        takeEvery( getServiceType( 'applyExpressPayment', 'requested' ), listener, type ),
        takeEvery( getServiceType( 'applyExpressPaymentSameSession', 'requested' ), listenerSameSession, type )
      ] );
    } );

  } );

  describe( 'listener saga success and error path', () =>{

    const data = {
      data: {
        nonce : '',
        details: {
          email:'test',
          payerId: 'LUT2LJSVTJR5N',
          firstName:'test',
          lastName:'test',
          billingAddress :{
            line1:'700 keeaumoku st',
            line2:'',
            city:'Honolulu',
            state:'HI',
            countryCode:'',
            postalCode:'96814'
          },
          shippingAddress: {
            recipientName: 'test test',
            line1:'700 keeaumoku st',
            line2:'',
            city:'Honolulu',
            state:'HI',
            countryCode:'',
            postalCode:'96814'
          },
          phone:''
        },
        history: undefined
      }
    }
    const values = {
      nonce : '',
      email:'test',
      payerId: 'LUT2LJSVTJR5N',
      paymentType: 'paypal',
      firstName:'test',
      lastName:'test',
      address1:'700 keeaumoku st',
      address2:'',
      city:'Honolulu',
      state:'HI',
      country:'',
      postalCode:'96814',
      phoneNumber:'',
      shipFirstName: 'test',
      shipLastName: 'test',
      shipAddressLine1: '700 keeaumoku st',
      shipAddressLine2: '',
      shipCity: 'Honolulu',
      shipState: 'HI',
      shipCountry: '',
      shipPostalCode: '96814',
      shipPhoneNumber: ''
    }
    const listenerSaga = listener( type, data );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        status: 'ok',
        body: {
          data:{
            cartSummary: {
              itemCount: '3'
            },
            messages: 'test'
          }
        }
      }
      const {
        pathname
      } = '';
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );
    it( 'After the success event - redirect to checkout', () => {

      const putDescriptor = listenerSaga.next().value;
      const res = {
        status: 'ok',
        body: {
          data:{
            cartSummary: {
              itemCount: '3'
            },
            messages: 'test'
          }
        }
      }
      const {
        pathname
      } = '';
      const qty=3;
      const loadCartMessages='test';

      expect( putDescriptor ).toEqual( put( serviceActions.checkoutRedirectListener( data.history, qty, loadCartMessages ) ) );
    } );
    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

  describe( 'listener saga success and error path', () =>{

    const action = {
      data: {
        nonce : '',
        details: {
          email:'test',
          payerId: 'LUT2LJSVTJR5N',
          firstName:'test',
          lastName:'test',
          billingAddress :{
            line1:'700 keeaumoku st',
            line2:'',
            city:'Honolulu',
            state:'HI',
            countryCode:'',
            postalCode:'96814'
          },
          shippingAddress: {
            recipientName: 'test test',
            line1:'700 keeaumoku st',
            line2:'',
            city:'Honolulu',
            state:'HI',
            countryCode:'',
            postalCode:'96814'
          },
          phone:''
        },
        history: {
          location: {
            'pathname': '/bag'
          },
          replace:jest.fn()
        }
      }
    }
    const values = {
      nonce : '',
      email:'test',
      payerId: 'LUT2LJSVTJR5N',
      paymentType: 'paypal',
      firstName:'test',
      lastName:'test',
      address1:'700 keeaumoku st',
      address2:'',
      city:'Honolulu',
      state:'HI',
      country:'',
      postalCode:'96814',
      phoneNumber:'',
      shipFirstName: 'test',
      shipLastName: 'test',
      shipAddressLine1: '700 keeaumoku st',
      shipAddressLine2: '',
      shipCity: 'Honolulu',
      shipState: 'HI',
      shipCountry: '',
      shipPostalCode: '96814',
      shipPhoneNumber: ''
    }
    const listenerSaga = listener( type, action );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        status: 'ok',
        body: {
          data :{
            result:'true'
          }
        }
      }
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'After the success event should redirect to checkout', () => {
      const pathname='/bag';
      const checkoutPath='/checkout';
      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( serviceActions.pageRedirect( pathname, checkoutPath ) ) );
    } );
  } );

  describe( 'listenerSameSession saga success and error path', () =>{

    const type = 'applyExpressPaymentSameSession';

    const values = {
      paymentType: 'paypal'
    }
    const data = {
      data: {
        history : undefined
      }
    }
    const listenerSameSessionSaga = listenerSameSession( type, data );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSameSessionSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSameSessionSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data :{
            cartSummary: {
              itemCount: '3'
            },
            messages: 'test'
          }
        }
      }
      const putDescriptor = listenerSameSessionSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'After the success event - redirect to checkout', () => {
      const res = {
        data :{
          body: {
            cartSummary: {
              itemCount: '3'
            },
            messages: 'test'
          }
        }
      }
      const qty=3;
      const loadCartMessages='test';
      const putDescriptor = listenerSameSessionSaga.next().value;
      expect( putDescriptor ).toEqual( put( serviceActions.checkoutRedirectListener( data.history, qty, loadCartMessages ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSameSessionSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );
  } );

  describe( 'listenerSameSession saga success path', () =>{

    const type = 'applyExpressPaymentSameSession';

    const values = {
      paymentType: 'paypal'
    }
    const action = {
      data: {
        history: {
          location: {
            'pathname': '/bag'
          },
          replace:jest.fn()
        }

      }
    }
    const listenerSameSessionSaga = listenerSameSession( type, action );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSameSessionSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSameSessionSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data :{
            result:'true'
          }
        }
      }
      const putDescriptor = listenerSameSessionSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'After the success event should redirect to checkout', () => {
      const pathname='/bag';
      const checkoutPath='/checkout';
      const putDescriptor = listenerSameSessionSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( serviceActions.pageRedirect( pathname, checkoutPath ) ) );
    } );
  } );
} );