import { takeEvery, call, put } from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';
import {
  ajax
} from 'utils/Ajax/Ajax';

export const listenerSameSession = function*( type, data ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let values = {
      paymentType: 'paypal'
    }
    const res = yield call(
      ajax, {
        type,
        method:'post',
        values
      }
    );
    yield put( getActionDefinition( type, 'success' )( res.body ) );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export const listenerSaveToAccount = function*( type, data ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let values = {
      paymentType: 'paypal',
      saveToProfile: true
    }
    const res = yield call(
      ajax, {
        type,
        method:'post',
        values
      }
    );
    yield put( getActionDefinition( type, 'success' )( res.body ) );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export const listener = function*( type, data ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let values = {
      nonce: data.data.nonce,
      email: data.data.details.email,
      payerId: data.data.details.payerId,
      paymentType: 'paypal',
      firstName: data.data.details.firstName,
      lastName: data.data.details.lastName,
      address1: data.data.details.billingAddress.line1,
      address2: data.data.details.billingAddress.line2,
      city: data.data.details.billingAddress.city,
      state: data.data.details.billingAddress.state,
      country: data.data.details.billingAddress.countryCode,
      postalCode: data.data.details.billingAddress.postalCode,
      phoneNumber: data.data.details.phone
    }
    const res = yield call(
      ajax, {
        type,
        method:'post',
        values
      }
    );
    yield put( getActionDefinition( type, 'success' )( res.body ) );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'applyPayment';
  registerServiceName( serviceType );
  let serviceTypeSameSession = 'applyPaymentSameSession';
  registerServiceName( serviceTypeSameSession );
  let serviceTypeSaveToMyAccount = 'savePaypaltoMyAccount';
  registerServiceName( serviceTypeSaveToMyAccount );
  yield [
    takeEvery( getServiceType( 'applyPayment', 'requested' ), listener, serviceType ),
    takeEvery( getServiceType( 'applyPaymentSameSession', 'requested' ), listenerSameSession, serviceType ),
    takeEvery( getServiceType( 'savePaypaltoMyAccount', 'requested' ), listenerSaveToAccount, serviceType )
  ]
}
