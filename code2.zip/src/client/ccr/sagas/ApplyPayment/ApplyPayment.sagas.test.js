import saga, { listener, listenerSameSession, listenerSaveToAccount } from './ApplyPayment.sagas';
import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import { ajax } from 'utils/Ajax/Ajax';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

describe( 'ApplyPayment Saga', () => {

  jest.mock( 'utils/Ajax/Ajax', ()=>{
    return { ajax:jest.fn() }
  } );
  const type = 'applyPayment';
  registerServiceName( type );
  const typeApplyPaymentSameSession = 'applyPaymentSameSession';
  registerServiceName( typeApplyPaymentSameSession );
  const typeSavePaypaltoMyAccount = 'savePaypaltoMyAccount';
  registerServiceName( typeSavePaypaltoMyAccount );

  describe( 'default saga', () =>{

    const coreSaga = saga();

    it( 'should listen for the applyPayment requested method', () =>{

      const takeLatestDescriptor = coreSaga.next().value;

      expect( takeLatestDescriptor ).toEqual( [
        takeEvery( getServiceType( 'applyPayment', 'requested' ), listener, type ),
        takeEvery( getServiceType( 'applyPaymentSameSession', 'requested' ), listenerSameSession, type ),
        takeEvery( getServiceType( 'savePaypaltoMyAccount', 'requested' ), listenerSaveToAccount, type )
      ] );
    } );

  } );

  describe( 'listener saga success and error path', () =>{

    const data = {
      data: {
        nonce : '',
        details: {
          email:'test',
          firstName:'test',
          lastName:'test',
          billingAddress :{
            line1:'700 keeaumoku st',
            line2:'',
            city:'Honolulu',
            state:'HI',
            countryCode:'',
            postalCode:'96814'
          },
          phone:''
        }
      }
    }
    const values = {
      nonce : '',
      email:'test',
      paymentType: 'paypal',
      firstName:'test',
      lastName:'test',
      address1:'700 keeaumoku st',
      address2:'',
      city:'Honolulu',
      state:'HI',
      country:'',
      postalCode:'96814',
      phoneNumber:''
    }
    const listenerSaga = listener( type, data );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        status: 'ok'
      }
      const putDescriptor = listenerSaga.next( { body: res } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );
  } );

  describe( 'listenerSameSession saga success and error path', () =>{

    const type = 'applyPaymentSameSession';

    const values = {
      paymentType: 'paypal'
    }
    const data={};
    const listenerSameSessionSaga = listenerSameSession( type, data );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSameSessionSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSameSessionSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        status: 'ok'
      }
      const putDescriptor = listenerSameSessionSaga.next( { body: res } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSameSessionSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );
  } );

  describe( 'listenerSaveToAccount saga success and error path', () =>{

    const type = 'savePaypaltoMyAccount';

    const values = {
      paymentType: 'paypal',
      saveToProfile: true
    }
    const data={};
    const listenerSaveToAccountSaga = listenerSaveToAccount( type, data );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaveToAccountSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaveToAccountSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        status: 'ok'
      }
      const putDescriptor = listenerSaveToAccountSaga.next( { body: res } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaveToAccountSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );
  } );
} );