import { takeEvery, call, put, select } from 'redux-saga/effects';
import { getUserState } from 'shared/reducers/User/User.reducer';
import isUndefined from 'lodash/isUndefined';


import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  actions as serviceActions,
  types as serviceActionTypes,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';

import {
  types as MiniCart
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

// Individual exports for testing
export const listener = function*( type, action ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );
    const res = yield call( ajax,
      {
        type,
        method: 'post'
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );

    if( res.body.data ){

      if( res.body.data.result ){
        const {
          pathname
        } = action.data.history.location;
        let checkoutPath = '/checkout';
        action.data.history.push( checkoutPath );
        yield put( serviceActions.pageRedirect( pathname, checkoutPath ) );
      }
      else {
        const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );

        let loadCartMessages = [];
        if( res.body.data.messages ){
          loadCartMessages = res.body.data.messages.items;
        }

        res.body.data.cartItems && res.body.data.cartItems.items.filter( cartItem => cartItem.displayType === 'updated' ).map( ( product, index ) => {
          loadCartMessages = loadCartMessages.concat( product.quantity.messages.items );
        } );

        // update remove items in data layer
        let removedItemsData = [];
        /** using &&'s short-circuiting , which is same as if statement.
        The removedItems array will be iterated only if it is not null
        */
        res.body.data.cartItems && res.body.data.cartItems.items.filter( cartItem => cartItem.displayType === 'removed' ).map( ( product, index ) => {
          const data= {
            'skuId': product.catalogRefId,
            'quantityRemoved': product.quantity,
            'reasonForRemoval': product.messages.items
          };
          removedItemsData.push( data );
        } );


        // analtyics tracking code
        const data = {
          'globalPageData': {
            'cart': {
              'autoRemovedItems':removedItemsData
            },
            'messages': loadCartMessages
          }
        };

        let evt = {
          'name': 'autoRemovedItems'
        };

        // Only fire autoRemovedItems event if items were removed.
        if( removedItemsData.length > 0 ){
          yield put( dataLayerActions.setDataLayer( data, evt ) );
        }
        else {
          yield put( dataLayerActions.setDataLayer( data ) );
        }

        // if the service returns messages fire event
        if( loadCartMessages.length > 0 ){
          let evt = {
            'name': 'serviceMessagesUpdated'
          };

          yield put( dataLayerActions.setDataLayer( data, evt ) );
        }

        // end analytics code

        yield put( serviceActions.checkoutRedirectListener( action.data.history, qty, loadCartMessages ) );
      }
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'initiateCheckout';

  registerServiceName( serviceType );

  yield takeEvery( MiniCart.INITIATE_CHECKOUT, listener, serviceType );
}

export const handleRedirects = function*( action ){

  try {
    if( !isUndefined( action ) && action.qty <= 0 ){
      const UserData = yield select( getUserState );

      const {
        isSignedIn
      } = UserData;

      const {
        history,
        qty,
        loadCartMessages
      } = action;

      const {
        pathname
      } = action.history.location;

      let signedInEmptyBag = '/bag/empty';
      let signedOutEmptyBag = '/bag/login';


      // if i am signed in, have no cart items, and I'm not on the signed emptyBagPage redirct me to the signedin emptyBagpage
      if( isSignedIn && qty === 0 && pathname !== signedInEmptyBag ){
        history.replace( signedInEmptyBag, {
          loadCartMessages
        } );
        yield put( serviceActions.pageRedirect( pathname, signedInEmptyBag ) );
      }

      // if i am not signed in, have no cart items, and I'm not on the signed out emptyBagPage redirct me to the signed out emptyBagpage
      if( !isSignedIn && qty === 0 && pathname !== signedOutEmptyBag ){
        history.replace( signedOutEmptyBag, {
          loadCartMessages
        } );
        yield put( serviceActions.pageRedirect( pathname, signedOutEmptyBag ) );
      }
    }

  }
  catch ( err ){

    let evt = {
      type: 'REDIRECT_FAILURE'
    }
    yield put( evt );
  }

}

export const ccrRedirects = function*(){
  yield takeEvery( serviceActionTypes.CHECKOUT_REDIRECT_LISTENER, handleRedirects );
};
