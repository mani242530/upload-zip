

import {
  takeLatest,
  takeEvery,
  put,
  call,
  select
} from 'redux-saga/effects';

import {
  actions as serviceActions,
  types as serviceActionTypes,
  registerServiceName,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import { getUserState } from 'shared/reducers/User/User.reducer';

import saga, { listener, handleRedirects, ccrRedirects } from './Checkout.sagas';
import { ajax } from 'utils/Ajax/Ajax';
import {
  types as MiniCart
} from 'hf/actions/MiniCart/MiniCart.actions';
import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';


jest.mock( 'utils/Ajax/Ajax', ()=>{
  return {
    ajax:jest.fn()
  }
} );

describe( 'Checkout.sagas', () => {

  const type = 'CHECKOUT_REDIRECT_LISTENER';
  const serviceType = 'initiateCheckout';

  registerServiceName( serviceType );
  registerServiceName( type );
  describe( 'default saga to check success path', () =>{

    const coreSaga = saga();

    it( 'should listen for the applyPayment requested method', () =>{

      const takeLatestDescriptor = coreSaga.next().value;

      expect( takeLatestDescriptor ).toEqual(
        takeEvery( MiniCart.INITIATE_CHECKOUT, listener, serviceType )
      );
    } );
  } );

  describe( 'listener saga success/failure path', () => {

    const action = {
      data :{
        'history': {
          'location': {
            'pathname': '/bag'
          },
          replace:jest.fn(),
          push:jest.fn()
        }
      }
    }



    const listenerSaga = listener( type, action );

    it( 'should wait until the loading event has been put', () => {

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        data:
        {
          title: 'test',
          status: 'ok',
          result:{}
        }
      }
      const putDescriptor = listenerSaga.next( { body: res } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.data ) ) );
    } );



    it( 'should update the datalayer and dispatch and event', () => {

      const res = {
        data: {
          'cartSummary': {
            'shippingCost': 5.95,
            'subTotal': 8.99,
            'itemCount': 1,
            'additionalDiscount': '-$10.50',
            'couponDiscount': 0,
            'estimatedTax': 'TBD',
            'giftBox': '$3.99',
            'estimatedTotal': 14.94,
            'currencyCode': 'USD',
            'couponCode': null
          },
          'cartItems':{
            'items': [
              {
                'couponApplied': false,
                'displayType':'removed',
                'brandName': 'OPI',
                'quantity': null,
                'productId': 'xlsImpprod5180311',
                'excludedFromCoupon': false,
                'adbugMessageMap': null,
                'catalogRefId': '2056976',
                'categoryName': null,
                'commerceItemid': null,
                'priceInfo': {
                  'salePrice': null,
                  'regularPrice': '$10',
                  'unitPriceMessage': null,
                  'bfxPriceMap': null
                },
                'productDisplayName': 'Soft Shades Nail Lacquer Collection',
                'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
                'variantInfo': {
                  'Color': 'Bubble Bath'
                },
                'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
                'shippingRestriction': null,
                'maxQty': null,
                'productURL': null,
                'messages': {
                  'items': [
                    {
                      'type': 'Info',
                      'message': 'Item no longer available'
                    }
                  ]
                }
              }
            ]
          },
          'messages': {
            'items': [
              {
                'type': 'Info',
                'message': 'Looks like you have items in your bag from before. They have been added below.'
              }
            ]
          }
        }
      };

      const listenerSaga = listener( type );
      listenerSaga.next();
      listenerSaga.next();
      listenerSaga.next( { body: res } )

      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': [
              {
                'skuId': '2056976',
                'quantityRemoved': null,
                'reasonForRemoval': res.data.cartItems.items[0].messages.items
              }
            ]
          },
          'messages': res.data.messages.items

        }
      };

      const evt = {
        'name': 'autoRemovedItems'
      };

      expect( listenerSaga.next().value ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );
    } );




    it( 'After the success event should redirect to checkout', () => {

      const pathname='/bag';
      const checkoutPath='/checkout';
      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( serviceActions.pageRedirect( pathname, checkoutPath ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );
  } );

  describe( 'listener saga success path', () => {

    const action = {
      data :{
        'history': {
          'location': {
            'pathname': '/bag'
          },
          replace:jest.fn(),
          push:jest.fn()
        }
      }
    }

    const listenerSaga = listener( type, action );

    it( 'should wait until the loading event has been put', () => {

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        data: {
          title: 'test',
          status: 'ok',
          cartSummary:{
            itemCount :0
          },
          messages:{
            items:[]
          }
        }
      }
      const putDescriptor = listenerSaga.next( { body: res } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.data ) ) );
    } );

    it( 'After success event -update remove items in data layer', () => {

      const data= {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': []
          },
          'messages': []
        }
      };

      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( data ) ) );
    } );

    it( 'After the success event - redirect to checkout', () => {

      const putDescriptor = listenerSaga.next().value;
      const qty=0;
      const loadCartMessages=[];

      expect( putDescriptor ).toEqual( put( serviceActions.checkoutRedirectListener( action.data.history, qty, loadCartMessages ) ) );
    } );

  } );

  describe( 'ccrRedirects saga to check success path', () =>{

    const ccrRedirectsSaga = ccrRedirects();

    it( 'should listen for the applyPayment requested method', () =>{

      const takeLatestDescriptor = ccrRedirectsSaga.next().value;

      expect( takeLatestDescriptor ).toEqual(
        takeEvery( serviceActionTypes.CHECKOUT_REDIRECT_LISTENER, handleRedirects )
      );
    } );
  } );

  describe( 'handleRedirects saga to check success path - signedIn user flow', () =>{

    const actions = {
      'history': {
        'location': {
          'pathname': '/bag'
        },
        replace:jest.fn()
      },
      'qty': 0,
      'loadCartMessages': []
    }

    const handleRedirectsSaga = handleRedirects( actions );
    const pathname = '/bag';
    const signedInEmptyBag='/bag/empty';

    it( 'should ', () =>{

      const selectDescriptor = handleRedirectsSaga.next().value;

      expect( selectDescriptor ).toEqual( select( getUserState ) );

    } );

    it( 'Should put a success event if user is signed in  ', () =>{

      const UserData ={
        isSignedIn : true
      }

      const putDescriptor_loggedIn = handleRedirectsSaga.next( UserData ).value;
      expect( putDescriptor_loggedIn ).toEqual( put( serviceActions.pageRedirect( pathname, signedInEmptyBag ) ) );

    } );

  } );

  describe( 'handleRedirects saga to check success path - guest flow', () =>{

    const actions = {
      'history': {
        'location': {
          'pathname': '/bag'
        },
        replace:jest.fn()
      },
      'qty': 0,
      'loadCartMessages': []
    }

    const handleRedirectsSaga = handleRedirects( actions );
    const pathname = '/bag';
    const signedOutEmptyBag='/bag/login';

    it( 'should ', () =>{

      const selectDescriptor = handleRedirectsSaga.next().value;

      expect( selectDescriptor ).toEqual( select( getUserState ) );

    } );

    it( 'Should put a success event if user is signed in  ', () =>{

      const UserData ={
        isSignedIn : false
      }

      const putDescriptor_loggedIn = handleRedirectsSaga.next( UserData ).value;
      expect( putDescriptor_loggedIn ).toEqual( put( serviceActions.pageRedirect( pathname, signedOutEmptyBag ) ) );

    } );

    it( 'Should put a failure event if no data is returned from the getUserState service  ', () =>{

      let evt = {
        type: 'REDIRECT_FAILURE'
      }
      const putDescriptor = handleRedirectsSaga.throw( evt ).value;
      expect( putDescriptor ).toEqual( put( evt ) );

    } );

  } );

} );