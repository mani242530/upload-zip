import { takeEvery, call, put } from 'redux-saga/effects';

import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  actions as serviceActions,
  types as serviceActionTypes,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';

import {
  types as MiniCart
} from 'hf/actions/MiniCart/MiniCart.actions';


import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

// Individual exports for testing
export const listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let trimmedCouponCode = action.item.trim();
    let query = {
      couponCode:  trimmedCouponCode
    }
    if( action.fromCheckout ){
      query.fromCheckout = action.fromCheckout;
    }
    const res = yield call( ajax,
      {
        type,
        method:'post',
        query
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );

    if( res.body.data ){

      // Analytics tracking code begin
      if( action.fromCheckout ){
        yield put( getActionDefinition( 'readCart', 'requested' )( { history: action.history, hideSpinner: true } ) );
      }
      else {
        const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
        const loadCartMessages = res.body.data.messages;
        yield put( serviceActions.checkoutRedirectListener( action.history, qty, loadCartMessages ) );
      }

      const {
        appliedCouponSummary
      } = res.body.data;

      let couponAppliedErrorMessage= appliedCouponSummary.messages && appliedCouponSummary.messages.items[0].message

      const evt = {
        'name': 'cartApplyCoupon',
        'data':{
          'couponCode': appliedCouponSummary.couponCode,
          'couponStatus': ( appliedCouponSummary.couponAppliedStatus ? 'valid' : couponAppliedErrorMessage )
        }
      }

      const data = {
        'globalPageData': {
          'order': {
            'couponSummary': appliedCouponSummary
          }
        }
      }

      yield put( dataLayerActions.setDataLayer( data, evt ) );

    }
    // Analtyics tracking code end

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export const remove_listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    let query = {};
    if( action.fromCheckout ){
      query.fromCheckout = action.fromCheckout;
    }
    const res = yield call( ajax,
      {
        type,
        method:'post',
        query
      }
    );
    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data ){



      if( action.fromCheckout ){
        yield put( getActionDefinition( 'readCart', 'requested' )( { history: action.history, hideSpinner: true } ) );
      }
      else {
        const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
        const loadCartMessages = res.body.data.messages;
        yield put( serviceActions.checkoutRedirectListener( action.history, qty, loadCartMessages ) );
      }

    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'applycoupon';

  registerServiceName( serviceType );

  yield takeEvery( MiniCart.COUPON_CODE, listener, serviceType );

  serviceType = 'removecoupon';

  registerServiceName( serviceType );

  yield takeEvery( MiniCart.COUPON_CODE_REMOVED, remove_listener, serviceType );
}
