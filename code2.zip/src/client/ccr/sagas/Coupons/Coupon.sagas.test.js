
/**
 * GWP  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import saga, { listener, remove_listener } from './Coupon.sagas';

import {
  actions as serviceActions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';
import {
  types as MiniCart
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

const _dynSessConf = '12345';

const couponCode = 'CPW1234566';
const fromCheckout =true;


describe( 'defaultSaga Saga', () => {
  const type = 'applycoupon';

  let action = {
    'item': couponCode,
    'fromCheckout':true
  }
  let action2 = {
    'item': couponCode,
    '_dynSessConf': _dynSessConf,
    fromCheckout:false
  }
  registerServiceName( type );
  registerServiceName( 'readCart' );

  describe( 'listener saga success path', () => {

    const listenerSaga = listener( type, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      let query = { couponCode, fromCheckout };

      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', query } ) );

    } );
    const res = {
      body: {
        data :{
          cartSummary: {
            itemCount :2
          },
          appliedCouponSummary:{
            couponAppliedStatus: true,
            couponCode:couponCode

          },
          messages:{}
        }
      }
    }
    it( 'should put success action', () => {

      const putDescriptor  = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );

    it( 'should put request action', () => {

      const putDescriptor  = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( 'readCart', 'requested' )( { history: action.history, hideSpinner: true } ) ) );

    } );

    it( 'should put data layer request action', () => {

      const putDescriptor  = listenerSaga.next( ).value;
      const data = {
        globalPageData: {
          order: {
            couponSummary: {
              couponAppliedStatus: true,
              couponCode: 'CPW1234566'
            }
          }
        }
      };
      const evt = {
        data: {
          couponCode: 'CPW1234566',
          couponStatus: 'valid'
        },
        name: 'cartApplyCoupon'
      };
      expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should put checkoutRedirectListener listner', () => {

      const listenerSaga2 = listener( type, action2 );
      listenerSaga2.next();
      listenerSaga2.next();
      listenerSaga2.next( res );
      const putDescriptor = listenerSaga2.next().value;
      const qty=2;
      const loadCartMessages={};

      expect( putDescriptor ).toEqual( put( serviceActions.checkoutRedirectListener( action.history, qty, loadCartMessages ) ) );

    } );

  } );
} );

describe( 'defaultSaga Saga', () => {

  const type = 'removecoupon';

  let action1 = {
    '_dynSessConf': _dynSessConf,
    fromCheckout:fromCheckout
  }

  let action2 = {
    '_dynSessConf': _dynSessConf,
    fromCheckout:false
  }

  registerServiceName( type );

  describe( 'listener saga success path', () => {

    const listenerSaga = remove_listener( type, action1 );
    const listenerSaga2 = remove_listener( type, action2 );

    it( 'should put the loading action ', () => {

      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;

      let query = { fromCheckout };
      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', query } ) );

    } );

    const res = {
      body: {
        data :{
          cartSummary: {
            itemCount :2
          },
          appliedCouponSummary:{
            couponAppliedStatus: true,
            couponCode:couponCode

          },
          messages:{}
        }
      }
    }
    it( 'should put success action', () => {

      const putDescriptor  = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );

    it( 'should put request action', () => {

      const putDescriptor  = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( 'readCart', 'requested' )( { history: action1.history, hideSpinner: true } ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should put checkoutRedirectListener listner', () => {

      listenerSaga2.next();
      listenerSaga2.next();
      listenerSaga2.next( res );
      const putDescriptor = listenerSaga2.next( ).value;
      const qty=2;
      const loadCartMessages={};

      expect( putDescriptor ).toEqual( put( serviceActions.checkoutRedirectListener( action2.history, qty, loadCartMessages ) ) );

    } );

  } );

} );

