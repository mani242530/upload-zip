import { takeEvery, call, put } from 'redux-saga/effects';

import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';


// Individual exports for testing
export const listener = function*( type, data ){
  try {

    yield put( getActionDefinition( type, 'loading' )() );
    let creditCardNumber = data.data.paymentFormValues.creditCardNumber.trim();

    // TODO: once validation is setup, we need to extract expirationMonth and expirationYear
    // from 'expirationDate'
    let expirationMonth = '';
    let expirationYear = '';
    let cvvNumber = '';
    if( data.data.paymentFormValues.expirationDate ){
      expirationMonth = data.data.paymentFormValues.expirationDate.substring( 0, 2 );
      expirationYear = data.data.paymentFormValues.expirationDate.substring( 3, 7 );
    }
    if( data.data.paymentFormValues.securityCode ){
      cvvNumber = data.data.paymentFormValues.securityCode.trim();
    }



    // TODO add these fields
    // let paymentType
    // let creditCardType
    // let country
    let values = {}
    if( data.data.paymentFormValues.sameAsShipping ){
      values ={
        paymentType:'creditCard',
        creditCardNumber: creditCardNumber,
        expirationMonth: expirationMonth,
        expirationYear: expirationYear,
        cardVerificationNumber:cvvNumber,
        creditCardType: data.data.paymentFormValues.creditCardType,
        sameAsShipping:true,
        primary: data.data.paymentFormValues.primary,
        nickName: data.data.paymentFormValues.nickName
      }
    }
    else {
      let firstName = data.data.paymentFormValues.firstName.trim();
      let lastName = data.data.paymentFormValues.lastName.trim();
      let phoneNumber = data.data.paymentFormValues.phoneNumber.trim();
      if( data.data.isSignedIn ){
        let email = data.data.paymentFormValues.login.trim();
        values={
          email: email
        }
      }
      let address1 = data.data.paymentFormValues.address1.trim();
      let address2 = data.data.paymentFormValues.address2.trim();
      let city = data.data.paymentFormValues.city.trim();
      let myState = data.data.paymentFormValues.state.trim();
      let postalCode = data.data.paymentFormValues.postalCode.trim();
      values = {
        ...values,
        paymentType:'creditCard',
        creditCardNumber: creditCardNumber,
        expirationMonth: expirationMonth,
        expirationYear: expirationYear,
        cardVerificationNumber: cvvNumber,
        firstName: firstName,
        lastName: lastName,
        phoneNumber: phoneNumber,
        address1: address1,
        address2: address2,
        city: city,
        state: myState,
        postalCode: postalCode,
        creditCardType: data.data.paymentFormValues.creditCardType,
        sameAsShipping: false,
        primary: data.data.paymentFormValues.primary,
        nickName: data.data.paymentFormValues.nickName
      }
    }

    const res = yield call( ajax,
      {
        type,
        method: 'post',
        values
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body ) );

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'submitCreditCard';

  registerServiceName( serviceType );

  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );

}
