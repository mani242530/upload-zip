/**
 * Page  sagas
 */

import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import saga, { listener } from './CreditCardPayment.sagas';
import Cookies from 'js-cookie';

import {
  types as CheckoutPage
} from '../../actions/CheckoutPage/CheckoutPage.actions';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';


describe( 'defaultSaga Saga of submitCreditCard', () =>{
  const type2 = 'submitCreditCard';
  registerServiceName( type2 );

  describe( 'default saga', () =>{

    Cookies.set( 'ultaSession', '12345' );
    const coreSaga = saga();

    it( 'should listen for the submitCreditCard requested method', () =>{

      const takeLatestDescriptor = coreSaga.next().value;
      expect( takeLatestDescriptor ).toEqual( takeEvery( getServiceType( type2, 'requested' ), listener, type2 ) );
    } );

  } );
  const data = {
    paymentFormValues:{
      paymentType: 'creditCard',
      creditCardNumber: '1234567891234567',
      expirationMonth: '',
      expirationYear: '',
      firstName: 'abc',
      lastName: 'bcd',
      phoneNumber: '(222) 222-2222',
      address1: 'abc ave',
      address2: 'bcd',
      cardVerificationNumber: '',
      city: 'abc',
      state: 'AB',
      postalCode: '22332',
      primary: undefined,
      creditCardType: 'Visa',
      sameAsShipping: false
    }
  }
  describe( 'listener saga success path of addProductSamples', () =>{

    const sessionID = '1212121222';
    let action = {
      query: {
        _dynSessConf: sessionID
      },
      data: {
        paymentFormValues: {
          paymentType: 'creditCard',
          creditCardNumber: '1234567891234567',
          expirationMonth: '05',
          expirationYear: '17',
          cvvNumber: '223',
          firstName: 'abc',
          lastName: 'bcd',
          phoneNumber: '(222) 222-2222',
          email: 'abc@gmail.com',
          address1: 'abc ave',
          address2: 'bcd',
          city: 'abc',
          state: 'AB',
          postalCode: '22332',
          creditCardType: 'Visa',
          sameAsShipping: false
        }
      }
    }

    const listenerSaga = listener( type2, action );

    it( 'should should until the loading event has been put', () =>{

      Cookies.set( 'ultaSession', sessionID );
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a success method', () =>{

      const callDescriptor = listenerSaga.next().value;
      const type = 'submitCreditCard';
      const values = data.paymentFormValues;
      const method = 'post';

      registerServiceName( type );

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () =>{

      let body = {
        paymentDetails: [{
          paymentInfo: {}
        }
        ]
      }

      const putDescriptor = listenerSaga.next( { body } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'success' )( body ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () =>{
      window.TRACK_SAGA_FAILURES = true;
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'failure' )( err ) ) );
      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );

  } );


} );


