import { takeEvery, call, put } from 'redux-saga/effects';

import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  actions as serviceActions,
  types as serviceActionTypes,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';

import {
  types as MiniCart
} from 'hf/actions/MiniCart/MiniCart.actions';

// Individual exports for testing
export const listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let query = {
      promotionId: action.item
    }
    const res = yield call( ajax,
      {
        type,
        method: 'post',
        query
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data ){

      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( serviceActions.checkoutRedirectListener( action.history, qty, loadCartMessages ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}
export const variantlistener = function*( type, action ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let query = {
      addGwpSkuId: action.skuid,
      promotionId: action.promotionid
    }
    const res = yield call( ajax,
      {
        type,
        method: 'post',
        query
      }
    );


    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data ){
      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( serviceActions.checkoutRedirectListener( action.history, qty, loadCartMessages ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }
}

export default function*(){
  let serviceType = 'removeGiftFromCart';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( MiniCart.REMOVE_GIFT_FROM_CART, listener, serviceType );

  serviceType = 'addItemToCart';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( MiniCart.ADD_TO_CART, listener, serviceType );

  serviceType = 'selectGiftVariant';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( MiniCart.SELECT_GIFT_VARIANT, variantlistener, serviceType );

}
