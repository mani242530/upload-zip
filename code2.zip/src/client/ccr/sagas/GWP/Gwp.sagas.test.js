
/**
 * GWP  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import saga, { listener, variantlistener } from './Gwp.sagas';

import {
  actions,
  registerServiceName,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import { ajax } from 'utils/Ajax/Ajax';

import {
  types as MiniCart
} from 'hf/actions/MiniCart/MiniCart.actions';

const promotionId = '1234566';

const gwpSaga = saga();

describe( 'Gwp Saga', () => {

  const type = 'removeGiftFromCart';

  registerServiceName( type );

  describe( 'gwpSaga with removeGiftFromCart as serviceType', () => {

    it( 'gwpSaga listener method', () => {

      const takeEveryDescriptor = gwpSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( MiniCart.REMOVE_GIFT_FROM_CART, listener, type )
      );

    } );
  } );

  describe( 'listener saga success/failure path', () => {

    const action = {
      item: {
        promotionId: promotionId,
        addGwpSkuId: '2342434',
        history: {}
      }
    };
    const res = {
      body: {
        data:{
          removeGiftFromCart: false,
          cartSummary: {
            itemCount: 10
          },
          messages: {}
        }
      }
    };
    const listenerSaga = listener( type, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;
      const query = { promotionId:action.item };

      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', query } ) );

    } );

    it( 'should put a success event after data is called', () => {

      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );

    it( 'should put checkoutRedirectListener action', () => {

      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual(
        put( actions.checkoutRedirectListener(
          action.history, res.body.data.cartSummary.itemCount, res.body.data.messages ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      global.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, global ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should throw the error on failure', () => {

      const err = {
        statusText: 'some failure message'
      }

      expect( () => {
        listenerSaga.next().throw( err )
      } ).toThrow();

    } );

  } );

} );

describe( 'gwpSaga', () => {

  const action = {
    item: {
      promotionId: promotionId,
      addGwpSkuId: '2342434',
      history: {}
    }
  };
  const res = {
    body: {
      data:{
        addItemToCart: false,
        cartSummary: {
          itemCount: 10
        },
        messages: {}
      }
    }
  };
  const type = 'addItemToCart';

  registerServiceName( type );

  describe( 'gwpSaga with addItemToCart as serviceType', () => {

    it( 'gwpSaga', () => {

      const takeEveryDescriptor = gwpSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( MiniCart.ADD_TO_CART, listener, type )
      );

    } );
  } );

  describe( 'listener saga success/failure path', () => {

    const listenerSaga = listener( type, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;
      const query = { promotionId:action.item };

      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', query } ) );

    } );

    it( 'should put a success event after data is called', () => {

      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );

    it( 'should put checkoutRedirectListener action', () => {

      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual(
        put( actions.checkoutRedirectListener(
          action.history, res.body.data.cartSummary.itemCount, res.body.data.messages ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

} );

describe( 'gwpSaga Saga', () => {

  const action = {
    item: {
      promotionId: promotionId,
      addGwpSkuId: '2342434',
      history: {}
    }
  };
  const res = {
    body: {
      data:{
        selectGiftVariant: false,
        cartSummary: {
          itemCount: 10
        },
        messages: {}
      }
    }
  };
  const type = 'selectGiftVariant';

  registerServiceName( type );

  describe( 'gwpSaga with addItemToCart as selectGiftVariant', () => {

    it( 'gwpSaga', () => {

      const takeEveryDescriptor = gwpSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( MiniCart.SELECT_GIFT_VARIANT, variantlistener, type )
      );

    } );

  } );

  describe( 'listener saga success path', () => {

    const listenerSaga = variantlistener( type, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;
      const query = {
        addGwpSkuId: action.addGwpSkuId,
        promotionId: action.promotionId
      };

      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', query } ) );

    } );

    it( 'should put a success event after data is called', () => {

      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );

    it( 'should put checkoutRedirectListener action', () => {

      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual(
        put( actions.checkoutRedirectListener(
          action.history, res.body.data.cartSummary.itemCount, res.body.data.messages ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

} );
