/**
 * Created by rush on 5/19/17.
 */


import { takeLatest, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import saga, { listener } from './GiftWrap.sagas';

import {
  types as miniCartTypes
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';


describe( 'defaultSaga Saga of addGiftNote', () => {
  const type2 = 'addGiftNote';
  registerServiceName( type2 );

  describe( 'default saga', () => {

    const coreSaga = saga();

    it( 'should listen for the addGiftNote requested method', () => {

      const takeLatestDescriptor = coreSaga.next().value;
      expect( takeLatestDescriptor ).toEqual( takeLatest( miniCartTypes.SET_GIFT_WRAP_GIFT_NOTE_SERVICE, listener, type2 ) );
    } );

  } );

  describe( 'listener saga success path of addGiftNote', () => {
    let action = {
      query: {
        giftNote: 'Happy Birthday Teja'
      }
    }

    const listenerSaga = listener( type2, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;
      const type = 'addGiftNote';
      registerServiceName( type );
      let query = {
        giftNote: 'Happy Birthday Teja'
      };
      callDescriptor.CALL.args[ 0 ].query = query;
      let method = 'post';
      expect( callDescriptor ).toEqual( call( ajax, { type, method, query } ) );

    } );

    it( 'should put a success event after data is called', () => {

      let body = {
        data:{
          giftOptions: {}
        }
      }

      const putDescriptor = listenerSaga.next( { body } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'success' )( body.data ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'failure' )( err ) ) );

    } );

  } );


} );

describe( 'defaultSaga Saga of addGiftWrap', () => {

  const type = 'addGiftWrap';
  registerServiceName( type );

  describe( 'default saga', () => {
    const type1 = 'addGiftWrap';
    const coreSaga1 = saga();

    it( 'should listen for the addGiftWrap requested method', () => {
      coreSaga1.next().value;
      const takeLatestDescriptor1 = coreSaga1.next().value;
      expect( takeLatestDescriptor1 ).toEqual( takeLatest( miniCartTypes.SET_GIFT_WRAP_GIFT_BOX_SERVICE, listener, type ) );
    } );

  } );

  describe( 'listener saga success path of addGiftWrap', () => {
    let action = {
      query: {
        addGiftWrap: true
      }
    }

    const listenerSaga = listener( type, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;

      let query = {
        addGiftWrap: true
      };
      let method = 'post';
      callDescriptor.CALL.args[ 0 ].query = query;
      expect( callDescriptor ).toEqual( call( ajax, { type, method, query } ) );

    } );

    it( 'should put a success event after data is called', () => {

      let body = {
        data:{
          giftOptions: {}
        }
      }

      const putDescriptor = listenerSaga.next( { body } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( body.data ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );

  } );


} );
