/**
 * Created by rush on 5/3/17.
 */
import { takeEvery, call, put, select, cancel, cancelled } from 'redux-saga/effects';
import { getUserState } from 'shared/reducers/User/User.reducer';
import { delay } from 'redux-saga';
import { isUndefined, find, concat, isEmpty, isNumber } from 'lodash';

import {
  ajax
} from 'utils/Ajax/Ajax';


import {
  actions as serviceActions,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

export const checkForRedirect = function*( action, loadCartCount ){

  const UserData = yield select( getUserState );
  // #1. Check to see if the user is signed in
  // #2. If the user is signein look at the current URL and redirect the user to the right place
  // #3. Check the user's cart count
  // #4. If the cart count is 0 redirect to the empty bag if you aren't on the empty bag
  // #5. If the cart count is > 0 redirect to the bag if not on the bag


  const {
    isSignedIn,
    shoppingCartCount
  } = UserData;

  const {
    history
  } = action.data;

  const {
    pathname
  } = action.data.history.location;


  const cartCount = loadCartCount || parseInt( shoppingCartCount, 10 );


  let bagPath = '/bag';
  let checkoutPath = '/checkout';
  let signedInEmptyBag = '/bag/empty';
  let signedOutEmptyBag = '/bag/login';

  // if the app is being redirected and no ajax call is made for loadCart we must fire
  // a pageNavigation event for analtyics tracking.
  const evt = {
    'name': 'pageNavigation'
  }


  // if the user has items in their cart and they are on an empty bag page send them to the bag
  // it is important to note that the signed in user status does not matter for this scenario
  if( cartCount > 0 && pathname !== bagPath && pathname !== checkoutPath ){
    // redirect the user to the bag page
    history.replace( bagPath );
    yield put( serviceActions.pageRedirect( pathname, bagPath ) );
    yield put( dataLayerActions.setDataLayer( {}, evt ) );
    yield cancel();
  }

  // if i am signed in, have no cart items, and I'm not on the signed emptyBagPage redirct me to the signedin emptyBagpage
  if( isSignedIn && cartCount === 0 && pathname !== signedInEmptyBag ){
    history.replace( signedInEmptyBag );
    yield put( serviceActions.pageRedirect( pathname, signedInEmptyBag ) );
    yield put( dataLayerActions.setDataLayer( {}, evt ) );
    yield cancel();
  }

  // if i am not signed in, have no cart items, and I'm not on the signed out emptyBagPage redirct me to the signed out emptyBagpage
  if( !isSignedIn && cartCount === 0 && pathname !== signedOutEmptyBag ){
    history.replace( signedOutEmptyBag );
    yield put( serviceActions.pageRedirect( pathname, signedOutEmptyBag ) );
    yield cancel();
  }
}

// Individual exports for testing
export const loadCart = function* ( type, CONFIG, action ){
  try {

    // before we do anything we need to see if we need to redirect the user
    yield call( checkForRedirect, action );

    yield put( getActionDefinition( type, 'loading' )() );
    let query = {};

    if( process.env.NODE_ENV === 'development' ){
      query.__CART_COUNT = CONFIG.DEBUGGING.CART.cartQty;
    }

    const res = yield call( ajax,
      {
        type,
        query
      }
    );

    // handle any redirects for user based on responses here

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );

    if( res.body.data ){

      const {
        cartSummary,
        cartItems,
        freeSampleInfo,
        messages
      } = res.body.data;

      // this check is to handles the scenario when cart had only one item, and it was removed as part of the load cart call
      // this logic is to ensure that the user will be directed to the empty bag page
      if( cartSummary.itemCount === 0 ){
        yield call( checkForRedirect, action, 0 );
      }
      // Analytics tracking code begin
      const giftItems = res.body.data.giftItems?res.body.data.giftItems.items:[]
      // update remove items in data layer
      let removedItemsData = [];

      const removedItems = cartItems && cartItems.items.filter( cartItem =>
        cartItem.displayType === 'removed' || cartItem.displayType === 'updated'
      ).map( ( product, index ) => {
        const reasonForRemoval = ( ( product.displayType === 'updated' && product.quantity.messages ) ?
          product.quantity.messages.items[0].message :
          product.messages.items[0].message );
        const data= {
          'skuId': product.catalogRefId,
          'quantityRemoved': product.quantity,
          'reasonForRemoval': reasonForRemoval
        };
        removedItemsData.push( data );
      } ) ;



      let cartContents = {};

      if( cartItems && cartItems.items ){
        cartContents = concat(
          ( cartItems.items.filter( cartItem => ( cartItem.displayType === 'default' || cartItem.displayType === 'updated' )
          ).map( ( commerceItem, index ) => {
            return {
              ...( commerceItem.productId && { 'productId': commerceItem.productId } ),
              ...( commerceItem.catalogRefId && { 'skuId': commerceItem.catalogRefId } ),
              ...( commerceItem.productDisplayName && { 'productName': commerceItem.productDisplayName } ),
              'pageURL': '/bag/',
              ...( commerceItem.brandName && { 'manufacturer': commerceItem.brandName } ),
              ...( commerceItem.productURL && { 'pageURL': commerceItem.productURL } ),
              ...( commerceItem.imageURL && { 'imageURL': commerceItem.imageURL } ),
              ...( commerceItem.priceInfo.salePrice && { 'unit_sale_price': commerceItem.priceInfo.salePrice } ),
              ...( commerceItem.quantity && { 'quantity': commerceItem.quantity } ),
              ...( commerceItem.priceInfo.regularPrice && { 'price': commerceItem.priceInfo.regularPrice.replace( '$', '' ) } ),
              ...( commerceItem.adbugMessageMap !== null && { 'promotions': commerceItem.adbugMessageMap.adbugMessage } )
            };
          } ) ),
          giftItems.filter( ( giftObject ) => {
            return ( find( giftObject.freeGifts, { 'selected': 'true' } ) )
          } ).map( ( filteredGifts ) => {
            const temp = find( filteredGifts.freeGifts, { 'selected': 'true' } )
            return {
              ...( temp.giftCatalogRefId && { 'skuId': temp.giftCatalogRefId } ),
              ...( temp.giftDisplayName && { 'productName': temp.giftDisplayName } ),
              ...( temp.giftBrandName && { 'manufacturer': temp.giftBrandName } ),
              ...( temp.giftPDPUrl && { 'pageURL': temp.giftPDPUrl } ),
              ...( temp.giftImageURL && { 'imageURL': temp.giftImageURL } )
            }
          } )
        );
      }



      const data = {
        'globalPageData': {
          'navigation': {
            'pageName': ( parseInt( cartSummary.itemCount, 10 ) > 0 ? 'bag' : 'empty bag' )
          },
          'order': {
            'currency': cartSummary.currencyCode,
            'total': ( cartSummary.estimatedTotal ).toFixed( 2 ),
            'subtotal': ( cartSummary.subTotal ).toFixed( 2 ),
            'shipping': ( isNumber( cartSummary.shippingCost ) ? ( cartSummary.shippingCost ).toFixed( 2 ) : cartSummary.shippingCost ),
            'itemCount': cartSummary.itemCount,
            'voucher_discount': cartSummary.couponDiscount,
            'orderItems': cartContents
          },
          'cart': {
            'autoRemovedItems':removedItemsData
          },
          'messages': messages
        }
      }

      let evt = {
        'name': 'pageNavigation'
      }


      yield put( dataLayerActions.setDataLayer( data, evt ) );

      // If items were removed dispatch event.
      if( removedItemsData.length > 0 ){
        evt = {
          'name': 'autoRemovedItems'
        }
        yield put( dataLayerActions.setDataLayer( {}, evt ) );
      }

    }
    // Analtyics tracking code end


  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
  finally {

    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'canceled' )() );
    }
  }
}


export default function( CONFIG ){
  return function* (){
    let serviceType = 'loadCart';
    // register events for the request
    registerServiceName( serviceType );
    yield takeEvery( getServiceType( 'loadCart', 'requested' ), loadCart, serviceType, CONFIG )

  }
}