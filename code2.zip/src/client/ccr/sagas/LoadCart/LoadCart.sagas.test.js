/**
 * Created by rush on 5/3/17.
 */

/**
 * LoadCart  sagas
 */
import { getUserState } from 'shared/reducers/User/User.reducer';
import { ajax } from 'utils/Ajax/Ajax';
import { cloneableGenerator } from 'redux-saga/utils';
import CONFIG from 'ccr/ccr.config';

import {
  takeEvery,
  call,
  put,
  select,
  cancel,
  cancelled
} from 'redux-saga/effects';

import saga, {
  loadCart,
  checkForRedirect
} from './LoadCart.sagas';

import {
  actions as serviceActions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import {
  isEmpty,
  concat,
  find
} from 'lodash';

jest.mock( 'utils/Ajax/Ajax', ()=>{
  return {
    ajax:jest.fn()
  }
} );

describe( 'LoadCart sagas', () => {

  const type = 'loadCart';

  registerServiceName( type );

  const loadCartSaga = saga( CONFIG )();

  it( 'should listen to loadCart service calls', () => {

    const takeEveryDescriptor = loadCartSaga.next().value;

    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), loadCart, type, CONFIG ) );

  } );

  describe( 'loadCart method success/failure path', () => {

    const res = {
      body: {
        data:{
          cartSummary: {
            shippingCost: 'FREE',
            subTotal: 286,
            itemCount: 5,
            orderGiftWrapAmt: 0,
            additionalDiscount: null,
            couponDiscount: 0,
            estimatedTax: 'TBD',
            estimatedTotal: 286,
            currencyCode: 'USD',
            couponCode: null
          },
          freeSamplesInfo: {
            items: [
              {
                catalogRefId: '2252998',
                sampleDesc: 'Fragrance',
                selected: false
              },
              {
                catalogRefId: '2252999',
                sampleDesc: 'Skincare',
                selected: false
              },
              {
                catalogRefId: '2253000',
                sampleDesc: 'Variety',
                selected: false
              }
            ]
          },
          messages: {
            items: [
              {
                type: 'Info',
                message: 'Looks like you have items in your bag from before. They\'ve been added below.'
              }
            ]
          },
          giftItems: {
            items: [{
              freeGifts: [{
                giftVariant: 'Signature Black',
                giftPDPUrl: '/go-curl-pocket-curler-pink?productId=xlsImpprod641081&sku=2161712',
                giftCatalogRefId: '2161712',
                giftDisplayName: 'Go Curl Pocket Curler - Pink',
                giftImageURL: 'http://images.ulta.com/is/image/Ulta/2161712?$sm$',
                selected: 'false',
                giftBrandName: 'Japonesque'
              },
              {
                giftVariant: 'Signature Red',
                giftPDPUrl: '/slant-tweezer?productId=prod2041233&sku=2145941',
                giftCatalogRefId: '2145941',
                giftDisplayName: 'Slant Tweezer',
                giftImageURL: 'http://images.ulta.com/is/image/Ulta/2145941?$sm$',
                selected: 'false',
                giftBrandName: 'Tweezerman'
              },
              {
                giftVariant: '1.7 oz',
                giftPDPUrl: '/eternity-men-eau-de-toilette?productId=2232&sku=2023775',
                giftCatalogRefId: '2023775',
                giftDisplayName: 'Eternity for Men Eau de Toilette',
                giftImageURL: 'http://images.ulta.com/is/image/Ulta/2023775?$sm$',
                selected: 'default',
                giftBrandName: 'Calvin Klein'
              }],
              promoValidity: 'offer valid 03/11/2015-12/30/2018 or while supplies last',
              bfxPriceMap: null,
              promoId: '0000071454',
              induldge: true
            },
            {
              freeGifts: [{
                giftPDPUrl: '/brazilliance-maracuja-self-tanner-mitt?productId=xlsImpprod5250035&sku=2258052',
                giftCatalogRefId: '2258052',
                giftDisplayName: 'Brazilliance Maracuja Self-Tanner & Mitt',
                giftImageURL: 'http://images.ulta.com/is/image/Ulta/2258052?$sm$',
                selected: 'true',
                giftBrandName: 'Tarte'
              },
              {
                giftPDPUrl: '/brazilliance-maracuja-self-tanner-mitt?productId=xlsImpprod5250035&sku=2258052',
                giftCatalogRefId: '2258052',
                giftDisplayName: 'Brazilliance Maracuja Self-Tanner & Mitt',
                giftImageURL: 'http://images.ulta.com/is/image/Ulta/2258052?$sm$',
                selected: 'default',
                giftBrandName: 'Tarte'
              }],
              promoValidity: 'offer valid 04/24/2017-07/31/2017 or while supplies last',
              bfxPriceMap: [
                {
                  bfxQty: '1',
                  bfxPrice: '$0.00'
                }
              ],
              promoId: '1000014332',
              induldge: true
            }]
          },
          cartItems: {
            items: [
              {
                displayType: 'removed',
                messages:{
                  items:[
                    {
                      type:'Info',
                      message:'Out of Stock'
                    }
                  ]
                },
                couponApplied: false,
                brandName: 'OPI',
                quantity: 2,
                productId: 'xlsImpprod13631063',
                excludedFromCoupon: false,
                adbugMessageMap: {
                  adbugMessage: null,
                  promoUrl: 'https://qa3.ulta.com/ulta/promotion/buy-more-save-more/detail/0000153130'
                },
                catalogRefId: '2299339',
                categoryName: 'Nail Polish',
                discountMessage: '',
                errorMsg: '',
                commerceItemid: 'ci14980000220',
                priceInfo: {
                  salePrice: '$10.00',
                  regularPrice: '$20.00',
                  bfxPriceMap: [
                    {
                      bfxQty: '2.0',
                      bfxPrice: '$5.00'
                    }
                  ],
                  unitPriceMessage: '2 @ $5.00'
                },
                productDisplayName: 'New Orleans Nail Lacquer Collection',
                imageURL: 'https://images.ulta.com/is/image/Ulta/2299339?$md$',
                variantInfo: {
                  Color: 'Spare Me A French Quarter? (mellowed raspberry crÃ¨me)'
                },
                skuDisplayName: 'New Orleans Nail Lacquer Collection',
                shippingRestriction: 'Cannot ship to your selected address',
                maxQty: 10,
                productURL: '/new-orleans-nail-lacquer-collection?productId=xlsImpprod13631063&sku=2299339'
              },
              {
                displayType: 'default',
                couponApplied: false,
                brandName: 'Dior',
                quantity: 3,
                productId: 'xlsImpprod13231211',
                excludedFromCoupon: false,
                adbugMessageMap: {
                  adbugMessage: null,
                  promoUrl: 'https://qa3.ulta.com/ulta/promotion/buy-more-save-more/detail/0000153130'
                },
                catalogRefId: '2291498',
                categoryName: 'Cologne',
                discountMessage: '',
                errorMsg: '',
                commerceItemid: 'ci14980000221',
                priceInfo: {
                  salePrice: null,
                  regularPrice: '$276.00',
                  bfxPriceMap: [
                    {
                      bfxQty: '3',
                      bfxPrice: '$92.00'
                    }
                  ],
                  unitPriceMessage: '3 @ $92.00'
                },
                productDisplayName: 'Dior Homme Eau for Men Eau de Toilette',
                imageURL: 'https://images.ulta.com/is/image/Ulta/2291498?$md$',
                variantInfo: {
                  Size: '3.4 oz'
                },
                skuDisplayName: 'Dior Homme Eau for Men Eau de Toilette',
                shippingRestriction: 'Cannot ship to your selected address',
                maxQty: 3,
                productURL: '/dior-homme-eau-men-eau-de-toilette?productId=xlsImpprod13231211&sku=2291498'
              }
            ]
          }
        }
      }
    };

    const listenerSaga = cloneableGenerator( loadCart )( type, CONFIG, {} );

    it( 'should check for redirect', () => {

      const callDescriptor = listenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( checkForRedirect, {} ) );

    } );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor  = listenerSaga.next( process ).value;
      const query= {};

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should call the ajax method', () => {

      const callDescriptor  = listenerSaga.next().value;
      const query= {};

      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    let listenerSagaClones3;
    it( 'should put success action', () => {
      listenerSagaClones3 = listenerSaga.clone();
      const putDescriptor  = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );


    it( 'should redirect to emptybag page if no items in cart', () => {
      const res1 ={
        body: {
          data:{
            cartSummary: {
              subTotal: 0,
              itemCount: 0
            },
            freeSamplesInfo: null,
            messages: null,
            removedItems: null,
            giftItems: null,
            cartItems: null
          }
        }
      };
      listenerSagaClones3.next( res1 ).value;
      const callDescriptor  =listenerSagaClones3.next().value;
      expect( callDescriptor ).toEqual( call( checkForRedirect, {}, 0 ) );
    } );

    describe( 'data layer actions', () => {

      let data = {
        'globalPageData': {
          'navigation': {
            'pageName': 'bag'
          },
          'order': {
            'currency': 'USD',
            'total': '286.00',
            'subtotal': '286.00',
            'shipping': 'FREE',
            'itemCount': 5,
            'voucher_discount': 0,
            'orderItems': [
              {
                'productId': 'xlsImpprod13231211',
                'skuId': '2291498',
                'productName': 'Dior Homme Eau for Men Eau de Toilette',
                'pageURL': '/dior-homme-eau-men-eau-de-toilette?productId=xlsImpprod13231211&sku=2291498',
                'manufacturer': 'Dior',
                'imageURL': 'https://images.ulta.com/is/image/Ulta/2291498?$md$',
                'quantity': 3,
                'price': '276.00',
                'promotions': null
              },
              {
                'skuId': '2258052',
                'productName': 'Brazilliance Maracuja Self-Tanner & Mitt',
                'manufacturer': 'Tarte',
                'pageURL': '/brazilliance-maracuja-self-tanner-mitt?productId=xlsImpprod5250035&sku=2258052',
                'imageURL': 'http://images.ulta.com/is/image/Ulta/2258052?$sm$'
              }
            ]
          },
          'cart': {
            'autoRemovedItems': [
              {
                'skuId': '2299339',
                'reasonForRemoval': 'Out of Stock',
                'quantityRemoved': 2
              }
            ]
          },
          'messages': {
            'items': [
              {
                'type': 'Info',
                'message': 'Looks like you have items in your bag from before. They\'ve been added below.'
              }
            ]
          }
        }
      };
      const evt = {
        name: 'pageNavigation'
      };
      let listenerSagaClone;
      let listenerSagaClone1

      it( 'should put setDataLayer action with a non-numeric value for shipping cost i.e.Free', () => {
        listenerSagaClone = listenerSaga.clone();
        listenerSagaClone1 = listenerSaga.clone();
        const putDescriptor = listenerSaga.next( res ).value;
        expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );
      } );

      it( 'should put setDataLayer action shippingCost with a numberic value for shipping cost i.e 10', () => {
        res.body.data.cartSummary.shippingCost = 10;
        data.globalPageData.order.shipping = '10.00';
        const putDescriptor = listenerSagaClone.next( res ).value;
        expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );
      } );

      it( 'should put setDataLayer action when cartitem data when giftiems is not present', () => {
        res.body.data.giftItems = null;

        data = {
          'globalPageData': {
            'navigation': {
              'pageName': 'bag'
            },
            'order': {
              'currency': 'USD',
              'total': '286.00',
              'subtotal': '286.00',
              'shipping': '10.00',
              'itemCount': 5,
              'voucher_discount': 0,
              'orderItems': [
                {
                  'productId': 'xlsImpprod13231211',
                  'skuId': '2291498',
                  'productName': 'Dior Homme Eau for Men Eau de Toilette',
                  'pageURL': '/dior-homme-eau-men-eau-de-toilette?productId=xlsImpprod13231211&sku=2291498',
                  'manufacturer': 'Dior',
                  'imageURL': 'https://images.ulta.com/is/image/Ulta/2291498?$md$',
                  'quantity': 3,
                  'price': '276.00',
                  'promotions': null
                }
              ]
            },
            'cart': {
              'autoRemovedItems': [
                {
                  'skuId': '2299339',
                  'quantityRemoved': 2,
                  'reasonForRemoval':'Out of Stock'
                }
              ]
            },
            'messages': {
              'items': [
                {
                  'type': 'Info',
                  'message': 'Looks like you have items in your bag from before. They\'ve been added below.'
                }
              ]
            }
          }
        }
        const putDescriptor = listenerSagaClone1.next( res ).value;
        expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );
      } );

      it( 'should put setDataLayer action for autoRemovedItems', () => {
        const evt = {
          name: 'autoRemovedItems'
        };
        const putDescriptor = listenerSaga.next().value;
        expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( {}, evt ) ) );
      } );
    } );

    describe( 'listener saga failure path', () => {

      it( 'should put a failure event if no data is returned from the service', () => {

        global.TRACK_SAGA_FAILURES = true;
        const err = {
          statusText:'some failure message'
        }
        const putDescriptor = listenerSaga.throw( err, global ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

      } );

      it( 'should cancel the event if an error occured in the service', () => {

        const cancelDescriptor = listenerSaga.next().value;

        expect( cancelDescriptor ).toEqual( cancelled() );

      } );

      it( 'should put a cancel action', () => {

        const putDescriptor = listenerSaga.next( true, global ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'canceled' )() ) );

      } );

    } );

  } );

  describe( 'checkForRedirect method', () => {

    const replace = ( path ) => {};
    const action = {
      data: {
        history: {
          location: {
            pathname: '/emptyBag'
          },
          replace: replace
        }
      }
    };

    describe( 'if the user has items in their cart and they are on an empty bag page send them to the bag', () => {

      const checkForRedirectWithItems = checkForRedirect( action );

      it( 'should select getUserState', () => {

        const selectDescriptor = checkForRedirectWithItems.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'should put redirect action', () => {

        const userData = {
          isSignedIn: true,
          shoppingCartCount: 4
        };
        const bagPath = '/bag';
        const selectDescriptor = checkForRedirectWithItems.next( userData ).value;

        expect( selectDescriptor ).toEqual( put( serviceActions.pageRedirect(
          action.data.history.location.pathname, bagPath ) ) );

      } );

      it( 'should put setDataLayer action', () => {

        const evt = {
          name: 'pageNavigation'
        };
        const selectDescriptor = checkForRedirectWithItems.next().value;

        expect( selectDescriptor ).toEqual( put( dataLayerActions.setDataLayer( {}, evt ) ) );

      } );

      it( 'should yield cancel', () => {

        const cancelDescriptor = checkForRedirectWithItems.next().value;

        expect( cancelDescriptor ).toEqual( cancel() );

      } );

    } );

    describe( 'if the user is signed in, have no cart items, and not on the signed emptyBagPage, redirect him to the signedin emptyBagpage', () => {

      const checkForRedirectNoItems = checkForRedirect( action );

      it( 'should select getUserState', () => {

        const selectDescriptor = checkForRedirectNoItems.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'should put redirect action', () => {

        const userData = {
          isSignedIn: true,
          shoppingCartCount: 0
        };
        const bagPath = '/bag/empty';
        const selectDescriptor = checkForRedirectNoItems.next( userData ).value;

        expect( selectDescriptor ).toEqual( put( serviceActions.pageRedirect(
          action.data.history.location.pathname, bagPath ) ) );

      } );

      it( 'should put setDataLayer action', () => {

        const evt = {
          name: 'pageNavigation'
        };
        const selectDescriptor = checkForRedirectNoItems.next().value;

        expect( selectDescriptor ).toEqual( put( dataLayerActions.setDataLayer( {}, evt ) ) );

      } );

      it( 'should yield cancel', () => {

        const cancelDescriptor = checkForRedirectNoItems.next().value;

        expect( cancelDescriptor ).toEqual( cancel() );

      } );

    } );

    describe( 'if the user is not signed in, have no cart items, and not on the signed out emptyBagPage redirct him to the signed out emptyBagpage', () => {

      const redirectNoItemsNotSigned = checkForRedirect( action );

      it( 'should select getUserState', () => {

        const selectDescriptor = redirectNoItemsNotSigned.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'should put redirect action', () => {

        const userData = {
          isSignedIn: false,
          shoppingCartCount: 0
        };
        const bagPath = '/bag/login';
        const selectDescriptor = redirectNoItemsNotSigned.next( userData ).value;

        expect( selectDescriptor ).toEqual( put( serviceActions.pageRedirect(
          action.data.history.location.pathname, bagPath ) ) );

      } );

      it( 'should yield cancel', () => {

        const cancelDescriptor = redirectNoItemsNotSigned.next().value;

        expect( cancelDescriptor ).toEqual( cancel() );

      } );

    } );

  } );

} );