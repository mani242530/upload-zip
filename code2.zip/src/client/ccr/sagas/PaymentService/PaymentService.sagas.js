
import { takeEvery, call, put, select } from 'redux-saga/effects';
import { delay } from 'redux-saga';
import { isUndefined, has, isEmpty } from 'lodash';
import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';


import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

let isPaymentRequested = {
  type: ''
}

export const listener = function*( type, data ){
  try {
    let res;
    if( !isUndefined( isPaymentRequested ) && isPaymentRequested.type === '' ){

      isPaymentRequested = yield put( getActionDefinition( type, 'loading' )( data.data.values ) );

      let values=data.data.values;
      try {
        if( !isUndefined( values.giftcardNumber ) ){
          yield call( delay, 2000 );
        }

      }
      catch ( e ){}

      res = yield call( ajax,
        {
          type,
          method:'post',
          values
        }
      );
    }
    yield put( getActionDefinition( type, 'success' )( { result:res.body, paymentType:data.data.values.paymentType } ) );
    if( !isUndefined( isPaymentRequested ) ){
      isPaymentRequested.type = '';
    }

    // Analytics tracking code begin
    if( !isUndefined( res.body ) ){
      const {
        cartSummary,
        paymentDetails
      } = res.body;

      let messages = [];
      paymentDetails.forEach( function( payment ){
        if( !isEmpty( payment.messages ) ){
          messages.push( ...payment.messages );
        }
      } );

      const data = {
        'globalPageData': {
          'order': {
            'total': ( cartSummary.estimatedTotal ).toFixed( 2 ),
            'subtotal': ( cartSummary.subTotal ).toFixed( 2 ),
            'shipping': ( cartSummary.shippingCost === 'FREE' ? cartSummary.shippingCost : ( cartSummary.shippingCost ).toFixed( 2 ) ),
            'voucher_discount': cartSummary.couponDiscount
          },
          'messages': messages
        }

      }

      let evt = undefined;

      paymentDetails.forEach( function( payment ){
        if( payment.paymentInfo.paymentType === 'giftCard' && payment.messages[0].messageType === 'Info' ){
          evt = {
            'name': 'trackApplyGiftCard'
          }
        }
        if( payment.paymentInfo.paymentType === 'giftCard' && payment.messages[0].messageType === 'Error' ){
          evt = {
            'name': 'trackErrorDisplayed',
            'data': {
              'errorType':'form',
              'errorLabel':'apply gift cart',
              'errorDescription': payment.messages[0].messageDesc
            }
          }
        }

      } );


      yield put( dataLayerActions.setDataLayer( data, evt ) );

      if( !isEmpty( messages ) ){
        const messageEvent = {
          'name': 'serviceMessagesUpdated'
        }
        yield put( dataLayerActions.setDataLayer( data, messageEvent ) );
      }

    }
    // Analtyics tracking code end

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

    if( !isUndefined( isPaymentRequested ) ){
      isPaymentRequested.type = '';
    }
  }
}

export default function*(){
  let serviceType = 'paymentServiceResponse';
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );

  serviceType = 'removePaymentService';
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );

}
