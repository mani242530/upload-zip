/**
 * PaymentService sagas test
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import saga, { listener } from './PaymentService.sagas';
import { delay } from 'redux-saga';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';

const res = {
  body: {
    cartSummary: {
      estimatedTotal: 422.57,
      subTotal: 394,
      shippingCost: 'FREE',
      couponDiscount: 0,
      itemCount: 12
    },
    paymentDetails: [{
      messages: [{
        messageType: 'Info',
        messageDesc: 'Test message desc'
      }],
      paymentInfo: {
        paymentType: 'giftCard'
      }
    }]
  }
};
const paymentType ='loyalty';
let isPaymentRequested = {
  type: ''
};
const data = {
  data:{
    values:{
      paymentType:paymentType,
      giftcardNumber: '3213132131'
    }
  }
};
const evt = 'test';

describe( 'paymentService Saga', () => {

  const paymentServiceSaga = saga();
  const type = 'paymentServiceResponse';

  registerServiceName( type );

  describe( 'paymentServiceResponse saga', () =>{

    it( 'should listen for the paymentServiceResponse requested method', () =>{

      const takeEveryDescriptor = paymentServiceSaga.next().value;

      expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), listener, type ) );

    } );

  } );

  describe( 'listener saga success/failure path', () => {

    const values=data.data.values;
    const listenerSaga = listener( type, data );

    it( 'should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;

      isPaymentRequested.type = 'loading';

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( data.data.values ) ) );
      expect( isPaymentRequested ).toEqual( { type:'loading' } );

    } );

    it( 'should call a delay of 2000', () => {

      const callDescriptor  = listenerSaga.next( isPaymentRequested ).value;

      expect( callDescriptor ).toEqual( call( delay, 2000 ) );

    } );

    it( 'should yield the ajax POST call', () => {

      const callDescriptor  = listenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', values } ) );

    } );

    it( 'should put a success call', () => {

      isPaymentRequested.type = '';
      const putDescriptor  = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual(
        put( getActionDefinition( type, 'success' )( { result:res.body, paymentType:data.data.values.paymentType } ) ) );
      expect( isPaymentRequested ).toEqual( { type:'' } );

    } );

    it( 'should put setDataLayer action', () => {

      const data = {
        globalPageData: {
          messages: res.body.paymentDetails[0].messages,
          order: {
            total: ( res.body.cartSummary.estimatedTotal ).toFixed( 2 ),
            subtotal: ( res.body.cartSummary.subTotal ).toFixed( 2 ),
            shipping: ( res.body.cartSummary.shippingCost === 'FREE' ? res.body.cartSummary.shippingCost : ( res.body.cartSummary.shippingCost ).toFixed( 2 ) ),
            voucher_discount: res.body.cartSummary.couponDiscount
          }
        }
      };
      const evt = {
        name: 'trackApplyGiftCard'
      };
      const putDescriptor  = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );

    } );

    describe( 'listener saga failure path', () => {

      const err = {
        statusText:'some failure message'
      };

      it( 'should put a failure event if no data is returned from the service', () => {

        global.TRACK_SAGA_FAILURES = true;
        const putDescriptor = listenerSaga.throw( err, global ).value;
        isPaymentRequested.type = '';

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

      } );

      it( 'should throw the error', () => {

        expect( () => {
          listenerSaga.next( isPaymentRequested ).throw( err )
        } ).toThrow();

        listenerSaga.next();
        expect( isPaymentRequested ).toEqual( { type:'' } );

      } );

    } );

    describe( 'listener saga failure path when not tracking failures', () => {

      const res = {
        body: {
          cartSummary: {
            estimatedTotal: 422.57,
            subTotal: 394,
            shippingCost: 'FREE',
            couponDiscount: 0,
            itemCount: 12
          },
          paymentDetails: [{
            messages: [{
              messageType: 'Error',
              messageDesc: 'Test message desc'
            }],
            paymentInfo: {
              paymentType: 'giftCard',
              messages: [{
                messageType: 'Error',
                messageDesc: 'Test message desc'
              }]
            }
          }]
        }
      };
      const paymentServiceSaga = saga();
      const listenerSaga = listener( type, data );
      const err = {
        statusText:'some failure message'
      };
      const values = data.data.values;
      const actionData = {
        globalPageData: {
          messages: [{
            messageDesc: 'Test message desc',
            messageType: 'Error'
          }],
          order: {
            total: ( res.body.cartSummary.estimatedTotal ).toFixed( 2 ),
            subtotal: ( res.body.cartSummary.subTotal ).toFixed( 2 ),
            shipping: ( res.body.cartSummary.shippingCost === 'FREE' ? res.body.cartSummary.shippingCost : ( res.body.cartSummary.shippingCost ).toFixed( 2 ) ),
            voucher_discount: res.body.cartSummary.couponDiscount
          }
        }
      };

      it( 'should until the loading event has been put', () => {

        const putDescriptor = listenerSaga.next().value;

        isPaymentRequested.type = 'loading';

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( data.data.values ) ) );
        expect( isPaymentRequested ).toEqual( { type:'loading' } );

      } );

      it( 'should call a delay of 2000', () => {

        const callDescriptor  = listenerSaga.next( isPaymentRequested ).value;

        expect( callDescriptor ).toEqual( call( delay, 2000 ) );

      } );

      it( 'should yield the ajax POST call', () => {

        const callDescriptor  = listenerSaga.next().value;

        expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', values } ) );

      } );

      it( 'should put a success call', () => {

        isPaymentRequested.type = '';
        const putDescriptor  = listenerSaga.next( res ).value;

        expect( putDescriptor ).toEqual(
          put( getActionDefinition( type, 'success' )( { result:res.body, paymentType:data.data.values.paymentType } ) ) );
        expect( isPaymentRequested ).toEqual( { type:'' } );

      } );

      it( 'should put setDataLayer action', () => {

        const evt = {
          name: 'trackErrorDisplayed',
          data: {
            errorType:'form',
            errorLabel:'apply gift cart',
            errorDescription: res.body.paymentDetails[0].messages[0].messageDesc
          }
        }
        const putDescriptor = listenerSaga.next( res ).value;

        expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( actionData, evt ) ) );

      } );

      it( 'should put setDataLayer messageEvent action', () => {

        const messageEvent = {
          'name': 'serviceMessagesUpdated'
        }
        const putDescriptor = listenerSaga.next( res ).value;

        expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( actionData, messageEvent ) ) );

      } );

      it( 'should put a failure event if no data is returned from the service', () => {

        global.TRACK_SAGA_FAILURES = false;
        const putDescriptor = listenerSaga.throw( err, global ).value;
        isPaymentRequested.type = '';

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

      } );

      it( 'should set the Payment Requested Type as blank', () => {

        listenerSaga.next();

        expect( isPaymentRequested ).toEqual( { type:'' } );

      } );

    } );

  } );

} );

describe( 'PaymentService Saga', () => {

  describe( 'removePaymentService saga', () => {

    it( 'should listen for the removePaymentService requested method', () => {

      const removePaymentServiceSaga = saga();
      const removeType = 'removePaymentService';

      registerServiceName( removeType );

      removePaymentServiceSaga.next();
      const takeEveryDescriptor = removePaymentServiceSaga.next().value;

      expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( removeType, 'requested' ), listener, removeType ) );

    } );

  } );

} );
