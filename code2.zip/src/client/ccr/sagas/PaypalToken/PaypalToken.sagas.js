/**
 * PaypalToken sagas
 */
import { takeEvery, call, put } from 'redux-saga/effects';

import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';

// Individual exports for testing
export const listener = function*( type, data ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const res = yield call( ajax, { type } );


    yield put( getActionDefinition( type, 'success' )( res.body ) );

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }
}

export default function*(){
  let serviceType = 'paypalToken';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( 'paypalToken', 'requested' ), listener, serviceType );
}
