import { takeLatest, call, put } from 'redux-saga/effects';
import { delay } from 'redux-saga';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  types as miniCartActionTypes
} from 'hf/actions/MiniCart/MiniCart.actions'

import {
  actions as serviceActions,
  types as serviceActionTypes,
  registerServiceName,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

// Individual exports for testing
export const listener = function*( type, action ){

  try {

    yield put( getActionDefinition( type, 'loading' )( action.item ) );

    let query = {
      removalCommerceId: action.item.commerceItemid
    }

    const res =  yield call(
      ajax, {
        type,
        method:'post',
        query
      }
    );
    yield put( getActionDefinition( type, 'success' )( { type:res.body.data, item:action.item } ) ) ;

    // Analytics tracking code begin
    if( res.body.data ){

      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( serviceActions.checkoutRedirectListener( action.item.history, qty, loadCartMessages ) );

      const {
        cartSummary
      } = res.body.data;


      // remove the item from the orderItems object data layer
      if( cartSummary.itemCount === 0 ){
        global.globalPageData.order.orderItems = {};
      }
      else {
        global.globalPageData.order.orderItems.splice( global.globalPageData.order.orderItems.map( function( item ){
          return item.skuId;
        } ).indexOf( action.item.catalogRefId ), 1 )
      }


      // update data layer and fire remove from cart event
      const evt = {
        'name': 'cartRemoveFromCart',
        'data': {
          'sku': action.item.catalogRefId
        }
      }
      const data = {
        'globalPageData': {
          'order': {
            'removedFromCart': action.item.catalogRefId
          }
        }
      }


      yield put( dataLayerActions.setDataLayer( data, evt ) );

    }
    // Analtyics tracking code end



  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export const updateListner = function*( type, action ){
  try {

    let values = {
      updateCommerceId: action.item,
      updateQuantity: action.quantity
    }
    const res =  yield call(
      ajax, {
        type,
        method:'post',
        values
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) ) ;
    if( res.body.data ){
      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( serviceActions.checkoutRedirectListener( action.history, qty, loadCartMessages ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let removeServiceType = 'removeItemFromCart';
  let updateServiceType = 'updateCartItems'
  // register events for the request
  registerServiceName( removeServiceType );
  registerServiceName( updateServiceType );

  yield takeLatest( miniCartActionTypes.REMOVE_FROM_CART, listener, removeServiceType );
  yield takeLatest( miniCartActionTypes.UPDATE_CART, updateListner, updateServiceType );

}
