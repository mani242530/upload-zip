import { takeLatest, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import { delay } from 'redux-saga';

import saga, {
  listener,
  updateListner
} from './ProductCell.sagas';

import {
  types as miniCartActionTypes
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  types,
  actions,
  registerServiceName,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';

jest.mock( 'utils/Ajax/Ajax', () => {
  return { ajax:jest.fn() }
} );

const type = 'removeItemFromCart';
const updateServiceType = 'updateCartItems'

describe( 'ProductCell Saga', () => {

  registerServiceName( type );
  registerServiceName( updateServiceType );

  describe( 'ProductCell saga', () => {

    const coreSaga = saga();

    it( 'should listen for the navigation requested method removeItemFromCart', () => {

      const takeLatestDescriptor = coreSaga.next().value;

      expect( takeLatestDescriptor ).toEqual(
        takeLatest( miniCartActionTypes.REMOVE_FROM_CART, listener, type )
      );

    } );

    it( 'should listen for the navigation requested method updateCartItems', () => {

      const takeLatestDescriptor = coreSaga.next().value;

      expect( takeLatestDescriptor ).toEqual(
        takeLatest( miniCartActionTypes.UPDATE_CART, updateListner, updateServiceType )
      );

    } );

  } );

  describe( 'removeItemFromCart listener saga success/failure path', () => {

    const itemID = '1234';
    const action = {
      item: {
        commerceItemid: '1234',
        catalogRefId: '5678',
        history: {}
      }
    };
    const res = {
      body: {
        data:{
          removeItemFromCart: false,
          cartSummary: {
            itemCount: 0
          },
          messages: {}
        }
      }
    };
    const listenerSaga = listener( type, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( action.item ) ) );

    } );

    it( 'should yield the ajax POST call', () => {

      const query = {
        removalCommerceId: itemID
      };
      const callDescriptor  = listenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', query } ) );

    } );

    it( 'should put a success call', () => {

      const putDescriptor  = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual(
        put( getActionDefinition( type, 'success' )( { type:res.body.data, item:action.item } ) ) );

    } );

    it( 'should put checkoutRedirectListener action', () => {

      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual(
        put( actions.checkoutRedirectListener(
          action.item.history, res.body.data.cartSummary.itemCount, res.body.data.messages ) ) );

    } );

    it( 'should put setDataLayer action', () => {

      const globalPageData = {
        order: {
          orderItems: []
        }
      };
      const evt = {
        name: 'cartRemoveFromCart',
        data: {
          sku: action.item.catalogRefId
        }
      };
      const data = {
        globalPageData: {
          order: {
            removedFromCart: action.item.catalogRefId
          }
        }
      }
      global.globalPageData = globalPageData;
      const putDescriptor = listenerSaga.next( global ).value;

      expect( putDescriptor ).toEqual(
        put( dataLayerActions.setDataLayer( data, evt ) ) );

    } );

    it( 'should set the orderitems in the page object to empty', () => {
      expect( global.globalPageData.order.orderItems ).toEqual( {} );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      };
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

  describe( 'updateCartItems listener saga success/failure path', () => {

    const action = {
      item: {},
      quantity: 1
    };
    const res = {
      body: {
        data:{
          removeItemFromCart: 'true',
          cartSummary: {
            itemCount: 4
          },
          messages: {}
        }
      }
    };
    const updateListenerSaga = updateListner( updateServiceType, action );

    it( 'should yield the Ajax POST call ', () => {

      const query = {
        method: 'post',
        type: updateServiceType,
        values: {
          updateCommerceId: action.item,
          updateQuantity: action.quantity
        }
      };
      const callDescriptor  = updateListenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( ajax, query ) );

    } );

    it( 'should put a success call', () => {

      const putDescriptor  = updateListenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual(
        put( getActionDefinition( updateServiceType, 'success' )( res.body.data ) ) );

    } );

    it( 'should put checkoutRedirectListener action', () => {

      const putDescriptor = updateListenerSaga.next().value;

      expect( putDescriptor ).toEqual(
        put( actions.checkoutRedirectListener(
          action.item.history, res.body.data.cartSummary.itemCount, res.body.data.messages ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = updateListenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( updateServiceType, 'failure' )( err ) ) );

    } );

  } );

} );
