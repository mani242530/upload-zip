import { takeEvery, call, put } from 'redux-saga/effects';

import {
  ajax
} from 'utils/Ajax/Ajax';
import { last } from 'lodash';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';
import {
  types as MiniCart
} from 'hf/actions/MiniCart/MiniCart.actions';

// Individual exports for testing
export const listener = function* ( type, data ){
  try {
    yield put( getActionDefinition( type, 'requested' )() );
    yield put( getActionDefinition( type, 'loading' )() );
    let query = {};
    if( data.data.cartSummary.itemCount > 0 ){
      query = {
        schema: 'cart_page.rvi,cart_page.horizontal',
        showRecentProducts: true,
        pId: last( data.data.cartItems.items.filter( cartItem => cartItem.displayType !== 'removed' ) ).productId
      }
    }
    else {
      query = {
        schema: 'cart_page.rvi',
        showRecentProducts: true
      }
    }

    const res = yield call( ajax,
      {
        type,
        query
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body ) );

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function* (){
  let serviceType = 'productRecs';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( 'loadCart', 'success' ), listener, serviceType );

}
