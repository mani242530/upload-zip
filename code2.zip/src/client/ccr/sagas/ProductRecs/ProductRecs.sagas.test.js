/**
 * Created by rush on 5/3/17.
 */

/**
 * LoadCart  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import saga, { listener } from './ProductRecs.sagas';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';
import {
  ajax
} from 'utils/Ajax/Ajax';



const type = 'productRecs';
const sessionID = 12345;
let data =
  {
    'cartItems': {
      'items': [{
        'productId': 'ceerf344r431'
      },
      {
        'productId': 'ceerf344r42'
      },
      {
        'productId': 'ceerf344r43'
      },
      {
        'productId': 'ceerf344r44',
        'displayType':'removed'
      }
      ]
    }

    ,
    'cartSummary': {
      'itemCount': 1

    }
  };

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );
  const productRecsSaga = saga();

  describe( 'listener saga success path', () => {

    const listenerSaga = listener( type, { data } );
    it( 'should listen for the navigation requested method', () => {

      const takeEveryDescriptor = productRecsSaga.next().value;
      expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( 'loadCart', 'success' ), listener, type ) );
    } );
    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'requested' )() ) );

    } );
    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      let callDescriptor = listenerSaga.next().value;

      let query = { schema: 'cart_page.rvi,cart_page.horizontal', showRecentProducts: true, pId: 'ceerf344r43' };

      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );
  } );
  describe( 'listener saga on empty page success path', () => {
    data =
      {
        'cartSummary': {
          'itemCount': 0
        }
      };
    const listenSaga = listener( type, { data } );
    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'requested' )() ) );

    } );
    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data in empty bag and return that data with a sucess method', () => {

      let callDescriptor = listenSaga.next().value;

      let query = { schema: 'cart_page.rvi', showRecentProducts: true };

      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

  } );


} );
