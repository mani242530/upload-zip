import { takeLatest, call, put } from 'redux-saga/effects';

import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  types as miniCartTypes
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  actions as serviceActions,
  types as serviceActionTypes,
  registerServiceName,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

// Individual exports for testing
export const listener = function*( type, action ){

  try {
    let methodType ='';
    yield put( getActionDefinition( type, 'loading' )() );
    let query;
    if( type === 'addProductSamples' ){
      let qty = action.quantity;
      let catalogRefId = action.catalogID;
      methodType = 'post';
      query = {
        catalogRefIds: catalogRefId,
        quantity: qty
      }
    }
    else {
      methodType = 'get';
      query = {}
    }


    const res =
      yield call( ajax,
        {
          type,
          method:methodType,
          query
        }
      );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data ){
      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( serviceActions.checkoutRedirectListener( action.history, qty, loadCartMessages ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'addProductSamples';
  // register events for the request
  registerServiceName( serviceType );
  yield takeLatest( miniCartTypes.SELECT_PRODUCT_SAMPLE_SERVICE, listener, serviceType );

  serviceType = 'removeProductSamples';
  // register events for the request
  registerServiceName( serviceType );
  yield takeLatest( miniCartTypes.REMOVE_PRODUCT_SAMPLE_SERVICE, listener, serviceType );

}
