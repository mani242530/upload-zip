/**
 * ReadCart sagas
 */

import { take, takeEvery, call, put, select, cancel, cancelled } from 'redux-saga/effects';
import { delay } from 'redux-saga';
import { getUserState } from 'shared/reducers/User/User.reducer';
import { getMiniCartState } from 'hf/reducers/MiniCart/MiniCart.reducer';
import {
  ajax
} from 'utils/Ajax/Ajax';
import {
  actions as CheckoutPageActions
} from 'ccr/actions/CheckoutPage/CheckoutPage.actions';
import {
  actions as serviceActions,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';

import { isUndefined, find, concat, isEmpty, has, isNumber } from 'lodash';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

export const checkForRedirect = function*( action ){

  const UserData = yield select( getUserState );
  const MiniCartData = yield select( getMiniCartState );

  const {
    isSignedIn,
    shoppingCartCount
  } = UserData;

  const {
    history
  } = action.data;

  const {
    pathname
  } = action.data.history.location;

  const cartCount = parseInt( shoppingCartCount, 10 );
  let signedInEmptyBag = '/bag/empty';
  let signedOutEmptyBag = '/bag/login';
  const bagPage = '/bag';
  const checkoutPage = '/checkout';

  // if the minicart data or cartPageData is empty we must call load cart
  // to make sure that we have the information to determin
  // if the user has opted into AND selected a free gift item
  if( isEmpty( MiniCartData ) || isEmpty( MiniCartData.cartPageData ) ){

    yield put( getActionDefinition( 'loadCart', 'requested' )( { history } ) );
    const cartPageData = yield take( getServiceType( 'loadCart', 'success' ) );

    const {
      giftItems
    } = cartPageData.data;

    // check the loadCartData to see if any of the items are opted in AND the if they are
    // check to see if the freeGift is selected for that 'indulge'.  If it opted in
    // and not selected we should redirect the user to the cart page, so that they can
    // make their selections

    let isAllVariantsSelected = true;

    if( !isEmpty( giftItems ) ){
      for ( let giftItem of giftItems ){
        if( giftItem && giftItem.induldge && giftItem.freeGifts && giftItem.freeGifts.length > 2 ){
          let selectedItemVals = giftItem.freeGifts.map( ( freeGift ) => freeGift.selected );
          if( selectedItemVals.indexOf( 'true' ) < 0 ){
            isAllVariantsSelected = false;
            break;
          }
        }
      }
    }

    if( !isAllVariantsSelected ){
      history.replace( bagPage );
      yield put( serviceActions.pageRedirect( checkoutPage, bagPage ) );
      yield cancel();

    }
  }




  // if i am signed in, have no cart items, and I'm not on the signed emptyBagPage redirct me to the signedin emptyBagpage
  if( isSignedIn && cartCount === 0 && pathname !== signedInEmptyBag ){
    history.replace( signedInEmptyBag );
    yield put( serviceActions.pageRedirect( pathname, signedInEmptyBag ) );
    yield cancel();
  }

  // if i am not signed in, have no cart items, and I'm not on the signed out emptyBagPage redirct me to the signed out emptyBagpage
  if( !isSignedIn && cartCount === 0 && pathname !== signedOutEmptyBag ){
    history.replace( signedOutEmptyBag );
    yield put( serviceActions.pageRedirect( pathname, signedOutEmptyBag ) );
    yield cancel();
  }
}

// Individual exports for testing
export const listener = function*( type, action ){

  try {
    const UserData = yield select( getUserState );

    const {
      isSignedIn
    } = UserData;

    // before we do anything we need to see if we need to redirect the user
    yield call( checkForRedirect, action );

    yield put( getActionDefinition( type, 'loading' )() );

    const res = yield call( ajax, { type } );

    yield put( getActionDefinition( type, 'success' )( res.body ) );

    // Analytics tracking code begin
    if( !isUndefined( res.body ) ){

      const {
        cartSummary,
        cartItems,
        freeSampleInfo,
        shippingInfo,
        paymentDetails
      } = res.body;

      let sampleAdded;
      let sampleSkuId;
      const cartContents = ( cartItems.commerceItems.map( ( commerceItem, index ) => {
        if( commerceItem.itemType === 'sample' ){
          sampleAdded = 'true';
          sampleSkuId = commerceItem.catalogRefId
        }
        return {
          ...( commerceItem.productId && { 'productId': commerceItem.productId } ),
          ...( commerceItem.catalogRefId && { 'skuId': commerceItem.catalogRefId } ),
          ...( commerceItem.productDisplayName && { 'productName': commerceItem.productDisplayName } ),
          'pageURL': '/checkout/',
          ...( commerceItem.brandName && { 'manufacturer': commerceItem.brandName } ),
          ...( commerceItem.productURL && { 'pageURL': commerceItem.productURL } ),
          ...( commerceItem.quantity && { 'quantity': commerceItem.quantity } ),
          ...( !isUndefined( commerceItem.adbugMessageMap ) && commerceItem.adbugMessageMap !== null && { 'promotions': commerceItem.adbugMessageMap.adbugMessage } ),
          ...( { 'itemType': commerceItem.itemType } )
        };

      } ) );

      let messages = [];

      if( !isEmpty( shippingInfo ) && !isEmpty( shippingInfo.messages ) ){
        messages.push( ...shippingInfo.messages );
      }

      if( !isEmpty( paymentDetails ) ){
        paymentDetails.forEach( function( payment ){
          if( !isEmpty( payment.messages ) ){
            messages.push( ...payment.messages );
          }
        } );
      }
      const data = {
        'globalPageData': {
          'action':{
            'sampleAdded': sampleAdded
          },
          'sampleSkuId': sampleSkuId,
          'order': {
            'currency': cartSummary.currencyCode,
            'total': ( cartSummary.estimatedTotal ) ? ( cartSummary.estimatedTotal ).toFixed( 2 ) : cartSummary.estimatedTotal,
            'subtotal': ( cartSummary.subTotal ) ? ( cartSummary.subTotal ).toFixed( 2 ) : cartSummary.subTotal,
            'shipping': ( isNumber( cartSummary.shippingCost ) ? ( cartSummary.shippingCost ).toFixed( 2 ) : cartSummary.shippingCost ),
            'itemCount': cartSummary.itemCount,
            'voucher_discount': cartSummary.couponDiscount,
            'orderItems': cartContents
          },
          'messages' : messages
        }
      }

      const evt = {
        'name': 'pageNavigation'
      }



      if( res.body.shippingInfo.shippingStatus === 'CorrectedAddress' ){
        yield call( delay, 2000 );
      }
      if( !isSignedIn ){
        yield put( CheckoutPageActions.updateDavPopup() );
      }

      // Only dispatch page navigation event when loading of checkout.
      if( !isUndefined( action.data.firePageNavigation ) && action.data.firePageNavigation ){
        yield put( dataLayerActions.setDataLayer( data, evt ) );
      }
      else {
        yield put( dataLayerActions.setDataLayer( data ) );
      }

      if( !isEmpty( messages ) ){
        const messageEvent = {
          'name': 'serviceMessagesUpdated'
        }
        yield put( dataLayerActions.setDataLayer( data, messageEvent ) );
      }

    }
    // Analtyics tracking code end





  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
  finally {
    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'canceled' )() );
    }
  }
}

export const listener1 = function*( type, data ){
  const UserData = yield select( getUserState );

  const {
    isSignedIn
  } = UserData;

  if( has( data.data, 'cartMerged' ) ){
    if( !data.data.cartMerged ){
      try {
        yield put( getActionDefinition( type, 'loading' )() );

        const res = yield call( ajax, { type } );

        yield put( getActionDefinition( type, 'success' )( res.body ) );
        if( res.body.shippingInfo.shippingStatus === 'CorrectedAddress' ){
          yield call( delay, 5000 );
        }
        if( !isSignedIn ){
          yield put( CheckoutPageActions.updateDavPopup() );
        }
      }
      catch ( err ){
        yield put( getActionDefinition( type, 'failure' )( err ) );
      }
    }
  }
}

export default function*(){
  let serviceType = 'readCart';
  // register events for the request
  registerServiceName( serviceType );

  yield takeEvery( getServiceType( 'readCart', 'requested' ), listener, serviceType );
  yield takeEvery( getServiceType( 'login', 'success' ), listener1, serviceType );


}
