/**
 * ReadCart sagas test
 */

import { takeEvery, call, put, take } from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/lib/utils';
import saga, { listener, listener1, checkForRedirect } from './ReadCart.sagas';
import Cookies from 'js-cookie';
import { delay } from 'redux-saga';
import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import {
  actions as serviceActions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';

const type = 'readCart';
const sessionID = 12345;
describe( 'defaultSaga Saga', () => {

  registerServiceName( type );
  registerServiceName( 'login' );

  describe( 'listener saga success path', () => {

    const listenerSaga = cloneableGenerator( listener )( type, { data: sessionID } );

    it( 'should until the loading event has been put', () => {
      listenerSaga.next().value;
      listenerSaga.next( { isSignedIn: true } ).value;
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor  = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( ajax, { type } ) );
    } );

    describe( 'data layer actions', () => {
      const res = {
        body : {
          cartItems : {
            commerceItems : []
          },
          cartSummary : {
            itemCount : 1,
            estimatedTotal : 100,
            subTotal : 50,
            shippingCost : 10
          },
          shippingInfo : {
            messages : [{
              key : 'failure',
              desc : 'error occurred'
            }]
          },
          paymentDetails : [
            {
              messages : [{
                'messageDesc': 'Credit card is expired.',
                'messageKey': 'CREDIT_CARD_NOT_VALID',
                'messageType': 'Error'
              }]
            }
          ]
        }
      }
      const messages = res.body.shippingInfo.messages.concat( res.body.paymentDetails[0].messages );

      const data = {
        'globalPageData': {
          'action':{
            'sampleAdded': undefined
          },
          'sampleSkuId': undefined,
          'order': {
            'currency': undefined,
            'total': '100.00',
            'subtotal': '50.00',
            'shipping': '10.00',
            'itemCount': 1,
            'voucher_discount': undefined,
            'orderItems': []
          },
          'messages' : messages
        }
      }
      const errEvent = {
        'name': 'serviceMessagesUpdated'
      }
      let listenerSagaClone;
      it( 'should put a datalayer action with a numeric value for shipping cost', () => {
        listenerSagaClone = listenerSaga.clone();
        listenerSaga.next( res );
        listenerSaga.next();
        expect( listenerSaga.next().value ).toEqual( put( dataLayerActions.setDataLayer( data, errEvent ) ) );
      } );

      it( 'should put a datalayer action with a non numeric value for shipping cost', () => {
        res.body.cartSummary.shippingCost = 'FREE';
        data.globalPageData.order.shipping = 'FREE';
        listenerSagaClone.next( res );
        listenerSagaClone.next();
        expect( listenerSagaClone.next().value ).toEqual( put( dataLayerActions.setDataLayer( data, errEvent ) ) );
      } );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

  describe( 'listener1 saga sucess path', () => {

    let type = 'login';

    const listenerSaga1 = cloneableGenerator( listener1 )( type, { data: { cartMerged : false } } );

    it( 'should until the loading event has been put', () => {
      listenerSaga1.next().value;
      const putDescriptor = listenerSaga1.next( { isSignedIn: false } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor  = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( ajax, { type } ) );

    } );

    it( 'should put a success event if the res.body is success', () => {

      const res = {
        success: 'false',
        shippingInfo : {
          shippingStatus : 'CorrectedAddress'
        }
      }
      const putDescriptor = listenerSaga1.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );

    } );

    it( 'should call delay if res.body is success', () => {
      const callDescriptor2 = listenerSaga1.next().value;

      expect( callDescriptor2 ).toEqual( call( delay, 5000 ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga1.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

} );


describe( 'checkforredirect test', () => {

  registerServiceName( 'loadCart' );

  const action = {
    data : {
      history : {
        location : {
          pathname : '/checkout'
        },
        replace:jest.fn()
      }
    }
  }

  let giftItems = {
    'giftItems': [{
      'freeGifts': [{
        'giftProductId': 'xlsImpprod14051035',
        'giftPDPUrl': '/ulta/browse/productDetail.jsp?productId=xlsImpprod14051035&skuId=2275796',
        'giftCatalogRefId': '2275796',
        'giftDisplayName': 'Online Only FREE deluxe sample POREfessional w/any $35 Benefit purchase',
        'giftCategoryName': 'Gifts with Purchase',
        'giftImageURL': 'https://images.ulta.com/is/image/Ulta/2275796?$md$',
        'selected': 'false',
        'giftBrandName': 'Benefit Cosmetics'
      },
      {
        'giftProductId': 'xlsImpprod14051035',
        'giftPDPUrl': '/ulta/browse/productDetail.jsp?productId=xlsImpprod14051035&skuId=2275796',
        'giftCatalogRefId': '2275796',
        'giftDisplayName': 'Online Only FREE deluxe sample POREfessional w/any $35 Benefit purchase',
        'giftCategoryName': 'Gifts with Purchase',
        'giftImageURL': 'https://images.ulta.com/is/image/Ulta/2275796?$md$',
        'selected': 'false',
        'giftBrandName': 'Benefit Cosmetics'
      },
      {
        'giftProductId': 'xlsImpprod14051035',
        'giftPDPUrl': '/ulta/browse/productDetail.jsp?productId=xlsImpprod14051035&skuId=2275796',
        'giftCatalogRefId': '2275796',
        'giftDisplayName': 'Online Only FREE deluxe sample POREfessional w/any $35 Benefit purchase',
        'giftCategoryName': 'Gifts with Purchase',
        'giftImageURL': 'https://images.ulta.com/is/image/Ulta/2275796?$md$',
        'selected': 'default',
        'giftBrandName': 'Benefit Cosmetics'
      }],
      'promoValidity': 'offer valid 05/07/2017-05/14/2018 or while supplies last',
      'bfxPriceMap': [{ 'bfxQty': '1', 'bfxPrice': '$0.00' }],
      'promoId': '0000156262',
      'induldge': true
    }]
  };

  const bagPage = '/bag';
  const checkoutPage = '/checkout';

  it( 'ensure that redirect action is invoked if gift items not selected', () => {
    const checkForRedirectSaga = checkForRedirect( action );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next( {} );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next();
    const nextDescriptor = checkForRedirectSaga.next( { 'data':giftItems } ).value;
    expect( nextDescriptor ).toEqual( put( serviceActions.pageRedirect( checkoutPage, bagPage ) ) );
  } );

  it( 'ensure that redirect action is not invoked if gift items is selected', () => {
    giftItems.giftItems[0].freeGifts[0].selected = 'true';
    const checkForRedirectSaga = checkForRedirect( action );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next( {} );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next();
    const nextDescriptor = checkForRedirectSaga.next( { 'data':giftItems } ).value;
    expect( nextDescriptor ).toEqual( undefined );
  } );

  it( 'ensure that redirect action is not invoked if indulge is false and gift item is not selected', () => {
    giftItems.giftItems[0].freeGifts[0].selected = 'false';
    giftItems.giftItems[0].induldge = false;
    const checkForRedirectSaga = checkForRedirect( action );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next( {} );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next();
    const nextDescriptor = checkForRedirectSaga.next( { 'data':giftItems } ).value;
    expect( nextDescriptor ).toEqual( undefined );
  } );

} );

