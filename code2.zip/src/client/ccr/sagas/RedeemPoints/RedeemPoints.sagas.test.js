import { takeEvery, call, put } from 'redux-saga/effects';
import saga, { listener } from './RedeemPoints.sagas';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';
const type  = 'redeemPoints';



describe( 'redeemPoints Saga', () => {
  registerServiceName( type );

  const redeemPointssaga = saga();

  it( 'should listen for the navigation request method', () => {

    const takeEveryDescriptor = redeemPointssaga.next().value;
    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );
  } );

  describe( 'listener saga success path', () => {

    const listenerSaga = listener( type );


    it( 'should  until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );


    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

} )
