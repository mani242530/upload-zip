
import { takeEvery, call, put } from 'redux-saga/effects';
import { isUndefined } from 'lodash';
import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

// Individual exports for testing
export const listener = function*( type, data ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );

    let loyaltyMemberId=data.data.loyaltyMemberId;
    let values={
      loyaltyMemberId:loyaltyMemberId
    };
    const res = yield call( ajax,
      {
        type,
        method:'post',
        values
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body ) );


    // Analytics tracking code begin
    if( !isUndefined( res.body ) ){

      let data = {};
      let evt = {};


      if( res.body.cartSummary ){
        // if cartSummary data is returned the member id was found.
        data = {
          'globalPageData': {
            'rewards': {
              'loyaltyId': loyaltyMemberId
            }
          }
        }

        evt = {
          'name': 'memberIDAdded'
        }

      }
      else {
        // if no cartSummary was found then the lookup failed
        data = {
          'globalPageData': {
            'messages': res.body.messages
          }
        }

        evt = {
          'name': 'serviceMessagesUpdated'
        }

      }

      yield put( dataLayerActions.setDataLayer( data, evt ) );


    }



  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'rewardsLookup';

  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
