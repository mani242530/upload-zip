import { takeEvery, call, put } from 'redux-saga/effects';
import saga, { listener } from './RewardsLookUp.sagas';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';


import {
  ajax
} from 'utils/Ajax/Ajax';



const type  = 'rewardsLookup';



describe( 'rewardsLookup Saga', () => {
  registerServiceName( type );

  const rewardsLookupsaga = saga();

  it( 'should listen for the navigation request method', () => {

    const takeEveryDescriptor = rewardsLookupsaga.next().value;
    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );
  } );

  describe( 'listener saga success path', () => {

    const data = {
      'data': {
        'loyaltyMemberId': '2919032271518'
      }
    }

    const listenerSaga = listener( type, data );


    it( 'should  until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );



    it( 'should dispatch an analytics event', () => {

      listenerSaga.next();


      // create saga response
      let res = {
        'body': {
          'cartSummary': {
            'shippingCost': 5.95,
            'subTotal': 160.98999999999998,
            'itemCount': '9',
            'orderGiftWrapAmt': 3.99,
            'additionalDiscount': null,
            'couponDiscount': 0,
            'estimatedTax': 'TBD',
            'estimatedTotal': 170.93,
            'currencyCode': 'USD',
            'rewardPointsEarned':'100'
          }
        }
      };

      const data = {
        'globalPageData': {
          'rewards': {
            'loyaltyId':'2919032271518'
          }
        }
      }

      // create dispatch event when loyalty member id added
      const evt = {
        'name': 'memberIDAdded'
      };


      const putDescriptor = listenerSaga.next( res );
      expect( listenerSaga.next().value ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );

    } );





    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

  describe( 'data layer test for server side messages', () => {

    const data1 = {
      'data': {
        'loyaltyMemberId': '2919032271518'
      }
    }

    const listenerSaga1 = listener( type, data1 );
    listenerSaga1.next();
    listenerSaga1.next();

    let res = {
      'body': {
        'messages' : [{
          'key' : 'loyaltyerror',
          'desc' : 'look up failed'
        }]
      }
    };

    const data = {
      'globalPageData': {
        'messages' : [{
          'key' : 'loyaltyerror',
          'desc' : 'look up failed'
        }]
      }
    }

    // create dispatch event when server side messages present
    const evt = {
      'name': 'serviceMessagesUpdated'
    };

    const putDescriptor = listenerSaga1.next( res );
    expect( listenerSaga1.next().value ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );

  } );

} )

