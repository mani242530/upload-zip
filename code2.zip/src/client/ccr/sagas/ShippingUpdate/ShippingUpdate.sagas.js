/**
 * getQualifiedShipMethod sagas
 */

import { takeEvery, call, put, delay, take } from 'redux-saga/effects';
import { isUndefined, has, isEmpty } from 'lodash';
import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';

import {
  types as CheckoutPage
} from '../../actions/CheckoutPage/CheckoutPage.actions';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

// Individual exports for testing
let isShippingRequested = {
  type: ''
}
export const listener = function*( type, action ){

  try {
    let res;
    if( !isUndefined( isShippingRequested ) && isShippingRequested.type === '' ){
      isShippingRequested = yield put( getActionDefinition( type, 'loading' )( action.data ) );

      let values = { };
      if( action.data.values !== null ){
        values = action.data.values;
      }

      res = yield call(
        ajax, {
          type,
          method:'post',
          values
        }
      );
    }

    yield put( getActionDefinition( type, 'success' )( res.body ) );

    let { shippingInfo } = res.body;

    if( !isEmpty( shippingInfo ) && !isEmpty( shippingInfo.messages ) ){

      let messages = shippingInfo.messages ;
      const data = {
        'globalPageData': {
          'messages' : messages
        }
      }

      const evt = {
        'name' : 'serviceMessagesUpdated'
      }

      yield put( dataLayerActions.setDataLayer( data, evt ) );
    }
    if( !isUndefined( isShippingRequested ) ){
      isShippingRequested.type = '';
    }

    if( has( res.body, 'shippingInfo.shipMethodInfo.estimatedDelivery' ) && res.body.shippingInfo.shipMethodInfo.estimatedDelivery === null ){
      yield put( getActionDefinition( 'estimatedDeliveryDate', 'requested' )() );
      yield take( getServiceType( 'estimatedDeliveryDate', 'success' ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

    if( !isUndefined( isShippingRequested ) ){
      isShippingRequested.type = '';
    }
  }
}


export default function*(){
  let serviceType = 'shippingUpdate';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );


}
