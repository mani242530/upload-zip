/**
 * ReadCart sagas test
 */

import { takeEvery, call, put, take } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import saga, { listener } from './ShippingUpdate.sagas';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';



const type = 'shippingUpdate';
const sessionID = undefined;
const shipMethodName = 'ups_next_day';
const shipAddrNickName = 'secondaryShippingAddress';
const confirmAddress=true;
let isShippingRequested = {
  type: ''
}

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );
  registerServiceName( 'estimatedDeliveryDate' );

  describe( 'listener saga success path', () => {

    const data = {
      sessionID,
      shipMethodName,
      shipAddrNickName,
      confirmAddress
    };
    const listenerSaga = listener( type, { data } );

    it( 'should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      isShippingRequested.type = 'loading';
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( data ) ) );
      expect( isShippingRequested ).toEqual( { type:'loading' } );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      let values = undefined;
      expect( callDescriptor ).toEqual( call( ajax, {
        type,
        method: 'post',
        values
      } ) );

    } );

    it( 'should put a success event after data is called', () => {
      let res = {
        title: 'test',
        status: 'ok',
        shippingInfo : {
          messages :[
            {
              key : 'address error',
              desc : 'error occurred'
            }
          ],
          shipMethodInfo : {
            estimatedDelivery : null
          }
        }
      }
      const putDescriptor = listenerSaga.next( { body: res } ).value;
      isShippingRequested.type = '';
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
      expect( isShippingRequested ).toEqual( { type:'' } );

    } );

    it( 'should put an event for data layer updates', () => {
      let res = {
        shippingInfo : {
          messages :[
            {
              key : 'address error',
              desc : 'error occurred'
            }
          ]
        }
      }
      const data = {
        'globalPageData': {
          'messages' : res.shippingInfo.messages
        }
      }

      const evt = {
        'name' : 'serviceMessagesUpdated'
      }
      expect( listenerSaga.next().value ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );
    } );

    it( 'should put a estimatedDeliveryDate sucess', () => {

      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( 'estimatedDeliveryDate', 'requested' )() ) );

    } );

    it( 'should take a estimatedDeliveryDate success', () => {

      const takeDescriptor = listenerSaga.next().value;

      expect( takeDescriptor ).toEqual( take( getServiceType( 'estimatedDeliveryDate', 'success' ) ) );


    } );


    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      window.TRACK_SAGA_FAILURES = true;
      const putDescriptor = listenerSaga.throw( err, window ).value;
      isShippingRequested.type = '';
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      expect( isShippingRequested ).toEqual( { type:'' } );

    } );

  } );
} );
