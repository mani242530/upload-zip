import { takeEvery, takeLatest, call, put, take, select } from 'redux-saga/effects';
import { getUserState } from 'shared/reducers/User/User.reducer';
import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';
import { delay } from 'redux-saga';
import { isUndefined, has, isEmpty, find } from 'lodash';
import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

export const listener = function* ( type, data ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );

    let estimatedTotal = data.data.amountDue; // this is the value from readCartData.cartSummary.estimatedTotal
    let shippingSuccess = data.data.shippingSuccess;
    let paymentSuccess = data.data.paymentSuccess;

    // if shipping is already not succes by the time submit order is invoked, the shipping service call
    // will be invoked from here
    if( !shippingSuccess ){

      yield put( getActionDefinition( 'shippingUpdate', 'requested' )( { values: data.data.shippingData } ) );
      let response = yield take( getServiceType( 'shippingUpdate', 'success' ) );
      let shippingResponse = response.data.shippingInfo;
      let shippingMessage = has( shippingResponse, 'messages' ) && !isEmpty( shippingResponse.messages );
      let shippingErrorMessage = shippingMessage && find( shippingResponse.messages, { 'messageType': 'Error' } );

      if( shippingErrorMessage || shippingResponse.shippingStatus !== 'Complete' ){
        yield put( getActionDefinition( type, 'failure' )( { setFocusTo: 'shipping' } ) );
      }
      // if there is a message ( not necessarily error ) for shipmethodinfo, we need to block submit order
      else if( shippingMessage && find( shippingResponse.messages, { 'messageRef': 'shipMethodInfo' } ) ){
        yield put( getActionDefinition( type, 'failure' )( { displayCheckoutLevelErrorMessage:'false' } ) );
      }
      else {
        shippingSuccess = true;

        // if there is change in estimated total when shipping call is made,
        // payment service will be forced
        if( estimatedTotal !== response.data.cartSummary.estimatedTotal ){
          estimatedTotal = response.data.cartSummary.estimatedTotal;
          paymentSuccess = false;
        }
      }
    }

    // if shipping is success, and if payment is not success and estimatedTotal > 0, payment service call
    // will be invoked from here
    if( shippingSuccess && estimatedTotal > 0 && !paymentSuccess ){

      yield put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: data.data.paymentData } ) );
      let paymentResponse =  yield take( getServiceType( 'paymentServiceResponse', 'success' ) );
      let crediCardObject = find( paymentResponse.data.result.paymentDetails, ['paymentInfo.paymentType', 'creditCard'] );
      let payPalObject = find( paymentResponse.data.result.paymentDetails, ['paymentInfo.paymentType', 'paypal'] );

      if( ( has( crediCardObject, 'messages' ) && !isEmpty( crediCardObject.messages ) ) ||
        ( ( has( payPalObject, 'messages' ) && !isEmpty( payPalObject.messages ) ) ) ){
        yield put( getActionDefinition( type, 'failure' )( { setFocusTo: 'payment' } ) );
      }
      else {
        paymentSuccess=true;
      }
    }

    // place order will be invoked if shipping is success
    let placeOrder = shippingSuccess && ( estimatedTotal <= 0 || ( estimatedTotal > 0 && paymentSuccess ) );

    if( placeOrder ){

      const UserData = yield select( getUserState );

      const {
        isSignedIn
      } = UserData;

      let values = !isSignedIn ? { guestUserEmailOptIn: data.data.guestUserEmailOptIn } : '';
      const res = yield call( ajax,
        {
          type,
          method: 'post',
          values
        }
      );

      yield put( getActionDefinition( type, 'success' )( res.body ) );

      // update the JSON data layer for analtyics purposes.
      yield call( updateDataLayer, res );


    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

// for analtyics tracking we must pass all messages (info/error)
// then let them know there are messages.
export const updateDataLayer = function* ( res ){

  if( res.body.messages ){

    // analtyics tracking code
    const data = {
      'globalPageData': {
        'messages': res.body.messages
      }
    };

    const evt = {
      'name': 'serviceMessagesUpdated'
    };

    yield put( dataLayerActions.setDataLayer( data, evt ) );

  }


}

export default function* (){
  let serviceType = 'submitOrderService';

  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
