import { takeEvery, call, put, select } from 'redux-saga/effects';
import saga, { listener, updateDataLayer } from './SubmitOrderService.sagas';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';
const type  = 'submitOrderService';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import { getUserState } from 'shared/reducers/User/User.reducer';

import { cloneableGenerator } from 'redux-saga/lib/utils';


describe( 'submitOrderService Saga', () => {
  registerServiceName( type );

  const submitOrdersaga = saga();

  it( 'should listen for the navigation request method', () => {

    const takeEveryDescriptor = submitOrdersaga.next().value;
    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );
  } );

  describe( 'check shipping and billing object success', () => {
    const data = {
      data: {
        amountDue: 23.80,
        paymentData: { },
        paymentSuccess: true,
        paymentResponse: {
          'messages': [],
          'paymentInfo': {
            'amount': 23.19,
            'contactInfo': {
              'lastName': 'Test',
              'country': 'US',
              'address2': '',
              'city': 'San Diego',
              'address1': '4583 Delaware St',
              'postalCode': '92116',
              'firstName': 'Test',
              'phoneNumber': '754-647-8754',
              'state': 'CA',
              'email': null
            },
            'nickName': 'Visa - 1111',
            'paymentType': 'creditCard',
            'paymentDetails': {
              'expirationYear': '2020',
              'creditCardNumber': '1111',
              'creditCardType': 'Visa',
              'expirationMonth': '11'
            },
            'currencyCode': 'USD'
          }
        },
        shippingSuccess: true,
        shippingResponse: {
          'messages': [],
          'shippingStatus': 'Complete'
        },
        guestUserEmailOptIn: false
      }
    }

    const values = { guestUserEmailOptIn: true };
    const listenerSaga = listener( type, data );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a success method', () => {
      let values= { guestUserEmailOptIn: false }
      let UserData = listenerSaga.next().value;
      UserData = {
        isSignedIn: false
      }
      let callDescriptor = listenerSaga.next( { select } ).value;
      const method = 'post';
      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );

    } );



    const res = {
      status: 'ok'
    }

    it( 'should put a success event after data is called', () => {


      const listenerSaga = listener( type, data );
      let callDescriptor = listenerSaga.next().value;
      let UserData = listenerSaga.next().value;
      UserData = {
        isSignedIn: false
      }
      let putDescriptor = listenerSaga.next( { select } ).value;
      putDescriptor = listenerSaga.next( { body : res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );







    } );


    it( 'should call updateDataLayer method', () => {

      const putDescriptor = listenerSaga.next( { body: res } ).value;
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( updateDataLayer, { body: res } ) );

    } );

  } );

  describe( 'updateDataLayer for analytics test', () => {

    const dataLayerRes = {
      'messages': [
        {
          'messageKey': 'itemNoLongerActive',
          'messageType': 'Error',
          'messageDesc': 'Item no longer active.',
          'messageRef': 'cart'
        },
        {
          'messageKey': 'MissingShippingFirstName',
          'messageType': 'Error',
          'messageDesc': 'The first name is missing in the shipping address',
          'messageRef': 'shipping'
        },
        {
          'messageKey': 'invalidCreditCardVerificationNumber',
          'messageType': 'Error',
          'messageDesc': 'Please enter a valid credit card verification number.',
          'messageRef': 'payment'
        },
        {
          'messageKey': 'ERROR_PROCESSING_ORDER',
          'messageType': 'Error',
          'messageDesc': 'Error Processing the Order. Please try again..',
          'messageRef': 'checkout'
        }
      ]
    }


    const dataLayer = updateDataLayer( { body: dataLayerRes } );

    const putDescriptor = dataLayer.next().value;

    const data = {
      'globalPageData': {
        'messages': dataLayerRes.messages
      }
    };

    const evt = {
      'name': 'serviceMessagesUpdated'
    };

    expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );


  } );

  describe( 'check shiping and billing object failure', () => {

    const data = {
      data: {
        amountDue: 23.80,
        paymentData: { },
        paymentSuccess: true,
        paymentResponse: { },
        shippingSuccess: true,
        shippingResponse: {
          'messages': [
            {
              'messageKey': 'INFO_SHIPPING_CORRECTED_ADDRESS',
              'messageType': 'Info',
              'messageRef': 'shippingAddress',
              'messageDesc': 'USPS recommends the following address to ensure your package is delivered without issues.'
            }
          ],
          'shippingStatus': 'Complete'
        }
      }
    }

    const values = { guestUserEmailOptIn: true };

    const listenerSaga = listener( type, data );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should put a failure event if wrong data is returned from the service', () => {

      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

  describe( 'check failure due to shippingMethod Info message', () => {
    registerServiceName( 'shippingUpdate' );
    const data = {
      data: {
        amountDue: 23.80,
        paymentData: { },
        paymentSuccess: true,
        paymentResponse: { },
        shippingSuccess: false,
        shippingData: { },
        shippingResponse: { }
      }
    };

    const shippingResponse = {
      data:{
        shippingInfo:  {
          shippingStatus: 'Complete',
          shippingAddress: {
            lastName: 'last',
            country: 'US',
            address2: null,
            city: 'APO',
            address1: 'PSC3 box 7263',
            postalCode: '96266',
            firstName: 'test',
            phoneNumber: '469-901-4395',
            state: 'AP',
            email: 'tst@ulta.com'
          },
          messages: [
            {
              messageKey: 'ERR_SHIP_PRICE_CHANGED',
              messageType: 'Info',
              messageRef: 'shipMethodInfo',
              messageDesc: 'Free or discounted shipping is available in the Continental U.S. only and excludes PO Boxes, APO/FPO addresses.'
            }
          ],
          shipMethodInfo: {
            cost: '$5.95',
            displayName: 'Standard Shipping',
            shipMethod: 'ups_ground',
            estimatedDelivery: null
          }
        }
      }
    };
    const listenerSaga1 = listener( type, data );
    listenerSaga1.next().value;// loading
    listenerSaga1.next().value;// shippingUpdate requested
    listenerSaga1.next( shippingResponse ).value;// shippingUpdate success
    it( 'should put a failure event if shipMethodInfo is returned from the service', () => {
      const msg = { displayCheckoutLevelErrorMessage:'false' };
      const putDescriptor = listenerSaga1.next( shippingResponse ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( msg ) ) );
    } );

  } );

  describe( 'listener saga success path', () => {

    const listenerSaga = listener( type );

    it( 'should  until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

  describe( 'payment service call check', () => {

    registerServiceName( type );
    registerServiceName( 'paymentServiceResponse' );
    const data = {
      data : {
        amountDue:100,
        shippingSuccess:true,
        paymentSuccess:false,
        paymentData :{
          creditCardNumber: '4111111111111111',
          expirationDate: '12/2020',
          securityCode: '123',
          firstNamepaymentAddressForm: 'test',
          lastNamepaymentAddressForm: 'test',
          address1paymentAddressForm: '1000 remngton blvd',
          address2paymentAddressForm: 'Ste 200',
          citypaymentAddressForm: 'Boolingbrook',
          state: 'IL',
          postalCodepaymentAddressForm: '07105',
          phoneNumberpaymentAddressForm: '(510)-213-8347'
        }
      }
    }
    const expectedOutput = {
      creditCardNumber: '4111111111111111',
      expirationDate: '12/2020',
      securityCode: '123',
      firstNamepaymentAddressForm: 'test',
      lastNamepaymentAddressForm: 'test',
      address1paymentAddressForm: '1000 remngton blvd',
      address2paymentAddressForm: 'Ste 200',
      citypaymentAddressForm: 'Boolingbrook',
      state: 'IL',
      postalCodepaymentAddressForm: '07105',
      phoneNumberpaymentAddressForm: '(510)-213-8347'
    }
    const listenerSaga = listener( type, data );
    it( 'should  until the loading event has been put', () => {
      listenerSaga.next();
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: expectedOutput } ) ) );
    } );

  } );

  describe( 'payment service call check when estimated total changes', () => {
    const data = {
      data : {
        amountDue:100,
        shippingSuccess:false,
        paymentSuccess:true,
        paymentData :{
          creditCardNumber: '4111111111111111',
          expirationDate: '12/2020',
          securityCode: '123',
          firstNamepaymentAddressForm: 'test',
          lastNamepaymentAddressForm: 'test',
          address1paymentAddressForm: '1000 remngton blvd',
          address2paymentAddressForm: 'Ste 200',
          citypaymentAddressForm: 'Boolingbrook',
          state: 'IL',
          postalCodepaymentAddressForm: '07105',
          phoneNumberpaymentAddressForm: '(510)-213-8347'
        },
        shippingData : {
          firstNameshippingAddressForm: 'test',
          lastNameshippingAddressForm: 'test',
          address1shippingAddressForm: '1000 remngton blvd',
          address2shippingAddressForm: 'Ste 200',
          cityshippingAddressForm: 'Boolingbrook',
          emailaddressshippingAddressForm: 'test@test.com',
          state: 'IL',
          postalCodeshippingAddressForm: '07105',
          phoneNumbershippingAddressForm: '(510)-213-8347'
        }
      }
    }
    const expectedShippingOutput = {
      firstNameshippingAddressForm: 'test',
      lastNameshippingAddressForm: 'test',
      address1shippingAddressForm: '1000 remngton blvd',
      address2shippingAddressForm: 'Ste 200',
      cityshippingAddressForm: 'Boolingbrook',
      emailaddressshippingAddressForm: 'test@test.com',
      state: 'IL',
      postalCodeshippingAddressForm: '07105',
      phoneNumbershippingAddressForm: '(510)-213-8347'
    }
    const listenerSaga = cloneableGenerator( listener )( type, data );
    listenerSaga.next();
    it( 'should make the shipping update call', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'shippingUpdate', 'requested' )( { values: expectedShippingOutput } ) ) );
    } );

    let listenerSagaClone;
    it( 'should make the payment call if the estimated total is different', () => {
      listenerSagaClone = listenerSaga.clone();
      listenerSaga.next();
      const expectedPaymentOutput = {
        creditCardNumber: '4111111111111111',
        expirationDate: '12/2020',
        securityCode: '123',
        firstNamepaymentAddressForm: 'test',
        lastNamepaymentAddressForm: 'test',
        address1paymentAddressForm: '1000 remngton blvd',
        address2paymentAddressForm: 'Ste 200',
        citypaymentAddressForm: 'Boolingbrook',
        state: 'IL',
        postalCodepaymentAddressForm: '07105',
        phoneNumberpaymentAddressForm: '(510)-213-8347'
      }
      const response = {
        data : {
          shippingInfo : {
            shippingStatus : 'Complete'
          },
          cartSummary:{
            estimatedTotal : 150
          }
        }
      }
      const putDescriptor = listenerSaga.next( response ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: expectedPaymentOutput } ) ) );
    } );

    it( 'should make the payment call if the estimated total is different', () => {
      listenerSagaClone.next();
      const expectedPaymentOutput = {
        creditCardNumber: '4111111111111111',
        expirationDate: '12/2020',
        securityCode: '123',
        firstNamepaymentAddressForm: 'test',
        lastNamepaymentAddressForm: 'test',
        address1paymentAddressForm: '1000 remngton blvd',
        address2paymentAddressForm: 'Ste 200',
        citypaymentAddressForm: 'Boolingbrook',
        state: 'IL',
        postalCodepaymentAddressForm: '07105',
        phoneNumberpaymentAddressForm: '(510)-213-8347'
      }
      const response = {
        data : {
          shippingInfo : {
            shippingStatus : 'Complete'
          },
          cartSummary:{
            estimatedTotal : 100
          }
        }
      }
      const putDescriptor = listenerSagaClone.next( response ).value;
      expect( putDescriptor ).not.toEqual( put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: expectedPaymentOutput } ) ) );
    } );

  } );

} )
