
import ProfileSaga from 'shared/sagas/Profile/Profile.sagas';
import { takeEvery, take, call, put } from 'redux-saga/effects';
import { isUndefined, has } from 'lodash';

import {
  types,
  actions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  types as userActions
} from 'shared/actions/User/User.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import { getRoute } from 'utils/Omniture/Omniture'

// Individual exports for testing
export const listener = function*( type, data ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const res = yield call( ajax,
      {
        type,
        method:'post'
      }
    );

    // Analytics tracking
    // Check if a rewards account was created and if so then update the data layer
    // and dispatch and event to show the account was created.
    if( !isUndefined( res.body ) && has( res.body, 'isRewardsMember' ) ){

      // Only dispatch an event if the account was created.
      if( res.body.isRewardsMember ){
        const data = {
          'globalPageData': {
            'action': {
              'loyaltyCreated': ( res.body.isRewardsMember === true ? 'true' : 'false' )
            },
            'navigation': {
              'location': ( getRoute( 'checkout' ) ? 'checkout' : global.location.pathname.replace( /\.[^\.\/]+$/, '' ).substr( 1 ) )
            }
          }
        };

        const evt = {
          'name': 'loyaltyCreated'
        };

        yield put( dataLayerActions.setDataLayer( data, evt ) );
      }
    }
    // End analytics

    yield put( getActionDefinition( type, 'success' )( res.body ) );


  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }
}

export default function*(){
  let serviceType = 'userRewards';


  // register events for the request
  registerServiceName( serviceType );

  yield takeEvery( getServiceType( 'userRewards', 'requested' ), listener, serviceType );
}
