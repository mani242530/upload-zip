
/**
 * UserRewards  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import saga, { listener } from './UserRewards.sagas';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import { getRoute } from 'utils/Omniture/Omniture'

const type = 'userRewards';

registerServiceName( type );

describe( 'UserRewards Saga', () => {
  describe( 'UserRewards saga', () =>{

    const UserRewardsSaga = saga();

    it( 'should listen for the userRewards requested method', () =>{

      const takeLatestDescriptor = UserRewardsSaga.next().value;

      expect( takeLatestDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), listener, type ) );
    } );

  } );
  describe( 'listener saga success/failure path', () => {

    const res = {
      body: {
        isRewardsMember : true
      }
    };

    const listenerSaga = listener( type );

    it( 'should put the loading event', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post' } ) );

    } );

    it( 'should put setDataLayer action', () => {

      const evt = {
        name: 'loyaltyCreated'
      };
      const data = {
        globalPageData: {
          action: {
            loyaltyCreated: ( res.body.isRewardsMember === true ? 'true' : 'false' )
          },
          'navigation': {
            'location': ( getRoute( 'checkout' ) ? 'checkout' : global.location.pathname.replace( /\.[^\.\/]+$/, '' ).substr( 1 ) )
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual(
        put( dataLayerActions.setDataLayer( data, evt ) ) );

    } );

    it( 'should put a success event after data is called', () => {

      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      const err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );
} );
