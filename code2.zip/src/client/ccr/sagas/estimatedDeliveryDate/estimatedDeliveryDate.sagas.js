import { takeEvery, call, put, delay } from 'redux-saga/effects';
import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'shared/actions/Services/Services.actions';

// Individual exports for testing
let isShippingRequested = {
  type: ''
}
export const listener = function*( type, action ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const res = yield call( ajax, { type } );

    yield put( getActionDefinition( type, 'success' )( res.body ) );

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}


export default function*(){
  let serviceType = 'estimatedDeliveryDate';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );


}
