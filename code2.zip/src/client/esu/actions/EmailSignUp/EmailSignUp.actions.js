/**
 * EmailSignUp Actions
 *
 * This file defines the action types and action creators for 'ESU'
 **/


/**
 * ACTION TYPES
 */
export const types = {
  TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM: 'ESU::TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM',
  TOGGLE_SHOW_EMAIL_SIGN_UP_FORM: 'ESU::TOGGLE_SHOW_EMAIL_SIGN_UP_FORM',
  SET_BODY_STYLE_PADDING_BOTTOM: 'ESU::SET_BODY_STYLE_PADDING_BOTTOM',
  SET_STICKY_FOOTER_DISPLAY: 'ESU::SET_STICKY_FOOTER_DISPLAY',
  SET_ESU_FORM_GT_SCREEN_HEIGHT: 'ESU::SET_ESU_FORM_GT_SCREEN_HEIGHT',
  SET_ESU_CONTAINER_TRANSLATE_Y: 'ESU::SET_ESU_CONTAINER_TRANSLATE_Y',
  SET_ESU_MODEL_OPENED_FLAG: 'ESU::SET_ESU_MODEL_OPENED_FLAG',
  SET_ESU_MODEL_CLOSED_FLAG: 'ESU::SET_ESU_MODEL_CLOSED_FLAG',
  SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR: 'ESU::SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR'
}


/**
 * ACTIONS
 */
export const actions = {
  toggleEligibleEmailSignUpForm: ( data ) => ( { type: types.TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM, data } ),
  toggleShowEmailSignUpForm: ( data ) => ( { type: types.TOGGLE_SHOW_EMAIL_SIGN_UP_FORM, data } ),
  setBodyStylePaddingBottom: ( data ) => ( { type: types.SET_BODY_STYLE_PADDING_BOTTOM, data } ),
  setStickyFooterDisplay: ( data ) => ( { type: types.SET_STICKY_FOOTER_DISPLAY, data } ),
  setESUFormGTScreenHeight: ( data ) => ( { type: types.SET_ESU_FORM_GT_SCREEN_HEIGHT, data } ),
  setESUContainerTranslateY: ( data ) => ( { type: types.SET_ESU_CONTAINER_TRANSLATE_Y, data } ),
  setESUModelOpenedFlag: () => ( { type: types.SET_ESU_MODEL_OPENED_FLAG } ),
  setESUModelClosedFlag: () => ( { type: types.SET_ESU_MODEL_CLOSED_FLAG } ),
  setSubmittedEmailSignUpFormError: ( data ) => ( { type: types.SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR, data } )
}
