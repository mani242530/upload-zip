/**
 * Test for Footer actions
 */

import { types, actions } from './EmailSignUp.actions';
import isFunction from 'lodash/isFunction';

describe( 'ESU action types', () => {

  it( 'The action type TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM should exist', () => {
    expect( types.TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM ).toBe( 'ESU::TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM' );
  } );

  it( 'The action type TOGGLE_SHOW_EMAIL_SIGN_UP_FORM should exist', () => {
    expect( types.TOGGLE_SHOW_EMAIL_SIGN_UP_FORM ).toBe( 'ESU::TOGGLE_SHOW_EMAIL_SIGN_UP_FORM' );
  } );

  it( 'The action type SET_BODY_STYLE_PADDING_BOTTOM should exist', () => {
    expect( types.SET_BODY_STYLE_PADDING_BOTTOM ).toBe( 'ESU::SET_BODY_STYLE_PADDING_BOTTOM' );
  } );

  it( 'The action type SET_STICKY_FOOTER_DISPLAY should exist', () => {
    expect( types.SET_STICKY_FOOTER_DISPLAY ).toBe( 'ESU::SET_STICKY_FOOTER_DISPLAY' );
  } );

  it( 'The action type SET_ESU_FORM_GT_SCREEN_HEIGHT should exist', () => {
    expect( types.SET_ESU_FORM_GT_SCREEN_HEIGHT ).toBe( 'ESU::SET_ESU_FORM_GT_SCREEN_HEIGHT' );
  } );

  it( 'The action type SET_ESU_CONTAINER_TRANSLATE_Y should exist', () => {
    expect( types.SET_ESU_CONTAINER_TRANSLATE_Y ).toBe( 'ESU::SET_ESU_CONTAINER_TRANSLATE_Y' );
  } );

  it( 'The action type SET_ESU_MODEL_OPENED_FLAG should exist', () => {
    expect( types.SET_ESU_MODEL_OPENED_FLAG ).toBe( 'ESU::SET_ESU_MODEL_OPENED_FLAG' );
  } );

  it( 'The action type SET_ESU_MODEL_CLOSED_FLAG should exist', () => {
    expect( types.SET_ESU_MODEL_CLOSED_FLAG ).toBe( 'ESU::SET_ESU_MODEL_CLOSED_FLAG' );
  } );

  it( 'The action type SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR should exist', () => {
    expect( types.SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR ).toBe( 'ESU::SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR' );
  } );

  it( 'The action creator toggleEligibleEmailSignUpForm function should exist', () => {
    expect( isFunction( actions.toggleEligibleEmailSignUpForm ) ).toBe( true );
  } );

  it( 'The action creator toggleShowEmailSignUpForm function should exist', () => {
    expect( isFunction( actions.toggleShowEmailSignUpForm ) ).toBe( true );
  } );

  it( 'The action creator setBodyStylePaddingBottom function should exist', () => {
    expect( isFunction( actions.setBodyStylePaddingBottom ) ).toBe( true );
  } );

  it( 'The action creator setStickyFooterDisplay function should exist', () => {
    expect( isFunction( actions.setStickyFooterDisplay ) ).toBe( true );
  } );

  it( 'The action creator setESUFormGTScreenHeight function should exist', () => {
    expect( isFunction( actions.setESUFormGTScreenHeight ) ).toBe( true );
  } );

  it( 'The action creator setESUContainerTranslateY function should exist', () => {
    expect( isFunction( actions.setESUContainerTranslateY ) ).toBe( true );
  } );

  it( 'The action creator setESUModelOpenedFlag function should exist', () => {
    expect( isFunction( actions.setESUModelOpenedFlag ) ).toBe( true );
  } );

  it( 'The action creator setESUModelClosedFlag function should exist', () => {
    expect( isFunction( actions.setESUModelClosedFlag ) ).toBe( true );
  } );

  it( 'The action creator setSubmittedEmailSignUpFormError function should exist', () => {
    expect( isFunction( actions.setSubmittedEmailSignUpFormError ) ).toBe( true );
  } );

  it( 'The action creator toggleEligibleEmailSignUpForm function should return the proper action creator object', () => {
    var data = true;
    let creator = actions.toggleEligibleEmailSignUpForm( data );
    expect( creator ).toEqual( {
      type: types.TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM,
      data
    } )
  } );

  it( 'The action creator toggleShowEmailSignUpForm function should return the proper action creator object', () => {
    var data = true;
    let creator = actions.toggleShowEmailSignUpForm( data );
    expect( creator ).toEqual( {
      type: types.TOGGLE_SHOW_EMAIL_SIGN_UP_FORM,
      data
    } )
  } );

  it( 'The action creator setBodyStylePaddingBottom function should return the proper action creator object', () => {
    var data = 10;
    let creator = actions.setBodyStylePaddingBottom( data );
    expect( creator ).toEqual( {
      type: types.SET_BODY_STYLE_PADDING_BOTTOM,
      data
    } )
  } );

  it( 'The action creator setStickyFooterDisplay function should return the proper action creator object', () => {
    var data = true;
    let creator = actions.setStickyFooterDisplay( data );
    expect( creator ).toEqual( {
      type: types.SET_STICKY_FOOTER_DISPLAY,
      data
    } )
  } );

  it( 'The action creator setESUFormGTScreenHeight function should return the proper action creator object', () => {
    var data = true;
    let creator = actions.setESUFormGTScreenHeight( data );
    expect( creator ).toEqual( {
      type: types.SET_ESU_FORM_GT_SCREEN_HEIGHT,
      data
    } )
  } );

  it( 'The action creator setESUContainerTranslateY function should return the proper action creator object', () => {
    var data = 150;
    let creator = actions.setESUContainerTranslateY( data );
    expect( creator ).toEqual( {
      type: types.SET_ESU_CONTAINER_TRANSLATE_Y,
      data
    } )
  } );

  it( 'The action creator setESUModelOpenedFlag function should return the proper action creator object', () => {
    var data = 300;
    let creator = actions.setESUModelOpenedFlag( data );
    expect( creator ).toEqual( {
      type: types.SET_ESU_MODEL_OPENED_FLAG
    } )
  } );

  it( 'The action creator setESUModelClosedFlag function should return the proper action creator object', () => {
    var data = 300;
    let creator = actions.setESUModelClosedFlag( data );
    expect( creator ).toEqual( {
      type: types.SET_ESU_MODEL_CLOSED_FLAG
    } )
  } );

  it( 'The action creator setSubmittedEmailSignUpFormError function should return the proper action creator object', () => {
    var data = true;
    let creator = actions.setSubmittedEmailSignUpFormError( data );
    expect( creator ).toEqual( {
      type: types.SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR,
      data
    } )
  } );

} );

