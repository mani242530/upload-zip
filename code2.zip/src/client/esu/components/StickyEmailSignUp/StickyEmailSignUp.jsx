/**
 * StickyEmailSignUp
 */

import React, { Component } from 'react';
import './StickyEmailSignUp.css';

import { formatMessage } from 'shared/components/Global/Global';
import Cookies from 'js-cookie';
import { connect } from 'react-redux';
import { reduxForm, isValid } from 'redux-form';
import { isSecurePage } from 'utils/Domain/Domain';
import messages from './StickyEmailSignUp.messages';
import InputField from 'shared/components/InputField/InputField';
import Divider from 'shared/components/Divider/Divider';
import Button from 'shared/components/Button/Button';
import Close from 'shared/components/Icons/close';
import ChevronDownSVG from 'shared/components/Icons/chevrondown';
import isUndefined from 'lodash/isUndefined';
import omitBy from 'lodash/omitBy';
import isNil from 'lodash/isNil';
import classNames from 'classnames';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';



import {
  actions as esuActions
} from 'esu/actions/EmailSignUp/EmailSignUp.actions';
import {
  actions as analyticActions
} from 'shared/actions/Analytics/Analytics.actions';
import {
  requiredValidation,
  validate as validationMethod,
  validationKeys
} from 'utils/FormValidations/FormValidations';
import {
  getActionDefinition
} from 'shared/actions/Services/Services.actions';
import FormValidationMessages from 'utils/FormValidations/FormValidations.messages';

/**
 * Class
 * @extends React.Component
 */
class StickyEmailSignUp extends Component{

  /**
   * Create a StickyEmailSignUp
   */
  constructor( props ){
    super( props );

    this.container = undefined;
    this.headerContainer = undefined;
    this.setTimerToShowStickyFooter = undefined;

    this.cancelStickyForm = this.cancelStickyForm.bind( this );
    this.handleSubmitEmailSignUp = this.handleSubmitEmailSignUp.bind( this );
    this.toggleEmailSignUpForm = this.toggleEmailSignUpForm.bind( this );
    this.showStickyFooter = this.showStickyFooter.bind( this );
    this.hideStickyFooter = this.hideStickyFooter.bind( this );
    this.setHideStickyFooterCookie = this.setHideStickyFooterCookie.bind( this );
    this.checkEligibleEmailSignUpForm = this.checkEligibleEmailSignUpForm.bind( this );
    this.handleWindowResize = this.handleWindowResize.bind( this );
    this.handleSetAnimationStyle = this.handleSetAnimationStyle.bind( this );
    this.handleCheckScreenHeight = this.handleCheckScreenHeight.bind( this );
    this.handleStopTimerOrHideFooter = this.handleStopTimerOrHideFooter.bind( this );
    this.handleRestartTimer = this.handleRestartTimer.bind( this );
    this.handleSuccessEmailSignUp = this.handleSuccessEmailSignUp.bind( this );
  }

  componentDidUpdate( prevProps ){
    if( this.props.stickyEmailSignUp.isCheckEligibleEmailSignUpForm && !prevProps.stickyEmailSignUp.isCheckEligibleEmailSignUpForm ){
      this.checkEligibleEmailSignUpForm();
    }

    if( this.props.stickyEmailSignUp.isEligibleEmailSignUpForm && !prevProps.stickyEmailSignUp.isEligibleEmailSignUpForm ){
      this.showStickyFooter();
    }

    // Check isNewUserOptedIn flag status to display the success or failure view after successfully submitted the email signup form
    if( !isUndefined( this.props.stickyEmailSignUp.isNewUserOptedIn ) && this.props.stickyEmailSignUp.isEmailSignUpFormSubmitted && this.props.stickyEmailSignUp.isNewUserOptedIn !== prevProps.stickyEmailSignUp.isNewUserOptedIn ){
      this.handleSuccessEmailSignUp();
    }

    // Check any overlay / left nav opened or closed, based on the user action show/hide the email signup form
    if( this.props.stickyEmailSignUp.isAnyModalOpen !== prevProps.stickyEmailSignUp.isAnyModalOpen ){
      ( this.props.stickyEmailSignUp.isAnyModalOpen ) ? this.handleStopTimerOrHideFooter() : this.handleRestartTimer();
    }

    // Check isValidToAnimateEmailSignUpForm flag before tigger animation function
    // After cancalled or submitted the form, if any change in the screen height or translate Y Position
    // The ESU form is displayed again to user on the same session. To avoid this, checking the below condition
    // Should not render ESU form before the wait time when resize the window
    if( isUndefined( this.setTimerToShowStickyFooter ) && this.props.stickyEmailSignUp.isValidToAnimateEmailSignUpForm ){
      // Whenever ESU form is displayed and mobile device screen height is changed by switch between landscape & portrait
      // Check to set HTML overflow hidden, if the container height is greater than screen height in mobile device
      // So, user can able to scroll the ESU form in smaller devices
      // Check the screen width changes and the display the ESU form based on device width. It will be used in desktop bowser resize
      if( ( this.props.screenWidth !== prevProps.screenWidth ) || ( this.props.screenHeight !== prevProps.screenHeight ) ){
        this.handleWindowResize();
      }

      // Whenever ESU form animates translateYPosition props will be updated through reducer
      // Check to set HTML overflow hidden, if the container height is greater than screen height in mobile device
      // So, user can able to scroll the ESU form in smaller devices
      if( this.props.isMobileDevice && !isUndefined( this.props.stickyEmailSignUp.translateYPosition ) && this.props.stickyEmailSignUp.translateYPosition !== prevProps.stickyEmailSignUp.translateYPosition ){
        this.handleCheckScreenHeight( this.container.offsetHeight, this.props.screenHeight );
      }
    }
  }

  checkEligibleEmailSignUpForm(){
    let isRenderEmailSignUpForm = this.props.isMobileDevice ? this.props.switchData.switches.ultaEmailSignUpConfig.showOnMobile : this.props.switchData.switches.ultaEmailSignUpConfig.showOnDesktop;
    // Use same cookie for guest and login user, so the sticky footer will not display when the user in any state
    let isFormCancalledBefore = Cookies.get( 'isSTKCancalled' );
    let isFromPromoEmailLink = ( global.location.href.indexOf( 'RID' ) !== -1 );

    if( isRenderEmailSignUpForm && !isFromPromoEmailLink && isFormCancalledBefore !== 'true' ){
      this.props.toggleEligibleEmailSignUpForm( true );
    }
  }

  handleWindowResize(){
    this.handleCheckScreenHeight( this.container.offsetHeight, this.props.screenHeight );
    if( !this.props.stickyEmailSignUp.isShowEmailSignUpForm ){
      let data = {
        mode: 'initialRender',
        containerHeight: this.container.offsetHeight,
        mhcHeight: this.headerContainer.offsetHeight,
        isMobileDevice: this.props.isMobileDevice
      }
      this.handleSetAnimationStyle( data );
    }
  }

  handleSetAnimationStyle( data ){
    this.props.setESUContainerTranslateY( data );
  }

  handleCheckScreenHeight( containerHeight, screenHeight ){
    // Set HTML scroll hidden CSS only when ESU form fully displayed on the mobile screen
    if( this.props.stickyEmailSignUp.isShowEmailSignUpForm && containerHeight > screenHeight ){
      this.props.setESUFormGTScreenHeight( true );
    }
    else {
      this.props.setESUFormGTScreenHeight( false );
    }
  }

  handleStopTimerOrHideFooter(){
    // Check the timer started to show the sticky ESU form and clear the timer when any model / overlay / left nav opened
    if( !isUndefined( this.setTimerToShowStickyFooter ) ){
      clearTimeout( this.setTimerToShowStickyFooter );
    }

    // Hide the sticky ESU form when ESU form displayed on the screen adn any model / overlay / left nav opened
    if( this.props.stickyEmailSignUp.isValidToAnimateEmailSignUpForm ){
      this.hideStickyFooter( true );
    }
  }

  // when any model / overlay / left nav closed, check the Eligible to display Email SignUp Form and restart the timer
  handleRestartTimer(){
    const {
      isSignedIn,
      isEmailOptIn,
      config,
      stickyEmailSignUp
    } = this.props;

    if( !isEmailOptIn && !stickyEmailSignUp.sessionData.isStickyFooterDisplay ){
      let isRenderEmailSignUpForm = this.props.isMobileDevice ? this.props.switchData.switches.ultaEmailSignUpConfig.showOnMobile : this.props.switchData.switches.ultaEmailSignUpConfig.showOnDesktop;
      // Use same cookie for guest and login user, so the sticky footer will not display when the user in any state
      let isFormCancalledBefore = Cookies.get( 'isSTKCancalled' );
      let isFromPromoEmailLink = ( global.location.href.indexOf( 'RID' ) !== -1 );

      if( isRenderEmailSignUpForm && !isFromPromoEmailLink && isFormCancalledBefore !== 'true' ){
        this.props.toggleEligibleEmailSignUpForm( true );
        this.showStickyFooter();
      }
    }
  }

  showStickyFooter(){
    let bodyStyles = document.body.currentStyle || global.getComputedStyle( document.body );
    // TO FIX Footer Overlay issue in Safari browser changed margin bottom to padding bottom
    let bodyPaddingBottom = parseInt( bodyStyles.paddingBottom, 10 );
    this.props.setBodyStylePaddingBottom( bodyPaddingBottom );
    if( this.props.isMobileDevice ){
      document.body.style.paddingBottom = ( bodyPaddingBottom + this.headerContainer.offsetHeight ) + 'px';
    }
    else {
      document.body.style.paddingBottom = ( bodyPaddingBottom + this.container.offsetHeight ) + 'px';
    }

    let waitTimeDesktop = parseInt( this.props.switchData.switches.ultaEmailSignUpConfig.waitTimeSFDesktop, 10 ) * 1000;
    let waitTimeMobile = parseInt( this.props.switchData.switches.ultaEmailSignUpConfig.waitTimeSFMobile, 10 ) * 1000;

    this.setTimerToShowStickyFooter = setTimeout( () => {
      let data = {
        mode: 'initialRender',
        containerHeight: this.container.offsetHeight,
        mhcHeight: this.headerContainer.offsetHeight,
        isMobileDevice: this.props.isMobileDevice
      }
      this.handleSetAnimationStyle( data );
      // Need to send true to hide the sticky footer in the same session
      let isDisableOnSameSession = ( process.env.NODE_ENV === 'development' ) ? this.props.config.DEBUGGING.ESU.DISABLE_ON_SAME_SESSION : true;
      this.props.setStickyFooterDisplay( isDisableOnSameSession );
      // Reset the value to check in handleAnyModelOpenClose function
      this.setTimerToShowStickyFooter = undefined;
    }, this.props.isMobileDevice ? waitTimeMobile : waitTimeDesktop );
  }

  hideStickyFooter( hideForSession = false ){
    if( !hideForSession ){
      this.setHideStickyFooterCookie();
    }
    // TO FIX Footer Overlay issue in Safari browser changed margin bottom to padding bottom
    document.body.style.paddingBottom = this.props.stickyEmailSignUp.bodyStylePaddingBottom + 'px';
    // Reset the reducer back to 0
    this.props.setBodyStylePaddingBottom( 0 );
    let data = {
      mode: 'hide'
    }
    this.handleSetAnimationStyle( data );
  }

  cancelStickyForm(){
    // To remove BLOCK_PAGE_SCROLL class from HTML Tag, when close the ESU FORM
    this.props.toggleShowEmailSignUpForm( false );
    this.props.stickyEmailSignUp.isSubmittedEmailSignUpFormError ? this.hideStickyFooter( true ) : this.hideStickyFooter() ;
  }

  toggleEmailSignUpForm(){
    // To get full container height of the ESU Form element in android mobiles used scrollHeight
    let data = {
      mode: 'displayForm',
      containerHeight: this.container.scrollHeight,
      mhcHeight: this.headerContainer.offsetHeight
    }
    this.handleSetAnimationStyle( data );
    this.props.toggleShowEmailSignUpForm( !this.props.stickyEmailSignUp.isShowEmailSignUpForm );
  }

  // Function to submit the ESU form to backend service
  // Form submitting logic will be added as part sprint 2 story ECOMM-31409
  handleSubmitEmailSignUp( values ){
    this.props.submitEmailSignUp( values );
  }

  // After successful submission form values, need to display the success message to user and hide after for X secs based on the config values
  handleSuccessEmailSignUp(){
    let confMsgDismissTime = parseInt( this.props.switchData.switches.ultaEmailSignUpConfig.confMsgDismissTime, 10 ) * 1000;
    setTimeout( () => {
      let data = {
        mode: 'hide'
      }
      this.handleSetAnimationStyle( data );
      // Don't set sticky ESU form Cookie when get error message from subscribe services
      // So, user can try again to submit the details in the next session
      ( !this.props.stickyEmailSignUp.messages ) ? this.setHideStickyFooterCookie() : null;
      // To remove BLOCK_PAGE_SCROLL class from HTML Tag, when close the ESU FORM
      this.props.toggleShowEmailSignUpForm( false );
    }, confMsgDismissTime );
  }

  setHideStickyFooterCookie(){
    // Use same cookie for guest and login user, so the sticky footer will not display when the user in any state
    Cookies.set( 'isSTKCancalled', 'true', {
      expires: parseInt( ( this.props.isSignedIn ) ? this.props.switchData.switches.ultaEmailSignUpConfig.regUserWaitPeriod : this.props.switchData.switches.ultaEmailSignUpConfig.guestUserWaitPeriod, 10 ),
      path: '/',
      secure: isSecurePage()
    } );
  }

  /**
   * Renders the StickyEmailSignUp component
   */
  render(){

    const {
      handleSubmit,
      stickyEmailSignUp,
      profileInfo
    } = this.props;

    const {
      isShowEmailSignUpForm,
      isShowCloseSVGIcon,
      isEmailSignUpFormSubmitted,
      isSubmittedEmailSignUpFormError,
      isSubscribeServiceFailure
    } = stickyEmailSignUp;

    const {
      sessionData
    } = this.props.stickyEmailSignUp.sessionData;

    return (
      <div className='StickyEmailSignUp'>
        { ( () => {
          if( stickyEmailSignUp.isEligibleEmailSignUpForm ){
            return (
              <div
                className={
                  classNames(
                    'StickyEmailSignUp--sticky StickyEmailSignUp--transition', {
                      'StickyEmailSignUp--setOverlay': stickyEmailSignUp.isESUFormHeightGTScreenHeight
                    }
                  )
                }
                ref={ elem => this.container = elem }
                aria-live='assertive'
                { ...( !isUndefined( stickyEmailSignUp.translateYPosition ) && { style: { transform: `translateY(${stickyEmailSignUp.translateYPosition}px)` } } ) }
              >
                <div className='StickyEmailSignUp__toggleIcon'>
                  <Button
                    inputTag='button'
                    btnType='button'
                    btnOption='no-style'
                    ariaLabel={ isShowCloseSVGIcon ? formatMessage( messages.cancelText ) : formatMessage( messages.chevronText ) }
                    title={ isShowCloseSVGIcon ? formatMessage( messages.cancelText ) : formatMessage( messages.chevronText ) }
                    clickEventHandler={ e => {
                      isShowCloseSVGIcon ? this.cancelStickyForm() : this.toggleEmailSignUpForm();
                    } }
                  >
                    <span>
                      {
                        // close display
                        isShowCloseSVGIcon &&
                          <Close />
                      }
                      {
                        // chevron display
                        !isShowCloseSVGIcon &&
                          <ChevronDownSVG />
                      }
                    </span>
                  </Button>
                </div>

                {
                  isEmailSignUpFormSubmitted &&
                  <div className='StickyEmailSignUp__successMessage text-center'>
                    <h2>{ ( stickyEmailSignUp.isNewUserOptedIn ) ? formatMessage( messages.youreInText ) : formatMessage( messages.weKnowYouText ) }</h2>
                    <Divider dividerType={ 'gray' } />
                    <p>{ ( stickyEmailSignUp.isNewUserOptedIn ) ? formatMessage( messages.successText ) : formatMessage( messages.existsInListText ) }</p>
                  </div>
                }

                {
                  !isEmailSignUpFormSubmitted && isSubmittedEmailSignUpFormError &&
                    <div className='StickyEmailSignUp__errorMessage text-center'>
                      {
                        // Display the Error messages when subscribe service getting failed from Services response
                        !isSubscribeServiceFailure && stickyEmailSignUp.messages && stickyEmailSignUp.messages.map( ( message, index ) => {
                          return (
                            <ResponseMessages
                              messageType={ message.messageType }
                              message={ message.messageDesc }
                              key={ index }
                            />
                          )
                        } )
                      }

                      {
                        // Display the Error messages when subscribe service getting failed due to some netwok issues
                        isSubscribeServiceFailure &&
                          <ResponseMessages
                            messageType='Error'
                            message={ formatMessage( messages.errorText ) }
                          />
                      }

                      <Button
                        className='StickyEmailSignUp__tryagain'
                        inputTag='button'
                        btnType='button'
                        btnOption='single'
                        btnSize='lg'
                        btnOutLine={ true }
                        title={ formatMessage( messages.tryAgainText ) }
                        clickEventHandler={ () => {
                          // function is used to display ESU form to re-submit the form
                          this.props.setSubmittedEmailSignUpFormError( false );
                        } }
                      >
                        <div className='StickyEmailSignUp__tryagain--msg'>
                          { formatMessage( messages.tryAgainText ) }
                        </div>
                      </Button>
                    </div>
                }

                {
                  !isEmailSignUpFormSubmitted && !isSubmittedEmailSignUpFormError &&
                    <div className='StickyEmailSignUp__content StickyEmailSignUp--row'>
                      <div
                        ref={ elem => this.headerContainer = elem }
                        className='StickyEmailSignUp__header'
                        onClick={
                          ()=> {
                            if( this.props.isMobileDevice ){
                              this.toggleEmailSignUpForm();
                            }
                          }
                        }
                      >
                        <h3>{ formatMessage( messages.headerText ) }</h3>
                        <p
                          className={
                            classNames(
                              {
                                // Added extraPadding is used to calculate initial mobile render to match with visual
                                'StickyEmailSignUp__header--extraPadding': this.props.isMobileDevice && !isShowEmailSignUpForm
                              }
                            )
                          }
                        >
                          <span>{ formatMessage( messages.signUpNowText ) }</span>
                          {
                            // desktop  display
                            !this.props.isMobileDevice &&
                              <span>{ formatMessage( messages.signUpOffersText ) }</span>
                          }
                          {
                            // mobile display
                            this.props.isMobileDevice && isShowEmailSignUpForm &&
                              <span>{ formatMessage( messages.signUpOffersText ) }</span>
                          }
                        </p>
                      </div>

                      <div
                        className={
                          classNames(
                            'StickyEmailSignUp__form', {
                              'StickyEmailSignUp__form--showAnimateForm': isShowEmailSignUpForm
                            }
                          )
                        }
                        id='StickyEmailSignUpForm'
                      >
                        <form
                          onSubmit={ handleSubmit( this.handleSubmitEmailSignUp ) }
                        >
                          <div className='StickyEmailSignUp__firstName StickyEmailSignUp__inputColumn'>
                            <InputField
                              label={ formatMessage( messages.FirstName ) }
                              type='text'
                              name='firstName'
                              autoComplete='given-name'
                              maxLength={ 30 }
                              { ...( profileInfo && { value: profileInfo.firstName } ) }
                            />
                          </div>
                          <div className='StickyEmailSignUp__lastName StickyEmailSignUp__inputColumn'>
                            <InputField
                              label={ formatMessage( messages.LastName ) }
                              type='text'
                              name='lastName'
                              autoComplete='family-name'
                              maxLength={ 30 }
                              { ...( profileInfo && { value: profileInfo.lastName } ) }
                            />
                          </div>
                          <div className='StickyEmailSignUp__emailAddress StickyEmailSignUp__inputColumn'>
                            <InputField
                              label={ formatMessage( messages.emailaddress ) }
                              type='email'
                              name='emailaddress'
                              autoComplete='email'
                              maxLength={ 100 }
                              { ...( profileInfo && { value: profileInfo.email } ) }
                            />
                          </div>
                          <div className='StickyEmailSignUp__submit StickyEmailSignUp__inputColumn'>
                            <Button
                              showLoader={ stickyEmailSignUp.esuFormSubmitSpinner }
                              className='StickyEmailSignUp__submit--signup'
                              inputTag='button'
                              btnType='submit'
                              btnOption='single'
                              btnSize='lg'
                              btnOutLine={ true }
                            >
                              <div className='StickyEmailSignUp__submit--signup--msg'>
                                { formatMessage( messages.signUpText ) }
                              </div>
                            </Button>
                          </div>
                        </form>
                      </div>
                    </div>
                }
              </div>
            )
          }
        } )() }
      </div>
    );
  }
}

export const validate = ( values, props ) =>{
  const errors = {};
  let requiredFields = [];

  requiredFields = ['firstName', 'lastName', 'emailaddress'];

  requiredFields.map(
    field =>{
      if( !values[field] ){
        errors[field] = requiredValidation( values[field] );
      }
    }
  );

  if( values['firstName'] ){
    errors['firstName'] = validationMethod( values['firstName'], validationKeys.firstValidateName, FormValidationMessages.validateFirstName );
  }

  if( values['lastName'] ){
    errors['lastName'] = validationMethod( values['lastName'], validationKeys.lastValidateName, FormValidationMessages.validateLastName );
  }

  if( values['emailaddress'] ){
    errors['emailaddress'] = validationMethod( values['emailaddress'], validationKeys.validateEmail, FormValidationMessages.invalidEmail );
  }

  return errors;
}

export const onSubmitFail = ( errors, dispatch, submitError, props ) => {
  let analyticErrors = [];
  analyticErrors.push( { 'StickyEmailSignUpFormErrors':  omitBy( errors, isNil ) } );

  let evt = {
    'name': 'trackErrorDisplayed',
    'data': analyticErrors
  }
  dispatch( analyticActions.triggerAnalyticsEvent( evt ) );
}

export const mapStateToProps = ( state ) => {
  return {
    ...state.esu,
    ...state.user,
    ...state.global
  };
}

export const mapDispatchToProps = ( dispatch ) => {
  return {
    toggleEligibleEmailSignUpForm: ( data ) => {
      dispatch( esuActions.toggleEligibleEmailSignUpForm( data ) );
    },
    toggleShowEmailSignUpForm: ( data ) => {
      dispatch( esuActions.toggleShowEmailSignUpForm( data ) );
    },
    setBodyStylePaddingBottom: ( data ) => {
      dispatch( esuActions.setBodyStylePaddingBottom( data ) );
    },
    setStickyFooterDisplay: ( data ) => {
      dispatch( esuActions.setStickyFooterDisplay( data ) );
    },
    setESUFormGTScreenHeight: ( data ) => {
      dispatch( esuActions.setESUFormGTScreenHeight( data ) );
    },
    setESUContainerTranslateY: ( data ) => {
      dispatch( esuActions.setESUContainerTranslateY( data ) );
    },
    setSubmittedEmailSignUpFormError: ( data ) => {
      dispatch( esuActions.setSubmittedEmailSignUpFormError( data ) );
    },
    submitEmailSignUp: ( data ) => {
      dispatch( getActionDefinition( 'subscribe', 'requested' )( data ) );
    }
  };
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return reduxForm( {
    form: 'StickyEmailSignUpForm',
    validate,
    onSubmitFail
  } )( connect( mapStateToProps, mapDispatchToProps )( StickyEmailSignUp ) );
};

export default connectFunction( mapStateToProps, mapDispatchToProps );
