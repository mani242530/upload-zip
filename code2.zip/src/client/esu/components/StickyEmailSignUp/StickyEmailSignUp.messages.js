/*
 * StickyEmailSignUp Messages
 *
 * This contains all the text for the StickyEmailSignUp component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  headerText: {
    id: 'i18n.StickyEmailSignUp.headerText',
    defaultMessage: 'DON\’T MISS THE FUN!'
  },
  signUpNowText: {
    id: 'i18n.StickyEmailSignUp.signUpNowText',
    defaultMessage: 'Sign up for emails now.'
  },
  signUpOffersText: {
    id: 'i18n.StickyEmailSignUp.signUpOffersText',
    defaultMessage: ' You\'ll be the first to know about our latest sales, new arrivals & special offers.'
  },
  cancelText: {
    id: 'i18n.StickyEmailSignUp.cancelText',
    defaultMessage: 'Close sticky email sign-up form'
  },
  chevronText: {
    id: 'i18n.StickyEmailSignUp.chevronText',
    defaultMessage: 'Hide sticky email sign-up form'
  },
  FirstName: {
    id: 'i18n.StickyEmailSignUp.FirstName',
    defaultMessage: 'First Name'
  },
  LastName: {
    id: 'i18n.StickyEmailSignUp.LastName',
    defaultMessage: 'Last Name'
  },
  emailaddress: {
    id: 'i18n.StickyEmailSignUp.emailaddress',
    defaultMessage: 'Email Address'
  },
  signUpText: {
    id: 'i18n.StickyEmailSignUp.signUpText',
    defaultMessage: 'SIGN UP'
  },
  tryAgainText: {
    id: 'i18n.StickyEmailSignUp.tryAgainText',
    defaultMessage: 'TRY AGAIN'
  },
  youreInText: {
    id: 'i18n.StickyEmailSignUp.youreInText',
    defaultMessage: 'YOU\'RE IN!'
  },
  successText: {
    id: 'i18n.StickyEmailSignUp.successText',
    defaultMessage: 'We\'ll send you a welcome message — so keep a lookout.'
  },
  errorText: {
    id: 'i18n.StickyEmailSignUp.errorText',
    defaultMessage: 'Unable to process request at this time'
  },
  weKnowYouText: {
    id: 'i18n.StickyEmailSignUp.weKnowYouText',
    defaultMessage: 'WE KNOW YOU!'
  },
  existsInListText: {
    id: 'i18n.StickyEmailSignUp.existsInListText',
    defaultMessage: 'Your email is already on our list. We\'ll keep the good stuff coming  your way.'
  }
} );
