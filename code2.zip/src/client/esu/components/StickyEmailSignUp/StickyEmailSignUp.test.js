import React from 'react';
import ReactDOM from 'react-dom';
import StickyEmailSignUp, { connectFunction, mapStateToProps, mapDispatchToProps } from './StickyEmailSignUp';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { Provider } from 'react-redux';
import Cookies from 'js-cookie';
import { isSecurePage } from 'utils/Domain/Domain';
import configureStore from 'esu/esu.store';
import CONFIG from 'esu/esu.config';
import messages from './StickyEmailSignUp.messages';
import device from 'utils/DeviceDetection/deviceDetection';
import {
  actions as esuActions
} from 'esu/actions/EmailSignUp/EmailSignUp.actions';
import {
  getActionDefinition
} from 'shared/actions/Services/Services.actions';



const dispatch = jest.fn();
var placeholder = document.createElement( 'div' );
placeholder.id = 'StickyEmailSignUp';
placeholder.height = 100;
document.getElementById = jest.fn().mockReturnValue( placeholder );

var placeholder1 = document.createElement( 'div' );
placeholder1.className = 'HamburgerBtn';
document.getElementsByClassName = jest.fn().mockReturnValue( placeholder1 );

let mockJestFn = jest.fn();
let mapDispatchToPropsMock = ( dispatch ) =>{
  return {
    config: CONFIG,
    toggleEligibleEmailSignUpForm: mockJestFn,
    toggleShowEmailSignUpForm: mockJestFn,
    setBodyStylePaddingBottom: mockJestFn,
    setStickyFooterDisplay: mockJestFn,
    setESUFormGTScreenHeight: mockJestFn,
    setESUContainerTranslateY: mockJestFn,
    setSubmittedEmailSignUpFormError: mockJestFn,
    submitEmailSignUp: mockJestFn
  }
};

let props = {
  isSignedIn: false,
  toggleEligibleEmailSignUpForm: mockJestFn,
  toggleShowEmailSignUpForm: mockJestFn,
  stickyEmailSignUp: {
    bodyStylePaddingBottom: 0,
    isCheckEligibleEmailSignUpForm: false,
    isEligibleEmailSignUpForm: false,
    isShowEmailSignUpForm: false,
    isEmailSignUpFormSubmitted: false,
    isESUFormHeightGTScreenHeight: false,
    isValidToAnimateEmailSignUpForm: false,
    translateYPosition: 100,
    successContainerHeight: 100,
    isSubmittedEmailSignUpFormError: false,
    isShowCloseSVGIcon: true
  },
  switchData: {
    switches: {
      ultaEmailSignUpConfig: {
        confMsgDismissTime: 5,
        guestUserWaitPeriod: 30,
        showOnMobile: true,
        regUserWaitPeriod: 90,
        showOnDesktop: true,
        waitTimeSFMobile: 0,
        waitTimeSFDesktop: 0
      }
    }
  },
  config: CONFIG
};

let props1 = {
  isSignedIn: undefined,
  stickyEmailSignUp: {
    isCheckEligibleEmailSignUpForm: false,
    isEligibleEmailSignUpForm: false
  },
  config: CONFIG
};


describe( '<StickyEmailSignUp in Desktop with guest flow />', () => {

  let store = configureStore( {}, CONFIG );
  store.getState().user = {
    isSignedIn: false
  }
  store.getState().global = {
    isMobileDevice: false,
    screenHeight: 100,
    screenWidth: 100
  }
  store.getState().esu = {
    stickyEmailSignUp: {
      isCheckEligibleEmailSignUpForm: true,
      isEligibleEmailSignUpForm: true,
      sessionData: {
        isStickyFooterDisplay: false
      }
    }
  }

  let StickyEmailSignUpMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
  let component = mountWithIntl(
    <Provider store={ store }>
      <StickyEmailSignUpMock { ...props } config={ CONFIG } />
    </Provider>
  );

  component.find( 'StickyEmailSignUp' ).instance().componentDidUpdate( props1 );

  it( 'renders without crashing', () => {
    let node = component.find( 'StickyEmailSignUp' ).instance();
    node.addEventToHideEmailSignUpForm = mockJestFn;
    node.handleSetAnimationStyle = mockJestFn;
    node.checkEligibleEmailSignUpForm = mockJestFn;
    node.showStickyFooter = mockJestFn;
    expect( component.find( 'StickyEmailSignUp' ).length ).toBe( 1 );
    expect( component.find( 'StickyEmailSignUp' ).instance().props.setBodyStylePaddingBottom ).toBeCalled();
    jest.useFakeTimers();
    jest.runAllTimers();

    node.addEventToHideEmailSignUpForm();
    node.hideStickyFooter();
    expect( component.find( 'StickyEmailSignUp' ).instance().props.setBodyStylePaddingBottom ).toBeCalled();
    expect( component.find( 'StickyEmailSignUp' ).instance().props.toggleEligibleEmailSignUpForm ).toBeCalled();

    node.handleWindowResize = mockJestFn;
    expect( component.find( 'StickyEmailSignUp' ).at( 0 ).props().setESUFormGTScreenHeight ).toBeCalled();

  } );

  it( 'handles Button click event to close the sticky footer', () => {
    let node = component.find( 'StickyEmailSignUp' );
    node.hideStickyFooter = mockJestFn;

    expect( component.find( 'StickyEmailSignUp button.btn-no-style' ).length ).toBe( 1 );
    component.find( 'StickyEmailSignUp button.btn-no-style' ).at( 0 ).simulate( 'click' );
    expect( node.hideStickyFooter ).toBeCalled();
  } );

  it( 'renders Field components', () => {
    expect( component.find( '.StickyEmailSignUp' ).find( 'InputField' ).length ).toBe( 3 );
    expect( component.find( '.StickyEmailSignUp' ).find( 'Button button.StickyEmailSignUp__submit--signup' ).length ).toBe( 1 );
  } );

  it( 'displays label message for the input boxes', () => {
    expect( component.find( '.StickyEmailSignUp__firstName' ).text() ).toBe( messages.FirstName.defaultMessage );
    expect( component.find( '.StickyEmailSignUp__lastName' ).text() ).toBe( messages.LastName.defaultMessage );
    expect( component.find( '.StickyEmailSignUp__emailAddress' ).text() ).toBe( messages.emailaddress.defaultMessage );
    expect( component.find( '.StickyEmailSignUp__submit' ).text() ).toBe( messages.signUpText.defaultMessage );
  } );

  it( 'Submit the sticky email signup form with errors fields', () => {
    component.onSubmitFail = mockJestFn;
    component.find( 'StickyEmailSignUp' ).find( 'form' ).simulate( 'submit' );
    expect( component.find( '.ResponseMessages' ).length ).toBe( 3 );
  } );

  it( 'Submit the sticky email signup form without errors fields', () => {
    store.getState().form.StickyEmailSignUpForm = {
      values: {
        firstName: 'Test',
        lastName: 'Test',
        emailaddress: 'test.ccr@testebiz.com'
      }
    }

    let component2 = mountWithIntl(
      <Provider store={ store }>
        <StickyEmailSignUpMock
          { ...props }
          handleSubmit={ mockJestFn }
        />
      </Provider>
    );

    component2.find( 'StickyEmailSignUp' ).find( 'form' ).simulate( 'submit' );
    expect( component2.find( '.ResponseMessages' ).length ).toBe( 0 );
    expect( component2.find( 'StickyEmailSignUp' ).at( 0 ).props().handleSubmit ).toBeCalled();

    component2.find( 'StickyEmailSignUp' ).instance().handleSubmitEmailSignUp();
    expect( component2.find( 'StickyEmailSignUp' ).instance().props.submitEmailSignUp ).toBeCalled();

  } );

  it( 'Success after Submit the sticky email signup form', () => {

    let props3 = {
      isSignedIn: undefined,
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: false,
        isEligibleEmailSignUpForm: true,
        isEmailSignUpFormSubmitted: true,
        isNewUserOptedIn: true
      },
      config: CONFIG
    };

    store.getState().esu = {
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: true,
        isEligibleEmailSignUpForm: true,
        isEmailSignUpFormSubmitted: true,
        isNewUserOptedIn: true,
        sessionData: {
          isStickyFooterDisplay: false
        }
      }
    }

    let component3 = mountWithIntl(
      <Provider store={ store }>
        <StickyEmailSignUpMock
          { ...props }
          handleSubmit={ mockJestFn }
        />
      </Provider>
    );

    component3.find( 'StickyEmailSignUp' ).instance().componentDidUpdate( props3 );
    let node = component3.find( 'StickyEmailSignUp' ).instance();
    node.handleSuccessEmailSignUp = mockJestFn;
    node.setHideStickyFooterCookie = mockJestFn;
    expect( component3.find( '.StickyEmailSignUp__successMessage h2' ).text() ).toBe( messages.youreInText.defaultMessage );
    expect( component3.find( '.StickyEmailSignUp__successMessage p' ).text() ).toBe( messages.successText.defaultMessage );

    expect( node.handleSuccessEmailSignUp ).toBeCalled();
    jest.useFakeTimers();
    jest.runAllTimers();
    expect( node.setHideStickyFooterCookie ).toBeCalled();

  } );

  it( 'Failure after Submit the sticky email signup form', () => {

    let props3 = {
      isSignedIn: undefined,
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: true,
        isEligibleEmailSignUpForm: true,
        isEmailSignUpFormSubmitted: false,
        isNewUserOptedIn: false,
        messages: [
          {
            messageKey: 'emailSignupFailure',
            messageType: 'Error',
            messageDesc: 'Unable to process request at this time'
          }
        ]
      },
      config: CONFIG
    };

    store.getState().esu = {
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: true,
        isEligibleEmailSignUpForm: true,
        isEmailSignUpFormSubmitted: false,
        isSubmittedEmailSignUpFormError: true,
        isSubscribeServiceFailure: false,
        isNewUserOptedIn: false,
        messages: [
          {
            messageKey: 'emailSignupFailure',
            messageType: 'Error',
            messageDesc: 'Unable to process request at this time'
          }
        ],
        sessionData: {
          isStickyFooterDisplay: false
        }
      }
    }

    let component3 = mountWithIntl(
      <Provider store={ store }>
        <StickyEmailSignUpMock
          { ...props }
          handleSubmit={ mockJestFn }
        />
      </Provider>
    );

    component3.find( 'StickyEmailSignUp' ).instance().componentDidUpdate( props3 );
    expect( component3.find( '.StickyEmailSignUp__errorMessage .ResponseMessages' ).text() ).toBe( props3.stickyEmailSignUp.messages[0].messageDesc );
    expect( component3.find( '.StickyEmailSignUp__errorMessage button' ).length ).toBe( 1 );
    expect( component3.find( '.StickyEmailSignUp__errorMessage button' ).text() ).toBe( messages.tryAgainText.defaultMessage );

  } );

  it( 'Check try again button works after Failure Submit the sticky email signup form', () => {

    store.getState().esu = {
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: true,
        isEligibleEmailSignUpForm: true,
        isEmailSignUpFormSubmitted: false,
        isSubmittedEmailSignUpFormError: true,
        isSubscribeServiceFailure: false,
        isNewUserOptedIn: false,
        messages: [
          {
            messageKey: 'emailSignupFailure',
            messageType: 'Error',
            messageDesc: 'Unable to process request at this time'
          }
        ],
        sessionData: {
          isStickyFooterDisplay: false
        }
      }
    }

    let component3 = mountWithIntl(
      <Provider store={ store }>
        <StickyEmailSignUpMock { ...props } />
      </Provider>
    );

    component3.find( '.StickyEmailSignUp__errorMessage button' ).simulate( 'submit' );
    expect( component3.find( 'StickyEmailSignUp' ).instance().props.setSubmittedEmailSignUpFormError ).toBeCalled();

  } );

  it( 'Check Network Failure while Submitting the sticky email signup form', () => {

    store.getState().esu = {
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: true,
        isEligibleEmailSignUpForm: true,
        isEmailSignUpFormSubmitted: false,
        isSubmittedEmailSignUpFormError: true,
        isSubscribeServiceFailure: true,
        sessionData: {
          isStickyFooterDisplay: false
        }
      }
    }

    let component3 = mountWithIntl(
      <Provider store={ store }>
        <StickyEmailSignUpMock { ...props } />
      </Provider>
    );

    expect( component3.find( '.StickyEmailSignUp__errorMessage .ResponseMessages' ).text() ).toBe( messages.errorText.defaultMessage );
    expect( component3.find( '.StickyEmailSignUp__errorMessage button' ).length ).toBe( 1 );
    expect( component3.find( '.StickyEmailSignUp__errorMessage button' ).text() ).toBe( messages.tryAgainText.defaultMessage );

  } );

  it( 'check handleSuccessEmailSignUp class function to be called', () => {
    store.getState().esu = {
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: true,
        isEligibleEmailSignUpForm: true,
        isSubmittedEmailSignUpFormError: true,
        sessionData: {
          isStickyFooterDisplay: false
        }
      }
    }

    let component4 = mountWithIntl(
      <Provider store={ store }>
        <StickyEmailSignUpMock { ...props } />
      </Provider>
    );

    let node = component4.find( 'StickyEmailSignUp' ).instance();
    node.handleSetAnimationStyle = mockJestFn;
    node.handleSuccessEmailSignUp();
    jest.useFakeTimers();
    jest.runAllTimers();
    expect( node.handleSetAnimationStyle ).toBeCalled();
    expect( node.props.toggleShowEmailSignUpForm ).toBeCalled();

  } );

  it( 'should not render sticky footer emailup form when showOnDesktop flag false', () => {
    let props4 = {
      ...props,
      switchData: {
        switches: {
          ultaEmailSignUpConfig: {
            ...props.switchData.switches.ultaEmailSignUpConfig,
            showOnDesktop: false
          }
        }
      }
    };

    store.getState().esu = {
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: true,
        isEligibleEmailSignUpForm: false,
        sessionData: {
          isStickyFooterDisplay: false
        }
      }
    }

    let component4 = mountWithIntl(
      <Provider store={ store }>
        <StickyEmailSignUpMock { ...props4 } />
      </Provider>
    );

    component4.find( 'StickyEmailSignUp' ).instance().componentDidUpdate( props1 );
    expect( component4.find( '.StickyEmailSignUp--sticky' ).length ).toBe( 0 );
  } );

  it( 'check cancelStickyForm class function to be called', () => {
    store.getState().esu = {
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: true,
        isEligibleEmailSignUpForm: true,
        isSubmittedEmailSignUpFormError: true,
        sessionData: {
          isStickyFooterDisplay: false
        }
      }
    }

    let component4 = mountWithIntl(
      <Provider store={ store }>
        <StickyEmailSignUpMock { ...props } />
      </Provider>
    );

    let node = component4.find( 'StickyEmailSignUp' ).instance();
    node.hideStickyFooter = mockJestFn;
    node.handleSetAnimationStyle = mockJestFn;
    node.cancelStickyForm();
    expect( node.props.toggleShowEmailSignUpForm ).toBeCalled();
    expect( node.hideStickyFooter ).toBeCalled();

  } );

  it( 'Should not render ESU form when isSTKCancalled cookie available', () => {

    let date = new Date();
    date.setDate( date.getDate() + 1 ); // add a day
    Cookies.set( 'isSTKCancalled', 'true', {
      expires: date,
      path: '/',
      secure: isSecurePage()
    } );

    store.getState().esu = {
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: false,
        isEligibleEmailSignUpForm: false,
        sessionData: {
          isStickyFooterDisplay: false
        }
      }
    }

    let component4 = mountWithIntl(
      <Provider store={ store }>
        <StickyEmailSignUpMock { ...props } />
      </Provider>
    );

    expect( component4.find( 'StickyEmailSignUp .StickyEmailSignUp--sticky' ).length ).toBe( 0 );

  } );

  it( 'mapDispatchToProps should dispatch the proper action', () => {
    const mdp = mapDispatchToProps( dispatch );
    mdp.toggleEligibleEmailSignUpForm( true );
    mdp.toggleShowEmailSignUpForm( true );
    mdp.setBodyStylePaddingBottom( 10 );
    mdp.setStickyFooterDisplay( true );
    mdp.setESUFormGTScreenHeight( true );
    mdp.setESUContainerTranslateY( true );
    mdp.setSubmittedEmailSignUpFormError( true );
    mdp.submitEmailSignUp( true );

    expect( dispatch ).toHaveBeenCalledWith( esuActions.toggleEligibleEmailSignUpForm( true ) );
    expect( dispatch ).toHaveBeenCalledWith( esuActions.toggleShowEmailSignUpForm( true ) );
    expect( dispatch ).toHaveBeenCalledWith( esuActions.setBodyStylePaddingBottom( 10 ) );
    expect( dispatch ).toHaveBeenCalledWith( esuActions.setStickyFooterDisplay( true ) );
    expect( dispatch ).toHaveBeenCalledWith( esuActions.setESUFormGTScreenHeight( true ) );
    expect( dispatch ).toHaveBeenCalledWith( esuActions.setESUContainerTranslateY( true ) );
    expect( dispatch ).toHaveBeenCalledWith( esuActions.setSubmittedEmailSignUpFormError( true ) );
    expect( dispatch ).toHaveBeenCalledWith( getActionDefinition( 'subscribe', 'requested' )( true ) );
  } );


  describe( '<StickyEmailSignUp in Mobile Device with logged in flow />', () => {

    let store1 = configureStore( {}, CONFIG );
    store1.getState().user = {
      isSignedIn: true,
      profileInfo: {
        firstName: 'Test First',
        lastName: 'Test Last',
        email: 'testuser@ulta.com'
      }
    }
    store1.getState().global = {
      isMobileDevice: true,
      switchData: {
        switches: {
          ultaEmailSignUpConfig: {
            confMsgDismissTime: 5,
            guestUserWaitPeriod: 30,
            showOnMobile: true,
            regUserWaitPeriod: 90,
            showOnDesktop: true,
            waitTimeSFMobile: 0,
            waitTimeSFDesktop: 0
          }
        }
      }
    }
    store1.getState().esu = {
      stickyEmailSignUp: {
        isCheckEligibleEmailSignUpForm: true,
        isEligibleEmailSignUpForm: true,
        isValidToAnimateEmailSignUpForm: true,
        translateYPosition: 0,
        isAnyModalOpen: false,
        sessionData: {
          isStickyFooterDisplay: false
        }
      }
    }

    let StickyEmailSignUpMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    let component = mountWithIntl(
      <Provider store={ store1 }>
        <StickyEmailSignUpMock { ...props } />
      </Provider>
    );
    component.find( 'StickyEmailSignUp' ).instance().componentDidUpdate( props1 );

    it( 'renders without crashing', () => {
      let node = component.find( 'StickyEmailSignUp' ).instance();
      node.addEventToHideEmailSignUpForm = mockJestFn;
      node.handleSetAnimationStyle = mockJestFn;
      node.checkEligibleEmailSignUpForm = mockJestFn;
      node.showStickyFooter = mockJestFn;
      expect( component.find( 'StickyEmailSignUp' ).length ).toBe( 1 );
      expect( component.find( 'StickyEmailSignUp' ).instance().props.setBodyStylePaddingBottom ).toBeCalled();
      jest.useFakeTimers();
      jest.runAllTimers();
      expect( component.find( 'StickyEmailSignUp' ).at( 0 ).props().setStickyFooterDisplay ).toBeCalled();

      node.addEventToHideEmailSignUpForm();
      node.hideStickyFooter();
      expect( component.find( 'StickyEmailSignUp' ).instance().props.setBodyStylePaddingBottom ).toBeCalled();
      expect( component.find( 'StickyEmailSignUp' ).instance().props.toggleEligibleEmailSignUpForm ).toBeCalled();

      node.handleWindowResize();
      expect( component.find( 'StickyEmailSignUp' ).at( 0 ).props().setESUFormGTScreenHeight ).toBeCalled();

      node.handleCheckScreenHeight( 200, 150 );
      expect( component.find( 'StickyEmailSignUp' ).at( 0 ).props().setESUFormGTScreenHeight ).toBeCalled();
      node.handleCheckScreenHeight( 150, 200 );
      expect( component.find( 'StickyEmailSignUp' ).at( 0 ).props().setESUFormGTScreenHeight ).toBeCalled();

      node.toggleEmailSignUpForm();
      expect( component.find( 'StickyEmailSignUp' ).instance().handleSetAnimationStyle ).toBeCalled();
      expect( component.find( 'StickyEmailSignUp' ).at( 0 ).props().toggleShowEmailSignUpForm ).toBeCalled();
      expect( component.find( 'StickyEmailSignUp' ).at( 0 ).props().setESUFormGTScreenHeight ).toBeCalled();
    } );

    it( 'handles Button click event to close the sticky footer', () => {
      let node = component.find( 'StickyEmailSignUp' );
      node.hideStickyFooter = mockJestFn;

      expect( component.find( 'StickyEmailSignUp button.btn-no-style' ).length ).toBe( 1 );
      component.find( 'StickyEmailSignUp button.btn-no-style' ).at( 0 ).simulate( 'click' );
      expect( node.hideStickyFooter ).toBeCalled();
    } );

    it( 'handles Mobile click event to open the sticky footer form to viewport', () => {
      component.find( 'StickyEmailSignUp .StickyEmailSignUp__header' ).simulate( 'click' );
      expect( component.find( 'StickyEmailSignUp' ).instance().props.toggleShowEmailSignUpForm ).toBeCalled();
    } );

    it( 'check user profile data are displayed in the input boxes', () => {
      expect( component.find( '.StickyEmailSignUp__firstName .InputField input' ).props().value ).toBe( store1.getState().user.profileInfo.firstName );
      expect( component.find( '.StickyEmailSignUp__lastName .InputField input' ).props().value ).toBe( store1.getState().user.profileInfo.lastName );
      expect( component.find( '.StickyEmailSignUp__emailAddress .InputField input' ).props().value ).toBe( store1.getState().user.profileInfo.email );
    } );

    it( 'check the max length for ESU form input fields', () => {
      expect( component.find( '.StickyEmailSignUp__firstName .InputField input' ).props().maxLength ).toBe( 30 );
      expect( component.find( '.StickyEmailSignUp__lastName .InputField input' ).props().maxLength ).toBe( 30 );
      expect( component.find( '.StickyEmailSignUp__emailAddress .InputField input' ).props().maxLength ).toBe( 100 );
    } );

    it( 'handles Mobile click event to close/hide the sticky footer form from viewport', () => {
      component.find( 'StickyEmailSignUp button.btn-no-style' ).at( 0 ).simulate( 'click' );
      expect( component.find( 'StickyEmailSignUp' ).instance().props.toggleShowEmailSignUpForm ).toBeCalled();
    } );

    it( 'Check the sticky footer ESU form hide, if isAnyModalOpen flag change to true', () => {
      let props2 = {
        isSignedIn: undefined,
        stickyEmailSignUp: {
          isCheckEligibleEmailSignUpForm: false,
          isEligibleEmailSignUpForm: false,
          isAnyModalOpen: true
        },
        config: CONFIG
      };

      store1.getState().esu = {
        stickyEmailSignUp: {
          isCheckEligibleEmailSignUpForm: true,
          isEligibleEmailSignUpForm: true,
          isValidToAnimateEmailSignUpForm: true,
          isAnyModalOpen: true,
          sessionData: {
            isStickyFooterDisplay: false
          }
        }
      }

      let component2 = mountWithIntl(
        <Provider store={ store1 }>
          <StickyEmailSignUpMock { ...props } />
        </Provider>
      );

      component2.find( 'StickyEmailSignUp' ).instance().componentDidUpdate( props2 );
      let node = component2.find( 'StickyEmailSignUp' ).instance();
      node.handleStopTimerOrHideFooter = mockJestFn;
      node.hideStickyFooter = mockJestFn;

      expect( node.handleStopTimerOrHideFooter ).toBeCalled();
      expect( node.hideStickyFooter ).toBeCalled();
    } );

    it( 'Check the sticky footer ESU form display, if isAnyModalOpen flag change to false', () => {
      let props2 = {
        isSignedIn: true,
        isEmailOptIn: false,
        toggleEligibleEmailSignUpForm: mockJestFn,
        toggleShowEmailSignUpForm: mockJestFn,
        stickyEmailSignUp: {
          isCheckEligibleEmailSignUpForm: false,
          isEligibleEmailSignUpForm: false,
          isAnyModalOpen: true
        },
        config: CONFIG
      };

      let props3 = {
        isSignedIn: true,
        isEmailOptIn: false,
        stickyEmailSignUp: {
          isCheckEligibleEmailSignUpForm: false,
          isEligibleEmailSignUpForm: false,
          isAnyModalOpen: false
        },
        config: CONFIG
      };

      store1.getState().user = {
        isSignedIn: true,
        isEmailOptIn: false
      }
      store1.getState().esu = {
        stickyEmailSignUp: {
          isCheckEligibleEmailSignUpForm: true,
          isEligibleEmailSignUpForm: true,
          isValidToAnimateEmailSignUpForm: true,
          isAnyModalOpen: false,
          sessionData: {
            isStickyFooterDisplay: false
          }
        }
      }

      let component2 = mountWithIntl(
        <Provider store={ store1 }>
          <StickyEmailSignUpMock { ...props2 } />
        </Provider>
      );

      component2.find( 'StickyEmailSignUp' ).instance().componentDidUpdate( props3 );
      let node = component2.find( 'StickyEmailSignUp' ).instance();
      node.handleRestartTimer = mockJestFn;
      node.showStickyFooter = mockJestFn;

      expect( node.handleRestartTimer ).toBeCalled();
      expect( node.props.toggleEligibleEmailSignUpForm ).toBeCalled();
      expect( node.showStickyFooter ).toBeCalled();
      jest.useFakeTimers();
      jest.runAllTimers();
      expect( node.setTimerToShowStickyFooter ).toBeUndefined();
    } );

    it( 'should not render sticky footer emailup form when showOnMobile flag false', () => {
      let props4 = {
        ...props,
        switchData: {
          switches: {
            ultaEmailSignUpConfig: {
              ...props.switchData.switches.ultaEmailSignUpConfig,
              showOnMobile: false
            }
          }
        }
      };

      store1.getState().esu = {
        stickyEmailSignUp: {
          isCheckEligibleEmailSignUpForm: true,
          isEligibleEmailSignUpForm: false,
          sessionData: {
            isStickyFooterDisplay: false
          }
        }
      }

      let component4 = mountWithIntl(
        <Provider store={ store1 }>
          <StickyEmailSignUpMock { ...props4 } />
        </Provider>
      );

      component4.find( 'StickyEmailSignUp' ).instance().componentDidUpdate( props1 );
      expect( component4.find( '.StickyEmailSignUp--sticky' ).length ).toBe( 0 );
    } );

    it( 'should not display the Sticky ESU form before the wait time when resize the window', () => {
      let props4 = {
        ...props,
        screenHeight: 200,
        screenWidth: 200,
        switchData: {
          switches: {
            ultaEmailSignUpConfig: {
              ...props.switchData.switches.ultaEmailSignUpConfig,
              waitTimeSFMobile: 10
            }
          }
        }
      };

      let props5 = {
        ...props4,
        screenHeight: 100,
        screenWidth: 100,
        stickyEmailSignUp: {
          ...props.stickyEmailSignUp,
          isValidToAnimateEmailSignUpForm: true
        }
      }

      store1.getState().esu = {
        stickyEmailSignUp: {
          isCheckEligibleEmailSignUpForm: true,
          isEligibleEmailSignUpForm: true,
          isValidToAnimateEmailSignUpForm: true,
          sessionData: {
            isStickyFooterDisplay: false
          }
        }
      }

      store1.getState().global = {
        screenHeight: 200,
        screenWidth: 200
      }

      let component4 = mountWithIntl(
        <Provider store={ store1 }>
          <StickyEmailSignUpMock { ...props4 } />
        </Provider>
      );

      component4.find( 'StickyEmailSignUp' ).instance().componentDidUpdate( props5 );
      let node = component4.find( 'StickyEmailSignUp' ).instance();
      expect( node.setTimerToShowStickyFooter ).not.toBeUndefined();
      // Style transform attribute are used to display the ESU form on the screen and it should be empty
      expect( component4.find( '.StickyEmailSignUp--sticky' ).prop( 'style' ) ).toBeUndefined();

    } );

    it( 'Check the Close and Chevron Down SVG icon display based on isShowCloseSVGIcon flag', () => {
      store1.getState().esu = {
        stickyEmailSignUp: {
          isCheckEligibleEmailSignUpForm: true,
          isEligibleEmailSignUpForm: true,
          isShowCloseSVGIcon: true,
          sessionData: {
            isStickyFooterDisplay: false
          }
        }
      }
      let component5 = mountWithIntl(
        <Provider store={ store1 }>
          <StickyEmailSignUpMock { ...props } />
        </Provider>
      );
      expect( component5.find( 'StickyEmailSignUp .StickyEmailSignUp__toggleIcon button title' ).text() ).toBe( 'Close' );

      store1.getState().esu = {
        stickyEmailSignUp: {
          isCheckEligibleEmailSignUpForm: true,
          isEligibleEmailSignUpForm: true,
          isShowCloseSVGIcon: false,
          sessionData: {
            isStickyFooterDisplay: false
          }
        }
      }
      let component6 = mountWithIntl(
        <Provider store={ store1 }>
          <StickyEmailSignUpMock { ...props } />
        </Provider>
      );
      expect( component6.find( 'StickyEmailSignUp .StickyEmailSignUp__toggleIcon button title' ) ).not.toBe( 'Close' );

    } );

  } );

} );
