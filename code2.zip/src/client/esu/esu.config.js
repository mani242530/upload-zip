import { getLocation } from 'utils/Domain/Domain';
export default {

  DEBUGGING: {
    LOGGING: {
      SCRIPT_TAG_LOGS: false,
      TRACK_DATA_LAYER_LOGS: false,
      TRACK_ANALYTICS_LOGS : false,
      DISABLE_SESSIONCAM: false,
      TRACK_REDUX_EVENTS: true,
      TRACK_SAGA_FAILURES: true
    },
    USER: {
      isSignedIn: false,
      isRewardsMember: true,
      rewardStatus: 'Member', // Member/Platinum/Diamond
      isEmailOptIn: false
    },
    CART: {
      cartQty: '4'
    },
    ESU: {
      DISABLE_ON_SAME_SESSION: false,
      isNewUserOptIn: false,
      isErrorMessage: false
    }
  },
  ENABLE_QUBIT: false,
  ENABLE_REFLEKTION: false,
  ENABLE_SESSIONCAM: true,

  SECONDS_TO_WAIT_FOR_SIGNAL_TIMEOUT: 2,

  SERVICES: {

    SESSION_BLACK_LIST: [
      'session',
      'navigation',
      'switches',
      'user'
    ],

    searchTypeAhead:  ( process.env.NODE_ENV === 'production' ) ? `${ getLocation().origin }/ulta/assembler?assemblerContentCollection=/content/Shared/Search%20box` : '/services/search/typeAhead',

    session: '/services/v1/session/token',

    switches: '/services/v1/global/config',

    user: '/services/v2/user/lite',

    profile: '/services/v1/user/profile',

    navigation: '/services/v2/page/nav',

    subscribe: '/services/v1/user/emailSubscribe'

  }
}
