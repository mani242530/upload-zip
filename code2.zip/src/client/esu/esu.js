
/**
 * stickyemailsignup.js
 *
 * this is the entry file for the sticky footer email signup application and is only used for setup code
 *
 */

// Needed for redux-saga es6 generator support
import 'babel-polyfill';

// ReactJS specific imports
import React from 'react';
import { renderComponent } from 'utils/ReactDOM/rendering';
import shimReady from 'static/js/shim';

// Redux specific imports
import { Provider } from 'react-redux';

// i18n (internationalization) imports
import LanguageProvider from 'shared/components/LanguageProvider/LanguageProvider';

// Application component imports
import Global from 'shared/components/Global/Global';
import HeroCarousel from 'shared/components/HeroCarousel/HeroCarousel';
import StickyEmailSignUp from 'esu/components/StickyEmailSignUp/StickyEmailSignUp';
import { translationMessages } from 'shared/components/LanguageProvider/i18n';
import { initialState as defaultCarouselData } from 'shared/reducers/HeroCarousel/HeroCarousel.reducer';
import configureStore from 'esu/esu.store';

import {
  loadState,
  saveState
} from 'utils/LocalStorage/LocalStorage';

import CONFIG from 'esu/esu.config';

import { setConfig } from 'utils/Ajax/Ajax';
setConfig( CONFIG );

import throttle from 'lodash/throttle';
import isUndefined from 'lodash/isUndefined';

let persistedState = loadState();

// Store into the reducer that the carousel data list from window object
if( isUndefined( persistedState ) ){
  persistedState = {
    heroCarousel: defaultCarouselData
  }
}
else {
  persistedState.heroCarousel = defaultCarouselData;
}

if( !isUndefined( window.heroCarouselList ) ){
  persistedState.heroCarousel.carouselList = window.heroCarouselList;
}

const store = configureStore( persistedState, CONFIG );

store.subscribe( () => {
  let state = store.getState();

  saveState( {
    session: state.session,
    emailSignUp: state.esu.stickyEmailSignUp.sessionData
  } );
} )

export const render = ( messages ) => {
  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Global />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-global' )
  );

  // HeroCarousel
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <HeroCarousel />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-heroCarousel' )
  );

  // STICKY EMAIL SIGNUP FOOTER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <StickyEmailSignUp config={ CONFIG } />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-stickyEmailSignUpFooter' )
  );
}

// Hot reloadable translation json fiels
if( module.hot ){
  // modules.hot.accept does not accept dynamic dependencies,
  // have to be constants at compile-time
  module.hot.accept( 'shared/components/LanguageProvider/i18n', () => {
    render( translationMessages );
  } );
}

// new polyfill for browsers without Intl support
shimReady( () => {
  render( translationMessages )
} );
