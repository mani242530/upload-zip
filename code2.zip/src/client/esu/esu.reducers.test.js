/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 **/

// import { fromJS } from 'immutable';
import { combineReducers } from 'redux';
import has from 'lodash/has';
import {
  reducer as formReducer,
  actionTypes as formActionTypes
} from 'redux-form';

import global from 'shared/reducers/Global/Global.reducer';
import session from 'shared/reducers/Session/Session.reducer';
import user from 'shared/reducers/User/User.reducer';
import language from 'shared/reducers/Language/Language.reducer';
import esu from 'esu/reducers/EmailSignUp/EmailSignUp.reducer';

import asyncReducers, {
  removeUnregisteredFormValue
} from './esu.reducers';
import _ from 'lodash';
// import reducers that are globally required in the ULTA app
//
describe( 'ESU reducer', ( ) => {

  it( 'should be a function', ( ) => {
    expect( _.isFunction( asyncReducers ) ).toBe( true );
  } );

  it( 'should return the combineReducers', ( ) => {
    expect( asyncReducers().toString ).toEqual( combineReducers( {
      global,
      session,
      user,
      language,
      esu,
      form: formReducer,
      ...asyncReducers
    } ).toString )
  } );

  it( 'should return the state if the action is not for unregistering a field', ( ) => {
    let actionCreator = {
      type: 'test',
      payload:{
        name:'test'
      }
    }

    let state = {
      values: {
        Field1:'test',
        Field2:'test',
        Field3:'test'
      }
    }

    expect( removeUnregisteredFormValue( state, actionCreator ) ).toEqual( state );

  } );

  it( 'should remove unregistered field', ( ) => {
    let actionCreator = {
      type: formActionTypes.UNREGISTER_FIELD,
      payload:{
        name:'Field1'
      }
    }

    let state = {
      values: {
        Field1:'test',
        Field2:'test',
        Field3:'test'
      }
    }

    let expectedOutput = {
      values: {
        Field2:'test',
        Field3:'test'
      }
    }

    expect( removeUnregisteredFormValue( state, actionCreator ) ).toEqual( expectedOutput );

  } );

} );