import CONFIG from 'esu/esu.config';
import { fork } from 'redux-saga/effects';

import sessionsaga, { sessionManager } from 'shared/sagas/Session/Session.sagas';
import switches from 'shared/sagas/Switches/Switches.sagas';
import usersaga from 'shared/sagas/User/User.sagas';
import profilesaga from 'shared/sagas/Profile/Profile.sagas';
import navigationsaga from 'shared/sagas/Navigation/Navigation.sagas';
import analyticssaga from 'shared/sagas/Analytics/Analytics.sagas';


import subscribesaga from 'esu/sagas/EmailSignUp/EmailSignUp.sagas';

// All sagas to be loaded
// sessionSAGA must be the first in the list
export default function*(){
  yield[
    // SHARED Module
    fork( sessionManager ),
    fork( sessionsaga( CONFIG ) ),
    fork( usersaga( CONFIG ) ),
    fork( profilesaga ),
    fork( navigationsaga ),
    fork( switches( CONFIG ) ),
    fork( analyticssaga ),

    fork( subscribesaga( CONFIG ) )
  ]
}
