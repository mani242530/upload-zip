import CONFIG from 'esu/esu.config';
import { fork } from 'redux-saga/effects';

import searchtypeaheadsaga from 'hf/sagas/SearchTypeAhead/SearchTypeAhead.sagas';

import sessionsaga, { sessionManager } from 'shared/sagas/Session/Session.sagas';
import usersaga from 'shared/sagas/User/User.sagas';
import profilesaga from 'shared/sagas/Profile/Profile.sagas';
import analyticssaga from 'shared/sagas/Analytics/Analytics.sagas';
import switches from 'shared/sagas/Switches/Switches.sagas';
import subscribesaga from 'esu/sagas/EmailSignUp/EmailSignUp.sagas';

import saga from './esu.sagas';

describe( 'esu sagas', () => {

  const esuSaga = saga();

  it( 'should load all sagas', () => {

    const yieldDescriptor = esuSaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      fork( sessionManager ),
      fork( sessionsaga( CONFIG ) ),
      fork( usersaga( CONFIG ) ),
      fork( profilesaga ),
      fork( switches( CONFIG ) ),
      fork( analyticssaga ),
      fork( searchtypeaheadsaga ),
      fork( subscribesaga( CONFIG ) )
    ] ) );

  } );

} );

