/**
 * EmailSignUp Redux reducer Module
 *
 */

import {
  types as esuTypes
} from 'esu/actions/EmailSignUp/EmailSignUp.actions';

import {
  getServiceType
} from 'shared/actions/Services/Services.actions';

import {
  types as mobileLeftNavActionTypes
} from 'hf/actions/MobileLeftNav/MobileLeftNav.actions';

import {
  types as headerActionTypes
} from 'hf/actions/Header/Header.actions';


import has from 'lodash/has';

/**
 * default state for the Footer reducer
 */

export const initialState = {
  stickyEmailSignUp: {
    sessionData: {
      isStickyFooterDisplay: false
    },
    bodyStylePaddingBottom: 0,
    isCheckEligibleEmailSignUpForm: false,
    isEligibleEmailSignUpForm: false,
    isShowEmailSignUpForm: false,
    isEmailSignUpFormSubmitted: false,
    isESUFormHeightGTScreenHeight: false,
    isValidToAnimateEmailSignUpForm: false,
    translateYPosition: undefined,
    isNewUserOptedIn: undefined,
    esuFormSubmitSpinner: false,
    isSubmittedEmailSignUpFormError: false,
    isSubscribeServiceFailure: false, // Flag is used to display error message, when have network failure
    isShowCloseSVGIcon: true, // Flag is used to display the Close or Chevron Down SVG icon
    isAnyModalOpen: false // Flag to check Modal/Quick Shop,Hamburger menu on mobile and Left Nav/flyouts on desktop
  }
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){

  switch ( action.type ){
    case getServiceType( 'user', 'success' ):
      let isESUOptedIn = false;
      // Updated the condition based on v2 user lite services
      if( has( action.data, 'user.accountInfo.firstName' ) ){
        // set isESUOptedIn flag based on service response data
        isESUOptedIn = action.data.user.accountInfo.emailOptIn;
      }
      if( !isESUOptedIn && !state.stickyEmailSignUp.sessionData.isStickyFooterDisplay && !state.stickyEmailSignUp.isAnyModalOpen ){
        return {
          ...state,
          stickyEmailSignUp: {
            ...state.stickyEmailSignUp,
            isCheckEligibleEmailSignUpForm: true
          }
        }
      }
      else {
        return state;
      }

    case getServiceType( 'subscribe', 'failure' ):
      return {
        ...state,
        stickyEmailSignUp: {
          ...state.stickyEmailSignUp,
          isSubmittedEmailSignUpFormError: true,
          isSubscribeServiceFailure: true,
          esuFormSubmitSpinner: false,
          isShowCloseSVGIcon: true // Flag used to change the ChevronDown to Close icon
        }
      }

    case getServiceType( 'subscribe', 'success' ):
      let errors = ( has( action.data, 'data.messages.items' ) && action.data.data.messages.items.length > 0 ) ;
      return {
        ...state,
        stickyEmailSignUp: {
          ...state.stickyEmailSignUp,
          esuFormSubmitSpinner: false,
          isNewUserOptedIn: action.data.data.newUser,
          isEmailSignUpFormSubmitted: !errors,
          isShowCloseSVGIcon: true, // Flag used to change the ChevronDown to Close icon
          isSubscribeServiceFailure: false,
          isSubmittedEmailSignUpFormError: errors,
          ...( errors && { messages: action.data.data.messages.items } )
        }
      }

    case getServiceType( 'subscribe', 'loading' ):
      return {
        ...state,
        stickyEmailSignUp: {
          ...state.stickyEmailSignUp,
          esuFormSubmitSpinner: true,
          messages: undefined
        }
      }

    case mobileLeftNavActionTypes.TOGGLE_LEFT_NAV:
    case headerActionTypes.TOGGLE_SEARCH_MODE:
      return {
        ...state,
        stickyEmailSignUp: {
          ...state.stickyEmailSignUp,
          isAnyModalOpen: ( action.mode === 'open' )
        }
      }

    case esuTypes.SET_ESU_MODEL_OPENED_FLAG:
      return {
        ...state,
        stickyEmailSignUp: {
          ...state.stickyEmailSignUp,
          isAnyModalOpen: true
        }
      }

    case esuTypes.SET_ESU_MODEL_CLOSED_FLAG:
      return {
        ...state,
        stickyEmailSignUp: {
          ...state.stickyEmailSignUp,
          isAnyModalOpen: false
        }
      }

    case esuTypes.TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM:
      if( !state.stickyEmailSignUp.isAnyModalOpen ){
        return {
          ...state,
          stickyEmailSignUp: {
            ...state.stickyEmailSignUp,
            isEligibleEmailSignUpForm: action.data,
            isValidToAnimateEmailSignUpForm: action.data
          }
        }
      }
      else {
        return state;
      }

    case esuTypes.TOGGLE_SHOW_EMAIL_SIGN_UP_FORM:
      return {
        ...state,
        stickyEmailSignUp: {
          ...state.stickyEmailSignUp,
          isShowEmailSignUpForm: action.data,
          isShowCloseSVGIcon: !action.data
        }
      }

    // TO FIX Footer Overlay issue in Safari browser changed margin bottom to padding bottom
    case esuTypes.SET_BODY_STYLE_PADDING_BOTTOM:
      return {
        ...state,
        stickyEmailSignUp: {
          ...state.stickyEmailSignUp,
          bodyStylePaddingBottom: action.data
        }
      }

    case esuTypes.SET_STICKY_FOOTER_DISPLAY:
      return {
        ...state,
        stickyEmailSignUp:{
          ...state.stickyEmailSignUp,
          sessionData: {
            ...state.sessionData,
            isStickyFooterDisplay: action.data
          }
        }
      }

    case esuTypes.SET_ESU_FORM_GT_SCREEN_HEIGHT:
      return {
        ...state,
        stickyEmailSignUp: {
          ...state.stickyEmailSignUp,
          isESUFormHeightGTScreenHeight: action.data
        }
      }

    // Set isSubmittedEmailSignUpFormError flag to show & hide the server side error message & ESU form
    // Reset the flags, when try again button clicked
    case esuTypes.SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR:

      return {
        ...state,
        stickyEmailSignUp: {
          ...state.stickyEmailSignUp,
          isSubmittedEmailSignUpFormError: action.data,
          isSubscribeServiceFailure: false,
          isShowCloseSVGIcon: window.innerWidth > 992
        }
      }

    case esuTypes.SET_ESU_CONTAINER_TRANSLATE_Y:
      switch ( action.data.mode ){
        case 'initialRender':
          if( action.data.isMobileDevice ){
            let animateHeight = action.data.containerHeight - action.data.mhcHeight;
            return {
              ...state,
              stickyEmailSignUp: {
                ...state.stickyEmailSignUp,
                isShowCloseSVGIcon: true,
                translateYPosition: animateHeight
              }
            }
          }
          else {
            return {
              ...state,
              stickyEmailSignUp: {
                ...state.stickyEmailSignUp,
                isShowCloseSVGIcon: true,
                translateYPosition: 0
              }
            }
          }

        case 'displayForm':
          if( state.stickyEmailSignUp.isShowEmailSignUpForm ){
            let animateHeight = action.data.containerHeight - action.data.mhcHeight;
            return {
              ...state,
              stickyEmailSignUp: {
                ...state.stickyEmailSignUp,
                translateYPosition: animateHeight
              }
            }
          }
          else {
            return {
              ...state,
              stickyEmailSignUp: {
                ...state.stickyEmailSignUp,
                translateYPosition: 0
              }
            }
          }

        case 'hide':
          return {
            ...state,
            stickyEmailSignUp: {
              ...state.stickyEmailSignUp,
              isValidToAnimateEmailSignUpForm: false,
              translateYPosition: 600 // Set maximum container height, so when user resize the browser it will not display again the viewport
            }
          }

        default:
          return state;
      }

    default:
      return state;
  }
}
