import reducer, {
  initialState
} from './EmailSignUp.reducer';

import {
  types
} from 'esu/actions/EmailSignUp/EmailSignUp.actions';

import {
  types as mobileLeftNavActionTypes
} from 'hf/actions/MobileLeftNav/MobileLeftNav.actions';

import {
  types as headerActionTypes
} from 'hf/actions/Header/Header.actions';

import {
  getServiceType,
  registerServiceName
} from 'shared/actions/Services/Services.actions';

import isFunction from 'lodash/isFunction';

import device from 'utils/DeviceDetection/deviceDetection';

describe( 'EmailSignUp reducer', ( ) => {

  registerServiceName( 'user' );
  registerServiceName( 'subscribe' );

  it( 'should have the proper default state', ( ) => {

    let expectedOutput = {
      stickyEmailSignUp: {
        sessionData: {
          isStickyFooterDisplay: false
        },
        bodyStylePaddingBottom: 0,
        isCheckEligibleEmailSignUpForm: false,
        isEligibleEmailSignUpForm: false,
        isShowEmailSignUpForm: false,
        isEmailSignUpFormSubmitted: false,
        isESUFormHeightGTScreenHeight: false,
        isValidToAnimateEmailSignUpForm: false,
        translateYPosition: undefined,
        isNewUserOptedIn: undefined,
        esuFormSubmitSpinner: false,
        isSubmittedEmailSignUpFormError: false,
        isSubscribeServiceFailure: false,
        isShowCloseSVGIcon: true,
        isAnyModalOpen: false
      }
    };
    expect( initialState ).toEqual( expectedOutput );

  } );

  it( 'should be a function', ( ) => {
    expect( isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  it( 'set isCheckEligibleEmailSignUpForm flag based on user data EmailSignUp event', () => {
    let res = {
      user: {
        accountInfo: {
          firstName: 'Test',
          emailOptIn: false
        }
      }
    }

    let actionCreator = {
      type: getServiceType( 'user', 'success' ),
      data: res
    }

    let state = {
      stickyEmailSignUp: {
        sessionData: {
          isStickyFooterDisplay: false
        },
        isCheckEligibleEmailSignUpForm: false
      }
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        sessionData: {
          isStickyFooterDisplay: false
        },
        isCheckEligibleEmailSignUpForm: true
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    let state1 = {
      stickyEmailSignUp: {
        sessionData: {
          isStickyFooterDisplay: true
        },
        isCheckEligibleEmailSignUpForm: false
      }
    }
    expect( reducer( state1, actionCreator ) ).toEqual( state1 );

  } );

  it( 'email subscribe event for the failure condition', () => {
    let actionCreator = {
      type: getServiceType( 'subscribe', 'failure' )
    }

    let expected = {
      stickyEmailSignUp: {
        isSubmittedEmailSignUpFormError: true,
        isSubscribeServiceFailure: true,
        esuFormSubmitSpinner: false,
        isShowCloseSVGIcon: true
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expected );
  } );

  it( 'email subscribe event for the loading condition', () => {
    let actionCreator = {
      type: getServiceType( 'subscribe', 'loading' )
    }

    let expected = {
      stickyEmailSignUp: {
        esuFormSubmitSpinner: true,
        messages: undefined
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expected );
  } );

  it( 'email subscribe event for the Success condition', () => {
    let actionCreator = {
      type: getServiceType( 'subscribe', 'success' ),
      data: {
        data: {
          newUser: true
        }
      }
    }

    let expected = {
      stickyEmailSignUp: {
        esuFormSubmitSpinner: false,
        isNewUserOptedIn: true,
        isShowCloseSVGIcon: true,
        isSubmittedEmailSignUpFormError: false,
        isSubscribeServiceFailure: false,
        isEmailSignUpFormSubmitted: true
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expected );
  } );

  it( 'email subscribe event for the Failure condition', () => {
    let actionCreator = {
      type: getServiceType( 'subscribe', 'success' ),
      data: {
        data: {
          newUser: false,
          messages: {
            items: [
              {
                messageKey: 'emailSignupFailure',
                messageType: 'Error',
                messageDesc: 'Unable to process request at this time'
              }
            ]
          }
        }
      }
    }

    let expected = {
      stickyEmailSignUp: {
        esuFormSubmitSpinner: false,
        isNewUserOptedIn: false,
        isShowCloseSVGIcon: true,
        isEmailSignUpFormSubmitted: false,
        isSubscribeServiceFailure: false,
        isSubmittedEmailSignUpFormError: true,
        messages: [
          {
            messageKey: 'emailSignupFailure',
            messageType: 'Error',
            messageDesc: 'Unable to process request at this time'
          }
        ]
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expected );
  } );

  it( 'toggle eligible email signup EmailSignUp event with isAnyModalOpen false', () => {
    let actionCreator = {
      type: types.TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM,
      data: true
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isAnyModalOpen: false,
        isEligibleEmailSignUpForm: true,
        isValidToAnimateEmailSignUpForm: true
      }
    };
    expect( reducer( { stickyEmailSignUp:{ isAnyModalOpen: false } }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'toggle eligible email signup EmailSignUp event with isAnyModalOpen true', () => {
    let actionCreator = {
      type: types.TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM,
      data: true
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isAnyModalOpen: true
      }
    };
    expect( reducer( { stickyEmailSignUp:{ isAnyModalOpen: true } }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'toggle show email signup EmailSignUp event', () => {
    let actionCreator = {
      type: types.TOGGLE_SHOW_EMAIL_SIGN_UP_FORM,
      data: true
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isShowEmailSignUpForm: true,
        isShowCloseSVGIcon: false
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Set Body Style Padding Bottom EmailSignUp event', () => {
    let actionCreator = {
      type: types.SET_BODY_STYLE_PADDING_BOTTOM,
      data: 10
    }

    let expectedOutput = { stickyEmailSignUp:{ bodyStylePaddingBottom: 10 } };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Set Sticky Footer Display to user EmailSignUp event', () => {
    let actionCreator = {
      type: types.SET_STICKY_FOOTER_DISPLAY,
      data: true
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        sessionData: {
          isStickyFooterDisplay: true
        }
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Check Set email signup form height with screen height and set the flag EmailSignUp event', () => {
    let actionCreator = {
      type: types.SET_ESU_FORM_GT_SCREEN_HEIGHT,
      data: true
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isESUFormHeightGTScreenHeight: true
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Check Set submitted email signup form error flag when get server errors in Desktop', () => {
    window.innerWidth = 993;
    let actionCreator = {
      type: types.SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR,
      data: true
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isSubmittedEmailSignUpFormError: true,
        isSubscribeServiceFailure: false,
        isShowCloseSVGIcon: true
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Check Set submitted email signup form error flag when get server errors in Mobile', () => {
    window.innerWidth = 991;
    let actionCreator = {
      type: types.SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR,
      data: true
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isSubmittedEmailSignUpFormError: true,
        isSubscribeServiceFailure: false,
        isShowCloseSVGIcon: false
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Set email signup form container translateY position in EmailSignUp event initialRender mode', () => {
    let actionCreator = {
      type: types.SET_ESU_CONTAINER_TRANSLATE_Y,
      data: {
        mode: 'initialRender',
        containerHeight: 150,
        mhcHeight: 25,
        isMobileDevice: true
      }
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isShowCloseSVGIcon: true,
        translateYPosition: 125
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    let actionCreator1 = {
      type: types.SET_ESU_CONTAINER_TRANSLATE_Y,
      data: {
        mode: 'initialRender',
        containerHeight: 150,
        mhcHeight: 25,
        isMobileDevice: false
      }
    }

    let expectedOutput1 = {
      stickyEmailSignUp: {
        isShowCloseSVGIcon: true,
        translateYPosition: 0
      }
    };
    expect( reducer( {}, actionCreator1 ) ).toEqual( expectedOutput1 );
  } );

  it( 'Set email signup form container translateY position in EmailSignUp event displayForm mode', () => {
    let actionCreator = {
      type: types.SET_ESU_CONTAINER_TRANSLATE_Y,
      data: {
        mode: 'displayForm',
        containerHeight: 150,
        mhcHeight: 25,
        introElemHeight: 20
      }
    }

    let state = {
      stickyEmailSignUp: {
        isShowEmailSignUpForm: true,
        isESUFormHeightGTScreenHeight: false
      }
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isShowEmailSignUpForm: true,
        isESUFormHeightGTScreenHeight: false,
        translateYPosition: 125
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    let actionCreator2 = {
      type: types.SET_ESU_CONTAINER_TRANSLATE_Y,
      data: {
        mode: 'displayForm',
        containerHeight: 150,
        mhcHeight: 25,
        introElemHeight: 20
      }
    }

    let state2 = {
      stickyEmailSignUp: {
        isShowEmailSignUpForm: false
      }
    }

    let expectedOutput2 = {
      stickyEmailSignUp: {
        isShowEmailSignUpForm: false,
        translateYPosition: 0
      }
    };
    expect( reducer( state2, actionCreator2 ) ).toEqual( expectedOutput2 );
  } );

  it( 'Set email signup form container translateY position in EmailSignUp event hide mode', () => {
    let actionCreator = {
      type: types.SET_ESU_CONTAINER_TRANSLATE_Y,
      data: {
        mode: 'hide'
      }
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isValidToAnimateEmailSignUpForm: false,
        translateYPosition: 600
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    let actionCreator1 = {
      type: types.SET_ESU_CONTAINER_TRANSLATE_Y,
      data: {
        mode: ''
      }
    }

    let expectedOutput1 = {
      stickyEmailSignUp: {
        translateYPosition: 150
      }
    };
    expect( reducer( expectedOutput1, actionCreator1 ) ).toEqual( expectedOutput1 );

  } );

  it( 'Check mobileLeftNavActionTypes TOGGLE_LEFT_NAV EVENT', () => {
    let actionCreator = {
      type: mobileLeftNavActionTypes.TOGGLE_LEFT_NAV,
      mode: 'open'
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isAnyModalOpen: true
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Check headerActionTypes TOGGLE_SEARCH_MODE EVENT', () => {
    let actionCreator = {
      type: headerActionTypes.TOGGLE_SEARCH_MODE,
      mode: 'close'
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isAnyModalOpen: false
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Set isAnyModalOpen flag to true when overlay dispatch open event happen', () => {
    let actionCreator = {
      type: types.SET_ESU_MODEL_OPENED_FLAG
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isAnyModalOpen: true
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Set isAnyModalOpen flag to false when overlay dispatch close event happen', () => {
    let actionCreator = {
      type: types.SET_ESU_MODEL_CLOSED_FLAG
    }

    let expectedOutput = {
      stickyEmailSignUp: {
        isAnyModalOpen: false
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

} );
