/**
 * EmailSignUp  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import { delay } from 'redux-saga';
import saga, { listener } from './EmailSignUp.sagas';
import Cookies from 'js-cookie';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';

import {
  actions as dataLayerActions
} from 'shared/actions/DataLayer/DataLayer.actions';

import CONFIG from 'esu/esu.config';

const type = 'subscribe';
const sessionID = '44432';

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );

  describe( 'default saga', () => {

    const subscribeSaga = saga( CONFIG )();

    it( 'should listen for the navigation requested method', () => {

      const takeEveryDescriptor = subscribeSaga.next().value;
      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( 'subscribe', 'requested' ), listener, type, CONFIG )
      );

    } );

  } );

  describe( 'listener saga success path', () => {

    Cookies.set( 'ultaSession', sessionID );
    const listenerSaga = listener( type, CONFIG, { data: sessionID } );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should put a delay of 2 seconds before moving forward', () => {

      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( delay, 2000 ) );

    } )

    it( 'should yield on requesting data and return that data with a sucess method one', () => {

      const callDescriptor = listenerSaga.next().value;
      const data = {
        type,
        method: 'post',
        values: {}
      };
      expect( callDescriptor ).toEqual( call( ajax, data ) );

    } );

    it( 'should put a success event after data is called', () => {

      let res = {
        data: {
          newUser: true
        },
        meta: {
          lastFetchedTime: '2017-11-08 14:52:33.608-06:00'
        }
      }

      const putDescriptor = listenerSaga.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );

    } );

    it( 'should update the datalayer after success event', () => {
      const data = {
        'globalPageData': {
          'action': {
            'emailOptIn': true
          },
          'navigation': {
            'path': 'email:footer'
          }
        }
      };

      const evt = {
        'name': 'Email-Optin'
      };

      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( dataLayerActions.setDataLayer( data, evt ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );


} );
