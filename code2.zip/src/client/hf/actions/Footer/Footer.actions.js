/**
 * Footer Actions
 *
 * This file defines the action types and action creators for 'Footer'
 **/


/**
 * ACTION TYPES
 */
export const types = {

  SET_ACTIVE_FOOTER_NAV_COLLAPSE: 'FOOTER::SET_ACTIVE_FOOTER_NAV_COLLAPSE',
  SET_FOOTER_DISPLAY_MODE: 'FOOTER::SET_FOOTER_DISPLAY_MODE'

}


/**
 * ACTIONS
 */
export const actions = {

  setActiveFooterNavCollapse: ( panelID ) => ( { type: types.SET_ACTIVE_FOOTER_NAV_COLLAPSE, panelID } ),
  setFooterDisplayMode: ( deviceType, mode ) => ( { type: types.SET_FOOTER_DISPLAY_MODE, mode, deviceType } )

}
