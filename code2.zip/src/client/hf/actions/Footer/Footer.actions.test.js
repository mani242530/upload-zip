/**
 * Test for Footer actions
 */

import { types, actions } from './Footer.actions';
import _ from 'lodash';

describe( 'Footer action types', () => {

  describe( 'Alert Window Resize', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_ACTIVE_FOOTER_NAV_COLLAPSE ).toBe( 'FOOTER::SET_ACTIVE_FOOTER_NAV_COLLAPSE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setActiveFooterNavCollapse ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      var panelID = 'test1';
      let creator = actions.setActiveFooterNavCollapse( panelID );
      expect( creator ).toEqual( {
        type: types.SET_ACTIVE_FOOTER_NAV_COLLAPSE,
        panelID
      } )
    } );
  } );

  describe( 'Footer display', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_FOOTER_DISPLAY_MODE ).toBe( 'FOOTER::SET_FOOTER_DISPLAY_MODE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setFooterDisplayMode ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      var deviceType = 'mobile';
      var mode = '';
      let creator = actions.setFooterDisplayMode( deviceType, mode );
      expect( creator ).toEqual( {
        type: types.SET_FOOTER_DISPLAY_MODE,
        deviceType,
        mode
      } )
    } );
  } );

} );

