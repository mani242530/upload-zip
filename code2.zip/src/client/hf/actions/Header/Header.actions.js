/**
 * Header Actions
 *
 * This file defines the action types and action creators for 'Header'
 **/


/**
 * ACTION TYPES
 */
export const types = {

  TOGGLE_SEARCH_MODE: 'HEADER::TOGGLE_SEARCH_MODE',
  SET_MAIN_NAV_BAR_HEIGHT: 'HEADER::SET_MAIN_NAV_BAR_HEIGHT',
  SET_HEADER_HEIGHT: 'HEADER::SET_HEADER_HEIGHT',
  SET_SHIPPING_BANNER_HEIGHT: 'HEADER::SET_SHIPPING_BANNER_HEIGHT',
  GET_NAV_ITEM_LIST: 'HEADER::GET_NAV_ITEM_LIST',
  SET_CURRENT_PAGE: 'SET_CURRENT_PAGE',
  SET_HEADER_DISPLAY_MODE: 'HEADER::SET_HEADER_DISPLAY:MODE'
}



/**
 * ACTIONS
 */
export const actions = {
  setMainNavBarHeight: ( height ) => ( { type: types.SET_MAIN_NAV_BAR_HEIGHT, height } ),
  setHeaderHeight: ( normalHeight, stickyHeight ) => ( { type: types.SET_HEADER_HEIGHT, normalHeight, stickyHeight } ),
  setHeaderDisplayMode: ( deviceType, mode )=> ( { type: types.SET_HEADER_DISPLAY_MODE, mode, deviceType } ),
  setShippingBannerHeight: ( height ) => ( { type: types.SET_SHIPPING_BANNER_HEIGHT, height } ),
  toggleSearchMode: ( mode, stickyContainerOffset, stickyContainerHeight ) => (
    {
      type: types.TOGGLE_SEARCH_MODE,
      mode: ( mode === 'close' || mode === 'open' )? mode: 'close',
      stickyContainerOffset,
      stickyContainerHeight
    }
  ),

  getNavItemList: ( navData ) => ( { type: types.GET_NAV_ITEM_LIST, navData } )


}
