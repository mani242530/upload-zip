/**
 * Test for Header actions
 */

import { types, actions } from './Header.actions';
import _ from 'lodash';

describe( 'Header action types', () => {
  it( 'The SET_HEADER_HEIGHT  action type should exist', () => {
    expect( types.SET_HEADER_HEIGHT ).toBe( 'HEADER::SET_HEADER_HEIGHT' );
  } );

  it( 'The SET_SHIPPING_BANNER_HEIGHT  action type should exist', () => {
    expect( types.SET_SHIPPING_BANNER_HEIGHT ).toBe( 'HEADER::SET_SHIPPING_BANNER_HEIGHT' );
  } );

  it( 'should have a action type of TOGGLE_SEARCH_MODE', () => {
    expect( types.TOGGLE_SEARCH_MODE ).toBe( 'HEADER::TOGGLE_SEARCH_MODE' );
  } );

  it( 'should have a action type of SET_MAIN_NAV_BAR_HEIGHT', () => {
    expect( types.SET_MAIN_NAV_BAR_HEIGHT ).toBe( 'HEADER::SET_MAIN_NAV_BAR_HEIGHT' );
  } );

  it( 'should have a action type of GET_NAV_ITEM_LIST', () => {
    expect( types.GET_NAV_ITEM_LIST ).toBe( 'HEADER::GET_NAV_ITEM_LIST' );
  } );
} );

describe( 'Header action creators', () => {

  describe( 'toggleSearchMode', () => {

    it( 'should be a function that returns the proper action creator', () => {
      expect( _.isFunction( actions.toggleSearchMode ) ).toBe( true );
      let creator = actions.toggleSearchMode();

      expect( creator ).toEqual( {
        type: types.TOGGLE_SEARCH_MODE,
        mode: 'close'
      } );

      let creator2 = actions.toggleSearchMode( 'open', 0, 1 );

      expect( creator2 ).toEqual( {
        type: types.TOGGLE_SEARCH_MODE,
        mode: 'open',
        stickyContainerOffset: 0,
        stickyContainerHeight: 1
      } );
    } );
  } );


  describe( 'setHeaderHeight', () => {

    it( 'setHeaderHeight should be a function', () => {
      expect( _.isFunction( actions.setHeaderHeight ) ).toBe( true );

    } );

    it( 'should return a properly configed action creator object', () => {
      let creator = actions.setHeaderHeight( 0, 0 );

      expect( creator ).toEqual( {
        type: types.SET_HEADER_HEIGHT,
        normalHeight: 0,
        stickyHeight: 0
      } );

    } );

  } );

  describe( 'setShippingBannerHeight', () => {

    it( 'setShippingBannerHeight should be a function', () => {
      expect( _.isFunction( actions.setShippingBannerHeight ) ).toBe( true );

    } );

    it( 'should return a properly configed action creator object', () => {
      let creator = actions.setShippingBannerHeight( 30 );

      expect( creator ).toEqual( {
        type: types.SET_SHIPPING_BANNER_HEIGHT,
        height: 30
      } );

    } );

  } );


  describe( 'getNavItemList', () => {

    it( 'setMainNavBarHeight should be a function', () => {
      expect( _.isFunction( actions.setMainNavBarHeight ) ).toBe( true );

    } );

    it( 'should return a properly configed action creator object', () => {
      let creator = actions.setMainNavBarHeight( 30 );

      expect( creator ).toEqual( {
        type: types.SET_MAIN_NAV_BAR_HEIGHT,
        height: 30
      } );

    } );

  } );

  describe( 'getNavItemList', () => {

    it( 'getNavItemList should be a function', () => {
      expect( _.isFunction( actions.getNavItemList ) ).toBe( true );

    } );

    it( 'should return a properly configed action creator object', () => {
      let creator = actions.getNavItemList( [] );

      expect( creator ).toEqual( {
        type: types.GET_NAV_ITEM_LIST,
        navData: []
      } );

    } );

  } );

  describe( 'setHeaderDisplayMode', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_HEADER_DISPLAY_MODE ).toBe( 'HEADER::SET_HEADER_DISPLAY:MODE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setHeaderDisplayMode ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      var deviceType = 'mobile';
      var mode = '';
      let creator = actions.setHeaderDisplayMode( deviceType, mode );
      expect( creator ).toEqual( {
        type: types.SET_HEADER_DISPLAY_MODE,
        deviceType,
        mode
      } )
    } );
  } );

} );
