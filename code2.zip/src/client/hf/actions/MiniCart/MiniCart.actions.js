/**
 *
 * MiniCart Actions
 *
 * This file defines the action types and action creators for 'MiniCart'
 **/


/**
 * ACTION TYPES
 */
export const types = {

  COUPON_CODE: 'MINI_CART::COUPON_CODE',
  COUPON_CODE_REMOVED: 'MINI_CART::COUPON_CODE_REMOVED',
  REMOVE_FROM_CART: 'MINI_CART::REMOVE_FROM_CART',
  REMOVE_GIFT_FROM_CART: 'MINI_CART::REMOVE_GIFT_FROM_CART',
  SET_GIFT_MESSAGE: 'MINI_CART::SET_GIFT_MESSAGE',
  SET_GIFT_BOX_TOGGLE_STATE: 'MINI_CART::SET_GIFT_BOX_TOGGLE_STATE',
  SHOW_BAG_SUMMARY: 'MINI_CART::SHOW_BAG_SUMMARY',
  SET_PRODUCT_SAMPLE: 'MINI_CART::SET_PRODUCT_SAMPLE',
  CART_RIGHT_PANEL_COLLAPSE: 'MINI_CART::CART_RIGHT_PANEL_COLLAPSE',
  SET_CHKOUT_BTN_STATE: 'MINI_CART::SET_CHKOUT_BTN_STATE',
  SELECT_PRODUCT_SAMPLE_SERVICE:'MINI_CART::SELECT_PRODUCT_SAMPLE_SERVICE',
  REMOVE_PRODUCT_SAMPLE_SERVICE:'MINI_CART::REMOVE_PRODUCT_SAMPLE_SERVICE',
  SELECT_GIFT_VARIANT:'MINI_CART::SELECT_GIFT_VARIANT',
  SET_COUPON_OFFER_REQ: 'MINI_CART::SET_COUPON_OFFER_REQ',
  SET_GIFT_WRAP_GIFT_NOTE_SERVICE : 'MINI_CART::SET_GIFT_WRAP_GIFT_NOTE_SERVICE',
  SET_GIFT_WRAP_GIFT_BOX_SERVICE : 'MINI_CART::SET_GIFT_WRAP_GIFT_BOX_SERVICE',
  OPEN_CART: 'MINI_CART::OPEN_CART',
  ADD_TO_CART: 'MINI_CART::ADD_TO_CART',
  UPDATE_CART: 'MINI_CART::UPDATE_CART',
  INITIATE_CHECKOUT: 'MINI_CART::INITIATE_CHECKOUT',
  RESET_CHECKOUT_ELIGIBILITY: 'MINI_CART::RESET_CHECKOUT_ELIGIBILITY',
  GET_PAYPAL_RESPONSE: 'MINI_CART::GET_PAYPAL_RESPONSE',
  HIDE_OUT_OF_STOCK_PANEL: 'MINI_CART::HIDE_OUT_OF_STOCK_PANEL',
  CLEAR_COUPON_ERROR: 'FORMS::CLEAR_COUPON_ERROR',
  FOCUS_GIFT_BOX :'MINI_CART::FOCUS_GIFT_BOX',
  BLUR_GIFT_BOX :'MINI_CART::BLUR_GIFT_BOX'



}


/**
 * ACTIONS
 */
export const actions = {
  addToCart: ( item, history ) => ( { type: types.ADD_TO_CART, item, history } ),
  removeFromCart: ( item ) => ( { type: types.REMOVE_FROM_CART, item } ),
  updateCart: ( item, quantity, history ) => ( { type: types.UPDATE_CART, item, quantity, history } ),
  removeGiftFromCart: ( item, history ) => ( { type: types.REMOVE_GIFT_FROM_CART, item, history } ),
  couponCodeUpdated: ( item, history, fromCheckout ) => ( { type: types.COUPON_CODE, item, history, fromCheckout } ),
  couponCodeRemoved: ( history, fromCheckout ) => ( { type: types.COUPON_CODE_REMOVED, history, fromCheckout } ),
  openCart: () => ( { type: types.OPEN_CART } ),
  setGiftMessage: ( text ) => ( { type: types.SET_GIFT_MESSAGE, text } ),
  setGiftBoxToggleStatus: ( status ) => ( { type: types.SET_GIFT_BOX_TOGGLE_STATE, status } ),
  setShowBagSummaryStatus: ( status ) => ( { type: types.SHOW_BAG_SUMMARY, status } ),
  setProductSample: ( catalogId ) => ( { type: types.SET_PRODUCT_SAMPLE, catalogId } ),
  setCartRightPanelCollapse: ( panelID ) => ( { type: types.CART_RIGHT_PANEL_COLLAPSE, panelID } ),
  setChkoutBtnStatus: ( status ) => ( { type: types.SET_CHKOUT_BTN_STATE, status } ),
  selectProductSampleService: ( catalogID, quantity, history ) => ( { type: types.SELECT_PRODUCT_SAMPLE_SERVICE, catalogID, quantity, history } ),
  removeProductSampleService: ( history ) => ( { type: types.REMOVE_PRODUCT_SAMPLE_SERVICE, history } ),
  setCouponOfferReqMet: ( status ) => ( { type: types.SET_COUPON_OFFER_REQ, status } ),
  selectGiftVariant: ( promotionid, skuid, history ) => ( { type: types.SELECT_GIFT_VARIANT, promotionid, skuid, history } ),
  setGiftWrapGiftNoteService: ( giftNote, history ) => ( { type: types.SET_GIFT_WRAP_GIFT_NOTE_SERVICE, giftNote, history } ),
  setGiftWrapGiftBoxService: ( giftboxStatus, history ) => ( { type: types.SET_GIFT_WRAP_GIFT_BOX_SERVICE, giftboxStatus, history } ),
  initiateCheckout: ( data ) => ( { type: types.INITIATE_CHECKOUT, data } ),
  resetCheckoutEligibility: () => ( { type: types.RESET_CHECKOUT_ELIGIBILITY } ),
  getPaypalResponse: ( info ) => ( { type: types.GET_PAYPAL_RESPONSE, info } ),
  hideOutOfStockItems: ( ) => ( { type: types.HIDE_OUT_OF_STOCK_PANEL } ),
  focusGiftBox: ( ) => ( { type: types.FOCUS_GIFT_BOX } ),
  blurGiftBox: ( ) => ( { type: types.BLUR_GIFT_BOX } )
}
