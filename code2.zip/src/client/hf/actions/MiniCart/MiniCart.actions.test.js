/**
 * Test for MiniCart actions
 */
import { types, actions } from './MiniCart.actions';
import _ from 'lodash';
describe( 'MiniCart action types', () => {

  describe( 'Open LoadCart', () => {

    it( 'The action type should exist', () => {
      expect( types.OPEN_CART ).toBe( 'MINI_CART::OPEN_CART' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.openCart ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = actions.openCart();
      expect( creator ).toEqual( {
        type: types.OPEN_CART
      } )
    } );
  } );

  describe( 'addToCart', () => {

    it( 'The action type should exist', () => {
      expect( types.ADD_TO_CART ).toBe( 'MINI_CART::ADD_TO_CART' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.addToCart ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let item = '43243534543';
      let history='123243535';
      let creator = actions.addToCart( item, history );
      expect( creator ).toEqual( {
        type: types.ADD_TO_CART,
        history,
        item
      } )
    } );
  } );
  describe( 'Update LoadCart', () => {

    it( 'The action type should exist', () => {
      expect( types.UPDATE_CART ).toBe( 'MINI_CART::UPDATE_CART' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.updateCart ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let item = 'a1234567';
      let history = '1234'
      let quantity = '2';
      let creator = actions.updateCart( item, quantity, history );
      expect( creator ).toEqual( {
        type: types.UPDATE_CART,
        item,
        quantity,
        history
      } )
    } );
  } );
  describe( 'Remove from cart', () => {

    it( 'The action type should exist', () => {
      expect( types.REMOVE_FROM_CART ).toBe( 'MINI_CART::REMOVE_FROM_CART' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.removeFromCart ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let item = { title: 'test', price: '$2231.22' };
      let creator = actions.removeFromCart( item );
      expect( creator ).toEqual( {
        type: types.REMOVE_FROM_CART,
        item
      } )
    } );
  } );
  describe( 'Remove Gift from cart', () => {
    it( 'The action type should exist', () => {
      expect( types.REMOVE_GIFT_FROM_CART ).toBe( 'MINI_CART::REMOVE_GIFT_FROM_CART' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.removeGiftFromCart ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let item = '43243534543';
      let history ='123243535';
      let creator = actions.removeGiftFromCart( item, history );
      expect( creator ).toEqual( {
        type: types.REMOVE_GIFT_FROM_CART,
        history,
        item
      } )
    } );
  } );

  describe( 'Coupon code applied', () => {
    it( 'The action type should exist', () => {
      expect( types.COUPON_CODE ).toBe( 'MINI_CART::COUPON_CODE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.couponCodeUpdated ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let item = '43243534543';
      let creator = actions.couponCodeUpdated( item );
      expect( creator ).toEqual( {
        type: types.COUPON_CODE,
        item
      } )
    } );
  } );
  describe( 'Coupon code removed', () => {
    it( 'The action type should exist', () => {
      expect( types.COUPON_CODE_REMOVED ).toBe( 'MINI_CART::COUPON_CODE_REMOVED' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.couponCodeRemoved ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = actions.couponCodeRemoved( );
      expect( creator ).toEqual( {
        type: types.COUPON_CODE_REMOVED
      } )
    } );
  } );
  describe( 'Coupon Offer requirements not met', () => {
    it( 'The action type should exist', () => {
      expect( types.SET_COUPON_OFFER_REQ ).toBe( 'MINI_CART::SET_COUPON_OFFER_REQ' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setCouponOfferReqMet ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let status=true;
      let creator = actions.setCouponOfferReqMet( status );
      expect( creator ).toEqual( {
        type: types.SET_COUPON_OFFER_REQ,
        status
      } )
    } );
  } );
  describe( 'select Gift variant', () => {

    it( 'The action type should exist', () => {
      expect( types.SELECT_GIFT_VARIANT ).toBe( 'MINI_CART::SELECT_GIFT_VARIANT' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.selectGiftVariant ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let promotionid = '43243534543';
      let skuid = '43243534543';
      let history ='123243535';
      let creator = actions.selectGiftVariant( promotionid, skuid, history );
      expect( creator ).toEqual( {
        type: types.SELECT_GIFT_VARIANT,
        history,
        promotionid,
        skuid
      } )
    } );
  } );
  describe( 'Set Gift Message', () => {
    it( 'The action type should exist', () => {
      expect( types.SET_GIFT_MESSAGE ).toBe( 'MINI_CART::SET_GIFT_MESSAGE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setGiftMessage ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let text = { giftText: 'GiftWrap Selected' };
      let creator = actions.setGiftMessage( text );
      expect( creator ).toEqual( {
        type: types.SET_GIFT_MESSAGE,
        text
      } )
    } );
  } );
  describe( 'Set Gift Box Toggle Status', () => {
    it( 'The action type should exist', () => {
      expect( types.SET_GIFT_BOX_TOGGLE_STATE ).toBe( 'MINI_CART::SET_GIFT_BOX_TOGGLE_STATE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setGiftBoxToggleStatus ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let status = { giftBoxToggle: true };
      let creator = actions.setGiftBoxToggleStatus( status );
      expect( creator ).toEqual( {
        type: types.SET_GIFT_BOX_TOGGLE_STATE,
        status
      } )
    } );
  } );
  describe( 'Set check out button Status', () => {
    it( 'The action type should exist', () => {
      expect( types.SET_CHKOUT_BTN_STATE ).toBe( 'MINI_CART::SET_CHKOUT_BTN_STATE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setChkoutBtnStatus ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let status = { chkoutbtnClk: true };
      let creator = actions.setChkoutBtnStatus( status );
      expect( creator ).toEqual( {
        type: types.SET_CHKOUT_BTN_STATE,
        status
      } )
    } );
  } );
  describe( 'Set Header Bag Summary Status', () => {
    it( 'The action type should exist', () => {
      expect( types.SHOW_BAG_SUMMARY ).toBe( 'MINI_CART::SHOW_BAG_SUMMARY' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setShowBagSummaryStatus ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let status = { showBagSummary: true };
      let creator = actions.setShowBagSummaryStatus( status );
      expect( creator ).toEqual( {
        type: types.SHOW_BAG_SUMMARY,
        status
      } )
    } );
  } );
  describe( 'Select Product Sample', () => {
    it( 'The action type should exist', () => {
      expect( types.SELECT_PRODUCT_SAMPLE_SERVICE ).toBe( 'MINI_CART::SELECT_PRODUCT_SAMPLE_SERVICE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.selectProductSampleService ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let catalogID = '12345';
      let quantity = '2';
      let history = '1234678' ;
      let creator = actions.selectProductSampleService( catalogID, quantity, history );
      expect( creator ).toEqual( {
        type: types.SELECT_PRODUCT_SAMPLE_SERVICE,
        catalogID,
        quantity,
        history
      } )
    } );
  } );
  describe( 'Remove Product Sample', () => {
    it( 'The action type should exist', () => {
      expect( types.REMOVE_PRODUCT_SAMPLE_SERVICE ).toBe( 'MINI_CART::REMOVE_PRODUCT_SAMPLE_SERVICE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.removeProductSampleService ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let history = '1234678' ;
      let creator = actions.removeProductSampleService( history );
      expect( creator ).toEqual( {
        type: types.REMOVE_PRODUCT_SAMPLE_SERVICE,
        history
      } )
    } );
  } );
  describe( 'Set Cart Page Right Panel Collapse', () => {
    it( 'The action type should exist', () => {
      expect( types.CART_RIGHT_PANEL_COLLAPSE ).toBe( 'MINI_CART::CART_RIGHT_PANEL_COLLAPSE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setCartRightPanelCollapse ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let panelID = 'gifts' ;
      let creator = actions.setCartRightPanelCollapse( panelID );
      expect( creator ).toEqual( {
        type: types.CART_RIGHT_PANEL_COLLAPSE,
        panelID
      } )
    } );
  } );
  describe( 'setGiftWrapGiftNoteService', () => {
    it( 'The action type should exist', () => {
      expect( types.SET_GIFT_WRAP_GIFT_NOTE_SERVICE ).toBe( 'MINI_CART::SET_GIFT_WRAP_GIFT_NOTE_SERVICE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setGiftWrapGiftNoteService ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let giftNote = 'Happy Birthday Teja' ;
      let history = '12345';
      let creator = actions.setGiftWrapGiftNoteService( giftNote, history );
      expect( creator ).toEqual( {
        type: types.SET_GIFT_WRAP_GIFT_NOTE_SERVICE,
        giftNote,
        history
      } )
    } );
  } );

  describe( 'focusGiftBox', () => {
    it( 'The action type should exist', () => {
      expect( types.FOCUS_GIFT_BOX ).toBe( 'MINI_CART::FOCUS_GIFT_BOX' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.focusGiftBox ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = actions.focusGiftBox();
      expect( creator ).toEqual( {
        type: types.FOCUS_GIFT_BOX
      } )
    } );
  } );

  describe( 'blurGiftBox', () => {
    it( 'The action type should exist', () => {
      expect( types.BLUR_GIFT_BOX ).toBe( 'MINI_CART::BLUR_GIFT_BOX' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.blurGiftBox ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = actions.blurGiftBox();
      expect( creator ).toEqual( {
        type: types.BLUR_GIFT_BOX
      } )
    } );
  } );

  describe( 'setProductSample', () => {
    it( 'The action type should exist', () => {
      expect( types.SET_PRODUCT_SAMPLE ).toBe( 'MINI_CART::SET_PRODUCT_SAMPLE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setProductSample ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const catalogId = '12345';
      const creator = actions.setProductSample( catalogId );
      expect( creator ).toEqual( {
        type: types.SET_PRODUCT_SAMPLE,
        catalogId
      } )
    } );
  } );

  describe( 'setGiftWrapGiftBoxService', () => {
    it( 'The action type should exist', () => {
      expect( types.SET_GIFT_WRAP_GIFT_BOX_SERVICE ).toBe( 'MINI_CART::SET_GIFT_WRAP_GIFT_BOX_SERVICE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setGiftWrapGiftBoxService ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const giftboxStatus = jest.fn();
      const creator = actions.setGiftWrapGiftBoxService( giftboxStatus, history );
      expect( creator ).toEqual( {
        type: types.SET_GIFT_WRAP_GIFT_BOX_SERVICE,
        giftboxStatus,
        history
      } )
    } );
  } );

  describe( 'initiateCheckout', () => {
    it( 'The action type should exist', () => {
      expect( types.INITIATE_CHECKOUT ).toBe( 'MINI_CART::INITIATE_CHECKOUT' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.initiateCheckout ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const creator = actions.initiateCheckout();
      expect( creator ).toEqual( {
        type: types.INITIATE_CHECKOUT
      } )
    } );
  } );

  describe( 'resetCheckoutEligibility', () => {
    it( 'The action type should exist', () => {
      expect( types.RESET_CHECKOUT_ELIGIBILITY ).toBe( 'MINI_CART::RESET_CHECKOUT_ELIGIBILITY' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.resetCheckoutEligibility ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const creator = actions.resetCheckoutEligibility();
      expect( creator ).toEqual( {
        type: types.RESET_CHECKOUT_ELIGIBILITY
      } )
    } );
  } );

  describe( 'getPaypalResponse', () => {
    it( 'The action type should exist', () => {
      expect( types.GET_PAYPAL_RESPONSE ).toBe( 'MINI_CART::GET_PAYPAL_RESPONSE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.getPaypalResponse ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const creator = actions.getPaypalResponse();
      expect( creator ).toEqual( {
        type: types.GET_PAYPAL_RESPONSE
      } )
    } );
  } );

  describe( 'hideOutOfStockItems', () => {
    it( 'The action type should exist', () => {
      expect( types.HIDE_OUT_OF_STOCK_PANEL ).toBe( 'MINI_CART::HIDE_OUT_OF_STOCK_PANEL' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.hideOutOfStockItems ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const creator = actions.hideOutOfStockItems();
      expect( creator ).toEqual( {
        type: types.HIDE_OUT_OF_STOCK_PANEL
      } )
    } );
  } );
} );
