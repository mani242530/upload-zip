/**
 * MobileLeftNav Actions
 *
 * This file defines the action types and action creators for 'MobileLeftNav'
 **/


/**
 * ACTION TYPES
 */
export const types = {

  SET_MOBILE_LEFT_NAV_DIMENSIONS: 'MOBILE_LEFT_NAV::SET_MOBILE_LEFT_NAV_DIMENSIONS',
  TOGGLE_LEFT_NAV: 'MOBILE_LEFT_NAV::TOGGLE_LEFT_NAV',
  OPEN_REWARDS: 'MOBILE_LEFT_NAV::OPEN_REWARDS',
  SET_ACTIVE_LEVEL: 'MOBILE_LEFT_NAV::SET_ACTIVE_LEVEL'
}



/**
 * ACTIONS
 */
export const actions = {

  setMobileLeftNavDimensions: ( width, height ) => ( { type: types.SET_MOBILE_LEFT_NAV_DIMENSIONS, width, height } ),

  setActiveLevel: ( level, index ) => ( { type: types.SET_ACTIVE_LEVEL, level, index } ),

  toggleLeftNav: ( mode ) => ( { type: types.TOGGLE_LEFT_NAV, mode } ),

  openRewards: ( ) => ( { type: types.OPEN_REWARDS } )

}
