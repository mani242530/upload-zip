/**
 * Test for MobileLeftNav actions
 */

import { types, actions } from './MobileLeftNav.actions';
import _ from 'lodash';

describe( 'MobileLeftNav action types', () => {

  describe( 'Set Mobile Left Nav Dimensions', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_MOBILE_LEFT_NAV_DIMENSIONS ).toBe( 'MOBILE_LEFT_NAV::SET_MOBILE_LEFT_NAV_DIMENSIONS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setMobileLeftNavDimensions ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = actions.setMobileLeftNavDimensions( 1257, 333 );
      expect( creator ).toEqual( {
        type: types.SET_MOBILE_LEFT_NAV_DIMENSIONS,
        width: 1257,
        height: 333
      } )
    } );
  } );

  describe( 'Toggle Left Nav', () => {

    it( 'The action type should exist', () => {
      expect( types.TOGGLE_LEFT_NAV ).toBe( 'MOBILE_LEFT_NAV::TOGGLE_LEFT_NAV' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.toggleLeftNav ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = actions.toggleLeftNav( 2403 );
      expect( creator ).toEqual( {
        type: types.TOGGLE_LEFT_NAV,
        mode: 2403
      } )
    } );
  } );

  describe( 'Open Rewards', () => {

    it( 'The action type should exist', () => {
      expect( types.OPEN_REWARDS ).toBe( 'MOBILE_LEFT_NAV::OPEN_REWARDS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.openRewards ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = actions.openRewards();
      expect( creator ).toEqual( {
        type: types.OPEN_REWARDS
      } )
    } );
  } );

  describe( 'Set Active Level', () => {

    it( 'The action type should exist', () => {
      expect( types.SET_ACTIVE_LEVEL ).toBe( 'MOBILE_LEFT_NAV::SET_ACTIVE_LEVEL' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( actions.setActiveLevel ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      var level = [];
      var index =  0;
      let creator = actions.setActiveLevel( level, index );
      expect( creator ).toEqual( {
        type: types.SET_ACTIVE_LEVEL,
        level,
        index
      } )
    } );
  } );

} );
