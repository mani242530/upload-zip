/**
 * TypeAheadSearch Actions
 *
 * This file defines the action types and action creators for 'TypeAheadSearch'
 **/


/**
 * ACTION TYPES
 */
export const types = {
  RESET_INPUT_VALUE: 'TYPE_AHEAD_SEARCH::RESET_INPUT_VALUE',
  SET_INPUT_WIDTH: 'TYPE_AHEAD_SEARCH::SET_INPUT_WIDTH',
  UPDATE_INPUT_VALUE: 'TYPE_AHEAD_SEARCH::UPDATE_INPUT_VALUE',
  CLEAR_SUGGESTIONS: 'TYPE_AHEAD_SEARCH::CLEAR_SUGGESTIONS',
  SET_SEARCH_RESULTS_HEIGHT: 'TYPE_AHEAD_SEARCH::SET_SEARCH_RESULTS_HEIGHT',

  LOAD_SUGGESTIONS_BEGIN: 'TYPE_AHEAD_SEARCH::LOAD_SUGGESTIONS_BEGIN',

  MAYBE_UPDATE_SUGGESTIONS: 'TYPE_AHEAD_SEARCH::MAYBE_UPDATE_SUGGESTIONS',

  REQUEST_SEARCH_RESULTS: 'TYPE_AHEAD_SEARCH::REQUEST_SEARCH_RESULTS',
  UPDATE_NAVIGATION_STATE_URL: 'TYPE_AHEAD_SEARCH::UPDATE_NAVIGATION_STATE_URL'
}


/**
 * ACTIONS
 */
export const actions = {

  setSearchResultsHeight: ( offset, screenHeight ) => ( { type: types.SET_SEARCH_RESULTS_HEIGHT, offset, screenHeight } ),

  setInputWidth: ( cancelBtnWidth, containerWidth, deviceWidth ) => ( { type:types.SET_INPUT_WIDTH, cancelBtnWidth, containerWidth, deviceWidth } ),

  updateInputValue: ( value ) => ( { type: types.UPDATE_INPUT_VALUE, value } ),

  requestSearchResults: ( query ) => ( { type: types.REQUEST_SEARCH_RESULTS, query } ),

  onSuggestionsClearRequested: () => ( { type: types.CLEAR_SUGGESTIONS } ),

  resetSearchInputValue: () => ( { type: types.RESET_INPUT_VALUE } ),

  navigationStateURL: ( data, label ) => ( { type: types.UPDATE_NAVIGATION_STATE_URL, data, label } )

}
