/**
 * Test for TypeAheadSearch actions
 */

import { types, actions } from './TypeAheadSearch.actions';
import _ from 'lodash';




describe( 'TypeAheadSearch action types', () => {
  it( 'expect all types to be defined', () => {
    expect( types.RESET_INPUT_VALUE ).toBe( 'TYPE_AHEAD_SEARCH::RESET_INPUT_VALUE' );
    expect( types.SET_INPUT_WIDTH ).toBe( 'TYPE_AHEAD_SEARCH::SET_INPUT_WIDTH' );
    expect( types.UPDATE_INPUT_VALUE ).toBe( 'TYPE_AHEAD_SEARCH::UPDATE_INPUT_VALUE' );
    expect( types.CLEAR_SUGGESTIONS ).toBe( 'TYPE_AHEAD_SEARCH::CLEAR_SUGGESTIONS' );
    expect( types.SET_SEARCH_RESULTS_HEIGHT ).toBe( 'TYPE_AHEAD_SEARCH::SET_SEARCH_RESULTS_HEIGHT' );
    expect( types.LOAD_SUGGESTIONS_BEGIN ).toBe( 'TYPE_AHEAD_SEARCH::LOAD_SUGGESTIONS_BEGIN' );
    expect( types.MAYBE_UPDATE_SUGGESTIONS ).toBe( 'TYPE_AHEAD_SEARCH::MAYBE_UPDATE_SUGGESTIONS' );
    expect( types.REQUEST_SEARCH_RESULTS ).toBe( 'TYPE_AHEAD_SEARCH::REQUEST_SEARCH_RESULTS' );
    expect( types.UPDATE_NAVIGATION_STATE_URL ).toBe( 'TYPE_AHEAD_SEARCH::UPDATE_NAVIGATION_STATE_URL' );
  } );
} );

describe( 'TypeAhead actions', () => {

  it( 'sould have action creators defined', () => {
    expect( _.isFunction( actions.setSearchResultsHeight ) ).toBe( true );
    expect( _.isFunction( actions.setInputWidth ) ).toBe( true );
    expect( _.isFunction( actions.updateInputValue ) ).toBe( true );
    expect( _.isFunction( actions.requestSearchResults ) ).toBe( true );
    expect( _.isFunction( actions.onSuggestionsClearRequested ) ).toBe( true );
    expect( _.isFunction( actions.resetSearchInputValue ) ).toBe( true );
    expect( _.isFunction( actions.navigationStateURL ) ).toBe( true );
  } );

  it( 'should create the proper action for setSearchResultsHeight', () => {
    let creator = actions.setSearchResultsHeight( 11, 0 );
    expect( creator ).toEqual( {
      type: types.SET_SEARCH_RESULTS_HEIGHT,
      offset: 11,
      screenHeight: 0
    } )
  } );

  it( 'should create the proper action for setInputWidth', () => {
    let creator = actions.setInputWidth( 11, 0, 321 );
    expect( creator ).toEqual( {
      type: types.SET_INPUT_WIDTH,
      cancelBtnWidth: 11,
      containerWidth: 0,
      deviceWidth: 321
    } )
  } );

  it( 'should create the proper action for updateInputValue', () => {
    let creator = actions.updateInputValue( 'newValue' );
    expect( creator ).toEqual( {
      type: types.UPDATE_INPUT_VALUE,
      value: 'newValue'
    } )
  } );

  it( 'should create the proper action for requestSearchResults', () => {
    let creator = actions.requestSearchResults( 'abc' );
    expect( creator ).toEqual( {
      type: types.REQUEST_SEARCH_RESULTS,
      query: 'abc'
    } )
  } );

  it( 'should create the proper action for onSuggestionsClearRequested', () => {
    let creator = actions.onSuggestionsClearRequested();
    expect( creator ).toEqual( {
      type: types.CLEAR_SUGGESTIONS
    } )
  } );

  it( 'should create the proper action for resetSearchInputValue', () => {
    let creator = actions.resetSearchInputValue();
    expect( creator ).toEqual( {
      type: types.RESET_INPUT_VALUE
    } )
  } );

  it( 'should create the proper action for navigationStateURL', () => {
    let creator = actions.navigationStateURL( '/nails?N=271o', 'MakeUp > lipstick' );
    expect( creator ).toEqual( {
      type: types.UPDATE_NAVIGATION_STATE_URL,
      data: '/nails?N=271o',
      label: 'MakeUp > lipstick'
    } )
  } );

} );

