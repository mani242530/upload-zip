/**
 * Footer
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import MobileFooter from 'hf/components/Footers/mobile/MobileFooter/MobileFooter';
import DesktopFooter from 'hf/components/Footers/Desktop/DesktopFooter/DesktopFooter';
import {
  actions as footerActions
} from 'hf/actions/Footer/Footer.actions';

import {
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

const defaultProps = {
  displayShippingPolicy: false
}

class Footer extends Component{

  render(){

    let hasLeftNav;

    if( this.props.isMobileDevice ){
      hasLeftNav = false;
    }
    else if( this.props.desktopFooterDisplayMode === 'default' ){
      hasLeftNav = true;
    }
    else {
      hasLeftNav = false;
    }

    return (
      <div className='Footer'>
        { this.props.isMobileDevice &&
          <MobileFooter
            { ...this.props }
            hasLeftNav={ hasLeftNav }
          />
        }

        { !this.props.isMobileDevice &&
          <DesktopFooter
            { ...this.props }
            hasLeftNav={ hasLeftNav }
          />
        }

      </div>
    );
  }
}
export const mapStateToProps = state => {
  return {
    ...state.global,
    ...state.footer,
    ...state.user,
    ...state.pagedata
  }
}

export const mapDispatchToProps  =  dispatch => {
  return {
    setActiveFooterNavCollapse: ( panelID ) => {
      dispatch( footerActions.setActiveFooterNavCollapse( panelID ) );
    }
  }
}

// this is to mock the data for test cases
export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( Footer ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );
