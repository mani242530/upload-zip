import React from 'react';
import { shallow } from 'enzyme';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import Footer, { mapStateToProps, mapDispatchToProps } from './Footer';
import device from 'utils/DeviceDetection/deviceDetection';
import { actions as footerActions
} from 'hf/actions/Footer/Footer.actions';



const dispatch = jest.fn();
const state = jest.fn();
const store = configureStore( {}, CONFIG );
const component = mountWithIntl(
  <Provider store={ store }>
    <Footer />
  </Provider>
);

describe( '<Footer />', () => {
  it( 'renders without crashing', () => {
    const component = mountWithIntl(
      <Provider store={ store }>
        <Footer />
      </Provider>
    );
    expect( component.find( 'Footer' ).length ).toBe( 1 );
  } );

  it( 'renders DesktopFooter when isMobileDevice is false', () => {
    store.getState().global.isMobileDevice = false;
    expect( component.find( 'DesktopFooter' ).length ).toBe( 1 );
  } );

  it( 'renders MobileFooter when isMobileDevice is true', () => {

    store.getState().global.isMobileDevice = true;
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <Footer />
      </Provider>
    );
    expect( component1.find( 'MobileFooter' ).length ).toBe( 1 );
  } );

  it( 'setActiveFooterNavCollapse should dispatch the proper action', () => {
    const mdp  = mapDispatchToProps( dispatch );
    const event = mdp.setActiveFooterNavCollapse( 'test1' );
    expect( dispatch ).toHaveBeenCalledWith( footerActions.setActiveFooterNavCollapse( 'test1' ) );
  } );
} );
