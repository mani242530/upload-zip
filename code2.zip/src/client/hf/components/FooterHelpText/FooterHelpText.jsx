/**
 * FooterHelpText
 */

import React from 'react';
import PropTypes from 'prop-types';
import './FooterHelpText.css';
import Anchor from 'shared/components/Anchor/Anchor';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './FooterHelpText.messages';


const propTypes = {
  hoursOfOperation:PropTypes.string,
  serviceNumber: PropTypes.string
}

const FooterHelpText = ( props ) => {

  let numberUrl = `tel:+${props.serviceNumber}`;
  return (
    <div className='FooterHelpText'>
      <div className='MobileFooterTandC__help'>
        <span>{ formatMessage( messages.helpMessage ) }</span>
        <Anchor
          className='MobileFooterTandC__help MobileFooterTandC__help__link'
          url='/ulta/guestservices/#contact-us'
        >
          { formatMessage( messages.helpLink ) }
        </Anchor>
        <span className='MobileFooterTandC__help__ends'>
          { formatMessage( messages.helpMessageEnds ) }:
        </span>
      </div>

      <p>
        <span className='MobileFooterTandC__hoursOfOperation'>
          { formatMessage( messages.time, { hours:props.hoursOfOperation } ) }</span>
        <span className='MobileFooterTandC__terms__space'>|</span>
        <Anchor
          className='MobileFooterTandC__help MobileFooterTandC__help__link MobileFooterTandC__help__number'
          url={ numberUrl }
        >
          { props.serviceNumber }
        </Anchor>
      </p>
    </div>
  );

}

FooterHelpText.propTypes = propTypes;

export default FooterHelpText;
