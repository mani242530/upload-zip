/*
 * FooterHelpText Messages
 *
 * This contains all the text for the FooterHelpText component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  helpMessage: {
    id: 'i18n.MobileFooterTandC.helpMessage',
    defaultMessage: 'We\'re here to'
  },
  helpLink: {
    id: 'i18n.MobileFooterTandC.helpLink',
    defaultMessage: 'help'
  },
  helpMessageEnds: {
    id: 'i18n.MobileFooterTandC.helpMessageEnds',
    defaultMessage: 'every day'
  },
  time: {
    id: 'i18n.MobileFooterTandC.time',
    defaultMessage: '{hours} CT'
  },
  number: {
    id: 'i18n.MobileFooterTandC.number',
    defaultMessage: '866-983-8582'
  }
} );
