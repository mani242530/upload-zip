import React from 'react';
import ReactDOM from 'react-dom';
import FooterHelpText from './FooterHelpText';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './FooterHelpText.messages';

describe( '<FooterHelpText />', () => {
  let props = {
    hoursOfOperation:'7am-11pm',
    serviceNumber :'1-866-983-8582'
  }
  let component = mountWithIntl( <FooterHelpText { ...props }/> );
  let container = component.find( 'FooterHelpText' );
  it( 'renders without crashing', () => {
    expect( component.find( 'FooterHelpText' ).length ).toBe( 1 );
  } );
  it( 'renders correct message for help number', () => {
    let TandC = container.find( 'Anchor' ).at( 0 );
    expect( TandC.text() ).toEqual( messages.helpLink.defaultMessage )
  } );
  it( 'renders correct number for help number', () => {
    let TandC = container.find( 'Anchor' ).at( 1 );
    let number = '1-866-983-8582'
    expect( TandC.text() ).toEqual( number );
  } );
  it( 'renders correct message for hours of operation', () => {

    let TandC = component.find( '.MobileFooterTandC__hoursOfOperation' );
    let message='7am-11pm CT';
    expect( TandC.text() ).toEqual( message );
  } );

} );
