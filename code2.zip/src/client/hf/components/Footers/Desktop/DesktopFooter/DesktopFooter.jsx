/**
 * DesktopFooter
 */

import React from 'react';
import './DesktopFooter.css';
import { formatMessage } from 'shared/components/Global/Global';
import BaseLayout from 'shared/components/BaseLayout/BaseLayout';
import messages from './DesktopFooter.messages';
import Anchor from 'shared/components/Anchor/Anchor';
import Divider from 'shared/components/Divider/Divider';
import FooterHelpText from 'hf/components/FooterHelpText/FooterHelpText';
import Image from 'shared/components/Image/Image';
import { formatOmnitureAttr } from 'utils/Omniture/Omniture';
import { host } from 'utils/Formatters/formatters';
import classNames from 'classnames';


/**
 * Renders the rewards links
 * this function is used to eliminate duplication of this code
 * we are rendering almost the exact code in two different locations
 * based on window.innerWidth
 * @param {string} classNameToAdd - A string that describes an optional additional className that should be added to .DesktopFooter__linkColumnHeader
 */
export const renderRewardsLinks = ( props, classNameToAdd = '' ) => {




  const {
    switchData
  } = props

  return (
    <div className='DesktopFooter__rewardsContainer'>
      <div className={
        classNames( {
          'DesktopFooter__linkColumnHeader': true,
          [`${classNameToAdd}`]: classNameToAdd !== ''
        } )
      }
      >
        { formatMessage( messages.ultamate ) }
      </div>


      <Anchor
        url={ switchData && switchData.switches && switchData.switches.learnMoreURL }
        dataNavDescription={ formatOmnitureAttr( 'f', 'learn more & apply' ) }
      >
        { formatMessage( messages.learn ) }
      </Anchor>
      <Anchor
        url={ switchData && switchData.switches && switchData.switches.genericADSUrl }
        target='_blank'
        dataNavDescription={ formatOmnitureAttr( 'f', 'manage account' ) }
      >
        { formatMessage( messages.manageAccount ) }
      </Anchor>
    </div>
  )
}

const DesktopFooter = ( props ) => {



  const {
    setActiveFooterNavCollapse,
    footerNavCollapse,
    switchData,
    hasLeftNav,
    desktopFooterDisplayMode
  } = props;

  let imageURL, americanFlagImageURL, canadianFlagImageURL = '#';

  if( switchData && switchData.switches && switchData.switches.staticContentDomain && switchData.switches.staticContentImgPath ){
    const staticDomain = switchData.switches.staticContentDomain;
    const staticPath = switchData.switches.staticContentImgPath;

    const baseImageUrl = `${staticDomain}${staticPath}`

    imageURL = `${baseImageUrl}/footer_cc.png`
    americanFlagImageURL = `${baseImageUrl}/footer-us-flag@2x.png`
    canadianFlagImageURL = `${baseImageUrl}/footer-canada-flag@2x.png`
  }

  return (

    <footer className='DesktopFooter'>

      { ( () => {
        if( desktopFooterDisplayMode === 'default' && switchData && switchData.switches ){

          return (
            <div className='DesktopFooter__topContainer'>
              <BaseLayout hasLeftNav={ hasLeftNav }>
                <div className='DesktopFooter__container'>

                  <div className='DesktopFooter__linksContainer'>

                    <div className={
                      classNames( {
                        'DesktopFooter__linksColumn': true,
                        'DesktopFooter__linksColumn--4column': switchData && switchData.switches && !switchData.switches.enableAcquisitionFLow
                      } )
                    }
                    >

                      <h5 className='DesktopFooter__linkColumnHeader'>
                        { formatMessage( messages.store ) }
                      </h5>

                      <Anchor
                        url={ 'https://' + host + ( switchData && switchData.switches ? switchData.switches.storeLocatorURL : '/ulta/stores/storelocator.jsp' ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'find a location' ) }
                        title={ formatMessage( messages.findLocation ) }
                      >
                        { formatMessage( messages.findLocation ) }
                      </Anchor>

                      <Anchor
                        url={ '/salon/' }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'beauty services' ) }
                        title={ formatMessage( messages.beautyServices ) }
                      >
                        { formatMessage( messages.beautyServices ) }
                      </Anchor>

                      <Anchor
                        url={ '/ulta/global/nav/allbrands.jsp' }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'list of brands' ) }
                        title={ formatMessage( messages.listBrands ) }
                      >
                        { formatMessage( messages.listBrands ) }
                      </Anchor>
                      <Anchor
                        url={ '/ulta/myaccount/learnmore_template.jsp?page=benefits' }
                        title={ formatMessage( messages.ultamateRewards ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'ultamate rewards' ) }
                      >
                        { formatMessage( messages.ultamateRewards ) }
                      </Anchor>

                    </div>

                    <div className='DesktopFooter__linksColumn'>

                      <h5 className='DesktopFooter__linkColumnHeader'>
                        { formatMessage( messages.guestServices ) }
                      </h5>

                      <Anchor
                        url={ '/ulta/guestservices/' }
                        title={ formatMessage( messages.customerSupport ) }
                        dataNavDescription='f - guest services center'
                      >
                        { formatMessage( messages.guestCenter ) }
                      </Anchor>
                      <Anchor
                        url={ '/ulta/myaccount/order.jsp' }
                        title={ formatMessage( messages.orderStatus ) }
                        dataNavDescription='f - order status'
                      >
                        { formatMessage( messages.orderStatus ) }
                      </Anchor>
                      <Anchor
                        url={ '/ulta/guestservices/guestServicesCenterDetails.jsp#ShippingPolicy' }
                        title={ formatMessage( messages.shippingPolicy ) }
                        dataNavDescription='f - shipping policy & rate'
                      >
                        { formatMessage( messages.shippingPolicy ) }
                      </Anchor>
                      <Anchor
                        url={ '/ulta/guestservices/guestServicesCenterDetails.jsp#ReturnPolicy' }
                        title={ formatMessage( messages.returns ) }
                        dataNavDescription='f - returns'
                      >
                        { formatMessage( messages.returns ) }
                      </Anchor>
                      <Anchor
                        url={ '/ulta/guestservices/#contact-us' }
                        title={ formatMessage( messages.contactUs ) }
                        dataNavDescription='f - contact us'
                      >
                        { formatMessage( messages.contactUs ) }
                      </Anchor>

                    </div>

                    <div className={
                      classNames( {
                        'DesktopFooter__linksColumn': true,
                        'DesktopFooter__linksColumn--4column': switchData && switchData.switches && !switchData.switches.enableAcquisitionFLow
                      } )
                    }
                    >

                      <h5 className='DesktopFooter__linkColumnHeader'>
                        { formatMessage( messages.aboutUs ) }
                      </h5>

                      <Anchor
                        url={ '/company/about-us/' }
                        title={ formatMessage( messages.ourCompany ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'our company' ) }
                      >
                        { formatMessage( messages.ourCompany ) }
                      </Anchor>

                      <Anchor
                        url={ 'http://ir.ulta.com/phoenix.zhtml?c=213869&amp;p=irol-irhome' }
                        title={ formatMessage( messages.investorRelations ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'investor relations' ) }
                      >
                        { formatMessage( messages.investorRelations ) }
                      </Anchor>
                      <Anchor
                        url={ '/ulta/common/affiliate.jsp' }
                        title={ formatMessage( messages.affiliates ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'affiliates' ) }
                      >
                        { formatMessage( messages.affiliates ) }
                      </Anchor>

                      <Anchor
                        url={ '/ulta/sitemap.jsp' }
                        title={ formatMessage( messages.siteMap ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'site map' ) }
                      >
                        { formatMessage( messages.siteMap ) }
                      </Anchor>
                      <Anchor
                        url={ '/ulta/common/supply_chain_transparency.jsp' }
                        title={ formatMessage( messages.supplyChain ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'supply chain transparency' ) }
                      >
                        { formatMessage( messages.supplyChain ) }
                      </Anchor>
                      <Anchor
                        url={ '/ulta/common/charitablegiving.jsp' }
                        title={ formatMessage( messages.charitableGiving ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'charitable giving' ) }
                      >
                        { formatMessage( messages.charitableGiving ) }
                      </Anchor>
                      <Anchor
                        url={ 'http://careers.ulta.com' }
                        title={ formatMessage( messages.careers ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'careers' ) }
                      >
                        { formatMessage( messages.careers ) }
                      </Anchor>

                    </div>

                    <div className={
                      classNames( {
                        'DesktopFooter__linksColumn': true,
                        'DesktopFooter__linksColumn--4column': switchData && switchData.switches && !switchData.switches.enableAcquisitionFLow
                      } )
                    }
                    >

                      <h5 className='DesktopFooter__linkColumnHeader'>
                        { formatMessage( messages.services ) }
                      </h5>

                      <Anchor
                        url={ '/giftcards' }
                        title={ formatMessage( messages.giftCards ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'gift cards' ) }
                      >
                        { formatMessage( messages.giftCards ) }
                      </Anchor>

                      <Anchor
                        url='/app/'
                        title={ formatMessage( messages.mobileApp ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'mobile app' ) }
                      >
                        { formatMessage( messages.mobileApp ) }
                      </Anchor>

                      <div className='DesktopFooter__linkColumnHeader DesktopFooter__linkColumnHeader--midColumn'>
                        { formatMessage( messages.beautyCalls ) }
                      </div>

                      <Anchor
                        url={ '/ulta/common/sms-text.jsp' }
                        title={ formatMessage( messages.getTextAlerts ) }
                        dataNavDescription={ formatOmnitureAttr( 'f', 'get text alerts' ) }
                      >
                        { formatMessage( messages.getTextAlerts ) }
                      </Anchor>

                      { ( ()=>{
                        if( switchData && switchData.switches && switchData.switches.enableIntlShipping ){
                          return (
                            <div>
                              <div className='DesktopFooter__linkColumnHeader DesktopFooter__linkColumnHeader--midColumn' >
                                { formatMessage( messages.shipTo ) }
                              </div>
                              <Anchor
                                url='/'
                                title={ formatMessage( messages.us ) }
                                className='DesktopFooter__shipTo DesktopFooter__shipTo--leftSide DesktopFooter__shipTo--active'
                                dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.us ) ) }
                              >
                                <Image
                                  src={ americanFlagImageURL }
                                  alt='American flag image'
                                />
                                <div className='DesktopFooter__shipToCountry'>
                                  { formatMessage( messages.us ) }
                                </div>
                              </Anchor>
                              <Anchor
                                url={ '//global.ulta.com/' }
                                title={ formatMessage( messages.canada ) }
                                className='DesktopFooter__shipTo'
                                dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.canada ) ) }
                              >
                                <Image
                                  src={ canadianFlagImageURL }
                                  alt='Canadian flag image'
                                />
                                <div className='DesktopFooter__shipToCountry'>
                                  { formatMessage( messages.canada ) }
                                </div>
                              </Anchor>
                            </div>
                          )
                        }
                      } )() }

                      { ( () => {
                        if( global.innerWidth <= 1199 && switchData && switchData.switches && switchData.switches.enableAcquisitionFLow ){
                          let classNameToAdd = ' DesktopFooter__linkColumnHeader--midColumn'
                          return renderRewardsLinks( props, classNameToAdd )
                        }
                      } )() }

                    </div>

                    { ( () => {
                      if( global.innerWidth > 1199 && switchData && switchData.switches && switchData.switches.enableAcquisitionFLow ){
                        let imageURL = '#';
                        if( switchData && switchData.switches && switchData.switches.staticContentDomain && switchData.switches.staticContentImgPath ){
                          const staticDomain = switchData.switches.staticContentDomain;
                          const staticPath = switchData.switches.staticContentImgPath;
                          imageURL = `${staticDomain}${staticPath}/footer_cc.png`
                        }
                        return (
                          <div className='DesktopFooter__linksColumn'>

                            { renderRewardsLinks( props ) }

                            <div className='DesktopFooter__rewardsMarketingCallout'>

                              <Anchor
                                url={ '/ulta/creditcards/landingpage.jsp' }
                                dataNavDescription={ formatOmnitureAttr( 'f', 'earn even more points  plus 20% off your next purchase' ) }
                              >
                                <Image
                                  src={ imageURL }
                                  alt='Footer CC'
                                  width={ 66 }
                                  height={ 42 }
                                />

                                <div
                                  className='DesktopFooter__rewardsText'
                                >
                                  { formatMessage( messages.earnMore ) }
                                </div>

                              </Anchor>

                            </div>

                          </div>
                        )
                      }
                    } )() }

                  </div>

                </div>
              </BaseLayout>
            </div>
          )

        }
      } )() }

      { ( ()=>{
        if( desktopFooterDisplayMode === 'customerService' ){
          return (
            <Divider dividerType='multi-color'/>
          )
        }
      } )() }

      { ( ()=>{
        if( desktopFooterDisplayMode === 'customerService' && switchData && switchData.switches ){
          return (
            <FooterHelpText
              hoursOfOperation={ props.switchData.switches.guestServiceHours }
              serviceNumber={ props.switchData.switches.guestServiceNumber }
            />
          )
        }
      } )() }

      { ( ()=>{
        if( desktopFooterDisplayMode !== 'none' ){
          return (
            <BaseLayout hasLeftNav={ hasLeftNav }>
              <div className='DesktopFooter__bottomContainer'>
                <div className='DesktopFooter__smallText'>

                  <div className='DesktopFooterTandC__terms'>
                    <Anchor

                      url={ '/ulta/common/user_agreement.jsp' }
                      title={ formatMessage( messages.terms ) }
                      dataNavDescription={ formatOmnitureAttr( 'f', 'terms & coconditions' ) }
                    >
                      { formatMessage( messages.terms ) }
                    </Anchor>

                    <div className='DesktopFooterTandC__terms__spacer'>|</div>

                    <Anchor
                      url={ '/ulta/common/privacyPolicy.jsp' }
                      title={ formatMessage( messages.privacy ) }
                      dataNavDescription={ formatOmnitureAttr( 'f', 'privacy policy' ) }
                    >
                      { formatMessage( messages.privacy ) }
                    </Anchor>

                    <div className='DesktopFooterTandC__terms__spacer'>|</div>

                    <Anchor
                      url={ '/ulta/common/privacyPolicy.jsp#InterestBasedAds' }
                      title={ formatMessage( messages.interestBasedAds ) }
                      dataNavDescription={ formatOmnitureAttr( 'f', 'interest based ads' ) }
                    >
                      { formatMessage( messages.interestBasedAds ) }
                    </Anchor>
                  </div>
                  <div className='DesktopFooterTandC__copyright'>
                    { formatMessage( messages.copyright, { date: new Date().getFullYear() } ) }
                  </div>
                </div>
              </div>
            </BaseLayout>
          )
        }
      } )() }

    </footer>
  );
}

export default DesktopFooter;
