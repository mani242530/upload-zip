/*
 * DesktopFooter Messages
 *
 * This contains all the text for the DesktopFooter component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  ultamate: {
    id: 'i18n.DesktopFooter.ultamate',
    defaultMessage: 'Ultamate Rewards Credit Card'
  },
  learn: {
    id: 'i18n.DesktopFooter.learn',
    defaultMessage: 'Learn More & Apply'
  },
  manageAccount: {
    id: 'i18n.DesktopFooter.manageAccount',
    defaultMessage: 'Manage Account'
  },
  store: {
    id: 'i18n.DesktopFooter.store',
    defaultMessage: 'Store'
  },
  findLocation: {
    id: 'i18n.DesktopFooter.findLocation',
    defaultMessage: 'Find a Store'
  },
  beautyServices: {
    id: 'i18n.DesktopFooter.beautyServices',
    defaultMessage: 'Beauty Services'
  },
  listBrands: {
    id: 'i18n.DesktopFooter.listBrands',
    defaultMessage: 'List of Brands'
  },
  ultamateRewards: {
    id: 'i18n.DesktopFooter.ultamateRewards',
    defaultMessage: 'Ultamate Rewards'
  },
  customerSupport: {
    id: 'i18n.DesktopFooter.customerSupport',
    defaultMessage: 'Customer Support'
  },
  guestServices: {
    id: 'i18n.DesktopFooter.guestServices',
    defaultMessage: 'Guest Services'
  },
  guestCenter: {
    id: 'i18n.DesktopFooter.guestCenter',
    defaultMessage: 'Guest Services Center'
  },
  orderStatus: {
    id: 'i18n.DesktopFooter.orderStatus',
    defaultMessage: 'Order Status'
  },
  shippingPolicy: {
    id: 'i18n.DesktopFooter.shippingPolicy',
    defaultMessage: 'Shipping Policy & Rate'
  },
  returns: {
    id: 'i18n.DesktopFooter.returns',
    defaultMessage: 'Returns'
  },
  contactUs: {
    id: 'i18n.DesktopFooter.contactUs',
    defaultMessage: 'Contact Us'
  },
  aboutUs: {
    id: 'i18n.DesktopFooter.aboutUs',
    defaultMessage: 'About Us'
  },
  ourCompany: {
    id: 'i18n.DesktopFooter.ourCompany',
    defaultMessage: 'Our Company'
  },
  investorRelations: {
    id: 'i18n.DesktopFooter.investorRelations',
    defaultMessage: 'Investor Relations'
  },
  affiliates: {
    id: 'i18n.DesktopFooter.affiliates',
    defaultMessage: 'Affiliates'
  },
  siteMap: {
    id: 'i18n.DesktopFooter.siteMap',
    defaultMessage: 'Site Map'
  },
  supplyChain: {
    id: 'i18n.DesktopFooter.supplyChain',
    defaultMessage: 'Supply Chain Transparency'
  },
  charitableGiving: {
    id: 'i18n.DesktopFooter.charitableGiving',
    defaultMessage: 'Charitable Giving'
  },
  careers: {
    id: 'i18n.DesktopFooter.careers',
    defaultMessage: 'Careers'
  },
  services: {
    id: 'i18n.DesktopFooter.services',
    defaultMessage: 'Services'
  },
  giftCards: {
    id: 'i18n.DesktopFooter.giftCards',
    defaultMessage: 'Gift Cards'
  },
  mobileApp: {
    id: 'i18n.DesktopFooter.mobileApp',
    defaultMessage: 'Mobile App'
  },
  beautyCalls: {
    id: 'i18n.DesktopFooter.beautyCalls',
    defaultMessage: 'Beauty Calls'
  },
  getTextAlerts: {
    id: 'i18n.DesktopFooter.getTextAlerts',
    defaultMessage: 'Get Text Alerts'
  },
  shipTo: {
    id: 'i18n.DesktopFooter.shipTo',
    defaultMessage: 'Ship To'
  },
  us: {
    id: 'i18n.DesktopFooter.us',
    defaultMessage: 'U.S.'
  },
  canada: {
    id: 'i18n.DesktopFooter.canada',
    defaultMessage: 'Canada'
  },
  earnMore: {
    id: 'i18n.DesktopFooter.earnMore',
    defaultMessage: 'Earn even more points plus 20% off your next purchase'
  },
  terms: {
    id: 'i18n.DesktopFooter.terms',
    defaultMessage: 'Terms & Conditions'
  },
  privacy: {
    id: 'i18n.DesktopFooter.privacy',
    defaultMessage: 'Privacy Policy'
  },
  interestBasedAds: {
    id: 'i18n.DesktopFooter.interestBasedAds',
    defaultMessage: 'Interest Based Ads'
  },
  copyright: {
    id: 'i18n.DesktopFooter.copyright',
    defaultMessage: 'Copyright 2000-{date} Ulta Beauty, Inc.'
  },
  helpPhone: {
    id: 'i18n.DesktopFooter.helpPhone',
    defaultMessage: ' 1-866-257-9195'
  }
} );
