import React from 'react';
import ReactDOM from 'react-dom';
import DesktopFooter from './DesktopFooter';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './DesktopFooter.messages';

describe( '<DesktopFooter />', () => {

  let props = {
    switchData: {
      switches: {
        enableIntlShipping: true,
        enableAcquisitionFLow: true,
        staticContentDomain:'testStaticContentDomain',
        staticContentImgPath:'staticContentImgPath'
      }
    },
    desktopFooterDisplayMode: 'default'
  }

  let component = mountWithIntl( <DesktopFooter { ...props } /> );
  let container = mountWithIntl( <DesktopFooter { ...props } /> ).find( 'DesktopFooter' );


  it( 'renders without crashing', () => {
    // component = mountWithIntl(<DesktopFooter />);
    expect( component.find( 'DesktopFooter' ).length ).toBe( 1 );
  } );

  it( 'renders correct message for Find a Store', () => {
    let message = container.find( 'Anchor' ).at( 0 );
    expect( message.text() ).toEqual( messages.findLocation.defaultMessage )
  } );

  it( 'should contain https in the link for Find a Store', () => {
    expect( component.find( '.DesktopFooter__linksContainer' ).find( 'Anchor' ).at( 0 ).props().url ).toContain( 'https' )
  } );

  it( 'renders correct message for Beauty Services', () => {
    let message = container.find( 'Anchor' ).at( 1 );
    expect( message.text() ).toEqual( messages.beautyServices.defaultMessage )
  } );

  it( 'renders correct message for List of Brands', () => {
    let message = container.find( 'Anchor' ).at( 2 );
    expect( message.text() ).toEqual( messages.listBrands.defaultMessage )
  } );

  it( 'renders correct message for Ultamate Rewards', () => {
    let message = container.find( 'Anchor' ).at( 3 );
    expect( message.text() ).toEqual( messages.ultamateRewards.defaultMessage )
  } );

  it( 'renders correct message for Guest Services Center', () => {
    let message = container.find( 'Anchor' ).at( 4 );
    expect( message.text() ).toEqual( messages.guestCenter.defaultMessage )
  } );

  it( 'renders correct message for Order Status', () => {
    let message = container.find( 'Anchor' ).at( 5 );
    expect( message.text() ).toEqual( messages.orderStatus.defaultMessage )
  } );

  it( 'renders correct message for Shipping Policy and Rate', () => {
    let message = container.find( 'Anchor' ).at( 6 );
    expect( message.text() ).toEqual( messages.shippingPolicy.defaultMessage )
  } );

  it( 'renders correct message for Returns', () => {
    let message = container.find( 'Anchor' ).at( 7 );
    expect( message.text() ).toEqual( messages.returns.defaultMessage )
  } );

  it( 'renders correct message for Contact Us', () => {
    let message = container.find( 'Anchor' ).at( 8 );
    expect( message.text() ).toEqual( messages.contactUs.defaultMessage )
  } );

  it( 'renders correct message for Our Company', () => {
    let message = container.find( 'Anchor' ).at( 9 );
    expect( message.text() ).toEqual( messages.ourCompany.defaultMessage )
    expect( message.props().url ).toEqual( '/company/about-us/' )
  } );

  it( 'renders correct message for Investor Relations', () => {
    let message = container.find( 'Anchor' ).at( 10 );
    expect( message.text() ).toEqual( messages.investorRelations.defaultMessage )
  } );

  it( 'renders correct message for Affiliates', () => {
    let message = container.find( 'Anchor' ).at( 11 );
    expect( message.text() ).toEqual( messages.affiliates.defaultMessage )
  } );

  it( 'renders correct message for Site Map', () => {
    let message = container.find( 'Anchor' ).at( 12 );
    expect( message.text() ).toEqual( messages.siteMap.defaultMessage )
  } );

  it( 'renders correct message for Supply Chain', () => {
    let message = container.find( 'Anchor' ).at( 13 );
    expect( message.text() ).toEqual( messages.supplyChain.defaultMessage )
  } );

  it( 'renders correct message for Charitable Giving', () => {
    let message = container.find( 'Anchor' ).at( 14 );
    expect( message.text() ).toEqual( messages.charitableGiving.defaultMessage )
  } );

  it( 'renders correct message for Careers', () => {
    let message = container.find( 'Anchor' ).at( 15 );
    expect( message.text() ).toEqual( messages.careers.defaultMessage )
  } );

  it( 'renders correct message for Gift Cards', () => {
    let message = container.find( 'Anchor' ).at( 16 );
    expect( message.text() ).toEqual( messages.giftCards.defaultMessage )
  } );

  it( 'renders correct message for Mobile App', () => {
    let message = container.find( 'Anchor' ).at( 17 );
    expect( message.text() ).toEqual( messages.mobileApp.defaultMessage )
  } );

  it( 'renders correct message for Get text alerts', () => {
    let message = container.find( 'Anchor' ).at( 18 );
    expect( message.text() ).toEqual( messages.getTextAlerts.defaultMessage )
  } );

  it( 'renders correct message for U.S.', () => {
    let message = container.find( 'Anchor' ).at( 19 );
    expect( message.text() ).toEqual( messages.us.defaultMessage )
  } );

  it( 'renders correct message for Canada', () => {
    let message = container.find( 'Anchor' ).at( 20 );
    expect( message.text() ).toEqual( messages.canada.defaultMessage )
  } );

  it( 'renders correct message for Learn More and Apply', () => {
    let message = container.find( 'Anchor' ).at( 21 );
    expect( message.text() ).toEqual( messages.learn.defaultMessage )
  } );

  it( 'renders correct message for Manage Account', () => {
    let message = container.find( 'Anchor' ).at( 22 );
    expect( message.text() ).toEqual( 'Opens in a new window' + messages.manageAccount.defaultMessage )
  } );

  it( 'renders correct message for Terms', () => {
    let message = container.find( 'Anchor' ).at( 23 );
    expect( message.text() ).toEqual( messages.terms.defaultMessage )
  } );

  it( 'renders correct message for Privacy Policy', () => {
    let message = container.find( 'Anchor' ).at( 24 );
    expect( message.text() ).toEqual( messages.privacy.defaultMessage )
  } );

  it( 'renders correct message for Interest Based Ads', () => {
    let message = container.find( 'Anchor' ).at( 25 );
    expect( message.text() ).toEqual( messages.interestBasedAds.defaultMessage )
  } );

  it( 'renders correct message for Store', () => {
    let message = container.find( '.DesktopFooter__linkColumnHeader' ).at( 0 );
    expect( message.text() ).toEqual( messages.store.defaultMessage )
  } );

  it( 'renders correct message for Guest Services', () => {
    let message = container.find( '.DesktopFooter__linkColumnHeader' ).at( 1 );
    expect( message.text() ).toEqual( messages.guestServices.defaultMessage )
  } );

  it( 'renders correct message for About Us', () => {
    let message = container.find( '.DesktopFooter__linkColumnHeader' ).at( 2 );
    expect( message.text() ).toEqual( messages.aboutUs.defaultMessage )
  } );

  it( 'renders correct message for Services', () => {
    let message = container.find( '.DesktopFooter__linkColumnHeader' ).at( 3 );
    expect( message.text() ).toEqual( messages.services.defaultMessage )
  } );

  it( 'renders correct message for Beauty Calls', () => {
    let message = container.find( '.DesktopFooter__linkColumnHeader' ).at( 4 );
    expect( message.text() ).toEqual( messages.beautyCalls.defaultMessage )
  } );

  it( 'renders correct message for Ship To', () => {
    let message = container.find( '.DesktopFooter__linkColumnHeader' ).at( 5 );
    expect( message.text() ).toEqual( messages.shipTo.defaultMessage )
  } );

  it( 'renders correct message for Ultamate Rewards Credit Card', () => {
    let message = container.find( '.DesktopFooter__linkColumnHeader' ).at( 6 );
    expect( message.text() ).toEqual( messages.ultamate.defaultMessage )
  } );

  it( 'renders correct message for copyright', () => {
    let copyright = container.find( '.DesktopFooterTandC__copyright' );
    let defaultCopyRight = 'Copyright 2000-' + new Date().getFullYear() + ' Ulta Beauty, Inc.';
    expect( copyright.text() ).toEqual( defaultCopyRight )
  } );

  it( 'renders correct link for careers', () => {
    let url = container.find( 'Anchor' ).at( 15 ).at( 0 ).props().url;
    expect( url ).toBe( 'http://careers.ulta.com' )
  } );

  it( 'renders correct link for Investor Relations', () => {
    let url = container.find( 'Anchor' ).at( 10 ).at( 0 ).props().url;
    expect( url ).toBe( 'http://ir.ulta.com/phoenix.zhtml?c=213869&amp;p=irol-irhome' )
  } );

  it( 'should render Image with proper src', () => {
    let Image = container.find( 'Image' );
    let americanFlagImageURL =props.switchData.switches.staticContentDomain+props.switchData.switches.staticContentImgPath+'/footer-us-flag@2x.png';
    let canadianFlagImageURL =props.switchData.switches.staticContentDomain+props.switchData.switches.staticContentImgPath+'/footer-canada-flag@2x.png';
    expect( Image.at( 0 ).props().src ).toBe( americanFlagImageURL );
    expect( Image.at( 1 ).props().src ).toBe( canadianFlagImageURL );
    expect( Image.length ).toBe( 2 )
  } );

  describe( 'window.innerWidth above 1199px', () => {
    global.innerWidth = 1200;

    let component = mountWithIntl( <DesktopFooter { ...props } /> );
    let container = mountWithIntl( <DesktopFooter { ...props } /> ).find( 'DesktopFooter' );

    it( 'renders correct message for Rewards Text', () => {
      let message = container.find( '.DesktopFooter__rewardsText' );
      expect( message.text() ).toEqual( messages.earnMore.defaultMessage )
    } );

  } );

  describe( 'Desktop Footer - Heading h5', () => {
    it( 'has 4 h5 elements', () => {
      expect( component.find( 'h5' ).length ).toBe( 4 );
    } );
    it( 'h5 should have store as defaultMessage', () => {
      let message = component.find( 'h5' ).at( 0 );
      expect( message.text() ).toBe( messages.store.defaultMessage );
    } );
    it( 'h5 should have guestServices as defaultMessage', () => {
      let message = component.find( 'h5' ).at( 1 );
      expect( message.text() ).toBe( messages.guestServices.defaultMessage );
    } );
    it( 'h5 should have aboutUs as defaultMessage', () => {
      let message = component.find( 'h5' ).at( 2 );
      expect( message.text() ).toBe( messages.aboutUs.defaultMessage );
    } );
    it( 'h5 should have services as defaultMessage', () => {
      let message = component.find( 'h5' ).at( 3 );
      expect( message.text() ).toBe( messages.services.defaultMessage );
    } );
  } );

} );
