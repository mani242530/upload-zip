/**
 *
 * MobileFooter
 *
 */

import React from 'react';
import './MobileFooter.css';
import messages from './MobileFooter.messages';

import MobileFooterViewOurApp from 'hf/components/Footers/mobile/MobileFooterViewOurApp/MobileFooterViewOurApp';
import MobileFooterUltamateRewards from 'hf/components/Footers/mobile/MobileFooterUltamateRewards/MobileFooterUltamateRewards';
// import MobileFooterFindAstore from 'components/MobileFooterFindAstore/MobileFooterFindAstore';

import MixedMenuButton from 'shared/components/MixedMenuButton/MixedMenuButton';
import { Collapse } from 'react-bootstrap';
import SocialIcon from 'mhp/components/SocialIcon/SocialIcon';
import MobileFooterSmallFooterLinks from 'hf/components/Footers/mobile/MobileFooterSmallFooterLinks/MobileFooterSmallFooterLinks';
import MobileFooterTandC from 'hf/components/Footers/mobile/MobileFooterTandC/MobileFooterTandC';
import BaseLayout from 'shared/components/BaseLayout/BaseLayout';
import Anchor from 'shared/components/Anchor/Anchor';
import Image from 'shared/components/Image/Image';
import Divider from 'shared/components/Divider/Divider';
import findSVG from 'shared/components/Icons/location';
import ultamateSVG from 'shared/components/Icons/ultamate';
import ordersSVG from 'shared/components/Icons/orders';
import phoneSVG from 'shared/components/Icons/contact_us';
import emailSVG from 'shared/components/Icons/email';
import { formatMessage } from 'shared/components/Global/Global';
import { formatOmnitureAttr } from 'utils/Omniture/Omniture';
import { host } from 'utils/Formatters/formatters';
import FooterHelpText from 'hf/components/FooterHelpText/FooterHelpText';


const MobileFooter = ( props ) =>{

  const americanFlagImageURL = '//static.ultainc.com/static/images/footer-us-flag@2x.png';
  const canadianFlagImageURL = '//static.ultainc.com/static/images/footer-canada-flag@2x.png';



  const {
    setActiveFooterNavCollapse,
    footerNavCollapse,
    mobileFooterDisplayMode,
    isSignedIn,
    hasLeftNav,
    switchData
  } = props;

  let orderStatusUrl;
  let UltamateRewardsUrl;

  if( props.isSignedIn ){
    orderStatusUrl = '/ulta/myaccount/template.jsp?page=orderstatus';
    UltamateRewardsUrl = '/ulta/myaccount/rewards.jsp';
  }
  else {
    orderStatusUrl = '/ulta/myaccount/pages/order_status_anonymous.jsp?_requestid=2056707';
    UltamateRewardsUrl = '/ulta/myaccount/learnmore_template.jsp?learnMoreAccordion=true&page=benefits';
  }
  return (
    <footer className='MobileFooter'>
      <BaseLayout hasLeftNav={ hasLeftNav }>
        { ( () =>{
          if( mobileFooterDisplayMode === 'default' ){
            return (
              <div>
                <MobileFooterViewOurApp appInstalled={ true }/>

                <MobileFooterUltamateRewards/>


                <div className='FooterNav'>
                  <MixedMenuButton
                    icon={ findSVG }
                    label={ formatMessage( messages.findAStore ) }
                    url={ 'https://' + host + ( switchData && switchData.switches ? switchData.switches.storeLocatorURL : '/ulta/stores/storelocator.jsp' ) }
                    dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.findAStore ) ) }
                  />
                  <MixedMenuButton
                    icon={ ultamateSVG }
                    label={ formatMessage( messages.ultamateRewards ) }
                    url='/ulta/myaccount/learnmore_template.jsp?learnMoreAccordion=true&page=benefits'
                    dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.ultamateRewards ) ) }
                  />
                  <MixedMenuButton
                    icon={ ordersSVG }
                    label={ formatMessage( messages.orders ) }
                    pointerType='collapse'
                    onClick={ e =>{
                      e.preventDefault();
                      setActiveFooterNavCollapse( 'orders' );
                    } }
                    pointerMinus={ footerNavCollapse.orders }
                  />
                  <Collapse in={ footerNavCollapse.orders }>
                    <div className='MobileFooter__collapse'>
                      <MixedMenuButton
                        label={ formatMessage( messages.orderstatus ) }
                        pointerType='none'
                        url='/ulta/myaccount/pages/order_status_anonymous.jsp?_requestid=2056707'
                        dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.orderstatus ) ) }
                      />
                      <MixedMenuButton
                        label={ formatMessage( messages.returns ) }
                        pointerType='none'
                        url='/ulta/guestservices/guestServicesCenterDetails.jsp#ReturnPolicy'
                        dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.returns ) ) }
                      />
                      <MixedMenuButton
                        label={ formatMessage( messages.shippingpolicy ) }
                        pointerType='none'
                        url='/ulta/guestservices/guestServicesCenterDetails.jsp#ShippingPolicy'
                        dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.shippingpolicy ) ) }
                      />
                    </div>
                  </Collapse>
                  <MixedMenuButton
                    icon={ phoneSVG }
                    label={ formatMessage( messages.contactUs ) }
                    pointerType='collapse'
                    pointerMinus={ footerNavCollapse.contactus }
                    onClick={ e =>{
                      e.preventDefault();
                      setActiveFooterNavCollapse( 'contactus' );
                    } }
                  />
                  <Collapse in={ footerNavCollapse.contactus }>
                    <div className='MobileFooter__collapse'>
                      { ( ()=>{
                        if( switchData && switchData.switches ){
                          return (
                            <MixedMenuButton
                              label={ props.switchData.switches.guestServiceNumber }
                              details={ props.switchData.switches.guestServiceHours }
                              pointerType='none'
                              url='tel:+1-866-983-8582'
                              dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.callUs ) ) }
                            />
                          )
                        }
                      } )() }
                      <MixedMenuButton
                        label={ formatMessage( messages.sendUsAnEmail ) }
                        pointerType='none'
                        url='/ulta/guestservices/contactUs.jsp'
                        dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.sendUsAnEmail ) ) }
                      />
                    </div>
                  </Collapse>
                  <MixedMenuButton
                    icon={ emailSVG }
                    label={ formatMessage( messages.getAlerts ) }
                    url='//pages.exacttarget.com/ulta-email-signup/'
                    dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.getAlerts ) ) }
                  />
                </div>

                <div className='SocialIcons'>
                  <SocialIcon type='facebook'/>
                  <SocialIcon type='twitter'/>
                  <SocialIcon type='pinterest'/>
                  <SocialIcon type='youtube'/>
                  <SocialIcon type='instagram'/>
                </div>
                <div className='MobileFooter_shipToContainer'>
                  <div className='MobileFooter_displayCenter'>
                    <div className='MobileFooter_shipTo'>
                      { formatMessage( messages.shipTo ) }
                    </div>
                  </div>
                  <div className='MobileFooter_displayCenter'>

                    <Anchor
                      url='/'
                      className='MobileFooter_displayCenter MobileFooter_anchor MobileFooter_active'
                      dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.us ) ) }
                    >

                      <Image
                        className='MobileFooter_image'
                        width={ 20 }
                        height={ 10 }
                        src={ americanFlagImageURL }
                        alt='American flag image'
                      />

                      <div className='MobileFooter_inline'>
                        { formatMessage( messages.us ) }
                      </div>

                    </Anchor>

                    <Anchor
                      url={ '//global-ulta.com/' }
                      className='MobileFooter_displayCenter MobileFooter_anchor'
                      dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.canada ) ) }
                    >

                      <Image
                        className='MobileFooter_image'
                        width={ 20 }
                        height={ 10 }
                        src={ canadianFlagImageURL }
                        alt='Canadian flag image'
                      />

                      <div className='MobileFooter_inline'>
                        { formatMessage( messages.canada ) }
                      </div>

                    </Anchor>
                  </div>
                </div>
                <MobileFooterSmallFooterLinks/>
                <Divider dividerType='multi-color'/>
              </div>
            );

          }

        } )() }

        { ( () =>{
          if( mobileFooterDisplayMode === 'customerService' ){
            return (
              <div className='MobileFooter__footerDivider'>
                <Divider dividerType='multi-color'/>
              </div>
            );
          }

        } )() }

        { ( ()=>{
          if( mobileFooterDisplayMode === 'customerService' && switchData && switchData.switches ){
            return (
              <FooterHelpText
                hoursOfOperation={ props.switchData.switches.guestServiceHours }
                serviceNumber={ props.switchData.switches.guestServiceNumber }
              />
            )
          }
        } )() }


        <MobileFooterTandC { ...props }/>
      </BaseLayout>
    </footer>
  );

}

export default MobileFooter;