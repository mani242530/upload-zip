/*
 * MobileFooter Messages
 *
 * This contains all the text for the MobileFooter component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  findAStore: {
    id: 'i18n.MobileFooter.findAStore',
    defaultMessage: 'Find a Store'
  },
  ultamateRewards: {
    id: 'i18n.MobileFooter.ultamateRewards',
    defaultMessage: 'Ultamate Rewards'
  },
  orders: {
    id: 'i18n.MobileFooter.orders',
    defaultMessage: 'Orders'
  },
  orderstatus: {
    id: 'i18n.MobileFooter.orderstatus',
    defaultMessage: 'Order Status'
  },
  shipTo:{
    id:'i18n.MobileFooter.shipTo',
    defaultMessage:'Ship To:'
  },
  us:{
    id:'i18n.MobileFooter.us',
    defaultMessage:'U.S.'
  },
  canada:{
    id:'i18.MobileFooter.canada',
    defaultMessage:'CANADA'
  },
  returns: {
    id: 'i18n.MobileFooter.returns',
    defaultMessage: 'Returns'
  },
  shippingpolicy: {
    id: 'i18n.MobileFooter.shippingpolicy',
    defaultMessage: 'Shipping Policy & Rates'
  },
  contactUs: {
    id: 'i18n.MobileFooter.contactUs',
    defaultMessage: 'Contact Us'
  },
  getAlerts: {
    id: 'i18n.MobileFooter.getAlerts',
    defaultMessage: 'Get Email & Text Alerts'
  },
  callUs: {
    id: 'i18n.MobileFooter.callUs',
    defaultMessage: 'Call Us 866-983-8582'
  },
  contactTimes: {
    id: 'i18n.MobileFooter.contactTimes',
    defaultMessage: '7am - 11pm CST 7 days a week'
  },
  sendUsAnEmail: {
    id: 'i18n.MobileFooter.sendUsAnEmail',
    defaultMessage: 'Send Us an Email'
  },
  needHelp: {
    id: 'i18n.LeftNavFooter.needHelp',
    defaultMessage: 'Need Help? Call Us:'
  },
  phone: {
    id: 'i18n.LeftNavFooter.phone',
    defaultMessage: '1-866-983-8582'
  }
} );
