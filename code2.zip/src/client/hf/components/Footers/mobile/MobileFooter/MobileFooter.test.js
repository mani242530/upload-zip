import React from 'react';
import MobileFooter from './MobileFooter';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

import ShallowRenderer from 'react-test-renderer/shallow';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import _ from 'lodash';
let store = configureStore( {}, CONFIG );


describe( '<MobileFooter />', () => {
  let component;
  let prop = {
    footerNavCollapse: {},
    mobileFooterDisplayMode: 'default',
    isSignedIn: false
  }
  const renderer = new ShallowRenderer();

  component = mountWithIntl(
    <Provider store={ store }>
      <MobileFooter { ...prop } />
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'MobileFooter' ).length ).toBe( 1 );
  } );


  describe( 'the mobileFooterDisplayMode is set to "default"', () => {

    var props = {
      footerNavCollapse: {},
      mobileFooterDisplayMode: 'default',
      isSignedIn: false
    }

    const defaultDisplay = mountWithIntl(
      <Provider store={ store }>
        <MobileFooter { ...props } />
      </Provider>
    );

    it( 'should contain https in the \'Find a Store\' link', () => {
      let navButtonFooter = component.find( 'MobileFooter' ).find( 'MixedMenuButton' ).at( 0 );
      expect( navButtonFooter.props().url ).toContain( 'https' );
    } );

  } );


  describe( 'the mobileFooterDisplayMode is set to customerService', () => {
    var props = {
      footerNavCollapse: {},
      mobileFooterDisplayMode: 'customerService',
      isSignedIn: false
    }

    const defaultDisplay = mountWithIntl(
      <Provider store={ store }>
        <MobileFooter { ...props } />
      </Provider>
    );

  } );

} );

describe( 'Render MixedMenuButton with the guestServiceHours and guestServiceNumber Component', () => {
  let component1;
  let component2;
  let setActiveFooterNavCollapseMock =jest.fn();
  let prop = {
    footerNavCollapse: {},
    isSignedIn: false,
    mobileFooterDisplayMode: 'default'
  }

  let prop1 = {
    setActiveFooterNavCollapse :setActiveFooterNavCollapseMock,
    footerNavCollapse: {},
    isSignedIn: true,
    mobileFooterDisplayMode: 'default',
    switchData: {
      switches: {
        guestServiceNumber: '123-456-7890',
        guestServiceHours: '7pm - 8Am'
      }
    }
  }

  component1 = mountWithIntl(
    <Provider store={ store }>
      <MobileFooter { ...prop } />
    </Provider>
  );

  it( 'Doesnt render the MixedMenuButton Component with guestServiceHours and guestServiceNumber if switchData is not present', () => {
    var menuButton = component1.find( 'MixedMenuButton' );
    expect( menuButton.length ).toBe( 9 );
    expect( menuButton.at( 7 ).props().label ).not.toBe( prop1.switchData.switches.guestServiceNumber );
  } );

  component2 = mountWithIntl(
    <Provider store={ store }>
      <MobileFooter { ...prop1 } />
    </Provider>
  );

  it( 'Renders the MixedMenuButton Component with guestServiceHours and guestServiceNumber if switchData is present', () => {
    var menuButtons = component2.find( 'MixedMenuButton' )
    expect( menuButtons.length ).toBe( 10 );
    expect( menuButtons.at( 7 ).props().label ).toEqual( prop1.switchData.switches.guestServiceNumber );
    expect( menuButtons.at( 7 ).props().details ).toEqual( prop1.switchData.switches.guestServiceHours );
  } );

  it( 'Should invoke setActiveFooterNavCollapse with orders as paramter on click of MixedMenuButton', () => {
    component2.find( 'MixedMenuButton' ).at( 2 ).simulate( 'click' )
    expect( setActiveFooterNavCollapseMock ).toHaveBeenCalledWith( 'orders' )
  } );

  it( 'Should invoke setActiveFooterNavCollapse with contactus as paramter on click of MixedMenuButton', () => {
    component2.find( 'MixedMenuButton' ).at( 6 ).simulate( 'click' )
    expect( setActiveFooterNavCollapseMock ).toHaveBeenCalledWith( 'contactus' )
  } );

} );
