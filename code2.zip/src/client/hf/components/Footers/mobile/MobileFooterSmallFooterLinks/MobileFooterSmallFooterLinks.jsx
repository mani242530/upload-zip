/**
 * MobileFooterSmallFooterLinks
 */

import React from 'react';
import Anchor from 'shared/components/Anchor/Anchor';
import './MobileFooterSmallFooterLinks.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './MobileFooterSmallFooterLinks.messages';
import { formatOmnitureAttr } from 'utils/Omniture/Omniture';


const MobileFooterSmallFooterLinks = ( props ) => {



  return (
    <div className='MobileFooterSmallFooterLinks'>
      <div className='MobileFooterSmallFooterLinks__Column'>
        <div className='MobileFooterSmallFooterLinks__Column--link'>
          <Anchor
            url='/giftcards/giftCard.jsp'
            dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.giftcard ) ) }
          >
            { formatMessage( messages.giftcard ) }
          </Anchor>
        </div>
        <div className='MobileFooterSmallFooterLinks__Column--link'>
          <Anchor
            url='/guestservices/guestServicesCenterDetails.jsp#ReturnPolicy'
            dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.returns ) ) }
          >
            { formatMessage( messages.returns ) }
          </Anchor>
        </div>
        <div className='MobileFooterSmallFooterLinks__Column--link'>
          <Anchor
            url='/guestservices/guestServicesCenterDetails.jsp#ShippingPolicy'
            dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.shipping ) ) }
          >
            { formatMessage( messages.shipping ) }
          </Anchor>
        </div>
      </div>
      <div className='MobileFooterSmallFooterLinks__Column'>
        <div className='MobileFooterSmallFooterLinks__Column--link'>
          <Anchor
            url='/company/about-us/'
            dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.company ) ) }
          >
            { formatMessage( messages.company ) }
          </Anchor>
        </div>
        <div className='MobileFooterSmallFooterLinks__Column--link'>
          <Anchor
            url='http://careers.ulta.com'
            dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.careers ) ) }
          >
            { formatMessage( messages.careers ) }
          </Anchor>
        </div>
        <div className='MobileFooterSmallFooterLinks__Column--link'>
          <Anchor
            url='//ir.ulta.com/phoenix.zhtml?c=213869&p=irol-irhome'
            dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.ir ) ) }
          >
            { formatMessage( messages.ir ) }
          </Anchor>
        </div>
      </div>
    </div>
  );

}

export default MobileFooterSmallFooterLinks;
