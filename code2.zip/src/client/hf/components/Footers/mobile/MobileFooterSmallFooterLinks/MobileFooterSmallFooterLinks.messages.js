/*
 * MobileFooterSmallFooterLinks Messages
 *
 * This contains all the text for the MobileFooterSmallFooterLinks component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  giftcard: {
    id: 'i18n.MobileFooterSmallFooterLinks.giftcard',
    defaultMessage: 'Gift Cards'
  },
  returns: {
    id: 'i18n.MobileFooterSmallFooterLinks.returns',
    defaultMessage: 'Returns'
  },
  shipping: {
    id: 'i18n.MobileFooterSmallFooterLinks.shipping',
    defaultMessage: 'Shipping Policy & Rates'
  },
  company: {
    id: 'i18n.MobileFooterSmallFooterLinks.company',
    defaultMessage: 'Our Company'
  },
  careers: {
    id: 'i18n.MobileFooterSmallFooterLinks.careers',
    defaultMessage: 'Careers'
  },
  ir: {
    id: 'i18n.MobileFooterSmallFooterLinks.ir',
    defaultMessage: 'Investor Relations'
  }
} );
