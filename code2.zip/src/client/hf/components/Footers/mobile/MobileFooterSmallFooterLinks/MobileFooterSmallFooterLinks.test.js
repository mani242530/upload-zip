import React from 'react';
import ReactDOM from 'react-dom';
import MobileFooterSmallFooterLinks from './MobileFooterSmallFooterLinks';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './MobileFooterSmallFooterLinks.messages';

describe( '<MobileFooterSmallFooterLinks />', () => {
  let component = mountWithIntl( <MobileFooterSmallFooterLinks /> );
  let container = mountWithIntl( <MobileFooterSmallFooterLinks /> ).find( 'MobileFooterSmallFooterLinks' );

  it( 'renders without crashing', () => {
    expect( component.find( 'MobileFooterSmallFooterLinks' ).length ).toBe( 1 );
  } );

  let links = container.find( 'Anchor' );

  it( 'should render 6 links', () => {
    expect( links.length ).toEqual( 6 );

  } );


  it( 'should render footer link text correctly', () => {

    expect( links.at( 0 ).text() ).toEqual( messages.giftcard.defaultMessage );
    expect( links.at( 1 ).text() ).toEqual( messages.returns.defaultMessage );
    expect( links.at( 2 ).text() ).toEqual( messages.shipping.defaultMessage );
    expect( links.at( 3 ).text() ).toEqual( messages.company.defaultMessage );
    expect( links.at( 3 ).props().url ).toEqual( '/company/about-us/' );
    expect( links.at( 4 ).text() ).toEqual( messages.careers.defaultMessage );
    expect( links.at( 5 ).text() ).toEqual( messages.ir.defaultMessage );
  } );
} );