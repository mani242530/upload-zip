/**
 * MobileFooterTandC
 */

import React from 'react';
import { connect } from 'react-redux';
import Anchor from 'shared/components/Anchor/Anchor';
import './MobileFooterTandC.css';
import { formatOmnitureAttr } from 'utils/Omniture/Omniture';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './MobileFooterTandC.messages';
import FooterHelpText from 'hf/components/FooterHelpText/FooterHelpText';

export const mapStateToProps = ( state ) => {
  return {
    ...state.header
  };
}

export const MobileFooterTandC = ( props ) => {
  return (
    <div className='MobileFooterTandC'>


      <p className='MobileFooterTandC__terms'>
        <Anchor
          url='/ulta/common/user_agreement.jsp'
          title={ formatMessage( messages.terms ) }
          dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.terms ) ) }
        >
          { formatMessage( messages.terms ) }
        </Anchor>
        <span className='MobileFooterTandC__terms__spacer'>\</span>
        <Anchor
          url='/ulta/common/privacyPolicy.jsp'
          title={ formatMessage( messages.privacy ) }
          dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.privacy ) ) }
        >
          { formatMessage( messages.privacy ) }
        </Anchor>
        <span className='MobileFooterTandC__terms__spacer'>\</span>

        { ( () => {
          if( props.displayShippingPolicy ){
            return (
              <span className='MobileFooterTandC__shipping'>
                <Anchor
                  url='/ulta/guestservices/guestServicesCenterDetails.jsp#ShippingPolicy'
                  title={ formatMessage( messages.shipping ) }
                  dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.shipping ) ) }
                >
                  { formatMessage( messages.shipping ) }
                </Anchor>
                <span> { '&' } </span>
                <Anchor
                  url='/ulta/guestservices/guestServicesCenterDetails.jsp#ReturnPolicy'
                  title={ formatMessage( messages.return ) }
                  dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.return ) ) }
                >
                  { formatMessage( messages.return ) }
                </Anchor>
              </span>
            )
          }
          else {
            return (
              <Anchor
                url={ '/ulta/common/privacyPolicy.jsp#InterestBasedAds' }
                title={ formatMessage( messages.interestBasedAds ) }
                dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.interestBasedAds ) ) }
              >
                { formatMessage( messages.interestBasedAds ) }
              </Anchor>
            )
          }
        } )() }

      </p>

      <p className='MobileFooterTandC__copyright'>
        { formatMessage( messages.copyright, { date: new Date().getFullYear() } ) }
      </p>
    </div>
  );

}

export default connect( mapStateToProps )( MobileFooterTandC );
