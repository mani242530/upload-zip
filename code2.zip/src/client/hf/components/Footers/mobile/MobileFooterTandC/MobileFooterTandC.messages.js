/*
 * MobileFooterTandC Messages
 *
 * This contains all the text for the MobileFooterTandC component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  shipping: {
    id: 'i18n.MobileFooterTandC.shipping',
    defaultMessage: 'Shipping'
  },
  return: {
    id: 'i18n.MobileFooterTandC.return',
    defaultMessage: 'Returns'
  },
  terms: {
    id: 'i18n.MobileFooterTandC.terms',
    defaultMessage: 'Terms & Conditions'
  },
  privacy: {
    id: 'i18n.MobileFooterTandC.privacy',
    defaultMessage: 'Privacy Policy'
  },
  interestBasedAds: {
    id: 'i18n.MobileFooterTandC.interestBasedAds',
    defaultMessage: 'Interest Based Ads'
  },
  copyright: {
    id: 'i18n.MobileFooterTandC.copyright',
    defaultMessage: 'Copyright 2000-{date} Ulta Beauty, Inc.'
  }
} );
