import React from 'react';
import ReactDOM from 'react-dom';
import ConnectedMobileFooterTandC, { MobileFooterTandC, mapStateToProps } from './MobileFooterTandC';
import { Provider } from 'react-redux';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './MobileFooterTandC.messages';
import reducer, { initialState } from 'hf/reducers/Header/Header.reducer';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';

const store = configureStore( {}, CONFIG );

import {
  types as headerTypes,
  actions as headerActions
} from 'hf/actions/Header/Header.actions'

import {
  types as globalTypes,
  actions as globalActions
} from 'shared/actions/Global/Global.actions'

let actionCreator = {
  type: headerTypes.SET_CURRENT_PAGE,
  currentPage: 'bag'
}



describe( '<MobileFooterTandC />', () => {

  global.CURRENT_PAGE='cart';

  let props = {
    currentPage: 'bag',
    switches:{
      guestServiceHours: '9am to 10pm',
      guestServiceNumber: '847-232-8400'
    },
    intl: {
      locale: 'en',
      formats: {},
      messages: {

      },
      formatMessage: jest.fn()
    }
  };

  let component = mountWithIntl(
    <Provider store={ store }>
      <ConnectedMobileFooterTandC { ...props } />
    </Provider>
  );

  let container = mountWithIntl(
    <Provider store={ store }>
      <ConnectedMobileFooterTandC { ...props } />
    </Provider>
  ).find( 'MobileFooterTandC' );

  it( 'renders without crashing', () => {
    expect( component.length ).toBe( 1 );
  } );

} );
describe( '<MobileFooterTandC />', () => {
  global.CURRENT_PAGE='checkout';
  let props = {
    currentPage: 'checkout',
    switches:{

    }
  };
  let component = mountWithIntl(
    <Provider store={ store }>
      <ConnectedMobileFooterTandC { ...props }/>
    </Provider>
  );

  let props2 = {
    displayShippingPolicy :true,
    switches:{
      guestServiceHours: '9am to 10pm',
      guestServiceNumber: '847-232-8400'
    }
  }

  reducer( initialState, props2 )


  let container = mountWithIntl(
    <Provider store={ store }>
      <ConnectedMobileFooterTandC { ...props2 }/>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.length ).toBe( 1 );
  } );

  it( 'renders links to shipping policy and returns', () => {
    expect( container.find( '.MobileFooterTandC__shipping' ).text() ).toBe( messages.shipping.defaultMessage +' & '+messages.return.defaultMessage )
  } );

} );
describe( '<MobileFooterTandC />', () => {

  global.CURRENT_PAGE='default';
  let props = {
    currentPage: 'bag'
  }
  let component = mountWithIntl(
    <Provider store={ store }>
      <ConnectedMobileFooterTandC { ...props } />
    </Provider>
  );
  let container = mountWithIntl(
    <Provider store={ store }>
      <ConnectedMobileFooterTandC { ...props } />
    </Provider>
  ).find( 'MobileFooterTandC' );

  it( 'renders without crashing', () => {

    expect( component.length ).toBe( 1 );
  } );

  it( 'renders correct message for terms and conditions', () => {
    let TandC = component.find( 'Anchor' ).at( 0 );
    expect( TandC.text() ).toEqual( messages.terms.defaultMessage )
  } );

  it( 'renders correct message for privacy policy', () => {
    let privacy = component.find( 'Anchor' ).at( 1 );
    expect( privacy.text() ).toEqual( messages.privacy.defaultMessage )
  } );

  it( 'renders correct message for interest based ads on \'/bag\' page', () => {
    let interest = component.find( 'Anchor' ).at( 2 );
    expect( interest.text() ).toEqual( messages.interestBasedAds.defaultMessage )
  } );

  it( 'renders correct message for copyright', () => {
    let copyright = component.find( 'p' ).at( 1 );
    let defaultCopyRight = 'Copyright 2000-' + new Date().getFullYear() + ' Ulta Beauty, Inc.';
    expect( copyright.text() ).toEqual( defaultCopyRight )
  } );

  it( 'renders correct message for interest based ads on \'/\' page', () => {
    props.currentPage = '/';
    let container2 = mountWithIntl(
      <Provider store={ store }>
        <ConnectedMobileFooterTandC { ...props } />
      </Provider>
    ).find( 'MobileFooterTandC' );

    let interest = component.find( 'Anchor' ).at( 2 );
    expect( interest.text() ).toEqual( messages.interestBasedAds.defaultMessage )
  } );
} );
