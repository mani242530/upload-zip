/**
 * MobileFooterUltamateRewards
 */
import React from 'react';
import './MobileFooterUltamateRewards.css';
import Anchor from 'shared/components/Anchor/Anchor';
import rewardsCC_footer from 'static/rewardsCC_footer.png';
import Image from 'shared/components/Image/Image';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './MobileFooterUltamateRewards.messages';
import { formatOmnitureAttr } from 'utils/Omniture/Omniture';
import ChevronRightSVG from 'shared/components/Icons/chevron_right';
import {
  host,
  fullyQualifyLink
} from 'utils/Formatters/formatters';


const MobileFooterUltamateRewards = ( props ) => {



  return (
    <div className='MobileFooterUltamateRewards'>
      <Anchor
        url='/ulta/creditcards/landingpage.jsp'
        dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.learnmore ) ) }
      >
        <div className='MobileFooterUltamateRewards__img-wrapper'>
          <Image
            src={ fullyQualifyLink( host, rewardsCC_footer ) }
            alt={ formatMessage( messages.learnmore ) }
            lazyLoad={ true }
          />
        </div>
        <div className='MobileFooterUltamateRewards__text-wrapper'>
          <p className='MobileFooterUltamateRewards__text-wrapper__heading'>{ formatMessage( messages.headertext1 ) } <sup>&reg;</sup><br /> { formatMessage( messages.headertext2 ) }</p>
        </div>
        <span className='MobileFooter__right-arrow'></span>
      </Anchor>
      <div className='clearfix'></div>

      <div className='MobileFooterUltamateRewards__links'>

        <div className='MobileFooterUltamateRewards__link'>
          <Anchor
            url='/ulta/creditcards/landingpage.jsp'
            className='MobileFooterUltamateRewards__Anchor MobileFooterUltamateRewards__Anchor--learn-more'
            dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.learnmore ) ) }
          >
            { formatMessage( messages.learnmore ) }
            <span className='MobileFooterUltamateRewards__links__chevron-right'>
              <ChevronRightSVG/>
            </span>
          </Anchor>
        </div>

        <div className='MobileFooterUltamateRewards__link'>
          <Anchor
            url='//comenity.net/ultamaterewardscredit'
            className='MobileFooterUltamateRewards__Anchor MobileFooterUltamateRewards__Anchor--manage-card'
            dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.managecard ) ) }
          >
            { formatMessage( messages.managecard ) }
            <span className='MobileFooterUltamateRewards__links__chevron-right'>
              <ChevronRightSVG/>
            </span>
          </Anchor>

        </div>

      </div>

    </div>
  );

}

export default MobileFooterUltamateRewards;
