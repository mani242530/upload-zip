/*
 * MobileFooterUltamateRewards Messages
 *
 * This contains all the text for the MobileFooterUltamateRewards component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  headertext1: {
    id: 'i18n.MobileFooterUltamateRewards.headertext1',
    defaultMessage: 'Ultamate rewards'
  },
  headertext2: {
    id: 'i18n.MobileFooterUltamateRewards.headertext2',
    defaultMessage: 'credit card'
  },
  learnmore: {
    id: 'i18n.MobileFooterUltamateRewards.learnmore',
    defaultMessage: 'Learn More & Apply'
  },
  managecard: {
    id: 'i18n.MobileFooterUltamateRewards.managecard',
    defaultMessage: 'Manage Card'
  }
} );
