import React from 'react';
import ReactDOM from 'react-dom';
import MobileFooterUltamateRewards from './MobileFooterUltamateRewards';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './MobileFooterUltamateRewards.messages';

import { IntlProvider } from 'react-intl';
import rewardsCC_footer from 'static/rewardsCC_footer.png';
import {
  host,
  fullyQualifyLink
} from 'utils/Formatters/formatters';

describe( '<MobileFooterUltamateRewards />', () => {
  let component;
  let props = {
    intl:{
      formatMessage: jest.fn()
    }
  };

  component = mountWithIntl( <MobileFooterUltamateRewards { ...props } /> );

  it( 'renders without crashing', () => {
    expect( component.find( 'MobileFooterUltamateRewards' ).length ).toBe( 1 );
  } );


  let links = component.find( 'Anchor' );

  it( 'should render three links', () => {
    expect( links.length ).toEqual( 3 );
  } );

  it( 'should render correct image src url', () => {
    expect( component.find( 'Image' ).at( 0 ).props().src ).toEqual( fullyQualifyLink( host, rewardsCC_footer ) );
  } );

  it( 'should render correct link for image', () => {
    expect( links.at( 0 ).props().url ).toEqual( '/ulta/creditcards/landingpage.jsp' );
  } );

  it( 'should render correct text for learn more link', () => {
    expect( links.at( 1 ).text() ).toEqual( messages.learnmore.defaultMessage );
  } );

  it( 'should render correct link for learn more', () => {
    expect( links.at( 1 ).props().url ).toEqual( '/ulta/creditcards/landingpage.jsp' );
  } );


  it( 'should render correct text for manage card link', () => {
    expect( links.at( 2 ).text() ).toEqual( messages.managecard.defaultMessage );
  } );

  it( 'should render correct link for manage card', () => {
    expect( links.at( 2 ).props().url ).toEqual( '//comenity.net/ultamaterewardscredit' );
  } );


} );

