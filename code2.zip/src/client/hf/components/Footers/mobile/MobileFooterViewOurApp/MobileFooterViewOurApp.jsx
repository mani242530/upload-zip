/**
 * MobileFooterViewOurApp
 */

import React from 'react';
import PropTypes from 'prop-types';
import './MobileFooterViewOurApp.css';
import Anchor from 'shared/components/Anchor/Anchor';
import Image from 'shared/components/Image/Image';

import getApp_phone from 'static/getApp_phone.jpeg';
import ChevronRightSVG from 'shared/components/Icons/chevron_right';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './MobileFooterViewOurApp.messages'
import { formatOmnitureAttr } from 'utils/Omniture/Omniture';
import {
  host,
  fullyQualifyLink
} from 'utils/Formatters/formatters';

const propTypes = {
  appInstalled: PropTypes.bool.isRequired
}


const MobileFooterViewOurApp = ( props ) => {

  return (
    <div className='MobileFooterViewOurApp'>
      <Anchor
        url='https://www.ulta.com/mobile/smart_link.html?locale=shop'
        dataNavDescription={ formatOmnitureAttr( 'f', formatMessage( messages.viewApp ) ) }
      >
        <div className='MobileFooterViewOurApp__imgWrapper'>
          <Image
            src={ fullyQualifyLink( host, getApp_phone ) }
            alt='View Our App'
            lazyLoad={ true }
          />
        </div>
        <div className='MobileFooterViewOurApp__textWrapper'>
          <p className='MobileFooterViewOurApp__textWrapper__heading'>
            { formatMessage( messages.viewApp ) }
          </p>
          <p className='MobileFooterViewOurApp__textWrapper__p MobileFooterViewOurApp__textWrapper__p--top'>{ formatMessage( messages.top ) }</p>
          <p className='MobileFooterViewOurApp__textWrapper__p MobileFooterViewOurApp__textWrapper__p--bottom'>{ formatMessage( messages.bottom ) }</p>
        </div>

        <div className='MobileFooterViewOurApp__imgRightArrow'>
          <ChevronRightSVG />
        </div>

      </Anchor>
      <div className='clearfix'></div>
    </div>
  );

}

MobileFooterViewOurApp.propTypes = propTypes;

export default MobileFooterViewOurApp;
