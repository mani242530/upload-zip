/*
 * MobileFooterViewOurApp Messages
 *
 * This contains all the text for the MobileFooterViewOurApp component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  openApp: {
    id: 'i18n.MobileFooterViewOurApp.openApp',
    defaultMessage: 'Open the app'
  },
  viewApp: {
    id: 'i18n.MobileFooterViewOurApp.viewApp',
    defaultMessage: 'View Our App'
  },
  top: {
    id: 'i18n.MobileFooterViewOurApp.top',
    defaultMessage: 'Access to what you love '
  },
  bottom: {
    id: 'i18n.MobileFooterViewOurApp.bottom',
    defaultMessage: 'about us... wherever & whenever!'
  }
} );
