import React from 'react';
import MobileFooterViewOurApp from './MobileFooterViewOurApp';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './MobileFooterViewOurApp.messages';
import getApp_phone from 'static/getApp_phone.jpeg';
import {
  host,
  fullyQualifyLink
} from 'utils/Formatters/formatters';

describe( '<MobileFooterViewOurApp />', () => {
  const componentWithApp = mountWithIntl( <MobileFooterViewOurApp appInstalled={ true } /> );
  const containerWithApp = componentWithApp.find( 'MobileFooterViewOurApp' );

  const componentWithoutApp = mountWithIntl( <MobileFooterViewOurApp appInstalled={ false } /> );
  const containerWithoutApp = componentWithoutApp.find( 'MobileFooterViewOurApp' );

  it( 'renders without crashing', () => {
    // component = mountWithIntl(<MobileFooterViewOurApp appInstalled={false} />);
    expect( componentWithApp.find( 'MobileFooterViewOurApp' ).length ).toBe( 1 );
    expect( componentWithoutApp.find( 'MobileFooterViewOurApp' ).length ).toBe( 1 );
  } );

  it( 'should render correct image src url', () => {
    let containerImage = containerWithApp.find( 'Image' ).at( 0 );
    expect( containerImage.at( 0 ).props().src ).toEqual( fullyQualifyLink( host, getApp_phone ) );
  } );

  it( 'renders the \'View our App\' message', () => {
    let appInstalledMsg = containerWithApp.find( 'p' ).at( 0 );
    expect( appInstalledMsg.text() ).toEqual( messages.viewApp.defaultMessage );
  } );

  it( 'renders correct top message when the user does or does not have the app installed', () => {
    let appInstalledMsg = containerWithApp.find( 'p' ).at( 1 );
    let appNotInstalledMsg = containerWithoutApp.find( 'p' ).at( 1 );
    expect( appInstalledMsg.text() ).toEqual( messages.top.defaultMessage );
    expect( appNotInstalledMsg.text() ).toEqual( messages.top.defaultMessage );
  } );

  it( 'renders correct bottom message when the user does or does not have the app installed', () => {
    let appInstalledMsg = containerWithApp.find( 'p' ).at( 2 );
    let appNotInstalledMsg = containerWithoutApp.find( 'p' ).at( 2 );
    expect( appInstalledMsg.text() ).toEqual( messages.bottom.defaultMessage );
    expect( appNotInstalledMsg.text() ).toEqual( messages.bottom.defaultMessage );
  } );

} );
