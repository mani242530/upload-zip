
/**
 * CreditCard
 */

import React from 'react';
import PropTypes from 'prop-types';
import { formatMessage } from 'shared/components/Global/Global';
import Divider from 'shared/components/Divider/Divider';
import Anchor from 'shared/components/Anchor/Anchor';
import messages from './CreditCardsFooter.messages';

import './CreditCardsFooter.css';


const propTypes = {
  helpPhoneNumber:PropTypes.string
}

const CreditCardsFooter = ( props ) => {



  let numberUrl = `tel:+${props.helpPhoneNumber}`;

  return (
    <div className='CreditCardsFooter'>
      <Divider dividerType='multi-color'/>
      <div className='CreditCardsFooter__container'>
        <div className='CreditCardsFooter__helpTextContainer'>
          <div className='CreditCardsFooter__helpTextContainer--cardIssueText'>
            <div className='CreditCardsFooter__helpTextContainer--cardIssueTextOne'>
              { formatMessage( messages.cardIssueThree ) }
            </div>
            <span className='CreditCardsFooter__helpTextContainer--cardIssueTextTwo'>
              { formatMessage( messages.cardIssueTwo ) }
              <Anchor
                target='_blank'
                className='CreditCardsFooter__link'
                url='/ulta/creditcards/landingpage.jsp'
              >
                { formatMessage( messages.helpLink ) }
              </Anchor>
            </span>
            <div className='CreditCardsFooter__helpTextContainer--cardIssueTextThree'>
              { formatMessage( messages.cardIssueOne ) }
            </div>
          </div>

          <div className='CreditCardsFooter__helpTextContainer--helpText'>
            { formatMessage( messages.hereToHelp ) }
            <Anchor
              className='CreditCardsFooter__helpTextContainer--helpText phone'
              url={ numberUrl }
            >
              { props.helpPhoneNumber }
            </Anchor>
          </div>

        </div>
      </div>
    </div>
  )

}

CreditCardsFooter.propTypes = propTypes;

export default CreditCardsFooter;



