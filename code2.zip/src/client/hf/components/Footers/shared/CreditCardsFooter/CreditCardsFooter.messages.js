
/*
 * CreditCardsFooter  Messages
 *
 * This contains all the text for the MobileFooter component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  hereToHelp: {
    id: 'i18n.MobileFooter.hereToHelp',
    defaultMessage: 'Need help? Call us at'
  },
  helpPhone: {
    id: 'i18n.MobileFooter.helpPhone',
    defaultMessage: '866-983-8582'
  },
  helpLink: {
    id: 'i18n.MobileFooter.helpLink',
    defaultMessage: ' ulta.com/credit.'
  },
  cardIssueOne: {
    id: 'i18n.MobileFooter.cardIssueOne',
    defaultMessage: 'The Ultamate Rewards® Mastercard® is issued by Comenity Capital Bank pursuant to a license from Mastercard.  Mastercard and the Mastercard Brand Mark are registered trademarks of Mastercard International Incorporated.'
  },
  cardIssueTwo: {
    id: 'i18n.MobileFooter.cardIssueTwo',
    defaultMessage: 'The Ultamate Rewards® Program is offered by Ulta Beauty® and its terms may change at any time. For program information, points balance, and full rewards terms and conditions, please visit'
  },
  cardIssueThree: {
    id: 'i18n.MobileFooter.cardIssueThree',
    defaultMessage: '*Subject to credit approval. 20% off all products and services on your first purchase with your credit card. 20% discount is only at Ulta Beauty and cannot be applied to previous purchases or gift cards.'
  }
} );
