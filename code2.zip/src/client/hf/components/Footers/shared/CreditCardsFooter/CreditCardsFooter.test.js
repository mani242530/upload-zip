import React from 'react';
import ReactDOM from 'react-dom';
import CreditCardsFooter from './CreditCardsFooter';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { IntlProvider } from 'react-intl';
import messages from './CreditCardsFooter.messages';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { Provider } from 'react-redux';

describe( '<CreditCardsFooter />', () => {
  const store = configureStore( {}, CONFIG );
  let component = mountWithIntl(
    <Provider store={ store }>
      <CreditCardsFooter />
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'CreditCardsFooter' ).length ).toBe( 1 );
  } );

  it( 'should have one CreditCardsFooter__helpTextContainer', () => {
    expect( component.find( '.CreditCardsFooter__helpTextContainer--cardIssueText' ).length ).toBe( 1 );
  } );

  it( 'it should show the card issue three message', () => {
    expect( component.find( '.CreditCardsFooter__helpTextContainer--cardIssueTextOne' ).at( 0 ).text() ).toBe( messages.cardIssueThree.defaultMessage );
  } );

  it( 'it should show the card issue two message', () => {
    expect( component.find( '.CreditCardsFooter__helpTextContainer--cardIssueTextTwo' ).at( 0 ).text() ).toMatch( messages.cardIssueTwo.defaultMessage );
  } );

  it( 'it should show the Anchor tag', () => {
    expect( component.find( '.CreditCardsFooter__helpTextContainer--cardIssueTextTwo' ).find( 'Anchor' ).length ).toBe( 1 );
  } );

  it( 'it should display the help link', () => {
    expect( component.find( '.CreditCardsFooter__helpTextContainer--cardIssueTextTwo' ).find( 'Anchor' ).at( 0 ).text() ).toMatch( messages.helpLink.defaultMessage );
  } );

  it( 'it should show the card issue one message', () => {
    expect( component.find( '.CreditCardsFooter__helpTextContainer--cardIssueTextThree' ).at( 0 ).text() ).toBe( messages.cardIssueOne.defaultMessage );
  } );

  it( 'it should display the help text', () => {
    expect( component.find( '.CreditCardsFooter__helpTextContainer--helpText' ).at( 0 ).text() ).toBe( messages.hereToHelp.defaultMessage );
  } );

} );
