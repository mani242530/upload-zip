/**
 * Header
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import MobileHeader from 'hf/components/Headers/mobile/MobileHeader/MobileHeader';
import classNames from 'classnames';
import './Header.css';
import { formatMessage } from 'shared/components/Global/Global';
import DesktopHeader from 'hf/components/Headers/desktop/DesktopHeader/DesktopHeader';
import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';
import messages from 'hf/components/Header/Header.messages';

import {
  actions as headerActions
} from 'hf/actions/Header/Header.actions'

import {
  actions as mobileLeftNavActions
} from 'hf/actions/MobileLeftNav/MobileLeftNav.actions'
import {
  actions as userActions
} from 'shared/actions/User/User.actions';

export const _SHOPPING_CART_URL = '/bag';

class Header extends Component{

  render(){

    return (
      <div className='Header'>
        { this.props.isMobileDevice &&
          <MobileHeader
            { ...this.props }
            ShoppingCartURL={ _SHOPPING_CART_URL }
          />
        }

        { !this.props.isMobileDevice &&
          <DesktopHeader
            { ...this.props }
            ShoppingCartURL={ _SHOPPING_CART_URL }
          />
        }
      </div>
    )
  }
}


export const mapStateToProps = ( state ) => {
  return {
    ...state.global,
    ...state.header,
    ...state.mobileLeftNav,
    ...state.session,
    ...state.user
  };
}



export const mapDispatchToProps = ( dispatch ) => {

  return {
    toggleSearchMode: ( mode, stickyContainerOffset, stickyContainerHeight ) => {
      dispatch( headerActions.toggleSearchMode( mode, stickyContainerOffset, stickyContainerHeight ) );
    },

    setMainNavBarHeight: ( height ) => {
      dispatch( headerActions.setMainNavBarHeight( height ) );
    },

    setHeaderHeight: ( normalHeight, stickyHeight ) => {
      dispatch( headerActions.setHeaderHeight( normalHeight, stickyHeight ) );
    },

    setShippingBannerHeight: ( height ) => {
      dispatch( headerActions.setShippingBannerHeight( height ) );
    },

    getNavItemList: ( navData ) => {
      dispatch( headerActions.getNavItemList( navData ) )
    },

    toggleLeftNav: ( mode ) => {
      dispatch( mobileLeftNavActions.toggleLeftNav( mode ) );
      dispatch( globalActions.enableDisableDocumentScroll( true ) );
    },

    logoutUser: ( history ) =>{
      dispatch( userActions.logoutUser( history ) )
    }

  };
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( Header ) );
};

export default connectFunction( mapStateToProps, mapDispatchToProps );
