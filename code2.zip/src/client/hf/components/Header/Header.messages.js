import { defineMessages } from 'react-intl';

export default defineMessages( {


  freeShipping: {
    id: 'i18n.Header.freeShipping',
    defaultMessage: 'You\'ve earned FREE shipping!'
  },
  spendMore: {
    id: 'i18n.Header.spendMore',
    defaultMessage: 'Only $50.00 away from FREE shipping'
  }
} );
