import React from 'react';
import Header, { mapDispatchToProps } from './Header';
import { Provider } from 'react-redux';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import messages from 'hf/components/Header/Header.messages';
import { shallow } from 'enzyme';
import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';
import {
  actions as mobileLeftNavActions
} from 'hf/actions/MobileLeftNav/MobileLeftNav.actions'
import {
  actions as userActions
} from 'shared/actions/User/User.actions';
import {
  actions as headerActions
} from 'hf/actions/Header/Header.actions'

describe( 'Header state methods', () => {
  let store = configureStore( {}, CONFIG );
  let component = mountWithIntl(
    <Provider store={ store }>
      <Header />
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'Header' ).length ).toBe( 1 );
  } );

  let dispatch = jest.fn();


  beforeEach( ()=> {
    dispatch.mockClear();
  } )

  let mdp  = mapDispatchToProps( dispatch );

  it( 'toggleSearchMode should dispatch the proper action', () => {
    const mode='close';
    const stickyContainerOffset = 0;
    const stickyContainerHeight = 1;
    let event = mdp.toggleSearchMode( mode, stickyContainerOffset, stickyContainerHeight );
    expect( dispatch ).toHaveBeenCalledWith(
      headerActions.toggleSearchMode( mode, stickyContainerOffset, stickyContainerHeight )
    );
  } );

  it( 'setMainNavBarHeight should dispatch the proper action', () => {
    const height = 30;
    let event = mdp.setMainNavBarHeight( height );
    expect( dispatch ).toHaveBeenCalledWith(
      headerActions.setMainNavBarHeight( height )
    );
  } );

  it( 'setHeaderHeight should dispatch the proper action', () => {
    const normalHeight = 0 ;
    const stickyHeight = 0;
    let event = mdp.setHeaderHeight( normalHeight, stickyHeight );
    expect( dispatch ).toHaveBeenCalledWith(
      headerActions.setHeaderHeight( normalHeight, stickyHeight )
    );
  } );

  it( 'setShippingBannerHeight should dispatch the proper action', () => {
    const height = 30;
    let event = mdp.setShippingBannerHeight( height );
    expect( dispatch ).toHaveBeenCalledWith(
      headerActions.setShippingBannerHeight( height )
    );
  } );

  it( 'getNavItemList should dispatch the proper action', () => {
    const navData = [];
    let event = mdp.getNavItemList( navData );
    expect( dispatch ).toHaveBeenCalledWith(
      headerActions.getNavItemList( navData )
    );
  } );

  it( 'toggleLeftNav should dispatch the proper action', () => {
    const event = mdp.toggleLeftNav( false );
    expect( dispatch ).toHaveBeenCalledWith(
      mobileLeftNavActions.toggleLeftNav( false )
    );
    expect( dispatch ).toHaveBeenCalledWith(
      globalActions.enableDisableDocumentScroll( true )
    );
  } );

  it( 'logoutUser should dispatch the proper action', () => {
    const event = mdp.logoutUser( );
    expect( dispatch ).toHaveBeenCalledWith(
      userActions.logoutUser( )
    );
  } );

} );
