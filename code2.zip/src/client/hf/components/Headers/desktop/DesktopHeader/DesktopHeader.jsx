/**
 * DesktopHeader
 */

import React, { Component } from 'react';
import './DesktopHeader.css';
import Anchor from 'shared/components/Anchor/Anchor';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './DesktopHeader.messages';
import MiniCart from 'hf/components/MiniCart/MiniCart';
import TypeAheadSearch from 'hf/components/TypeAheadSearch/TypeAheadSearch';
import { isUndefined, has } from 'lodash';
import classNames from 'classnames';
import ShippingBanner from 'hf/components/Headers/shared/ShippingBanner/ShippingBanner';
import Rewards from 'hf/components/Rewards/Rewards';
import SVG from 'shared/components/Icons/chevrondown';
import Logo from 'shared/components/Logo/Logo';
import SignInMenu from 'shared/components/SignInMenu/SignInMenu';
import { formatOmnitureAttr } from 'utils/Omniture/Omniture';
import { host } from 'utils/Formatters/formatters';

/**
 * Class
 * @extends React.Component
 */
export const initialState = {
  showSignIn: false,
  rewardsFlag: false
};


class DesktopHeader extends Component{

  /**
   * Create a DesktopHeader
   */
  constructor( props ){
    super( props );
    this.state = initialState;
    this.rewardsOptionToggle = this.rewardsOptionToggle.bind( this, this.state.rewardsFlag );
    this.showSignInOptions = this.showSignInOptions.bind( this, this.state.showSignIn );
  }

  /**
   * Renders the DesktopHeader component
   */
  toggleSearchMode( display ){
    let stickynavEl = document.getElementById( 'navigation__wrapper--sticky' );
    let boundingPos = stickynavEl.getBoundingClientRect();
    this.props.toggleSearchMode( display, boundingPos.top, boundingPos.height );
  }

  rewardsOptionToggle( rewardsFlagParam ){
    this.setState( { rewardsFlag: !this.state.rewardsFlag } );
    this.setState( { showSignIn: false } );
  }

  showSignInOptions( signinFlag ){
    this.setState( { showSignIn: !this.state.showSignIn } );
    this.setState( { rewardsFlag: false } );

  }

  render(){


    return (
      <div className='DesktopHeader'>
        <div className={
          classNames( {
            'DesktopHeader__StickyHeader':  this.props.desktopHeaderDisplayMode === 'default'
          } )
        }
        >
          <nav className={
            classNames( 'NavigationBar', {
              'NavigationBar--simpleHeader':  this.props.desktopHeaderDisplayMode === 'focused'
            } )
          }
          >

            { ( ()=>{
              if( this.props.desktopHeaderDisplayMode === 'default' ){
                return (
                  <div>
                    <div className='NavigationBar__item NavigationBar--search'>
                      <TypeAheadSearch
                        displayType='desktop'
                        searchMode='open'
                        closeSearchMode={ this.toggleSearchMode }
                      />
                    </div>
                    <div className='NavigationBar__item NavigationBar__item--navElement'>
                      <Anchor
                        url={ 'https://' + host + ( this.props.switchData && this.props.switchData.switches ? this.props.switchData.switches.storeLocatorURL : '/ulta/stores/storelocator.jsp' ) }
                        dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.findStore ) ) }
                      >
                        { formatMessage( messages.findStore ) }
                      </Anchor>
                    </div>
                    <div className='NavigationBar__item NavigationBar__item--navElement'>
                      <Anchor
                        url='//pages.exacttarget.com/ulta-email-signup/'
                        dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.emailSignUp ) ) }
                      >
                        { formatMessage( messages.emailSignUp ) }
                      </Anchor>
                    </div>
                    <div className='NavigationBar__item NavigationBar__item--navElement'>
                      <Anchor
                        url='/giftcards'
                        dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.giftCards ) ) }
                      >
                        { formatMessage( messages.giftCards ) }
                      </Anchor>
                    </div>
                    <div
                      className='NavigationBar__item NavigationBar__item--navElement NavigationBar__item--signin'
                      onClick={ this.showSignInOptions.bind( this, this.state.showSignIn ) }
                    >
                      { ( () => {
                        if( this.props.isSignedIn ){

                          return (
                            <div className='NavigationBar__item--signin userProfile'>
                              { ( () => {
                                if( this.state.showSignIn ){
                                  return (
                                    <SignInMenu
                                      history={ this.props.history }
                                      userLogout={ this.props.logoutUser }
                                    />
                                  )
                                }
                              } )() }
                              <div className='NavigationBar__item NavigationBar__item--rewardsChevron'>
                                { formatMessage( messages.welcomeMessage, { name: this.props.userName } ) }
                                <div className='NavigationBar__item NavigationBar__item--rewardsChevron--svg'>
                                  <SVG/>
                                </div>
                              </div>
                            </div>
                          )
                        }
                        else {
                          return (
                            <Anchor url='/ulta/myaccount/login.jsp'
                              dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.signIn ) ) }
                              title='Sign in'
                            >
                              { formatMessage( messages.signIn ) }
                            </Anchor>
                          )
                        }

                      } )() }
                    </div>
                    <div
                      className='NavigationBar__item NavigationBar__item--rewards'
                      onClick={ this.rewardsOptionToggle.bind( this, this.state.rewardsFlag ) }
                    >

                      <div className='NavigationBar__item NavigationBar__item--rewardsChevron'
                        title='Get Ultamate Rewards'
                        role='button'
                        aria-expanded={ this.state.rewardsFlag }
                      >
                        <div className='NavigationBar__item NavigationBar__item--rewardsChevron--text'>
                          { formatMessage( messages.rewards ) }
                        </div>
                        <div className='NavigationBar__item NavigationBar__item--rewardsChevron--svg'>
                          <SVG/>
                        </div>
                      </div>

                      { ( () => {
                        if( this.state.rewardsFlag ){
                          return (
                            <Rewards
                              signedIn={ this.props.isSignedIn }
                              rewardsMember={ this.props.isRewardsMember }
                              memberId={ this.props.memberId }
                              rewardPointTotal={ this.props.rewardPointTotal }
                              memberStatus={ this.props.memberStatus }
                              isCardHolder={ ( !isUndefined( this.props.rewardsInfo ) && has( this.props, 'rewardsInfo.isCardholder' ) )? this.props.rewardsInfo.isCardHolder : false }
                            />

                          )
                        }
                      } )() }
                    </div>
                    <div className='NavigationBar__item NavigationBar__item--cart'>
                      <MiniCart
                        url={ has( this.props.switchData, 'switches.cartURL' )? this.props.switchData.switches.cartURL : this.props.ShoppingCartURL }
                        alt=''
                        label=''
                      />
                    </div>
                  </div>
                )
              }
              else if( this.props.desktopHeaderDisplayMode === 'focused' ){
                return (
                  <div className='NavigationBar__item NavigationBar__item__simpleHeader'>
                    <div className='NavigationBar__item NavigationBar__item__simpleHeader--logo'>
                      <Logo/>
                    </div>
                    <div className='NavigationBar__item NavigationBar__item__simpleHeader--bag'>
                      <MiniCart
                        url={ has( this.props.switchData, 'switches.cartURL' )? this.props.switchData.switches.cartURL : this.props.ShoppingCartURL }
                        alt=''
                        label=''
                      />
                    </div>
                  </div>
                )
              }
            } )() }
          </nav>
          { ( () => {
            if( this.props.desktopHeaderDisplayMode !== 'focused' ){
              let shippingBannerMessage = undefined;
              let bannerUrl = undefined;
              if( this.props.cartPageShippingBanner.message !== undefined && this.props.shoppingCartCount !== 0 ){
                shippingBannerMessage = this.props.cartPageShippingBanner.message;
                bannerUrl='';
              }
              else if( this.props.shippingBanner.message !== undefined && this.props.type === 'generic' ){
                shippingBannerMessage = this.props.shippingBanner.message;
                bannerUrl = this.props.shippingBanner.url;
              }

              if( shippingBannerMessage ){
                return (
                  <div className='Header_Banners'>
                    <div className='Header__shippingPanel'>
                      <ShippingBanner
                        message={ shippingBannerMessage }
                        url={ bannerUrl }
                      />
                    </div>
                  </div>
                )
              }

            }
          } )() }
        </div>
      </div>
    )
  }
}

export default DesktopHeader;
