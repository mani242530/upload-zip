/*
 * DesktopHeader Messages
 *
 * This contains all the text for the DesktopHeader component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.DesktopHeader.header',
    defaultMessage: 'This is the DesktopHeader component !'
  },
  welcomeMessage: {
    id: 'i18n.DesktopHeader.welcomeMessage',
    defaultMessage: 'Hi, {name}'
  },
  findStore: {
    id: 'i18n.DesktopHeader.findStore',
    defaultMessage: 'Find a Store'
  },
  emailSignUp: {
    id: 'i18n.DesktopHeader.emailSignUp',
    defaultMessage: 'Email Signup'
  },
  giftCards: {
    id: 'i18n.DesktopHeader.giftCards',
    defaultMessage: 'Gift Cards'
  },
  signIn: {
    id: 'i18n.DesktopHeader.signIn',
    defaultMessage: 'Sign In'
  },
  rewards: {
    id: 'i18n.DesktopHeader.rewards',
    defaultMessage: 'Rewards'
  }
} );

