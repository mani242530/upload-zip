import React from 'react';
import ReactDOM from 'react-dom';
import DesktopHeader from './DesktopHeader';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { initialState } from 'hf/reducers/Header/Header.reducer';
import { Provider } from 'react-redux';
import Anchor from 'shared/components/Anchor/Anchor';
import messages from './DesktopHeader.messages';
import _ from 'lodash';

var placeholder = document.createElement( 'div' );
global.requestAnimationFrame = jest.fn();

placeholder.height = 300;
document.getElementById = jest.fn().mockReturnValue( placeholder );


describe( '<DesktopHeader />', () => {

  let props = initialState;
  const store = configureStore( {}, CONFIG );
  props.setHeaderHeight = jest.fn();
  props.setShippingBannerHeight = jest.fn();
  props.toggleLeftNav = jest.fn();
  props.setMainNavBarHeight = jest.fn();
  props.getNavItemList = jest.fn();
  const oldCartUrl = '/bag'

  let component = mountWithIntl(
    <Provider store={ store }>
      <DesktopHeader { ...props } ShoppingCartURL={ oldCartUrl }/>
    </Provider>
  );


  it( 'renders without crashing', () => {

    expect( component.find( '.NavigationBar' ).length ).toBe( 1 );
  } );

  it( 'should have the proper react component as children', () => {
    expect( component.find( '.NavigationBar__item .NavigationBar__item--navElement' ).find( 'Anchor' ).length ).toBe( 4 );
    expect( component.find( '.NavigationBar__item--rewardsChevron--svg' ).find( 'SVG' ).length ).toBe( 1 );
    expect( component.find( '.NavigationBar__item--cart' ).children().find( 'MiniCart' ).length ).toBe( 1 );
  } );

  it( 'Should contain https in the \'Find a Store\' link', () => {
    expect( component.find( '.NavigationBar__item--navElement' ).find( Anchor ).at( 0 ).props().url ).toContain( 'https' );
  } );

  it( 'Should contain links as given in src prop of Anchor component', () => {
    expect( component.find( '.NavigationBar__item--navElement' ).find( Anchor ).at( 1 ).props().url ).toBe( '//pages.exacttarget.com/ulta-email-signup/' );
    expect( component.find( '.NavigationBar__item--navElement' ).find( Anchor ).at( 2 ).props().url ).toBe( '/giftcards' );
  } );

  it( 'Should contain labels as given on the navigation panel', () => {
    expect( component.find( '.NavigationBar__item--navElement' ).children().find( 'Anchor' ).at( 0 ).props().children ).toBe( messages.findStore.defaultMessage );
    expect( component.find( '.NavigationBar__item--navElement' ).children().find( 'Anchor' ).at( 1 ).props().children ).toBe( messages.emailSignUp.defaultMessage );
    expect( component.find( '.NavigationBar__item--navElement' ).children().find( 'Anchor' ).at( 2 ).props().children ).toBe( messages.giftCards.defaultMessage );
    expect( component.find( '.NavigationBar__item--rewards' ).text() ).toBe( 'Rewards' );
  } );

  it( 'should only render the logo and bag component when in desk mode for checkout page', () => {
    let props = initialState;
    const store = configureStore( {}, CONFIG );
    props.setHeaderHeight = jest.fn();
    props.setShippingBannerHeight = jest.fn();
    props.toggleLeftNav = jest.fn();
    props.setMainNavBarHeight = jest.fn();
    props.getNavItemList = jest.fn();
    props.desktopHeaderDisplayMode = 'focused';

    let component = mountWithIntl(
      <Provider store={ store }>
        <DesktopHeader { ...props } ShoppingCartURL={ oldCartUrl }/>
      </Provider>
    );
    expect( component.find( '.DesktopHeader' ).children().find( 'Logo' ).length ).toBe( 1 );
    expect( component.find( '.NavigationBar__item--cart' ).children().find( 'MiniCart' ).length ).toBe( 0 );
  } );

  it( 'Should contain toggle function for Rewards components', () => {

    let mockFun = component.find( 'DesktopHeader' );
    mockFun.showSignInOptions = jest.fn();
    mockFun.showSignInOptions( true );
    expect( mockFun.showSignInOptions ).toBeCalled();
    mockFun.rewardsOptionToggle = jest.fn();
    mockFun.rewardsOptionToggle( true );
    expect( mockFun.showSignInOptions ).toBeCalled();
  } );



  it( 'Should render Reward component when clicked on `NavigationBar__item--rewards` div', () => {
    component.find( '.NavigationBar__item--rewards' ).simulate( 'click' );
    expect( component.find( '.NavigationBar__item--rewards' ).children().find( 'Rewards' ).length ).toBe( 1 );
  } );

  it( 'Should render Reward component when clicked on `NavigationBar__item--signin` div', () => {
    component.find( '.NavigationBar__item--signin' ).simulate( 'click' );
    expect( component.find( '.NavigationBar__item--signin' ).find( 'SignInMenu' ).length ).toBe( 0 );
  } );
  let props1={
    desktopHeaderDisplayMode:'focused',
    cartPageShippingBanner:{},
    shippingBanner:{
      message: undefined
    }
  }
  let component1 = mountWithIntl(
    <Provider store={ store }>
      <DesktopHeader { ...props1 } ShoppingCartURL={ oldCartUrl }/>
    </Provider>
  );
  it( 'shoud render simple header if desktopHeaderDisplayMode is focused', () => {
    expect( component1.find( '.NavigationBar__item__simpleHeader' ).length ).toBe( 1 );
  } );
  it( 'shoud render logo for simpleHeader', () => {
    expect( component1.find( '.NavigationBar__item__simpleHeader--logo' ).length ).toBe( 1 );
  } );

  let props2 = {
    desktopHeaderDisplayMode: 'default',

    cartPageShippingBanner:{
      message: 'undefined'
    },
    shippingBanner:{
      message: undefined
    },
    switchData : {
      switches: {
        cartURL : '/bag'
      }
    }
  }

  let component2 = mountWithIntl(
    <Provider store={ store }>
      <DesktopHeader { ...props2 } ShoppingCartURL={ oldCartUrl }/>
    </Provider>
  );
  let newCartUrl = '/bag';

  it( 'should have new cart url if switch data is available ', () => {

    expect( component2.find( 'MiniCart' ).at( 0 ).props().url ).toBe( newCartUrl );
  } );

  it( 'if the switches data is not available should go to old url', ()=>{
    let props2 = {
      desktopHeaderDisplayMode: 'default',

      cartPageShippingBanner:{
        message: 'undefined'
      },
      shippingBanner:{
        message: undefined
      },
      switchData : {
        switches: {

        }
      }
    }

    let component3 = mountWithIntl(
      <Provider store={ store }>
        <DesktopHeader { ...props2 } ShoppingCartURL={ oldCartUrl }/>
      </Provider>
    );

    component3 = mountWithIntl(
      <Provider store={ store }>
        <DesktopHeader { ...props2 } ShoppingCartURL={ oldCartUrl }/>
      </Provider>
    );
    expect( component3.find( 'MiniCart' ).at( 0 ).props().url ).toBe( oldCartUrl );
  } );
  it( 'Should display the shipping banner only if shoppingCart count is greater than 1', ()=>{
    let props3 = {
      desktopHeaderDisplayMode: 'default',
      shoppingCartCount : 1,
      cartPageShippingBanner:{
        message: 'You have earned free shipping'
      },
      shippingBanner:{
        message: undefined
      },
      switchData : {
        switches: {

        }
      }
    }

    let component4 = mountWithIntl(
      <Provider store={ store }>
        <DesktopHeader { ...props3 } ShoppingCartURL={ oldCartUrl }/>
      </Provider>
    );

    expect( component4.find( '.Header_Banners' ).length ).toBe( 1 );
  } );


  it( 'Should not display the shipping banner if type generic is not there in props and there is cartPageShippingBannerMessage in emptycart page', ()=>{
    let props3 = {
      desktopHeaderDisplayMode: 'default',
      shoppingCartCount : 0,
      cartPageShippingBanner:{
        message: 'You have earned free shipping'
      },
      shippingBanner:{
        message: 'You have earned free shipping'
      },
      switchData : {
        switches: {

        }
      }
    }

    let component4 = mountWithIntl(
      <Provider store={ store }>
        <DesktopHeader { ...props3 } ShoppingCartURL={ oldCartUrl }/>
      </Provider>
    );

    expect( component4.find( '.Header_Banners' ).length ).toBe( 0 );
  } );

  it( 'Should display the shipping banner in PDP paage', ()=>{
    let props5= {
      desktopHeaderDisplayMode: 'default',
      type:'generic',
      shoppingCartCount : 0,
      cartPageShippingBanner:{
        message: undefined
      },
      shippingBanner:{
        message: 'You have earned free shipping'
      },
      switchData : {
        switches: {

        }
      }
    }

    let component4 = mountWithIntl(
      <Provider store={ store }>
        <DesktopHeader { ...props5 } />
      </Provider>
    );

    expect( component4.find( '.Header_Banners' ).length ).toBe( 1 );
  } );

  let props4 = {
    desktopHeaderDisplayMode: 'default',
    shoppingCartCount : 0,
    cartPageShippingBanner:{
      message: 'You have earned free shipping'
    },
    shippingBanner:{
      message: undefined
    }
  }

  let component5 = mountWithIntl(
    <Provider store={ store }>
      <DesktopHeader { ...props4 } ShoppingCartURL={ oldCartUrl }/>
    </Provider>
  );

  it( 'role and aria-expanded attribute is present for the rewards component', () => {
    expect( component5.find( '.NavigationBar__item .NavigationBar__item--rewardsChevron' ).length ).toBe( 1 );
    expect( component5.find( '.NavigationBar__item .NavigationBar__item--rewardsChevron' ).props().role ).toBe( 'button' );
    expect( component5.find( '.NavigationBar__item .NavigationBar__item--rewardsChevron' ).props()['aria-expanded'] ).toBe( false );
  } );

  it( 'aria-expanded attribute should have the value true for rewards component when rewards menu is expanded', () => {
    component5.find( '.NavigationBar__item--rewards' ).simulate( 'click' );
    expect( component5.find( '.NavigationBar__item .NavigationBar__item--rewardsChevron' ).props()['aria-expanded'] ).toBe( true );
  } );

  it( 'should have NavigationBar__item--signin userProfile if isSignedIn is true', () => {
    let props5 = {
      isSignedIn: true,
      desktopHeaderDisplayMode: 'default',
      shoppingCartCount : 0,
      cartPageShippingBanner:{
        message: 'You have earned free shipping'
      },
      shippingBanner:{}
    }

    let component6 = mountWithIntl(
      <Provider store={ store }>
        <DesktopHeader { ...props5 } ShoppingCartURL={ oldCartUrl }/>
      </Provider>
    );
    const instance = component6.find( 'DesktopHeader' ).instance();
    instance.showSignInOptions( true );

    expect( component6.find( '.NavigationBar__item--signin .userProfile' ).length ).toBe( 1 );
  } );

  it( 'should call props.toggleSearchMode when toggleSearchMode with input as close is called ', () => {
    const props = {
      toggleSearchMode: jest.fn(),
      cartPageShippingBanner:{
        message: 'You have earned free shipping'
      }
    }

    const component = mountWithIntl(
      <Provider store={ store }>
        <DesktopHeader { ...props } ShoppingCartURL={ oldCartUrl }/>
      </Provider>
    );
    const instance = component.find( 'DesktopHeader' ).instance();
    instance.toggleSearchMode( 'close' );
    expect( props.toggleSearchMode ).toBeCalled();
  } );

} );
