/**
 * HamburgerBtn
 */

import React from 'react';
import './HamburgerBtn.css';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './HamburgerBtn.messages';
import MinusSVG from 'shared/components/Icons/minus';

const HamburgerBtn = ( props ) => {

  return (
    <div
      className='HamburgerBtn'
      onClick={ props.onClick }
    >
      <div className='HamburgerBtn HamburgerBtn__container'>
        <div className='HamburgerBtn__icon'>
          <MinusSVG />
        </div>
        <div className='HamburgerBtn__icon'>
          <MinusSVG />
        </div>
        <div className='HamburgerBtn__icon'>
          <MinusSVG />
        </div>
      </div>
      <span className='HamburgerBtn__label'
        id='menu_HamburgerBtn'
        role='button'
        tabIndex='-1'
      >
        <span>{ formatMessage( messages.label ) }</span>
      </span>
    </div>
  );
}

export default HamburgerBtn;
