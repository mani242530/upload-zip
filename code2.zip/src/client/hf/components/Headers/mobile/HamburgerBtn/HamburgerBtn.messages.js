/*
 * HamburgerBtn Messages
 *
 * This contains all the text for the HamburgerBtn component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  label: {
    id: 'i18n.HamburgerBtn.label',
    defaultMessage: 'Menu'
  }
} );
