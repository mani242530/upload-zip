import React from 'react';
import HamburgerBtn from './HamburgerBtn';
import MinusSVG from 'shared/components/Icons/minus';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
// import renderer from 'react-test-renderer';

describe( '<HamburgerBtn />', () => {
  const component = mountWithIntl( <HamburgerBtn /> ).find( 'HamburgerBtn' );

  it( 'renders without crashing', () => {
    expect( component ).toBeTruthy();
  } );

  it( 'should have 3 Minus SVG elements as children', () => {
    let svgs = component.find( 'HamburgerBtn' ).find( MinusSVG );
    expect( svgs.length ).toBe( 3 );

  } );
  it( 'should have id as menu_HamburgerBtn', () => {
    let id = component.find( 'HamburgerBtn .HamburgerBtn__label' ).props().id;
    expect( id ).toBe( 'menu_HamburgerBtn' );

  } );

  it( 'should have role as button', () => {
    let role = component.find( 'HamburgerBtn .HamburgerBtn__label' ).props().role;
    expect( role ).toBe( 'button' );

  } );

  it( 'should have tabIndex as -1 ', () => {
    let tabIndex = component.find( 'HamburgerBtn .HamburgerBtn__label' ).props().tabIndex;
    expect( tabIndex ).toBe( '-1' );

  } );
} );