/**
 * MainNavBtn
 */

import React from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import Anchor from 'shared/components/Anchor/Anchor';
import './MainNavBtn.css';



const propTypes = {
  Svg: PropTypes.func.isRequired,
  dataNavDescription: PropTypes.string,
  label: PropTypes.string.isRequired,
  url: PropTypes.string.isRequired,
  ariaLabel: PropTypes.string,
  onClick: PropTypes.func,
  id: PropTypes.string
}



/**
 * Class
 * @extends React.Component
 */
const MainNavBtn = ( props ) => {

  const {
    ariaLabel,
    Svg,
    label,
    url,
    dataNavDescription,
    children,
    id
  } = props;


  return (
    <div
      className={
        classNames( {
          'MainNavBtn': true
        } )
      }
      onClick={ props.onClick }
    >
      <Anchor
        id={ id }
        url={ url }
        dataNavDescription={ dataNavDescription }
        ariaLabel={ ariaLabel }
      >
        <Svg />
        <span className='MainNavBtn__label'>
          { label }
        </span>
        { children }
      </Anchor>
    </div>
  );

}

MainNavBtn.propTypes = propTypes;

export default MainNavBtn;
