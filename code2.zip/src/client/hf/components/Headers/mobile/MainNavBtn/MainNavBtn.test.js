import React from 'react';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import MainNavBtn from './MainNavBtn';
import LocationSVG from 'shared/components/Icons/location.js';
import Anchor from 'shared/components/Anchor/Anchor';
import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';

describe( '<MainNavBtn />', () => {
  let component = shallow(
    <MainNavBtn
      Svg={ LocationSVG }
      label='tmp'
      url='www.ulta.com'
      id='mainNavBtn'
    />
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'div' ).length ).toBe( 1 );
  } );

  let childAnchor = component.children( Anchor );
  it( 'should have an anchor as a child', () => {
    expect( childAnchor.length ).toBe( 1 );
  } );

  it( 'anchor should have the url passed as an attribute', ()=> {
    expect( childAnchor.props().url ).toBe( 'www.ulta.com' );
  } );

  it( 'anchor should have the id passed as an attribute', ()=> {
    expect( childAnchor.props().id ).toBe( 'mainNavBtn' );
  } );



  describe( 'Child Components', () => {
    let imgTag = childAnchor.find( LocationSVG );
    it( 'should have an SVG as a child', () => {
      expect( imgTag.length ).toBe( 1 );
    } );

    it( 'should have a paragraph tag with the label as it\'s value', () => {
      let labeltag = childAnchor.find( 'span' );
      expect( labeltag.length ).toBe( 1 );
      expect( labeltag.html() ).toBe( '<span class="MainNavBtn__label">tmp</span>' );
    } );


  } )
} );
