/**
 * MobileHeader
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './MobileHeader.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './MobileHeader.messages';

// assets
import LocationSVG from 'shared/components/Icons/location';
import HamburgerBtn from 'hf/components/Headers/mobile/HamburgerBtn/HamburgerBtn';
import Logo from 'shared/components/Logo/Logo';
import SearchSVG from 'shared/components/Icons/search';
import MainNavBtn from 'hf/components/Headers/mobile/MainNavBtn/MainNavBtn';
import MiniCart from 'hf/components/MiniCart/MiniCart';
import ShippingBanner from 'hf/components/Headers/shared/ShippingBanner/ShippingBanner';
import TypeAheadSearch from 'hf/components/TypeAheadSearch/TypeAheadSearch';

import { isUndefined, throttle, has } from 'lodash';
import { isServer } from 'utils/DeviceDetection/deviceDetection';
import classNames from 'classnames';
import { formatOmnitureAttr } from 'utils/Omniture/Omniture';
import { host } from 'utils/Formatters/formatters';

const propTypes = {
  toggleLeftNav: PropTypes.func.isRequired
};

const currentScrollPosition = isServer() ? 0: window.scrollY;

export const initialState = {
  currentScrollPosition,
  StickyHeaderHeight: 0,
  MobileHeaderHeight: 0,
  shippingBannerHeight: 0,
  headerHeight: 0,
  previousScrollPosition: 0,
  hasUserScrolledUp: false,
  hasFoldBeenCrossed: false,
  displaySearchBar: true,
  headerMode: 'default',
  searchMode: 'close',
  headerAnimationStyles: {},
  searchModeAnimationStyles: {}
}

/**
 * Class
 * @extends React.Component
 */
class MobileHeader extends Component{

  /**
   * Create a MobileHeader
   */

  constructor( props ){
    super( props );

    this.state = initialState;
    this.setHeaderHeight = this.setHeaderHeight.bind( this );
    this.setMainNavBarHeight = this.setMainNavBarHeight.bind( this );
    this.toggleSearchMode = this.toggleSearchMode.bind( this );
    this.handleHamburgerClick = this.handleHamburgerClick.bind( this );
    this.setHeaderDisplay = this.setHeaderDisplay.bind( this );
    this.setHeaderAnimation = this.setHeaderAnimation.bind( this );
    this.setSearchModeAnimationStyles = this.setSearchModeAnimationStyles.bind( this ) ;
    this.throttleScroll = this.throttleScroll.bind( this );
    this.externalStateUpdate = this.externalStateUpdate.bind( this );
    this.setFocusToHamburgerButton = this.setFocusToHamburgerButton.bind( this );
  }

  headerHeight = 0;

  throttleScroll(){

    let t = throttle( ()=> {
      this.setHeaderDisplay();
    }, 400 );

    t();

  }


  // We had to add this to be able to properly set the state from the unit tests
  // this definitely isn't a good practice, so we need to move all of this internal
  // state stuff back to the reducer so that things are easier to manage - JR
  externalStateUpdate( key, val ){
    this.setState( { [key]: val } );
  }

  componentDidMount(){
    try {
      this.setMainNavBarHeight( document.getElementById( 'navigation__wrapper--sticky' ).offsetHeight );
      this.setHeaderHeight();
    }
    catch ( e ){

    }

    document.addEventListener( 'scroll', this.throttleScroll );
  }

  componentWillUnmount(){
    document.removeEventListener( 'scroll', this.throttleScroll );
  }

  componentDidUpdate( prevProps ){

    if( this.props.mobileHeaderDisplayMode !== prevProps.mobileHeaderDisplayMode ){
      this.setHeaderHeight();
    }

    if( prevProps.menuActive && !this.props.menuActive ){
      this.setFocusToHamburgerButton();
    }

    // check to see if the resize value has changed.  and if so set the local state value of MobileHeaderHeight and screenheight
    if( !isUndefined( this.props.shippingBanner.message ) && isUndefined( prevProps.shippingBanner.message ) ){
      let elem = document.getElementById( 'ShippingBanner' )
      if( elem !== null ){
        this.setState( { shippingBannerHeight: elem.offsetHeight } )
      }
      this.setHeaderHeight();
    }
  }

  placeHolderRef = undefined;

  setFocusToHamburgerButton(){
    // setting focus back to Menu(Hamburger) button once the user clicks on close button from left nav.
    if( document.getElementById( 'menu_HamburgerBtn' ) ){
      document.getElementById( 'menu_HamburgerBtn' ).focus();
    }
  }

  setSearchModeAnimationStyles( mode, stickyHeaderOffset, stickyHeaderHeight, state ){
    let val;
    switch ( mode ){
      case 'open':
        // possible values for state.headerMode = display, hide, default

        if( state.headerMode === 'default' ){
          // var headerOffset = state.mainNavBarHeight + state.shippingBannerHeight + 3;
          let headerOffset = ( stickyHeaderOffset + stickyHeaderHeight - 9 ) * -1;
          return {
            transform: `translateY(${headerOffset}px)`,
            top: `-${state.previousScrollPosition}px`,
            // the bottom attribute is to make sure that we overlay the entire page
            // this may not be needed if we move to a page overlay component
            bottom: `${headerOffset}px`
          }
        }
        else if( state.headerMode === 'display' ){

          let headerOffset = ( state.previousScrollPosition + stickyHeaderHeight - 9 ) * -1;
          return {
            transform: `translateY(${headerOffset}px)`
          }
        }
        break;

      case 'close':
        val = {
          transform: 'translateY(0px)'
        };
        break;

      default:
        val = {};
        break;
    }

    return val

  }


  setMainNavBarHeight( height ){
    this.setState( { mainNavBarHeight: height } );
    // this.props.setMainNavBarHeight( height );
  }

  setHeaderAnimation( mode ){
    let val;
    // if we're in the normal header mode fall below
    switch ( mode ){
      case 'display':
        val = {
          // top: `${state.previousScrollPosition}px`,
          transform: 'translateY(0px)'
        };
        break;

      case 'hide':
        val = {
          transform: `translateY(-${this.state.StickyHeaderHeight}px)`
        };

        break;

      case 'default':
        val = {};
        break;

      default:
        val = {};
        break
    }
    return val;
  }

  toggleSearchMode( display ){
    this.props.toggleSearchMode( display );
    if( this.state.searchMode !== display ){
      let stickynavEl = document.getElementById( 'navigation__wrapper--sticky' ) ;
      let boundingPos = stickynavEl.getBoundingClientRect();


      if( this.state.headerMode === 'default' ){

        this.setState( {
          displaySearchBar:  true,
          searchModeAnimationStyles: this.setSearchModeAnimationStyles( display, boundingPos.top, boundingPos.height, this.state )
        } );

      }
      else if( ( this.state.headerMode === 'display' && display === 'open' ) ){

        this.setState( {
          displaySearchBar: true,
          headerAnimationStyles: this.setHeaderAnimation( 'hide' )
        } );

      }
      else {
        this.setState( {
          displaySearchBar: true,
          headerAnimationStyles: this.setHeaderAnimation( 'display' )
        } );
      }


      this.setState( {
        searchMode: display
      } )
    // this.props.toggleSearchMode( display,boundingPos.top, boundingPos.height );
    }
  }

  setHeaderHeight(){
    let mobileHeader =  document.getElementById( 'MobileHeader' );
    let stickyHeight = document.getElementById( 'navigation__wrapper--sticky' ).offsetHeight;

    // we need to remove the height style before we measure to make sure we have the true height of the content and not our own set height
    mobileHeader.removeAttribute( 'style' );
    let newHeight = document.getElementById( 'MobileHeader' ).offsetHeight;
    this.headerHeight = newHeight === 0 ? this.headerHeight : newHeight;

    mobileHeader.style.height =`${ this.headerHeight }px`;

    this.setState( {
      MobileHeaderHeight: `${ newHeight }px`,
      /*
      24 is account for the padding that's present when headerMode is 'display'' the best way to handle this is to tie a redex saga to the on scroll global event so we can foce an update

      */
      StickyHeaderHeight: stickyHeight + 24
    } );
    // this.props.setHeaderHeight( , stickyHeight );
  }

  handleHamburgerClick(){
    this.props.toggleLeftNav( 'open' );
  }


  setHeaderDisplay(){

    if( this.state.searchMode === 'close' ){
      const currentScrollPosition = window.scrollY;
      let headerMode;
      this.setState( {
        currentScrollPosition
      } );

      // This condition checks to see if the user has scroll beyond the initial page fold
      if( currentScrollPosition > document.documentElement.clientHeight ){
        // tell the application that the fold has been crosed by the user scrolling
        this.setState( {
          hasFoldBeenCrossed: true,
          displaySearchBar: false
        } );
        // this condition identifies if the user has scrolled beyond the fold, but is now scrolling back up the page
        if( currentScrollPosition < this.state.previousScrollPosition ){
          this.setState( {
            hasUserScrolledUp: true,
            headerMode: 'display'
          } );

          headerMode = 'display';
        }
        // this condition indentifies that hte user has scrolled beyond the fold and is still scrolling down
        else {
          this.setState( {
            headerMode: 'hide'
          } );
          headerMode = 'hide';
        }
      }
      // this condition identifies that the user has scrolled back into the original page display fold
      // and also checks to see if the user is in the original page fold, but has already scrolled past it before
      // we only want to provision scrolling behavior here for people have scrolled past the fold
      else if( this.state.hasFoldBeenCrossed ){
        // this condition identifies that the user is scrolling backwards but is in the original fold and above the
        // minimum scroll threshold
        if( currentScrollPosition < this.state.previousScrollPosition ){
          this.setState( {
            headerMode: 'display'
          } );
          headerMode = 'display';
        }
        // this condition identifies that the user has scrolled back into the original threshold, but is now scrolling
        // back down the page
        else {
          this.setState( {
            headerMode: 'hide'
          } );
          headerMode = 'hide';
        }
      }

      // this condition identifies if the user has not scrolled beyond the minimum scroll threshhold
      if( currentScrollPosition <= this.state.shippingBannerHeight ){
        this.setState( {
          headerMode : 'default',
          hasUserScrolledUp : false,
          hasFoldBeenCrossed : false,
          displaySearchBar : true
        } );
        headerMode = 'default';
      }

      this.setState( {
        searchModeAnimationStyles: {},
        headerAnimationStyles: this.setHeaderAnimation( headerMode ),
        previousScrollPosition : currentScrollPosition
      } );
    }


  }

  /**
   * Renders the MobileHeader component
   */
  render(){

    const {
      mobileHeaderDisplayMode
    } = this.props;

    const {
      searchMode,
      searchModeAnimationStyles,
      headerMode,
      hasFoldBeenCrossed,
      hasUserScrolledUp,
      displaySearchBar,
      headerAnimationStyles
    } = this.state;

    return (
      <header
        id='MobileHeader'
        className={
          classNames( {
            'MobileHeader--searchMode': searchMode === 'open'
          } )
        }
      >
        <div
          className={
            classNames( {
              'MobileHeader__searchMode': searchMode === 'open' && headerMode !== 'focused',
              'MobileHeader__searchMode--sticky': searchMode === 'open' && headerMode !== 'focused',
              'MobileHeader__searchMode--fixed': searchMode === 'open' && headerMode !== 'focused',
              'MobileHeader__searchMode--transition': true
            } )
          }
          onTouchMove={
            ( e )=>{
              e.preventDefault();
            }
          }
          style={ searchModeAnimationStyles }
        >
          <div
            className={
              classNames( 'MobileHeader__shippingBanner', {
                'MobileHeader__shippingBanner--minHeight': mobileHeaderDisplayMode === 'default'
              } )
            }
          >
            { ( () => {
              if( !isUndefined( this.props.shippingBanner.message ) && mobileHeaderDisplayMode !== 'focused' && this.props.displayShippingBanner !== false ){
                return (
                  <ShippingBanner
                    message={ this.props.shippingBanner.message }
                    url={ this.props.shippingBanner.url }
                  />
                )
              }
            } )() }
          </div>
          <div className='MobileHeader__container'>
            <section className='navigation'>
              <div className='navigation--primary'>
                <div className='navigation__wrapper'>
                  <div
                    id='navigation__wrapper--sticky'
                    className={
                      classNames( {
                        'navigation__wrapper--sticky': true,
                        'navigation__wrapper--fixed': headerMode !== 'default',
                        'navigation__wrapper--transition': headerMode !== 'default',
                        'navigation__wrapper--notransition': ( headerMode === 'hide' && hasFoldBeenCrossed === true && hasUserScrolledUp === false ),
                        'navigation__wrapper--offscreen':  headerMode === 'hide'
                      } )
                    }
                    style={ headerAnimationStyles }
                  >
                    <div className='navigation__row'>
                      <div className='navigation__section navigation__section--left'>
                        <div className='navigation__item navigation__item--hamburger'>
                          { ( ()=>{

                            if(
                              mobileHeaderDisplayMode === 'default' ||
                              mobileHeaderDisplayMode === 'no_search'
                            ){
                              return (
                                <HamburgerBtn
                                  label={ formatMessage( messages.menu ) }
                                  onClick={
                                    ( e ) => {
                                      this.handleHamburgerClick()
                                    }
                                  }
                                />
                              )
                            }
                          } )() }
                        </div>
                        <div
                          className={
                            classNames( 'navigation__item navigation__item--search', {
                              'navigation__item--search--visible': displaySearchBar,
                              'navigation__item--search-hidden': !displaySearchBar,
                              'navigation__item__noSearchmode': mobileHeaderDisplayMode === 'no_search'
                            } )
                          }
                        >
                          { ( ()=>{
                            if( mobileHeaderDisplayMode === 'default' ||
                              mobileHeaderDisplayMode === 'no_search' ){

                              return (
                                <MainNavBtn
                                  Svg={ SearchSVG }
                                  onClick={
                                    ( e ) => {
                                      e.preventDefault();
                                      this.toggleSearchMode( 'open' );
                                    }
                                  }
                                  label={ formatMessage( messages.search ) }
                                  ariaLabel={ formatMessage( messages.search ) }
                                  url='#'
                                />
                              )
                            }
                          } )() }
                        </div>
                      </div>
                      <div className='navigation__section navigation__section--middle'>
                        <div className='navigation__item navigation__item--logo'>
                          <Logo />
                        </div>
                      </div>
                      <div className='navigation__section navigation__section--right'>
                        <div className='navigation__item navigation__item--stores'>
                          { ( ()=>{
                            if( mobileHeaderDisplayMode === 'default' ||
                              mobileHeaderDisplayMode === 'no_search' ){
                              return (
                                <MainNavBtn
                                  Svg={ LocationSVG }
                                  label={ formatMessage( messages.stores ) }
                                  url={ 'https://' + host + ( this.props.switchData && this.props.switchData.switches ? this.props.switchData.switches.storeLocatorURL : '/ulta/stores/storelocator.jsp' ) }
                                  dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.stores ) ) }
                                />
                              )
                            }
                          } )() }
                        </div>
                        <div className='navigation__item navigation__item--bag'>
                          <MiniCart
                            label={ formatMessage( messages.bag ) }
                            url={ has( this.props.switchData, 'switches.cartURL' )? this.props.switchData.switches.cartURL : this.props.ShoppingCartURL }
                            dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.bag ) ) }
                          />
                        </div>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

          </div>
        </div>
        { ( () => {
          if( mobileHeaderDisplayMode !== 'focused' &&
            searchMode === 'open'
          ){
            return (
              <TypeAheadSearch
                enableReflektionTag={ this.props.enableReflektionTag }
                searchMode={ searchMode }
                closeSearchMode={ this.toggleSearchMode }
                displayType='mobile'
              />
            )
          }
        } )() }
      </header>
    );
  }
}

MobileHeader.propTypes = propTypes;

export default MobileHeader;
