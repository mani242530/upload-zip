/*
 * HamburgerBtn Messages
 *
 * This contains all the text for the HamburgerBtn component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  menu: {
    id: 'i18n.MobileHeader.menu',
    defaultMessage: 'Menu'
  },
  search: {
    id: 'i18n.MobileHeader.search',
    defaultMessage: 'Search'
  },

  stores: {
    id: 'i18n.MobileHeader.stores',
    defaultMessage: 'Stores'
  },
  orders: {
    id: 'i18n.MobileFooter.orders',
    defaultMessage: 'Orders'
  },

  findStores: {
    id: 'i18n.MobileHeader.findStores',
    defaultMessage: 'Find stores'
  },
  inputPlaceholder: {
    id: 'i18n.MobileHeader.inputPlaceholder',
    defaultMessage: 'Search for all things beauty'
  },
  bag: {
    id: 'i18n.MobileHeader.bag',
    defaultMessage: 'Bag'
  },

  viewBag: {
    id: 'i18n.MobileHeader.viewBag',
    defaultMessage: 'View bag'
  }

} );
