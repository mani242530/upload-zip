import React from 'react';
import MobileHeader from './MobileHeader';
import messages from './MobileHeader.messages';
import _ from 'lodash';
import { initialState } from 'hf/reducers/Header/Header.reducer';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import Header, { mapDispatchToProps as headerPropMethods } from 'hf/components/Header/Header';

import { mountWithIntl, createComponentWithIntl } from 'utils/intl-enzyme-test-helper';

var placeholder = document.createElement( 'div' );
placeholder.height = 300;
document.getElementById = jest.fn().mockReturnValue( placeholder );
global.requestAnimationFrame =jest.fn();
describe( '<MobileHeader />', () => {

  let props = initialState;
  let toggleLeftNavMock = jest.fn();
  let toggleSearchModeMock =jest.fn();
  const store = configureStore( {}, CONFIG );
  props.setHeaderHeight = jest.fn();
  props.setShippingBannerHeight = jest.fn();
  props.toggleLeftNav = toggleLeftNavMock;
  props.setMainNavBarHeight = jest.fn();
  props.toggleSearchMode = toggleSearchModeMock;

  let switchData = {
    switches: {
      cartURL : '/bag',
      storeLocatorURL : '/ulta/stores/storelocator.jsp'
    }
  };
  props.switchData = switchData;
  props.mobileHeaderDisplayMode='default';
  let component = mountWithIntl(
    <Provider store={ store }>
      <MobileHeader { ...props } />
    </Provider>
  );


  it( 'should have the proper react component as children', () => {
    expect( component.find( '.navigation__item--hamburger' ).children().find( 'HamburgerBtn' ).length ).toBe( 1 );
    expect( component.find( '.navigation__item--search' ).children().find( 'MainNavBtn' ).length ).toBe( 1 );
    expect( component.find( '.navigation__item--logo' ).children().find( 'Logo' ).length ).toBe( 1 );
    expect( component.find( '.navigation__item--stores' ).children().find( 'MainNavBtn' ).length ).toBe( 1 );
    expect( component.find( '.navigation__item--bag' ).children().find( 'MiniCart' ).length ).toBe( 1 );
  } );

  it( 'should only render the logo and bag component when in mini mode', () => {
    let nprops = _.cloneDeep( props );

    let component = mountWithIntl(
      <Provider store={ store }>
        <MobileHeader { ...nprops } />
      </Provider>
    );

    expect( component.find( '.navigation__item--hamburger' ).children().find( 'HamburgerBtn' ).length ).toBe( 1 );
    expect( component.find( '.navigation__item--search' ).children().find( 'MainNavBtn' ).length ).toBe( 1 );
    expect( component.find( '.navigation__item--logo' ).children().find( 'Logo' ).length ).toBe( 1 );
    expect( component.find( '.navigation__item--stores' ).children().find( 'MainNavBtn' ).length ).toBe( 1 );
    expect( component.find( '.navigation__item--bag' ).children().find( 'MiniCart' ).length ).toBe( 1 );
  } );

  it( 'Should invoke setHeaderHeight on componentDidUpdate', () => {
    const props1={
      mobileHeaderDisplayMode:'default',
      shippingBanner:{
        message:'shipping'
      }
    }
    const prevProps={
      mobileHeaderDisplayMode:'default1',
      shippingBanner:{
        message:'shipping'
      }
    }
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <MobileHeader { ...props1 } />
      </Provider>
    );
    let node = component1.find( 'MobileHeader' ).instance();
    node.setHeaderHeight=jest.fn();
    node.componentDidUpdate( prevProps );
    expect( node.setHeaderHeight ).toBeCalled();
  } );

  it( 'Should invoke setHeaderHeight on componentDidUpdate with is as ShippingBanner', () => {
    let appElement = document.createElement( 'div' );
    appElement.id='ShippingBanner';
    document.body.appendChild( appElement );
    const props1={
      mobileHeaderDisplayMode:'default',
      shippingBanner:{
        message:'shipping'
      }
    }
    const prevProps={
      mobileHeaderDisplayMode:'default',
      shippingBanner:{
        message:undefined
      }
    }
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <MobileHeader { ...props1 } />
      </Provider>
    );
    let node = component1.find( 'MobileHeader' ).instance();
    node.setHeaderHeight=jest.fn();
    node.componentDidUpdate( prevProps );
    expect( node.setHeaderHeight ).toBeCalled();
  } );

  it( 'setSearchModeAnimationStyles should set transform styles', () => {
    let appElement = document.createElement( 'div' );
    appElement.id='ShippingBanner';
    document.body.appendChild( appElement );
    const props1={
      mobileHeaderDisplayMode:'default',
      shippingBanner:{
        message:'shipping'
      }
    }
    const prevProps={
      mobileHeaderDisplayMode:'default',
      shippingBanner:{
        message:undefined
      }
    }
    const state={
      headerMode:'display',
      previousScrollPosition: 1
    }
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <MobileHeader { ...props1 } />
      </Provider>
    );
    let node = component1.find( 'MobileHeader' ).instance();
    expect( JSON.stringify( node.setSearchModeAnimationStyles( 'open', 1, 10, state ) ) ).toBe( '{"transform":"translateY(-2px)"}' );
    expect( JSON.stringify( node.setSearchModeAnimationStyles( 'close', 1, 10, state ) ) ).toBe( '{"transform":"translateY(0px)"}' );
    expect( JSON.stringify( node.setSearchModeAnimationStyles( '', 1, 10, state ) ) ).toBe( '{}' );
  } );

  describe( 'setHeaderHeight', ()=> {

    let target = component.find( 'MobileHeader' ).instance();

    it( 'should exist as a MobileHeader Class method', () => {
      expect( _.isFunction( target.setHeaderHeight ) ).toBe( true );
    } );

    it( 'should be called in componentDidMount ', () => {
      target.setHeaderHeight = jest.fn();
      target.componentDidMount();

      expect( target.setHeaderHeight ).toHaveBeenCalled();
    } );

    it( 'should call the props \'setHeaderheight\' method', () => {
      let el = mountWithIntl(
        <Provider store={ store }>
          <MobileHeader { ...props } />
        </Provider>
      );
      let target = el.find( 'MobileHeader' ).instance();

      target.setHeaderHeight = jest.fn();
      target.componentDidMount();
      expect( target.setHeaderHeight ).toHaveBeenCalledWith();
      expect( target.state.MobileHeaderHeight ).toBe( '0px' );

    } );

    it( 'should not contain ShippingBanner component if the CURRENT_PAGE variable is cart', () => {
      expect( component.find( 'ShippingBanner' ).length ).toBe( 0 );
    } );


    it( 'should  contain ShippingBanner component if the CURRENT_PAGE variable is other than cart', () => {

      let props = initialState;
      props.headerFooterDisplayMode='default';
      props.shippingBanner.message='Free Shipping';
      let el1 = mountWithIntl(
        <Provider store={ store }>
          <MobileHeader { ...props } />
        </Provider>
      );

      expect( el1.find( 'ShippingBanner' ).length ).toBe( 1 );
    } );

    it( 'should not render ShippingBanner component if displayShippingBanner prop is false', () => {

      let props = initialState;
      props.headerFooterDisplayMode='default';
      props.shippingBanner.message='Free Shipping';
      props.displayShippingBanner=false;
      let el1 = mountWithIntl(
        <Provider store={ store }>
          <MobileHeader { ...props } />
        </Provider>
      );

      expect( el1.find( 'ShippingBanner' ).length ).toBe( 0 );
    } );

    it( 'should not call the setShippingBannerHeight method if a shipping object is not passed', () => {
      let newprops = initialState;
      newprops.setHeaderHeight = jest.fn();

      let el = mountWithIntl(
        <Provider store={ store }>
          <MobileHeader { ...newprops } />
        </Provider>
      );
      let target = el.find( 'MobileHeader' ).instance();
      target.setShippingBannerHeight = jest.fn();
      expect( target.setShippingBannerHeight ).not.toHaveBeenCalled();
    } );
  } );


  describe( 'hamburger button', () => {
    let hamburger = component.find( 'HamburgerBtn' );

    it( 'should have the proper label', () => {
      expect( hamburger.props().label ).toBe( messages.menu.defaultMessage );
    } );

    it( 'should invoke toggleLeftNav on click Hamburger button ', () => {
      component.find( '.navigation__item--hamburger' ).children().find( 'HamburgerBtn' ).simulate( 'click' );
      expect( toggleLeftNavMock ).toBeCalled;
    } );

    it( 'should set the focus to SignIn on click Hamburger button ', () => {
      props.menuActive = false;
      let props1={
        ...props,
        menuActive:true,
        mobileHeaderDisplayMode: ''
      }
      let target = component.find( 'MobileHeader' ).instance();
      target.setFocusToHamburgerButton= jest.fn();
      target.componentDidUpdate( props1 );
      expect( target.setFocusToHamburgerButton ).toBeCalled();
    } );
  } );

  describe( 'search button', () => {
    let search = component.find( '.navigation__item--search' ).find( 'MainNavBtn' );

    it( 'should have the proper label message', () => {
      expect( search.props().label ).toBe( messages.search.defaultMessage );
    } );
    it( 'should have a url value of \'#\'', () => {
      expect( search.props().url ).toBe( '#' );
    } );
    it( 'should have the proper aria-label message', () => {
      expect( search.props().ariaLabel ).toBe( messages.search.defaultMessage );
    } );
  } );

  describe( 'store locator btn', () => {

    let stores = component.find( '.navigation__item--stores' ).find( 'MainNavBtn' );


    it( 'should have the proper label message', () => {
      expect( stores.props().label ).toBe( messages.stores.defaultMessage );
    } );
    it( 'should contain https in the link', () => {
      expect( stores.props().url ).toContain( 'https' );
    } );
  } );


  describe( 'bag btn', () => {
    let switchData = {
      switches: {
        cartURL : '/bag'
      }
    };
    props.switchData = switchData;
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <MobileHeader { ...props }/>
      </Provider>
    );

    let stores = component1.find( '.navigation__item--bag' ).find( 'MainNavBtn' );

    it( 'should have the proper label message', () => {
      expect( stores.props().label ).toBe( messages.bag.defaultMessage );
    } );
    it( 'should have the proper  url value', () => {
      expect( stores.props().url ).toBe( '/bag' );
    } );
  } );

  describe( 'dynamic css classes', () => {

    beforeEach( ()=> {
      props = initialState;
    } );

    describe( 'searchbar wrapper', () => {
      let container = component.find( '.navigation__item--search' );

      it( 'a component with the class \'navigation__item\' and \'navigation__item-search should exist', () => {
        expect( container ).toBeTruthy();
        expect( container.hasClass( 'navigation__item' ) ).toBe( true );
        expect( container.hasClass( 'navigation__item--search' ) ).toBe( true );
      } );

      it( 'should have the proper classes when \'displaySearchBar\' is true', () => {
        props.displaySearchBar = true;

        let component = mountWithIntl(
          <Provider store={ store }>
            <MobileHeader { ...props } />
          </Provider>
        );
        let container = component.find( '.navigation__item--search' );
        expect( container.hasClass( 'navigation__item' ) ).toBe( true );
        expect( container.hasClass( 'navigation__item--search' ) ).toBe( true );
        expect( container.hasClass( 'navigation__item--search-visible' ) ).toBe( false );
        expect( container.hasClass( 'navigation__item--search-hidden' ) ).toBe( false );
      } );

      it( 'should have the proper classes when \'displaySearchBar\' is false', () => {
        props.displaySearchBar = false;

        let component = mountWithIntl(
          <Provider store={ store }>
            <MobileHeader { ...props } />
          </Provider>
        );
        let container = component.find( '.navigation__item--search' );
        expect( container.hasClass( 'navigation__item' ) ).toBe( true );
        expect( container.hasClass( 'navigation__item--search' ) ).toBe( true );
        expect( container.hasClass( 'navigation__item--search-hidden' ) ).toBe( false );
        expect( container.hasClass( 'navigation__item--search-visible' ) ).toBe( false );
      } );

    } );

    describe( 'sticky navigation wrapper', () => {
      let container = component.find( '.navigation__wrapper--sticky' );

      it( 'a component with the class \'navigation__wrapper--sticky\' should exist', () => {
        expect( container ).toBeTruthy();
      } );

      it( 'should have the style attribute with the proper prop passed for animations', () => {
        /* This needs to be revisited - .simulate is not working properly */
        let component = mountWithIntl(
          <Provider store={ store }>
            <MobileHeader { ...props } />
          </Provider>
        );
        let mHeader = component.find( 'MobileHeader' );
        let btn = mHeader.find( '[label="Search"]' );
        // btn.simulate( 'click' );
        // let btn1 = mHeader.find( '#TypeAhead__cancel' );
        // btn1.simulate( 'click' );
        // expect( component.find( '.MobileHeader__searchMode--transition' ).props().style.transform ).toEqual( 'translateY(0px)' );
      } );

      it( 'should have the right classes if headerMode is default', () => {
        expect( container.hasClass( 'navigation__wrapper--fixed' ) ).toBe( false );
        expect( container.hasClass( 'navigation__wrapper--transition' ) ).toBe( false );
        expect( container.hasClass( 'navigation__wrapper--offscreen' ) ).toBe( false );
        expect( container.hasClass( 'navigation__wrapper--notransition' ) ).toBe( false );
      } );


      it( 'should have the proper classes when the headerMode is \'hide\'', () => {
        let component = mountWithIntl(
          <Provider store={ store }>
            <MobileHeader { ...props } />
          </Provider>
        );
        const mHeader = component.find( 'MobileHeader' );
        mHeader.instance().externalStateUpdate( 'headerMode', 'hide' );
        component.update();
        let container = component.find( '.navigation__wrapper--sticky' );
        expect( container.hasClass( 'navigation__wrapper--fixed' ) ).toBe( true );
        expect( container.hasClass( 'navigation__wrapper--transition' ) ).toBe( true );
        expect( container.hasClass( 'navigation__wrapper--offscreen' ) ).toBe( true );
        expect( container.hasClass( 'navigation__wrapper--notransition' ) ).toBe( false );
      } );

      it( 'should have the proper classes when the headerMode is \'display\'', () => {
        let component = mountWithIntl(
          <Provider store={ store }>
            <MobileHeader { ...props } />
          </Provider>
        );
        const mHeader = component.find( 'MobileHeader' );
        mHeader.instance().externalStateUpdate( 'headerMode', 'display' );
        component.update();
        let container = component.find( '.navigation__wrapper--sticky' );
        expect( container.hasClass( 'navigation__wrapper--fixed' ) ).toBe( true );
        expect( container.hasClass( 'navigation__wrapper--transition' ) ).toBe( true );
        expect( container.hasClass( 'navigation__wrapper--offscreen' ) ).toBe( false );
        expect( container.hasClass( 'navigation__wrapper--notransition' ) ).toBe( false );
      } );

      it( 'should have the class \'navigation__wrapper--notransition\' when the headerMode is \'hide\', hasFoldBeenCrossed is true, and hasUserScrolledUp is false', () => {
        let component = mountWithIntl(
          <Provider store={ store }>
            <MobileHeader { ...props } />
          </Provider>
        );
        const mHeader = component.find( 'MobileHeader' );
        mHeader.instance().externalStateUpdate( 'headerMode', 'hide' );
        mHeader.instance().externalStateUpdate( 'hasFoldBeenCrossed', true );
        mHeader.instance().externalStateUpdate( 'hasUserScrolledUP', false );
        component.update();
        let container = component.find( '.navigation__wrapper--sticky' );
        expect( container.hasClass( 'navigation__wrapper--notransition' ) ).toBe( true );
      } );

    } );

  } );

  describe( 'SearchMode', () => {
    let toggleSearchMode = toggleSearchModeMock;
    let component = mountWithIntl(
      <Provider store={ store }>
        <MobileHeader
          toggleSearchMode={ toggleSearchMode }
          { ...props }
        />
      </Provider>
    );

    let container = component.find( 'MobileHeader' );

    it( 'should have a method called \'toggleSearchMode\'', () => {
      expect( _.isFunction( container.instance().toggleSearchMode ) ).toBe( true );
    } );

    it( 'search btn should call open search mode', () => {
      container.instance().toggleSearchMode = jest.fn();
      let btn = component.find( '.navigation__item--search' ).find( 'MainNavBtn' );
      btn.simulate( 'click' );
      expect( container.instance().toggleSearchMode ).toHaveBeenCalledWith( 'open' );
    } );

    it( 'search should have toggleSearchMode attribute set', () => {
      let search = component.find( '.navigation__item--search' );
      container.instance().toggleSearchMode = jest.fn();
      search.find( '.MainNavBtn .Anchor' ).simulate( 'click' );
      expect( container.instance().toggleSearchMode ).toHaveBeenCalledWith( 'open' );
    } );

    it( 'On click search btn should call toggleSearchMode and set searchModeAnimationStyles in the state', () => {
      let btn = component.find( '.navigation__item--search' ).find( 'MainNavBtn' );
      btn.simulate( 'click' );
      expect( toggleSearchModeMock ).toBeCalled;

    } );

    it( 'On click search btn should call toggleSearchMode', () => {

      let component2 = mountWithIntl(
        <Provider store={ store }>
          <MobileHeader
            toggleSearchMode={ toggleSearchMode }
            { ...props }
          />
        </Provider>
      );
      let node1 = component2.find( 'MobileHeader' );
      node1.instance().state.headerMode = 'default';
      component2.update();
      let btn = component2.find( '.navigation__item--search' ).find( 'MainNavBtn' );
      btn.simulate( 'click' );
      expect( JSON.stringify( node1.instance().state.searchModeAnimationStyles ) ).toBe( '{\"transform\":\"translateY(9px)\",\"top\":\"-0px\",\"bottom\":\"9px\"}' );

    } );

    it( 'Should set displaySearchBar as true when parameter for toggleSearchMode is given as close ', () => {
      const props1={
        mobileHeaderDisplayMode:'default',
        shippingBanner:{
          message:'shipping'
        },
        toggleSearchMode: jest.fn()
      }
      const state1={
        headerMode:'default',
        previousScrollPosition: 1
      }
      let component1 = mountWithIntl(
        <Provider store={ store }>
          <MobileHeader { ...props1 } />
        </Provider>
      );
      let node = component1.find( 'MobileHeader' ).instance();
      node.state.headerMode='display';
      node.toggleSearchMode( 'close' )
      expect( node.state.displaySearchBar ).toBe( true );
    } );





  } );

  describe( 'Anchoring for the bag', () => {
    let toggleSearchMode = jest.fn();
    it( 'should have the cart url if switch data is available', () => {
      let switchData = {
        switches: {
          cartURL : '/bag',
          storeLocatorURL : '/ulta/stores/storelocator.jsp'
        }
      };
      props.switchData = switchData;
      let component1 = mountWithIntl(
        <Provider store={ store }>
          <MobileHeader { ...props }
            toggleSearchMode={ toggleSearchMode }
          />
        </Provider>
      );
      expect( component1.find( 'MiniCart' ).at( 0 ).props().url ).toBe( props.switchData.switches.cartURL );
    } );

    it( 'if switch data is unavailable it should have url from props', ()=>{
      let switchData = {
        switches: {
          storeLocatorURL : '/ulta/stores/storelocator.jsp'
        }
      };
      props.switchData = switchData;
      let shoppingCartURL = '/bag';
      let component1 = mountWithIntl(
        <Provider store={ store }>
          <MobileHeader { ...props }
            toggleSearchMode={ toggleSearchMode }
            ShoppingCartURL={ shoppingCartURL }
          />
        </Provider>
      );
      expect( component1.find( 'MiniCart' ).at( 0 ).props().url ).toBe( shoppingCartURL );
    } );
  } );
  describe( 'throttleScroll ', ()=> {

    it( 'should Invoke throttleScroll method and set searchModeAnimationStyles in the state to {} on on triggering scroll event', () => {
      let scrollEvent = new CustomEvent( 'scroll' );
      let props = initialState;
      let node1 = component.find( 'MobileHeader' ).instance();
      document.dispatchEvent( scrollEvent );
      expect( JSON.stringify( node1.state.searchModeAnimationStyles ) ).toBe( '{}' );
      expect( JSON.stringify( node1.state.previousScrollPosition ) ).toBe( '0' );
    } );

    it( 'Should invoke removeEventListener on componentWillUnmount', () => {
      let removeEventListenerMock =jest.fn();
      document.removeEventListener = removeEventListenerMock;
      let node1 = component.find( 'MobileHeader' ).instance();
      node1.componentWillUnmount();
      expect( removeEventListenerMock ).toBeCalled();
      expect( removeEventListenerMock.mock.calls.length ).toBe( 1 );
    } );

  } );

  describe( 'setHeaderAnimation ', ()=> {

    it( 'should Return proper response if setHeaderAnimation method is invoked with paramter mode as hide', () => {
      let node1 = component.find( 'MobileHeader' ).instance();
      node1.state.StickyHeaderHeight = '25';
      expect( JSON.stringify( node1.setHeaderAnimation( 'hide' ) ) ).toBe( '{\"transform":\"translateY(-25px)\"}' );
    } );

    it( 'should Return proper response if setHeaderAnimation method is invoked with paramter mode as display', () => {
      let node1 = component.find( 'MobileHeader' ).instance();
      expect( JSON.stringify( node1.setHeaderAnimation( 'display' ) ) ).toBe( '{\"transform\":\"translateY(0px)\"}' );
    } );

    it( 'should Return an empty object if setHeaderAnimation method is invoked with paramtermode as default', () => {
      let node1 = component.find( 'MobileHeader' ).instance();
      expect( JSON.stringify( node1.setHeaderAnimation( 'default' ) ) ).toBe( '{}' );
    } );

    it( 'should Return an empty object if setHeaderAnimation method is invoked with paramter mode other than hide,display,default', () => {
      let node1 = component.find( 'MobileHeader' ).instance();
      expect( JSON.stringify( node1.setHeaderAnimation( 'test' ) ) ).toBe( '{}' );
    } );

    it( 'should set headermode according to scrollY and previousScrollPosition', () => {
      const props1={
        mobileHeaderDisplayMode:'default',
        shippingBanner:{
          message:'shipping'
        },
        toggleSearchMode: jest.fn()
      }
      const state1={
        headerMode:'default',
        previousScrollPosition: 1
      }
      let component2 = mountWithIntl(
        <Provider store={ store }>
          <MobileHeader { ...props1 } />
        </Provider>
      );
      let node = component2.find( 'MobileHeader' ).instance();
      node.state.headerMode='display';
      node.state.previousScrollPosition=2;
      window.scrollY=1;
      node.setHeaderDisplay( )
      expect( node.state.displaySearchBar ).toBe( false );
      expect( node.state.headerMode ).toBe( 'display' );
      window.scrollY=1;
      node.state.previousScrollPosition=0;
      node.setHeaderDisplay( );
      expect( node.state.headerMode ).toBe( 'hide' );
    } );
  } );

} );
