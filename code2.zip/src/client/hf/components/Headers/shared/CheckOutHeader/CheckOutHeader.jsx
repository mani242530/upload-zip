
/**
 * CheckOutHeader
 */

import React, { Component } from 'react';
import './CheckOutHeader.css';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './CheckOutHeader.messages';
import Locksvg from 'shared/components/Icons/lock';
import 'shared/components/Gutter/Gutter.css';

/**
 * Class
 * @extends React.Component
 */
class CheckOutHeader extends Component{

  componentDidMount(){
    this.secureCheckoutHeading.focus();
  }

  render(){
    return (
      <div className='CheckOutHeader Gutter'>
        <Locksvg/>
        <h1
          tabIndex='-1'
          ref={ ( el )=>{
            this.secureCheckoutHeading=el
          } }
        >
          <span>{ formatMessage( messages.header ) }</span>
        </h1>
      </div>
    );
  }

}

export default CheckOutHeader;
