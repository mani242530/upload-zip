/*
 * CheckOutHeader Messages
 *
 * This contains all the text for the CheckOutHeader component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.CheckOutHeader.header',
    defaultMessage: 'Secure Checkout'
  }
} );
