import React from 'react';
import ReactDOM from 'react-dom';
import CheckOutHeader from './CheckOutHeader';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

describe( '<CheckOutHeader />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <CheckOutHeader /> );
    expect( component.find( 'CheckOutHeader' ).length ).toBe( 1 );
  } );

  it( 'Should call heading focus when component is mounted', ()=> {
    const componentNode = component.find( 'CheckOutHeader' ).instance();
    componentNode.secureCheckoutHeading.focus = jest.fn();
    componentNode.componentDidMount();
    expect( componentNode.secureCheckoutHeading.focus ).toBeCalled();
  } );
} );
