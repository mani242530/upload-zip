/**
 * ShippingBanner
 */

import React from 'react';
import PropTypes from 'prop-types';
import Anchor from 'shared/components/Anchor/Anchor';
import classNames from 'classnames';
import './ShippingBanner.css';

const propTypes = {
  module: PropTypes.string,
  message: PropTypes.string,
  mobileMessage: PropTypes.string,
  desktopMessage: PropTypes.string,
  url: PropTypes.string,
  isMobile: PropTypes.bool
}

const defaultProps = {
  message: '',
  module: 'default'
}

const ShippingBanner = ( props ) => {


  const renderConditionalContent = ( ) =>{
    const {
      message,
      url
    } = props


    if( url ){
      return (
        <Anchor
          url={ url }
          ariaLabel={ 'FreeSHipping banner' }
        >
          <div
            className='ShippingBanner__Message'
            dangerouslySetInnerHTML={ { __html: message } }
          />
        </Anchor>
      )
    }
    else {
      let regex = /(?=href)\w+/g

      return (
        <div
          className={
            classNames( 'ShippingBanner__Message', {
              'ShippingBanner__Message--link': regex.test( message.toLowerCase() )
            } )
          }
          dangerouslySetInnerHTML={ { __html: message } }
        />
      )
    }
  }

  return (
    <div
      id='ShippingBanner'
      className='ShippingBanner'
    >
      { renderConditionalContent( ) }
    </div>
  );

}


ShippingBanner.propTypes = propTypes;
ShippingBanner.defaultProps = defaultProps;
export default ShippingBanner;
