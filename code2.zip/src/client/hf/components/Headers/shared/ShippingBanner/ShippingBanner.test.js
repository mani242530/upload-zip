import React from 'react';
import ReactDOM from 'react-dom';
import ShippingBanner from './ShippingBanner';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

describe( '<ShippingBanner />', () => {
  let component;

  let props = {
    message: 'this is a test'
  }

  it( 'renders without crashing', () => {
    component = mountWithIntl( <ShippingBanner { ...props }/> );
    expect( component.find( 'ShippingBanner' ).length ).toBe( 1 );
  } );
} );
