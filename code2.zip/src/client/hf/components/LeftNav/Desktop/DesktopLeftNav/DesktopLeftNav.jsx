/**
 * DesktopLeftNav
 */

import React from 'react';
import PropTypes from 'prop-types';
import Anchor from 'shared/components/Anchor/Anchor';
import Logo from 'shared/components/Logo/Logo';
import Image from 'shared/components/Image/Image';
import classNames from 'classnames';
import DesktopLeftNavSection from 'hf/components/LeftNav/Desktop/DesktopLeftNavSection/DesktopLeftNavSection';
import './DesktopLeftNav.css';

import { formatMessage } from 'shared/components/Global/Global';


const propTypes = {
  desktopNavPanelList: PropTypes.array,
  headerFooterDisplayMode: PropTypes.string
}

const DesktopLeftNav = ( props ) => {

  const {
    desktopNavPanelList,
    headerFooterDisplayMode,
    desktopHeaderDisplayMode
  } = props

  if( headerFooterDisplayMode !== 'checkout' &&
    headerFooterDisplayMode !== 'creditcards' &&
    desktopHeaderDisplayMode !== 'focused' &&
    desktopNavPanelList.length > 0
  ){

    return (
      <div className='DesktopLeftNav'>
        <Logo/>
        <div className='DesktopLeftNav__contentContainer'>
          { ( ()=>{
            const formatNavDisplayContentForTradeMark = ( navDisplayContent ) => {
              if( navDisplayContent.endsWith( '&trade;' ) ){
                return [navDisplayContent.replace( '&trade;', '' ), <span>&trade;</span>];
              }
              else {
                return navDisplayContent;
              }
            }

            try {
              if( desktopNavPanelList && desktopNavPanelList.length > 0 ){
                return desktopNavPanelList.map( ( navItem, index ) => {
                  if( navItem.navElementType && navItem.navElementType === 'Filler' ){
                    return (
                      <div
                        className='DesktopLeftNav__navItemDivider'
                        key={ index }
                      >
                      </div>
                    )
                  }
                  else if( navItem.navElementType && navItem.navElementType === 'ImageCategory' ){
                    return (
                      <Anchor
                        url={ navItem.cateogryLink.navTargetLink }
                        key={ index }
                      >
                        <Image
                          src={ navItem.Image }
                          alt={ navItem.cateogryLink.linkText }
                        />
                      </Anchor>
                    )
                  }
                  else if( navItem && navItem.navDisplayContent ){

                    return (
                      <div
                        key={ index }
                        className='DesktopLeftNav__navItemContainer'
                      >
                        <div
                          className={
                            classNames( {
                              'DesktopLeftNav__navItem': true,
                              'DesktopLeftNav__navItem--orangePop': navItem.fontColor === 'demo-orange-pop' || navItem.fontColor === 'nav-menu-style-melon',
                              'DesktopLeftNav__navItem--magenta': navItem.fontColor === 'mad-for-magenta-ada'
                            } ) }
                        >
                          <Anchor
                            url={ navItem.categoryLink.navTargetLink }
                            dataNavDescription={ navItem.categoryLink[ 'data-nav-description' ] }
                          >
                            { formatNavDisplayContentForTradeMark( navItem.navDisplayContent ) }
                          </Anchor>
                        </div>
                        { ( ()=>{
                          if( navItem.paginatedNavItems && navItem.paginatedNavItems.length > 0 ){
                            return (
                              <DesktopLeftNavSection
                                paginatedNavItems={ navItem.paginatedNavItems }
                              />
                            )
                          }
                        } )() }
                      </div>
                    )
                  }
                  return null
                } )
              }
            }
            catch ( e ){
              console.log( e.message ); //eslint-disable-line

            }
          } )() }
        </div>
      </div>
    )
  }
  else {
    return null;
  }

}

DesktopLeftNav.propTypes = propTypes;

export default DesktopLeftNav;
