import React from 'react';
import ReactDOM from 'react-dom';
import DesktopHeader from 'hf/components/Headers/desktop/DesktopHeader/DesktopHeader';
import DesktopLeftNav from './DesktopLeftNav';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import navData from 'hf/components/LeftNav/Desktop/DesktopLeftNav/DesktopLeftNavData';
import { getServiceType } from 'shared/actions/Services/Services.actions';

import reducer, {
  initialState
} from 'hf/reducers/MobileLeftNav/MobileLeftNav.reducer';

let action = {
  type: getServiceType( 'navigation', 'success' ),
  data: { desktopNavContent:navData.mobileNavContent }
};
let new_state = reducer( initialState, action );

describe( '<DesktopLeftNav />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <DesktopLeftNav desktopNavPanelList={ [1, 2, 23] } /> );
    expect( component.find( 'DesktopLeftNav' ).length ).toBe( 1 );
  } );

  let newComponent = mountWithIntl( <DesktopLeftNav desktopNavPanelList={ new_state.desktopNavPanelList } /> );

  it( 'renders navData appropriately', () => {
    expect( newComponent.find( 'DesktopLeftNav' ).length ).toBe( 1 );
    expect( newComponent.find( 'DesktopLeftNavSection' ).length ).toBe( 10 );
    expect( newComponent.find( '.DesktopLeftNavSection__navItem' ).length ).toBe( 215 );
  } );


  it( 'renders navItems with a color of orangePop when passed \'nav-menu-style-melon\' as \'textColor\'', () => {
    expect( newComponent.find( '.DesktopLeftNav__navItem--orangePop' ).length ).toBe( 3 );
  } );

  it( 'renders navItems with a color of Mad For Magenta when passed \'mad-for-magenta-ada\' as \'textColor\'', () => {
    expect( newComponent.find( '.DesktopLeftNav__navItem--magenta' ).length ).toBe( 1 );
  } );

  it( 'renders a divider when passed \'Filler\' as \'navElementType\'', () => {
    expect( newComponent.find( '.DesktopLeftNav__navItemDivider' ).length ).toBe( 2 );
  } );

  it( 'renders a <DesktopLeftNavSection /> for each \'paginatedNavItem\' sent in props', () => {
    expect( newComponent.find( 'DesktopLeftNavSection' ).length ).toBe( 10 );
  } );

  it( 'renders a trademark as is when passed like ™ as part of navDisplayContent text', () => {
    let AnchorTags = newComponent.find( 'Anchor' );
    const regExpr = /THE SALON™/g;
    let found = false;
    AnchorTags.forEach( ( anchor ) => {
      if( anchor.html().match( regExpr ) ){
        found = true;
      }
    } );
    expect( found ).toBe( true );
  } );


  it( 'renders a trademark as ™ when appended as &trade; at the end of navDisplayContent text', () => {
    let AnchorTags = newComponent.find( 'Anchor' );
    const regExpr = /<span>™<\/span>/g;
    let found = false;
    AnchorTags.forEach( ( anchor ) => {
      if( anchor.html().match( regExpr ) ){
        found = true;
      }
    } );
    expect( found ).toBe( true );
  } );

  it( 'renders as normal text when &trade; or ™ are not part of navDisplayContent text', () => {
    let AnchorTags = newComponent.find( 'Anchor' );
    const regExpr = /CURRENT AD/g;
    let found = false;
    AnchorTags.forEach( ( anchor ) => {
      if( anchor.html().match( regExpr ) ){
        found = true;
      }
    } );
    expect( found ).toBe( true );
  } );

  describe( 'display configurations', () => {

    it( ' should not render the left nav if the headerFooterDisplay is \'checkout\'', () => {
      component = mountWithIntl(
        <DesktopLeftNav
          headerFooterDisplayMode='checkout'
          desktopNavPanelList={ ['asdf', 'asdf'] }
        />
      );

      expect( component.instance() ).toBe( null );


    } );

    it( ' should not render the left nav if the headerFooterDisplay is \'checkout\'', () => {
      component = mountWithIntl(
        <DesktopLeftNav
          headerFooterDisplayMode='creidtcards'
          desktopNavPanelList={ ['asdf', 'asdf'] }
        />
      );
      expect( component.instance() ).toBe( null );

    } );

    it( ' should not render the left nav if the headerFooterDisplay is \'focused\'', () => {
      component = mountWithIntl(
        <DesktopLeftNav
          headerFooterDisplayMode='focused'
          desktopNavPanelList={ ['asdf', 'asdf'] }
        />
      );
      expect( component.instance() ).toBe( null );

    } );

    it( ' should not render the left nav if the \'desktopNavPanelList\' has no entries', () => {
      component = mountWithIntl(
        <DesktopLeftNav
          desktopNavPanelList={ [] }
        />
      );
      expect( component.instance() ).toBe( null );

    } );
  } );

} );
