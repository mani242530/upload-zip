/**
 * DesktopLeftNavSection
 */

import React from 'react';
import PropTypes from 'prop-types';
import Anchor from 'shared/components/Anchor/Anchor';
import Image from 'shared/components/Image/Image';
import classNames from 'classnames';
import './DesktopLeftNavSection.css';

import { formatMessage } from 'shared/components/Global/Global';

const propTypes = {
  paginatedNavItems: PropTypes.array
}

const DesktopLeftNavSection = ( props ) => {

  const {
    paginatedNavItems
  } = props

  if( paginatedNavItems && paginatedNavItems.length > 0 ){

    return (
      <div
        className={ `DesktopLeftNavSection DesktopLeftNavSection__width--${ paginatedNavItems.length }` }
      >
        <div
          className={ `DesktopLeftNavSection__wrapper DesktopLeftNavSection__width--${ paginatedNavItems.length }` }
        >
          { ( ()=>{

            return paginatedNavItems.map( ( navItemsPanel, index ) => {

              const isLastPanel = index === paginatedNavItems.length - 1;

              return (
                <div
                  key={ index }
                  className={
                    classNames( {
                      'DesktopLeftNavSection__panel': true,
                      'DesktopLeftNavSection__panel--lastPanel': isLastPanel
                    } )
                  }
                >

                  { ( ()=>{

                    if( navItemsPanel && navItemsPanel.length > 0 ){
                      return navItemsPanel.map( ( navItem, index ) => {

                        return (
                          <div
                            key={ index }
                            className={
                              classNames( {
                                'DesktopLeftNavSection__navItem': true,
                                'DesktopLeftNavSection__navItem--capitalized': navItem.displayAsSubCategory,
                                'DesktopLeftNavSection__navItem--firstItem': index === 0
                              } )

                            }

                          >
                            { ( ()=>{

                              if( navItem.navElementType === 'ImageSubCategory' ){
                                return (
                                  <Anchor
                                    className='DesktopLeftNavSection__flyout'
                                    url={ navItem.imageLink.navTargetLink }
                                    target={ navItem.imageLink.showInNewPage ? '_blank' : '_self' }
                                    dataSlotPosition={ navItem.imageLink[ 'data-slot-position' ] }
                                  >
                                    <Image
                                      src={ navItem.image }
                                      alt={ navItem.imageAlt }
                                    />
                                  </Anchor>
                                )

                              }
                              else if( navItem.navDisplayContent ){


                                let url = '#';

                                if( navItem.categoryLink && navItem.categoryLink.navTargetLink ){
                                  url = navItem.categoryLink.navTargetLink;
                                }
                                else if( navItem.navTargetLink ){
                                  url = navItem.navTargetLink;
                                }

                                return (
                                  <Anchor
                                    url={ url }
                                    dataNavDescription={ navItem.dataNavDescription }
                                  >
                                    { navItem.navDisplayContent }
                                  </Anchor>
                                )
                              }
                              else {
                                return (
                                  <Anchor
                                    className='DesktopLeftNavSection__flyout'
                                    url={ navItem.imageLink.navTargetLink }
                                    target={ navItem.imageLink.showInNewPage ? '_blank' : '_self' }
                                    dataSlotPosition={ navItem.imageLink[ 'data-slot-position' ] }
                                  >
                                    <Image
                                      src={ navItem.imgSrc }
                                      alt={ navItem.imageAlt }
                                    />
                                  </Anchor>
                                )
                              }
                            } )() }

                          </div>
                        )
                      } )
                    }
                  } )() }

                </div>

              )

            } )

          } )() }
        </div>
      </div>
    );
  }
  return null
}

DesktopLeftNavSection.propTypes = propTypes;

export default DesktopLeftNavSection;
