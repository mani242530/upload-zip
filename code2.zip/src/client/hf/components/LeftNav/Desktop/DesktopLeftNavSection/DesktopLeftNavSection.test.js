import React from 'react';
import ReactDOM from 'react-dom';
import DesktopLeftNavSection from './DesktopLeftNavSection';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

import navData from 'hf/components/LeftNav/Desktop/DesktopLeftNav/DesktopLeftNavData'

import reducer, {
  initialState
} from 'hf/reducers/Header/Header.reducer'

import {
  types as headerTypes,
  actions as headerActions
} from 'hf/actions/Header/Header.actions';

// let newInitialState;
let newInitialState = initialState;

let action = headerActions.getNavItemList( navData.mobileNavContent );
let new_state = reducer( initialState, action );
let desktopNavPanelList = new_state.desktopNavPanelList;

let paginatedNavItems = desktopNavPanelList[1].paginatedNavItems;
let paginatedNavItems2 = desktopNavPanelList[2].paginatedNavItems;


describe( '<DesktopLeftNavSection />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <DesktopLeftNavSection /> );
    expect( component.find( 'DesktopLeftNavSection' ).length ).toBe( 1 );
  } );

  let saleCategoriesWithImage =[
    [
      {
        'navElementType':'SubCategory',
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'http://qa2.ulta.com/ulta/promotion/buy-more-save-more/',
          'data-nav-description':'m - sale & coupons:buy more save more',
          'linkText':''
        },
        'navDisplayContent':'BUY MORE SAVE MORE'
      },
      {
        'image':'https://images.ulta.com/is/image/Ulta/flyout_071716_hair',
        'imageLink':{
          'showInNewPage':false,
          'navTargetLink':'http://qa2.ulta.com/makeup?N=26y1',
          'linkText':'',
          'data-slot-position':'sale & coupons_flyout_071716_hair'
        },
        'navDisplayContent':'Image',
        'navElementType':'ImageSubCategory',
        'imageAlt':'',
        'imageSubCat':true
      }
    ]
  ];

  let saleCategoriesWithoutImage =[
    [
      {
        'navElementType':'SubCategory',
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'http://qa2.ulta.com/ulta/promotion/buy-more-save-more/',
          'data-nav-description':'m - sale & coupons:buy more save more',
          'linkText':''
        },
        'navDisplayContent':'BUY MORE SAVE MORE'
      }
    ]
  ];

  let component2 = mountWithIntl( <DesktopLeftNavSection paginatedNavItems={ paginatedNavItems } /> );
  let component3 = mountWithIntl( <DesktopLeftNavSection paginatedNavItems={ paginatedNavItems2 } /> );
  let component4 = mountWithIntl( <DesktopLeftNavSection paginatedNavItems={ saleCategoriesWithImage } /> );
  let component5 = mountWithIntl( <DesktopLeftNavSection paginatedNavItems={ saleCategoriesWithoutImage } /> );

  it( 'renders a list of nav items when sent an array of \'paginatedNavItems\'', () => {
    expect( component2.find( '.DesktopLeftNavSection' ).length ).toBe( 1 );
    expect( component2.find( '.DesktopLeftNavSection__navItem' ).length ).toBe( 41 );
  } );

  it( 'renders the appropriate number of panels based on the \'paginatedNavItems\' sent', () => {
    expect( component2.find( '.DesktopLeftNavSection__panel' ).length ).toBe( 4 );
    expect( component3.find( '.DesktopLeftNavSection__panel' ).length ).toBe( 2 );
  } );

  it( 'renders a right border on each panel except for the last one', () => {
    expect( component2.find( '.DesktopLeftNavSection__panel' ).length ).toBe( 4 );
    expect( component2.find( '.DesktopLeftNavSection__panel--lastPanel' ).length ).toBe( 1 );
  } );

  it( 'renders a flyout when a flyout is included in the \'paginatedNavItems\'', () => {
    expect( component2.find( '.Anchor .DesktopLeftNavSection__flyout' ).length ).toBe( 2 );
    expect( component3.find( '.Anchor .DesktopLeftNavSection__flyout' ).length ).toBe( 1 );
  } );

  it( 'renders a flyout when an ImageSubCategory is included in the \'paginatedNavItems\'', () => {
    expect( component4.find( '.Anchor .DesktopLeftNavSection__flyout' ).length ).toBe( 1 );
  } );

  it( 'fails to render a flyout when an ImageSubCategory is not included in the \'paginatedNavItems\'', () => {
    expect( component5.find( '.DesktopLeftNavSection__flyout' ).length ).toBe( 0 );
  } );

} );
