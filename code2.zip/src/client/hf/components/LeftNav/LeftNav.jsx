/**
 * LeftNav
 */

import React, { Component } from 'react';
import { isServer } from 'utils/DeviceDetection/deviceDetection';
import { connect } from 'react-redux';
import MobileLeftNav from 'hf/components/LeftNav/Mobile/MobileLeftNav/LeftNav';
import DesktopLeftNav from 'hf/components/LeftNav/Desktop/DesktopLeftNav/DesktopLeftNav';


import {
  actions as servicesActions,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  actions as mobileLeftNavActions
} from 'hf/actions/MobileLeftNav/MobileLeftNav.actions'

import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';
import {
  actions as userActions
} from 'shared/actions/User/User.actions';

export const mapStateToProps = ( state ) => {

  return {
    ...state.mobileLeftNav,
    ...state.global,
    ...state.user,
    ...state.header,
    ...state.session
  };
}

export const mapDispatchToProps = ( dispatch ) => {
  return {

    getNavigationData: ( ) => {
      dispatch( getActionDefinition( 'navigation', 'requested' )() );
    },

    setMobileLeftNavDimensions: ( width, height ) => {
      dispatch( mobileLeftNavActions.setMobileLeftNavDimensions( width, height ) );
    },

    setActiveLevel: ( level, index ) => {
      dispatch( mobileLeftNavActions.setActiveLevel( level, index ) );
    },

    toggleLeftNav: ( mode ) => {
      dispatch( mobileLeftNavActions.toggleLeftNav( mode ) );
      dispatch( globalActions.enableDisableDocumentScroll( false ) );
    },

    openRewards: () => {
      dispatch( mobileLeftNavActions.openRewards() )
    },

    enableDisableDocumentScroll: ( val ) => {
      dispatch( globalActions.enableDisableDocumentScroll( val ) );
    },

    registerRemoveIOSRubberEffect: ( elem ) => {
      dispatch( globalActions.registerRemoveIOSRubberEffect( elem ) );
    },

    logoutUser: ( ) =>{
      dispatch( userActions.logoutUser() )
    }

  };
}

class LeftNav extends Component{

  componentDidUpdate( prevProps ){
    // request the navigation data if we have an active session, but no nav data
    if( !isServer() && this.props.activeSession && !prevProps.activeSession ){
      // request the navigation data
      this.props.getNavigationData();
    }
  }

  render(){

    if( this.props.isMobileDevice ){
      return (
        <MobileLeftNav { ...this.props } />
      )
    }
    else {
      return (
        <DesktopLeftNav { ...this.props } />
      )
    }

  }
}


export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( LeftNav ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );
