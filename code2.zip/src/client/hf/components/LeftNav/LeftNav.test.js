import React from 'react';
import LeftNav, {
  mapStateToProps,
  mapDispatchToProps
} from './LeftNav';
import { shallow } from 'enzyme';
import {
  actions as mobileLeftNavActions
} from 'hf/actions/MobileLeftNav/MobileLeftNav.actions'
import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';
import {
  registerServiceName,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';
import {
  actions as userActions
} from 'shared/actions/User/User.actions';
import _ from 'lodash';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

const store = configureStore( {}, CONFIG );

const props = {
  mobileLeftNav: jest.fn(),
  global: jest.fn(),
  user: jest.fn(),
  header: jest.fn(),
  session: jest.fn()
}

let component = mountWithIntl(
  <Provider store={ store } >
    <LeftNav { ...props } />
  </Provider>
);

describe( 'MobileLeftNav state methods', () => {

  const dispatch = jest.fn();
  beforeEach( ()=> {
    dispatch.mockClear();
  } )

  const mdp  = mapDispatchToProps( dispatch );

  it( 'getNavigationData should dispatch the proper action', () => {
    registerServiceName( 'navigation' );
    const event = mdp.getNavigationData( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'navigation', 'requested' )()
    );
  } );

  it( 'setMobileLeftNavDimensions should dispatch the proper action', () => {
    const event = mdp.setMobileLeftNavDimensions( 6, 10 );
    expect( dispatch ).toHaveBeenCalledWith(
      mobileLeftNavActions.setMobileLeftNavDimensions( 6, 10 )
    );
  } );

  it( 'setActiveLevel should dispatch the proper action', () => {
    const event = mdp.setActiveLevel( 1, 2 );
    expect( dispatch ).toHaveBeenCalledWith(
      mobileLeftNavActions.setActiveLevel( 1, 2 )
    );
  } );

  it( 'toggleLeftNav should dispatch the proper action', () => {
    const event = mdp.toggleLeftNav( false );
    expect( dispatch ).toHaveBeenCalledWith(
      mobileLeftNavActions.toggleLeftNav( false )
    );
    expect( dispatch ).toHaveBeenCalledWith(
      globalActions.enableDisableDocumentScroll( false )
    );
  } );

  it( 'openRewards should dispatch the proper action', () => {
    const event = mdp.openRewards( );
    expect( dispatch ).toHaveBeenCalledWith(
      mobileLeftNavActions.openRewards( )
    );
  } );

  it( 'enableDisableDocumentScroll should dispatch the proper action', () => {
    const event = mdp.enableDisableDocumentScroll( true );
    expect( dispatch ).toHaveBeenCalledWith(
      globalActions.enableDisableDocumentScroll( true )
    );
  } );

  it( 'registerRemoveIOSRubberEffect should dispatch the proper action', () => {
    const elem= '<div></div>';
    const event = mdp.registerRemoveIOSRubberEffect( elem );
    expect( dispatch ).toHaveBeenCalledWith(
      globalActions.registerRemoveIOSRubberEffect( elem )
    );
  } );

  it( 'logoutUser should dispatch the proper action', () => {
    const event = mdp.logoutUser( );
    expect( dispatch ).toHaveBeenCalledWith(
      userActions.logoutUser( )
    );
  } );

  it( 'should render the DesktopLeftNav if \'global.innerWidth\' is greater than 991px', () => {

    window.innerWidth = 1200;
    const props1 = {
      isMobileDevice: false,
      desktopHeaderDisplayMode: 'default',
      desktopNavPanelList : [{
        'navList': [
          {
            'displayFeatured': 'true',
            'navDisplayContent': 'MAKEUP',
            'data-nav-description': 'makeup:featured',
            'displayBookAppt': 'false',
            'navElementType': 'rootCategory',
            'featuredLabel': 'Featured'
          }
        ]
      }],
      registerRemoveIOSRubberEffect: jest.fn(),
      setActiveLevel: jest.fn(),
      activeLevel: [],
      mobileNavContent: {
        navList: []
      }

    }
    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props1 } />
      </Provider>
    );
    expect( component.find( 'DesktopLeftNav' ).length ).toBe( 1 );
  } );
} );
