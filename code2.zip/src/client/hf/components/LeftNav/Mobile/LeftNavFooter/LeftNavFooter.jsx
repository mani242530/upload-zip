/**
 * LeftNavFooter
 */

import React from 'react';
import './LeftNavFooter.css';
import classNames from 'classnames';
import phoneSVG from 'shared/components/Icons/contact_us';
import emailSVG from 'shared/components/Icons/email';
import Button from 'shared/components/Button/Button';
import MixedMenuButton from 'shared/components/MixedMenuButton/MixedMenuButton';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './LeftNavFooter.messages';
import PropTypes from 'prop-types';



const propTypes = {
  userLogout: PropTypes.func
}


const LeftNavFooter = ( props ) => {

  const getUserLogout = () => {
    props.userLogout();
    props.toggleLeftNav( 'close' );
  }



  const {
    isSignedIn
  } = props;

  return (
    <div
      id='js-LeftNavFooter'
      className={
        classNames(
          'LeftNavFooter'
        )
      }
    >
      { ( ()=>{
        if( props.switchData && props.switchData.switches ){
          return (
            <MixedMenuButton
              icon={ phoneSVG }
              label={ props.switchData.switches.guestServiceNumber }
              details={ props.switchData.switches.guestServiceHours }
              pointerType='none'
              dataNavDescription='m - call'
              url='tel:+1-866-983-8582'
            />
          )
        }
      } )() }
      <MixedMenuButton
        icon={ emailSVG }
        label={ formatMessage( messages.sendUsAnEmail ) }
        pointerType='none'
        dataNavDescription='m - email'
        url={ '/ulta/guestservices/contactUs.jsp' }
      />
      {
        ( ()=>{
          if( isSignedIn ){
            return (
              <div className='LeftNavFooter__SignoutWrap'>
                <Button
                  inputTag='a'
                  btnSize='sm'
                  dataNavDescription='m - sign out'
                  btnURL={ 'ulta/myaccount/login.jsp?_DARGS=/ulta/global/inc/header_signIn_content.jsp_A&_DAV=logout' }
                >
                  { formatMessage( messages.signout ) }
                </Button>
              </div>
            )
          }
        } )()
      }
    </div>
  );
}

LeftNavFooter.propTypes = propTypes;

export default LeftNavFooter;