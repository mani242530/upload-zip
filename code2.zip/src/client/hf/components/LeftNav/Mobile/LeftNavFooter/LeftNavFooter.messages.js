/*
 * LeftNavFooter Messages
 *
 * This contains all the text for the LeftNavFooter component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  callUs: {
    id: 'i18n.LeftNavFooter.callUs',
    defaultMessage: 'Call Us 866-983-8582'
  },
  contactTimes: {
    id: 'i18n.LeftNavFooter.callUs',
    defaultMessage: '7am - 11pm CST 7 days a week'
  },
  sendUsAnEmail: {
    id: 'i18n.LeftNavFooter.sendUsAnEmail',
    defaultMessage: 'Send Us an Email'
  },
  signout:{
    id: 'i18n.LeftNavFooter.signOut',
    defaultMessage: 'Sign Out'
  }
} );
