import React from 'react';
import ReactDOM from 'react-dom';
import LeftNavFooter from './LeftNavFooter';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import _ from 'lodash';

describe( '<LeftNavFooter />', () => {
  let component, component1;

  let props = {
    switchData: {
      switches: {
        guestServiceNumber: '123-456-7890',
        guestServiceHours: '7pm - 8Am'
      }
    }
  }

  component1 = mountWithIntl(
    <LeftNavFooter
      isSignedIn={ true }
      { ...props }
    />
  );

  it( 'renders without crashing', () => {
    component = mountWithIntl( <LeftNavFooter/> );
    expect( component.find( 'LeftNavFooter' ).length ).toBe( 1 );
  } );

  it( 'renders a button if user is signedIn', () => {
    expect( component1.find( '.LeftNavFooter__SignoutWrap' ). length ).toBe( 1 );
  } );

  it( 'renders a button of type anchor if user is signedIn', () => {
    expect( component1.find( '.LeftNavFooter__SignoutWrap a' ). length ).toBe( 1 );
  } );

  it( 'renders mixedMenu Button', () => {
    expect( component1.find( 'MixedMenuButton' ).length ).toBe( 2 );

  } );

  it( 'renders MixedMenuButton with guestServiceNumber &  guestServiceHours component Only If the switches Data is Available', () => {
    var menuButtons = component1.find( 'MixedMenuButton' )
    expect( menuButtons.length ).toBe( 2 );
    expect( menuButtons.at( 0 ).props().label ).toEqual( props.switchData.switches.guestServiceNumber );
    expect( menuButtons.at( 0 ).props().details ).toEqual( props.switchData.switches.guestServiceHours );
  } );

  it( 'Does not renders MixedMenuButton with guestServiceNumber &  guestServiceHours component If the switches Data is not Available', () => {
    let props1={
      switchData: { }
    }

    let component2 = mountWithIntl(
      <LeftNavFooter
        isSignedIn={ true }
        { ...props1 }
      />
    );

    var menuButton = component2.find( 'MixedMenuButton' );
    expect( menuButton.length ).toBe( 1 );
    expect( menuButton.at( 0 ).props().label ).not.toBe( props.switchData.switches.guestServiceNumber );
  } );


  it( 'renders first mixedMenuButton with valid props', () => {
    expect( component1.find( 'MixedMenuButton' ).at( 0 ).props().url ).toEqual( 'tel:+1-866-983-8582' );
  } );

  it( 'renders second mixedMenuButton with valid props', () => {
    expect( component1.find( 'MixedMenuButton' ).at( 1 ).props().label ).toEqual( 'Send Us an Email' );
    expect( component1.find( 'MixedMenuButton' ).at( 1 ).props().url ).toEqual( '/ulta/guestservices/contactUs.jsp' );
  } );

  it( 'renders a button of type anchor with a correct href if user is signedIn', () => {
    expect( component1.find( '.LeftNavFooter__SignoutWrap a' ).props().href ).toEqual( '//www.ulta.com/ulta/myaccount/login.jsp?_DARGS=/ulta/global/inc/header_signIn_content.jsp_A&_DAV=logout' );
  } );
} );
