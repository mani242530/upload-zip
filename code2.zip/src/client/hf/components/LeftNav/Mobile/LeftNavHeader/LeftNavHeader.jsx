/**
 * LeftNavHeader
 */

import React from 'react';
import classNames from 'classnames';
import './LeftNavHeader.css';
import { formatMessage } from 'shared/components/Global/Global';
import { Collapse } from 'react-bootstrap';
import messages from './LeftNavHeader.messages';
import Button from 'shared/components/Button/Button';
import MainNavBtn from 'hf/components/Headers/mobile/MainNavBtn/MainNavBtn';
import Anchor from 'shared/components/Anchor/Anchor';
import ChevronLeftSVG from 'shared/components/Icons/chevronleft';
import HeartSVG from 'shared/components/Icons/heart';
import HomeSVG from 'shared/components/Icons/home';
import AccountSVG from 'shared/components/Icons/account';
import RewardsSVG from 'shared/components/Icons/rewards';

const LeftNavHeader = ( props ) => {


  const renderAnonymous = ( formatMessage ) => {

    return (
      <div className='LeftNavHeader__Anonymous'>
        <div className='LeftNavHeader__Button LeftNavHeader__Button--signin'>
          <Button
            id='signIn_Button'
            ref={ ( refId ) => {
              props.getButtonRef( refId );
            } }
            btnOption='single'
            inputTag='a'
            btnSize='sm'
            dataNavDescription='m - sign in'
            btnURL={ '/ulta/myaccount/login.jsp' }
          >
            <span>{ formatMessage( messages.signin ) }</span>
          </Button>
        </div>
        <div className='LeftNavHeader__Button LeftNavHeader__Button--signup'>
          <Button
            btnOption='single'
            inputTag='a'
            btnOutLine={ true }
            btnSize='sm'
            dataNavDescription='m - sign up'
            btnURL={ 'ulta/myaccount/register.jsp' }
          >
            <span>{ formatMessage( messages.signup ) }</span>
          </Button>
        </div>
      </div>
    )

  }



  const renderSignedIn = ( formatMessage ) => {

    const {
      userName,
      rewardPointTotal,
      isRewardsMember
    } = props

    return (
      <div className='LeftNavHeader__SignedIn'>
        <div className='LeftNavHeader__Text-welcome'>
          { formatMessage( messages.welcome, { name: userName } ) }
        </div>

        { ( () => {
          if( isRewardsMember && rewardPointTotal > 0 ){
            return (
              <div className='LeftNavHeader__Text-rewards'>
                { formatMessage( messages.rewardspoints, { points: rewardPointTotal } ) }
              </div>
            )
          }
        } )() }


      </div>
    )

  }

  const handleBackClick = () => {
    props.setActiveLevel( props.activeLevel.slice( 0, -1 ) );
    props.resetNavScrollPosition();
  }

  const renderNavigationBackButton = ( formatMessage ) => {
    return (
      <div
        className='Navigation__Back'
        onClick={
          ( e ) => {
            handleBackClick()
          }
        }
      >
        <div className='Navigation__Back--icon'>
          <ChevronLeftSVG />
        </div>
        <div className='Navigation__Back--text'>
          { formatMessage( messages.back ) }
        </div>
      </div>
    );
  }

  const renderUtilityBar = ( formatMessage ) => {
    const {
      isSignedIn,
      rewardsOpen,
      openRewards
    } = props;
    return (
      <div className='UtilityBar'>

        <div className='LeftNavHeader__Row LeftNavHeader__Row--spacing'>
          { isSignedIn ? renderSignedIn( formatMessage ) : renderAnonymous( formatMessage ) }
        </div>

        <div className='LeftNavHeader__Row'>
          <div className='LeftNavHeader__MainNavBtn'>
            <MainNavBtn
              id='home_MainNavBtn'
              dataNavDescription='m - home'
              Svg={ HomeSVG }
              label={ formatMessage( messages.home ) }
              url={ '/' }
            />
          </div>
          <div className='LeftNavHeader__MainNavBtn'>
            <MainNavBtn
              dataNavDescription='m - favorites'
              Svg={ HeartSVG }
              label={ formatMessage( messages.favorites ) }
              url={ 'ulta/myaccount/template.jsp?page=favorites' }
            />
          </div>
          <div className='LeftNavHeader__MainNavBtn'>
            <MainNavBtn
              dataNavDescription='m - my account'
              Svg={ AccountSVG }
              label={ formatMessage( messages.myaccount ) }
              url={ 'ulta/myaccount/template.jsp?page=profile' }
            />
          </div>
          <div
            className={
              classNames( 'LeftNavHeader__MainNavBtn', {
                'LeftNavHeader__MainNavBtn--close' : !rewardsOpen,
                'LeftNavHeader__MainNavBtn--open': rewardsOpen
              } )
            }
          >
            { ( () => {
              if( isSignedIn ){
                return (
                  <MainNavBtn
                    dataNavDescription='m - rewards'
                    Svg={ RewardsSVG }
                    label={ formatMessage( messages.rewards ) }
                    url={ 'ulta/myaccount/rewards_template.jsp?page=rewards' }
                  />
                )
              }
              else {
                return (
                  <MainNavBtn
                    Svg={ RewardsSVG }
                    label={ formatMessage( messages.rewards ) }
                    url='#'
                    onClick={
                      ( e )=>{
                        e.preventDefault();
                        openRewards();
                      }
                    }
                  />
                )
              }
            } )() }
          </div>
        </div>
        <Collapse in={ rewardsOpen } >
          <div>
            <div className='LeftNavHeader__Rewards-link' >
              <Anchor
                dataNavDescription='m - learn more'
                url={ 'ulta/myaccount/learnmore_template.jsp?page=benefits' }
              >
                <span>{ formatMessage( messages.link_learnmore ) }</span>
              </Anchor>
            </div>
            <div className='LeftNavHeader__Rewards-link' >
              <Anchor
                dataNavDescription='m - my rewards'
                url={ 'ulta/myaccount/login.jsp?benefits=true' }
              >
                <span>{ formatMessage( messages.link_rewards ) }</span>
              </Anchor>
            </div>
            <div className='LeftNavHeader__Rewards-link' >
              <Anchor
                dataNavDescription='m - ultamate rewards credit card'
                url={ 'ulta/creditcards/landingpage.jsp' }
              >
                <span>{ formatMessage( messages.link_creditcard ) }</span>
              </Anchor>
            </div>
          </div>
        </Collapse>
      </div>
    )
  }


  /**
   * Renders the LeftNavHeader component
   */



  return (
    <div
      id='js-LeftNavHeader'
      className='LeftNavHeader'
    >
      {
        ( ()=>{
          if( props.activeLevel.length !== 0 ){
            return renderNavigationBackButton( formatMessage );
          }
          else {
            return renderUtilityBar( formatMessage )
          }
        } )()
      }
    </div>
  );

}

export default LeftNavHeader;
