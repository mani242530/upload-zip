/*
 * LeftNavHeader Messages
 *
 * This contains all the text for the LeftNavHeader component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  back: {
    id: 'i18n.LeftNavHeader.back',
    defaultMessage: 'Back'
  },
  signin: {
    id: 'i18n.LeftNavHeader.signin',
    defaultMessage: 'Sign In'
  },
  signup: {
    id: 'i18n.LeftNavHeader.signup',
    defaultMessage: 'Sign Up'
  },
  home: {
    id: 'i18n.LeftNavHeader.home',
    defaultMessage: 'Home'
  },
  favorites: {
    id: 'i18n.LeftNavHeader.favorites',
    defaultMessage: 'Favorites'
  },
  myaccount: {
    id: 'i18n.LeftNavHeader.myaccount',
    defaultMessage: 'My Account'
  },
  rewards: {
    id: 'i18n.LeftNavHeader.rewards',
    defaultMessage: 'Rewards'
  },
  welcome: {
    id: 'i18n.LeftNavHeader.welcome',
    defaultMessage: 'Hi, {name}!'
  },
  rewardspoints: {
    id: 'i18n.LeftNavHeader.rewardspoints',
    defaultMessage: 'You have {points} Points'
  },
  link_learnmore: {
    id: 'i18n.LeftNavHeader.link_learnmore',
    defaultMessage: 'Learn More'
  },
  link_rewards: {
    id: 'i18n.LeftNavHeader.link_rewards',
    defaultMessage: 'My Rewards'
  },
  link_creditcard: {
    id: 'i18n.LeftNavHeader.link_creditcard',
    defaultMessage: 'Ultamate Rewards Credit Card'
  }


} );
