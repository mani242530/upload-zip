import React from 'react';
import ReactDOM from 'react-dom';
import LeftNavHeader from './LeftNavHeader';
import messages from './LeftNavHeader.messages';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

let store = configureStore( {}, CONFIG );
let props = {
  isSignedIn: true,
  activeLevel: [],
  openRewards: jest.fn(),
  getButtonRef: jest.fn()
}


describe( '<LeftNavHeader />', () => {
  let component;


  it( 'renders without crashing', () => {
    component = mountWithIntl( <LeftNavHeader { ...props }/> );
    expect( component.find( 'LeftNavHeader' ).length ).toBe( 1 );
  } );


  describe( 'Buttons', () => {

    var prop = {
      ...props,
      isSignedIn: false
    }
    component = mountWithIntl(
      <LeftNavHeader
        { ...prop }
        isSignedIn={ false }
      />
    );
    let buttons = component.find( 'Button' );

    it( 'renders a sign in button with the correct text when not signed in', () => {
      expect( buttons.at( 0 ).text() ).toEqual( messages.signin.defaultMessage )
    } );

    it( 'renders a sign up button with the correct text', () => {
      expect( buttons.at( 1 ).text() ).toEqual( messages.signup.defaultMessage )
    } )

  } );

  let navButtons = component.find( 'MainNavBtn' );

  describe( 'MainNavBtn', () => {
    let prop = {
      ...props
    }
    it( 'renders for main nav buttons', () => {
      expect( navButtons.length ).toEqual( 4 );
    } );

    it( 'renders home button', () => {
      expect( navButtons.at( 0 ).text() ).toEqual( messages.home.defaultMessage )
      expect( navButtons.at( 0 ).find( 'Anchor' ).props().url ).toEqual( '/' )
    } );

    it( 'should have id as home_MainNavBtn for Home Link', () => {
      expect( navButtons.at( 0 ).find( 'Anchor' ).props().id ).toEqual( 'home_MainNavBtn' )
    } );

    it( 'renders favorites button', () => {
      expect( navButtons.at( 1 ).text() ).toEqual( messages.favorites.defaultMessage )
      expect( navButtons.at( 1 ).find( 'Anchor' ).props().url ).toEqual( 'ulta/myaccount/template.jsp?page=favorites' )
    } );

    it( 'renders my account button', () => {
      expect( navButtons.at( 2 ).text() ).toEqual( messages.myaccount.defaultMessage )
      expect( navButtons.at( 2 ).find( 'Anchor' ).props().url ).toEqual( 'ulta/myaccount/template.jsp?page=profile' )
    } );

    it( 'renders rewards button when signedIn true', () => {
      component = mountWithIntl(
        <LeftNavHeader
          { ...prop }
          isSignedIn={ true }
        />
      );
      let navButtons = component.find( 'MainNavBtn' );
      expect( navButtons.at( 3 ).props().label ).toEqual( messages.rewards.defaultMessage );
      expect( navButtons.at( 3 ).find( 'Anchor' ).props().url ).toEqual( 'ulta/myaccount/rewards_template.jsp?page=rewards' );
    } );

    it( 'renders rewards button when signedIn false', () => {
      component = mountWithIntl(
        <LeftNavHeader
          { ...prop }
          isSignedIn={ false }
        />
      );
      let navButtons = component.find( 'MainNavBtn' );
      expect( navButtons.at( 3 ).props().label ).toEqual( messages.rewards.defaultMessage );
      expect( navButtons.at( 3 ).find( 'Anchor' ).props().url ).toEqual( '#' );
    } );

  } );

  describe( 'navigation back button', () => {
    var prop = {
      ...props,
      activeLevel: ['1|1'],
      isSignedIn: false
    }
    component = mountWithIntl(
      <LeftNavHeader
        { ...prop }
      />
    );

    it( 'should render the back button if the menu is on a sub tier', () => {
      let backbtn = component.find( '#js-LeftNavHeader' );
      expect( backbtn.length ).toBe( 1 );

    } );

  } );


  describe( 'Rewards Collapse Menu', () => {

    var prop = {
      ...props,
      isSignedIn: false
    }
    component = mountWithIntl(
      <LeftNavHeader
        { ...prop }
      />
    );
    let navButtons = component.find( 'MainNavBtn' )
    let rewardsMenu = component.find( 'Collapse' );


    it( 'rewards button has onclick event', () => {
      expect( navButtons.at( 3 ).props().onClick.length ).toBe( 1 );
    } );

    it( 'expands menu when clicked', () => {

      navButtons.at( 3 ).simulate( 'click' );
      expect( prop.openRewards ).toHaveBeenCalled();
    } );

    it( 'rewards menu renders three links', () => {
      expect( rewardsMenu.find( 'Anchor' ).length ).toBe( 3 );
    } );
    it( 'renders Learn More Link', () => {
      expect( rewardsMenu.find( 'Anchor' ).at( 0 ).props().url ).toEqual( 'ulta/myaccount/learnmore_template.jsp?page=benefits' );
    } );

    it( 'renders My Rewards Link', () => {
      expect( rewardsMenu.find( 'Anchor' ).at( 1 ).props().url ).toEqual( 'ulta/myaccount/login.jsp?benefits=true' );
    } );

    it( 'renders Ultamate Rewards Credit Card Link', () => {
      expect( rewardsMenu.find( 'Anchor' ).at( 2 ).props().url ).toEqual( 'ulta/creditcards/landingpage.jsp' );
    } );

    it( 'renders appropriate header if \'isSignedIn\' attribute is set to true', () => {
      component = mountWithIntl(
        <Provider store={ store } >
          <LeftNavHeader { ...props } />
        </Provider>
      )

      const element = component.find( 'LeftNavHeader' ).children().find( '.LeftNavHeader__SignedIn' );
      expect( element.length ).toBe( 1 );
    } );

    it( 'renders appropriate header if \'isRewardsMember\' atrribute is set to true and if \'rewardPointTotal\' are 0', () => {
      props.isRewardsMember = true;
      props.rewardPointTotal = 0;
      component = mountWithIntl(
        <Provider store={ store } >
          <LeftNavHeader { ...props } />
        </Provider>
      )
      expect( component.find( '.LeftNavHeader__Text-rewards' ).length ).toBe( 0 );
    } );

    it( 'renders appropriate header if \'isRewardsMember\' atrribute is set to true and if \'rewardPointTotal\' are more than 0', () => {
      props.isRewardsMember = true;
      props.rewardPointTotal = 20;
      component = mountWithIntl(
        <Provider store={ store } >
          <LeftNavHeader { ...props } />
        </Provider>
      )
      expect( component.find( '.LeftNavHeader__Text-rewards' ).length ).toBe( 1 );
    } );

    it( 'renders appropriate header if \'isRewardsMember\' atrribute is set to false', () => {
      props.isRewardsMember = false;
      component = mountWithIntl(
        <Provider store={ store } >
          <LeftNavHeader { ...props } />
        </Provider>
      )
      expect( component.find( '.LeftNavHeader__Text-rewards' ).length ).toBe( 0 );
    } );

    it( 'renders MainNavBtn as a button without Collapse component if \'isSignedIn\' attribute is set to false', () => {

      props.isSignedIn = false

      component = mountWithIntl(
        <Provider store={ store } >
          <LeftNavHeader { ...props } />
        </Provider>
      )

      const mainNavBtnProps = component.find( 'LeftNavHeader' ).children().find( 'MainNavBtn' ).at( 3 ).props()
      expect( typeof( mainNavBtnProps.onClick ) ).toBe( 'function' );
    } );

    it( 'renders appropriate header if \'isSignedIn\' attribute is set to false', () => {

      props.isSignedIn = false

      component = mountWithIntl(
        <Provider store={ store } >
          <LeftNavHeader { ...props } />
        </Provider>
      )

      const element = component.find( 'LeftNavHeader' ).children().find( '.LeftNavHeader__Anonymous' )
      expect( element.length ).toBe( 1 );
    } );

  } );

} );
