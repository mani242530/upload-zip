/**
 * LeftNav
 */

import React, { Component } from 'react';
import NavSection from 'hf/components/NavSection/NavSection';
import LeftNavFooter from 'hf/components/LeftNav/Mobile/LeftNavFooter/LeftNavFooter';
import LeftNavHeader from 'hf/components/LeftNav/Mobile/LeftNavHeader/LeftNavHeader';
import classNames from 'classnames';
import './LeftNav.css';
import CloseX from 'shared/components/Icons/close';
import DesktopLeftNav from 'hf/components/LeftNav/Desktop/DesktopLeftNav/DesktopLeftNav';
import isEmpty from 'lodash/isEmpty';
import isUndefined from 'lodash/isUndefined';
import delay from 'lodash/delay';
import throttle from 'lodash/throttle';
import difference from 'lodash/difference';
import { scrollToTop } from 'utils/Animation/Animation';
import { maintain } from 'ally.js';


const initialState = {
  navHeight: 'auto'
}

/**
 * Class
 * @extends React.Component
 */

class LeftNav extends Component{


  /**
   * Create a LeftNav
   */
  constructor( props ){
    super( props );

    this.state = initialState;
    this.resetNavScrollPosition = this.resetNavScrollPosition.bind( this );
    this.setFocusToSignIn = this.setFocusToSignIn.bind( this );
    this.setFocusToHome = this.setFocusToHome.bind( this );
    this.disableBackgroundElements = this.disableBackgroundElements.bind( this );
    this.enableBackgroundElements = this.enableBackgroundElements.bind( this );
    this.getButtonRef = this.getButtonRef.bind( this );
    this.focussedElement = undefined; // we are using this variable to remove aria-hidden='true' from the divs using ally.js
  }

  componentDidMount(){

    let scrollContainer = document.getElementById( 'LeftNav__container--scroll' );
    this.props.registerRemoveIOSRubberEffect( scrollContainer );
    // if we have an active session flag here it means that the session was stored in the session cookie,
    // so we can immeditely request the navigation data
    if( this.props.activeSession ){
      // only get leftNavData if we don't have any
      if( isEmpty( this.props.mobileNavContent ) ){
        this.props.getNavigationData();
      }

    }
  }

  componentDidUpdate( prevProps ){

    // request the navigation data if we have an active session, but no nav data
    if( this.props.activeSession && !prevProps.activeSession ){
      // request the navigation data
      this.props.getNavigationData();
    }
    if( !prevProps.menuActive && this.props.menuActive ){
      if( this.props.isSignedIn ){
        // the focus will be on Home link for the registered user when the user clicks on Menu button
        this.setFocusToHome();
      }
      else {
        // the focus will be on SignIn link for the anonymous user when the user clicks on Menu button
        this.setFocusToSignIn();
      }
    }

    if( !prevProps.menuActive && this.props.menuActive ){
      this.disableBackgroundElements();
    }

    if( prevProps.menuActive && !this.props.menuActive ){
      this.enableBackgroundElements();
    }


    if( this.props.mobileNavContent.navList && isEmpty( prevProps.mobileNavContent.navList ) ){
      try {
        let navContent;
        let activeNavContent = document.querySelectorAll( '.LeftNav__animation__container--visible' );
        if( activeNavContent.length > 0 ){
          navContent = activeNavContent[ activeNavContent.length - 1 ];
        }
        else {
          navContent = document.getElementById( 'LeftNav__animation__container' );
        }

        // header height
        var navHeaderHeight = document.getElementById( 'js-LeftNavHeader' ).offsetHeight;
        var navFooterHeight = document.getElementById( 'js-LeftNavFooter' ).offsetHeight;

        var minContentHeight = global.innerHeight - navHeaderHeight - navFooterHeight;


        let navHeight;
        if( this.props.activeLevel.length === 0 ){

          navHeight = 'auto';
        }
        else {

          navHeight = navContent.offsetHeight < minContentHeight ? `${minContentHeight}px`: `${navContent.offsetHeight}px`
        }

        // find the active panel and grab the heigh from there
        this.props.setMobileLeftNavDimensions( navContent.offsetWidth, navContent.offsetHeight );

        if( this.state.navHeight !== navHeight ){
          this.setState( { navHeight: navHeight } );
        }

      }
      catch ( e ){

      }

    }
  }

  disableBackgroundElements(){
    // we are injecting aria-hidden='true' for all the div elements except leftnav and globalAssertiveRegion as soon as the user clicks on Menu button (only on Mobile) using ally.js
    let globalAssertiveRegion = document.getElementById( 'globalAssertiveRegion' );
    let navElement = this.mobileLeftNavRef;
    this.focussedElement = maintain.hidden( {
      filter: [navElement, globalAssertiveRegion]
    } );
  }

  enableBackgroundElements(){
    // aria-hidden='true' will be removed on all the divs after closing the menu button.
    this.focussedElement.disengage();

  }
  setFocusToSignIn(){
    // setting focus to SignIn button once the user clicks on Menu(Hamburger) button for anonymous user.
    if( this.signInButtonRef ){
      this.signInButtonRef.focus();
    }
  }

  setFocusToHome(){
    // setting focus to Home button once the user clicks on Menu(Hamburger) button for registered user.
    if( document.getElementById( 'home_MainNavBtn' ) ){
      document.getElementById( 'home_MainNavBtn' ).focus();
    }
  }
  resetNavScrollPosition(){

    let elem = document.getElementById( 'LeftNav__container--scroll' );
    let scrollUp = throttle( ()=> {
      delay( ()=> {
        scrollToTop( elem, 300 );
      }, 750 );
    }, 1000 );

    scrollUp();

  }


  /**
   * Closes the LeftNav
   */
  closeNav(){
    // dispatch an action to reset the sub menus
    document.getElementById( 'LeftNav__container--scroll' ).scrollTop = 0;
    this.props.toggleLeftNav( 'close' );
  }


  /**
   * Takes a floating point number, converts it to
   * a fixed number and returns the number as a string
   * with 'px' concatenated suitable for use in CSS as
   * a px dimension
   */
  pixelize( num ){
    let _num = num.toFixed( 2 );
    return _num + 'px';
  }

  getButtonRef( refId ){
    this.signInButtonRef = refId;
  }
  /**
   * Renders the LeftNav component
   */
  render(){
    // return null;

    const {
      menuActive,
      mobileLeftNavHeight,
      mobileLeftNavWidth,
      mobileNavContent
    } = this.props


    let expandHeightType = this.state.navHeight === 'auto' ? mobileLeftNavHeight: this.navHeight;

    const animationConfig = {
      duration: 700,
      halfExpandedHeight: expandHeightType * 1.2,
      expandedHeight: expandHeightType * 3.4,
      startPosition: {
        x: 30,
        y: 30
      },
      mobileHeaderAdjust: 56
    }

    let innerContentStyle = {};


    let animateFromCircleStyle = {};

    // by running this only when mobileLeftNavHeight > 0 we can
    // read the height of the content div in componentDidMount before
    // setting the starting values for the circle animation. Once these
    // values are set, the height of the content div is altered by setting these styles.
    if( mobileLeftNavHeight !== 0 ){

      animateFromCircleStyle = {
        'width': '0',
        'height': '0',
        'top': this.pixelize( animationConfig.startPosition.y ),
        'left': this.pixelize( animationConfig.startPosition.x ),
        'WebkitTransition': `all ${ animationConfig.duration }ms ease-in-out`,
        'MozTransition': `all ${ animationConfig.duration }ms ease-in-out`,
        'transition': `all ${ animationConfig.duration }ms ease-in-out`
      }

      innerContentStyle = {
        'opacity': '0',
        'WebkitTransition': `opacity ${ animationConfig.duration }ms ease-in-out 0.4s`,
        'MozTransition': `opacity ${ animationConfig.duration }ms ease-in-out 0.4s`,
        'transition': `opacity ${ animationConfig.duration }ms ease-in-out 0.4s`
      }

      if( menuActive ){
        innerContentStyle = Object.assign( {},
          innerContentStyle,
          {
            'opacity': 1
          }
        )
      }
    }

    const animateToCircleStyle = Object.assign( {},
      animateFromCircleStyle,
      {
        'width': this.pixelize( animationConfig.expandedHeight ),
        'height': this.pixelize( animationConfig.expandedHeight ),
        'top': this.pixelize( - animationConfig.halfExpandedHeight + animationConfig.startPosition.y ),
        'left': this.pixelize( - animationConfig.halfExpandedHeight + animationConfig.startPosition.x )
      }
    )

    const backgroundAnimateFromStyle = {
      'opacity': 0.9,
      'WebkitTransition': `opacity ${ animationConfig.duration }ms ease-in-out`,
      'MozTransition': `opacity ${ animationConfig.duration }ms ease-in-out`,
      'transition': `opacity ${ animationConfig.duration }ms ease-in-out`
    }

    const backgroundAnimateToStyle = Object.assign( {},
      backgroundAnimateFromStyle,
      {
        'opacity': 0.9
      }
    )

    const xAnimateToStyle = Object.assign( {},
      backgroundAnimateFromStyle,
      {
        'opacity': 1
      }
    )

    if( this.props.mobileHeaderDisplayMode !== 'focused' && this.props.isMobileDevice ){
      return (
        <div
          className='LeftNav'
          style={ ( ()=>( menuActive? { 'left': 0 } : {} ) )() }
          id='mhp-left-nav'
          ref={ ( refId ) => {
            this.mobileLeftNavRef = refId;
          } }
        >
          <div className='LeftNav__wrapper'>
            <div
              className='LeftNav__background'
              onClick={ ( e ) => {
                this.closeNav()
              } }
              style={ menuActive ? backgroundAnimateToStyle : backgroundAnimateFromStyle }
            >
            </div>

            <div
              style={ innerContentStyle }
              className='LeftNav__container__inner__border'
            ></div>

            <div className='LeftNav__container__inner' >

              <div
                className='LeftNav__container__inner__circle'
                style={ menuActive ? animateToCircleStyle : animateFromCircleStyle }
                id='left-nav-circle'
              >
              </div>

              <div
                className='LeftNav__container__inner__content'
                style={ innerContentStyle }
                id='left-nav-content'
              >
                <div
                  id='LeftNav__container--scroll'
                  className='LeftNav__container--scroll touchMoveAllowed'
                  style={
                    { height: `${global.innerHeight}px` }
                  }
                >
                  <LeftNavHeader
                    resetNavScrollPosition={ this.resetNavScrollPosition }
                    getButtonRef={ this.getButtonRef }
                    { ...this.props }
                  />
                  <div
                    className='LeftNav__animationroot'
                    style={
                      {
                        transform: `translateX( ${this.props.leftNavAnimationOffset} )`
                      }
                    }
                  >
                    <div
                      id='LeftNav__animation__container'
                      className='LeftNav__animation__container LeftNav__animation__container--topLevel'
                      style={
                        {
                          height: this.state.navHeight
                        }
                      }
                    >
                      {
                        ( ()=>{

                          if( mobileNavContent.navList ){
                            return mobileNavContent.navList.map( ( section, index ) => {

                              switch ( section.navElementType ){

                                case 'CategorySeparator':
                                  return (
                                    <div
                                      className={
                                        classNames(
                                          'LeftNav__separator', {
                                            'LeftNav__separator--line': section.insertLine
                                          }
                                        )
                                      }
                                      key={ index }
                                    />
                                  )

                                default:

                                  const navSectionProps = {
                                    level: [],
                                    resetNavScrollPosition: this.resetNavScrollPosition,
                                    parentIndex: 0,
                                    setActiveLevel: this.props.setActiveLevel,
                                    activeLevel: this.props.activeLevel,
                                    navWidth: mobileLeftNavWidth,
                                    sectionHeader: section.navDisplayContent,
                                    sectionHeaderUrl: section.navTargetLink,
                                    categories: section.categories,
                                    broadcastMessage: this.props.broadcastMessage
                                  }

                                  return (
                                    <NavSection
                                      key={ index }
                                      { ...navSectionProps }
                                    />
                                  )
                              }
                            } )
                          }
                        } )()
                      }

                    </div>
                  </div>
                  <LeftNavFooter
                    { ...this.props }
                    userLogout={ this.props.logoutUser }
                  />
                </div>
              </div>
            </div>

            <div
              className='LeftNav__x'
              style={ menuActive ? xAnimateToStyle : backgroundAnimateFromStyle }
              role='button'
              tabIndex='-1'
              onClick={ ( e ) => {
                this.closeNav()
              } }
            >
              <CloseX />
            </div>
          </div>
        </div>
      )
    }
    else {
      return null;
    }
  }
}

export default LeftNav;
