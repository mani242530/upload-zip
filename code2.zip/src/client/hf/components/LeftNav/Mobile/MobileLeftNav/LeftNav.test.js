import React from 'react';
import ReactDOM from 'react-dom';
import LeftNav from './LeftNav';
import toJson from 'enzyme-to-json';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { mountWithIntl, shallowWithIntl } from 'utils/intl-enzyme-test-helper';
import device from 'utils/DeviceDetection/deviceDetection';

let store = configureStore( {}, CONFIG );



let props = {
  isMobileDevice: true,
  registerRemoveIOSRubberEffect: jest.fn(),
  setActiveLevel: jest.fn(),
  activeLevel: [],
  mobileNavContent: {
    navList: []
  },
  desktopNavContent: {
    navList: []
  },
  desktopNavPanelList:[],
  requestLeftNavData: jest.fn(),
  menuActive:true
}


global.innerWidth = 900;

describe( '<LeftNav />', () => {
  let component;

  it( 'renders without crashing', () => {

    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props } />
      </Provider>
    );

    expect( component.find( 'LeftNav' ).length ).toBe( 1 );
  } );

  it( 'renders the LeftNavHeader component when \'navDisplayContent\' attribute is set to \'UTILITY MENU\'', () => {

    props.mobileNavContent.navList = [
      {
        'navDisplayContent': 'UTILITY MENU',
        'navElementType': 'MobileUtilityMenu',
        'categories': [
          {
            'navDisplayContent': 'Home',
            'navTargetLink': '/',
            'navElementType': 'MobileUtilityBar'
          }
        ]
      },
      {
        'navDisplayContent': 'SHOP',
        'navElementType': 'SHOP',
        'categories': [
          {
            'navDisplayContent': 'Brands',
            'navTargetLink': '/global/nav/allbrands.jsp',
            'navElementType': 'rootCategory',
            'categories': []
          }
        ]
      },
      {
        'endeca:auditInfo': {
          'ecr:resourcePath': '/content/Shared/Mobile Navigation Collection/Mobile LeftNav New',
          'ecr:innerPath': 'content[2]'
        },
        'navDisplayContent': 'Filler',
        'navElementType': 'CategorySeparator',
        'insertLine': true
      }
    ]

    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props } />
      </Provider>
    );

    expect( component.find( 'LeftNavHeader' ).length ).toBe( 1 );
  } );

  it( 'sets focus to SignIn button when anonymous user clicks on Menu', () => {
    let appElement = document.createElement( 'div' );
    appElement.id='globalAssertiveRegion';
    document.body.appendChild( appElement );
    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props } />
      </Provider>
    );
    let props1={
      ...props,
      menuActive: false
    }
    props.isSignedIn= false;
    let target = component.find( 'LeftNav' ).instance();
    target.setFocusToSignIn = jest.fn();
    target.componentDidUpdate( props1 );
    expect( target.setFocusToSignIn ).toBeCalled();
  } );
  let instance;
  var placeholder = document.createElement( 'div' );
  placeholder.id = 'LeftNav__container--scroll';
  placeholder.scrollTop = 0;
  document.getElementById = jest.fn().mockReturnValue( placeholder );

  it( 'should call the closeNav method with onClick of div with className LeftNav__background', () => {
    props.toggleLeftNav = jest.fn();
    component = mountWithIntl( <LeftNav { ...props } /> );
    instance = component.find( 'LeftNav' ).instance();
    component.find( 'LeftNav' ).find( '.LeftNav__wrapper .LeftNav__background' ).simulate( 'click', instance.closeNav );
    expect( document.getElementById( placeholder ).scrollTop ).toEqual( 0 );
    expect( props.toggleLeftNav ).toHaveBeenCalledWith( 'close' );
  } );

  it( 'sets focus to Home button when registered user clicks on Menu', () => {
    props.isSignedIn= true;
    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props } />
      </Provider>
    );
    let props1={
      ...props,
      menuActive: false
    }
    let target = component.find( 'LeftNav' ).instance();
    target.setFocusToHome = jest.fn();
    target.componentDidUpdate( props1 );
    expect( target.setFocusToHome ).toBeCalled();
  } );

  it( 'should call the closeNav method with onClick of div with className LeftNav__x', () => {
    let props2 = {
      isMobileDevice: true,
      registerRemoveIOSRubberEffect: jest.fn(),
      setActiveLevel: jest.fn(),
      activeLevel: [],
      mobileNavContent: {
        navList: []
      },
      desktopNavContent: {
        navList: []
      },
      desktopNavPanelList:[],
      requestLeftNavData: jest.fn(),
      toggleLeftNav : jest.fn()
    }
    component = mountWithIntl( <LeftNav { ...props2 } /> );
    let instance = component.find( 'LeftNav' ).instance();
    expect( props2.toggleLeftNav ).not.toHaveBeenCalledWith( 'close' );
    component.find( 'LeftNav' ).find( '.LeftNav__wrapper .LeftNav__x' ).simulate( 'click', instance.closeNav );
    expect( document.getElementById( placeholder ).scrollTop ).toEqual( 0 );
    expect( props2.toggleLeftNav ).toHaveBeenCalledWith( 'close' );
  } );
  describe( 'renderNavContent()', () => {

    it( 'renders a separator when \'navElementType\' attribute is set to \'CategorySeparator\'', () => {

      component = mountWithIntl(
        <Provider store={ store } >
          <LeftNav { ...props } />
        </Provider>
      );

      expect( component.find( 'LeftNav' ).children().find( '.LeftNav__separator' ).length ).toBe( 1 );
    } );

    it( 'renders a separator as a line when \'insertLine\' attribute is set to \'true\'', () => {

      component = mountWithIntl(
        <Provider store={ store } >
          <LeftNav { ...props } />
        </Provider>
      );

      expect( component.find( 'LeftNav' ).children().find( '.LeftNav__separator.LeftNav__separator--line' ).length ).toBe( 1 );
    } );

    it( 'renders a <NavSection /> component by default', () => {

      component = mountWithIntl(
        <Provider store={ store } >
          <LeftNav { ...props } />
        </Provider>
      );

      expect( component.find( 'LeftNav' ).children().find( 'NavSection' ).length ).toBe( 2 );
    } );
  } );

  it( 'should render an x to close the nav', () => {

    // this test is disabled until we get confirmation from the UX team
    // as to whether or not we need the 'x'

    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props } />
      </Provider>
    );
    expect( component.find( '.LeftNav__x' ).length ).toBe( 1 );
  } );


  it( 'should invoke setMobileLeftNavDimensions when component is updated', () => {

    window.innerWidth = 1200;
    const props1 = {
      isMobileDevice: false,
      desktopHeaderDisplayMode: 'default',
      desktopNavPanelList : [{
        'navList': [
          {
            'displayFeatured': 'true',
            'navDisplayContent': 'MAKEUP',
            'data-nav-description': 'makeup:featured',
            'displayBookAppt': 'false',
            'navElementType': 'rootCategory',
            'featuredLabel': 'Featured'
          }
        ]
      }],
      registerRemoveIOSRubberEffect: jest.fn(),
      setActiveLevel: jest.fn(),
      activeLevel: [],
      mobileNavContent: {
        navList: [{ 'Category':'Men' }, { 'Cateogry':'Fragrance' }]
      },
      setMobileLeftNavDimensions:jest.fn()

    }

    const prevProps = {
      mobileNavContent: {
        navList: []
      }
    }
    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props1 } />
      </Provider>
    );
    let appElement = document.createElement( 'div' );
    appElement.id='js-LeftNavHeader';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id='js-LeftNavFooter';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id='LeftNav__animation__container';
    document.body.appendChild( appElement );

    component.find( 'LeftNav' ).instance().componentDidUpdate( prevProps );
    expect( props1.setMobileLeftNavDimensions ).toBeCalled();
  } );

  const prevProps = {
    mobileNavContent: {
      navList: []
    },
    activeSession: false,
    menuActive: false
  }
  props.activeSession = true;
  props.getNavigationData = jest.fn();
  props.menuActive = true;

  it( 'should request the navigation data if we have an active session and if isSignedIn is true, set focus on Home link', () => {
    props.isSignedIn = true;
    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props } />
      </Provider>
    );
    instance = component.find( 'LeftNav' ).instance();
    instance.setFocusToHome =jest.fn();
    instance.componentDidUpdate( prevProps );
    expect( props.getNavigationData ).toHaveBeenCalled( );
    expect( instance.setFocusToHome ).toHaveBeenCalled( );
  } );

  it( 'should request the navigation data if we have an active session and if isSignedIn is false,set focus on SignIn link', () => {
    props.isSignedIn = false;
    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props } />
      </Provider>
    );
    instance = component.find( 'LeftNav' ).instance();
    instance.setFocusToSignIn =jest.fn();
    instance.componentDidUpdate( prevProps );
    expect( props.getNavigationData ).toHaveBeenCalled( );
    expect( instance.setFocusToSignIn ).toHaveBeenCalled( );
  } );

  it( 'should call componentDidUpdate to set navHeight', () => {
    props.activeLevel = '0|3';
    props.setMobileLeftNavDimensions =jest.fn();
    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props } />
      </Provider>
    );
    let appElement = document.createElement( 'div' );
    appElement.className='LeftNav__animation__container--visible';
    document.body.appendChild( appElement );
    let activeNavContent =document.querySelectorAll( '.LeftNav__animation__container--visible' );
    instance = component.find( 'LeftNav' ).instance();
    expect( instance.state.navHeight ).toEqual( 'auto' );
    instance.componentDidUpdate( prevProps );
    expect( activeNavContent.length ).toBeGreaterThan( 0 );
    expect( instance.state.navHeight ).toEqual( '768px' );
  } );

  it( 'should call the componentDidMount', () => {
    props.mobileNavContent = {};
    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props } />
      </Provider>
    );
    instance = component.find( 'LeftNav' ).instance();
    instance.componentDidMount();
    expect( props.getNavigationData ).toHaveBeenCalled( );
  } );

  it( 'should call the setFocusToHome method', () => {
    props.mobileNavContent = {};
    component = mountWithIntl(
      <Provider store={ store } >
        <LeftNav { ...props } />
      </Provider>
    );

    let appElement = document.createElement( 'div' );
    appElement.id='home_MainNavBtn';
    document.body.appendChild( appElement );
    document.getElementById( 'home_MainNavBtn' ).focus =jest.fn();
    instance = component.find( 'LeftNav' ).instance();
    instance.setFocusToHome();
    expect( document.getElementById( 'home_MainNavBtn' ).focus ).toHaveBeenCalled( );

  } );
} );
