/**
 * MiniCart
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import MobileBag from 'hf/components/MobileBag/MobileBag';

import {
  actions as miniCartActions
} from 'hf/actions/MiniCart/MiniCart.actions';

const propTypes = {
  label: PropTypes.string.isRequired,
  url: PropTypes.string.isRequired,
  quantity: PropTypes.number
}

/**
 * Class
 * @extends React.Component
 */
export class MiniCart extends Component{

  /**
   * Renders the MiniCart component
   */
  render(){
    return (
      <div className='MiniCart'>
        <MobileBag { ...this.props } />
      </div>
    );
  }
}

MiniCart.propTypes = propTypes;

export const mapStateToProps = ( state ) => {
  return { ...state.minicart }
}

export const mapDispatchToProps = ( dispatch ) => {
  return {
    addToCart: () => {
      dispatch( miniCartActions.addToCart() );
    },
    openCart: () => {
      dispatch( miniCartActions.openCart() );
    },
    updateCart: () => {
      dispatch( miniCartActions.updateCart() );
    },
    removeFromCart: () => {
      dispatch( miniCartActions.removeFromCart() );
    },
    setGiftMessage: ( text ) => {
      dispatch( miniCartActions.setGiftMessage( text ) );
    },
    setGiftBoxToggleStatus: ( status ) => {
      dispatch( miniCartActions.setGiftBoxToggleStatus( status ) );
    },
    setChkoutBtnStatus: ( status ) => {
      dispatch( miniCartActions.setChkoutBtnStatus( status ) );
    },
    setShowBagSummaryStatus: ( status ) => {
      dispatch( miniCartActions.setShowBagSummaryStatus( status ) );
    }
  }
}

// this is to mock the data for test cases
export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( MiniCart ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );
