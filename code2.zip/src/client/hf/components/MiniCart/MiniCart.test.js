import React from 'react';
import ReactDOM from 'react-dom';
import MiniCart, {
  mapStateToProps,
  mapDispatchToProps
} from './MiniCart';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import {
  actions as miniCartActions
} from 'hf/actions/MiniCart/MiniCart.actions';

let store = configureStore( {}, CONFIG );
let props = {
  src: 'tmp',
  alt: 'tmp',
  label: 'tmp',
  url:'tmp'
}


describe( '<MiniCart />', () => {
  it( 'renders without crashing', () => {
    let component = mountWithIntl(
      <Provider store={ store }>
        <MiniCart { ...props } />
      </Provider>
    );
  } );
  const dispatch = jest.fn();
  beforeEach( ()=> {
    dispatch.mockClear();
  } )

  const mdp  = mapDispatchToProps( dispatch );

  it( 'addToCart should dispatch the proper action', () => {
    const event = mdp.addToCart( );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.addToCart( )
    );
  } );

  it( 'openCart should dispatch the proper action', () => {
    const event = mdp.openCart( );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.openCart( )
    );
  } );

  it( 'updateCart should dispatch the proper action', () => {
    const event = mdp.updateCart( );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.updateCart( )
    );
  } );

  it( 'removeFromCart should dispatch the proper action', () => {
    const event = mdp.removeFromCart( );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.removeFromCart( )
    );
  } );

  it( 'setGiftMessage should dispatch the proper action', () => {
    const text = 'test';
    const event = mdp.setGiftMessage( text );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setGiftMessage( text )
    );
  } );

  it( 'setGiftBoxToggleStatus should dispatch the proper action', () => {
    const status = true;
    const event = mdp.setGiftBoxToggleStatus( status );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setGiftBoxToggleStatus( status )
    );
  } );

  it( 'setChkoutBtnStatus should dispatch the proper action', () => {
    const status = true;
    const event = mdp.setChkoutBtnStatus( status );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setChkoutBtnStatus( status )
    );
  } );

  it( 'setShowBagSummaryStatus should dispatch the proper action', () => {
    const status = true;
    const event = mdp.setShowBagSummaryStatus( status );
    expect( dispatch ).toHaveBeenCalledWith(
      miniCartActions.setShowBagSummaryStatus( status )
    );
  } );
} );
