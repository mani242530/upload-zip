/**
 * MobileBag
 */

import React from 'react';
import PropTypes from 'prop-types';
import './MobileBag.css';

import MainNavBtn from 'hf/components/Headers/mobile/MainNavBtn/MainNavBtn';
import classNames from 'classnames';

import BagSVG from 'shared/components/Icons/bag';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './MobileBag.messages';

const propTypes = {
  label: PropTypes.string.isRequired,
  url: PropTypes.string.isRequired,
  quantity: PropTypes.number
}

export const renderBagQuantity = ( quantity, props ) => {

  if( quantity > 0 ){
    return (
      <div className='MobileBag__Quantity'>
        <span className='MobileBag__Quantity--text'>
          { props.quantity }
        </span>
      </div>
    )
  }
}

/**
 * Class
 * @extends React.Component
 */
const MobileBag = ( props ) => {



  const {
    label,
    url,
    quantity
  } = props;
  return (
    <div
      className={
        classNames( {
          'MobileBag': true,
          'MobileBag__QuanityWrap': quantity > 0
        } )
      }
    >
      <MainNavBtn
        dataNavDescription='h - cart'
        Svg={ BagSVG }
        label={ label }
        url={ url }
        ariaLabel={ formatMessage( messages.itemsInCart, { quantity } ) }
      >
        { renderBagQuantity( quantity, props ) }
      </MainNavBtn>

    </div>
  );

}

MobileBag.propTypes = propTypes;

export default MobileBag;
