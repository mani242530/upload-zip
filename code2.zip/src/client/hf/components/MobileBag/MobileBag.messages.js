
/*
 * HamburgerBtn Messages
 *
 * This contains all the text for the HamburgerBtn component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  itemsInCart : {
    id: 'i18n.MobileHeader.menu',
    defaultMessage: 'Cart - {quantity, number} {quantity, plural, one {item} other {items} } - shows more content'
  }
} );
