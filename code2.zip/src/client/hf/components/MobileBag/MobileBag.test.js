import React from 'react';
import ReactDOM from 'react-dom';
import MobileBag from './MobileBag';
import messages from './MobileBag.messages';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import _ from 'lodash';

describe( '<MobileBag />', () => {
  let component;

  let props = {
    src: 'test',
    alt: 'test',
    label: 'test',
    url: 'test',
    quantity: 0
  }

  it( 'renders without crashing', () => {
    component = mountWithIntl( <MobileBag { ...props }/> );
    expect( component.find( 'MobileBag' ).length ).toBe( 1 );
  } );

  it( 'should provide the proper aria label string', () => {
    component = mountWithIntl( <MobileBag { ...props }/> );

    expect( component.find( 'MainNavBtn' ).at( 0 ).props().ariaLabel ).toBe( 'Cart - 0 items - shows more content' );
  } );

  describe( 'Quantity', () => {

    it( 'should not render the quantity if there aren\'t any items in the cart', () => {
      component = mountWithIntl( <MobileBag { ...props }/> );
      expect( component.find( '.MobileBag__Quantity' ).length ).toBe( 0 )
    } );

    it( 'should  render the quantity if there are items in the cart', () => {
      let props = {
        src: 'test',
        alt: 'test',
        label: 'test',
        url: 'test',
        quantity: 1
      }
      component = mountWithIntl( <MobileBag { ...props }/> );
      expect( component.find( 'MainNavBtn' ).find( '.MobileBag__Quantity' ).length ).toBe( 1 )
    } );
  } )
} );
