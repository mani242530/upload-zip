import React from 'react';
import LeftNav, {
  mapStateToProps,
  mapDispatchToProps
} from './MobileLeftNav';
import { shallow } from 'enzyme';
import {
  actions as mobileLeftNavActions
} from 'hf/actions/MobileLeftNav/MobileLeftNav.actions'
import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';
import {
  registerServiceName,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';
import {
  actions as userActions
} from 'shared/actions/User/User.actions';
import _ from 'lodash';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';

describe( 'MobileLeftNav state methods', () => {

  it( 'mapStateToProps should return the \'mobileLeftNav\' state', () => {

    const store = configureStore( {}, CONFIG );
    const props = {
      mobileLeftNav: jest.fn(),
      global: jest.fn(),
      user: jest.fn(),
      header: jest.fn(),
      session: jest.fn()
    }

    const component = mountWithIntl(
      <Provider store={ store }>
        <LeftNav { ...props } />
      </Provider>
    );
  } );

  const dispatch = jest.fn();
  beforeEach( ()=> {
    dispatch.mockClear();
  } )

  const mdp  = mapDispatchToProps( dispatch );

  it( 'getNavigationData should dispatch the proper action', () => {
    registerServiceName( 'navigation' );
    const event = mdp.getNavigationData( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'navigation', 'requested' )()
    );
  } );

  it( 'setMobileLeftNavDimensions should dispatch the proper action', () => {
    const event = mdp.setMobileLeftNavDimensions( 6, 10 );
    expect( dispatch ).toHaveBeenCalledWith(
      mobileLeftNavActions.setMobileLeftNavDimensions( 6, 10 )
    );
  } );

  it( 'setActiveLevel should dispatch the proper action', () => {
    const event = mdp.setActiveLevel( 1, 2 );
    expect( dispatch ).toHaveBeenCalledWith(
      mobileLeftNavActions.setActiveLevel( 1, 2 )
    );
  } );

  it( 'toggleLeftNav should dispatch the proper action', () => {
    const event = mdp.toggleLeftNav( false );
    expect( dispatch ).toHaveBeenCalledWith(
      mobileLeftNavActions.toggleLeftNav( false )
    );
    expect( dispatch ).toHaveBeenCalledWith(
      globalActions.enableDisableDocumentScroll( false )
    );
  } );

  it( 'openRewards should dispatch the proper action', () => {
    const event = mdp.openRewards( );
    expect( dispatch ).toHaveBeenCalledWith(
      mobileLeftNavActions.openRewards( )
    );
  } );

  it( 'enableDisableDocumentScroll should dispatch the proper action', () => {
    const event = mdp.enableDisableDocumentScroll( true );
    expect( dispatch ).toHaveBeenCalledWith(
      globalActions.enableDisableDocumentScroll( true )
    );
  } );

  it( 'registerRemoveIOSRubberEffect should dispatch the proper action', () => {
    const elem= '<div></div>';
    const event = mdp.registerRemoveIOSRubberEffect( elem );
    expect( dispatch ).toHaveBeenCalledWith(
      globalActions.registerRemoveIOSRubberEffect( elem )
    );
  } );

  it( 'logoutUser should dispatch the proper action', () => {
    const event = mdp.logoutUser( );
    expect( dispatch ).toHaveBeenCalledWith(
      userActions.logoutUser( )
    );
  } );

  it( 'broadcastMessage should dispatch the proper action', () => {
    const event = mdp.broadcastMessage( );
    expect( dispatch ).toHaveBeenCalledWith(
      globalActions.setBroadcastMessage( )
    );
  } );
} );
