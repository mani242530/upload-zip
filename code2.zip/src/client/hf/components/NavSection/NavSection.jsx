/**
 * NavSection
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import NavSectionHeader from 'hf/components/NavSectionHeader/NavSectionHeader';
import NavSectionLinks from 'hf/components/NavSectionLinks/NavSectionLinks';
import './NavSection.css';
import Button from 'shared/components/Button/Button';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './NavSection.messages';


const propTypes = {
  parentIndex: PropTypes.number,
  level: PropTypes.array,
  setActiveLevel: PropTypes.func.isRequired,
  resetNavScrollPosition: PropTypes.func.isRequired
}


/**
 * Class
 * @extends React.Component
 */
class NavSection extends Component{

  constructor( props ){
    super();
    this.handleBackClick = this.handleBackClick.bind( this );
  }

  handleBackClick(){
    this.props.setActiveLevel( this.props.activeLevel.slice( 0, -1 ) );
    this.props.resetNavScrollPosition();
  }

  render(){

    return (
      <div
        className='NavSection'
      >
        <div className='NavSection__container' >
          <NavSectionHeader
            sectionTitle={ this.props.sectionHeader }
            url={ this.props.sectionHeaderUrl }
            dataNavDescription={ this.props.dataNavDescription }
            activeLevel={ this.props.activeLevel }
            level={ this.props.level }
            broadcastMessage={ this.props.broadcastMessage }
          />
          <NavSectionLinks
            { ...this.props }
          />
          {
            ( ()=>{
              if( this.props.activeLevel.length !== 0 ){
                return (
                  // Back button link as sr-only added for accessibility
                  <div className='NavSection__hiddenBackButton' >
                    <Button
                      inputTag='button'
                      className='sr-only'
                      role='link' // added role as link because iOS devices are not calling an click event if the role is not set to link
                      clickEventHandler={
                        ( e ) => {
                          e.preventDefault();
                          this.handleBackClick()
                        }
                      }
                    >
                      { formatMessage( messages.previousMenu ) }
                    </Button>
                  </div>
                );
              }
            } )()
          }
        </div>
      </div>
    );
  }
}

NavSection.propTypes = propTypes;

export default NavSection;
