/*
 * NavSection Messages
 *
 * This contains all the text for the NavSection component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  previousMenu: {
    id: 'i18n.NavSection.back',
    defaultMessage: 'previous menu'
  }

} );
