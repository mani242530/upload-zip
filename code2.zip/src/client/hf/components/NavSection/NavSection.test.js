import React from 'react';
import ReactDOM from 'react-dom';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { IntlProvider } from 'react-intl';
import _ from 'lodash';
import NavSection from './NavSection';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import Button from 'shared/components/Button/Button';


let store = configureStore( {}, CONFIG );
let props = {
  setActiveLevel: jest.fn(),
  resetNavScrollPositiona: jest.fn()

}


const intlProvider = new IntlProvider( { locale: 'en' }, {} );
const { intl } = intlProvider.getChildContext();

describe( '<NavSection />', () => {
  let subCategories= [
    {
      'navDisplayContent': 'Home',
      'navTargetLink': '/',
      'navElementType': 'MobileUtilityBar'
    },
    {
      'navDisplayContent': 'Favorites',
      'navTargetLink': '/ulta/myaccount/template.jsp?page=favorites',
      'navElementType': 'MobileUtilityBar'
    },
    {
      'navDisplayContent': 'MyAccount',
      'navTargetLink': '/ulta/myaccount/template.jsp?page=profile',
      'navElementType': 'MobileUtilityBar'
    },
    {
      'navDisplayContent': 'Rewards',
      'navTargetLink': '/ulta/myaccount/rewards.jsp',
      'navElementType': 'MobileUtilityBar'
    }
  ];

  const props= {
    level: [],
    parentIndex: 0,
    setActiveLevel: jest.fn(),
    resetNavScrollPosition: jest.fn(),
    activeLevel: '0|3',
    navWidth: 334,
    sectionHeader: 'Section header',
    sectionHeaderUrl: 'Section URL',
    categories: subCategories,
    showBackButton: false,
    dataNavDescription:'m - makeup:face'
  }

  const component = mountWithIntl(
    <Provider store={ store } >
      <NavSection
        { ...props }
      />
    </Provider>
  );


  it( 'renders NavSection component', () => {
    expect( _.isUndefined( component.find( 'NavSection' ) ) ).toBe( false );
  } );

  it( 'renders NavSectionHeader component if header text provided', () => {
    expect( component.find( 'NavSectionHeader' ).props().sectionTitle ).toEqual( props.sectionHeader );
    expect( component.find( 'NavSectionHeader' ).props().dataNavDescription ).toEqual( props.dataNavDescription );
  } );

  it( 'Render NavSectionLinks component if subCategories are provided', () => {
    expect( component.find( 'NavSectionLinks' ).props().categories ).toBeDefined();
  } );

  it( 'should have a sr only back button', ()=>{
    expect( component.find( Button ).length ).toBe( 1 );
    expect( component.find( Button ).props().className ).toBe( 'sr-only' );
  } );

  it( 'should have a sr only back button role as link', ()=>{
    expect( component.find( Button ).props().role ).toBe( 'link' );
  } );

  it( 'Invokes handleBackClick on click of Button', () => {
    const instance = component.find( 'NavSection' ).instance();
    component.find( Button ).simulate( 'click', instance.handleBackClick );
    expect( props.setActiveLevel ).toHaveBeenCalledWith( props.activeLevel.slice( 0, -1 ) );
    expect( props.resetNavScrollPosition ).toHaveBeenCalled( );
  } );

  // TODO write test to ensure that NavSectionHeader is not rendered if their are not categories present


} );
