/**
 * NavSectionHeader
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './NavSectionHeader.css';
import Anchor from 'shared/components/Anchor/Anchor';
import { isEqual, isEmpty } from 'lodash';

const propTypes = {
  sectionTitle: PropTypes.string.isRequired,
  dataNavDescription: PropTypes.string,
  url: PropTypes.string,
  target: PropTypes.string,
  activeLevel: PropTypes.array, // added below three props for screen reader to read out the NavSection Header if the user navigates back form a sub nav section.
  level: PropTypes.array,
  broadcastMessage: PropTypes.func

}

const defaultProps = {
  url: '',
  target: ''
}

/**
 * Class
 * @extends React.Component
 */
class NavSectionHeader extends Component{

  constructor( props ){
    super();
    this.focusOnHeader = this.focusOnHeader.bind( this );
  }
  /**
   * Renders the NavSectionHeader component
   */

  componentDidUpdate( ){
    this.focusOnHeader( );
  }

  focusOnHeader( ){
    const {
      level,
      activeLevel
    } = this.props;
    // we are using this function to focus on the navsection header if we are navigate back from the sub nav section in mobile left nav.
    if( isEqual( activeLevel, level ) && !isEmpty( level ) ){
      setTimeout( ()=>{
        this.navHeaderRef.focus();
      }, 700 );
    }
  }

  render(){

    const {
      sectionTitle,
      dataNavDescription,
      subCategories
    } = this.props;

    return (
      <div className='NavSectionHeader'>
        { this.props.url &&
          <Anchor url={ this.props.url }
            dataNavDescription={ dataNavDescription }
            ref={ ( refId ) => {
              this.navHeaderRef = refId;
            } }
            tabIndex='-1'
          >
            { sectionTitle }
          </Anchor>
        }

        { !this.props.url &&
          <div
            ref={ ( refId ) => {
              this.navHeaderRef = refId;
            } }
            tabIndex='-1'
          >
            { sectionTitle }
          </div>
        }
      </div>

    );
  }
}

NavSectionHeader.propTypes = propTypes;
NavSectionHeader.defaultProps = defaultProps;

export default NavSectionHeader;
