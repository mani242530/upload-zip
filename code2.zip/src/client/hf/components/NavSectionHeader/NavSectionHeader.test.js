import React from 'react';
import ReactDOM from 'react-dom';
import { shallow } from 'enzyme';
import { shallowToJson } from 'enzyme-to-json';
import NavSectionHeader from './NavSectionHeader';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { intlProvider } from 'react-intl';
import PropTypes from 'prop-types';
import Anchor from 'shared/components/Anchor/Anchor';

describe( '<NavSectionHeader />', () => {
  let text = 'Header Title';
  let props ={
    activeLevel: ['1|0', '1|2'],
    level: ['1|0', '1|2'],
    broadcastMessage: jest.fn(),
    dataNavDescription:'m - face',
    url:'test'
  }
  let component = shallow(
    <NavSectionHeader
      sectionTitle={ text }

    /> );

  it( 'renders without crashing', () => {
    const div = document.createElement( 'div' );
    ReactDOM.render( <NavSectionHeader sectionTitle={ text } />, div );
  } );



  it( 'should display the appropriate section title when passed a String', () => {
    let titleText = component.text();
    expect( titleText ).toEqual( text );
  } );

  it( 'should read out header when the active level and level are equal', () => {
    let component = mountWithIntl( <NavSectionHeader { ...props } />
    );
    let target = component.find( 'NavSectionHeader' ).instance();
    target.focusOnHeader = jest.fn();
    target.componentDidUpdate();
    expect( target.focusOnHeader ).toBeCalled();
  } );

  it( 'should render the Anchor component with dataNavDescription if props have url', () => {
    let component = mountWithIntl( <NavSectionHeader { ...props } />
    );
    expect( component.find( Anchor ).length ).toBe( 1 );
    expect( component.find( Anchor ).props().dataNavDescription ).toBe( props.dataNavDescription );
  } );

  it( 'should set focus on NavSectionHeader as soon as focusOnHeader method is invoked', () => {
    jest.useFakeTimers();
    let component = mountWithIntl( <NavSectionHeader { ...props } />
    );
    let target = component.find( 'NavSectionHeader' ).instance();
    target.focusOnHeader();
    target.navHeaderRef.focus = jest.fn();
    jest.runAllTimers();
    expect( target.navHeaderRef.focus ).toBeCalled() ;
  } );

  it( 'should not call set the focus if the level and activeLevel values are not equal', () => {
    jest.useFakeTimers();
    props.activeLevel=['1|0'];
    props.level=['1|2'];
    let component = mountWithIntl( <NavSectionHeader { ...props } />
    );
    let target = component.find( 'NavSectionHeader' ).instance();
    target.focusOnHeader();
    target.navHeaderRef.focus = jest.fn();
    jest.runAllTimers();
    expect( target.navHeaderRef.focus ).not.toBeCalled() ;
  } );

} );

