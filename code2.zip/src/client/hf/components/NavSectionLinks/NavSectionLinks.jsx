/**
 * NavSectionLinks
 */

import React, { Component } from 'react';
import './NavSectionLinks.css';
import classNames from 'classnames';
import Anchor from 'shared/components/Anchor/Anchor';
import NavSection from 'hf/components/NavSection/NavSection';

import clone from 'lodash/clone';
import difference from 'lodash/difference';



const initialState = {
  showSubNav: false
}


/**
 * Class
 * @extends React.Component
 */
class NavSectionLinks extends Component{

  /**
   * Create a NavSectionLinks
   */
  constructor( props ){
    super( props );
    this.state = initialState;
    this.handleAnchorClick = this.handleAnchorClick.bind( this );
    this.checkIfSubLevelIsActive = this.checkIfSubLevelIsActive.bind( this );
  }

  checkIfSubLevelIsActive( level, nextIndex ){
    // first make sure that we are only looking at coparisons that are a or less
    // than the lenth of the new activeLevel
    if( level.length <= this.props.activeLevel.length ){
      // we only want to display the items in the list that are at or less than the level that the user has selected

      if( difference( level, this.props.activeLevel ).length === 0 ){
        return true;
      }
    }

    return false;
  }

  handleAnchorClick( level ){
    this.props.setActiveLevel( level )
    this.props.resetNavScrollPosition();
  }

  /**
   * Renders the NavSectionLinks component
   */

  render(){

    return (
      <div className='NavSectionLinks'>

        { ( () => {

          if( this.props.displayFeatured === 'true' && this.props.redirectURL && this.props.featuredLabel ){
            return (
              <div
                className='NavSection__Category NavSection__Featured'
              >
                <Anchor
                  url={ this.props.redirectURL }
                >
                  { this.props.featuredLabel }
                </Anchor>
              </div>
            )
          }

        } )() }

        {
          ( () => {

            return this.props.categories.map( ( category, index ) => {
              let levelArray = clone( this.props.level );
              levelArray.push( `${this.props.parentIndex}|${index}` );


              let omnitureAttribute = category.categoryLink ? category.categoryLink['data-nav-description'] : category['data-nav-description'];

              let navSectionProps = {
                level: levelArray,
                resetNavScrollPosition: this.props.resetNavScrollPosition,
                parentIndex: ( this.props.parentIndex + 1 ),
                setActiveLevel: this.props.setActiveLevel,
                activeLevel: this.props.activeLevel,
                activeSubLevel: this.props.activeSubLevel,
                navWidth: this.props.navWidth,
                dataNavDescription: omnitureAttribute,
                sectionHeader: category.navDisplayContent,
                sectionHeaderUrl: category.navTargetLink,
                categories: category.categories,
                bookApptLabel: category.bookApptLabel,
                bookApptLink: category.bookApptLink,
                displayBookAppt: category.displayBookAppt,
                displayFeatured: category.displayFeatured,
                featuredLabel: category.featuredLabel,
                redirectURL: category.redirectURL,
                toggleLeftNav: this.props.toggleLeftNav,
                fontColor: category.fontColor,
                broadcastMessage: this.props.broadcastMessage
              };

              let url = '#';
              if( category.navElementType !== 'Filler' ){

                if( category.categories && category.categories.length > 0 ){

                  if( category.categoryLink && category.categoryLink.navTargetLink ){
                    url = category.categoryLink.navTargetLink;
                  }

                  return (
                    <div
                      ref={ ( refId ) => {
                        this.navId=refId;
                      } }
                      className={
                        classNames(
                          'NavSection__Category NavSection__Category--parent', {
                            'NavSection__Category--orangePop': category.fontColor === 'nav-menu-style-melon',
                            'NavSection__Category--magenta': category.fontColor === 'mad-for-magenta-ada'
                          }
                        )
                      }
                      key={ index }
                    >
                      <Anchor
                        url={ url }
                        clickHandler={
                          ( e ) => {
                            e.preventDefault();
                            this.handleAnchorClick( levelArray, this.props.parentIndex + 1 );
                          }
                        }
                      >
                        { category.navDisplayContent }

                      </Anchor>
                      <div
                        className={
                          classNames(
                            'LeftNav__animation__container', {
                              'LeftNav__animation__container--visible': this.checkIfSubLevelIsActive( levelArray ),
                              'LeftNav__animation__container--hidden':  !this.checkIfSubLevelIsActive( levelArray )
                            }
                          )
                        }
                        style={
                          {
                            left: `${this.props.navWidth}px`
                          }
                        }
                      >
                        <NavSection { ...navSectionProps } />
                      </div>

                    </div>
                  )
                }
                else {

                  if( category.categoryLink && category.categoryLink.navTargetLink ){
                    url = category.categoryLink.navTargetLink
                  }
                  else if( category && category.navTargetLink ){
                    url = category.navTargetLink
                  }
                  else {
                    url = '#'
                  }

                  return (
                    <div
                      className={
                        classNames( 'NavSection__Category', {
                          'NavSection__Category--orangePop': category.fontColor === 'nav-menu-style-melon',
                          'NavSection__Category--magenta': category.fontColor === 'mad-for-magenta-ada'
                        } )
                      }
                      key={ index }
                    >
                      <Anchor
                        dataNavDescription={ omnitureAttribute }
                        url={ url }
                      >
                        { category.navDisplayContent }
                      </Anchor>
                    </div>
                  )
                }
              }
              else {
                // hard coding this as a line for now per the design
                // requirements of MHP 2017. Eventually we will need to make this conditional
                // based on the value of 'category.insertLine' (assuming the JSON attribute name doesn't change)
                return (
                  <div
                    className='NavSection__Filler'
                    key={ index }
                  ></div>
                )
              }
            } )
          } )()
        }

        { ( () => {

          if( this.props.displayBookAppt === 'true' && this.props.bookApptLink && this.props.bookApptLabel ){
            return (
              <div
                className={
                  classNames( 'NavSection__Category NavSection__BookAppt', {
                    'NavSection__Category--orangePop': this.props.fontColor === 'nav-menu-style-melon',
                    'NavSection__Category--magenta': this.props.fontColor === 'mad-for-magenta-ada'
                  } )
                }
              >
                <Anchor url={ this.props.bookApptLink } >
                  { this.props.bookApptLabel }
                </Anchor>
              </div>
            )
          }

        } )() }

      </div>
    )
  }
}


export default NavSectionLinks;

