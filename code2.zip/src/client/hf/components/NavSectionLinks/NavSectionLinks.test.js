import React from 'react';
import ReactDOM from 'react-dom';
import NavSectionLinks from './NavSectionLinks';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { shallow, mount } from 'enzyme';
import _ from 'lodash';
import { Provider } from 'react-redux';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';


let store = configureStore( {}, CONFIG );
let props = {
  tmp: 'tmp',
  getNavLinkId: jest.fn()
}

let subCategories = [
  {
    categories: [],
    categoryLink: {
      linkText: '',
      navTargetLink: 'http://uloc1-ulta1.ulta.com/global/nav/allbrands.jsp',
      showInNewPage: false
    },
    fontColor: 'nav-menu-style-melon',
    navDisplayContent: 'Brands',
    navElementType: 'rootCategory'
  },
  {
    insertBlank: false,
    insertLine: true,
    lineColor: 'BK',
    navDisplayContent: 'Filler',
    navElementType: 'Filler'
  },
  {
    categories: [],
    categoryLink: {
      linkText: '',
      navTargetLink: 'http://uloc1-ulta1.ulta.com/global/nav/allbrands.jsp',
      showInNewPage: false
    },
    fontColor: 'nav-menu-style-melon',
    navDisplayContent: 'Brands',
    navElementType: 'rootCategory'
  },
  {
    categories: [],
    categoryLink: {
      linkText: '',
      navTargetLink: 'http://uloc1-ulta1.ulta.com/global/nav/allbrands.jsp',
      showInNewPage: false
    },
    fontColor: 'nav-menu-style-melon',
    navDisplayContent: 'Brands',
    navElementType: 'rootCategory'
  }
];


describe( '<NavSectionLinks />', () => {
  let component;


  let props = {
    level: [],
    parentIndex: 0,
    setActiveLevel: jest.fn(),
    activeLevel: '0|0',
    navWidth: 33,
    sectionHeader: 'HEADER',
    sectionHeaderUrl: 'test.com',
    categories: subCategories,
    showBackButton: false,
    getNavLinkId: jest.fn()
  }

  component = mountWithIntl( <NavSectionLinks { ...props } /> );

  it( 'renders NavSectionLinks div', () => {
    expect( component.find( 'NavSectionLinks' ).length ).toBe( 1 );
  } );

  it( 'renders number of links in array', () => {
    expect( component.find( 'a' ).length ).toBe( 3 );
  } );

  it( 'NavSectionLinks requires categories prop', () => {
    expect( component.props().categories ).toBeDefined();
  } );

  let diff_props = {
    level: [],
    parentIndex: 0,
    setActiveLevel: jest.fn(),
    activeLevel: '0|0',
    navWidth: 33,
    sectionHeader: 'HEADER',
    sectionHeaderUrl: 'test.com',
    categories: [
      {
        categories: [],
        navTargetLink: '/go/for/pizza',
        fontColor: 'nav-menu-style-melon',
        navDisplayContent: 'Brands',
        navElementType: 'rootCategory'
      }
    ],
    showBackButton: false,
    getNavLinkId: jest.fn()
  }
  let diff_component = mountWithIntl( <NavSectionLinks { ...diff_props } /> );

  it( 'should render a link with the correct url if the category has a valid url in the \'navTargetLink\' attribute', () => {
    let re = /href="(.+)" target/
    expect( diff_component.find( '.NavSectionLinks' ).find( '.Anchor' ).html().match( re )[1] ).toBe( '//www.ulta.com/go/for/pizza' )
  } );

  let new_props = {
    level: [],
    parentIndex: 0,
    setActiveLevel: jest.fn(),
    activeLevel: '0|0',
    navWidth: 33,
    sectionHeader: 'HEADER',
    sectionHeaderUrl: 'test.com',
    categories: [
      {
        categories: [],
        categoryLink: {
          linkText: '',
          navTargetLink: '/go/for/tacos',
          showInNewPage: false
        },
        fontColor: 'nav-menu-style-melon',
        navDisplayContent: 'Brands',
        navElementType: 'rootCategory'
      }
    ],
    showBackButton: false,
    getNavLinkId: jest.fn()
  }
  let new_component = mountWithIntl( <NavSectionLinks { ...new_props } /> );

  it( 'should render a link with the correct url if the category has a valid url in the \'categoryLink.navTargetLink\' attribute', () => {
    let re = /href="(.+)" target/
    expect( new_component.find( '.NavSectionLinks' ).find( '.Anchor' ).html().match( re )[1] ).toBe( '//www.ulta.com/go/for/tacos' )
  } );

  it( 'should invoke resetNavScrollPosition on click of the anchor link', () => {

    let props3 = {
      level: [],
      parentIndex: 0,
      setActiveLevel: jest.fn(),
      resetNavScrollPosition: jest.fn(),
      activeLevel: '0|0',
      navWidth: 33,
      sectionHeader: 'HEADER',
      sectionHeaderUrl: 'test.com',
      categories: [
        {
          categories: [
            {
              categoryLink: {
                linkText: '',
                navTargetLink: '/go/for/',
                showInNewPage: false
              }
            }
          ],
          categoryLink: {
            linkText: '',
            navTargetLink: '/go/for/tacos',
            showInNewPage: false
          },
          fontColor: 'nav-menu-style-melon',
          navDisplayContent: 'Brands',
          navElementType: 'rootCategory'
        }
      ],
      showBackButton: false,
      getNavLinkId: jest.fn()
    }
    let component3 = mountWithIntl( <NavSectionLinks { ...props3 } /> );
    let re = /href="(.+)" target/
    let anchor = component3.find( '.NavSection__Category .NavSection__Category--parent .NavSection__Category--orangePop' ).find( 'Anchor' ).at( 0 );
    expect( anchor.html().match( re )[1] ).toBe( '//www.ulta.com/go/for/tacos' );
    anchor.simulate( 'click' );
    expect( props3.resetNavScrollPosition ).toBeCalled();
  } );
  let these_props = {
    level: [],
    parentIndex: 0,
    setActiveLevel: jest.fn(),
    activeLevel: '0|0',
    navWidth: 33,
    sectionHeader: 'HEADER',
    sectionHeaderUrl: 'test.com',
    categories: [
      {
        categories: [],
        fontColor: 'nav-menu-style-melon',
        navDisplayContent: 'Brands',
        navElementType: 'rootCategory'
      }
    ],
    showBackButton: false,
    getNavLinkId: jest.fn()
  }
  let a_new_component = mountWithIntl( <NavSectionLinks { ...these_props } /> );

  it( 'should render a link with the correct url if no url is present', () => {
    let re = /href="(.+)" target/
    expect( a_new_component.find( '.NavSectionLinks' ).find( '.Anchor' ).html().match( re )[1] ).toBe( '#' )
  } );

  it( 'should have data-nav-description for omniture for subcategory', () => {
    const props4 = {
      level: [],
      parentIndex: 0,
      setActiveLevel: jest.fn(),
      activeLevel: '0|0',
      navWidth: 33,
      'navDisplayContent':'SHOP',
      'navElementType':'SHOP',
      'categories':[
        {
          'navDisplayContent':'Makeup',
          'data-nav-description':'makeup:featured',
          'displayBookAppt':'true',
          'navElementType':'rootCategory',
          'featuredLabel':'Featured',
          'categories':[
            {
              'navDisplayContent':'Face',
              'navTargetLink':'https://www.ulta.com/makeup-face?N=26y3',
              'data-nav-description':'m - makeup:face',
              'navElementType':'subCategory',
              'categories':[
                {
                  'navDisplayContent':'Foundation',
                  'navTargetLink':'https://www.ulta.com/makeup-face-foundation?N=26y5',
                  'data-nav-description':'m - makeup:face:foundation',
                  'navElementType':'subCategory'
                }
              ]
            }
          ]
        }
      ],
      showBackButton: false,
      getNavLinkId: jest.fn()
    }
    const component4 = mountWithIntl( <NavSectionLinks { ...props4 } /> );
    expect( component4.find( '.NavSection .NavSection__container .NavSectionLinks .NavSection__Category' ).find( 'Anchor' ).at( 0 ).props( ).dataNavDescription ).toBeUndefined();
    expect( component4.find( '.NavSection .NavSection__container .NavSectionLinks .NavSection__Category' ).find( 'Anchor' ).at( 1 ).props( ).dataNavDescription ).toBe( 'm - makeup:face' );
    expect( component4.find( '.NavSection .NavSection__container .NavSectionLinks .NavSection__Category' ).find( 'Anchor' ).at( 2 ).props( ).dataNavDescription ).toBe( 'm - makeup:face:foundation' );
  } );

  it( 'should not have data-nav-description for omniture for rootCategory ', () => {
    const props4 = {
      level: [],
      parentIndex: 0,
      setActiveLevel: jest.fn(),
      activeLevel: '0|0',
      navWidth: 33,
      sectionHeader: 'HEADER',
      sectionHeaderUrl: 'test.com',
      categories: [
        {
          categories: [],
          fontColor: 'nav-menu-style-melon',
          navDisplayContent: 'Brands',
          'data-nav-description':'m - brands',
          navElementType: 'rootCategory'
        }
      ],
      showBackButton: false,
      getNavLinkId: jest.fn()
    }
    const component4 = mountWithIntl( <NavSectionLinks { ...props4 } /> );
    expect( component4.find( '.NavSection__Category' ).find( '.Anchor' ).props().dataNavDescription ).toBeUndefined();
  } );

  describe( 'Separator', () => {

    let props = {
      level: [],
      parentIndex: 0,
      setActiveLevel: jest.fn(),
      activeLevel: '0|0',
      navWidth: 33,
      sectionHeader: 'HEADER',
      sectionHeaderUrl: 'test.com',
      categories: subCategories,
      showBackButton: false,
      getNavLinkId: jest.fn()
    }


    let component = shallow( <NavSectionLinks { ...props } /> );
    const element = component.at( 0 ).props().children


    it( 'should render a Separator if \'Filler\' is passed as navElementType ', () => {
      expect( element[1][1].props.className ).toBe( 'NavSection__Filler' );

    } );

    it( 'should not render a Separator if \'Filler\' is not passed as navElementType', () => {
      expect( element[1][0].props.className ).toMatch( /NavSection__Category/ );
      expect( element[1][2].props.className ).toMatch( /NavSection__Category/ );
      expect( element[1][3].props.className ).toMatch( /NavSection__Category/ );
    } );

  } );

} );
