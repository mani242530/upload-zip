/**
 * NewsLetterSignup
 */

import React, { Component } from 'react';
import ToggleButton from 'shared/components/ToggleButton/ToggleButton';
import './NewsLetterSignup.css';
import { Field, reduxForm } from 'redux-form';
import { connect } from 'react-redux';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './NewsLetterSignup.messages';
import ResponseMessages from 'shared/components/ResponseMessages/ResponseMessages';
import Divider from 'shared/components/Divider/Divider';
import PropTypes from 'prop-types';

/**
 * Class
 * @extends React.Component
 */
const propTypes={
  newsLetterSignupStatus: PropTypes.func,
  signUpLetterFlag: PropTypes.bool
}
/**
 * Class
 * @extends React.Component
 */
class NewsLetterSignup extends Component{

  /**
   * Create a NewsLetterSignup
   */
  constructor( props ){
    super( props );
    this.clickEventFunction = this.clickEventFunction.bind( this );
  }

  clickEventFunction( value ){
    this.props.newsLetterSignupStatus( value );
  }


  /**
   * Renders the NewsLetterSignup component
   */
  render(){


    return (
      <div>
        <div className='NewsLetterSignup'>
          <div className='NewsLetterSignup__text'>
            <div className='NewsLetterSignup__header'>
              { formatMessage( messages.newsLetterTextHeader ) }
            </div>
            <div className='NewsLetterSignup__content'>
              { formatMessage( messages.newsLetterTextContent ) }
            </div>
          </div>
          <div className='NewsLetterSignup__toggleButton'>
            <label htmlFor='newsLetterSignupToggleButtonId' className='sr-only'>{ formatMessage( messages.newsLetterTextHeader ) }</label>
            { ( ()=>{
              return (
                <div>
                  <form>
                    <ToggleButton
                      id='newsLetterSignupToggleButtonId'
                      name='newsLetter'
                      onClick={ this.clickEventFunction }
                      isChecked={ this.props.signUpLetterFlag }
                    />
                  </form>
                </div>
              )
            } )() }
          </div>
        </div>
        <div className='NewsLetterSignup__divider'>
          <Divider dividerType={ 'gray' }/>
        </div>
      </div>
    );
  }
}

NewsLetterSignup.propTypes = propTypes;

const mapStateToProps = ( state ) => {
  return {
    formData: state.form
  };
}

export default
reduxForm( {
  form: 'newsLetterSignup'
} )( connect( mapStateToProps )( NewsLetterSignup ) );
