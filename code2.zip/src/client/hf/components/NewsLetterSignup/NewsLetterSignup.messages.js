/*
 * NewsLetterSignup Messages
 *
 * This contains all the text for the NewsLetterSignup component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.NewsLetterSignup.header',
    defaultMessage: 'This is the NewsLetterSignup component !'
  },
  newsLetterTextHeader: {
    id: 'i18n.NewsLetterSignup.newsLetterTextHeader',
    defaultMessage: 'Sign up for emails now'
  },
  newsLetterTextContent: {
    id: 'i18n.NewsLetterSignup.newsLetterTextContent',
    defaultMessage: 'Be the first to know about our latest sales, new arrivals & special offers'
  }
} );
