import React from 'react';
import ReactDOM from 'react-dom';
import NewsLetterSignup from './NewsLetterSignup';
import configureStore from 'ccr/ccr.store';
import CONFIG from 'ccr/ccr.config';
import messages from './NewsLetterSignup.messages';
import { Provider } from 'react-redux';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';

import { IntlProvider } from 'react-intl';

describe( '<NewsLetterSignup />', () => {
  let component;
  let props ={
    newsLetterSignupStatus: jest.fn(),
    signUpLetterFlag:false
  }
  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store } >
      <NewsLetterSignup { ...props } />
    </Provider>
  );
  it( 'renders without crashing', () => {

    expect( component.find( 'NewsLetterSignup' ).length ).toBe( 1 );
  } );
  it( 'should contain newsLetterSignUp header message div', () => {
    expect( component.find( '.NewsLetterSignup__header' ).length ).toBe( 1 );
  } );

  it( 'should contain newsLetterSignUp header text div', () => {
    expect( component.find( '.NewsLetterSignup__content' ).length ).toBe( 1 );
  } );

  it( 'should contain toggleButton div', () => {
    expect( component.find( '.NewsLetterSignup__toggleButton' ).length ).toBe( 1 );
  } );

  it( 'should contain newsLetterSignUp header message', () => {
    expect( component.find( '.NewsLetterSignup__header' ).text() ).toBe( messages.newsLetterTextHeader.defaultMessage );
  } );

  it( 'should contain newsLetterSignUp header text message', () => {
    expect( component.find( '.NewsLetterSignup__content' ).text() ).toBe( messages.newsLetterTextContent.defaultMessage );
  } );

  it( 'should contain ToggleButton component', () => {
    expect( component.find( 'ToggleButton' ).length ).toBe( 1 );
  } );

  it( 'The id of the toggle button and the htmlFor of the label element should match', () => {
    expect( component.find( '.NewsLetterSignup__toggleButton' ).children( 'label' ).text() ).toBe( messages.newsLetterTextHeader.defaultMessage );
    expect( component.find( 'ToggleButton' ).props()['id'] ).toBe( component.find( '.NewsLetterSignup__toggleButton' ).children( 'label' ).props()['htmlFor'] );
  } );

} );
