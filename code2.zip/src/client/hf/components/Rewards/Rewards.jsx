/**
 * Rewards
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './Rewards.css';
import rewardsCC from 'static/rewardsCC_footer.png';
import Button from 'shared/components/Button/Button';
import { formatMessage } from 'shared/components/Global/Global';
import messages from './Rewards.messages';
import Image from 'shared/components/Image/Image';
import Anchor from 'shared/components/Anchor/Anchor';


const propTypes = {
  signedIn:PropTypes.bool,
  rewardsMember: PropTypes.bool,
  rewardPointTotal: PropTypes.number,
  memberStatus: PropTypes.string
}

/**
 * Class
 * @extends React.Component
 */
class Rewards extends Component{

  /**
   * Renders the Rewards component
   */
  render(){

    const imageURL= '//static.ultainc.com/static/images/footer_cc.png';
    return (
      <div className='Rewards'>
        <div className='RewardsPanel__rewardsProgramPanel'>
          <div className='RewardsPanel__rewardsPanelHeader'>
            { ( () => {
              let rewardsLH = formatMessage( messages.rewardsLeftHeader );
              let splitRewards = rewardsLH.split( '®' );
              return (
                <h3>
                  { `${splitRewards[0]}` }
                  <sup>®</sup>
                  { `${splitRewards[1]}` }
                </h3>
              )
            } )() }
          </div>
          { ( () => {
            if( this.props.signedIn && this.props.rewardsMember ){
              return (
                <div>
                  <div
                    className='RewardsPanel__rewardsProgramPanel__rewardDetails'
                  >
                    { formatMessage( messages.MemberStatus, { Status: this.props.memberStatus } ) }
                  </div>
                  <div
                    className='RewardsPanel__rewardsProgramPanel__rewardDetails'
                  >
                    {
                      formatMessage( messages.MemberPoints, {
                        Points: ( this.props.rewardPointTotal === 0 )
                          ? '0'
                          : this.props.rewardPointTotal
                      } )
                    }
                  </div>
                  <Button
                    className='RewardsPanle__rewardsProgramPanel__button RewardsPanel__rewardsProgramPanel--rewardsButton'
                    inputTag='a'
                    btnOutLine={ true }
                    btnOption='default'
                    btnURL='/ulta/myaccount/rewards.jsp'
                  >
                    { 'MY REWARDS' }
                  </Button>


                  <Button
                    className='RewardsPanle__rewardsProgramPanel__button RewardsPanel__rewardsProgramPanel--rewardsButton'
                    inputTag='a'
                    btnOutLine={ true }
                    btnOption='default'
                    btnURL='/ulta/myaccount/rewards.jsp#bonus_offers'
                  >
                    { 'MY BONUS OFFERS' }
                  </Button>
                </div>
              )
            }
            else {
              return (
                <div>
                  <div className='RewardsPanel__rewardsProgramPanel--rewardsMessage'>
                    <p>
                      <span>{ formatMessage( messages.findOutMessage ) }</span> <br />
                      <span>{ formatMessage( messages.firstLeftMessage ) }</span>
                    </p>
                  </div>

                  <Button
                    className='RewardsPanel__rewardsProgramPanel--rewardsButton'
                    inputTag='a'
                    btnOutLine={ true }
                    btnOption='default'
                    btnURL='/ulta/myaccount/learnmore_template.jsp?learnMoreAccordion=true&page=benefits'
                  >
                    { formatMessage( messages.firstLeftButton ) }
                  </Button>

                  <div className='RewardsPanel__rewardsProgramPanel--rewardsMessage'>
                    <p>
                      <span>{ formatMessage( messages.joinNowMessage ) }</span><br />
                      <span>{ formatMessage( messages.secondLeftMessage ) }</span>
                    </p>
                  </div>

                  <Button
                    className='RewardsPanel__rewardsProgramPanel--rewardsButton'
                    inputTag='a'
                    btnOutLine={ true }
                    btnOption='default'
                    btnURL='/ulta/myaccount/register.jsp'
                  >
                    { formatMessage( messages.secondLeftButton ) }
                  </Button>
                </div>
              )
            }
          } )() }

        </div>
        <div className='RewardsPanel__creditCardPanel'>
          <div className='RewardsPanel__rewardsPanelHeader'>
            { ( () => {
              let rewardsLH = formatMessage( messages.rewardsRightHeader );
              let splitRewards = rewardsLH.split( '®' );
              return (
                <h3>
                  { `${splitRewards[0]}` }
                  <sup>®</sup>
                  { `${splitRewards[1]}` }
                </h3>
              )
            } )() }
          </div>

          <Button
            className='RewardsPanel__creditCardPanel--rewardsButton'
            inputTag='a'
            btnOutLine={ true }
            btnOption='default'
            btnURL='/ulta/creditcards/landingpage.jsp'
          >
            { this.props.isCardHolder ? formatMessage( messages.learMore ) : formatMessage( messages.firstRightButton ) }
          </Button>


          <Button
            className='RewardsPanel__creditCardPanel--rewardsButton'
            inputTag='a'
            btnOutLine={ true }
            btnOption='default'
            btnURL='//comenity.net/ultamaterewardscredit'
          >
            { formatMessage( messages.secondRightButton ) }
          </Button>
          <Anchor
            url='/ulta/creditcards/landingpage.jsp'
          >
            <div className='RewardsPanel__creditCardPanel--rewardsImage'>
              <Image
                src={ imageURL }
                alt=''
                width={ 66 }
                height={ 42 }
              />
            </div>
            <div className='RewardsPanel__creditCardPanel--rewardsImageText'>
              { formatMessage( messages.firstRightMessage ) }
            </div>
          </Anchor>

        </div>
      </div>

    );
  }
}

Rewards.propTypes = propTypes;

export default Rewards;
