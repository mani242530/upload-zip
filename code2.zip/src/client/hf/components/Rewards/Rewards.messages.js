/*
 * Rewards Messages
 *
 * This contains all the text for the Rewards component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  rewardsLeftHeader: {
    id: 'i18n.Rewards.rewardsLeftHeader',
    defaultMessage: 'ULTAMATE REWARDS® PROGRAM'
  },
  findOutMessage: {
    id: 'i18n.Rewards.findOutMessage',
    defaultMessage: 'Find Out How'
  },
  firstLeftMessage: {
    id: 'i18n.Rewards.firstLeftMessage',
    defaultMessage: 'Beauty Loves You Back'
  },
  firstLeftButton:{
    id: 'i18n.Rewards.firstLeftButton',
    defaultMessage: 'Learn More'
  },
  joinNowMessage: {
    id: 'i18n.Rewards.joinNowMessage',
    defaultMessage: 'Join Now or'
  },
  MemberId: {
    id: 'i18n.Rewards.MemberId',
    defaultMessage: 'Member ID: {ID}'
  },
  MemberPoints: {
    id: 'i18n.Rewards.MemberPoints',
    defaultMessage: 'My Points: {Points}'
  },
  MemberStatus: {
    id: 'i18n.Rewards.MemberStatus',
    defaultMessage: 'My Status: {Status}'
  },
  secondLeftMessage: {
    id: 'i18n.Rewards.secondLeftMessage',
    defaultMessage: 'Manage your Membership'
  },
  secondLeftButton:{
    id: 'i18n.Rewards.secondLeftButton',
    defaultMessage: 'Create An Account'
  },
  rewardsRightHeader: {
    id: 'i18n.Rewards.rewardsRightHeader',
    defaultMessage: 'ULTAMATE REWARDS® CREDIT CARD'
  },
  firstRightButton:{
    id: 'i18n.Rewards.firstRightButton',
    defaultMessage: 'Learn More & Apply'
  },
  learMore:{
    id: 'i18n.Rewards.learMore',
    defaultMessage: 'Learn More'
  },
  secondRightButton:{
    id: 'i18n.Rewards.secondRightButton',
    defaultMessage: 'Manage My Card'
  },
  firstRightMessage:{
    id: 'i18n.Rewards.firstRightMessage',
    defaultMessage: 'Earn even more points plus 20% off your next purchase'
  },
  learnMoreUrl:{
    id: 'i18n.Rewards.learnMoreUrl',
    defaultMessage: 'https://www.ulta.com/ulta/myaccount/learnmore_template.jsp?learnMoreAccordion=true&page=benefits'
  },
  createAccountUrl:{
    id: 'i18n.Rewards.createAccountUrl',
    defaultMessage: 'https://www.ulta.com/ulta/myaccount/register.jsp'
  },
  learnMandPUrl:{
    id: 'i18n.Rewards.learnMandPUrl',
    defaultMessage: 'https://www.ulta.com/ulta/creditcards/landingpage.jsp'
  },
  manageMyCardUrl:{
    id: 'i18n.Rewards.manageMyCardUrl',
    defaultMessage: 'https://d.comenity.net/ultamaterewardscredit/'
  }


} );
