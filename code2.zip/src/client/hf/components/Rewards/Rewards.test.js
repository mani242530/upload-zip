import React from 'react';
import ReactDOM from 'react-dom';
import Rewards from './Rewards';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import messages from './Rewards.messages';
import { IntlProvider } from 'react-intl';

describe( '<Rewards />', () => {
  let component = mountWithIntl(
    <Rewards
      signedIn={ false }
      rewardsMember={ false }
    />
  );

  let component1 = mountWithIntl(
    <Rewards
      signedIn={ true }
      rewardsMember={ false }
    />
  );

  let component2 = mountWithIntl(
    <Rewards
      signedIn={ true }
      rewardsMember={ true }
      memberStatus='Platinum'
      rewardPointTotal='5000'
    />
  );

  let component3 = mountWithIntl(
    <Rewards
      signedIn={ true }
      rewardsMember={ true }
      memberStatus='Member'
      rewardPointTotal='0'
    />
  );

  it( 'renders without crashing', () => {
    expect( component.find( '.RewardsPanel__rewardsProgramPanel' ).length ).toBe( 1 );
  } );

  it( 'should have the proper react components as children', () => {
    expect( component.find( '.RewardsPanel__rewardsPanelHeader' ).find( 'h3' ).length ).toBe( 2 );
    expect( component.find( '.RewardsPanel__rewardsProgramPanel--rewardsMessage' ).find( 'p' ).length ).toBe( 2 );
    expect( component.find( '.RewardsPanel__rewardsProgramPanel' ).find( 'Button' ).length ).toBe( 2 );
    expect( component.find( '.RewardsPanel__creditCardPanel' ).find( 'Button' ).length ).toBe( 2 );
    expect( component.find( '.RewardsPanel__creditCardPanel' ).find( 'Anchor' ).length ).toBe( 1 );
  } );

  it( 'should render correct urls when user is not signed in', () => {
    expect( component.find( '.RewardsPanel__creditCardPanel--rewardsButton a' ).at( 0 ).props().href ).toBe( '//www.ulta.com/ulta/creditcards/landingpage.jsp' );
    expect( component.find( '.RewardsPanel__creditCardPanel--rewardsButton a' ).at( 1 ).props().href ).toBe( '//comenity.net/ultamaterewardscredit' );
    expect( component.find( '.RewardsPanel__rewardsProgramPanel--rewardsButton a' ).at( 0 ).props().href ).toBe( '//www.ulta.com/ulta/myaccount/learnmore_template.jsp?learnMoreAccordion=true&page=benefits' );
    expect( component.find( '.RewardsPanel__rewardsProgramPanel--rewardsButton a' ).at( 1 ).props().href ).toBe( '//www.ulta.com/ulta/myaccount/register.jsp' );
  } );

  it( 'Should contain labels as given on the navigation panel', () => {
    expect( component.find( '.RewardsPanel__rewardsProgramPanel .RewardsPanel__rewardsPanelHeader' ).text() ).toBe( 'ULTAMATE REWARDS® PROGRAM' );
    expect( component.find( '.RewardsPanel__creditCardPanel .RewardsPanel__rewardsPanelHeader' ).text() ).toBe( 'ULTAMATE REWARDS® CREDIT CARD' );
    expect( component.find( 'Anchor .RewardsPanel__creditCardPanel--rewardsImageText' ).text() ).toBe( 'Earn even more points plus 20% off your next purchase' );
  } );

  it( 'should have the proper react components as children', () => {
    expect( component1.find( '.RewardsPanel__rewardsPanelHeader' ).find( 'h3' ).length ).toBe( 2 );
    expect( component1.find( '.RewardsPanel__rewardsProgramPanel--rewardsMessage' ).find( 'p' ).length ).toBe( 2 );
    expect( component1.find( '.RewardsPanel__rewardsProgramPanel' ).find( 'Button' ).length ).toBe( 2 );
    expect( component1.find( '.RewardsPanel__creditCardPanel' ).find( 'Button' ).length ).toBe( 2 );
    expect( component1.find( '.RewardsPanel__creditCardPanel' ).find( 'Anchor' ).length ).toBe( 1 );
  } );

  it( 'shoud render correct urls when user is signedin and not rewards member', () => {
    expect( component1.find( '.RewardsPanel__creditCardPanel--rewardsButton a' ).at( 0 ).props().href ).toBe( '//www.ulta.com/ulta/creditcards/landingpage.jsp' );
    expect( component1.find( '.RewardsPanel__creditCardPanel--rewardsButton a' ).at( 1 ).props().href ).toBe( '//comenity.net/ultamaterewardscredit' );
    expect( component1.find( '.RewardsPanel__rewardsProgramPanel--rewardsButton a' ).at( 0 ).props().href ).toBe( '//www.ulta.com/ulta/myaccount/learnmore_template.jsp?learnMoreAccordion=true&page=benefits' );
    expect( component1.find( '.RewardsPanel__rewardsProgramPanel--rewardsButton a' ).at( 1 ).props().href ).toBe( '//www.ulta.com/ulta/myaccount/register.jsp' );
  } );

  it( 'Should contain labels as given on the navigation panel', () => {
    expect( component1.find( '.RewardsPanel__rewardsProgramPanel .RewardsPanel__rewardsPanelHeader' ).text() ).toBe( 'ULTAMATE REWARDS® PROGRAM' );
    expect( component1.find( '.RewardsPanel__creditCardPanel .RewardsPanel__rewardsPanelHeader' ).text() ).toBe( 'ULTAMATE REWARDS® CREDIT CARD' );
    expect( component1.find( 'Anchor .RewardsPanel__creditCardPanel--rewardsImageText' ).text() ).toBe( 'Earn even more points plus 20% off your next purchase' );
  } );

  it( 'should have the proper react components as children', () => {
    expect( component2.find( '.RewardsPanel__rewardsPanelHeader' ).find( 'h3' ).length ).toBe( 2 );
    expect( component2.find( '.RewardsPanel__rewardsProgramPanel__rewardDetails' ).length ).toBe( 2 );
    expect( component2.find( '.RewardsPanel__rewardsProgramPanel__rewardDetails' ).at( 0 ).text() ).toBe( messages.MemberStatus.defaultMessage.replace( '{Status}', 'Platinum' ) );
    expect( component2.find( '.RewardsPanel__rewardsProgramPanel__rewardDetails' ).at( 1 ).text() ).toBe( messages.MemberPoints.defaultMessage.replace( '{Points}', '5000' ) );
    expect( component2.find( '.RewardsPanel__rewardsProgramPanel' ).find( 'Button' ).length ).toBe( 2 );
    expect( component2.find( '.RewardsPanel__creditCardPanel' ).find( 'Button' ).length ).toBe( 2 );
    expect( component2.find( '.RewardsPanel__creditCardPanel' ).find( 'Anchor' ).length ).toBe( 1 );
  } );


  it( 'Should contain labels as given on the navigation panel', () => {
    expect( component2.find( '.RewardsPanel__rewardsProgramPanel .RewardsPanel__rewardsPanelHeader' ).text() ).toBe( 'ULTAMATE REWARDS® PROGRAM' );
    expect( component2.find( '.RewardsPanel__creditCardPanel .RewardsPanel__rewardsPanelHeader' ).text() ).toBe( 'ULTAMATE REWARDS® CREDIT CARD' );
    expect( component2.find( 'Anchor .RewardsPanel__creditCardPanel--rewardsImageText' ).text() ).toBe( 'Earn even more points plus 20% off your next purchase' );
  } );

  it( 'shoud render correct urls when user is signedin and user is rewards member', () => {
    expect( component2.find( '.RewardsPanel__creditCardPanel--rewardsButton a' ).at( 0 ).props().href ).toBe( '//www.ulta.com/ulta/creditcards/landingpage.jsp' );
    expect( component2.find( '.RewardsPanel__creditCardPanel--rewardsButton a' ).at( 1 ).props().href ).toBe( '//comenity.net/ultamaterewardscredit' );
    expect( component2.find( '.RewardsPanel__rewardsProgramPanel--rewardsButton a' ).at( 0 ).props().href ).toBe( '//www.ulta.com/ulta/myaccount/rewards.jsp' );
    expect( component2.find( '.RewardsPanel__rewardsProgramPanel--rewardsButton a' ).at( 1 ).props().href ).toBe( '//www.ulta.com/ulta/myaccount/rewards.jsp#bonus_offers' );
  } );

  it( 'shoud render reward point as 0 for a signed in user having 0 reward point ', () => {
    expect( component3.find( '.RewardsPanel__rewardsProgramPanel__rewardDetails' ).at( 0 ).text() ).toBe( messages.MemberStatus.defaultMessage.replace( '{Status}', 'Member' ) );
    expect( component3.find( '.RewardsPanel__rewardsProgramPanel__rewardDetails' ).at( 1 ).text() ).toBe( messages.MemberPoints.defaultMessage.replace( '{Points}', '0' ) );
  } );

} );
