/**
 * TypeAhead
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './TypeAhead.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './TypeAhead.messages';
import classNames from 'classnames';
import Image from 'shared/components/Image/Image';
import SearchSVG from 'shared/components/Icons/search';
import CloseSVG from 'shared/components/Icons/close';

import Autosuggest from 'react-autosuggest';
import IsolatedScroll from 'react-isolated-scroll';

import TypeAheadSuggestion from 'hf/components/TypeAheadSuggestion/TypeAheadSuggestion';
import Button from 'shared/components/Button/Button';
import isEqual from 'lodash/isEqual';
import isUndefined from 'lodash/isUndefined';

import {
  host,
  fullyQualifyLink
} from 'utils/Formatters/formatters';

const propTypes = {
  displayType: PropTypes.oneOf( ['desktop', 'mobile'] ),
  searchMode: PropTypes.string.isRequired,
  closeSearchMode: PropTypes.func.isRequired
}


/**
 * Class
 * @extends React.Component
 */
class TypeAhead extends Component{

  /**
   * Create a TypeAhead
   */
  constructor( props ){
    super( props );

    this.handleSearchSubmit = this.handleSearchSubmit.bind( this );
    this.handleClearBtnClick = this.handleClearBtnClick.bind( this );
    this.handleInputChange = this.handleInputChange.bind( this );
    this.renderInputComponent = this.renderInputComponent.bind( this );
    this.renderSuggestion = this.renderSuggestion.bind( this );
    this.renderSectionTitle = this.renderSectionTitle.bind( this );
    this.getSectionSuggestions = this.getSectionSuggestions.bind( this );
    this.shouldRenderSuggestions = this.shouldRenderSuggestions.bind( this );
    this.getSuggestionValue = this.getSuggestionValue.bind( this );
    this.setSearchResultsHeight = this.setSearchResultsHeight.bind( this );
    this.renderSuggestionsContainer = this.renderSuggestionsContainer.bind( this );
    this.suggestionsClearRequested = this.suggestionsClearRequested.bind( this );
    this.storeInputReference = this.storeInputReference.bind( this );
    this.handleInputBlur = this.handleInputBlur.bind( this );
    this.animateOn = this.animateOn.bind( this );
  }

  handleInputBlur(){
    this.input.blur();
  }

  elem = undefined;

  animateOn(){

    global.requestAnimationFrame( () => {
      this.elem.style.transition = 'opacity 390ms';
      this.elem.style.transitionDelay = '250ms';
      this.elem.style.opacity = 1;
    } );

    this.input.focus();
  }

  componentDidMount(){
    if( this.props.displayType === 'mobile' ){
      let resultsContainer = document.getElementById( 'TypeAheadSearch__results' );

      if( resultsContainer ){
        this.resultsContainer = resultsContainer;
        this.resultsContainer.addEventListener( 'scroll', this.handleInputBlur );
      }

      this.animateOn();

      this.props.enableDisableDocumentScroll( true );
      this.props.registerRemoveIOSRubberEffect( document.getElementById( 'TypeAheadSearch__results' ) );

      document.ontouchmove = ( e ) => {
        e.preventDefault();
      };
    }
  }

  componentDidUpdate( prevProps ){
    // Check isReadSuggestions flag before trigger a live data
    // get the typeahead search result count and trigger a message to screen reader
    if( this.props.isReadSuggestions && !isEqual( this.props.suggestions, prevProps.suggestions ) ){
      let totalResultCount = 0;
      this.props.suggestions.map( ( value, index ) => {
        totalResultCount += value.dimensionSearchValues.length
      } );
      // TRIGGER EVENT FOR LIVE DATA
      if( this.props.suggestions.length <= 0 ){
        this.props.broadcastMessage( formatMessage( messages.noResultsFound ) );
      }
      else {
        this.props.broadcastMessage( formatMessage( messages.resultsAvailable, { totalResultCount } ) );
      }
    }
  }

  componentWillUnMount(){
    if( this.resultsContainer ){
      this.resultsContainer.removeEventListener( 'scroll', this.handleInputBlur );
    }
  }

  storeInputReference = autosuggest => {
    if( autosuggest !== null ){
      this.input = autosuggest.input;
    }
  }


  setSearchResultsHeight(){
    let offset = document.getElementById( 'TypeAheadSearch__results' ).getBoundingClientRect();
    this.props.setSearchResultsHeight( offset.top, this.props.documentDimensions.height );
  }

  getSuggestionValue( suggestion ){
    // Update the form action URL when press key up or down in typeahead suggestion list
    this.props.navigationStateURL( suggestion.navigationState, suggestion.label );
    // trigger suggestion label when press key up or down in typeahead suggestion list for screen reader
    this.props.broadcastMessage( suggestion.label );
  }

  shouldRenderSuggestions( value ){
    return value.trim().length > 2;
  }

  getSectionSuggestions( section ){
    return section.dimensionSearchValues;
  }

  suggestionsClearRequested(){
    if( this.props.displayType === 'desktop' ){
      this.props.onSuggestionsClearRequested();
    }
  }

  renderSuggestionsContainer( { containerProps, children } ){
    const { ref, ...restContainerProps } = containerProps;
    const callRef = isolatedScroll => {
      if( isolatedScroll !== null ){
        ref( isolatedScroll.component );
      }
    }


    let totalResultCount = 0;
    this.props.suggestions.map( ( value, index ) => {
      totalResultCount += value.dimensionSearchValues.length
    } );

    if( this.props.displayType === 'mobile' || children !== null ){

      return (
        <IsolatedScroll
          { ...restContainerProps }
          ref={ callRef }
          id='TypeAheadSearch__results'
          className={
            classNames(
              'react-autosuggest__suggestions-container', {
                'touchMoveAllowed': totalResultCount > 10,
                'TypeAheadSearch__results--hide': totalResultCount <= 0
              }
            )
          }
          onTouchMove={
            ( e ) => {
              this.input.blur();
            }
          }

          onMouseUp={
            ( e ) => {
              if( this.props.displayType === 'desktop' ){
                e.preventDefault();
              }
            }
          }
          onMouseDown={
            ( e ) => {
              if( this.props.displayType === 'desktop' ){
                e.preventDefault();
              }
            }
          }
          style={ ( this.props.displayType === 'mobile' ) ? { height: this.props.searchResultsHeight } : {} }
        >
          { children }
        </IsolatedScroll>
      );
    }
  }

  renderSectionTitle( section ){

    let label;
    switch ( section.dimensionName ){
      case 'product.category':
        label = formatMessage( messages.categories );
        break;
      case 'product.brandName':
        label = formatMessage( messages.brands );
        break;
      case 'd_displayName':
        label = formatMessage( messages.products );
        break;
      case 'd_redirectkeyword':
        label = formatMessage( messages.relatedSearches );
        break;
    }

    return (
      <div className='TypeAhead__section--title'>
        { label }
      </div>
    )
  }


  renderSuggestion( suggestion, { query } ){
    return (
      <TypeAheadSuggestion
        searchQuery={ query }
        suggestion={ suggestion }
      />
    )
  }

  setInputWidth(){

    this.props.setInputWidth(
      document.getElementById( 'TypeAhead__cancel' ).offsetWidth,
      document.getElementById( 'TypeAhead__wrapper' ).offsetWidth,
      this.props.documentDimensions.width
    )
  }


  handleClearBtnClick( e ){
    this.props.resetSearchInputValue();
    this.input.focus();
  }

  handleInputChange( e, data ){
    // update the reducer with the proper search term
    if( this.props.displayType === 'mobile' ){
      this.setSearchResultsHeight();
    }
    // When up/down arrow key pressed in the search text box, the data.newValue will be undefined becuase getSuggestionValue function will not return anything to udpate in the search text box
    if( !isUndefined( data.newValue ) ){
      this.props.onInputChange( data.newValue );
    }
  }


  /**
   * event handler for the submission of the search form
   * @param {object} e - event object
   */
  handleSearchSubmit( e ){
    if( isUndefined( this.props.navigationURL ) ){
      // don't submit the form if there aren't any search params
      if( this.props.inputValue === '' ){
        e.preventDefault();
      }
    }
    else {
      // don't submit the form if navigationURL is avaiable then redirect to the navigation URL
      e.preventDefault();
      window.location.href = fullyQualifyLink( host, this.props.navigationURL );
    }
  }


  renderInputComponent( inputProps ){

    const {
      inputWidth,
      displayType,
      inputValue,
      searchMode
    } = this.props;

    let desktopFlag = displayType === 'desktop';
    // Set Reflektion data attribute value based upon inflection
    let rfkAttrVal = ( desktopFlag ) ? 'rfkid_6' : 'rfkid_6a';

    return (
      <div className='TypeAhead__inputContainer'>
        <div
          className='TypeAhead__input'
          style={
            {
              width: inputWidth
            }
          }
        >
          <input
            { ...inputProps }
            className={
              classNames( {
                'TypeAhead__field': displayType === 'mobile',
                'TypeAhead__field--hasActionButtons': inputValue.trim().length > 0,
                'TypeAhead__field--inlineSubmit': searchMode === 'open'
              } )
            }
            type='search'
            spellCheck='false'
            autoComplete='off'
            autoCorrect='off'
            autoCapitalize='off'
            aria-label={ formatMessage( messages.searchAriaLabelText ) }
            aria-haspopup='true'
            placeholder={ ( displayType === 'mobile' ) ? formatMessage( messages.inputPlaceholder ) : formatMessage( messages.desktopPlaceholder ) }
            { ...( this.props.enableReflektionTag === true && { 'data-rfkid': rfkAttrVal } ) }
          />
        </div>
        { ( () => {
          if( ( this.props.searchMode === 'open' ) && ( this.props.displayType === 'mobile' ) ){
            return (
              <div className='TypeAhead__cancel' id='TypeAhead__cancel'>
                <Button
                  inputTag='a'
                  btnOption='link'
                  btnSize='xs'
                  className='cncl'
                  btnColor='madformagenta'
                  componentMounted={
                    () => {
                      this.setInputWidth()
                    }
                  }
                  clickEventHandler={
                    ( e ) => {
                      e.stopPropagation();
                      document.ontouchmove = ( e ) => {
                        return true
                      };
                      this.props.closeSearchMode( 'close' );
                      this.props.enableDisableDocumentScroll( false );
                    }
                  }
                >
                  { formatMessage( messages.cancel ) }
                </Button>
              </div>
            )
          }
        } )() }
      </div>
    )
  }


  /**
   * Renders the Search component
   */
  render(){

    const {
      inputValue,
      searchMode,
      setInputWidth,
      style,
      suggestions,
      displayType,
      onSuggestionsFetchRequested
    } = this.props;

    let inputProps = {
      onBlur: () => {
      },
      value: inputValue,
      onChange: this.handleInputChange
    }

    // this should change to false if there are no results
    let shouldRenderSuggestions = !!( searchMode === 'open' && this.props.displayType === 'mobile' );
    let mobileFlag = !!( ( searchMode === 'open' && inputValue.trim().length > 0 && displayType === 'mobile' ) );
    let desktopFlag = displayType === 'desktop';

    return (
      <form
        className={
          classNames(
            'TypeAhead', {
              'TypeAhead--desktop': ( this.props.displayType === 'desktop' ),
              'TypeAhead--display': searchMode === 'open',
              'TypeAhead--hide': searchMode !== 'open'
            } )
        }
        method='get'
        action={ this.props.formAction }
        ref={ ( form ) => {
          this.elem = form
        } }
        style={
          {
            top: ( this.props.displayType === 'mobile' ) ? `${ global.scrollY }px` : {}
          }
        }
        onSubmit={
          ( e ) => this.handleSearchSubmit( e )
        }
        role='search'
      >
        <div
          id='TypeAhead__wrapper'
          className={
            classNames( {
              'TypeAhead__wrapper': true,
              'TypeAhead__searchMode': searchMode === 'open'
            } )
          }
        >
          <Autosuggest
            alwaysRenderSuggestions={ true }
            multiSection={ true }
            suggestions={ suggestions }
            onSuggestionsFetchRequested={ onSuggestionsFetchRequested }
            getSuggestionValue={ this.getSuggestionValue }
            renderSuggestion={ this.renderSuggestion }
            renderSectionTitle={ this.renderSectionTitle }
            getSectionSuggestions={ this.getSectionSuggestions }
            renderInputComponent={ this.renderInputComponent }
            renderSuggestionsContainer={ this.renderSuggestionsContainer }
            shouldRenderSuggestions={ this.shouldRenderSuggestions }
            onSuggestionsClearRequested={ this.suggestionsClearRequested }
            ref={ this.storeInputReference }
            inputProps={ inputProps }
          />

          <div className='TypeAhead__actions'>
            { ( () => {
              if( mobileFlag || desktopFlag ){
                return (
                  <Button
                    inputTag='button'
                    className='TypeAhead__submit'
                    btnType='submit'
                    ariaLabel={ formatMessage( messages.searchIconAltText ) }
                  >
                    <SearchSVG />
                  </Button>
                )
              }
            } )() }
          </div>

        </div>
        <input
          type='hidden'
          name='Dy'
          value='1'
        />
        <input
          type='hidden'
          name='ciSelector'
          value='searchResults'
        />
      </form>
    );
  }
}

TypeAhead.propTypes = propTypes;

export default TypeAhead;
