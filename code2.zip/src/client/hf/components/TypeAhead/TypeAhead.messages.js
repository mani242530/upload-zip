/*
 * TypeAhead Messages
 *
 * This contains all the text for the TypeAhead component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  inputPlaceholder: {
    id: 'i18n.TypeAhead.inputPlaceholder',
    defaultMessage: 'Search for all things beauty'
  },
  desktopPlaceholder:{
    id: 'i18n.TypeAhead.desktopPlaceholder',
    defaultMessage: 'Search'
  },
  cancel:{
    id: 'i18n.TypeAhead.cancel',
    defaultMessage: 'Cancel'
  },
  searchIconAltText: {
    id: 'i18n.TypeAhead.searchIconAltText',
    defaultMessage: 'Search'
  },
  closeIconAltText: {
    id: 'i18n.TypeAhead.closeIconAltText',
    defaultMessage: 'Close'
  },
  categories: {
    id: 'i18n.TypeAhead.categories',
    defaultMessage: 'Categories'
  },
  brands: {
    id: 'i18n.TypeAhead.brands',
    defaultMessage: 'Brands'
  },
  products: {
    id: 'i18n.TypeAhead.products',
    defaultMessage: 'Products'
  },
  relatedSearches: {
    id: 'i18n.TypeAhead.relatedSearches',
    defaultMessage: 'Related Searches'
  },
  resultsAvailable: {
    id: 'i18n.TypeAhead.resultsAvailable',
    defaultMessage: '{ totalResultCount } results are available.'
  },
  noResultsFound: {
    id: 'i18n.TypeAhead.noResultsFound',
    defaultMessage: 'No search results.'
  },
  searchAriaLabelText: {
    id: 'i18n.TypeAhead.searchAriaLabelText',
    defaultMessage: 'Search'
  }

} );
