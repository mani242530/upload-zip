import React from 'react';
import ReactDOM from 'react-dom';
import TypeAhead from './TypeAhead';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import _ from 'lodash';
import { shallow } from 'enzyme';
import messages from './TypeAhead.messages';

Object.defineProperty( window.location, 'href', {
  writable: true,
  value: ''
} );

describe( '<TypeAhead />', () => {

  let props ={
    documentDimensions: 600,
    suggestions: [],
    inputValue: '',
    enableDisableDocumentScroll: jest.fn(),
    registerRemoveIOSRubberEffect: jest.fn(),
    onSuggestionsFetchRequested: jest.fn(),
    resetearchInputvalue: jest.fn(),
    setInputWidth: jest.fn(),
    onInputChange: jest.fn(),
    onSuggestionsClearRequested: jest.fn(),
    requestSearchResults: jest.fn(),
    setSearchResultsHeight: jest.fn(),
    closeSearchMode: jest.fn(),
    broadcastMessage: jest.fn(),
    navigationStateURL: jest.fn(),
    displayType: 'mobile',
    enableReflektionTag: true,
    resetSearchInputValue: jest.fn(),
    isReadSuggestions: false
  }

  global.requestAnimationFrame = jest.fn();

  const component = mountWithIntl( <TypeAhead { ...props } searchMode='close' /> );

  it( 'renders without crashing', () => {
    expect( component ).toBeTruthy();
  } );

  it( 'should have searchMode as a proptype', ()=> {
    expect( component.props().searchMode ).toBeTruthy();
  } );
  const formEl = component.find( 'form' );
  let node = component.find( 'TypeAhead' ).instance();

  it( 'should return IsolatedScroll component with react-autosuggest suggestions container', ()=>{
    const props1 = {
      ...props,
      displayType:'Desktop',
      searchResultsHeight:350,
      suggestions: []
    };
    const params = {
      containerProps: { ref :jest.fn(), restContainerProps: { children: '<h1>a<h1>' } },
      children: ['<h1>b<h1>']
    };
    const component1 = mountWithIntl( <TypeAhead { ...props1 } searchMode='close' /> );
    const node1 = component1.find( 'TypeAhead' ).instance();
    const isolatedScrollComponent = node1.renderSuggestionsContainer( params );
    expect( isolatedScrollComponent ).toBeTruthy();
    expect( isolatedScrollComponent.props.className ).toBe( 'react-autosuggest__suggestions-container TypeAheadSearch__results--hide' );
  } );

  it( 'should not return IsolatedScroll component with react-autosuggest suggestions container when children property is null', ()=>{
    const props1 = {
      ...props,
      displayType:'Desktop',
      searchResultsHeight:350,
      suggestions: []
    };
    const params = {
      containerProps: { ref :jest.fn(), restContainerProps: { children: '<h1>a<h1>' } },
      children: null
    };
    const component1 = mountWithIntl( <TypeAhead { ...props1 } searchMode='close' /> );
    const node1 = component1.find( 'TypeAhead' ).instance();
    const isolatedScrollComponent = node1.renderSuggestionsContainer( params );
    expect( isolatedScrollComponent ).toBeFalsy();
  } );

  it( 'should return IsolatedScroll component with touchMoveAllowed', ()=>{
    const props1 = {
      ...props,
      searchResultsHeight:350,
      suggestions: [{
        dimensionSearchValues: [{ a:1 }, { b:2 }]
      }, {
        dimensionSearchValues: [{ c:1 }, { d:1 }, { e:1 }]
      },
      {
        dimensionSearchValues: [{ f:1 }, { g:1 }, { h:1 }, { i:1 }, { j:1 }, { k:1 }, { l:1 }]
      }]
    };
    const params = {
      containerProps: { ref :jest.fn(), restContainerProps: { children: '<h1>a<h1>' } },
      children: '<h1>b<h1>'
    };
    const component1 = mountWithIntl( <TypeAhead { ...props1 } searchMode='close' /> );
    const node1 = component1.find( 'TypeAhead' ).instance();
    const isolatedScrollComponent = node1.renderSuggestionsContainer( params );
    expect( isolatedScrollComponent ).toBeTruthy();
    expect( isolatedScrollComponent.props.className ).toBe( 'react-autosuggest__suggestions-container touchMoveAllowed' );
  } );

  it( 'should return titleComponent based on input provided ', ()=>{
    const node1 = component.find( 'TypeAhead' ).instance();
    let titleComponent = node1.renderSectionTitle( { dimensionName: 'product.category' } );
    expect( titleComponent ).toBeTruthy();
    expect( titleComponent.props.children ).toBe( 'Categories' );

    titleComponent = node1.renderSectionTitle( { dimensionName: 'product.brandName' } );
    expect( titleComponent.props.children ).toBe( 'Brands' );

    titleComponent = node1.renderSectionTitle( { dimensionName: 'd_displayName' } );
    expect( titleComponent.props.children ).toBe( 'Products' );

    titleComponent = node1.renderSectionTitle( { dimensionName: 'd_redirectkeyword' } );
    expect( titleComponent.props.children ).toBe( 'Related Searches' );

  } );

  it( 'should invoke handleClearBtnClick & handleInputChange ', ()=>{
    const node1 = component.find( 'TypeAhead' ).instance();
    node1.handleClearBtnClick( {} );
    expect( props.resetSearchInputValue ).toBeCalled();

    node1.handleInputChange( {}, { newValue: 1 } );
    expect( props.onInputChange ).toHaveBeenCalledWith( 1 );

  } );

  describe( 'Form component', () => {

    it( 'should have a form element with a "Select" class', () => {
      expect( formEl.length ).toBe( 1 );
      expect( formEl.hasClass( 'TypeAhead' ) ).toBe( true );
    } );


    it( 'should have the propper, method, action, and onSubmit values set', () => {
      expect( formEl.props().method ).toBe( 'get' );
      expect( formEl.props().action ).toBe( node.action );
      expect( formEl.props().role ).toBe( 'search' );
    } );


    it( 'should call handleTypeAheadSubmit when the form is submitted', () => {
      node.handleSearchSubmit = jest.fn();
      formEl.simulate( 'submit', { preventDefault(){} } );
      expect( node.handleSearchSubmit ).toBeCalled();
    } );

  } );


  describe( 'input fields', () => {

    describe( 'text field', () => {

      let input = formEl.find( 'input[type="search"]' );
      it( 'should have a single text input field', ()=> {
        expect( input.length ).toBe( 1 );
        expect( input.hasClass( 'TypeAhead__field' ) ).toBe( true );
      } );

      it( 'should have the autoComplete attribute set to \'off\'', () => {
        expect( input.props().autoComplete ).toBe( 'off' );
      } );

      it( 'should have the proper placeholder message', ()=> {
        expect( input.props().placeholder ).toBe( messages.inputPlaceholder.defaultMessage );
      } );

      it( 'should have the proper aria-label message', () => {
        expect( input.props()['aria-label'] ).toBe( messages.searchAriaLabelText.defaultMessage );
      } );

      it( 'should have focus and blur events defined', ()=> {
        expect( input.props().onFocus ).toBeTruthy();
        expect( input.props().onBlur ).toBeTruthy();
      } );

      it( 'should have a Reflektion data-rfkid attribute if enableReflektionTag is true', ()=> {
        expect( input.prop( 'data-rfkid' ) ).toBeTruthy();
      } );

      it( 'should not have a Reflektion data-rfkid attribute if enableReflektionTag is false', ()=> {
        props = { ...props, enableReflektionTag: false };
        let tmpComponent = mountWithIntl( <TypeAhead { ...props } searchMode='open'/> ).render();
        let input = tmpComponent.find( 'input[type="search"]' );
        expect( input.prop( 'data-rfkid' ) ).toBe( undefined );
      } );

    } );

    describe( 'hidden fields', () => {
      let hiddenInputs = formEl.find( 'input[type="hidden"]' );

      it( 'should have 2 hidden input fields', () => {
        expect( hiddenInputs.length ).toBe( 2 );
      } );

      it( 'should have the propper hidden field values', () => {
        expect( hiddenInputs.at( 0 ).props().name ).toBe( 'Dy' );
        expect( hiddenInputs.at( 0 ).props().value ).toBe( '1' );

        expect( hiddenInputs.at( 1 ).props().name ).toBe( 'ciSelector' );
        expect( hiddenInputs.at( 1 ).props().value ).toBe( 'searchResults' );
      } );
    } );

    var dummyElement = document.createElement( 'div' );
    document.getElementById = jest.fn().mockReturnValue( dummyElement );

    describe( 'submit button', () => {

      describe( 'should show inline search submit', ()=> {
        props = { ...props, inputValue: 'ALP' };

        let tmpComponent = mountWithIntl( <TypeAhead { ...props } searchMode='open'/> );

        let input = tmpComponent.find( '.TypeAhead__wrapper' ).find( 'button[type=\'submit\']' );

        it( 'should have a single submit input field if configured', ()=> {
          expect( input.length ).toBe( 1 );
          expect( input.hasClass( 'TypeAhead__submit' ) ).toBe( true );
        } );

        it( 'should have the proper aria-label message', () => {
          expect( input.props()['aria-label'] ).toBe( messages.searchIconAltText.defaultMessage );
        } );

        it( 'should have an image as a child that has the proper alt message', () => {
          let img = input.find( 'Image' );
          expect( tmpComponent.find( '.TypeAhead__actions' ).find( 'svg' ).length ).toBe( 1 );
        } );

      } );

    } );

    describe( 'close button', () => {

      props = { ...props, inputValue: 'ALP' };

      let tmpComponent = mountWithIntl( <TypeAhead { ...props } searchMode='open'/> );

      let input = tmpComponent.find( '.TypeAhead__cancel' );
      it( 'should have an image as a child that has the proper alt message', () => {
        expect( input.text() ).toBe( messages.cancel.defaultMessage );
      } );

      it( 'should call the parent container \'handleCloseBtnClick\' when clicked', () => {
        node.handleCloseBtnClick = jest.fn();
        input.find( 'Button' ).simulate( 'click' );
        expect( props.closeSearchMode ).toHaveBeenCalledWith( 'close' );
      } );


    } );
  } );

  describe( 'Render Accessibility Content', () => {
    let mockJestFn = jest.fn();

    it( 'should check suggestion result updates on componentDidUpdate event in Desktop breakpoint', () => {

      let props1 = {
        ...props,
        displayType: 'desktop',
        isReadSuggestions: false,
        suggestions: []
      };

      let props2 = {
        ...props,
        displayType: 'desktop',
        isReadSuggestions: true,
        suggestions: [
          {
            displayName: 'product.category',
            dimensionSearchValues: [
              {
                label: 'Makeup'
              }
            ]
          },
          {
            displayName: 'd_displayName',
            dimensionSearchValues: [
              {
                label: 'Blush Subtil'
              },
              {
                label: 'Blush Rush'
              },
              {
                label: 'Blush'
              }
            ]
          }
        ]
      };

      let component1 = mountWithIntl(
        <TypeAhead { ...props2 } />
      );

      let node = component1.find( 'TypeAhead' ).instance();
      node.componentDidUpdate( props1 );
      expect( node.props.broadcastMessage ).toBeCalledWith( '4 results are available.' );

    } );

    it( 'should check suggestion result updates on componentDidUpdate event in Mobile breakpoint', () => {

      let props1 = {
        ...props,
        isReadSuggestions: false,
        suggestions: []
      };

      let props2 = {
        ...props,
        isReadSuggestions: true,
        suggestions: [
          {
            displayName: 'product.category',
            dimensionSearchValues: [
              {
                label: 'Makeup'
              }
            ]
          },
          {
            displayName: 'd_displayName',
            dimensionSearchValues: [
              {
                label: 'Blush Subtil'
              }
            ]
          }
        ]
      };

      let component1 = mountWithIntl(
        <TypeAhead { ...props2 } />
      );

      let node = component1.find( 'TypeAhead' ).instance();
      node.componentDidUpdate( props1 );
      expect( node.props.broadcastMessage ).toBeCalledWith( '2 results are available.' );

    } );

    it( 'should check no suggestion result updates on componentDidUpdate event', () => {

      let props1 = {
        ...props,
        isReadSuggestions: true,
        suggestions: [
          {
            displayName: 'product.category',
            dimensionSearchValues: [
              {
                label: 'Makeup'
              }
            ]
          }
        ]
      };

      let props2 = {
        ...props,
        isReadSuggestions: true,
        suggestions: []
      };

      let component1 = mountWithIntl(
        <TypeAhead { ...props2 } />
      );

      let node = component1.find( 'TypeAhead' ).instance();
      node.componentDidUpdate( props1 );
      expect( node.props.broadcastMessage ).toBeCalledWith( messages.noResultsFound.defaultMessage );

    } );

    it( 'should check getSuggestionValue class function to be called', () => {

      let component1 = mountWithIntl(
        <TypeAhead { ...props } />
      );

      let node = component1.find( 'TypeAhead' ).instance();
      let data = {
        navigationState: '/nails?N=271o',
        label: 'Nails'
      };
      node.getSuggestionValue( data );
      expect( node.props.navigationStateURL ).toBeCalled();
      expect( node.props.broadcastMessage ).toBeCalled();
      expect( node.props.navigationStateURL ).toHaveBeenCalledWith( data.navigationState, data.label )
    } );

    it( 'should check suggestionsClearRequested class function to be called and onSuggestionsClearRequested not be called in Mobile', () => {

      let component1 = mountWithIntl(
        <TypeAhead { ...props } />
      );

      let node = component1.find( 'TypeAhead' ).instance();
      node.suggestionsClearRequested();
      expect( node.props.onSuggestionsClearRequested ).not.toBeCalled();

    } );

    it( 'should check suggestionsClearRequested class function to be called and onSuggestionsClearRequested be called in Desktop', () => {

      let props1 = {
        ...props,
        displayType: 'desktop'
      };

      let component1 = mountWithIntl(
        <TypeAhead { ...props1 } />
      );

      let node = component1.find( 'TypeAhead' ).instance();
      node.suggestionsClearRequested();
      expect( node.props.onSuggestionsClearRequested ).toBeCalled();

    } );

    it( 'should check onInputChange function to be called when data available', () => {

      let component1 = mountWithIntl(
        <TypeAhead { ...props } />
      );

      let node = component1.find( 'TypeAhead' ).instance();
      let data = {
        newValue: 'Nails'
      };
      let e = new CustomEvent();
      node.handleInputChange( e, data );
      expect( node.props.onInputChange ).toBeCalled();

    } );

    it( 'should check onInputChange function not to be called when data is not available', () => {

      let props1 = {
        ...props,
        onInputChange: jest.fn()
      }
      let component1 = mountWithIntl(
        <TypeAhead { ...props1 } />
      );

      let node = component1.find( 'TypeAhead' ).instance();
      let data = {};
      let e = new CustomEvent();
      node.handleInputChange( e, data );
      expect( node.props.onInputChange ).not.toBeCalled();

    } );

    it( 'should check handleSearchSubmit class function should not redirect the page, if navigationURL is not available', () => {

      let props1 = {
        ...props,
        navigationURL: undefined
      }
      let component1 = mountWithIntl(
        <TypeAhead { ...props1 } />
      );

      let node = component1.find( 'TypeAhead' ).instance();
      let e = new CustomEvent();
      node.handleSearchSubmit( e );
      expect( window.location.href ).toBe( '' );

    } );

    it( 'should check handleSearchSubmit class function should redirect the page, if navigationURL is available', () => {

      let props1 = {
        ...props,
        navigationURL: '/nails?N=271o'
      }
      let component1 = mountWithIntl(
        <TypeAhead { ...props1 } />
      );

      let node = component1.find( 'TypeAhead' ).instance();
      let e = new CustomEvent();
      node.handleSearchSubmit( e );
      expect( window.location.href ).toBe( '//www.ulta.com/nails?N=271o' );

    } );

  } );

} );
