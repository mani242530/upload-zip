/**
 * TypeAheadSearch
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import TypeAhead from 'hf/components/TypeAhead/TypeAhead';

import {
  actions as typeAheadActions
} from 'hf/actions/TypeAheadSearch/TypeAheadSearch.actions'

import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';

import { makeGetDocumentDimensions } from 'shared/reducers/Global/Global.reducer';

import isUndefined from 'lodash/isUndefined';

export const mapStateToProps = ( state ) => {
  let documentDimensions = makeGetDocumentDimensions();

  return Object.assign( {},
    {
      documentDimensions: documentDimensions( state )
    },
    {
      ...state.typeaheadsearch
    },
  )
}

export const mapDispatchToProps = ( dispatch ) => {

  return {
    setSearchResultsHeight: ( offset, screenHeight ) => {
      dispatch( typeAheadActions.setSearchResultsHeight( offset, screenHeight ) )
    },

    requestSearchResults: ( query ) => {
      dispatch( typeAheadActions.requestSearchResults( query ) );
    },

    onSuggestionsClearRequested: () => {
      dispatch( typeAheadActions.onSuggestionsClearRequested() );
    },

    onInputChange: ( val ) => {
      dispatch( typeAheadActions.updateInputValue( val ) );
    },

    setInputWidth: ( cancelBtnWidth, containerWidth, deviceWidth ) => {
      dispatch( typeAheadActions.setInputWidth( cancelBtnWidth, containerWidth, deviceWidth ) );
    },

    resetSearchInputValue: () => {
      dispatch( typeAheadActions.resetSearchInputValue() );
    },

    onSuggestionsFetchRequested: ( query ) => {
      // only request data if we have 3 or more characters entered
      // check value is not defined, when up/down arrow key pressed in the search text box
      if( !isUndefined( query.value ) && query.value.length >= 3 ){
        dispatch( typeAheadActions.requestSearchResults( query ) );
      }
    },

    navigationStateURL: ( url, label ) => {
      dispatch( typeAheadActions.navigationStateURL( url, label ) );
    },

    enableDisableDocumentScroll: ( val ) => {
      dispatch( globalActions.enableDisableDocumentScroll( val ) );
    },

    registerRemoveIOSRubberEffect: ( elem ) => {
      dispatch( globalActions.registerRemoveIOSRubberEffect( elem ) );
    },

    // broadcastMessage function to trigger for live data
    broadcastMessage : function( message ){
      dispatch( globalActions.setBroadcastMessage( message ) )
    }

  }
}

// this is to mock the data for test cases
export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( TypeAhead ) );
};

export default connectFunction( mapStateToProps, mapDispatchToProps );


