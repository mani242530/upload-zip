import React from 'react';
import TypeAheadSearch, { mapDispatchToProps, mapStateToProps } from './TypeAheadSearch';
import { initialState } from 'hf/reducers/TypeAheadSearch/TypeAheadSearch.reducer';
import { Provider } from 'react-redux';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import {
  actions as typeAheadActions,
  types as typeAheadActionTypes
} from 'hf/actions/TypeAheadSearch/TypeAheadSearch.actions';
import {
  actions as globalActions
} from 'shared/actions/Global/Global.actions';

// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';

describe( '<TypeAheadSearch />', () => {
  let dispatch = jest.fn();


  beforeEach( ()=> {
    dispatch.mockClear();
  } )



  let mdp  = mapDispatchToProps( dispatch );

  it( 'setSearchResults should dispatch the proper action', () => {
    let event = mdp.setSearchResultsHeight( 1, 1 );
    expect( dispatch ).toHaveBeenCalledWith(
      typeAheadActions.setSearchResultsHeight( 1, 1 )
    );
  } );

  it( 'requestSearchResults should dispatch the proper action', () => {
    let event = mdp.requestSearchResults( 'test' );
    expect( dispatch ).toHaveBeenCalledWith(
      typeAheadActions.requestSearchResults( 'test' )
    );
  } );

  it( 'onSuggestionsClearRequested should dispatch the proper action', () => {
    let event = mdp.onSuggestionsClearRequested();
    expect( dispatch ).toHaveBeenCalledWith(
      typeAheadActions.onSuggestionsClearRequested()
    );
  } );

  it( 'onInputChange should dispatch the proper action', () => {
    let event = mdp.onInputChange( 'hi' );
    expect( dispatch ).toHaveBeenCalledWith(
      typeAheadActions.updateInputValue( 'hi' )
    );
  } );

  it( 'setInputWidth should dispatch the proper action', () => {
    let event = mdp.setInputWidth( 20, 20, 405 );
    expect( dispatch ).toHaveBeenCalledWith(
      typeAheadActions.setInputWidth( 20, 20, 405 )
    );
  } );

  it( 'resetSearchInputValue should dispatch the proper action', () => {
    let event = mdp.resetSearchInputValue();
    expect( dispatch ).toHaveBeenCalledWith(
      typeAheadActions.resetSearchInputValue()
    );
  } );

  it( 'onSuggestionsFetchRequested should not dispatch the proper action if the query is not longer than 3 characters', () => {
    var query1 = {
      value: 'te'
    }
    let event = mdp.onSuggestionsFetchRequested( query1 );
    expect( dispatch ).not.toHaveBeenCalled();
  } );

  it( 'onSuggestionsFetchRequested should dispatch the proper action', () => {
    let query = {
      value: 'tes'
    }
    let event = mdp.onSuggestionsFetchRequested( query );
    expect( dispatch ).toHaveBeenCalledWith(
      typeAheadActions.requestSearchResults( query )
    );
  } );

  it( 'navigationStateURL should dispatch the proper action', () => {
    let data = '/nails?N=271o';
    let label = 'makeUp>lipstick'
    let event = mdp.navigationStateURL( data, label );
    expect( dispatch ).toHaveBeenCalledWith(
      typeAheadActions.navigationStateURL( data, label )
    );
  } );

  it( 'broadcastMessage should dispatch the proper action', () => {
    const message = 'test message';
    mdp.broadcastMessage( message );
    expect( dispatch ).toHaveBeenCalledWith(
      globalActions.setBroadcastMessage( message )
    );
  } );

} );
