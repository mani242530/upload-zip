/**
 * TypeAheadSuggestion
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './TypeAheadSuggestion.css';

import Anchor from 'shared/components/Anchor/Anchor';
import AutosuggestHighlightMatch from 'autosuggest-highlight/match';
import AutosuggestHighlightParse from 'autosuggest-highlight/parse';
import classNames from 'classnames';



const propTypes = {
  suggestion: PropTypes.object.isRequired,
  searchQuery: PropTypes.string.isRequired
}


/**
 * Class
 * @extends React.Component
 */
class TypeAheadSuggestion extends Component{


  /**
   * Renders the TypeAheadSuggestion component
   */
  render(){
    const {
      suggestion,
      searchQuery
    } = this.props;

    const matches = AutosuggestHighlightMatch( suggestion.label, searchQuery );
    const parts = AutosuggestHighlightParse( suggestion.label, matches );

    return (
      <div className='TypeAheadSuggestion'>
        <Anchor
          url={ suggestion.navigationState }
        >
          {
            parts.map( ( part, index ) => {
              return (
                <span
                  className={
                    classNames( {
                      'highlight': part.highlight
                    } )
                  }
                  key={ index }
                >
                  { part.text }
                </span>
              );
            } )
          }
        </Anchor>
      </div>
    );
  }
}

TypeAheadSuggestion.propTypes = propTypes;

export default TypeAheadSuggestion;
