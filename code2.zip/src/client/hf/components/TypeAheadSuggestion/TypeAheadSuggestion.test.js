import React from 'react';
import ReactDOM from 'react-dom';
import TypeAheadSuggestion from './TypeAheadSuggestion';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';

describe( '<TypeAheadSuggestion />', () => {
  let component;

  let props = {
    suggestion: {
      navigationState : 'google.com',
      label: 'Ggle'
    },
    searchQuery: 'Gg'
  }
  it( 'renders without crashing', () => {

    component = mountWithIntl( <TypeAheadSuggestion { ...props } /> );
    expect( component.find( 'TypeAheadSuggestion' ).length ).toBe( 1 );
  } );

  it( 'should have an Anchor component as a child', () => {
    expect( component.find( 'Anchor' ).length ).toBe( 1 );
  } );
} );
