/**
 * external.js
 *
 * this is the entry file for the application and is only used for setup code
 *
 */

// Needed for redux-saga es6 generator support
import 'babel-polyfill';
import 'shared/theme/theme.css';

// ReactJS specific imports
import React from 'react';
import { renderComponent } from 'utils/ReactDOM/rendering';
import shimReady from 'static/js/shim';

// Redux specific imports
import { Provider } from 'react-redux';

// i18n (internationalization) imports
import LanguageProvider from 'shared/components/LanguageProvider/LanguageProvider';

// Application component imports
import Global from 'shared/components/Global/Global';
import Header from 'hf/components/Header/Header';
import LeftNav from 'hf/components/LeftNav/LeftNav';
import Footer from 'hf/components/Footer/Footer'
import { translationMessages } from 'shared/components/LanguageProvider/i18n';
import configureStore from 'hf/hf.store';
import { updateDataLayer } from 'utils/Omniture/Omniture';
import { fullyQualifyLink, host } from 'utils/Formatters/formatters';
import merge from 'lodash/merge';

import CONFIG from 'hf/hf.config';

import { setConfig } from 'utils/Ajax/Ajax';
setConfig( CONFIG );

import {
  loadState,
  saveState
} from 'utils/LocalStorage/LocalStorage';

import throttle from 'lodash/throttle';

let store;

export const render = ( messages ) => {

  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Global />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'ulta-global' )
  );

  // HEADER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Header />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'ulta-Header' )
  );

  // LEFTNAV
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <LeftNav />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'ulta-Nav' )
  );

  // FOOTER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Footer />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'ulta-Footer' )
  );

  // Default Omniture page data
  if( typeof globalPageData !== 'undefined' ){
    if( globalPageData.navigation.pageName === '' ){
      var btPage = document.getElementsByTagName( 'title' )[0].innerHTML.toLowerCase();
      var pageData = { 'globalPageData':{ 'navigation': { 'pageName':btPage, 'channel':btPage } } };
      updateDataLayer( pageData );
    }
  }

}

if( document.cookie.indexOf( 'isNativeApp' ) === -1 ){

  const initialState = {
    header: {
      mobileHeaderDisplayMode: 'no_search',
      desktopHeaderDisplayMode: 'default',
      shippingBanner: {
        message: undefined,
        url: '/'
      },
      cartPageShippingBanner: {
        message: undefined
      }
    },
    footer: {
      mobileFooterDisplayMode: 'default',
      desktopFooterDisplayMode: 'default',
      footerNavCollapse: {
        contactus: false,
        orders: false,
        samples: false,
        gifts: false,
        coupons: false
      }
    }
  }
  let headerFooterScript = document.getElementById( 'uhfjs' );

  if( headerFooterScript === null && process.env.NODE_ENV === 'test' ){
    // this code will make sure that the script element is in place for unit test scripts
    // in the production envrionment the script element will be loaded by the index.html file
    let appElement = document.createElement( 'div' );
    appElement.id='uhfjs';
    appElement.setAttribute( 'data-mobile-header', 'default' );
    appElement.setAttribute( 'data-mobile-footer', 'default' );
    appElement.setAttribute( 'data-desktop-header', 'default' );
    appElement.setAttribute( 'data-desktop-footer', 'default' );
    appElement.setAttribute( 'data-nav', 'default' );
    document.body.appendChild( appElement );
    headerFooterScript = appElement;
  }

  if( headerFooterScript.hasAttribute( 'data-mobile-header' ) ){
    const mHeader = headerFooterScript.getAttribute( 'data-mobile-header' );
    if( ['default', 'focused', 'no_search'].includes( mHeader ) ){
      initialState.header.mobileHeaderDisplayMode = mHeader;
    }
  }
  if( headerFooterScript.hasAttribute( 'data-mobile-footer' ) ){
    const mFooter = headerFooterScript.getAttribute( 'data-mobile-footer' );
    if( ['default', 'customerService'].includes( mFooter ) ){
      initialState.footer.mobileFooterDisplayMode = mFooter;
    }
  }
  if( headerFooterScript.hasAttribute( 'data-desktop-header' ) ){
    const dHeader = headerFooterScript.getAttribute( 'data-desktop-header' );
    if( ['default', 'focused'].includes( dHeader ) ){
      initialState.header.desktopHeaderDisplayMode = dHeader;
    }
  }
  if( headerFooterScript.hasAttribute( 'data-desktop-footer' ) ){
    const dFooter = headerFooterScript.getAttribute( 'data-desktop-footer' );
    if( ['default', 'customerService', 'none'].includes( dFooter ) ){
      initialState.footer.desktopFooterDisplayMode = dFooter;
    }
  }
  if( headerFooterScript.hasAttribute( 'data-nav' ) ){
    const dNav = headerFooterScript.getAttribute( 'data-nav' );
  }

  var tagStyle = document.createElement( 'style' );
  var styleDef = document.createTextNode( '@media all and (min-width: 922px){ #ulta-Body { margin-top: 55px; } }' );
  tagStyle.appendChild( styleDef );
  document.getElementsByTagName( 'head' )[0].appendChild( tagStyle );

  store = configureStore( merge( initialState, loadState() ), CONFIG );
  store.subscribe( () => {
    let state = store.getState();

    saveState( {
      session: state.session,
      // To fix the sticky footer displayed multiple times in same session when switching between REACT page because SFD (Sticky Footer Displayed) session cookie is deleted or not persisting
      // To save & restore emailSignUp sfd session cookie
      emailSignUp: state.esu.stickyEmailSignUp.sessionData,
      searchInputValue: state.typeaheadsearch.inputValue,
      selectedTerm: state.typeaheadsearch.selectedTerm
    } );

    return state;
  } );

  // Hot reloadable translation json fiels
  if( module.hot ){
    // modules.hot.accept does not accept dynamic dependencies,
    // have to be constants at compile-time
    module.hot.accept( 'shared/components/LanguageProvider/i18n', () => {
      render( translationMessages );
    } );
  }

  // new polyfill for browsers without Intl support
  shimReady( () => {
    render( translationMessages )
  } );

}
