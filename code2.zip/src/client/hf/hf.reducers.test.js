/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 **/

import { combineReducers } from 'redux';
import {
  reducer as formReducer,
  actionTypes as formActionTypes
} from 'redux-form';

import global from 'shared/reducers/Global/Global.reducer';
import session from 'shared/reducers/Session/Session.reducer';
import user from 'shared/reducers/User/User.reducer';
import language from 'shared/reducers/Language/Language.reducer';
import header from 'hf/reducers/Header/Header.reducer';
import footer from 'hf/reducers/Footer/Footer.reducer';
import minicart from 'hf/reducers/MiniCart/MiniCart.reducer';
import typeaheadsearch from 'hf/reducers/TypeAheadSearch/TypeAheadSearch.reducer';
import mobileLeftNav from 'hf/reducers/MobileLeftNav/MobileLeftNav.reducer';
import pagedata from 'shared/reducers/Page/Page.reducer';

import asyncReducers, {
  removeUnregisteredFormValue
} from './hf.reducers';
import _ from 'lodash';


// import reducers that are globally required in the ULTA app


describe( 'hf reducer', ( ) => {

  it( 'should be a function', ( ) => {
    expect( _.isFunction( asyncReducers ) ).toBe( true );
  } );

  it( 'should return the combineReducers', ( ) => {
    expect( asyncReducers().toString ).toEqual( combineReducers( {
      global,
      session,
      user,
      language,
      header,
      footer,
      minicart,
      mobileLeftNav,
      typeaheadsearch,
      pagedata,
      form: formReducer,
      ...asyncReducers
    } ).toString )
  } );

  it( 'should return the state if the action is not for unregistering a field', ( ) => {
    let actionCreator = {
      type: 'test',
      payload:{
        name:'test'
      }
    }

    let state = {
      values: {
        Field1:'test',
        Field2:'test',
        Field3:'test'
      }
    }

    expect( removeUnregisteredFormValue( state, actionCreator ) ).toEqual( state );

  } );

  it( 'should remove unregistered field', ( ) => {
    let actionCreator = {
      type: formActionTypes.UNREGISTER_FIELD,
      payload:{
        name:'Field1'
      }
    }

    let state = {
      values: {
        Field1:'test',
        Field2:'test',
        Field3:'test'
      }
    }

    let expectedOutput = {
      values: {
        Field2:'test',
        Field3:'test'
      }
    }

    expect( removeUnregisteredFormValue( state, actionCreator ) ).toEqual( expectedOutput );

  } );

} );