import CONFIG from 'hf/hf.config';
import { fork } from 'redux-saga/effects';

import searchtypeaheadsaga from 'hf/sagas/SearchTypeAhead/SearchTypeAhead.sagas';

import sessionsaga, { sessionManager } from 'shared/sagas/Session/Session.sagas';
import usersaga from 'shared/sagas/User/User.sagas';
import profilesaga from 'shared/sagas/Profile/Profile.sagas';
import loginsaga from 'shared/sagas/Login/Login.sagas';
import navigationsaga from 'shared/sagas/Navigation/Navigation.sagas';
import pagesaga from 'shared/sagas/Page/Page.sagas';
import switches from 'shared/sagas/Switches/Switches.sagas';
import analyticssaga from 'shared/sagas/Analytics/Analytics.sagas';
import logout from 'shared/sagas/Logout/Logout.sagas';
import createAccount from 'shared/sagas/CreateAccount/CreateAccount.sagas';


// All sagas to be loaded
// sessionSAGA must be the first in the list
export default function*(){
  yield[
    // SHARED Module
    fork( sessionManager ),
    fork( sessionsaga( CONFIG ) ),
    fork( usersaga( CONFIG ) ),
    fork( profilesaga ),
    fork( loginsaga ),
    fork( navigationsaga ),
    fork( pagesaga ),
    fork( switches( CONFIG ) ),
    fork( analyticssaga ),
    fork( logout ),
    fork( createAccount ),

    // Header Footer Module
    fork( searchtypeaheadsaga )
  ]
}
