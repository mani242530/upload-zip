import CONFIG from 'hf/hf.config';
import { fork } from 'redux-saga/effects';

import searchtypeaheadsaga from 'hf/sagas/SearchTypeAhead/SearchTypeAhead.sagas';

import sessionsaga, { sessionManager } from 'shared/sagas/Session/Session.sagas';
import usersaga from 'shared/sagas/User/User.sagas';
import profilesaga from 'shared/sagas/Profile/Profile.sagas';
import loginsaga from 'shared/sagas/Login/Login.sagas';
import navigationsaga from 'shared/sagas/Navigation/Navigation.sagas';
import pagesaga from 'shared/sagas/Page/Page.sagas';
import switches from 'shared/sagas/Switches/Switches.sagas';
import analyticssaga from 'shared/sagas/Analytics/Analytics.sagas';
import logout from 'shared/sagas/Logout/Logout.sagas';
import createAccount from 'shared/sagas/CreateAccount/CreateAccount.sagas';

import saga from './hf.sagas';


describe( 'hf sagas', () => {

  const hfSaga = saga();

  it( 'should load all sagas', () => {

    const yieldDescriptor = hfSaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      fork( sessionManager ),
      fork( sessionsaga( CONFIG ) ),
      fork( usersaga( CONFIG ) ),
      fork( profilesaga ),
      fork( loginsaga ),
      fork( navigationsaga ),
      fork( pagesaga ),
      fork( switches( CONFIG ) ),
      fork( analyticssaga ),
      fork( logout ),
      fork( createAccount ),
      fork( searchtypeaheadsaga )
    ] ) );

  } );

} );