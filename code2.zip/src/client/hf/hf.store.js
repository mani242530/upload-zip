/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 */
import 'babel-polyfill';
import { createStore, applyMiddleware, compose } from 'redux';
import { persistState } from 'redux-devtools';
import createSagaMiddleware from 'redux-saga';
import createReducer from 'hf/hf.reducers';
import forEach from 'lodash/forEach';
import keys from 'lodash/keys';
import { setWindowDebuggingFlag } from 'utils/Debugging/Debugging.js';

// Import global Sagas
import sagas from 'hf/hf.sagas';

const sagaMiddleware = createSagaMiddleware();

export default function configureStore( initialState = {}, CONFIG ){

  const middlewares = [
    sagaMiddleware
  ];

  const enhancers = [
    applyMiddleware( ...middlewares )
  ];

  if( process.env.NODE_ENV !== 'production' ){
    enhancers.push( persistState(
      global.location.href.match( /[?&]debug_session=([^&#]+)\b/ )
    ) );
  }

  const debugKeys = keys( CONFIG.DEBUGGING.LOGGING );
  // loop over all the falgs in the config file to dynamically create bindings
  forEach( debugKeys, ( key ) => {
    setWindowDebuggingFlag( key, CONFIG );
  } );

  const composeEnhancers =
    global.TRACK_REDUX_EVENTS &&
    typeof global === 'object' &&
    global.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ?
      global.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : compose;

  const store = createStore(
    createReducer(),
    initialState,
    composeEnhancers( ...enhancers )
  );

  // Run Global Sagas automatically
  sagaMiddleware.run( sagas );

  // extensions
  store.runSaga = sagaMiddleware.run;
  store.asyncReducers = {};


  if( module.hot ){
    module.hot.accept( 'hf/hf.reducers', () => {
      System.import( 'hf/hf.reducers' ).then( ( reducerModule ) => {
        const createReducers = reducerModule.default;
        const nextReducers = createReducers( store.asyncReducers );

        store.replaceReducer( nextReducers );
      } );
    } );
  }

  return store;

}
