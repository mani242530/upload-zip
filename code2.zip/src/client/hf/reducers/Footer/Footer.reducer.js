/**
 * Footer Redux reducer Module
 *
 */

import { createSelector } from 'reselect';
import forIn from 'lodash/forIn';
import {
  types as FooterTypes,
  actions as FooterActions
} from '../../actions/Footer/Footer.actions';
import {
  types as esuTypes,
  actions as esuActions
} from 'esu/actions/EmailSignUp/EmailSignUp.actions';

/**
 * default state for the Footer reducer
 */

export const initialState = {

  mobileFooterDisplayMode: 'default',
  desktopFooterDisplayMode: 'default',
  footerNavCollapse: {
    contactus: false,
    orders: false,
    samples: false,
    gifts: false,
    coupons: false
  }
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){

  switch ( action.type ){
    case FooterTypes.SET_FOOTER_DISPLAY_MODE:

      return {
        ...state,
        [action.deviceType]: action.mode
      }

    case FooterTypes.SET_ACTIVE_FOOTER_NAV_COLLAPSE:

      return {
        ...state,
        footerNavCollapse: configureNavigationCollapseDisplay( action.panelID, state )
      }

    default:
      return state;
  }
}


export const configureNavigationCollapseDisplay = ( panelID, state )=> {
  let obj = {}
  forIn( state.footerNavCollapse, ( val, key ) => {
    if( panelID === key ){
      obj[key] = !val;

    }
    else {
      obj[key] = false;
    }
  } );

  return obj;
};


