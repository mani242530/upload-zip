import reducer, {
  setHeaderFooterDisplayMode,
  initialState,
  configureNavigationCollapseDisplay
} from './Footer.reducer';

import {
  types
} from '../../actions/Footer/Footer.actions';

import _ from 'lodash';

let newInitialState;

describe( 'Footer reducer', ( ) => {


  it( 'should have the proper default state', ( ) => {

    let expectedOutput = {
      mobileFooterDisplayMode: 'default',
      desktopFooterDisplayMode: 'default',
      footerNavCollapse: {
        contactus: false,
        orders: false,
        samples: false,
        gifts: false,
        coupons: false
      }
    };
    expect( initialState ).toEqual( expectedOutput );

  } );

  describe( 'headerFooterDisplayMode attribute should be set based on CURRENT_PAGE variable (`checkout`)', ( ) => {

    beforeEach( ( ) => {
      global.CURRENT_PAGE = 'checkout';
      newInitialState = require.requireMock( './Footer.reducer' ).initialState;
    } );

  } )

  it( 'should be a function', ( ) => {
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  describe( 'SET_ACTIVE_FOOTERNAV_COLLAPSE', ( ) => {
    let panelID, actionCreator, expectedOutput;

    it( 'should handle the event and set the \'arg\' attribute', ( ) => {

      panelID = 'contactus';

      actionCreator = {
        type: types.SET_ACTIVE_FOOTER_NAV_COLLAPSE,
        panelID
      }

      let expectedOutput = { footerNavCollapse:{ contactus: true } };
      expect( reducer( { footerNavCollapse:{ contactus: false } }, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'should update the collapse display options to only show the passed panelID', ( ) => {

      let initialSample = _.cloneDeep( initialState );
      initialSample.footerNavCollapse.tes1 = false;
      initialSample.footerNavCollapse.tes2 = false;
      initialSample.footerNavCollapse.tes3 = false;

      let expectedSample = _.cloneDeep( initialSample );
      let dynamicKey = 'orders'

      expectedSample.footerNavCollapse[ dynamicKey ] = true;

      expect( configureNavigationCollapseDisplay( dynamicKey, initialSample ) ).toEqual( expectedSample.footerNavCollapse );


      expectedSample.footerNavCollapse[ dynamicKey ] = false;
      dynamicKey = 'tes3';
      expectedSample.footerNavCollapse[ dynamicKey ] = true;


      expect( configureNavigationCollapseDisplay( dynamicKey, initialSample ) ).toEqual( expectedSample.footerNavCollapse );

    } );

  } );

} );
