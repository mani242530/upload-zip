/**
 * MiniCart Redux reducer Module
 *
 */

import { createSelector } from 'reselect';

import {
  types as MiniCartTypes,
  actions as MiniCartActions
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  getServiceType,
  getActionDefinition,
  types as serviceTypes
} from 'shared/actions/Services/Services.actions';
import _ from 'lodash';
import has from 'lodash/has';
import isUndefined from 'lodash/isUndefined';
import isEmpty from 'lodash/isEmpty';
import concat from 'lodash/concat';

/**
 * default state for the MiniCart reducer
 */

import {
  actionTypes as ReduxActionType
} from 'redux-form';

export const initialState = {
  cartDataAvailable: false,
  switchesDataAvailable: false,
  quantity: undefined,
  giftText: '',
  giftBoxToggle: false,
  cartPageData: {
    messages: null,
    removedItems: undefined,
    updatedItems: undefined
  },
  recommendedProducts: {},
  chkoutbtnClk: false,
  eligibleForCheckout: false,
  showBagSummary: false,
  removingItem: '',
  couponOfferReqMet: false,
  productSampleCatalogID: '-1',
  cartRightPanelCollapse: {
    userRewards:false,
    samples: false,
    gifts: false,
    coupons: false,
    giftCard: false
  },
  errorRemoving: '',
  giftTextChange: false,
  hideOOSPanel: false,
  cartSignIn:false,
  payPalClientToken: undefined
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */

export const reducerSwitch = function( state, action, serverMessage, serverUpdatedItemMessage, serverRemovedItemMessage ){

  switch ( action.type ){

    case getServiceType( 'initiateCheckout', 'success' ):

      if( !action.data.result ){
        return {
          ...state,
          cartPageData:{
            ...action.data,
            messages: serverMessage( action.data, state ),
            removedItems: serverRemovedItemMessage( action.data, state ),
            updatedItems: serverUpdatedItemMessage( action.data, state )
          },
          hideOOSPanel: toggleOutOfStockPanelView( action.data ),
          quantity: parseInt( action.data.cartSummary.itemCount, 10 )
        }
      }
      else {

        return Object.assign( {},
          state, {
            eligibleForCheckout: true
          }
        )
      }

    case ReduxActionType.CHANGE:

      if( action.meta.form === 'Coupon' && action.meta.field === 'couponName' && has( state.cartPageData, 'appliedCouponSummary.messages.items' )
        && has( state, 'cartPageData.appliedCouponSummary.couponCode' ) &&
        state.cartPageData.appliedCouponSummary.couponCode.toUpperCase() !== action.payload.toUpperCase() ){
        return {
          ...state,
          cartPageData: {
            ...state.cartPageData,
            appliedCouponSummary:{
              ...state.cartPageData.appliedCouponSummary,
              messages:null
            }
          }
        }
      }
      else {
        return {
          ...state
        }
      }

    case MiniCartTypes.RESET_CHECKOUT_ELIGIBILITY:


      return Object.assign(
        {},
        state,
        {
          eligibleForCheckout: false
        }
      )

    case getServiceType( 'initiateCheckout', 'failure' ):

      return state

    // Data from service to populate the shopping cart count
    case getServiceType( 'user', 'success' ):

      return {
        ...state,
        quantity: parseInt( action.data.cart.itemCount, 10 ) // Updated based on v2 user lite services
      }

    case getServiceType( 'switches', 'success' ):
      return {
        ...state,
        switchesDataAvailable: true
      }

    case getServiceType( 'loadCart', 'requested' ):
    case serviceTypes.SESSION_TIMEOUT:
      return {
        ...state,
        cartDataAvailable: false
      }

    case getServiceType( 'loadCart', 'loading' ):
      return {
        ...state,
        cartPageData:{
          ...state.cartPageData,
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        }
      }

    // Data from service to populate the cart data
    case getServiceType( 'loadCart', 'success' ):

      if( has( action.data, 'appliedCouponSummary' ) && ( action.data.appliedCouponSummary.couponAppliedStatus === false ) ){
        return {
          ...state,
          cartPageData: {
            ...action.data,
            appliedCouponSummary: action.data.appliedCouponSummary,
            messages: serverMessage( action.data, state ),
            removedItems: serverRemovedItemMessage( action.data, state ),
            updatedItems: serverUpdatedItemMessage( action.data, state )
          },
          hideOOSPanel: toggleOutOfStockPanelView( action.data ),
          giftText: action.data.giftOptions.giftNote !== null ? action.data.giftOptions.giftNote : '',
          giftBoxToggle: action.data.giftOptions.giftBoxSelected,
          quantity: parseInt( action.data.cartSummary.itemCount, 10 ),
          cartDataAvailable: true,
          cartRightPanelCollapse : toggleSampleProductRightPanelCollapse( action.data, state )

        }
      }
      else {
        return {
          ...state,
          cartPageData:{
            ...action.data,
            messages: serverMessage( action.data, state ),
            removedItems: serverRemovedItemMessage( action.data, state ),
            updatedItems: serverUpdatedItemMessage( action.data, state )
          },
          hideOOSPanel: toggleOutOfStockPanelView( action.data ),
          giftText: action.data.giftOptions.giftNote !== null ? action.data.giftOptions.giftNote : '',
          giftBoxToggle: action.data.giftOptions.giftBoxSelected,
          quantity: parseInt( action.data.cartSummary.itemCount, 10 ),
          cartDataAvailable: true,
          cartRightPanelCollapse : toggleSampleProductRightPanelCollapse( action.data, state )

        }
      }





    case getServiceType( 'session', 'success' ):
      return {
        ...state
      }


    case getServiceType( 'addGiftNote', 'success' ):
      try {
        return {
          ...state,
          cartPageData:{
            ...action.data,
            messages: serverMessage( action.data, state ),
            removedItems: serverRemovedItemMessage( action.data, state ),
            updatedItems: serverUpdatedItemMessage( action.data, state )
          },
          hideOOSPanel: toggleOutOfStockPanelView( action.data ),
          giftText: action.data.giftOptions.giftNote,
          quantity: parseInt( action.data.cartSummary.itemCount, 10 ),
          giftTextChange: false
        }
      }
      catch ( e ){

      }
    case getServiceType( 'addGiftNote', 'failure' ):

      return {
        ...state
      }

    case getServiceType( 'applyPayment', 'success' ):
      return {
        ...state,
        cartPageData: {
          ...state.cartPageData,
          cartSummary: action.data.cartSummary
        }
      }

    case getServiceType( 'applyExpressPayment', 'success' ):
      if( !action.data.result ){
        return {
          ...state,
          cartPageData:{
            ...action.data,
            messages: serverMessage( action.data, state ),
            removedItems: serverRemovedItemMessage( action.data, state ),
            updatedItems: serverUpdatedItemMessage( action.data, state )
          },
          hideOOSPanel: toggleOutOfStockPanelView( action.data ),
          quantity: parseInt( action.data.cartSummary.itemCount, 10 ),
          chkoutbtnClk: true
        }
      }
      else {
        return Object.assign( {},
          state, {
            chkoutbtnClk: true,
            eligibleForCheckout: true
          }
        )
      }

    case getServiceType( 'applyExpressPaymentSameSession', 'success' ):
      if( !action.data.result ){
        return {
          ...state,
          cartPageData:{
            ...action.data,
            messages: serverMessage( action.data, state ),
            removedItems: serverRemovedItemMessage( action.data, state ),
            updatedItems: serverUpdatedItemMessage( action.data, state )
          },
          hideOOSPanel: toggleOutOfStockPanelView( action.data ),
          quantity: parseInt( action.data.cartSummary.itemCount, 10 ),
          chkoutbtnClk: true
        }
      }
      else {
        return Object.assign( {},
          state, {
            chkoutbtnClk: true,
            eligibleForCheckout: true
          }
        )
      }

    case getServiceType( 'addGiftWrap', 'success' ):
      try {
        return {
          ...state,
          cartPageData:{
            ...action.data,
            messages: serverMessage( action.data, state ),
            removedItems: serverRemovedItemMessage( action.data, state ),
            updatedItems: serverUpdatedItemMessage( action.data, state )
          },
          hideOOSPanel: toggleOutOfStockPanelView( action.data ),
          giftBoxToggle: action.data.giftOptions.giftBoxSelected,
          quantity: parseInt( action.data.cartSummary.itemCount, 10 )
        }
      }
      catch ( e ){


      }
    case getServiceType( 'addGiftWrap', 'failure' ):

      return {
        ...state
      }


    case getServiceType( 'addProductSamples', 'success' ):
      try {
        if( action.data.cartItems ){
          return {
            ...state,
            cartPageData:{
              ...action.data,
              messages: serverMessage( action.data, state ),
              removedItems: serverRemovedItemMessage( action.data, state ),
              updatedItems: serverUpdatedItemMessage( action.data, state )
            },
            hideOOSPanel: toggleOutOfStockPanelView( action.data ),
            quantity: parseInt( action.data.cartSummary.itemCount, 10 )
          }
        }

      }
      catch ( e ){
      }
    case getServiceType( 'addProductSamples', 'failure' ):

      return {
        ...state
      }

    case getServiceType( 'productRecs', 'success' ):
      try {
        if( action.data.recommendedProducts !== undefined ){
          return {
            ...state,
            recommendedProducts: action.data
          }
        }

      }
      catch ( e ){

      }
    case getServiceType( 'productRecs', 'failure' ):
      return {
        ...state
      }

    case getServiceType( 'paypalToken', 'success' ):
      if( !isUndefined( action.data.result ) && action.data.result === 'Error' ){
        return {
          ...state
        }
      }
      else {
        return {
          ...state,
          payPalClientToken: action.data.payPalClientToken
        }
      }

    case getServiceType( 'paypalToken', 'loading' ):
      return {
        ...state,
        payPalClientToken: undefined
      }

    case getServiceType( 'removeItemFromCart', 'success' ):
      try {
        if( action.data.type.cartItems ){
          return {
            ...state,
            cartPageData: {
              ...action.data.type,
              messages: serverMessage( action.data.type, state ),
              removedItems: serverRemovedItemMessage( action.data.type, state ),
              updatedItems: serverUpdatedItemMessage( action.data.type, state )
            },
            hideOOSPanel: toggleOutOfStockPanelView( action.data.type ),
            removingItem: '',
            quantity: parseInt( action.data.type.cartSummary.itemCount, 10 )
          }
        }
        else {
          return {
            ...state,
            errorRemoving: action.data.type.messages && action.data.type.messages.items[0].messageDesc,
            removingItem: action.data.item,
            quantity: parseInt( action.data.type.cartSummary.itemCount, 10 )
          }
        }
      }
      catch ( e ){
      }
    case getServiceType( 'removeItemFromCart', 'failure' ):
      return {
        ...state,
        errorRemoving: '',
        removingItem: '',
        removeItem: false
      }
    case getServiceType( 'removeItemFromCart', 'loading' ):
      return {
        ...state,
        errorRemoving: '',
        removingItem: action.data,
        removeItem: true
      }
    case getServiceType( 'updateCartItems', 'success' ):
      return {
        ...state,
        cartPageData:{
          ...action.data,
          messages: serverMessage( action.data, state ),
          removedItems: serverRemovedItemMessage( action.data, state ),
          updatedItems: serverUpdatedItemMessage( action.data, state )
        },
        hideOOSPanel: toggleOutOfStockPanelView( action.data ),
        quantity: parseInt( action.data.cartSummary.itemCount, 10 ),
        removeItem: false
      }

    case getServiceType( 'removeProductSamples', 'success' ):

      try {
        if( action.data.cartItems ){
          return {
            ...state,
            cartPageData:{
              ...action.data,
              messages: serverMessage( action.data, state ),
              removedItems: serverRemovedItemMessage( action.data, state ),
              updatedItems: serverUpdatedItemMessage( action.data, state )
            },
            hideOOSPanel: toggleOutOfStockPanelView( action.data ),
            quantity: parseInt( action.data.cartSummary.itemCount, 10 )
          }
        }

      }
      catch ( e ){

      }
      return {
        ...state
      }
    case getServiceType( 'removeProductSamples', 'failure' ):

      return {
        ...state
      }


    case getServiceType( 'applycoupon', 'success' ):

      if( has( action.data, 'cartSummary' ) ){
        return {
          ...state,
          cartPageData:{
            ...action.data,
            messages: serverMessage( action.data, state ),
            removedItems: serverRemovedItemMessage( action.data, state ),
            updatedItems: serverUpdatedItemMessage( action.data, state )
          },
          hideOOSPanel: toggleOutOfStockPanelView( action.data ),
          quantity: parseInt( ( action.data.cartSummary || {} ).itemCount || 0, 10 ),
          couponApplying: false
        }
      }

    case getServiceType( 'applycoupon', 'failure' ):
      return {
        ...state,
        couponApplying:false
      }

    case getServiceType( 'removecoupon', 'success' ):
      if( has( action.data, 'cartSummary' ) ){
        return {
          ...state,
          cartPageData:{
            ...action.data,
            messages: serverMessage( action.data, state ),
            removedItems: serverRemovedItemMessage( action.data, state ),
            updatedItems: serverUpdatedItemMessage( action.data, state )
          },
          hideOOSPanel: toggleOutOfStockPanelView( action.data ),
          quantity: parseInt( ( action.data.cartSummary || {} ).itemCount || 0, 10 ),
          couponApplying: false,
          isCouponRemoved : true
        }
      }
      else {
        return {
          ...state,
          isCouponRemoved : true
        }
      }


    case getServiceType( 'removecoupon', 'failure' ):
      return {
        ...state
      }
    case getServiceType( 'applycoupon', 'loading' ):
      try {
        return {
          ...state,
          couponApplying:true,
          isCouponRemoved : false
        }
      }
      catch ( e ){

      }

    case MiniCartTypes.CLEAR_COUPON_ERROR:
      let cartPageData =  state.cartPageData;
      delete cartPageData.appliedCouponSummary
      cartPageData.appliedCouponSummary = {
        couponAppliedStatus: 'Initial' }
      return {
        ...state,
        cartPageData

      }

    case getServiceType( 'removeGiftFromCart', 'success' ):
      return {
        ...state,
        cartPageData:{
          ...action.data,
          messages: serverMessage( action.data, state ),
          removedItems: serverRemovedItemMessage( action.data, state ),
          updatedItems: serverUpdatedItemMessage( action.data, state )
        },
        hideOOSPanel: toggleOutOfStockPanelView( action.data ),
        quantity: parseInt( action.data.cartSummary.itemCount, 10 )
      }
    case getServiceType( 'removeGiftFromCart', 'failure' ):
      return {
        ...state
      }
    case getServiceType( 'addItemToCart', 'success' ):
      return {
        ...state,
        cartPageData:{
          ...action.data,
          messages: serverMessage( action.data, state ),
          removedItems: serverRemovedItemMessage( action.data, state ),
          updatedItems: serverUpdatedItemMessage( action.data, state )
        },
        hideOOSPanel: toggleOutOfStockPanelView( action.data ),
        quantity: parseInt( action.data.cartSummary.itemCount, 10 )

      }
    case getServiceType( 'addItemToCart', 'failure' ):
      return {
        ...state

      }
    case getServiceType( 'selectGiftVariant', 'success' ):
      return {
        ...state,
        cartPageData:{
          ...action.data,
          messages: serverMessage( action.data, state ),
          removedItems: serverRemovedItemMessage( action.data, state ),
          updatedItems: serverUpdatedItemMessage( action.data, state )
        },
        hideOOSPanel: toggleOutOfStockPanelView( action.data ),
        quantity: parseInt( action.data.cartSummary.itemCount, 10 )
      }
    case getServiceType( 'selectGiftVariant', 'failure' ):
      return {
        ...state
      }

    case MiniCartTypes.SET_GIFT_MESSAGE:
      return Object.assign( {},
        state, {
          giftText: action.text,
          giftTextChange: true
        }
      )

    case MiniCartTypes.SET_GIFT_BOX_TOGGLE_STATE:
      return Object.assign( {},
        state, {
          giftBoxToggle: action.status
        }
      )
    case MiniCartTypes.SET_CHKOUT_BTN_STATE:
      return Object.assign( {},
        state, {
          chkoutbtnClk: action.status
        }
      )
    case MiniCartTypes.SET_COUPON_OFFER_REQ:
      return Object.assign( {},
        state, {
          couponOfferReqMet: action.status
        }
      )
    case MiniCartTypes.SHOW_BAG_SUMMARY:
      return Object.assign( {},
        state, {
          showBagSummary: action.status
        }
      )
    case MiniCartTypes.SET_PRODUCT_SAMPLE:
      return Object.assign( {},
        state, {
          productSampleCatalogID: action.catalogId
        }
      )

    case MiniCartTypes.CART_RIGHT_PANEL_COLLAPSE:
      return {
        ...state,
        cartRightPanelCollapse: toggleCartPageRightPanelOptionsCollapse( action.panelID, state )
      }

    // ToDo we need this at later point of time
    case MiniCartTypes.UPDATE_CART:
      return Object.assign( {},
        state, {
          arg: action.arg
        }
      )
    case MiniCartTypes.ADD_TO_CART:
      return Object.assign( {},
        state, {
          item: action.item
        }
      )
    case MiniCartTypes.REMOVE_FROM_CART:
      return Object.assign( {},
        state, {
          item: action.item
        }
      )


    case MiniCartTypes.OPEN_CART:
      return Object.assign( {},
        state, {}
      )
    case MiniCartTypes.HIDE_OUT_OF_STOCK_PANEL:
      return {
        ...state,
        cartPageData:{
          ...state.cartPageData,
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        }
      }

    case getServiceType( 'login', 'success' ):
      if( has( action.data, 'success' ) ){
        if( action.data.success === 'true' ){
          return {
            ...state,
            cartSignIn: true

          }
        }
      }

    case MiniCartTypes.FOCUS_GIFT_BOX:
      return {
        ...state,
        giftBoxActiveFlag: true
      }

    case MiniCartTypes.BLUR_GIFT_BOX:
      return {
        ...state,
        giftBoxActiveFlag: false
      }
    default:
      return state;
  }
};

export default function reducer( state = initialState, action ){
  return reducerSwitch( state, action, serverMessage, serverUpdatedItemMessage, serverRemovedItemMessage )
}

export const toggleCartPageRightPanelOptionsCollapse = ( panelID, state ) => {
  let panelsOpened = {}
  _.forIn( state.cartRightPanelCollapse, ( val, key ) => {
    if( panelID === key ){
      panelsOpened[ key ] = !val;
    }
    else {
      panelsOpened[ key ] = val;

    }
  } );
  return panelsOpened;
}

export const toggleSampleProductRightPanelCollapse = ( cartPageData, state ) => {
  let cartRightPanelCollapse = null;
  if( has( cartPageData, 'freeSamplesInfo.items' ) ){
    cartPageData.freeSamplesInfo.items.filter( ( samples, index ) => {
      {
        if( samples.selected && ! isEmpty( samples.shippingRestriction )
          && cartPageData.showShippingRestrictionMsg ){
          cartRightPanelCollapse = {
            ...state.cartRightPanelCollapse,
            samples:true
          }
        }
      }
    } )
  }
  if( cartRightPanelCollapse ){
    return cartRightPanelCollapse;
  }
  return state.cartRightPanelCollapse;
}


export const toggleOutOfStockPanelView = ( cartPageData ) =>{
  if( ( cartPageData.cartItems && cartPageData.cartItems.items.filter( cartItem => ( cartItem.displayType === 'removed' || cartItem.displayType === 'updated' ) ).length > 0 ) || cartPageData.messages ){
    return false;
  }

}

export const serverMessage = ( data, state ) => {
  // if both response mesagse and message in state exist concatenate and return.
  // else return response if no message exist in state
  if( !isEmpty( data.messages ) ){
    if( state.cartPageData.messages ){
      return { items: concat( state.cartPageData.messages.items, data.messages.items ) };
    }
    else {
      return data.messages ;
    }
  }
  else {
    return state.cartPageData.messages;
  }

}
export const serverRemovedItemMessage = ( data, state ) => {
  // if removed items exist in the action payload, add it to the existing list of removed items in the state,
  // else return the removedItems
  const currentRemovedItems = data.cartItems && data.cartItems.items.filter( cartItem => cartItem.displayType === 'removed' );

  if( !isEmpty( currentRemovedItems ) ){
    if( state.cartPageData.removedItems ){
      return concat( state.cartPageData.removedItems, currentRemovedItems );
    }
    else {
      return currentRemovedItems;
    }
  }
  else {
    return state.cartPageData.removedItems;
  }
}

export const serverUpdatedItemMessage = ( data, state ) => {
  // if updated items exist in the action payload, add it to the existing list of updated items in the state,
  // else return the updatedItems
  const currentUpdatedItems = data.cartItems && data.cartItems.items.filter( cartItem => cartItem.displayType === 'updated' );

  if( !isEmpty( currentUpdatedItems ) ){

    if( state.cartPageData.updatedItems ){
      return concat( state.cartPageData.updatedItems, currentUpdatedItems );
    }
    else {
      return currentUpdatedItems;
    }
  }
  else {
    return state.cartPageData.updatedItems;
  }



}
export const getMiniCartState = state => state.minicart;

