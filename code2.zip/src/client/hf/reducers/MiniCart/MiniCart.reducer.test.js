import reducer, {
  initialState,
  reducerSwitch,
  toggleOutOfStockPanelView,
  serverMessage,
  serverRemovedItemMessage,
  serverUpdatedItemMessage,
  toggleSampleProductRightPanelCollapse
} from './MiniCart.reducer';

import {
  types
} from 'hf/actions/MiniCart/MiniCart.actions';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition,
  types as serviceTypes
} from 'shared/actions/Services/Services.actions';

import _ from 'lodash';

import {
  actionTypes as ReduxActionType
} from 'redux-form';

import concat from 'lodash/concat';

const serverMessageMock = jest.fn();
const serverRemovedItemMessageMock = jest.fn();
const serverUpdatedItemMessageMock = jest.fn();
const state={
  cartPageData:{
    messages:null,
    removedItems: undefined,
    updatedItems: undefined
  }
}

describe( 'MiniCart reducer', ( ) => {

  registerServiceName( 'user' );
  registerServiceName( 'loadCart' );
  registerServiceName( 'addProductSamples' );
  registerServiceName( 'removeProductSamples' );
  registerServiceName( 'removeItemFromCart' );
  registerServiceName( 'updateCartItems' );
  registerServiceName( 'removeGiftFromCart' );
  registerServiceName( 'addItemToCart' );
  registerServiceName( 'selectGiftVariant' );
  registerServiceName( 'addGiftNote' );
  registerServiceName( 'addGiftWrap' );
  registerServiceName( 'applycoupon' );
  registerServiceName( 'removecoupon' );
  registerServiceName( 'initiateCheckout' );
  registerServiceName( 'switches' );
  registerServiceName( 'applyExpressPayment' );
  registerServiceName( 'applyExpressPaymentSameSession' );
  registerServiceName( 'productrecs' );
  registerServiceName( 'applyPayment' );
  registerServiceName( 'paypalToken' );
  registerServiceName( 'login' );



  it( 'should have the proper default state', ( ) => {
    let expectedState = {
      cartDataAvailable: false,
      switchesDataAvailable: false,
      quantity: undefined,
      giftText: '',
      giftBoxToggle: false,
      cartPageData: {
        messages: null,
        removedItems: undefined,
        updatedItems: undefined
      },
      recommendedProducts: {},
      chkoutbtnClk: false,
      eligibleForCheckout: false,
      showBagSummary: false,
      removingItem: '',
      couponOfferReqMet: false,
      productSampleCatalogID: '-1',
      cartRightPanelCollapse: {
        userRewards:false,
        samples: false,
        gifts: false,
        coupons: false,
        giftCard: false
      },
      errorRemoving: '',
      giftTextChange: false,
      hideOOSPanel: false,
      cartSignIn:false,
      payPalClientToken: undefined
    }

    expect( initialState ).toEqual( expectedState );

  } );

  it( 'should be a function', ( ) => {
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  describe( 'User data successfullly loaded', ( ) => {
    it( 'should set the cart quantity', ( ) => {
      let res = {
        cart: {
          itemCount: 33
        }
      }

      let actionCreator = {
        type: getServiceType( 'user', 'success' ),
        data: res
      }

      let expectedOutput = {
        quantity: 33
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );
  } );


  describe( 'product related test cases', ( ) => {
    it( 'should set the product recommendation data', ( ) => {
      let res = {
        recommendedProducts: {}
      }
      let actionCreator = {
        type: getServiceType( 'productrecs', 'success' ),
        data: res
      }

      let expectedOutput = {
        'recommendedProducts': {
          'recommendedProducts': {}
        }
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'Product samples failure event', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addProductSamples', 'success' )
      };
      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'product recommendation failure event', ( ) => {
      let actionCreator = {
        type: getServiceType( 'productRecs', 'failure' )
      };
      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );
  describe( 'CartPage Data successfullly loaded', ( ) => {
    it( 'should set the cart quantity', ( ) => {
      let res = {
        cartPageData: {
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: null,
            giftBoxSelected: false
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data: res.cartPageData
      }

      let expectedOutput = {
        cartDataAvailable: true,
        cartPageData: {
          cartSummary: {},
          giftOptions: {
            giftBoxSelected: false,
            giftNote: null
          },
          messages: null
        },
        giftBoxToggle: false,
        giftText: '',
        hideOOSPanel: undefined,
        quantity: NaN
      }
      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should call serverMessage function after loadCart success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data:{
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: null,
            giftBoxSelected: false
          }
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock );
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );

    it( 'load cart success when couponAppliedStatus is false', ( ) => {
      let res = {
        cartPageData: {
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: null,
            giftBoxSelected: false
          },
          appliedCouponSummary: {
            couponAppliedStatus: false
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data: res.cartPageData
      }

      let expectedOutput = {
        cartDataAvailable: true,
        cartPageData: {
          cartSummary: {},
          giftOptions: {
            giftBoxSelected: false,
            giftNote: null
          },
          messages: null,
          appliedCouponSummary: {
            couponAppliedStatus: false
          },
          removedItems: undefined,
          updatedItems: undefined
        },
        cartRightPanelCollapse : undefined,
        giftBoxToggle: false,
        giftText: '',
        hideOOSPanel: undefined,
        quantity: NaN
      }
      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'load cart success', ( ) => {
      let res = {
        cartPageData: {
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: 'Happy Birthday',
            giftBoxSelected: false
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data: res.cartPageData
      }

      let expectedOutput = {
        cartDataAvailable: true,
        cartPageData: {
          cartSummary: {},
          giftOptions: {
            giftBoxSelected: false,
            giftNote: 'Happy Birthday'
          },
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        },
        cartRightPanelCollapse: undefined,
        giftBoxToggle: false,
        giftText: 'Happy Birthday',
        hideOOSPanel: undefined,
        quantity: NaN
      }
      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'remove item Data successfullly loaded', ( ) => {
    it( 'should set the cart quantity to empty on success', ( ) => {
      let res = {
        type: {
          cartItems: {
            'items': [
              {
                'displayType': 'default',
                'couponApplied': false,
                'brandName': 'Jack Black',
                'quantity': {
                  'messages': null,
                  'value': 10
                },
                'productId': 'xlsImpprod3730155',
                'excludedFromCoupon': false,
                'adbugMessageMap': null,
                'catalogRefId': '2211507',
                'categoryName': 'Shaving Cream & Razors',
                'commerceItemid': 'ci15804000058',
                'priceInfo': {
                  'salePrice': null,
                  'regularPrice': '$170.00',
                  'bfxPriceMap': [
                    {
                      'bfxQty': '10',
                      'bfxPrice': '$17.00'
                    }
                  ],
                  'unitPriceMessage': '10 @ $17.00',
                  'messages': null
                },
                'productDisplayName': 'Beard Lube Conditioning Shave',
                'imageURL': 'https://images.ulta.com/is/image/Ulta/2211507?$md$',
                'variantInfo': {
                  'Size': '6.0 oz'
                },
                'skuDisplayName': 'Beard Lube Conditioning Shave',
                'shippingRestriction': null,
                'maxQty': 10,
                'productURL': '/beard-lube-conditioning-shave?productId=xlsImpprod3730155&sku=2211507',
                'messages': null
              }
            ]
          },
          cartSummary: {
            itemCount: 3
          },
          messages: null
        },
        removingItem: ''
      }

      let actionCreator = {
        type: getServiceType( 'removeItemFromCart', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartItems':  {
            'items': [
              {
                'displayType': 'default',
                'couponApplied': false,
                'brandName': 'Jack Black',
                'quantity': {
                  'messages': null,
                  'value': 10
                },
                'productId': 'xlsImpprod3730155',
                'excludedFromCoupon': false,
                'adbugMessageMap': null,
                'catalogRefId': '2211507',
                'categoryName': 'Shaving Cream & Razors',
                'commerceItemid': 'ci15804000058',
                'priceInfo': {
                  'salePrice': null,
                  'regularPrice': '$170.00',
                  'bfxPriceMap': [
                    {
                      'bfxQty': '10',
                      'bfxPrice': '$17.00'
                    }
                  ],
                  'unitPriceMessage': '10 @ $17.00',
                  'messages': null
                },
                'productDisplayName': 'Beard Lube Conditioning Shave',
                'imageURL': 'https://images.ulta.com/is/image/Ulta/2211507?$md$',
                'variantInfo': {
                  'Size': '6.0 oz'
                },
                'skuDisplayName': 'Beard Lube Conditioning Shave',
                'shippingRestriction': null,
                'maxQty': 10,
                'productURL': '/beard-lube-conditioning-shave?productId=xlsImpprod3730155&sku=2211507',
                'messages': null
              }
            ]
          },
          'cartSummary': {
            'itemCount': 3
          },
          'messages':null,
          'removedItems': undefined,
          'updateItems': undefined
        },
        'quantity': 3,
        'hideOOSPanel': undefined,
        'removingItem': ''
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'should call serverMessage function after removeItemFromCart success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removeItemFromCart', 'success' ),
        data: {
          type: {
            cartItems: [],
            cartSummary: {
              itemCount: 3
            },
            messages: null
          },
          removingItem: ''
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock )
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );

    it( 'should set the cart quantity to empty if no item is in cart', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removeItemFromCart', 'success' ),
        data: {
          type: {
            cartItems: null,
            cartSummary: {
              itemCount: 0
            },
            messages: null
          },
          removingItem: ''
        }
      }

      let expectedOutput = {
        cartPageData:  {
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        },
        errorRemoving: null,
        quantity: 0,
        removingItem: undefined
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set the cart quantity to empty on success1', ( ) => {
      let res = {
        cartSummary: {
          itemCount: 3
        },
        messages: null
      }

      let actionCreator = {
        type: getServiceType( 'removeGiftFromCart', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartSummary': {
            'itemCount': 3
          },
          'messages': null
        },
        'hideOOSPanel': undefined,
        'quantity': 3
      }


      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'should call serverMessage function after removeGiftFromCart success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removeGiftFromCart', 'success' ),
        data: {
          cartSummary: {
            itemCount: 3
          },
          messages: null
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock )
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );
    it( 'RemoveGiftFromCart failure', ( ) => {

      let res1 = '';

      let actionCreator1 = {
        type: getServiceType( 'removeGiftFromCart', 'failure' )
      }

      let expectedOutput1 = {}

      expect( reducer( {}, actionCreator1 ) ).toEqual( expectedOutput1 );

    } );


    it( 'should set the cart quantity on loading', ( ) => {

      let res1 = '';

      let actionCreator1 = {
        type: getServiceType( 'removeItemFromCart', 'loading' ),
        data: res1
      }


      let expectedOutput1 = {
        'removingItem': '',
        'errorRemoving': '',
        removeItem: true
      }

      expect( reducer( {}, actionCreator1 ) ).toEqual( expectedOutput1 );

    } );

    it( 'should set the cart quantity to empty on failure', ( ) => {
      let res = {}

      let actionCreator2 = {
        type: getServiceType( 'removeItemFromCart', 'failure' ),
        data: res
      }

      let expectedOutput2 = {
        'removingItem': '',
        'errorRemoving': '',
        removeItem: false
      }

      expect( reducer( {}, actionCreator2 ) ).toEqual( expectedOutput2 );

    } );
  } );
  describe( 'Coupons applied and removed', ( ) => {

    it( 'apply coupon loading', ( ) => {
      let res = {}
      const actionCreator2 = {
        type: getServiceType( 'applycoupon', 'loading' ),
        data: res,
        couponOfferReqNotMet: false
      }
      let expectedOutput = {
        couponApplying:true,
        isCouponRemoved : false
      }
      expect( reducer( {}, actionCreator2 ) ).toEqual( expectedOutput );

    } );


    it( 'should apply coupon to cart on success', ( ) => {
      let res = {
        appliedCouponSummary: {
          couponOfferReqNotMet: false
        },
        cartSummary: {
          itemCount: 3
        },
        messages:null
      }
      let couponOfferReqMet = false;
      let actionCreator2 = {
        type: getServiceType( 'applycoupon', 'success' ),
        data: res,
        couponOfferReqNotMet: false
      }
      let expectedOutput = {
        'cartPageData': {
          'appliedCouponSummary': {
            'couponOfferReqNotMet': false
          },
          'cartSummary': {
            'itemCount': 3
          },
          'messages': null
        },
        'couponApplying': false,
        'hideOOSPanel': undefined,
        'quantity': 3
      }
      expect( reducer( state, actionCreator2 ) ).toEqual( expectedOutput );

    } );
    it( 'should rermove coupon from cart on success', ( ) => {
      let res = {
        appliedCouponSummary: {
          couponOfferReqNotMet: false
        },
        cartSummary: {
          itemCount: 3
        },
        messages: null
      }
      let couponOfferReqMet = false;
      let actionCreator2 = {
        type: getServiceType( 'removecoupon', 'success' ),
        data: res,
        couponOfferReqNotMet: false
      }
      let expectedOutput = {
        'cartPageData': {
          'appliedCouponSummary': {
            'couponOfferReqNotMet': false
          },
          'cartSummary': {
            'itemCount': 3
          },
          'messages': null
        },
        'couponApplying': false,
        'hideOOSPanel': undefined,
        'isCouponRemoved':true,
        'quantity': 3
      }
      expect( reducer( state, actionCreator2 ) ).toEqual( expectedOutput );
    } );

    it( 'should call serverMessage function after removecoupon success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removecoupon', 'success' ),
        data: {
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          messages: null
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock )
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );

    it( 'should set isCouponRemoved after removecoupon success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removecoupon', 'success' )
      }
      let expectedOutput = {
        isCouponRemoved : true
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Remove coupon failure', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removecoupon', 'failure' )
      }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should call serverMessage function', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applycoupon', 'success' ),
        data:{
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          messages:null
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock )
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );

    it( 'should set couponApplying after applycoupon failure', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applycoupon', 'failure' )
      }
      let expectedOutput ={
        couponApplying: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should clear coupon error message upon change in coupon formdata', () => {
      let state = {
        cartPageData:{
          'appliedCouponSummary': {
            couponCode:'test',
            messages:{
              items:[
                {
                  type:'Error',
                  message:'code is invalid'
                }
              ]
            }
          }
        }
      }
      let action = {
        type: ReduxActionType.CHANGE,
        meta:{
          form:'Coupon',
          field:'couponName'
        },
        payload: 'tes'
      }
      let expectedOutput ={
        cartPageData:{
          'appliedCouponSummary': {
            couponCode:'test',
            messages:null
          }
        }
      }
      expect( reducer( state, action ) ).toEqual( expectedOutput );
    } );

    it( 'should not clear coupon error message if there is no change in form data', () => {
      let state = {
        cartPageData:{
          'appliedCouponSummary': {
            couponCode:'test',
            messages:{
              items:[
                {
                  type:'Error',
                  message:'code is invalid'
                }
              ]
            }
          }
        }
      }
      let action = {
        type: ReduxActionType.CHANGE,
        meta:{
          form:'Coupon',
          field:'couponName'
        },
        payload: 'TEST'
      }
      let expectedOutput ={
        cartPageData:{
          'appliedCouponSummary': {
            couponCode:'test',
            messages:{
              items:[
                {
                  type:'Error',
                  message:'code is invalid'
                }
              ]
            }
          }
        }
      }
      expect( reducer( state, action ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'SET_COUPON_OFFER_REQ', ( ) => {


    let actionCreator = {
      type: types.SET_COUPON_OFFER_REQ
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );
  describe( 'OPEN_CART', ( ) => {


    let actionCreator = {
      type: types.OPEN_CART
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'HIDE_OUT_OF_STOCK_PANEL', ( ) => {


    let actionCreator = {
      type: types.HIDE_OUT_OF_STOCK_PANEL
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        cartPageData:{
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'CLEAR_COUPON_ERROR', ( ) => {


    let actionCreator = {
      type: types.CLEAR_COUPON_ERROR
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        cartPageData:{
          appliedCouponSummary : {
            couponAppliedStatus: 'Initial'
          },
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        }
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'REMOVE_FROM_CART', ( ) => {

    let actionCreator = {
      type: types.REMOVE_FROM_CART
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );


  describe( 'ADD TO CART', ( ) => {
    let item = {
      price: '$2221',
      title: 'awer'
    }

    let actionCreator = {
      type: types.ADD_TO_CART,
      item
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        item: { ...item }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );


  describe( 'REMOVE_FROM_CART', ( ) => {

    let actionCreator = {
      type: types.REMOVE_FROM_CART
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'ADD_TO_CART', ( ) => {

    let actionCreator = {
      type: types.ADD_TO_CART
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'SELECT_GIFT_VARIANT', ( ) => {

    let actionCreator = {
      type: types.SELECT_GIFT_VARIANT
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );


  describe( 'UPDATE_CART', ( ) => {

    let item = {
      somekey: 333
    }
    let actionCreator = {
      type: types.UPDATE_CART,
      item
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'SET_GIFT_MESSAGE', ( ) => {

    let text = 'GiftWrap Selected';
    let actionCreator = {
      type: types.SET_GIFT_MESSAGE,
      text
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        giftText: 'GiftWrap Selected',
        giftTextChange: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );


  describe( 'SET_GIFT_BOX_TOGGLE_STATE', ( ) => {

    let status = true;
    let actionCreator = {
      type: types.SET_GIFT_BOX_TOGGLE_STATE,
      status
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        giftBoxToggle: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );


  describe( 'SET_CHKOUT_BTN_STATE', ( ) => {

    let status = true;
    let actionCreator = {
      type: types.SET_CHKOUT_BTN_STATE,
      status
    }
    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        chkoutbtnClk: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'SHOW_BAG_SUMMARY', ( ) => {

    let status = true;
    let actionCreator = {
      type: types.SHOW_BAG_SUMMARY,
      status
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        showBagSummary: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'Product Sample added successfully', ( ) => {

    it( 'should set the selected Product Sample', ( ) => {
      let res = {
        cartSummary: {
          itemCount: 3
        },
        cartItems: {
          'items': [
            {
              'displayType': 'default',
              'couponApplied': false,
              'brandName': 'Jack Black',
              'quantity': {
                'messages': null,
                'value': 10
              },
              'productId': 'xlsImpprod3730155',
              'excludedFromCoupon': false,
              'adbugMessageMap': null,
              'catalogRefId': '2211507',
              'categoryName': 'Shaving Cream & Razors',
              'commerceItemid': 'ci15804000058',
              'priceInfo': {
                'salePrice': null,
                'regularPrice': '$170.00',
                'bfxPriceMap': [
                  {
                    'bfxQty': '10',
                    'bfxPrice': '$17.00'
                  }
                ],
                'unitPriceMessage': '10 @ $17.00',
                'messages': null
              },
              'productDisplayName': 'Beard Lube Conditioning Shave',
              'imageURL': 'https://images.ulta.com/is/image/Ulta/2211507?$md$',
              'variantInfo': {
                'Size': '6.0 oz'
              },
              'skuDisplayName': 'Beard Lube Conditioning Shave',
              'shippingRestriction': null,
              'maxQty': 10,
              'productURL': '/beard-lube-conditioning-shave?productId=xlsImpprod3730155&sku=2211507',
              'messages': null
            }
          ]
        },
        freeSampleInfo: {
          freeSamples: [{
            'catalogRefId': '2252998',
            'sampleDesc': 'Fragrance',
            'selected': true
          }]
        },
        messages: null
      }

      let actionCreator = {
        type: getServiceType( 'addProductSamples', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartItems': {
            'items': [
              {
                'displayType': 'default',
                'couponApplied': false,
                'brandName': 'Jack Black',
                'quantity': {
                  'messages': null,
                  'value': 10
                },
                'productId': 'xlsImpprod3730155',
                'excludedFromCoupon': false,
                'adbugMessageMap': null,
                'catalogRefId': '2211507',
                'categoryName': 'Shaving Cream & Razors',
                'commerceItemid': 'ci15804000058',
                'priceInfo': {
                  'salePrice': null,
                  'regularPrice': '$170.00',
                  'bfxPriceMap': [
                    {
                      'bfxQty': '10',
                      'bfxPrice': '$17.00'
                    }
                  ],
                  'unitPriceMessage': '10 @ $17.00',
                  'messages': null
                },
                'productDisplayName': 'Beard Lube Conditioning Shave',
                'imageURL': 'https://images.ulta.com/is/image/Ulta/2211507?$md$',
                'variantInfo': {
                  'Size': '6.0 oz'
                },
                'skuDisplayName': 'Beard Lube Conditioning Shave',
                'shippingRestriction': null,
                'maxQty': 10,
                'productURL': '/beard-lube-conditioning-shave?productId=xlsImpprod3730155&sku=2211507',
                'messages': null
              }
            ]
          },
          'cartSummary': {
            'itemCount': 3
          },
          'freeSampleInfo': {
            'freeSamples': [{
              'catalogRefId': '2252998',
              'sampleDesc': 'Fragrance',
              'selected': true
            }]
          },
          'messages': null,
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'hideOOSPanel': undefined,
        'quantity': 3
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'should call serverMessage function after addProductSamples success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addProductSamples', 'success' ),
        data: {
          cartSummary: {
            itemCount: 3
          },
          cartItems: {},
          freeSampleInfo: {
            freeSamples: [{
              'catalogRefId': '2252998',
              'sampleDesc': 'Fragrance',
              'selected': true
            }]
          },
          messages: null
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock )
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );
  } );

  describe( 'SET_PRODUCT_SAMPLE', ( ) => {

    let catalogId = '1234';
    let actionCreator = {
      type: types.SET_PRODUCT_SAMPLE,
      catalogId
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        productSampleCatalogID: '1234'
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'CART_RIGHT_PANEL_COLLAPSE', ( ) => {
    let state1 = {
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      }
    }
    let panelID = 'gifts';
    let actionCreator = {
      type: types.CART_RIGHT_PANEL_COLLAPSE,
      panelID
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        cartRightPanelCollapse: {
          samples: false,
          gifts: true,
          coupons: false
        }
      };

      expect( reducer( state1, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'initiateCheckout action dipatched sucessfully ', ( ) => {
    it( 'should set the cart quantity to 3', ( ) => {
      let state={
        cartPageData:{
          messages:null,
          removedItems: undefined,
          updatedItems: undefined
        }
      }
      let res = {
        cartSummary: {
          itemCount: 3
        },
        messages: {
          items:[{ 'message':'cart' }]
        }
      }

      let actionCreator = {
        type: getServiceType( 'initiateCheckout', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartSummary': {
            'itemCount': 3
          },
          'messages': {
            'items':[{ 'message':'cart' }]
          },
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'hideOOSPanel' : false,
        'quantity': 3
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'If the result is empty then eligibilty should be true', ( ) => {
      let actionCreator = {
        type: getServiceType( 'initiateCheckout', 'success' ),
        data:{
          result:{}
        }
      }
      let expectedOutput = { eligibleForCheckout:true };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should call serverMessage function', ( ) => {
      let actionCreator = {
        type: getServiceType( 'initiateCheckout', 'success' ),
        data:{
          cartSummary:{
            itemCount:10
          }
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock )
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );
    it( 'Intiate Checkout failure event ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'initiateCheckout', 'failure' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Reset Checkout eligibility ', ( ) => {
      let actionCreator = {
        type: types.RESET_CHECKOUT_ELIGIBILITY
      }
      let expectedOutput = { eligibleForCheckout: false };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Payment related testcases', ( ) => {
    it( 'should set the cart quantity to 3', ( ) => {
      let res = {
        cartSummary: {
          itemCount: 3
        },
        messages: null
      }

      let actionCreator = {
        type: getServiceType( 'applyExpressPayment', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartSummary': {
            'itemCount': 3
          },
          'messages': null
        },
        'hideOOSPanel' : undefined,
        'quantity': 3,
        'chkoutbtnClk': true
      }
      const currentState={
        cartPageData:{
          messages:null
        }
      }
      expect( reducer( currentState, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'should call serverMessage function after applyExpressPayment success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applyExpressPayment', 'success' ),
        data: {
          cartSummary: {
            itemCount: 3
          },
          messages: null
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock )
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );
    it( 'Apply Express Payment success which has result object', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applyExpressPayment', 'success' ),
        data:{
          result:{}
        }
      }
      let expectedOutput = { chkoutbtnClk: true, eligibleForCheckout: true };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should set the cart quantity to 3', ( ) => {

      let res = {
        cartSummary: {
          itemCount: 3
        },
        messages: null
      }

      let actionCreator = {
        type: getServiceType( 'applyExpressPaymentSameSession', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartSummary': {
            'itemCount': 3
          },
          'messages': null
        },
        'hideOOSPanel' : undefined,
        'quantity': 3,
        'chkoutbtnClk': true
      }
      const currentState={
        cartPageData:{
          messages:null
        }
      }
      expect( reducer( currentState, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'should call serverMessage function after applyExpressPaymentSameSession success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applyExpressPaymentSameSession', 'success' ),
        data: {
          cartSummary: {
            itemCount: 3
          },
          messages: { messageRef:'cart' }
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock )
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );

    it( 'applyExpressPaymentSameSession success which has result object', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applyExpressPaymentSameSession', 'success' ),
        data:{
          result:{}
        }
      }

      let expectedOutput={ chkoutbtnClk: true, eligibleForCheckout: true };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'apply payment success case', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applyPayment', 'success' ),
        data:{
          cartSummary: {
            itemCount: 3
          }
        }
      }
      let expectedOutput = {
        cartPageData: {
          cartSummary: {
            itemCount: 3
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Switches related cases', ( ) => {
    it( 'switches case is success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'switches', 'success' )
      }
      let expectedOutput = { switchesDataAvailable: true }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );
  describe( 'Add Gift Note and Gift Wrap Test cases', ( ) => {
    it( 'add Gift Note success', ( ) => {
      let state={
        cartPageData:{
          messages:null
        }
      }
      let actionCreator = {
        type: getServiceType( 'addGiftNote', 'success' ),
        data: {
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          giftOptions: {
            giftNote: 'Happy Birthday'
          },
          messages:null
        }
      }
      let expectedOutput = {
        cartPageData: {
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          giftOptions: {
            giftNote: 'Happy Birthday'
          },
          messages:null
        },
        giftText: 'Happy Birthday',
        giftTextChange: false,
        hideOOSPanel: undefined,
        quantity: 3
      }
      // expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock );
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );
    it( 'should call serverMessage function after giftNote success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'giftNote', 'success' ),
        data: {
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          giftOptions: {
            giftNote: 'Happy Birthday'
          },
          messages:null
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock )
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );
    it( 'addGiftNote Failure case', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addGiftNote', 'failure' )
      }
      let expectedOutput = { }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should handle the event and set the state', ( ) => {
      let actionCreator = {
        type: types.FOCUS_GIFT_BOX
      }
      let expectedOutput = {
        giftBoxActiveFlag: true
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should handle the event and set the state', ( ) => {
      let actionCreator = {
        type: types.BLUR_GIFT_BOX
      }
      let expectedOutput = {
        giftBoxActiveFlag: false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should set the cart quantity', ( ) => {
      let state={
        cartPageData:{
          messages:null
        }
      }
      let res = {
        cartSummary: {
          itemCount: 3
        },
        cartPageData: {
          giftOptions: {}
        },
        giftOptions: {
          giftNote: {}
        },
        giftText: {},
        giftBoxToggle: {},
        messages: null
      }


      let actionCreator = {
        type: getServiceType( 'addGiftWrap', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartPageData': {
            'giftOptions': {}
          },
          'cartSummary': {
            'itemCount': 3
          },
          'giftBoxToggle': {},
          'giftOptions': {
            'giftNote': {}
          },
          'giftText': {},
          'messages': null
        },
        'giftBoxToggle': undefined,
        'hideOOSPanel': undefined,
        'quantity': 3
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'should call serverMessage function after addGiftWrap success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addGiftWrap', 'success' ),
        data: {
          cartSummary: {
            itemCount: 3
          },
          cartPageData: {
            giftOptions: {}
          },
          giftOptions: {
            giftNote: {}
          },
          giftText: {},
          giftBoxToggle: {},
          messages: null
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock )
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();

    } );

    it( 'Add Gift Wrap failure case', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addGiftWrap', 'failure' )
      };
      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );
  describe( 'Paypal Token', ( ) => {
    it( 'Paypal Token success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'success' ),
        data: {
          result: 'Error'
        }
      }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Paypal Token success if result is empty', ( ) => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'success' ),
        data: {
          result: '',
          payPalClientToken: undefined
        }
      }
      let expectedOutput = {
        payPalClientToken: undefined
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Paypal Token loading', ( ) => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'loading' )
      }
      let expectedOutput = {
        payPalClientToken: undefined
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );
  describe( 'Remove Product Samples', ( ) => {
    it( 'should rermove coupon from cart on success', ( ) => {
      let res = {
        cartItems:{
          items:[
            {
              'skuId':'12312312'
            }
          ]
        },
        cartSummary: {
          itemCount: 3
        }
      }
      let couponOfferReqMet = false;
      let actionCreator = {
        type: getServiceType( 'removeProductSamples', 'success' ),
        data: res
      }
      let expectedOutput = {
        'cartPageData': {
          'cartItems':{
            'items':[
              {
                'skuId':'12312312'
              }
            ]
          },
          'cartSummary': {
            'itemCount': 3
          },
          'messages': null,
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'hideOOSPanel': undefined,
        'quantity': 3
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Remove Product Samples success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removeProductSamples', 'success' )
      }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Remove Product Samples failure', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removeProductSamples', 'failure' )
      }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );
  describe( 'Update Cart Items', ( ) => {
    it( 'Update Cart Items success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'updateCartItems', 'success' ),
        data: {
          cartSummary: {
            itemCount: 11
          }
        }
      }
      let expectedOutput = {}
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock );
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );
  } );

  describe( 'Add Item To Cart', ( ) => {
    it( 'Add Item To Cart success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addItemToCart', 'success' ),
        data: {
          cartSummary: {
            itemCount: 11
          }
        }
      }
      let expectedOutput = {}
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock );
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );
    it( 'Add Item To Cart failure', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addItemToCart', 'failure' ) }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Select Gift Variant', ( ) => {
    it( 'Select Gift Variant success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'selectGiftVariant', 'success' ),
        data: {
          cartSummary: {
            itemCount: 11
          }
        }
      }
      let expectedOutput = {}
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock, serverRemovedItemMessageMock );
      expect( serverMessageMock ).toBeCalled();
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( serverRemovedItemMessageMock ).toBeCalled();
    } );
    it( 'Select Gift Variant failure', ( ) => {
      let actionCreator = {
        type: getServiceType( 'selectGiftVariant', 'failure' ) }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Login', ( ) => {
    it( 'login success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'login', 'success' ),
        data: {
          success: 'true'
        }
      }
      let expectedOutput = {
        cartSignIn: true
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );
} );

describe( 'tests for toggleOutOfStockPanelView', ( ) => {

  it( 'toggleOutOfStockPanelView should not return false when cart items messages are empty and updated/remove items not present', ( ) => {
    const cartPageData = {
      cartItems:{
        items:[
          {
            'skuId':'12312312'
          }
        ]
      },
      messages:null
    };
    expect( toggleOutOfStockPanelView( cartPageData ) ).not.toBe( false );
  } )

  it( 'toggleOutOfStockPanelView should false when cart data has messages', ( ) => {
    const cartPageData = {
      cartItems:{
        items:[
          {
            'skuId':'12312312'
          }
        ]
      },
      messages:{
        items:[
          {
            'type':'error',
            'message':'cart merged'
          }
        ]
      }
    };
    expect( toggleOutOfStockPanelView( cartPageData ) ).toBe( false );
  } )

  it( 'toggleOutOfStockPanelView should false when updated items not present', ( ) => {
    const cartPageData = {
      cartItems:{
        items:[
          {
            'skuId':'12312312',
            'displayType':'updated'
          }
        ]
      },
      messages:null
    };
    expect( toggleOutOfStockPanelView( cartPageData ) ).toBe( false );
  } )

  it( 'toggleOutOfStockPanelView should false when removed items not present', ( ) => {
    const cartPageData = {
      cartItems:{
        items:[
          {
            'skuId':'12312312',
            'displayType':'removed'
          }
        ]
      },
      messages:null
    };
    expect( toggleOutOfStockPanelView( cartPageData ) ).toBe( false );
  } )

} );

describe( 'tests for serverMessage', ( ) => {

  it( 'if there are no messages in the incoming data should return existing messages in state', ( ) => {
    const data ={};
    const state = {
      cartPageData:{
        messages: {
          items:[
            {
              type:'Info',
              message:'cart merged'
            }
          ]
        }
      }
    }
    expect( serverMessage( data, state ) ).toBe( state.cartPageData.messages );
  } )

  it( 'if there are messages in the incoming data and existing messages in state, it should return the concatenated messages', ( ) => {
    const data ={
      messages: {
        items:[
          {
            type:'Info',
            message:'cart updated'
          }
        ]
      }
    };
    const state = {
      cartPageData:{
        messages: {
          items:[
            {
              type:'Info',
              message:'cart merged'
            }
          ]
        }
      }
    }
    expect( serverMessage( data, state ) ).toEqual( { items: concat( state.cartPageData.messages.items, data.messages.items ) } );
  } )

  it( 'if there are messages in the incoming data and no existing messages in state, it should return the incoming messages', ( ) => {
    const data ={
      messages: {
        items:[
          {
            type:'Info',
            message:'cart updated'
          }
        ]
      }
    };
    const state = {
      cartPageData:{
        messages: null
      }
    }
    expect( serverMessage( data, state ) ).toEqual( data.messages );
  } )
} );


describe( 'tests for serverRemovedItemMessage', ( ) => {

  it( 'if there are no removed items in the incoming data should return removed items in state', ( ) => {
    const data ={
      cartItems:{
        items:[
          {
            skuId:'12312312',
            displayType:'default'
          }
        ]
      }
    };
    const state = {
      cartPageData:{
        removedItems:[
          {
            skuId:'2323232',
            displayType:'removed'
          }
        ]
      }
    }
    expect( serverRemovedItemMessage( data, state ) ).toBe( state.cartPageData.removedItems );
  } )

  it( 'if there are removed items in the incoming data and removed items exist in state, it should return the concatenated items', ( ) => {
    const data ={
      cartItems:{
        items:[
          {
            skuId:'12312312',
            displayType:'removed'
          }
        ]
      }
    };
    const state = {
      cartPageData:{
        removedItems:[
          {
            skuId:'2323232',
            displayType:'removed'
          }
        ]
      }
    }
    expect( serverRemovedItemMessage( data, state ) ).toEqual( concat( state.cartPageData.removedItems, data.cartItems.items ) );

  } )

  it( 'if there are removed items in the incoming data and no removed items in state, it should return the incoming removed items', ( ) => {
    const data ={
      cartItems:{
        items:[
          {
            skuId:'12312312',
            displayType:'removed'
          }
        ]
      }
    };
    const state = {
      cartPageData:{}
    }
    expect( serverRemovedItemMessage( data, state ) ).toEqual( concat( data.cartItems.items ) );
  } )
} );

describe( 'tests for serverUpdatedItemMessage', ( ) => {

  it( 'if there are no updated items in the incoming data should return updated items in state', ( ) => {
    const data ={
      cartItems:{
        items:[
          {
            skuId:'12312312',
            displayType:'default'
          }
        ]
      }
    };
    const state = {
      cartPageData:{
        updatedItems:[
          {
            skuId:'2323232',
            displayType:'updated'
          }
        ]
      }
    }
    expect( serverUpdatedItemMessage( data, state ) ).toBe( state.cartPageData.updatedItems );
  } )

  it( 'if there are updated items in the incoming data and updated items exist in state, it should return the concatenated items', ( ) => {
    const data ={
      cartItems:{
        items:[
          {
            skuId:'12312312',
            displayType:'updated'
          }
        ]
      }
    };
    const state = {
      cartPageData:{
        updatedItems:[
          {
            skuId:'2323232',
            displayType:'updated'
          }
        ]
      }
    }
    expect( serverUpdatedItemMessage( data, state ) ).toEqual( concat( state.cartPageData.updatedItems, data.cartItems.items ) );

  } )

  it( 'if there are updated items in the incoming data and no updated items in state, it should return the incoming updated items', ( ) => {
    const data ={
      cartItems:{
        items:[
          {
            skuId:'12312312',
            displayType:'updated'
          }
        ]
      }
    };
    const state = {
      cartPageData:{}
    }
    expect( serverUpdatedItemMessage( data, state ) ).toEqual( concat( data.cartItems.items ) );
  } )
} );

describe( 'tests for toggleSampleProductRightPanelCollapse', ( ) => {

  it( 'if selected sample have ShippingRestriction Message but showShippingRestrictionMsg is false then should return cartRightPanelCollapse in state', ( ) => {
    const cartpageData ={
      showShippingRestrictionMsg:false,
      freeSamplesInfo: {
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Fragrance Added'
            }
          ]
        },
        items: [
          {
            catalogRefId: '2252998',
            sampleDesc: 'Fragrance',
            shippingRestriction: 'Cannot ship to your selected address. Please select a different free sample.',
            selected: true
          },
          {
            catalogRefId: '2252999',
            sampleDesc: 'Skincare',
            shippingRestriction: null,
            selected: false
          },
          {
            catalogRefId: '2253000',
            sampleDesc: 'Variety',
            shippingRestriction: null,
            selected: false
          }
        ]
      }
    };
    const state = {
      cartRightPanelCollapse: {
        userRewards:false,
        samples: false,
        gifts: false,
        coupons: false,
        giftCard: false
      }
    }
    expect( toggleSampleProductRightPanelCollapse( cartpageData, state ) ).toBe( state.cartRightPanelCollapse );
  } )

  it( 'if selected sample doesn\'t have shippingRestriction message then should return cartRightPanelCollapse in state', ( ) => {
    const cartpageData ={
      showShippingRestrictionMsg:true,
      freeSamplesInfo: {
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Fragrance Added'
            }
          ]
        },
        items: [
          {
            catalogRefId: '2252998',
            sampleDesc: 'Fragrance',
            shippingRestriction: null,
            selected: true
          },
          {
            catalogRefId: '2252999',
            sampleDesc: 'Skincare',
            shippingRestriction: null,
            selected: false
          },
          {
            catalogRefId: '2253000',
            sampleDesc: 'Variety',
            shippingRestriction: null,
            selected: false
          }
        ]
      }
    };
    const state = {
      cartRightPanelCollapse: {
        userRewards:false,
        samples: false,
        gifts: false,
        coupons: false,
        giftCard: false
      }
    }
    expect( toggleSampleProductRightPanelCollapse( cartpageData, state ) ).toBe( state.cartRightPanelCollapse );
  } )

  it( 'if selected sample is ShippingRestricted and showShippingRestrictionMsg is true then should return cartRightPanelCollapse in state with sample node in it as true', ( ) => {
    const cartpageData ={
      showShippingRestrictionMsg:true,
      freeSamplesInfo: {
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Fragrance Added'
            }
          ]
        },
        items: [
          {
            catalogRefId: '2252998',
            sampleDesc: 'Fragrance',
            shippingRestriction: 'Cannot ship to your selected address. Please select a different free sample.',
            selected: true
          },
          {
            catalogRefId: '2252999',
            sampleDesc: 'Skincare',
            shippingRestriction: null,
            selected: false
          },
          {
            catalogRefId: '2253000',
            sampleDesc: 'Variety',
            shippingRestriction: null,
            selected: false
          }
        ]
      }
    };
    const state = {
      cartRightPanelCollapse: {
        userRewards:false,
        samples: false,
        gifts: false,
        coupons: false,
        giftCard: false
      }
    }

    const expectedState ={
      cartRightPanelCollapse: {
        userRewards:false,
        samples: true,
        gifts: false,
        coupons: false,
        giftCard: false
      }
    }
    expect( JSON.stringify( toggleSampleProductRightPanelCollapse( cartpageData, state ) ) ).toBe( JSON.stringify( expectedState.cartRightPanelCollapse ) );
  } )

  it( 'if no sample been selected then should return cartRightPanelCollapse in state', ( ) => {
    const cartpageData ={
      showShippingRestrictionMsg:true,
      freeSamplesInfo: {
        messages: null,
        items: [
          {
            catalogRefId: '2252998',
            sampleDesc: 'Fragrance',
            shippingRestriction: 'Cannot ship to your selected address. Please select a different free sample.',
            selected: false
          },
          {
            catalogRefId: '2252999',
            sampleDesc: 'Skincare',
            shippingRestriction: null,
            selected: false
          },
          {
            catalogRefId: '2253000',
            sampleDesc: 'Variety',
            shippingRestriction: null,
            selected: false
          }
        ]
      }
    };
    const state = {
      cartRightPanelCollapse: {
        userRewards:false,
        samples: false,
        gifts: false,
        coupons: false,
        giftCard: false
      }
    }
    expect( toggleSampleProductRightPanelCollapse( cartpageData, state ) ).toBe( state.cartRightPanelCollapse );
  } )

} );

describe( 'tests for session time out', ( ) => {
  it( 'should set cartDataAvailable to false on SESSION_TIMEOUT', ( ) => {

    let state = {
      cartPageData: {},
      cartDataAvailable:true
    }

    let actionCreator = {
      type: serviceTypes.SESSION_TIMEOUT
    }

    let expectedOutput = {
      cartPageData: {},
      cartDataAvailable:false
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } )
} )



