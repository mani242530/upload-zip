import reducer, {
  initialState,
  setToFixedPosition,
  removeFixedPosition,
  showLeftNav,
  hideLeftNav,
  checkIfIPhoneSafari,
  createEvent,
  dispatchCreatedEvent
} from './MobileLeftNav.reducer';


import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  types as globalActionTypes
} from 'shared/actions/Global/Global.actions';

import {
  types as mobileLeftNavTypes
} from 'hf/actions/MobileLeftNav/MobileLeftNav.actions';

import _ from 'lodash';

document.dispatchEvent = jest.fn();

describe( 'MobileLeftNav Reducer', () => {

  it( 'should have the proper default state', () => {
    let expectedState = {
      activeLevel: [],
      mobileLeftNavHeight: undefined,
      mobileLeftNavWidth: undefined,
      leftNavAnimationOffset: '0px',
      menuActive: false,
      leftNavScrollPosition: 0,
      leftNavScrollAdjust: 0,
      leftNavStyle: {},
      rewardsOpen: false,
      mobileNavContent: {},
      desktopNavPanelList: []
    };

    expect( initialState ).toEqual( expectedState );
  } );


  it( 'should be a function', () => {
    expect( _.isFunction( reducer ) ).toBe( true );
    expect( _.isFunction( CustomEvent ) ).toBe( true );
    expect( _.isFunction( dispatchCreatedEvent ) ).toBe( true );
  } );

  it( 'returns a custom Event', () => {
    let cEvent = new CustomEvent( 'NEWTEST', {
      detail: {
        IsMenuOpen: true
      }
    } );

    let nEvent = createEvent( 'NEWTEST', true );
    expect( JSON.stringify( nEvent ) ).toEqual( JSON.stringify( cEvent ) );
  } );

  it( 'invokes the Dispatch Event', () => {
    dispatchCreatedEvent( 'NEWTEST' );
    expect( document.dispatchEvent ).toHaveBeenCalled();
  } );

  describe( 'Navigation data  request success', () => {

    let data = {
      mobileNavContent: {
        body: {},
        fakestuff: {}
      },
      desktopNavContent: {
        navList: [{
          categories: []
        }]
      }
    };

    let res = {
      mobileNavContent: {
        body: {},
        fakestuff: {}
      },
      desktopNavPanelList: [{
        categories: [],
        paginatedNavItems: []
      }]
    };

    registerServiceName( 'navigation' );


    it( 'should set the navContent when the data is loaded', () => {
      let actionCreator = {
        type: getServiceType( 'navigation', 'success' ),
        data: data
      }

      let expectedOutput = {
        ...initialState,
        ...res
      }

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set mobileNavContent and desktopNavPanelList when the data is loaded', () => {
      const data = {
        mobileNavContent: {
          body: {},
          fakestuff: {}
        },
        desktopNavContent: {
          navList: [{
            categories: [{
              navDisplayContent: 'Brands',
              navElementType: 'rootCategory',
              categories: [],
              categoryLink: {
                showInNewPage: false,
                navTargetLink: 'http://qa3.ulta.com/global/nav/allbrands.jsp',
                'data-nav-description': 'm - brands',
                linkText: ''
              },
              fontColor: 'nav-menu-style-melon'
            }]
          }]
        }
      };
      const actionCreator = {
        type: getServiceType( 'navigation', 'success' ),
        data: data
      }
      const expectedOutput = {
        ...initialState,
        mobileNavContent: data.mobileNavContent,
        desktopNavPanelList: data.desktopNavContent.navList
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set the navContent when the data is loaded and has flyout', () => {
      const data = {
        mobileNavContent: {
          body: {},
          fakestuff: {}
        },
        desktopNavContent: {
          navList: [{
            categories: [{
              navDisplayContent: 'Brands',
              navElementType: 'rootCategory',
              categories: [],
              categoryLink: {
                showInNewPage: false,
                navTargetLink: 'http://qa3.ulta.com/global/nav/allbrands.jsp',
                'data-nav-description': 'm - brands',
                linkText: ''
              },
              fontColor: 'nav-menu-style-melon'
            }],
            flyout: [
              {
                imageLink: {
                  showInNewPage: false,
                  navTargetLink: 'http://da3.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod14051007',
                  linkText: '',
                  'data-slot-position': 'makeup_flyout_050916_makeup'
                },
                navElementType: 'subcategory',
                navAttributes: 'promoflyout',
                imageAlt: '',
                imgSrc: 'http://images.ulta.com/is/image/Ulta/flyout_050916_makeup'
              }
            ]
          }]
        }
      };
      const actionCreator = {
        type: getServiceType( 'navigation', 'success' ),
        data: data
      }
      const expectedOutput = {
        ...initialState,
        mobileNavContent: data.mobileNavContent,
        desktopNavPanelList: data.desktopNavContent.navList
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );


  describe( 'SET_MOBILE_LEFT_NAV_DIMENSIONS', () => {

    let height = 2255;
    let width = 220;

    let actionCreator = {
      type: mobileLeftNavTypes.SET_MOBILE_LEFT_NAV_DIMENSIONS,
      width,
      height
    }

    it( 'should handle the event and set the \'mobileLeftNav\' attribute', () => {

      let expectedOutput = {
        mobileLeftNavHeight: height,
        mobileLeftNavWidth: width
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );


  } );

  describe( 'TOGGLE_LEFT_NAV', () => {

    let mode = 1323;

    let actionCreator = {
      type: mobileLeftNavTypes.TOGGLE_LEFT_NAV,
      mode
    }

    it( 'should handle the event and set the \'menuActive\' attribute', () => {

      let expectedOutput = {
        menuActive: true,
        activeLevel: [],
        leftNavAnimationOffset: '0px'
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should update the states \'menuActive\' attribute', () => {


      let expectedOutput = Object.assign( {}, initialState,
        {
          leftNavScrollPosition: 0,
          menuActive: true
        }
      );

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'SET_ACTIVE_LEVEL', () => {

    it( 'should handle the event and set the \'leftNavAnimationOffset\' attribute and activeLevel as empty', () => {
      const actionCreator = {
        type: mobileLeftNavTypes.SET_ACTIVE_LEVEL,
        level: []
      }
      const expectedOutput = {
        activeLevel: [],
        leftNavAnimationOffset: '0px'
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should handle the event and set the \'leftNavAnimationOffset\' attribute and activeLevel', () => {
      const actionCreator = {
        type: mobileLeftNavTypes.SET_ACTIVE_LEVEL,
        level: ['1|1']
      }
      const state = { mobileLeftNavWidth: '1' };
      const expectedOutput = {
        ...state,
        activeLevel: ['1|1'],
        leftNavAnimationOffset: '-2px'
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'OPEN_REWARDS', () => {

    it( 'should handle the event and set rewards as true', () => {
      const actionCreator = { type: mobileLeftNavTypes.OPEN_REWARDS }
      const expectedOutput = { rewardsOpen: true };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

} );
