/**
 * TypeAheadSearch Redux reducer Module
 *
 */

import { createSelector } from 'reselect';
import {
  types as TypeAheadSearchTypes,
  actions as TypeAheadSearchActions
} from 'hf/actions/TypeAheadSearch/TypeAheadSearch.actions';

import {
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  types as headerActionTypes
} from 'hf/actions/Header/Header.actions'

import {
  types as GlobalTypes,
  actions as GlobalActions
} from 'shared/actions/Global/Global.actions';

/**
 * default state for the TypeAheadSearch reducer
 */


export const initialState = {
  enableReflektionTag: false,
  cancelBtnWidth: 0,
  inputContainerWidthRatio: 0,
  inputWidth: '100%',
  inputValue: '',
  formAction: buildFormAction( '' ),
  isLoading: false,
  isSearchMode: false,
  searchResultsHeight: 0,
  inputOffset: 0,
  suggestions: [],
  navigationURL: undefined, // This flag was added to updated the navigation URL, when up/down arrow key pressed after displayed the suggesions
  isReadSuggestions: false // This flag was added to avoid reading the 'No search results' text when blur from search box
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){

  switch ( action.type ){

    case headerActionTypes.TOGGLE_SEARCH_MODE:
      let updates = {};

      if( action.mode === 'close' ){
        updates = {
          ...updates,
          inputWidth: '100%',
          inputValue: '',
          isSearchMode: false,
          suggestions:[]
        }
      }
      else {
        updates = {
          ...updates,
          isSearchMode: true
        }
      }

      return {
        ...state,
        ...updates
      }

    case getServiceType( 'switches', 'success' ):

      return {
        ...state,
        enableReflektionTag: action.data.switches.enableReflektionTag
      }

    case GlobalTypes.ALERT_WINDOW_RESIZE:

      let calculatedInputContainerWidth = Math.floor( action.screenWidth * state.inputContainerWidthRatio );
      return {
        ...state,
        inputWidth: state.isSearchMode? setInputWidth( state.cancelBtnWidth, calculatedInputContainerWidth ) : '100%',
        searchResultsHeight:  calculateSearchResultsHeight( action.screenHeight, state.inputOffset )
      }

    case TypeAheadSearchTypes.SET_SEARCH_RESULTS_HEIGHT:
      let searchResultsHeight = calculateSearchResultsHeight( action.screenHeight, action.offset );
      return {
        ...state,
        searchResultsHeight,
        inputOffset: action.offset
      }

    case TypeAheadSearchTypes.SET_INPUT_WIDTH:

      return {
        ...state,
        cancelBtnWidth: action.cancelBtnWidth,
        inputContainerWidthRatio: parseFloat( action.containerWidth / action.deviceWidth ),
        inputWidth: setInputWidth( action.cancelBtnWidth, action.containerWidth )
      }

    case TypeAheadSearchTypes.RESET_INPUT_VALUE:
      return {
        ...state,
        inputValue: '',
        suggestions:[],
        navigationURL: undefined,
        formAction: buildFormAction( '' )
      }

    case TypeAheadSearchTypes.UPDATE_INPUT_VALUE:
      let value = action.value;

      value = value
        .replace( /\\/g, '' )
        .replace( /\//g, '' )
        .replace( /\%/g, '' );

      if( containsSpCh( value ) ){
        value = '';
      }



      let suggestions = ( action.value.length <3 )? [] : state.suggestions;


      return {
        ...state,
        formAction: buildFormAction( encodeURIComponent( value ) ),
        inputValue: value,
        navigationURL: undefined,
        suggestions
      }

    case TypeAheadSearchTypes.UPDATE_NAVIGATION_STATE_URL:
      return {
        ...state,
        navigationURL: action.data,
        selectedTerm: action.label
      }

    case TypeAheadSearchTypes.CLEAR_SUGGESTIONS:
      return {
        ...state,
        isReadSuggestions: false,
        suggestions:[]
      }

    // Data from service to populate the navigation service data
    case getServiceType( 'searchTypeAhead', 'success' ):
      return {
        ...state,
        isReadSuggestions: true,
        suggestions: getSuggestions( action.data, state.inputValue )
      }


    case TypeAheadSearchTypes.LOAD_SUGGESTIONS_BEGIN:
      return {
        ...state,
        isLoading: true
      }

    default:
      return state;
  }
}

export function getSuggestions( suggestions, inputValue ){
  const escapedValue = escapeRegexCharacters( inputValue.trim() );
  const regex = new RegExp( '^' + escapedValue, 'i' );

  if( escapedValue === '' ){
    return [];
  }

  let res = suggestions
    .map( section => {

      let resultSet = section.dimensionSearchValues.map(
        suggestion => {
          let _suggestion = suggestion;
          let ancestors = suggestion.ancestors;
          var breadcrumb = '';

          if( ancestors !== null && ancestors.length > 0 ){
            for ( var i = 0; i < ancestors.length; i++ ){
              breadcrumb += ancestors[i].label + ' > ';
            }
          }
          _suggestion.label = breadcrumb + _suggestion.label;

          let label = _suggestion.label

          switch ( section.displayName ){
            case 'product.category':/* categories */
              break;

            case 'product.brandName':/* brands */
            case 'd_displayName':/* products */
              if( _suggestion.label.indexOf( '/' ) > 0 ){
                _suggestion.label = _suggestion.label.replace( /\//g, '' );
              }

              if( _suggestion.label.indexOf( '%' ) > 0 ){
                _suggestion.label = _suggestion.label.replace( /\%/g, '' );
              }

              _suggestion.navigationState = `/ulta/a/_/Ntt-${ encodeURIComponent( _suggestion.label ) }?ciSelector=searchResults`;
              break;

            case 'd_redirectkeyword':/* related */
              _suggestion.navigationState = `/ulta/a/_/Ntt-${ encodeURIComponent( _suggestion.label ) }?ciSelector=searchResults`;
              break;
          }

          let NfIndex = _suggestion.navigationState.indexOf( 'Nf=' );

          if( NfIndex > 0 ){
            var match = _suggestion.navigationState.substring( NfIndex, NfIndex + 46 );
            _suggestion.navigationState.replace( match, '' );
          }

          let accIndex = _suggestion.navigationState.indexOf( 'assemblerContentCollection=' );

          if( accIndex > 0 ){
            var match = _suggestion.navigationState.substring( accIndex, accIndex + 60 );
            _suggestion.navigationState.replace( match, '' );
          }

          return _suggestion;
        }
      );

      return {
        dimensionName: section.dimensionName,
        dimensionSearchValues: resultSet
      };

    } )
    .filter( section => section.dimensionSearchValues.length > 0 );

  return res;

}

// TODO is this the desired output?!?!?
// https://developer.mozilla.org/en/docs/Web/JavaScript/Guide/Regular_Expressions#Using_Special_Characters
export function escapeRegexCharacters( str ){
  return str.replace( /[.*+?^${}()|[\]\\]/g, '\\$&' );
}

export function containsSpCh( c ){
  var a = /^[@\!\#\$\^\%\&\*\(\)\+\=\-\[\]\\\'\;\,\.\/\{\}\|\"\:\<\>\?\~\`\_]$/;
  for ( var b = 0; b < c.length; b++ ){
    if( !c.charAt( b ).match( a ) ){
      return false
    }
  }
  return true;
}

export function setInputWidth( btnWidth, containerWidth ){

  return `${( 100 - Math.ceil( ( btnWidth / containerWidth ) * 100 ) - 6 )}%`;
}

export function buildFormAction( query ){
  // sanitize the search params before constucting the URL

  let formAction = [];
  formAction.push( '/ulta/a/_/Ntt-' );
  formAction.push( query );
  formAction.push( '/Nty-1' );
  return formAction.join( '' )
}

export function calculateSearchResultsHeight( screenHeight, inputOffset ){
  return ( screenHeight - inputOffset ) - 15 ;
}

