import reducer, {
  initialState,
  calculateSearchResultsHeight,
  setInputWidth,
  buildFormAction,
  getSuggestions,
  escapeRegexCharacters
} from './TypeAheadSearch.reducer';

import {
  types
} from '../../actions/TypeAheadSearch/TypeAheadSearch.actions';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import _ from 'lodash';

import {
  types as headerActionTypes
} from 'hf/actions/Header/Header.actions';

const suggestions = [
  {
    dimensionName: 'product.brandName',

    dimensionSearchValues:[
      { label: 'Alpha', navigationState: '/alpha/test' },
      { label: 'Zeta', navigationState: '/Zeta/test' },
      { label: 'Eta', navigationState: '/Eta/test' }
    ]
  }
]

describe( 'TypeAheadSearch reducer', () => {


  it( 'should have the proper default state', () => {
    let expectedState = {
      enableReflektionTag: false,
      cancelBtnWidth: 0,
      formAction: '/ulta/a/_/Ntt-/Nty-1',
      inputContainerWidthRatio: 0,
      inputOffset: 0,
      inputValue: '',
      inputWidth: '100%',
      isLoading: false,
      isSearchMode: false,
      searchResultsHeight: 0,
      suggestions: [],
      navigationURL: undefined,
      isReadSuggestions: false
    }

    expect( initialState ).toEqual( expectedState );

  } );

  it( 'should be a function', () => {
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', () => {
    expect( reducer( undefined, { type: 'jibberjabber' } ) ).toEqual( initialState );
  } );

  describe( 'setSearchResultsHeight', () => {


    it( 'calculateearhResultsHeight should return the proper value', () => {
      let calcHeight = calculateSearchResultsHeight( 1000, 100 );
      expect( calcHeight ).toBe( 885 );

    } );

    it( 'should handle the event and set the state', () => {

      let offset = 400;
      let screenHeight = 30;

      let actionCreator = {
        type: types.SET_SEARCH_RESULTS_HEIGHT,

        offset,
        screenHeight
      }

      let expectedOutput = {
        inputOffset: offset,
        searchResultsHeight: -385
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'setInputWidth', () => {

    it( 'should set the correct value', () => {
      let nWidth = setInputWidth( 50, 1000 );

      expect( nWidth ).toEqual( '89%' );
    } );
  } );

  describe( 'SET_INPUT_WIDTH', () => {
    it( 'should handle the action and return the proper value', () => {
      let actionCreator = {
        type: types.SET_INPUT_WIDTH,
        cancelBtnWidth: 50,
        containerWidth: 1000,
        deviceWidth: 1040
      }

      let expectedOutput = {
        cancelBtnWidth: 50,
        inputContainerWidthRatio: ( actionCreator.containerWidth / actionCreator.deviceWidth ),
        inputWidth: '89%'
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );
  } );

  describe( 'buildFormAction', () => {
    it( 'should return the proper string for a form action', () => {
      let query = 'this_is_a_test';
      let action = buildFormAction( query );
      expect( action ).toBe( `/ulta/a/_/Ntt-${query}/Nty-1` );
    } );
  } );

  describe( 'UPDATE_INPUT_VALUE', () => {
    it( 'should set the input value of the search box', () => {
      let query = '\\hiworl%/;d';
      let actionCreator = {
        type: types.UPDATE_INPUT_VALUE,
        value: query
      }

      let expectedResult = {
        formAction: '/ulta/a/_/Ntt-hiworl%3Bd/Nty-1',
        inputValue: 'hiworl;d',
        navigationURL: undefined
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expectedResult );

    } );

  } );

  describe( 'RESET_INPUT_VALUE', () => {
    it( 'should reset the fields and update the state', () => {
      let actionCreator = {
        type: types.RESET_INPUT_VALUE
      }

      let expectedResult = {
        inputValue: '',
        suggestions: [],
        navigationURL: undefined,
        formAction: '/ulta/a/_/Ntt-/Nty-1'
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedResult );

    } );
  } );

  describe( 'UPDATE_NAVIGATION_STATE_URL', () => {
    it( 'should update the navigationURL state', () => {
      let actionCreator = {
        type: types.UPDATE_NAVIGATION_STATE_URL,
        data: '/nails?N=271o',
        label: 'makeUp>lipStick'
      }

      let expectedResult = {
        navigationURL: '/nails?N=271o',
        selectedTerm:'makeUp>lipStick'
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedResult );

    } );
  } );

  describe( 'CLEAR_SUGGESTIONS', () => {
    it( 'should reset the suggestions on event handling', () => {
      let actionCreator = {
        type: types.CLEAR_SUGGESTIONS
      }

      expect( reducer( {}, actionCreator ) ).toEqual( { isReadSuggestions: false, suggestions:[] } );
    } );

  } );

  describe( 'getSuggestions', () => {
    it( 'should return the list of suggestions', () => {
      let data = [
        {
          dimensionName: 'product.brandName',

          dimensionSearchValues:[
            { label: 'Alpha', navigationState: '/alpha/test', ancestors:[] },
            { label: 'Zeta', navigationState: '/Zeta/test', ancestors:[] },
            { label: 'Eta', navigationState: '/Eta/test', ancestors:[] }
          ]
        }
      ];
      let list = getSuggestions( data, 'AlP' );

      expect( typeof list ).toBe( 'object' );

      expect( list.length ).toBe( 1 );
      expect( list ).toEqual( [
        {
          dimensionName: 'product.brandName',

          dimensionSearchValues:[
            { label: 'Alpha', navigationState: '/alpha/test', ancestors:[] },
            { label: 'Zeta', navigationState: '/Zeta/test', ancestors:[] },
            { label: 'Eta', navigationState: '/Eta/test', ancestors:[] }
          ]
        }] );
    } );

    it( 'should return the list of suggestions with a label having a combined value if ancestors is passed', () => {
      let data = [
        {
          dimensionName: 'product.category',
          displayName:'product.category',
          dimensionSearchValues:[
            { label: 'Blush',
              navigationState: '/makeup-face-blush?N=277v',
              ancestors:[
                { label:'Makeup' },
                { label:'face' }
              ] }
          ]

        }
      ];
      let list = getSuggestions( data, 'Blu' );

      expect( typeof list ).toBe( 'object' );

      expect( list.length ).toBe( 1 );
      expect( list ).toEqual( [
        {
          dimensionName: 'product.category',

          dimensionSearchValues:[
            { label: 'Makeup > face > Blush',
              navigationState: '/makeup-face-blush?N=277v',
              ancestors:[
                { label:'Makeup' },
                { label:'face' }
              ] }
          ]

        }] );
    } );


    it( 'should return the list of suggestions - displayName : d_redirectkeyword', () => {
      let data = [
        {
          dimensionName: 'd_redirectkeyword',
          displayName:'d_redirectkeyword',
          dimensionSearchValues:[
            { label: 'Becca Mineral Blush',
              navigationState: '/ulta/a/_/Ntt-Becca%20Mineral%20Blush?ciSelector=searchResults',
              ancestors:[] }
          ]

        }
      ];
      let list = getSuggestions( data, 'Blu' );

      expect( typeof list ).toBe( 'object' );

      expect( list.length ).toBe( 1 );
      expect( list ).toEqual( [
        {
          dimensionName: 'd_redirectkeyword',

          dimensionSearchValues:[
            { label: 'Becca Mineral Blush',
              navigationState: '/ulta/a/_/Ntt-Becca%20Mineral%20Blush?ciSelector=searchResults',
              ancestors:[] }
          ]

        }] );
    } );

    it( 'should return the list of suggestions - displayName : d_displayName', () => {
      let data = [
        {
          displayName: 'd_displayName',
          dimensionName: 'd_displayName',
          dimensionSearchValues:[
            { label: 'Becca Mineral/ % Blush',
              navigationState: '/ulta/a/_/Ntt-Becca%20Mineral%20Blush?ciSelector=searchResults',
              ancestors:[] }
          ]

        }
      ];
      let list = getSuggestions( data, 'Blu' );

      expect( typeof list ).toBe( 'object' );

      expect( list.length ).toBe( 1 );
      expect( list ).toEqual( [
        {
          dimensionName: 'd_displayName',

          dimensionSearchValues:[
            { label: 'Becca Mineral  Blush',
              navigationState: '/ulta/a/_/Ntt-Becca%20Mineral%20%20Blush?ciSelector=searchResults',
              ancestors:[] }
          ]

        }] );
    } );

  } );

  describe( 'REQUEST_SEARCH_RESULTS', () => {
    it( 'handles the actions', () => {

      registerServiceName( 'searchTypeAhead' );
      let actionData = [
        {
          dimensionName: 'product.brandName',

          dimensionSearchValues:[
            { label: 'Alpha', navigationState: '/alpha/test', ancestors:[] }
          ]
        }
      ];

      let actionCreator = {
        type: getServiceType( 'searchTypeAhead', 'success' ),
        data: actionData

      }

      let expectedResults = {
        inputValue: 'Alp',
        isReadSuggestions: true,
        suggestions: actionCreator.data
      }

      expect( reducer( { inputValue: 'Alp' }, actionCreator ) ).toEqual( expectedResults );
    } );
  } );

  describe( 'LOAD_SUGGESTIONS_BEGIN', () => {

    it( 'should update the state proper', () => {

      let actionCreator = {
        type: types.LOAD_SUGGESTIONS_BEGIN
      };
      expect( reducer( {}, actionCreator ) ).toEqual( { isLoading:true } );


    } );
  } );

  describe( 'excapeRegexCharacter', () => {
    it( 'should remove invalid characters', ()=>{
      let string = '||%%WWWE';

      let cleanString = escapeRegexCharacters( string );
      expect( cleanString ).toBe( '\\|\\|%%WWWE' );
    } );

  } );

  describe( 'TOGGLE_SEARCH_MODE', () => {
    const actionCreator = {
      type: headerActionTypes.TOGGLE_SEARCH_MODE,
      mode: 'close'
    }
    it( 'should update the state proper when closed', () => {
      const expectedOutput = {
        inputWidth: '100%',
        inputValue: '',
        isSearchMode: false,
        suggestions:[]
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should update the state proper when open', () => {
      actionCreator.mode = 'open';
      const expectedOutput = {
        isSearchMode: true
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

} );
