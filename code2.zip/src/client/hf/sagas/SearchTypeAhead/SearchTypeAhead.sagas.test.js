

/**
 * Page  sagas
 */

import { takeLatest, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import saga, { listener } from './SearchTypeAhead.sagas';

import {
  types as typeAheadTypes
} from 'hf/actions/TypeAheadSearch/TypeAheadSearch.actions';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'shared/actions/Services/Services.actions';

import {
  ajax
} from 'utils/Ajax/Ajax';


const date =  new Date();
let time = date.setHours( date.getHours(), 0, 0, 0 );
const type = 'searchTypeAhead';

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );

  describe( 'default saga', () => {

    const coreSaga = saga();

    it( 'should listen for the navigation requested method', () => {

      const takeLatestDescriptor = coreSaga.next().value;
      expect( takeLatestDescriptor ).toEqual( takeLatest( typeAheadTypes.REQUEST_SEARCH_RESULTS, listener, type ) );
    } );

  } );

  describe( 'listener saga success path', () => {
    let qVal = 'ASF';

    const listenerSaga = listener( type, { query: { value:qVal } } );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor  = listenerSaga.next().value;

      let query = {
        format: 'json',
        Dy: 1,
        Ntt:`${qVal}*`,
        Nr: 'OR(AND(product.isLive:1,sku.isLive:1,NOT(product.category:Gifts:Gifts with Purchase)),keywords:1)',
        Nf: `product.startDate|LTEQ+${time}`
      };

      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a success event after data is called', () => {

      let body = {
        contents: [{
          autoSuggest:[{
            displayName: 'BLAH',
            dimensionSearchGroups:[
              {
                label: 'hi world'
              },
              {
                label: 'this is a test!'
              }
            ]
          }]
        }]
      }

      const putDescriptor = listenerSaga.next( { body } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( body.contents[0].autoSuggest[0].dimensionSearchGroups ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );


} );
