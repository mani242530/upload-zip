/**
 * CategoriesMenu
 */

import React from 'react';
import PropTypes from 'prop-types';
import Anchor from 'shared/components/Anchor/Anchor';
import ChevronRightSVG from 'shared/components/Icons/chevron_right';
import classNames from 'classnames';
import './CategoriesMenu.css';


const propTypes = {
  categories: PropTypes.object.isRequired
}

/**
 * Create a CategoriesMenu
 */
const CategoriesMenu = ( props ) => {

  const {
    categories
  } = props;

  return (
    <div
      className='CategoriesMenu'
      style={ {
        'marginTop': categories.topMargin,
        'marginBottom': categories.bottomMargin
      } }
    >

      <div className='CategoriesMenu__header'>
        { categories.title }
      </div>

      { ( ()=>{
        if( categories.Category ){
          return categories.Category.map( ( category, index ) => {
            return (
              <div
                className={ classNames( {
                  'CategoriesMenu__links': true,
                  'CategoriesMenu__links--divider': index < categories.Category.length - 1
                } ) }
                key={ index }
              >

                <Anchor
                  dataNavDescription={ category.categoryLink['data-nav-description'] }
                  url={ category.categoryLink.navTargetLink }
                  target={ category.categoryLink.showInNewPage ? '_blank' : '_self' }
                >
                  <div className='CategoriesMenu__text'>
                    { category.navDisplayContent }
                  </div>

                  <div className='CategoriesMenu__chevron-right'>
                    <ChevronRightSVG />
                  </div>

                </Anchor>

              </div>

            )

          } )
        }
      } )() }

    </div>
  );
}

CategoriesMenu.propTypes = propTypes;

export default CategoriesMenu;
