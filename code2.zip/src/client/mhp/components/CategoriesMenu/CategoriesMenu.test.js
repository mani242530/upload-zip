import React from 'react';
import ReactDOM from 'react-dom';
import CategoriesMenu from './CategoriesMenu';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { mount } from 'enzyme';

let CategoriesMenuData = {
  'topMargin': '15px',
  'Category': [
    {
      'endeca:auditInfo': {
        'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
        'ecr:innerPath': 'mobileContent[18]/Category[0]'
      },
      'name': 'MakeUp',
      'categoryLink': {
        '@type': 'DynamicLink',
        'showInNewPage': true,
        'endeca:auditInfo': {
          'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
          'ecr:innerPath': 'mobileContent[18]/Category[0]/categoryLink'
        },
        'name': 'Dynamic Link',
        'navTargetLink': '/makeup?N=26y1',
        'linkText': ''
      },
      '@type': 'MobileCategorySelector'
    },
    {
      'endeca:auditInfo': {
        'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
        'ecr:innerPath': 'mobileContent[18]/Category[1]'
      },
      'name': 'Skin',
      'categoryLink': {
        '@type': 'DynamicLink',
        'showInNewPage': true,
        'endeca:auditInfo': {
          'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
          'ecr:innerPath': 'mobileContent[18]/Category[1]/categoryLink'
        },
        'name': 'Dynamic Link',
        'navTargetLink': '/skin-care?N=2707',
        'linkText': ''
      },
      '@type': 'MobileCategorySelector'
    },
    {
      'endeca:auditInfo': {
        'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
        'ecr:innerPath': 'mobileContent[18]/Category[2]'
      },
      'name': 'Hair',
      'categoryLink': {
        '@type': 'DynamicLink',
        'showInNewPage': false,
        'endeca:auditInfo': {
          'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
          'ecr:innerPath': 'mobileContent[18]/Category[2]/categoryLink'
        },
        'name': 'Dynamic Link',
        'navTargetLink': '/hair?N=26wz',
        'linkText': ''
      },
      '@type': 'MobileCategorySelector'
    },
    {
      'endeca:auditInfo': {
        'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
        'ecr:innerPath': 'mobileContent[18]/Category[3]'
      },
      'name': 'Men',
      'categoryLink': {
        '@type': 'DynamicLink',
        'showInNewPage': false,
        'endeca:auditInfo': {
          'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
          'ecr:innerPath': 'mobileContent[18]/Category[3]/categoryLink'
        },
        'name': 'Dynamic Link',
        'navTargetLink': '/men?N=26zq',
        'linkText': ''
      },
      '@type': 'MobileCategorySelector'
    },
    {
      'endeca:auditInfo': {
        'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
        'ecr:innerPath': 'mobileContent[18]/Category[4]'
      },
      'name': 'Nails',
      'categoryLink': {
        '@type': 'DynamicLink',
        'showInNewPage': false,
        'endeca:auditInfo': {
          'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
          'ecr:innerPath': 'mobileContent[18]/Category[4]/categoryLink'
        },
        'name': 'Dynamic Link',
        'navTargetLink': '/nails?N=271o',
        'linkText': ''
      },
      '@type': 'MobileCategorySelector'
    },
    {
      'endeca:auditInfo': {
        'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
        'ecr:innerPath': 'mobileContent[18]/Category[5]'
      },
      'name': 'Fragrance',
      'categoryLink': {
        '@type': 'DynamicLink',
        'showInNewPage': false,
        'endeca:auditInfo': {
          'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
          'ecr:innerPath': 'mobileContent[18]/Category[5]/categoryLink'
        },
        'name': 'Dynamic Link',
        'navTargetLink': '/fragrance?N=26wa',
        'linkText': ''
      },
      '@type': 'MobileCategorySelector'
    },
    {
      'endeca:auditInfo': {
        'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
        'ecr:innerPath': 'mobileContent[18]/Category[6]'
      },
      'name': 'Bath & Body',
      'categoryLink': {
        '@type': 'DynamicLink',
        'showInNewPage': false,
        'endeca:auditInfo': {
          'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
          'ecr:innerPath': 'mobileContent[18]/Category[6]/categoryLink'
        },
        'name': 'Dynamic Link',
        'navTargetLink': '/bath-body?N=26us',
        'linkText': ''
      },
      '@type': 'MobileCategorySelector'
    },
    {
      'endeca:auditInfo': {
        'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
        'ecr:innerPath': 'mobileContent[18]/Category[7]'
      },
      'name': 'Ulta Collection',
      'categoryLink': {
        '@type': 'DynamicLink',
        'showInNewPage': false,
        'endeca:auditInfo': {
          'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
          'ecr:innerPath': 'mobileContent[18]/Category[7]/categoryLink'
        },
        'name': 'Dynamic Link',
        'navTargetLink': '/ulta-collection?N=26vr',
        'linkText': ''
      },
      '@type': 'MobileCategorySelector'
    },
    {
      'endeca:auditInfo': {
        'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
        'ecr:innerPath': 'mobileContent[18]/Category[8]'
      },
      'name': 'Sale',
      'categoryLink': {
        '@type': 'DynamicLink',
        'showInNewPage': false,
        'endeca:auditInfo': {
          'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
          'ecr:innerPath': 'mobileContent[18]/Category[8]/categoryLink'
        },
        'name': 'Dynamic Link',
        'navTargetLink': '/_/N-1z13uvl?ciSelector=searchResults&pgName=specialOffers',
        'linkText': ''
      },
      '@type': 'MobileCategorySelector'
    }
  ],
  '@type': 'MobileCategoryCollection',
  'bottomMargin': '15px',
  'endeca:auditInfo': {
    'ecr:resourcePath': '/content/web browser/Home/Mobile Home Pages/PLEASE DON\'T CHANGE- Heather week 38',
    'ecr:innerPath': 'mobileContent[18]'
  },
  'name': 'Categories',
  'title': 'Shop Categories'
}

describe( '<CategoriesMenu />', () => {
  let component;
  let props;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <CategoriesMenu categories={ CategoriesMenuData } /> );
    expect( component.find( 'CategoriesMenu' ).length ).toBe( 1 );
  } );

  it( 'renders the appropriate number of categories per props passed', () => {
    component = mountWithIntl( <CategoriesMenu categories={ CategoriesMenuData } /> );
    expect( component.find( '.CategoriesMenu__links' ).length ).toBe( 9 );
  } );

  describe( 'rendered output', () => {


    CategoriesMenuData.topMargin = '23px'
    CategoriesMenuData.bottomMargin = '35px'
    CategoriesMenuData.title = 'Hello Ulta'

    props = {
      categories: CategoriesMenuData
    }

    component = mountWithIntl(
      <CategoriesMenu { ...props } />
    );

    let element = component.find( 'CategoriesMenu' ).html()



    it( 'renders top and bottom margin based on data passed in props', () => {

      const regMarginTop = /margin-top: 23px/g
      const regMarginBottom = /margin-bottom: 35px/g

      expect( element.match( regMarginTop ).length ).toBe( 1 );
      expect( element.match( regMarginBottom ).length ).toBe( 1 );
    } );

    it( 'renders the title passed in from props', () => {

      const regTitle = /Hello Ulta/g

      expect( element.match( regTitle ).length ).toBe( 1 );
    } );

    it( 'opens links with the appropriate target attribute as passed in props', () => {

      const regBlank = /_blank/g
      const regSelf = /_self/g

      expect( element.match( regBlank ).length ).toBe( 2 );
      expect( element.match( regSelf ).length ).toBe( 7 );
    } );
  } );

} );
