/**
 * ImageGrid
 */

import React from 'react';
import PropTypes from 'prop-types';
import Image from 'shared/components/Image/Image';
import Anchor from 'shared/components/Anchor/Anchor';
import ChevronRightSVG from 'shared/components/Icons/chevron_right';
import './ImageGrid.css';

import { formatMessage } from 'shared/components/Global/Global';
import messages from './ImageGrid.messages';



const propTypes = {

  // brandList: an array which has all of the data
  // needed to display each brand logo
  brandList: PropTypes.array.isRequired,

  // marginBottom: a string in the form '15px'
  // which designates the bottom margin
  marginBottom: PropTypes.string,

  // marginTop: a string in the form '15px'
  // which designates the top margin
  marginTop: PropTypes.string,

  // brandCount: the total number of brands listed on the
  // on the 'all brands' page( http://www.ulta.com/global/nav/allbrands.jsp )
  // should be sent as a prop from the appropriate service call
  brandCount: PropTypes.number
}

const defaultProps = {
  // this default is temporary until we have the service call
  // wired up
  brandCount: 200
}


const ImageGrid = ( props ) => {



  const {
    brandCount,
    brandList
  } = props

  return (
    <div className='ImageGrid'>
      <div className='ImageGrid__brand-container'>

        { ( ()=>{

          return brandList.map( ( brand, index ) => {

            const {
              brandLink,
              brandImage,
              imageAlt
            } = brand

            const navLink = brandLink.navTargetLink
            const target = brandLink.showInNewPage

            return (
              <div
                className='ImageGrid__brand-logo'
                key={ index }
              >
                <Anchor
                  url={ navLink }
                  target={ target ? '_blank' : '_self' }
                >
                  <Image
                    src={ brandImage }
                    alt={ imageAlt }
                  />
                </Anchor>
              </div>
            )

          } )

        } )() }

      </div>

      <div className='ImageGrid__viewAll' >
        <Anchor
          url='/global/nav/allbrands.jsp'
        >
          { formatMessage( messages.view_all, { brands: brandCount } ) }
          <span className='ImageGrid__chevron-right'>
            <ChevronRightSVG />
          </span>
        </Anchor>
      </div>

    </div>
  );

}

ImageGrid.propTypes = propTypes;
ImageGrid.defaultProps = defaultProps;

export default ImageGrid;
