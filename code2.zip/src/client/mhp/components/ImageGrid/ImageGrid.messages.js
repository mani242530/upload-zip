/*
 * ImageGrid Messages
 *
 * This contains all the text for the ImageGrid component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  view_all: {
    id: 'i18n.ImageGrid.view_all',
    defaultMessage: 'view all {brands}'
  }
} );
