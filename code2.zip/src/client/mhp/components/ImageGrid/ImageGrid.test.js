import React from 'react';
import ReactDOM from 'react-dom';
import ImageGrid from './ImageGrid';
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import ImageGridData from 'mhp/components/ImageGrid/ImageGridData';
import messages from 'mhp/components/ImageGrid/ImageGrid.messages'

describe( '<ImageGrid />', () => {
  let component;
  let props = {
    brandList: ImageGridData.brand,
    marginBottom: ImageGridData.bottomMargin,
    marginTop: ImageGridData.topMargin
  };

  it( 'renders without crashing', () => {

    component = mountImageGrid( props );
    expect( component.find( 'ImageGrid' ).length ).toBe( 1 );
  } );

  it( 'renders with the correct number of brand logos as passed in props', () => {
    component = mountImageGrid( props );
    expect( component.find( '.ImageGrid__brand-logo' ).length ).toBe( 10 );
  } );

  it( 'should render the number of brands on the brand page when passed in props', () => {
    props.brandCount = Math.random();
    component = mountImageGrid( props );
    expect( component.find( '.ImageGrid__viewAll a' ).text() ).toBe( 'view all ' + props.brandCount );
  } );

  it( 'should render the \'view all\' message from messages', () => {
    let re = / {brands}/;
    let message = messages.view_all.defaultMessage.replace( re, '' );
    component = mountImageGrid( props );
    expect( component.find( '.ImageGrid__viewAll a' ).text() ).toBe( message + ' ' + props.brandCount )
  } );

} );

function mountImageGrid( props ){
  return mountWithIntl(
    <ImageGrid
      { ...props }
    />
  );
}
