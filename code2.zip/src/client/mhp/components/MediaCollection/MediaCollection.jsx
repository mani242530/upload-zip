/**
 * MediaCollection
 */

import React from 'react';
import PropTypes from 'prop-types';
import './MediaCollection.css';
import MediaItem from '../MediaItem/MediaItem';
import classNames from 'classnames';



const propTypes = {
  imageData: PropTypes.array,
  layout: PropTypes.string,
  marginTop: PropTypes.string,
  marginBottom: PropTypes.string
}

const defaultProps = {
  marginTop: '0px',
  marginBottom: '0px'
}

const MediaCollection = ( props ) => {

  const {
    imageData,
    layout,
    marginTop,
    marginBottom
  } = props;

  const style = {
    marginTop: marginTop,
    marginBottom: marginBottom
  }


  return (
    <div
      className='MediaCollection'
      style={ style }
    >
      <div
        className={
          classNames( {
            'MediaCollection__Row' : layout === undefined,
            'MediaCollection__Row--sidebyside2' : layout === '2up',
            'MediaCollection__Row--sidebyside3': layout === '3up'
          } )
        }
      >
        { ( ()=> {

          return imageData.map( ( image, index ) => {

            return (
              <MediaItem
                dataNavDescription={ image.mediaLink['data-nav-description'] }
                dataSlotPosition={ image.mediaLink['data-slot-position'] }
                src={ image.mobileMedia }
                alt={ image.imageAlt }
                url={ image.mediaLink ? image.mediaLink.navTargetLink : '#' }
                key={ index }
              />
            )
          } )

        } )() }


      </div>
    </div>
  );

}

MediaCollection.propTypes = propTypes;
MediaCollection.defaultProps = defaultProps;

export default MediaCollection;
