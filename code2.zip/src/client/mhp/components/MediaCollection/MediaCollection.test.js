import React from 'react';
import ReactDOM from 'react-dom';
import MediaCollection from './MediaCollection';
import { shallow } from 'enzyme';
import { shallowToJson } from 'enzyme-to-json'
import { mountWithIntl } from 'utils/intl-enzyme-test-helper';
import { intlProvider } from 'react-intl';

describe( '<MediaCollection />', () => {
  let component;

  let data = [
    {
      mobileMedia: '111',
      imageAlt: '222',
      mediaLink:{
        navTargetLink: '333',
        dataNavDescription: '22',
        dataSlotPosition: 1
      }
    },
    {
      mobileMedia: '111',
      imageAlt: '222',
      mediaLink:{
        navTargetLink: '333',
        dataNavDescription: '22',
        dataSlotPosition: 1
      }
    },
    {
      mobileMedia: '111',
      imageAlt: '222',
      mediaLink:{
        navTargetLink: '333',
        dataNavDescription: '22',
        dataSlotPosition: 1
      }
    }
  ];

  let props = {
    imageData: data
  }



  component = mountWithIntl( <MediaCollection { ...props }/> );

  it( 'renders without crashing', () => {
    expect( component.find( 'MediaCollection' ).length ).toBe( 1 );
  } );

  it( 'renders 2up layout with 2 Media Items', () => {
    component = mountWithIntl( <MediaCollection { ...props } layout='2up'/> );
    expect( component.find( 'MediaCollection' ).find( 'MediaItem' ).length ).toBe( 3 );

  } )


  it( '3up layout contains 3 Media Items', () => {
    component = mountWithIntl( <MediaCollection { ...props } layout='3up'/> );
    expect( component.find( 'MediaCollection' ).find( 'MediaItem' ).length ).toBe( 3 );

  } )



} );
