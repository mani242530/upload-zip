import '@storybook/addon-actions/register';
import '@storybook/addon-links/register';
import '@storybook/addon-notes/register';
import 'storybook-addon-intl/register';
import '@storybook/addon-a11y/register';
import '@storybook/addon-viewport/register';
