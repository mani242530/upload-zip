import { addDecorator, configure } from '@storybook/react';
import { setIntlConfig, withIntl } from 'storybook-addon-intl';

import { addLocaleData } from 'react-intl';

import en from 'react-intl/locale-data/en';

addLocaleData( en );

const messages = {};

const getMessages = ( locale ) => messages[locale]

  
setIntlConfig( {
  locales: [ 
    'en' 
  ],
  defaultLocale: 'en',
  getMessages
} );

addDecorator( withIntl );

const getPath = ( name ) => {
				let path = `../../src/components/components/${name}/_${name}.storybook`;
  console.log( 'ath', path ); 
  return path;
}

configure( () => require( '../../src/react/components/Anchor/.stories' ), module );
configure( () => require( '../../src/react/components/Button/.stories' ), module );
