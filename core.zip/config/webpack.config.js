var path = require('path');
var root = path.join(__dirname, '');
var VERSION = require('./../package.json').version;
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var KssWebpackPlugin = require('kss-webpack-plugin');
var	distributionFileName = ( 'ulta-fed-core_v'  + VERSION );

var KssConfig = {
  source: [ path.join(root, './../src/') ],
  builder: path.join(root, './../styleguide/themes/andromeda/'),
  destination: path.join(root, './../dist/styleguide/'),
  css: path.join('../css/' + distributionFileName + '.css' ),
  title: 'Andromeda',
  verbose: true
};

module.exports = {
		devtool: 'source-map',
    target: 'node',
		module: {
			loaders: [
					{
            test: /\.scss/,
            loader: ExtractTextPlugin.extract(
              Object.assign(
                {
                  // fallback: require.resolve('style-loader'),
                  use: [
									  // 'style-loader',
									  'css-loader',
									  'sass-loader'
                    // {
                    //   loader: require.resolve('css-loader'),
                    //   options: {
                    //     importLoaders: 1,
                    //     minimize: true,
                    //     sourceMap: true,
                    //   },
                    // },
                    // {
                    //   loader: require.resolve('postcss-loader'),
                    //   options: {
                    //     // Necessary for external CSS imports to work
                    //     // https://github.com/facebookincubator/create-react-app/issues/2677
                    //     ident: 'postcss',
                    //     plugins: () => [
                    //       require('postcss-flexbugs-fixes'),
                    //       autoprefixer({
                    //         browsers: [
                    //           '>1%',
                    //           'last 4 versions',
                    //           'Firefox ESR',
                    //           'not ie < 9', // React doesn't support IE8 anyway
                    //         ],
                    //         flexbox: 'no-2009',
                    //       }),
                    //     ],
                    //   },
                    // },
                  ],
                },
                // extractTextPluginOptions
              )
            )
					},
      // {
      //   test: /\.(js|jsx)$/,
      //   enforce: 'pre',
      //   use: [
      //     {
      //       options: {
      //         // formatter: eslintFormatter,
      //         // eslintPath: require.resolve('eslint'),

      //       },
      //       // loader: require.resolve('eslint-loader'),
      //     },
      //   ],
      //   include: paths.appSrc,
      // },
			]
		},
		entry: {
		  'css/ulta-fed-core': path.join(root, './../scripts/compile-sass')
		},
		output: {
			path: path.join(root, './../dist/css'),
			filename: distributionFileName + '.js'
		},
		plugins: [
			new ExtractTextPlugin( distributionFileName + '.css', { allChunks: true } ),
			new KssWebpackPlugin( KssConfig ),
		]
	}
