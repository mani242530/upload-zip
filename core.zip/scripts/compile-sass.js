var recursive = require( 'recursive-readdir' );

export const importALlStyleFiles = ( ) => {
  require( './../src/theme/theme.scss' ); // eslint-disable-line
  recursive( './../src/views', function( err, files ){
    files.map( ( file ) => {
      if( ( /^(.(.*\.scss$))*$/ ).test( file ) ){
          require( './../src/views/'+file ); // eslint-disable-line
      }
    } )
  } );
}

importALlStyleFiles();
