
/**
 * Services Actions
 *
 * This file defines the action types and action creators for 'Services'
 **/


/**
 * ACTION TYPES
 */

export const TRIGGER_ANALYTICS_EVENT = 'ANALYTICS::TRIGGER_ANALYTICS_EVENT';
export const ANALYTICS_EVENT_FAILURE = 'ANALYTICS::ANALYTICS_EVENT_FAILURE';
export const ANALYTICS_EVENT_FIRED = 'ANALYTICS::ANALYTICS_EVENT_FIRED';


/**
 * ACTIONS
 */
export const triggerAnalyticsEvent = ( evt ) => ( { type: TRIGGER_ANALYTICS_EVENT, evt } );
export const analyticsEventFailure = ( err ) => ( { type: ANALYTICS_EVENT_FAILURE, err } );
export const analyticsEventFired = ( evt ) => ( { type: ANALYTICS_EVENT_FIRED, evt } );
