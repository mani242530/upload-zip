/**
 * Test for Analytics events
 */

import _ from 'lodash';
import * as events from './analytics.events';


describe( 'Analytics action events', () => {
  it( 'expect all events to be defined', () => {
    expect( events.TRIGGER_ANALYTICS_EVENT ).toBe( 'ANALYTICS::TRIGGER_ANALYTICS_EVENT' );
    expect( events.ANALYTICS_EVENT_FAILURE ).toBe( 'ANALYTICS::ANALYTICS_EVENT_FAILURE' );
    expect( events.ANALYTICS_EVENT_FIRED ).toBe( 'ANALYTICS::ANALYTICS_EVENT_FIRED' );
  } );
} );

describe( 'Analytics events', () => {

  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.triggerAnalyticsEvent ) ).toBe( true );
    expect( _.isFunction( events.analyticsEventFailure ) ).toBe( true );
    expect( _.isFunction( events.analyticsEventFired ) ).toBe( true );
  } );

  it( 'should create the proper action for triggerAnalyticsEvent', () => {
    const analyticErrors = [];
    const evt = {
      name: 'trackErrorDisplayed',
      data: analyticErrors
    }
    const creator = events.triggerAnalyticsEvent( evt );
    expect( creator ).toEqual( {
      type: events.TRIGGER_ANALYTICS_EVENT,
      evt:evt
    } )
  } );

  it( 'should create the proper action for analyticsEventFailure', () => {
    const err = 'insufficient data to trigger analytics event';
    const creator = events.analyticsEventFailure( err );
    expect( creator ).toEqual( {
      type: events.ANALYTICS_EVENT_FAILURE,
      err:err
    } )
  } );

  it( 'should create the proper action for analyticsEventFired', () => {
    const analyticErrors = [];
    const evt = {
      name: 'trackErrorDisplayed',
      data: analyticErrors
    }
    const creator = events.analyticsEventFired( evt );
    expect( creator ).toEqual( {
      type: events.ANALYTICS_EVENT_FIRED,
      evt:evt
    } )
  } );
} );
