/**
 * EmailSignUp Actions
 *
 * This file defines the action and action creators for 'ESU'
 **/


/**
 * ACTION TYPES
 */
export const TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM = 'ESU::TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM';
export const TOGGLE_SHOW_EMAIL_SIGN_UP_FORM = 'ESU::TOGGLE_SHOW_EMAIL_SIGN_UP_FORM';
export const SET_BODY_STYLE_PADDING_BOTTOM = 'ESU::SET_BODY_STYLE_PADDING_BOTTOM';
export const SET_STICKY_FOOTER_DISPLAY = 'ESU::SET_STICKY_FOOTER_DISPLAY';
export const SET_ESU_FORM_GT_SCREEN_HEIGHT = 'ESU::SET_ESU_FORM_GT_SCREEN_HEIGHT';
export const SET_ESU_CONTAINER_TRANSLATE_Y = 'ESU::SET_ESU_CONTAINER_TRANSLATE_Y';
export const SET_ESU_MODEL_OPENED_FLAG = 'ESU::SET_ESU_MODEL_OPENED_FLAG';
export const SET_ESU_MODEL_CLOSED_FLAG = 'ESU::SET_ESU_MODEL_CLOSED_FLAG';
export const SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR = 'ESU::SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR';


/**
 * ACTIONS
 */
export const toggleEligibleEmailSignUpForm = ( data ) => ( { type: TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM, data } );
export const toggleShowEmailSignUpForm = ( data ) => ( { type: TOGGLE_SHOW_EMAIL_SIGN_UP_FORM, data } );
export const setBodyStylePaddingBottom = ( data ) => ( { type: SET_BODY_STYLE_PADDING_BOTTOM, data } );
export const setStickyFooterDisplay = ( data ) => ( { type: SET_STICKY_FOOTER_DISPLAY, data } );
export const setESUFormGTScreenHeight = ( data ) => ( { type: SET_ESU_FORM_GT_SCREEN_HEIGHT, data } );
export const setESUContainerTranslateY = ( data ) => ( { type: SET_ESU_CONTAINER_TRANSLATE_Y, data } );
export const setESUModelOpenedFlag = () => ( { type: SET_ESU_MODEL_OPENED_FLAG } );
export const setESUModelClosedFlag = () => ( { type: SET_ESU_MODEL_CLOSED_FLAG } );
export const setSubmittedEmailSignUpFormError = ( data ) => ( { type: SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR, data } );
