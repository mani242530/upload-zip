/**
 * Footer Actions
 *
 * This file defines the action types and action creators for 'Footer'
 **/


/**
 * ACTION TYPES
 */
export const TOGGLE_ADDRESS_FIELD_DISPlAY = 'FORMS::TOGGLE_ADDRESS_FIELD_DISPlAY';
export const TOGGLE_ADDRESS2_FIELD_DISPlAY = 'FORMS::TOGGLE_ADDRESS2_FIELD_DISPlAY';
export const TOGGLE_INPUTFIELD_DISPLAY = 'FORMS::TOGGLE_INPUTFIELD_DISPLAY';
export const TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY = 'FORMS::TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY';
export const TOGGLE_EDIT_USER_DATA = 'FORMS::TOGGLE_EDIT_USER_DATA';
export const INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK = 'FORMS::INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK';
export const CLEAR_VALIDATION_ERROR = 'FORMS::CLEAR_VALIDATION_MESSAGES';
export const SET_COUPON_ERROR = 'FORMS::SET_COUPON_ERROR';
export const RESET_COUPON_STATE = 'FORMS::RESET_COUPON_STATE';
export const CLEAR_LOGIN_ERROR = 'FORMS::CLEAR_LOGIN_ERROR_MESSAGES';


/**
 * ACTIONS
 */
export const toggleAddressFieldDisplay = ( ) => ( { type: TOGGLE_ADDRESS_FIELD_DISPlAY } );
export const toggleAddress2FieldDisplay = ( ) => ( { type: TOGGLE_ADDRESS2_FIELD_DISPlAY } );
export const toggleAddressFieldDisplayPaymentForm = ( formName ) => ( { type: TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY, formName } );
export const toggleInputFieldDisplay = ( fieldName ) => ( { type: TOGGLE_INPUTFIELD_DISPLAY, fieldName } );
export const toggleEditUserData = () => ( { type: TOGGLE_EDIT_USER_DATA } );
export const removeValidationMessages = () =>( { type: CLEAR_VALIDATION_ERROR } );
export const goBack = () => ( { type: INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK } );
export const setCouponErrorMessage = ( errorMessage ) => ( { type: SET_COUPON_ERROR, errorMessage } );
export const resetCouponsState = () => ( { type: RESET_COUPON_STATE } );
export const removeLoginMessages = () =>( { type: CLEAR_LOGIN_ERROR } );
