/**
 * Test for Forms actions
 */

import _ from 'lodash';
import * as events from './forms.events';

describe( 'Forms action types', () => {

  describe( 'Alert Window Resize', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_ADDRESS_FIELD_DISPlAY ).toBe( 'FORMS::TOGGLE_ADDRESS_FIELD_DISPlAY' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.toggleAddressFieldDisplay ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.toggleAddressFieldDisplay( );
      expect( creator ).toEqual( {
        type: events.TOGGLE_ADDRESS_FIELD_DISPlAY
      } )
    } );
  } );

  describe( 'Alert Window Resize for address2', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_ADDRESS2_FIELD_DISPlAY ).toBe( 'FORMS::TOGGLE_ADDRESS2_FIELD_DISPlAY' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.toggleAddress2FieldDisplay ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.toggleAddress2FieldDisplay( );
      expect( creator ).toEqual( {
        type: events.TOGGLE_ADDRESS2_FIELD_DISPlAY
      } )
    } );
  } );

  describe( 'TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY ).toBe( 'FORMS::TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.toggleAddressFieldDisplayPaymentForm ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.toggleAddressFieldDisplayPaymentForm( );
      expect( creator ).toEqual( {
        type: events.TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY
      } )
    } );
  } );

  describe( 'TOGGLE_INPUTFIELD_DISPLAY', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_INPUTFIELD_DISPLAY ).toBe( 'FORMS::TOGGLE_INPUTFIELD_DISPLAY' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.toggleInputFieldDisplay ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.toggleInputFieldDisplay( );
      expect( creator ).toEqual( {
        type: events.TOGGLE_INPUTFIELD_DISPLAY
      } )
    } );
  } );

  describe( 'TOGGLE_EDIT_USER_DATA', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_EDIT_USER_DATA ).toBe( 'FORMS::TOGGLE_EDIT_USER_DATA' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.toggleEditUserData ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.toggleEditUserData( );
      expect( creator ).toEqual( {
        type: events.TOGGLE_EDIT_USER_DATA
      } )
    } );
  } );

  describe( 'CLEAR_VALIDATION_ERROR', () => {

    it( 'The action type should exist', () => {
      expect( events.CLEAR_VALIDATION_ERROR ).toBe( 'FORMS::CLEAR_VALIDATION_MESSAGES' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.removeValidationMessages ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.removeValidationMessages( );
      expect( creator ).toEqual( {
        type: events.CLEAR_VALIDATION_ERROR
      } )
    } );
  } );

  describe( 'INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK ', () => {

    it( 'The action type should exist', () => {
      expect( events.INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK ).toBe( 'FORMS::INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.goBack ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.goBack( );
      expect( creator ).toEqual( {
        type: events.INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK
      } )
    } );
  } );

  describe( 'SET_COUPON_ERROR', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_COUPON_ERROR ).toBe( 'FORMS::SET_COUPON_ERROR' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setCouponErrorMessage ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.setCouponErrorMessage( );
      expect( creator ).toEqual( {
        type: events.SET_COUPON_ERROR
      } )
    } );
  } );

  describe( 'RESET_COUPON_STATE', () => {

    it( 'The action type should exist', () => {
      expect( events.RESET_COUPON_STATE ).toBe( 'FORMS::RESET_COUPON_STATE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.resetCouponsState ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.resetCouponsState( );
      expect( creator ).toEqual( {
        type: events.RESET_COUPON_STATE
      } )
    } );
  } );

  describe( 'CLEAR_LOGIN_ERROR', () => {

    it( 'The action type should exist', () => {
      expect( events.CLEAR_LOGIN_ERROR ).toBe( 'FORMS::CLEAR_LOGIN_ERROR_MESSAGES' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.removeLoginMessages ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.removeLoginMessages( );
      expect( creator ).toEqual( {
        type: events.CLEAR_LOGIN_ERROR
      } )
    } );
  } );

} );
