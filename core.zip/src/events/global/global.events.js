/**
 * Global Actions
 *
 * This file defines the action types and action creators for 'Global'
 **/


/**
 * ACTION TYPES
 */
export const ALERT_WINDOW_RESIZE = 'GLOBAL::ALERT_WINDOW_RESIZE';
export const ALERT_DOCUMENT_SCROLL = 'GLOBAL::ALERT_DOCUMENT_SCROLL';
export const ENABLE_DISABLE_DOCUMENT_SCROLL = 'GLOBAL::ENABLE_DISABLE_DOCUMENT_SCROLL';
export const REGISTER_REMOVE_IOS_RUBBER_EFFECT = 'GLOBAL::REGISTER_REMOVE_IOS_RUBBER_EFFECT';
export const ENABLE_QUBIT_READY_FLAG = 'GLOBAL::ENABLE_QUBIT_READY_FLAG';
export const BROADCAST_MESSAGE_SET = 'GLOBAL::BROADCAST_MESSAGE_SET';
export const OPEN_STATUS_ERROR_POPUP = 'GLOBAL::OPEN_STATUS_ERROR_POPUP';
export const CLOSE_STATUS_ERROR_POPUP = 'GLOBAL::CLOSE_STATUS_ERROR_POPUP';
export const LOAD_SCRIPTS = 'GLOBAL::LOAD_SCRIPTS';


/**
 * ACTIONS
 */
export const alertWindowResize = ( screenHeight, screenWidth, isMobileDevice, hasInflectionChanged ) => ( {
  type: ALERT_WINDOW_RESIZE,
  screenHeight,
  screenWidth,
  isMobileDevice,
  hasInflectionChanged
} );
export const alertDocumentScroll = ( currentScrollPosition ) => ( { type: ALERT_DOCUMENT_SCROLL, currentScrollPosition } );
export const enableDisableDocumentScroll = ( enable ) => ( { type: ENABLE_DISABLE_DOCUMENT_SCROLL, enable } );
export const registerRemoveIOSRubberEffect = ( elem ) => ( { type: REGISTER_REMOVE_IOS_RUBBER_EFFECT, elem } );
export const enableQubitReadyFlag = () => ( { type: ENABLE_QUBIT_READY_FLAG } );
export const setBroadcastMessage = ( data ) => ( { type: BROADCAST_MESSAGE_SET, data } );
export const openStatusErrorPopUp = () =>( { type: OPEN_STATUS_ERROR_POPUP } );
export const closeStatusErrorPopUp = () =>( { type: CLOSE_STATUS_ERROR_POPUP } );
export const loadScripts = ()=>( { type: LOAD_SCRIPTS } );
