/**
 * Test for Global actions
 */

import _ from 'lodash';
import * as events from './global.events';


describe( 'Global action types', () => {

  describe( 'register element to remove rubber effect', () => {

    it( 'The action type should exist', () => {
      expect( events.REGISTER_REMOVE_IOS_RUBBER_EFFECT ).toBe( 'GLOBAL::REGISTER_REMOVE_IOS_RUBBER_EFFECT' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.registerRemoveIOSRubberEffect ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let elem = '<div></div>';
      let creator = events.registerRemoveIOSRubberEffect( elem );

      expect( creator ).toEqual( {
        type: events.REGISTER_REMOVE_IOS_RUBBER_EFFECT,
        elem
      } )
    } );
  } );

  describe( 'Enable/Disable document scroll', () => {

    it( 'The action type should exist', () => {
      expect( events.ENABLE_DISABLE_DOCUMENT_SCROLL ).toBe( 'GLOBAL::ENABLE_DISABLE_DOCUMENT_SCROLL' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.enableDisableDocumentScroll ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.enableDisableDocumentScroll( true );
      expect( creator ).toEqual( {
        type: events.ENABLE_DISABLE_DOCUMENT_SCROLL,
        enable: true
      } )
    } );
  } );

  describe( 'enableQubitReadyFlag', () => {
    it( 'The action type should exist', () => {
      expect( events.ENABLE_QUBIT_READY_FLAG ).toBe( 'GLOBAL::ENABLE_QUBIT_READY_FLAG' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.enableQubitReadyFlag ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.enableQubitReadyFlag();
      expect( creator ).toEqual( {
        type: events.ENABLE_QUBIT_READY_FLAG
      } )
    } );
  } );

  describe( 'Alert Window Resize', () => {

    it( 'The action type should exist', () => {
      expect( events.ALERT_WINDOW_RESIZE ).toBe( 'GLOBAL::ALERT_WINDOW_RESIZE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.alertWindowResize ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.alertWindowResize( 399 );
      expect( creator ).toEqual( {
        type: events.ALERT_WINDOW_RESIZE,
        screenHeight: 399
      } )
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.alertWindowResize( 10, 20 );
      expect( creator ).toEqual( {
        type: events.ALERT_WINDOW_RESIZE,
        screenHeight: 10,
        screenWidth: 20
      } )
    } );

    it( 'The action creator function should return the proper action creator object when all 4 params are not passed', () => {
      let creator = events.alertWindowResize( 1, 2, true );
      expect( creator ).toEqual( {
        type: events.ALERT_WINDOW_RESIZE,
        screenHeight: 1,
        screenWidth: 2,
        isMobileDevice: true
      } )
    } );

    it( 'The action creator function should return the proper action creator object when all 4 parameters are passed', () => {
      let creator = events.alertWindowResize( 1, 2, true, false );
      expect( creator ).toEqual( {
        type: events.ALERT_WINDOW_RESIZE,
        screenHeight: 1,
        screenWidth: 2,
        isMobileDevice: true,
        hasInflectionChanged: false
      } )
    } );
  } );

  describe( 'Load Scripts', () => {

    it( 'The action type should exist', () => {
      expect( events.LOAD_SCRIPTS ).toBe( 'GLOBAL::LOAD_SCRIPTS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.loadScripts ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.loadScripts( );
      expect( creator ).toEqual( {
        type: events.LOAD_SCRIPTS
      } )
    } );
  } );

  describe( 'Alert Document Scroll', () => {

    it( 'The action type should exist', () => {
      expect( events.ALERT_DOCUMENT_SCROLL ).toBe( 'GLOBAL::ALERT_DOCUMENT_SCROLL' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.alertDocumentScroll ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.alertDocumentScroll( 31112 );
      expect( creator ).toEqual( {
        type: events.ALERT_DOCUMENT_SCROLL,
        currentScrollPosition: 31112
      } )
    } );
  } );

  describe( 'Broadcast Message Set', () => {

    it( 'The action type should exist', () => {
      expect( events.BROADCAST_MESSAGE_SET ).toBe( 'GLOBAL::BROADCAST_MESSAGE_SET' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setBroadcastMessage ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = {
        assertiveMessageAdd: '$5 Gift Card (****1212 1212 1212 1212) Applied!'
      };
      const creator = events.setBroadcastMessage( data );
      expect( creator ).toEqual( {
        type: events.BROADCAST_MESSAGE_SET,
        data
      } );
    } );
  } );

  describe( 'CLOSE_STATUS_ERROR_POPUP', () => {

    it( 'The action type should exist', () => {
      expect( events.CLOSE_STATUS_ERROR_POPUP ).toBe( 'GLOBAL::CLOSE_STATUS_ERROR_POPUP' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.closeStatusErrorPopUp ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.closeStatusErrorPopUp( );
      expect( creator ).toEqual( {
        type: events.CLOSE_STATUS_ERROR_POPUP
      } );
    } );
  } );

  describe( 'OPEN_STATUS_ERROR_POPUP', () => {

    it( 'The action type should exist', () => {
      expect( events.OPEN_STATUS_ERROR_POPUP ).toBe( 'GLOBAL::OPEN_STATUS_ERROR_POPUP' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.openStatusErrorPopUp ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.openStatusErrorPopUp();
      expect( creator ).toEqual( {
        type: events.OPEN_STATUS_ERROR_POPUP
      } );
    } );
  } );

} );
