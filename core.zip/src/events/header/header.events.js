/**
 * Header Actions
 *
 * This file defines the action types and action creators for 'Header'
 **/


/**
 * ACTION TYPES
 */
export const TOGGLE_SEARCH_MODE = 'HEADER::TOGGLE_SEARCH_MODE';
export const SET_MAIN_NAV_BAR_HEIGHT = 'HEADER::SET_MAIN_NAV_BAR_HEIGHT';
export const SET_HEADER_HEIGHT = 'HEADER::SET_HEADER_HEIGHT';
export const SET_SHIPPING_BANNER_HEIGHT = 'HEADER::SET_SHIPPING_BANNER_HEIGHT';
export const GET_NAV_ITEM_LIST = 'HEADER::GET_NAV_ITEM_LIST';
export const SET_CURRENT_PAGE = 'SET_CURRENT_PAGE';
export const SET_HEADER_DISPLAY_MODE = 'HEADER::SET_HEADER_DISPLAY:MODE';
export const TOGGLE_REWARDS_OPTION = 'HEADER::TOGGLE_REWARDS_OPTION';
export const TOGGLE_SIGNIN_OPTION = 'HEADER::TOGGLE_SIGNIN_OPTION';




/**
 * ACTIONS
 */
export const setMainNavBarHeight = ( height ) => ( { type: SET_MAIN_NAV_BAR_HEIGHT, height } );
export const setHeaderHeight = ( headerHeight ) => ( { type: SET_HEADER_HEIGHT, headerHeight } );
export const setHeaderDisplayMode = ( deviceType, mode )=> ( { type: SET_HEADER_DISPLAY_MODE, mode, deviceType } );
export const setShippingBannerHeight = ( height ) => ( { type: SET_SHIPPING_BANNER_HEIGHT, height } );
export const toggleSearchMode = ( mode, stickyContainerOffset, stickyContainerHeight ) => (
  {
    type: TOGGLE_SEARCH_MODE,
    mode: ( mode === 'close' || mode === 'open' ) ? mode : 'close',
    stickyContainerOffset,
    stickyContainerHeight
  }
);

export const getNavItemList = ( navData ) => ( { type: GET_NAV_ITEM_LIST, navData } );
export const toggleRewardsOption = () => ( { type: TOGGLE_REWARDS_OPTION } );
export const toggleSigninOption = () => ( { type: TOGGLE_SIGNIN_OPTION } );
