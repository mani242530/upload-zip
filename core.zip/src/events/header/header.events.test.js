/**
 * Test for Header actions
 */

import _ from 'lodash';
import * as events from './header.events';

describe( 'Header action types', () => {
  it( 'The SET_HEADER_HEIGHT  action type should exist', () => {
    expect( events.SET_HEADER_HEIGHT ).toBe( 'HEADER::SET_HEADER_HEIGHT' );
  } );

  it( 'The SET_SHIPPING_BANNER_HEIGHT  action type should exist', () => {
    expect( events.SET_SHIPPING_BANNER_HEIGHT ).toBe( 'HEADER::SET_SHIPPING_BANNER_HEIGHT' );
  } );

  it( 'should have a action type of TOGGLE_SEARCH_MODE', () => {
    expect( events.TOGGLE_SEARCH_MODE ).toBe( 'HEADER::TOGGLE_SEARCH_MODE' );
  } );

  it( 'should have a action type of SET_MAIN_NAV_BAR_HEIGHT', () => {
    expect( events.SET_MAIN_NAV_BAR_HEIGHT ).toBe( 'HEADER::SET_MAIN_NAV_BAR_HEIGHT' );
  } );

  it( 'should have a action type of GET_NAV_ITEM_LIST', () => {
    expect( events.GET_NAV_ITEM_LIST ).toBe( 'HEADER::GET_NAV_ITEM_LIST' );
  } );

  it( 'should have a action type of TOGGLE_REWARDS_OPTION', () => {
    expect( events.TOGGLE_REWARDS_OPTION ).toBe( 'HEADER::TOGGLE_REWARDS_OPTION' );
  } );

  it( 'should have a action type of TOGGLE_SIGNIN_OPTION', () => {
    expect( events.TOGGLE_SIGNIN_OPTION ).toBe( 'HEADER::TOGGLE_SIGNIN_OPTION' );
  } );
} );

describe( 'Header action creators', () => {

  describe( 'toggleSearchMode', () => {

    it( 'should be a function that returns the proper action creator', () => {
      expect( _.isFunction( events.toggleSearchMode ) ).toBe( true );
      let creator = events.toggleSearchMode();

      expect( creator ).toEqual( {
        type: events.TOGGLE_SEARCH_MODE,
        mode: 'close'
      } );

      let creator2 = events.toggleSearchMode( 'open', 0, 1 );

      expect( creator2 ).toEqual( {
        type: events.TOGGLE_SEARCH_MODE,
        mode: 'open',
        stickyContainerOffset: 0,
        stickyContainerHeight: 1
      } );
    } );
  } );


  describe( 'setHeaderHeight', () => {

    it( 'setHeaderHeight should be a function', () => {
      expect( _.isFunction( events.setHeaderHeight ) ).toBe( true );

    } );

    it( 'should return a properly configed action creator object', () => {
      let creator = events.setHeaderHeight( 100 );

      expect( creator ).toEqual( {
        type: events.SET_HEADER_HEIGHT,
        headerHeight: 100
      } );

    } );

  } );

  describe( 'setShippingBannerHeight', () => {

    it( 'setShippingBannerHeight should be a function', () => {
      expect( _.isFunction( events.setShippingBannerHeight ) ).toBe( true );

    } );

    it( 'should return a properly configed action creator object', () => {
      let creator = events.setShippingBannerHeight( 30 );

      expect( creator ).toEqual( {
        type: events.SET_SHIPPING_BANNER_HEIGHT,
        height: 30
      } );

    } );

  } );


  describe( 'getNavItemList', () => {

    it( 'setMainNavBarHeight should be a function', () => {
      expect( _.isFunction( events.setMainNavBarHeight ) ).toBe( true );

    } );

    it( 'should return a properly configed action creator object', () => {
      let creator = events.setMainNavBarHeight( 30 );

      expect( creator ).toEqual( {
        type: events.SET_MAIN_NAV_BAR_HEIGHT,
        height: 30
      } );

    } );

  } );

  describe( 'getNavItemList', () => {

    it( 'getNavItemList should be a function', () => {
      expect( _.isFunction( events.getNavItemList ) ).toBe( true );

    } );

    it( 'should return a properly configed action creator object', () => {
      let creator = events.getNavItemList( [] );

      expect( creator ).toEqual( {
        type: events.GET_NAV_ITEM_LIST,
        navData: []
      } );

    } );

  } );

  describe( 'setHeaderDisplayMode', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_HEADER_DISPLAY_MODE ).toBe( 'HEADER::SET_HEADER_DISPLAY:MODE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setHeaderDisplayMode ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      var deviceType = 'mobile';
      var mode = '';
      let creator = events.setHeaderDisplayMode( deviceType, mode );
      expect( creator ).toEqual( {
        type: events.SET_HEADER_DISPLAY_MODE,
        deviceType,
        mode
      } )
    } );
  } );

  describe( 'toggleRewardsOption', () => {

    it( 'toggleRewardsOption should be a function', () => {
      expect( _.isFunction( events.toggleRewardsOption ) ).toBe( true );

    } );

    it( 'should return a properly configed action creator object', () => {
      let creator = events.toggleRewardsOption();

      expect( creator ).toEqual( {
        type: events.TOGGLE_REWARDS_OPTION
      } );

    } );

  } );

  describe( 'toggleSigninOption', () => {

    it( 'toggleSigninOption should be a function', () => {
      expect( _.isFunction( events.toggleSigninOption ) ).toBe( true );

    } );

    it( 'should return a properly configed action creator object', () => {
      let creator = events.toggleSigninOption();

      expect( creator ).toEqual( {
        type: events.TOGGLE_SIGNIN_OPTION
      } );

    } );

  } );

} );
