/**
 * HeroCarousel Actions
 *
 * This file defines the action types and action creators for 'ESU'
 **/


/**
 * ACTION TYPES
 */
export const TOGGLE_AUTO_PLAY = 'HERO_CAROUSEL::TOGGLE_AUTO_PLAY';
export const SET_CURRENT_CAROUSEL_SLIDE = 'HERO_CAROUSEL::SET_CURRENT_CAROUSEL_SLIDE';


/**
 * ACTIONS
 */
export const toggleAutoPlay = ( data ) => ( { type:TOGGLE_AUTO_PLAY, data } );
export const setCurrentCarouselSlide = ( data ) => ( { type: SET_CURRENT_CAROUSEL_SLIDE, data } );
