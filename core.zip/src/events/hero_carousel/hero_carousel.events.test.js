/**
 * Test for Footer actions
 */

import isFunction from 'lodash/isFunction';
import * as events from './hero_carousel.events';

describe( 'HeroCarousel action types', () => {

  it( 'The action type TOGGLE_AUTO_PLAY should exist', () => {
    expect( events.TOGGLE_AUTO_PLAY ).toBe( 'HERO_CAROUSEL::TOGGLE_AUTO_PLAY' );
  } );

  it( 'The action type SET_CURRENT_CAROUSEL_SLIDE should exist', () => {
    expect( events.SET_CURRENT_CAROUSEL_SLIDE ).toBe( 'HERO_CAROUSEL::SET_CURRENT_CAROUSEL_SLIDE' );
  } );

  it( 'The action creator toggleAutoPlay function should exist', () => {
    expect( isFunction( events.toggleAutoPlay ) ).toBe( true );
  } );

  it( 'The action creator setCurrentCarouselSlide function should exist', () => {
    expect( isFunction( events.setCurrentCarouselSlide ) ).toBe( true );
  } );

  it( 'The action creator toggleAutoPlay function should return the proper action creator object', () => {
    var data = true;
    let creator = events.toggleAutoPlay( data );
    expect( creator ).toEqual( {
      type: events.TOGGLE_AUTO_PLAY,
      data
    } )
  } );

  it( 'The action creator setCurrentCarouselSlide function should return the proper action creator object', () => {
    var data = 1;
    let creator = events.setCurrentCarouselSlide( data );
    expect( creator ).toEqual( {
      type: events.SET_CURRENT_CAROUSEL_SLIDE,
      data
    } )
  } );

} );
