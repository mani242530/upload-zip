/**
 * Language Actions
 *
 * This file defines all of the action type and action creators for 'Language'
 **/


/**
 * ACTION TYPES
 */
export const CHANGE_LOCALE = 'LOCALE/CHANGE_LOCALE';


/**
 * ACTIONS
 */
export const changeLocale = ( locale ) => ( { type: CHANGE_LOCALE, locale } );
