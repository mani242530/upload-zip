
/**
 * Test for Language actions
 */

import _ from 'lodash';
import * as events from './language.events';

describe( 'Language action types', () => {
  it( 'The CHANGE_LOCALE action  should be the right value', () => {
    expect( events.CHANGE_LOCALE ).toBe( 'LOCALE/CHANGE_LOCALE' );
  } );
} );

describe( 'Language action creators', () => {
  it( 'changeLocale should exist', () => {
    expect( _.isFunction( events.changeLocale ) ).toBe( true );
  } );
} );

describe( 'Language actions', () => {
  it( 'should create the proper action for changeLocale', () => {
    const locale = 'en';
    const creator = events.changeLocale( locale );
    expect( creator ).toEqual( {
      type: events.CHANGE_LOCALE,
      locale
    } );
  } );
} );
