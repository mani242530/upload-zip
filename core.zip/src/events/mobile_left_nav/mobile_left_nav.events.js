/**
 * MobileLeftNav Actions
 *
 * This file defines the action types and action creators for 'MobileLeftNav'
 **/


/**
 * ACTION TYPES
 */
export const SET_MOBILE_LEFT_NAV_DIMENSIONS = 'MOBILE_LEFT_NAV::SET_MOBILE_LEFT_NAV_DIMENSIONS';
export const TOGGLE_LEFT_NAV = 'MOBILE_LEFT_NAV::TOGGLE_LEFT_NAV';
export const OPEN_REWARDS = 'MOBILE_LEFT_NAV::OPEN_REWARDS';
export const SET_ACTIVE_LEVEL = 'MOBILE_LEFT_NAV::SET_ACTIVE_LEVEL';
export const SET_MOBILE_LEFT_NAV_SCROLL = 'MOBILE_LEFT_NAV::SET_MOBILE_LEFT_NAV_SCROLL';

/**
 * ACTIONS
 */
export const setMobileLeftNavDimensions = ( width, height ) => ( { type: SET_MOBILE_LEFT_NAV_DIMENSIONS, width, height } );
export const setActiveLevel = ( level, index ) => ( { type: SET_ACTIVE_LEVEL, level, index } );
export const toggleLeftNav = ( mode ) => ( { type: TOGGLE_LEFT_NAV, mode } );
export const openRewards = ( ) => ( { type: OPEN_REWARDS } );
export const setMobileLeftNavScroll = ( data ) => ( { type: SET_MOBILE_LEFT_NAV_SCROLL, data } );
