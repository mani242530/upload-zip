/**
 * Test for MobileLeftNav actions
 */

import _ from 'lodash';
import * as events from './mobile_left_nav.events';

describe( 'MobileLeftNav action types', () => {

  describe( 'Set Mobile Left Nav Dimensions', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_MOBILE_LEFT_NAV_DIMENSIONS ).toBe( 'MOBILE_LEFT_NAV::SET_MOBILE_LEFT_NAV_DIMENSIONS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setMobileLeftNavDimensions ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.setMobileLeftNavDimensions( 1257, 333 );
      expect( creator ).toEqual( {
        type: events.SET_MOBILE_LEFT_NAV_DIMENSIONS,
        width: 1257,
        height: 333
      } )
    } );
  } );

  describe( 'Set Mobile Left Nav Scroll', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_MOBILE_LEFT_NAV_SCROLL ).toBe( 'MOBILE_LEFT_NAV::SET_MOBILE_LEFT_NAV_SCROLL' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setMobileLeftNavScroll ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.setMobileLeftNavScroll( {
        globalHeight: 768, navContentHeight: 460, navHeaderHeight: 30, navFooterHeight: 130
      } );
      expect( creator ).toEqual( {
        type: events.SET_MOBILE_LEFT_NAV_SCROLL,
        data: {
          globalHeight: 768, navContentHeight: 460, navHeaderHeight: 30, navFooterHeight: 130
        }
      } )
    } );
  } );

  describe( 'Toggle Left Nav', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_LEFT_NAV ).toBe( 'MOBILE_LEFT_NAV::TOGGLE_LEFT_NAV' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.toggleLeftNav ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.toggleLeftNav( 2403 );
      expect( creator ).toEqual( {
        type: events.TOGGLE_LEFT_NAV,
        mode: 2403
      } )
    } );
  } );

  describe( 'Open Rewards', () => {

    it( 'The action type should exist', () => {
      expect( events.OPEN_REWARDS ).toBe( 'MOBILE_LEFT_NAV::OPEN_REWARDS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.openRewards ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.openRewards();
      expect( creator ).toEqual( {
        type: events.OPEN_REWARDS
      } )
    } );
  } );

  describe( 'Set Active Level', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_ACTIVE_LEVEL ).toBe( 'MOBILE_LEFT_NAV::SET_ACTIVE_LEVEL' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setActiveLevel ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      var level = [];
      var index =  0;
      let creator = events.setActiveLevel( level, index );
      expect( creator ).toEqual( {
        type: events.SET_ACTIVE_LEVEL,
        level,
        index
      } )
    } );
  } );

} );
