
/**
 * Footer Actions
 *
 * This file defines the action types and action creators for 'Footer'
 **/


/**
 * ACTION TYPES
 */
export const USER_LOGOUT = 'USER::USER_LOGOUT';
export const RESET_USER_LOGOUT = 'USER::RESET_USER_LOGOUT';


/**
 * ACTIONS
 */
export const logoutUser = ( history ) => ( { type: USER_LOGOUT, history } );
export const resetLogoutFlag = () => ( { type: RESET_USER_LOGOUT } );
