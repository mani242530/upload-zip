/**
 * Test for User actions
 */

import _ from 'lodash';
import * as events from './profile.events';


describe( 'User action types', () => {
  it( 'expect all types to be defined', () => {
    expect( events.USER_LOGOUT ).toBe( 'USER::USER_LOGOUT' );
    expect( events.RESET_USER_LOGOUT ).toBe( 'USER::RESET_USER_LOGOUT' );
  } );
} );

describe( 'User actions', () => {
  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.logoutUser ) ).toBe( true );
    expect( _.isFunction( events.resetLogoutFlag ) ).toBe( true );
  } );

  it( 'should create the proper action for logoutUser', () => {
    const history = jest.fn()
    const creator = events.logoutUser( history );
    expect( creator ).toEqual( {
      type: events.USER_LOGOUT,
      history:history
    } )
  } );

  it( 'should create the proper action for resetLogoutFlag', () => {
    const creator = events.resetLogoutFlag();
    expect( creator ).toEqual( {
      type: events.RESET_USER_LOGOUT
    } )
  } );
} );
