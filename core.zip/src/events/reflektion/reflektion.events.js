/**
 * Services Actions
 *
 * This file defines the action types and action creators for Reflektion
 **/


/**
 * ACTION TYPES
 */
export const TRIGGER_REFLEKTION_EVENTS = 'REFLEKTION::TRIGGER_REFLEKTION_EVENTS';


/**
     * ACTIONS
     */
export const triggerReflektionEvents = ( data ) => ( { type: TRIGGER_REFLEKTION_EVENTS, data } );
