
/**
 * Test for Language actions
 */

import _ from 'lodash';
import * as events from './reflektion.events';


describe( 'Reflektion action types', () => {
  it( 'The TRIGGER_REFLEKTION_EVENTS action  should be the right value', () => {
    expect( events.TRIGGER_REFLEKTION_EVENTS ).toBe( 'REFLEKTION::TRIGGER_REFLEKTION_EVENTS' );
  } );
} );

describe( 'Reflektion action creators', () => {
  it( 'TRIGGER_REFLEKTION_EVENTS should exist', () => {
    expect( _.isFunction( events.triggerReflektionEvents ) ).toBe( true );
  } );
} );

describe( 'Reflektion actions', () => {
  it( 'should create the proper action for triggerReflektionEvents', () => {
    const data = {
      'type': 'a2c',
      'name': 'cart',
      'value': {
        'products': [
          {
            'sku': '1011045'
          }
        ]
      }
    };
    const creator = events.triggerReflektionEvents( data );
    expect( creator ).toEqual( {
      type: events.TRIGGER_REFLEKTION_EVENTS,
      data: data
    } );
  } );
} );
