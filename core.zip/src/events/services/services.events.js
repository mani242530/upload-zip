
/**
 * Services Actions
 *
 * This file defines the action types and action creators for 'Services'
 **/


/**
 * ACTION TYPES
 */
export const PERSIST_SESSION_DATA = 'SERVICES::PERSIST_SESSION_DATA';
export const SESSION_TOKEN_REQUESTED = 'SERVICES::SESSION_TOKEN_REQUESTED';
export const CHECK_SESSION_TIMESTAMP = 'SERVICES::CHECK_SESSION_TIMESTAMP';
export const SESSION_TIMEOUT = 'SERVICES::SESSION_TIMEOUT';
export const PAGE_REDIRECT = 'SERVICES::PAGE_REDIRECT';
export const CHECKOUT_REDIRECT_LISTENER = 'SERVICES::CHECKOUT_REDIRECT_LISTENER';

/** this is ammended dynamically by the registration event below, which is called in SAGAS default export **/
export const DYNAMIC_EVENT_TYPES = {};


/**
 * ACTIONS
 */

/** this is ammended dynamically by the registration event below, which is called in SAGAS default export **/
export const DYNAMIC_ACTIONS = {};
export const persistSessionData = ( isSecureProtocol, token ) => ( { type: PERSIST_SESSION_DATA, isSecureProtocol, token } );
export const sessionTimeout = () => ( { type: SESSION_TIMEOUT } );
export const checkSessionTimestamp = ( lastFetchedTime ) => ( { type: CHECK_SESSION_TIMESTAMP, lastFetchedTime } );
export const sessionTokenRequested = () => ( { type: SESSION_TOKEN_REQUESTED } );
export const pageRedirect = ( from, to ) => ( { type: PAGE_REDIRECT, from, to } );
export const checkoutRedirectListener = ( history, qty, loadCartMessages ) => ( {
  type: CHECKOUT_REDIRECT_LISTENER, history, qty, loadCartMessages
} );

export const eventTypes = [
  'REQUESTED',
  'SUCCESS',
  'FAILURE',
  'LOADING',
  'CANCELED'

]

export const getActionDefinition = ( key, type ) => {
  return DYNAMIC_ACTIONS[`${key.toLowerCase()}Data${getActionName( type )}`];
}

export const getServiceType = ( key, type ) => {

  return DYNAMIC_EVENT_TYPES[`${key.toUpperCase()}_DATA_${type.toUpperCase()}`];

};

export const getActionName = ( val ) => {
  return val.charAt( 0 ).toUpperCase() + val.substr( 1 ).toLowerCase();
};

export const registerServiceName = ( id ) => {
  eventTypes.map( ( val ) => {
    let key = id.toUpperCase();
    let name = `${key}_DATA_${val}`;
    // create the event name
    DYNAMIC_EVENT_TYPES[ name ] = `SERVICES::${name}`;
    // create the requst action creator
    let eActionKey = getActionName( val );

    DYNAMIC_ACTIONS[`${id.toLowerCase()}Data${eActionKey}`] = ( data ) => ( { type: DYNAMIC_EVENT_TYPES[name], data } );

  } );
};
