
/**
 * Test for Services actions
 */

import _ from 'lodash';
import * as events from './services.events';



describe( 'Services action types', () => {

  describe( 'sessionTimeout', () => {
    it( 'should have the proper event value', () => {
      expect( events.SESSION_TIMEOUT ).toBe( 'SERVICES::SESSION_TIMEOUT' );
    } )

    it( 'should have an event for PERSIST_SESSION_DATA', () => {
      expect( events.PERSIST_SESSION_DATA ).toBe( 'SERVICES::PERSIST_SESSION_DATA' );
    } );

    it( 'should have the proper event creator defined', () => {
      expect( _.isFunction( events.sessionTimeout ) ).toBeTruthy();
    } );

    it( 'should create the proper action creator object', () => {
      const actionCreator = events.sessionTimeout( );
      expect( actionCreator ).toEqual( { type: events.SESSION_TIMEOUT } );
    } );
  } );

  describe( 'persisteSessionData', () => {
    it( 'should have an action created called persisteSessionData', () => {
      expect( _.isFunction( events.persistSessionData ) ).toBeTruthy();
    } );

    it( 'should return the proper action creator construct', () => {
      let isSecureProtocol = 'someval';
      let token = 'abc123';
      let actionCreator = events.persistSessionData( isSecureProtocol, token );

      expect( actionCreator ).toEqual( {
        type: events.PERSIST_SESSION_DATA,
        isSecureProtocol,
        token
      } )
    } );
  } );

  describe( 'Check session timestamp', () => {
    it( 'should have the proper event value', () => {
      expect( events.CHECK_SESSION_TIMESTAMP ).toBe( 'SERVICES::CHECK_SESSION_TIMESTAMP' );
    } )

    it( 'should have the proper event creator defined', () => {
      expect( _.isFunction( events.checkSessionTimestamp ) ).toBeTruthy();
    } );

    it( 'should create the proper action creator object', () => {
      let res = '4352123';
      let actionCreator = events.checkSessionTimestamp( res );

      expect( actionCreator ).toEqual( {
        type: events.CHECK_SESSION_TIMESTAMP,
        lastFetchedTime: res
      } );

    } );

  } );


  describe( 'Session token requested', () => {

    it( 'The action type should exist', () => {
      expect( events.SESSION_TOKEN_REQUESTED ).toBe( 'SERVICES::SESSION_TOKEN_REQUESTED' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.sessionTokenRequested ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.sessionTokenRequested();
      expect( creator ).toEqual( {
        type: events.SESSION_TOKEN_REQUESTED
      } )
    } );
  } );


  describe( 'pageRedirect', () => {
    it( 'The action type should exist', () => {
      expect( events.PAGE_REDIRECT ).toBe( 'SERVICES::PAGE_REDIRECT' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.pageRedirect ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const from = jest.fn();
      const to = jest.fn();
      let creator = events.pageRedirect( from, to );
      expect( creator ).toEqual( {
        type: events.PAGE_REDIRECT,
        from,
        to
      } );
    } );
  } );

  describe( 'checkoutRedirectListener', () => {
    it( 'The action type should exist', () => {
      expect( events.CHECKOUT_REDIRECT_LISTENER ).toBe( 'SERVICES::CHECKOUT_REDIRECT_LISTENER' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.checkoutRedirectListener ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const history = jest.fn();
      const qty = 4;
      const loadCartMessages = {};
      let creator = events.checkoutRedirectListener( history, qty, loadCartMessages );
      expect( creator ).toEqual( {
        type: events.CHECKOUT_REDIRECT_LISTENER,
        history,
        qty,
        loadCartMessages
      } );
    } );
  } );

  describe( 'eventTypes', () => {

    it( 'should have the right defined events.eventTypes for interpolation', () => {
      expect( events.eventTypes ).toEqual( [
        'REQUESTED',
        'SUCCESS',
        'FAILURE',
        'LOADING',
        'CANCELED'
      ] );
    } );
  } );

  events.registerServiceName( 'session' );

  describe( 'getActionName', () => {
    it( 'should format the action name with a capital first letter and lowercase for the rest', () => {

      expect( events.getActionName( 'sUcCess' ) ).toBe( 'Success' );
    } );
  } );

  describe( 'registerServiceName', () => {

    it( 'should add events based on the event keys to the action object', () => {

      events.registerServiceName( 'DONUTS' );

      expect( _.isFunction( events.DYNAMIC_ACTIONS.donutsDataRequested ) ).toBeTruthy();
      expect( _.isFunction( events.DYNAMIC_ACTIONS.donutsDataSuccess ) ).toBeTruthy();
      expect( _.isFunction( events.DYNAMIC_ACTIONS.donutsDataFailure ) ).toBeTruthy();
      expect( _.isFunction( events.DYNAMIC_ACTIONS.donutsDataLoading ) ).toBeTruthy();



      expect( events.DYNAMIC_EVENT_TYPES.DONUTS_DATA_REQUESTED ).toEqual( 'SERVICES::DONUTS_DATA_REQUESTED' );
      expect( events.DYNAMIC_EVENT_TYPES.DONUTS_DATA_SUCCESS ).toEqual( 'SERVICES::DONUTS_DATA_SUCCESS' );

      expect( events.DYNAMIC_EVENT_TYPES.DONUTS_DATA_FAILURE ).toEqual( 'SERVICES::DONUTS_DATA_FAILURE' );
      expect( events.DYNAMIC_EVENT_TYPES.DONUTS_DATA_LOADING ).toEqual( 'SERVICES::DONUTS_DATA_LOADING' );
    } );
  } );

  describe( 'getActionDefinition', ()=> {

    it( 'should return a properly formatted action definition name', ()=> {

      let definition = events.getActionDefinition( 'session', 'success' );
      expect( _.isFunction( definition ) ).toBeTruthy();

    } );

  } );

  describe( 'getServiceType', ()=> {

    it( 'should return the proper action type from the types object', () => {
      expect( events.getServiceType( 'session', 'loading' ) ).toEqual( 'SERVICES::SESSION_DATA_LOADING' );
    } );

  } );


} );
