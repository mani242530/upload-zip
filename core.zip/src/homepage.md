

<div class="kss-heroslot">
    <h1> ANDROMEDA <span class="kss-heroslot--smallText">DESIGN SYSTEM </span></h1>
    <p> a guide from ULTA Beauty to build delightful experiences </p>
</div>

<div class="kss-homepage__main">
    <div class="kss-homepage__main--column">
        <div class="kss-homepage__main--placeholder"></div>
        <h2>Getting Started</h2>
        <p>Design system onboarding</p>
    </div>
    <div class="kss-homepage__main--column">
        <div class="kss-homepage__main--placeholder"></div>
        <h2>Components</h2>
        <p>Interface building blocks</p>
    </div>
    <div class="kss-homepage__main--column">
        <div class="kss-homepage__main--placeholder"></div>
        <h2>Guidelines</h2>
        <p>All things font, color and design</p>
    </div>
</div>


A pattern library (Live Style Guide) is a living document of code, which details all the various elements and coded modules of your site or application. Beyond its use in consolidating the front-end code, it also documents the visual language, such as header styles and color palettes, used to create the site; thus producing visual consistency. This way, it’s a one-stop place for the entire team—from product owners and producers to designers and developers—to reference when discussing site changes and iterations.

By documenting and assembling a reference site of our patterns, we were able to speed up our process and solve some internal communication problems. A common lexicon of code and UI elements benefits us in a few ways:

* We can build consistently, focusing our energy on workflows and logic, not web forms and list items.
* We can reuse code instead of reinventing the wheel or roping in an engineer.
* We can see all of our patterns in one place, quickly revealing maintenance issues.5
* Our pattern library is both a learning tool and a compass to correct our course as we build new things.

## It’s a living, learning library.

We believe iteration is a vital part of the design process. Being able to change fast requires both an efficient workflow and a well defined collection of reusable parts that can assemble new interfaces quickly.

We guard our pattern library jealously, and add new patterns only when the case for doing so is sound. New patterns come at a high cost—they require new design elements, additional code, maintenance, and they increase the cognitive load on users.

As the craft of Web design continues to evolve, we’re recognizing the need to develop thoughtful design systems
</div>
