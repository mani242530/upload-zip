
/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 **/

import { combineReducers } from 'redux';
import {
  reducer as formReducer,
  actionTypes as formActionTypes
} from 'redux-form';

import global from './models/global/global.model';
import page from './models/page/page.model';
import session from './models/session/session.model';
import user from './models/user/user.model';
import language from './models/language/language.model';
// import reducers that are globally required in the ULTA app
//


export default ( asyncReducers ) => {
  return combineReducers( {
    global,
    session,
    user,
    language,
    pagedata: page,
    form: formReducer,
    ...asyncReducers
  } )
}
