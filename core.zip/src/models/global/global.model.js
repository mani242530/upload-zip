/**
 * Global Redux reducer Module
 *
 */

import { createSelector } from 'reselect';
import cloneDeep from 'lodash/cloneDeep';
import {
  REGISTER_REMOVE_IOS_RUBBER_EFFECT,
  ENABLE_QUBIT_READY_FLAG,
  ALERT_WINDOW_RESIZE,
  ENABLE_DISABLE_DOCUMENT_SCROLL,
  BROADCAST_MESSAGE_SET,
  OPEN_STATUS_ERROR_POPUP,
  CLOSE_STATUS_ERROR_POPUP
} from '../../events/global/global.events';

import { isServer } from '../../utils/device_detection/device_detection';

import {
  TOGGLE_LEFT_NAV
} from '../../events/mobile_left_nav/mobile_left_nav.events'
import {
  TOGGLE_SEARCH_MODE
} from '../../events/header/header.events';
import {
  TOGGLE_SHOW_EMAIL_SIGN_UP_FORM
} from '../../events/email_sign_up/email_sign_up.events';

import {
  getServiceType,
  getActionDefinition
} from '../../events/services/services.events';



const getInnerWidth = function(){
  return window.innerWidth < 992
};

const getWiderWidth = function(){
  return window.innerWidth > 991
};

/**
 * default state for the Global duck module.
 */
export const initialState = {
  HTML_ELEMENT_CLASS: '',
  screenWidth: 0,
  screenHeight: 0,
  mobileWidth:992,
  currentScrollPosition: 0,
  displayType:'',
  blockDocumentScroll: false,
  noRubberEffect: [],
  switchData: undefined,
  qubitReady: false,
  fireLps: false,
  canFireLpsEvent: false,
  assertiveMessageAdd: '',
  isMobileDevice: isServer() ? false : getInnerWidth(),
  isWiderDevice: isServer() ? false : getWiderWidth(),
  isServerSideRendered:false,
  displayStatusErrorPopUp:false
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){
  switch ( action.type ){

    case getServiceType( 'switches', 'success' ):
      return {
        ...state,
        switchData: {
          switches:{
            ...action.data.switches,
            /**
              * This is a derived flag to enable virtual try on, this will be turned on when enableVirtualTryOn and enableVirtualTryOnLandingPage flags are true
              */
            virtualTryOnEnabled: action.data.switches.enableVirtualTryOn && action.data.switches.enableVirtualTryOnLandingPage,

            /**
              * This is a derived flag to determine when to fire the events, this will be turned on when either visualSearchEnabled flag is true or enableRfkRecommendation is true or enableRfkEvents is true
              * i.e either if Reflektion Search, Refektion Recommendation and enableRfkEvents is turned on
              */
            enableRefBeaconScript:!!action.data.switches.visualSearchEnabled || !!action.data.switches.enableRfkRecommendation || !!action.data.switches.enableRfkEvents
          }
        }
      };

    case REGISTER_REMOVE_IOS_RUBBER_EFFECT:
      let registry = cloneDeep( state.noRubberEffect );

      registry.push( action.elem );
      return {
        ...state,
        noRubberEffect: registry
      };

    case ENABLE_QUBIT_READY_FLAG:
      return {
        ...state,
        qubitReady: true,
        canFireLpsEvent: state.fireLps === true
      };

    case getServiceType( 'RealtimeOLPS', 'success' ):

      return {
        ...state,
        fireLps: true,
        canFireLpsEvent: !!( ( action.data.olpsResponse.responseType === '01' && state.qubitReady === true ) )
      };

    case ALERT_WINDOW_RESIZE:

      let displayType, isMobileDevice;

      if( action.screenWidth < state.mobileWidth ){
        displayType = 'mobile';
        isMobileDevice = true;
      }
      else {
        displayType = 'desktop';
        isMobileDevice = false;
      }

      return {
        ...state,
        screenHeight: action.screenHeight,
        screenWidth: action.screenWidth,
        displayType,
        isMobileDevice,
        isWiderDevice:getWiderWidth()
      };


    case ENABLE_DISABLE_DOCUMENT_SCROLL:
      return {
        ...state,
        blockDocumentScroll: action.enable
      };

    case TOGGLE_SHOW_EMAIL_SIGN_UP_FORM:
      let HTML_ELEMENT_CLASSNAME = ( action.data === true ) ? 'BLOCK_PAGE_SCROLL' : '';
      return {
        ...state,
        HTML_ELEMENT_CLASS: HTML_ELEMENT_CLASSNAME
      };

    case TOGGLE_LEFT_NAV:
    case TOGGLE_SEARCH_MODE:
      let HTML_ELEMENT_CLASS = ( action.mode === 'open' ) ? 'BLOCK_PAGE_SCROLL' : '';
      return {
        ...state,
        HTML_ELEMENT_CLASS
      };

    case BROADCAST_MESSAGE_SET:
      return {
        ...state,
        assertiveMessageAdd:action.data
      };

    case OPEN_STATUS_ERROR_POPUP:
      return {
        ...state,
        displayStatusErrorPopUp:true
      }

    case CLOSE_STATUS_ERROR_POPUP:
      return {
        ...state,
        displayStatusErrorPopUp:false
      }

    default:
      return state;
  }
}



export const selectGlobal = ( state ) => state.global;

export const makeGetSwitchesData = () => createSelector(
  selectGlobal,
  ( globalState ) => globalState.switchData
);



export const makeGetDocumentDimensions = () => createSelector(
  selectGlobal,
  ( globalState ) => ( { width: globalState.screenWidth, height: globalState.screenHeight } )
);
