import _ from 'lodash';
import languageReducer, { getLanguageState, getLocale, initialState } from './language.model';
import {
  CHANGE_LOCALE
} from '../../events/language/language.events'
import { configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';


let store = configureStore( );


describe( 'Language Reducer module', ()=> {

  const expectedState = {
    locale: 'en'
  } ;

  it( 'Exports a reducer function default', ()=> {
    expect( _.isFunction( languageReducer ) ).toBe( true );
  } );

  it( 'should have the proper default state', () => {
    expect( initialState ).toEqual( expectedState );
  } );

  it( 'should return the initial state', () => {
    expect( languageReducer( undefined, {} ) ).toEqual( initialState );
  } );

  it( 'calling the changeLocale', () => {
    const actionCreator = {
      type: CHANGE_LOCALE,
      locale:initialState.locale
    }
    let expected = { locale: initialState.locale };
    expect( languageReducer( {}, actionCreator ) ).toEqual( expected );
  } );

  describe( 'getLanguageState', () => {

    it( 'getLanguageState should return language state', () => {
      const state = {
        language: {
          HTML_ELEMENT_CLASS: '',
          screenWidth: 0,
          screenHeight: 0,
          currentScrollPosition: 0,
          displayType:'',
          blockDocumentScroll: false,
          noRubberEffect: [],
          switchData: undefined,
          qubitReady: false,
          fireLps: false,
          canFireLpsEvent: false,
          assertiveMessageAdd: '',
          isServerSideRendered:false,
          displayStatusErrorPopUp:false
        }
      };
      expect( getLanguageState()( state ) ).toEqual( state.language );
    } );

    it( 'should return the languageState.locale from the language reducer', () => {
      const languageState = {
        locale :'test'
      };
      store.getState().language.locale = 'test';
      const selector = getLocale();
      expect( selector( store.getState() ) ).toEqual( languageState.locale );
    } );
  } );

} );
