/**
 * Page Redux reducer Module
 *
 */


import {
  getServiceType,
  getActionDefinition
} from '../../events/services/services.events';

import {
  TOGGLE_EDIT_USER_DATA,
  TOGGLE_INPUTFIELD_DISPLAY,
  TOGGLE_ADDRESS_FIELD_DISPlAY,
  INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK,
  TOGGLE_ADDRESS2_FIELD_DISPlAY,
  CLEAR_VALIDATION_ERROR
} from '../../events/forms/forms.events';



/**
 * default state for the Page reducer
 */

export const initialState = {
  formConfig: {
    fieldShowHideToggleData: {
      password: false,
      ssn: false,
      LoginPassword: false,
      ResetPassword:false
    }
  },
  creditcards: {
    lpsRequestComplete: false,
    editUserData: false,
    addressOpen: false,
    address2Open: false,
    applyFormIsSubmitting: false,
    lpsFlag: undefined,
    beautyClubNumberisRequired: false,
    hasProfileData: false,
    instantCreditResponse: {}
  },
  homepage:{}
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){

  switch ( action.type ){

    // Data from service to populate the shopping cart count
    case getServiceType( 'page', 'success' ):

      return {
        ...state,
        homepage: action.data

      }

    case getServiceType( 'banner', 'success' ):

      return {
        ...state,
        creditcards: {
          ...state.creditcards,
          bannerImageUri: action.data.bannerImageUri
        }
      }

    case getServiceType( 'profile', 'success' ):

      return {
        ...state,
        creditcards: {
          ...state.creditcards,
          ...( action.data.profileInfo?.address && {
            hasProfileData: true
          } )
        }
      }

    case getServiceType( 'lpsLookUp', 'requested' ):
      return {
        ...state,
        creditcards: {
          ...state.creditcards,
          lpsRequestComplete: false
        }
      }

      // lpsLookUp
    case getServiceType( 'lpsLookUp', 'success' ):

      let beautyClubNumberisRequired = ( action.data.LookupExactMatchResult === '405' );


      return {
        ...state,
        creditcards: {
          ...state.creditcards,
          lpsFlag: action.data.LookupExactMatchResult,
          lpsRequestComplete: true,
          beautyClubNumberisRequired
        }
      }

    case getServiceType( 'applyForm', 'loading' ):
      return {
        ...state,
        creditcards:{
          ...state.creditcards,
          applyFormIsSubmitting: true
        }
      }
    case getServiceType( 'applyForm', 'success' ):
      return {
        ...state,
        creditcards:{
          ...state.creditcards,
          applyFormIsSubmitting: false,
          instantCreditResponse: action.data.instantCreditResponse,
          ...( ( action.data.messageBeans && action.data.messageBeans.length > 0 ) && { messageBeans: action.data.messageBeans } )
        }
      }
    case getServiceType( 'applyForm', 'failure' ):
      return {
        ...state,
        creditcards:{
          ...state.creditcards,
          applyFormIsSubmitting: false
        }
      }

    case getServiceType( 'prescreenApply', 'loading' ):
      return {
        ...state,
        creditcards:{
          ...state.creditcards,
          applyFormIsSubmitting: true
        }
      }
    case getServiceType( 'prescreenApply', 'success' ):
      return {
        ...state,
        creditcards:{
          ...state.creditcards,
          applyFormIsSubmitting: false,
          instantCreditResponse: action.data.instantCreditResponse,
          ...( ( action.data.messageBeans && action.data.messageBeans.length > 0 ) && { messageBeans: action.data.messageBeans } )
        }
      }
    case getServiceType( 'prescreenApply', 'failure' ):
      return {
        ...state,
        creditcards:{
          ...state.creditcards,
          applyFormIsSubmitting: false
        }
      }

    case getServiceType( 'switches', 'success' ):
      return {
        ...state,
        creditcards: {
          ...state.creditcards,
          guestServiceNumber: action.data.switches.guestServiceNumber
        }
      }

    case TOGGLE_EDIT_USER_DATA:
      return {
        ...state,
        creditcards: {
          ...state.creditcards,
          editUserData: !state.creditcards.editUserData

        }
      }

    case TOGGLE_INPUTFIELD_DISPLAY:

      return {
        ...state,
        creditcards: {
          ...state.creditcards
        },
        formConfig: {
          ...state.formConfig,
          fieldShowHideToggleData: {
            ...state.formConfig.fieldShowHideToggleData,
            [ action.fieldName ]: !state.formConfig.fieldShowHideToggleData[ action.fieldName ]
          }
        }
      }

    case TOGGLE_ADDRESS_FIELD_DISPlAY:
      return {
        ...state,
        creditcards: {
          ...state.creditcards,
          addressOpen: !state.creditcards.addressOpen

        }
      }

    case INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK:
      return {
        ...state,
        creditcards: {
          ...state.creditcards,
          instantCreditResponse: {},
          hasProfileData: false

        }
      }

    case TOGGLE_ADDRESS2_FIELD_DISPlAY:
      return {
        ...state,
        creditcards: {
          ...state.creditcards,
          address2Open: !state.creditcards.address2Open

        }
      }

    case CLEAR_VALIDATION_ERROR:
      return {
        ...state,
        creditcards:{
          ...state.creditcards,
          messageBeans: undefined
        }
      }


    default:
      return state;
  }
}
