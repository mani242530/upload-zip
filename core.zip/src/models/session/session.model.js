/**
 * Global Redux reducer Module
 *
 */

import { createSelector } from 'reselect';


import {
  PERSIST_SESSION_DATA,
  SESSION_TIMEOUT,
  getServiceType,
  getActionDefinition
} from '../../events/services/services.events';



/**
 * default state for the Global duck module.
 */
export const initialState = {
  secureToken: undefined,
  unsecureToken: undefined,
  sessionID: undefined,
  activeSession: undefined
};

/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){
  switch ( action.type ){

    case PERSIST_SESSION_DATA:
      return {
        ...state,
        ...( !action.isSecureProtocol && { unsecureToken: action.token } ),
        ...( action.isSecureProtocol && { secureToken: action.token } )
      }

    case getServiceType( 'session', 'requested' ):
      return {
        ...state,
        activeSession: undefined
      }

    case getServiceType( 'user', 'success' ):
      return {
        ...state,
        activeSession: true
      }

    case getServiceType( 'user', 'failure' ):
    case getServiceType( 'session', 'failure' ):
    case getServiceType( 'logout', 'success' ):
    case SESSION_TIMEOUT:
      return {
        ...state,
        unsecureToken: undefined,
        secureToken: undefined,
        activeSession: undefined
      }

    default:
      return state;
  }
}


const selectSession = ( state ) => state.session;


export const makeGetSessionInfo = () => createSelector(
  selectSession,
  ( sessionState ) => {
    return {
      ...( sessionState.secureToken && { secureToken: sessionState.secureToken } ),
      ...( sessionState.unsecureToken && { unsecureToken: sessionState.unsecureToken } )
    }
  }
)
