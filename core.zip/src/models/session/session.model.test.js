import reducer, {
  initialState,
  makeGetSessionInfo
} from './session.model';


import {
  PERSIST_SESSION_DATA,
  SESSION_TIMEOUT,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from '../../events/services/services.events';




import { configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';


let store = configureStore( );


describe( 'session data async calls', () => {

  it( 'should update the activeSession when user succes event is dispatched', () => {
    registerServiceName( 'user' );
    let res = {
      sessionConfirmationNumber: 3030
    };

    let actionCreator = getActionDefinition( 'user', 'success' )( res.sessionConfirmationNumber );


    expect( reducer( {}, actionCreator ) ).toEqual( {
      activeSession: true
    } );

  } );

  it( 'should have the activeSession as undefined when session requested', () => {
    registerServiceName( 'session' );
    const actionCreator = getActionDefinition( 'session', 'requested' )();

    expect( reducer( {}, actionCreator ) ).toEqual( {
      activeSession: undefined
    } );
  } );

  it( 'should set activeSession,secureToken,unsecureToken as undefined when session failure', () => {
    registerServiceName( 'session' );
    const actionCreator = getActionDefinition( 'session', 'failure' )();
    const initialState = {
      unsecureToken: 123123,
      secureToken: 123333,
      activeSession: true
    }
    const expectedOutput = {
      unsecureToken: undefined,
      secureToken: undefined,
      activeSession: undefined
    }

    expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set activeSession,secureToken,unsecureToken as undefined when user failure', () => {
    registerServiceName( 'session' );
    const actionCreator = getActionDefinition( 'user', 'failure' )();
    const initialState = {
      unsecureToken: 123123,
      secureToken: 123333,
      activeSession: true
    }
    const expectedOutput = {
      unsecureToken: undefined,
      secureToken: undefined,
      activeSession: undefined
    }

    expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
  } );


  it( 'should set unsecureToken as true if isSecureProtocol is false', () => {
    registerServiceName( 'session' );
    const actionCreator = {
      type: PERSIST_SESSION_DATA,
      token: true,
      isSecureProtocol: false
    }
    expect( reducer( {}, actionCreator ) ).toEqual( { unsecureToken:true } );
  } );

  it( 'should set secureToken as true if isSecureProtocol is true', () => {
    registerServiceName( 'session' );
    const actionCreator = {
      type: PERSIST_SESSION_DATA,
      token: true,
      isSecureProtocol: true
    }
    expect( reducer( {}, actionCreator ) ).toEqual( { secureToken:true } );
  } );

  it( 'should set activeSession,secureToken,unsecureToken as undefined when SESSION_TIMEOUT calls', () => {
    registerServiceName( 'session' );
    const actionCreator = {
      type: SESSION_TIMEOUT
    }
    const expectedOutput = {
      unsecureToken: undefined,
      secureToken: undefined,
      activeSession: undefined
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set activeSession,secureToken,unsecureToken as undefined when logout success is called', () => {
    registerServiceName( 'session' );
    const actionCreator = {
      type: getServiceType( 'logout', 'success' )
    }
    const expectedOutput = {
      unsecureToken: undefined,
      secureToken: undefined,
      activeSession: undefined
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

} );


describe( 'makeGetSessionInfo', () => {

  it( 'should return the activeSession attribute from the Global reducer', () => {
    registerServiceName( 'session' );
    const res = {
      sessionConfirmationNumber: 3030
    };
    const actionCreator = getActionDefinition( 'session', 'success' )( res.sessionConfirmationNumber );
    store.dispatch( actionCreator );
    store.getState().session.secureToken = true;
    const selector = makeGetSessionInfo();
    expect( selector( store.getState() ) ).toEqual( { secureToken:true } );

  } );
} );
