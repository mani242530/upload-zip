


import isEmpty from 'lodash/isEmpty';
import get from 'lodash/get';
import has from 'lodash/has';
import isUndefined from 'lodash/isUndefined';
import { CHANGE as REDUXFORM_CHANGE } from 'redux-form/es/actionTypes';
import {
  CLEAR_LOGIN_ERROR
} from '../../events/forms/forms.events';
import {
  RESET_USER_LOGOUT
} from '../../events/profile/profile.events'
import {
  getServiceType,
  SESSION_TIMEOUT
} from '../../events/services/services.events';
import appConstants from '../../utils/constants/appConstants';


export const initialState = {
  isSignedIn: undefined,
  rewardPointTotal: '500',
  memberId:'',
  memberStatus:'',
  userName: '',
  addressbook: {},
  profileCreditCardList: {},
  isLoginFormSubmitting: false,
  isRewardsMember: undefined,
  isEmailOptIn: undefined,
  userDataLoaded: false,
  userLoggedOut:undefined,
  loginEmail:'',
  showAddressBookSpinner: false,
  showProfileCreditCardsSpinner: false,
  loyaltyMemberId:'',
  GTI:undefined,
  isReauth:false
}

export default function reducer( state = initialState, action ){

  let newState;

  switch ( action.type ){

    case REDUXFORM_CHANGE:
      if( !state.isReauth && action.meta.form === appConstants.FORMS.LOGIN && has( state, 'loginMessages' ) && !isEmpty( state.loginMessages ) &&
      ( ( action.meta.field === 'username' && action.payload !== state.loginEmail ) ||
      ( action.meta.field === 'password' && action.payload.length > 0 ) ) ){
        return {
          ...state,
          loginMessages : []
        };
      }
      else if( action.meta.form === 'UserRewardsLookup' && has( state, 'rewardsLookup.messages' ) && isUserRewardFieldUpdated( state, action.meta.field, action.payload ) ){
        return {
          ...state,
          rewardsLookup:null
        }
      }
      else {
        return {
          ...state
        };
      }

    case getServiceType( 'logout', 'success' ):
    case SESSION_TIMEOUT:
      return {
        ...state,
        isSignedIn: undefined
      }

    case getServiceType( 'profile', 'success' ):
      return {
        ...state,
        isSignedIn: true,
        profileInfo: action.data.profileInfo,
        rewardsInfo: action.data.rewardsInfo
      }

    case getServiceType( 'user', 'success' ):
      let signedIn = false;
      let userName = undefined;
      let isRewardsMember = false;
      let userData = undefined;
      let emailOptIn = false;

      // Updated the below condition based on v2 user lite services
      if( has( action.data, 'user.accountInfo.firstName' ) ){
        signedIn = true;
        userName = action.data.user.accountInfo.firstName;
        isRewardsMember = action.data.user.accountInfo.rewardsMember;
        // In the updated user v2 lite service, the below values added for Email Signup Sticky Footer Form
        // If user is logged in then the values will be updated to the reducer
        emailOptIn = action.data.user.accountInfo.emailOptIn;
        userData = {
          firstName: action.data.user.accountInfo.firstName,
          lastName: action.data.user.accountInfo.lastName,
          email: action.data.user.accountInfo.email,
          dateOfBirth: action.data.user.accountInfo.dateOfBirth,
          userName:action.data.user.accountInfo.userName
        };
      }


      return {
        ...state,
        shoppingCartCount:action.data.cart.itemCount,
        isSoftLoginUser: action.data.user.isSoftLoginUser,
        rewardPointTotal: has( action.data, 'user.rewardsInfo.pointsBalance' ) ? action.data.user.rewardsInfo.pointsBalance : 0, // Updated the condition based on v2 user lite services
        isRewardsMember: isRewardsMember,
        isSignedIn: signedIn,
        isEmailOptIn: emailOptIn,
        ...( ( action.data.messageBeans && action.data.messageBeans.length > 0 ) && { messageBeans: action.data.messageBeans } ),
        memberStatus: has( action.data, 'user.rewardsInfo.status' ) ? action.data.user.rewardsInfo.status : null, // Updated the condition based on v2 user lite services
        userDataLoaded: true,
        userName: userName,
        GTI: get( action, 'data.user.accountInfo.GTI' ),
        profileInfo: {
          ...state.profileInfo,
          ...( !isUndefined( userData ) && { ...userData } )
        },
        previewDate:action.data.meta.previewDate
      }

    case getServiceType( 'addressbook', 'loading' ):
      return {
        ...state,
        addressbook: {},
        showAddressBookSpinner: true
      }
    case getServiceType( 'addressbook', 'success' ):
      return {
        ...state,
        addressbook: action.data,
        showAddressBookSpinner:false
      }
    case getServiceType( 'rewardsLookup', 'requested' ):
      return {
        ...state,
        loyaltyMemberId:action.data.loyaltyMemberId
      }
    case getServiceType( 'userRewards', 'success' ):
      return {
        ...state,
        isRewardsMember: action.data.isRewardsMember
      }

    case getServiceType( 'profileCreditCards', 'success' ):
      const profileCreditCards = action.data.data.profileCreditCards;
      return {
        ...state,
        profileCreditCardList: {
          profileCreditCards: profileCreditCards && formatProfileCreditCardList( profileCreditCards )
        },
        showProfileCreditCardsSpinner: false
      }

    case getServiceType( 'profileCreditCards', 'loading' ):
      return {
        ...state,
        showProfileCreditCardsSpinner: true
      }
    case getServiceType( 'login', 'loading' ):
      return {
        ...state,
        isLoginFormSubmitting: true
      }

    case getServiceType( 'login', 'requested' ):
      return {
        ...state,
        loginEmail:action.data.values.username,
        loginMessages: undefined,
        isReauth:!!action.data.reauth && !action.data.reauthRetry
      }

    case getServiceType( 'profile', 'failure' ):
    case getServiceType( 'user', 'failure' ):
    case getServiceType( 'session', 'failure' ):
    case getServiceType( 'login', 'failure' ):
      return {
        ...state,
        ...( action.data?.status !== 409 && { isLoginFormSubmitting: false } )
      }

    case getServiceType( 'login', 'success' ):
      // check to see if a success response comes from login and if so set values accordingly
      // set signedInFlag. If there are no messages we set isSignedIn to true

      return {
        ...state,
        isLoginFormSubmitting: false,
        isSignedIn: action.data.res.success,
        ...( action.data.res.messages && { loginMessages: action.data.res.messages.items } ),
        ...( !action.data.res.success && {
          profileInfo: {
            ...state.profileInfo,
            userName:undefined
          }
        } )
      }

    case getServiceType( 'createAccount', 'requested' ):
      return {
        ...state,
        messageBeans: undefined
      }

    case getServiceType( 'createAccount', 'success' ):
      let tempIsSignedIn;
      if( isUndefined( action.data.messageBeans ) && !isEmpty( action.data ) ){
        tempIsSignedIn = true;
      }
      else if( action.data.messageBeans.length === 0 ){
        tempIsSignedIn = true;
      }
      return {
        ...state,
        isSignedIn: tempIsSignedIn,
        ...( ( action.data.messageBeans && action.data.messageBeans.length > 0 ) && { messageBeans: action.data.messageBeans } )

      }

    case getServiceType( 'rewardsLookup', 'success' ):
      let success = true;
      if( action.data.success && action.data.success === 'false' ){
        success = false;
      }

      if( !success ){
        return {
          ...state,
          rewardsLookup: { ...action.data, success }
        }
      }
      else {
        return {
          ...state,
          rewardsLookup: { rewardPointEarned:action.data.cartSummary.rewardPointsEarned, success }
        }
      }

    // Data from service to populate the shopping cart count
    case getServiceType( 'initiateCheckout', 'success' ):
    case getServiceType( 'loadCart', 'success' ):
    case getServiceType( 'addGiftNote', 'success' ):
    case getServiceType( 'applyExpressPayPalPayment', 'success' ):
    case getServiceType( 'addGiftWrap', 'success' ):
    case getServiceType( 'addProductSamples', 'success' ):
    case getServiceType( 'updateCartItems', 'success' ):
    case getServiceType( 'removeProductSamples', 'success' ):
    case getServiceType( 'applycoupon', 'success' ):
    case getServiceType( 'removecoupon', 'success' ):
    case getServiceType( 'removeGiftFromCart', 'success' ):
    case getServiceType( 'addItemToCart', 'success' ):
    case getServiceType( 'selectGiftVariant', 'success' ):
    case getServiceType( 'multipleItemsAdd', 'success' ):
      if( has( action.data, 'cartSummary' ) && !isUndefined( action.data.cartSummary.itemCount ) ){
        return {
          ...state,
          shoppingCartCount: parseInt( action.data.cartSummary.itemCount, 10 )
        }
      }
      else {
        return {
          ...state
        }
      }

    case getServiceType( 'removeItemFromCart', 'success' ):
      return {
        ...state,
        shoppingCartCount: parseInt( action.data.type.cartSummary.itemCount, 10 )
      }
    case getServiceType( 'qsAddItem', 'success' ):
      return {
        ...state,
        shoppingCartCount: parseInt( action.data.responseData.cartSummary.itemCount, 10 )
      }
    case getServiceType( 'moveToBagFromSaveForLater', 'success' ):
    case getServiceType( 'moveToSaveForLater', 'success' ):
      return {
        ...state,
        ...( action.data.cart && { shoppingCartCount: action.data.cart.cartSummary.itemCount } )
      }

    case RESET_USER_LOGOUT:
      return {
        ...state,
        isSignedIn:false,
        userLoggedOut: false
      }

    case CLEAR_LOGIN_ERROR:
      return {
        ...state,
        loginMessages : []
      }

    default:
      return state;
  }
}

export const isUserRewardFieldUpdated = ( state, fieldName, value ) =>{
  let changed = false;
  if( has( state, 'loyaltyMemberId' ) &&
    !isEmpty( state.loyaltyMemberId )
  ){
    if( fieldName === 'memberID' ){
      changed = state.loyaltyMemberId !== value;
    }
  }
  return changed;
}

// Modify profileCreditCardList items object by adding expiration date
export const formatProfileCreditCardList = ( profileCreditCardList ) =>{
  profileCreditCardList.items && profileCreditCardList.items.map( profileCreditCard=>{
    let profileCreditCardMod = profileCreditCard;
    const expirationMonth = profileCreditCardMod.expirationMonth.value && profileCreditCardMod.expirationMonth.value ;
    const expirationYear = profileCreditCardMod.expirationYear.value && profileCreditCardMod.expirationYear.value;
    // Add Expiration Date by concatinating expirationMonth and expirationYear
    profileCreditCardMod.expirationDate = expirationMonth && expirationYear ? expirationMonth + '/' + expirationYear : null;
  } );
  return { items :profileCreditCardList.items }
}


export const getUserState = state => state.user;

// GTI for guest user is not yet implemented in the user lite service . so added temporary place holder anonymousUser
export const getGTI = state => state.user.GTI || 'anonymousUser';
