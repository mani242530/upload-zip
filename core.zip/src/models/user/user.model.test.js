import {
  CHANGE as REDUXFORM_CHANGE
} from 'redux-form/es/actionTypes'
import _ from 'lodash';
import reducer, {
  initialState,
  getGTI,
  getUserState
} from './user.model';

import {
  getServiceType,
  registerServiceName,
  SESSION_TIMEOUT
} from '../../events/services/services.events';

import {
  RESET_USER_LOGOUT
} from '../../events/profile/profile.events'

import {
  CLEAR_LOGIN_ERROR
} from '../../events/forms/forms.events';
import appConstants from '../../utils/constants/appConstants';




describe( 'User Reducer', () => {

  registerServiceName( 'addressbook' );
  registerServiceName( 'profileCreditCards' );
  registerServiceName( 'userRewards' );
  registerServiceName( 'profile' );
  registerServiceName( 'createAccount' );
  registerServiceName( 'rewardsLookup' );

  registerServiceName( 'initiateCheckout' );
  registerServiceName( 'loadCart' );
  registerServiceName( 'addGiftNote' );
  registerServiceName( 'applyExpressPayPalPayment' );
  registerServiceName( 'addGiftWrap' );
  registerServiceName( 'addProductSamples' );
  registerServiceName( 'updateCartItems' );
  registerServiceName( 'removeProductSamples' );
  registerServiceName( 'applycoupon' );
  registerServiceName( 'removecoupon' );
  registerServiceName( 'removeGiftFromCart' );
  registerServiceName( 'addItemToCart' );
  registerServiceName( 'selectGiftVariant' );
  registerServiceName( 'removeItemFromCart' );
  registerServiceName( 'multipleItemsAdd' );
  registerServiceName( 'qsAddItem' );
  registerServiceName( 'moveToBagFromSaveForLater' );
  registerServiceName( 'moveToSaveForLater' );
  registerServiceName( 'session' );


  it( 'should have the proper default state', () => {
    let expectedState = {
      isSignedIn: undefined,
      rewardPointTotal: '500',
      memberId:'',
      memberStatus:'',
      loginEmail:'',
      userName: '',
      addressbook: {},
      profileCreditCardList: {},
      isLoginFormSubmitting: false,
      isRewardsMember: undefined,
      userDataLoaded: false,
      userLoggedOut:undefined,
      showAddressBookSpinner: false,
      showProfileCreditCardsSpinner: false,
      loyaltyMemberId:'',
      GTI:undefined,
      isReauth:false
    };

    expect( initialState ).toEqual( expectedState );
  } );

  it( 'should be a function', () => {
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  describe( 'user login request success', () => {
    registerServiceName( 'login' );

    it( 'should set the isSignedIn flag to true on loginSuccess', () => {
      let res = { res :{ success: true, messages:null } };

      let actionCreator = {
        type:getServiceType( 'login', 'success' ),
        data: res
      }

      expect( reducer( initialState, actionCreator ).isSignedIn ).toEqual( true );

    } );


    it( 'should set the isSignedIn flag to false and profile info userName to undefined if Messages object is returned and not null', () => {
      let res = {
        'res':{
          'success':false,
          'messages': {
            'items': [
              {
                'type': 'Error',
                'message': 'The email address/username or password you entered is invalid. Please try again.'
              }
            ]
          }
        }
      }

      let actionCreator = {
        type:getServiceType( 'login', 'success' ),
        data: res
      }


      let expectedOutput = {
        isLoginFormSubmitting: false,
        isSignedIn: false,
        loginMessages: [{ 'type': 'Error', 'message': 'The email address/username or password you entered is invalid. Please try again.' }],
        profileInfo: { 'userName': undefined }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );




    it( 'should clear loginMessages upon change in login formdata and reauth is not true', () => {
      let state = { loginEmail:'test@re.com', loginMessages:['The email address is not valid'] }
      let action = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:appConstants.FORMS.LOGIN,
          field:'username'
        },
        payload: 'test@re.co'
      }
      let expectedOutput = { loginEmail:'test@re.com', loginMessages: [] };
      expect( reducer( state, action ) ).toEqual( expectedOutput );
    } );

    it( 'should not clear loginMessages upon change in login formdata if isReauth is true', () => {
      let state = { isReauth:true, loginEmail:'test@re.com', loginMessages:['The email address is not valid'] }
      let action = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:appConstants.FORMS.LOGIN,
          field:'username'
        },
        payload: 'test@re.co'
      }
      let expectedOutput = { isReauth:true, loginEmail:'test@re.com', loginMessages:['The email address is not valid'] };
      expect( reducer( state, action ) ).toEqual( expectedOutput );
    } );

    it( 'should clear messageBeans upon change in userRewardLook formdata', () => {
      let state = {
        loyaltyMemberId:'1234567891234',
        rewardsLookup:{
          messages: [
            {
              messageKey: 'invalidMember',
              messageType: 'Error',
              messageDesc: 'Please enter a valid member ID'
            }
          ],
          success: false
        }
      }
      let action = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:'UserRewardsLookup',
          field:'memberID'
        },
        payload: '123456789123'
      }
      let expectedOutput = { loyaltyMemberId:'1234567891234', rewardsLookup: null };
      expect( reducer( state, action ) ).toEqual( expectedOutput );
    } );

    it( 'calling the session timeout', () => {
      let actionCreator = {
        type: SESSION_TIMEOUT
      }

      let expected = { isSignedIn: undefined };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );
    it( 'calling the logout success', () => {
      let actionCreator = {
        type: getServiceType( 'logout', 'success' )
      }

      let expected = { isSignedIn: undefined };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'login event for the failure condition', () => {
      let actionCreator = {
        type: getServiceType( 'login', 'failure' )
      }

      let expected = { isLoginFormSubmitting: false };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'login event for the requested event', () => {
      let actionCreator = {
        type: getServiceType( 'login', 'requested' ),
        data : {
          values : {
            username : 'john',
            password : 'ulta@123'
          }
        }
      }

      let expected = { messageBeans: undefined, loginEmail:'john', isReauth:false };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );


    it( 'should set isReauth to true if reauth is true and reauthRetry is false', () => {
      let actionCreator = {
        type: getServiceType( 'login', 'requested' ),
        data : {
          values : {
            username : 'john',
            password : 'ulta@123'
          },
          reauth:true,
          reauthRetry:false
        }
      }

      let expected = { messageBeans: undefined, loginEmail:'john', isReauth:true };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'login event for the loading event', () => {
      let actionCreator = {
        type: getServiceType( 'login', 'loading' )
      }

      let expected = { isLoginFormSubmitting: true };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'create account requested event', () => {
      let actionCreator = {
        type: getServiceType( 'createAccount', 'requested' )
      }

      let expected = { messageBeans: undefined };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } )

    it( 'create account for the success event with messageBeans empty', () => {
      let actionCreator = {
        type: getServiceType( 'createAccount', 'success' ),
        data:{
          messageBeans:''
        }
      }

      let expected = { isSignedIn: true }
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'create account for the success event with messageBeans not empty', () => {
      let res = {
        'profileInfo':{
          'lastName':'APPROVE-MC',
          'address':{
            'country':'US', 'address2':'Apt 505', 'city':'Naperville', 'address1':'819 Pomeroon St', 'postalCode':'60540', 'phoneNumber':'767-898-0101', 'state':'IL'
          },
          'dateOfBirth':'03/17',
          'firstName':'ALWAYS',
          'beautyClubPlanType':{
            'planLevel':'0', 'planDesc':'MEMBER', 'planType':'2', 'item-id':'/atg/userprofiling/ProfileAdapterRepository/beautyClubPlans/1146000003'
          },
          'email':'psugumar@ulta.com'
        },
        'rewardsInfo':{
          'isCardHolder':false, 'creditCardType':null, 'memberSince':null, 'platinum':false, 'memberNumber':null, 'planId':'2'
        }
      }
      let actionCreator = {
        type: getServiceType( 'createAccount', 'success' ),
        data: res
      }

      let expected = { isSignedIn: true }
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Reset User Logout event', () => {
      let actionCreator = {
        type: RESET_USER_LOGOUT
      }

      let expectedOutput = { isSignedIn: false, userLoggedOut: false };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should clear the loginMessages on CLEAR_LOGIN_ERROR event', () => {
      let actionCreator = {
        type: CLEAR_LOGIN_ERROR
      }

      let expectedOutput = { loginMessages: [] };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'user data  request success', () => {

    registerServiceName( 'user' );

    it( 'should set the navContent when the data is loaded and user is logged out', () => {

      let res = {
        data: {
          cart: {
            itemCount: 0
          },
          user: {
            rewardsInfo: {
              pointRedeemValue: 111,
              pointsBalance: 4411,
              pointRedeem: 3330,
              status: null
            },
            accountInfo: { GTI:'Udid12345' },
            isSoftLoginUser:false
          },
          meta:{
            previewDate: '2019-05-24'
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'user', 'success' ),
        data: res.data
      }

      let expectedOutput = {
        ...initialState,
        isSignedIn: false,
        isSoftLoginUser:false,
        isEmailOptIn: false,
        rewardPointTotal: res.data.user.rewardsInfo.pointsBalance,
        isRewardsMember: false,
        shoppingCartCount:0,
        userDataLoaded: true,
        userName: undefined,
        memberStatus: null,
        previewDate: '2019-05-24',
        GTI:'Udid12345',
        profileInfo: {}
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set the navContent when the data is loaded and user is logged in', () => {
      let res = {
        data: {
          cart: {
            itemCount: 0
          },
          user: {
            rewardsInfo: {
              pointRedeemValue: 111,
              pointsBalance: 4411,
              pointRedeem: 3330,
              status: null
            },
            accountInfo: {
              lastName: 'Test Last',
              firstName: 'Test First',
              email: 'testuser@ulta.com',
              rewardsMember: false,
              emailOptIn: true,
              dateOfBirth: '04/30',
              GTI: 'Udid12345',
              userName: 'testusername'
            },
            isSoftLoginUser:false
          },
          meta: {
            previewDate:'2019-05-24'
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'user', 'success' ),
        data: res.data
      }

      let expectedOutput = {
        ...initialState,
        isSignedIn: true,
        isSoftLoginUser:false,
        isEmailOptIn: true,
        rewardPointTotal: res.data.user.rewardsInfo.pointsBalance,
        userName: res.data.user.accountInfo.firstName,
        isRewardsMember: false,
        shoppingCartCount:0,
        userDataLoaded: true,
        memberStatus: null,
        previewDate:'2019-05-24',
        GTI: 'Udid12345',
        profileInfo: {
          dateOfBirth: '04/30',
          email: 'testuser@ulta.com',
          firstName: 'Test First',
          lastName: 'Test Last',
          userName: 'testusername'
        }
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set the isSoftLoginUser as true if service returns the same', () => {
      let res = {
        data: {
          cart: {
            itemCount: 0
          },
          user: {
            rewardsInfo: {
              pointRedeemValue: 111,
              pointsBalance: 4411,
              pointRedeem: 3330,
              status: null
            },
            accountInfo: {
              lastName: 'Test Last',
              firstName: 'Test First',
              email: 'testuser@ulta.com',
              rewardsMember: false,
              emailOptIn: true,
              dateOfBirth: '04/30',
              GTI: 'Udid12345'
            },
            isSoftLoginUser:true
          },
          meta:{
            previewDate:'2019-05-24'
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'user', 'success' ),
        data: res.data
      }

      expect( reducer( initialState, actionCreator ).isSignedIn ).toBe( true );
    } );

  } );

  describe( 'address book Related Test cases', () =>{
    it( 'address book loading event', () => {
      let actionCreator = {
        type: getServiceType( 'addressbook', 'loading' )
      }

      let expectedOutput = {
        addressbook: {},
        showAddressBookSpinner: true
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'address book success event', () => {
      let actionCreator = {
        type: getServiceType( 'addressbook', 'success' ),
        data: {
          'lastName':'Ambula',
          'address':{
            'country':'US', 'address2':'Apt 312', 'city':'Naperville', 'address1':'724 Greenwood Circle', 'postalCode':'60543', 'phoneNumber':'234567890', 'state':'IL'
          },
          'dateOfBirth':'06/23',
          'firstName':'Anup',
          'beautyClubPlanType':{
            'planLevel':'0', 'planDesc':'MEMBER', 'planType':'2', 'item-id':'/atg/userprofiling/ProfileAdapterRepository/beautyClubPlans/1173500001'
          },
          'passwordExpired':false,
          'email':'johncorner47@gmail.com'
        }
      }

      let expectedOutput = {
        addressbook:{
          'lastName':'Ambula',
          'address':{
            'country':'US', 'address2':'Apt 312', 'city':'Naperville', 'address1':'724 Greenwood Circle', 'postalCode':'60543', 'phoneNumber':'234567890', 'state':'IL'
          },
          'dateOfBirth':'06/23',
          'firstName':'Anup',
          'beautyClubPlanType':{
            'planLevel':'0', 'planDesc':'MEMBER', 'planType':'2', 'item-id':'/atg/userprofiling/ProfileAdapterRepository/beautyClubPlans/1173500001'
          },
          'passwordExpired':false,
          'email':'johncorner47@gmail.com'
        },
        showAddressBookSpinner: false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Profile Credit Cards loading case', () => {
      let actionCreator = {
        type: getServiceType( 'profileCreditCards', 'loading' )
      }

      let expectedOutput = {
        showProfileCreditCardsSpinner: true
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Profile Credit Cards success case', () => {
      let actionCreator = {
        type: getServiceType( 'profileCreditCards', 'success' ),
        data: {
          data:{
            profileCreditCards: {
              items:[
                {
                  expirationDate: '09/2025',
                  expirationYear: { value: '2025' },
                  contactInfo: {
                    lastName: 'Ambula',
                    country: 'US',
                    address2: 'Apt 312',
                    city: 'Naperville',
                    address1: '724 Greenwood Cir',
                    postalCode: '60563',
                    firstName: 'Anup',
                    phoneNumber: '123-456-7890',
                    state: 'IL'
                  },
                  nickName: 'Visa - 1111',
                  creditCardType: 'Visa',
                  expirationMonth: { value: '09' },
                  isEditable: true,
                  creditCardNumber: '1111',
                  isPrimary: true
                },
                {
                  expirationDate: '08/2023',
                  expirationYear: { value: '2023' },
                  contactInfo: {
                    lastName: 'Ambula',
                    country: 'US',
                    address2: 'Apt 312',
                    city: 'Naperville',
                    address1: '724 Greenwood Cir',
                    postalCode: '60563',
                    firstName: 'Anup Sharan',
                    phoneNumber: '123-456-7890',
                    state: 'IL'
                  },
                  nickName: 'Mastercard - 4444',
                  creditCardType: 'Mastercard',
                  expirationMonth: { value: '08' },
                  isEditable: true,
                  creditCardNumber: '4444',
                  isPrimary: false
                }
              ]
            }
          }
        }
      }

      let expectedOutput = {
        profileCreditCardList: {
          profileCreditCards: {
            items: [
              {
                expirationDate: '09/2025',
                expirationYear: { value: '2025' },
                contactInfo: {
                  lastName: 'Ambula',
                  country: 'US',
                  address2: 'Apt 312',
                  city: 'Naperville',
                  address1: '724 Greenwood Cir',
                  postalCode: '60563',
                  firstName: 'Anup',
                  phoneNumber: '123-456-7890',
                  state: 'IL'
                },
                nickName: 'Visa - 1111',
                creditCardType: 'Visa',
                expirationMonth: { value:'09' },
                isEditable: true,
                creditCardNumber: '1111',
                isPrimary: true
              },
              {
                expirationDate: '08/2023',
                expirationYear: { value: '2023' },
                contactInfo: {
                  lastName: 'Ambula',
                  country: 'US',
                  address2: 'Apt 312',
                  city: 'Naperville',
                  address1: '724 Greenwood Cir',
                  postalCode: '60563',
                  firstName: 'Anup Sharan',
                  phoneNumber: '123-456-7890',
                  state: 'IL'
                },
                nickName: 'Mastercard - 4444',
                creditCardType: 'Mastercard',
                expirationMonth: { value:'08' },
                isEditable: true,
                creditCardNumber: '4444',
                isPrimary: false
              }
            ]
          }
        },
        showProfileCreditCardsSpinner: false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'User rewards success event', () => {
      let actionCreator = {
        type: getServiceType( 'userRewards', 'success' ),
        data: { isRewardsMember: true }
      }

      let expectedOutput = { isRewardsMember: true }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Profile success case', () => {
      let actionCreator = {
        type: getServiceType( 'profile', 'success' ),
        data:{
          'rewardsInfo':{
            'preScreenRequired':false, 'isCardHolder':false, 'creditCardType':null, 'memberSince':'9/7/2017', 'platinum':false, 'memberNumber':'2919040776678', 'planId':'2', 'preScreenId':null
          },
          'profileInfo':{
            'lastName':'Ambula',
            'address':{
              'country':'US', 'address2':'Apt 312', 'city':'Naperville', 'address1':'724 Greenwood Circle', 'postalCode':'60543', 'phoneNumber':'234567890', 'state':'IL'
            },
            'dateOfBirth':'06/23',
            'firstName':'Anup',
            'beautyClubPlanType':{
              'planLevel':'0', 'planDesc':'MEMBER', 'planType':'2', 'item-id':'/atg/userprofiling/ProfileAdapterRepository/beautyClubPlans/1173500001'
            },
            'passwordExpired':false,
            'email':'johncorner47@gmail.com'
          }
        }
      }

      let expectedOutput = {
        'isSignedIn': true,
        'rewardsInfo':{
          'preScreenRequired':false, 'isCardHolder':false, 'creditCardType':null, 'memberSince':'9/7/2017', 'platinum':false, 'memberNumber':'2919040776678', 'planId':'2', 'preScreenId':null
        },
        'profileInfo':{
          'lastName':'Ambula',
          'address':{
            'country':'US', 'address2':'Apt 312', 'city':'Naperville', 'address1':'724 Greenwood Circle', 'postalCode':'60543', 'phoneNumber':'234567890', 'state':'IL'
          },
          'dateOfBirth':'06/23',
          'firstName':'Anup',
          'beautyClubPlanType':{
            'planLevel':'0', 'planDesc':'MEMBER', 'planType':'2', 'item-id':'/atg/userprofiling/ProfileAdapterRepository/beautyClubPlans/1173500001'
          },
          'passwordExpired':false,
          'email':'johncorner47@gmail.com'
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Rewards Look up event with success ', () => {
      let actionCreator = {
        type: getServiceType( 'rewardsLookup', 'success' ),
        data: {
          success: 'false'
        }
      }

      let expectedOutput = { rewardsLookup: { success: false } };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Data from service to populate the shopping cart count', ()=> {
    it( 'initiateCheckout success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'initiateCheckout', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'initiateCheckout', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'loadCart success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'addGiftNote success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'addGiftNote', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'addGiftNote', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'applyExpressPayPalPayment success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'applyExpressPayPalPayment', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'applyExpressPayPalPayment', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'addGiftWrap success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'addGiftWrap', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'addGiftWrap', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'addProductSamples success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'addProductSamples', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'addProductSamples', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'updateCartItems success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'updateCartItems', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'updateCartItems', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'removeProductSamples success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'removeProductSamples', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'removeProductSamples', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'applycoupon success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'applycoupon', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'applycoupon', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'removecoupon success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'removecoupon', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'removecoupon', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'removeGiftFromCart success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'removeGiftFromCart', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'removeGiftFromCart', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'addItemToCart success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'addItemToCart', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'addItemToCart', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'selectGiftVariant success and failure case', () => {
      let actionCreator = {
        type: getServiceType( 'selectGiftVariant', 'success' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
      actionCreator = {
        type: getServiceType( 'selectGiftVariant', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'qsAddItem success', () => {
      let actionCreator = {
        type: getServiceType( 'qsAddItem', 'success' ),
        data:{
          responseData:{
            cartSummary: {
              shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
            }
          }
        }
      }

      let expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'removeItemFromCart success', () => {
      let actionCreator = {
        type: getServiceType( 'removeItemFromCart', 'success' ),
        data:{
          type:{
            cartSummary: {
              shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
            }
          }
        }
      }

      let expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'multipleItemsAdd success', () => {
      let actionCreator = {
        type: getServiceType( 'multipleItemsAdd', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
          }
        }
      }

      let expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should show the cart if qsAddItem success', () => {
      let actionCreator = {
        type: getServiceType( 'qsAddItem', 'success' ),
        data:{
          responseData:{
            cartSummary: {
              shippingCost: 6.95, subTotal: 26, itemCount: '1', orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
            }
          }
        }
      }

      let expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );


    it( 'should return profileCreditCards as null if there was no profileCreditCards in the received response', () => {

      let actionCreator = {
        type: getServiceType( 'profileCreditCards', 'success' ),
        data:{
          data:{ profileCreditCards:null }
        }
      }

      let expectedOutput = {
        profileCreditCardList : {
          profileCreditCards:null
        },
        showProfileCreditCardsSpinner:false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should update shoppingCartCount on moveToBagFromSaveForLater success if cart is not null', () => {

      const state = {
        shoppingCartCount:0
      }
      let actionCreator = {
        type: getServiceType( 'moveToBagFromSaveForLater', 'success' ),
        data:{
          cart:{
            cartSummary: {
              shippingCost: 6.95, subTotal: 26, itemCount: 1, orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
            }
          }
        }
      }

      let expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should return existing state on moveToBagFromSaveForLater success if cart is null', () => {

      const state = {
        shoppingCartCount:0
      }
      let actionCreator = {
        type: getServiceType( 'moveToBagFromSaveForLater', 'success' ),
        data:{
          cart:null
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( state );
    } );

    it( 'should update shoppingCartCount on moveToSaveForLater success if cart is not null', () => {

      const state = {
        shoppingCartCount:0
      }
      let actionCreator = {
        type: getServiceType( 'moveToSaveForLater', 'success' ),
        data:{
          cart:{
            cartSummary: {
              shippingCost: 6.95, subTotal: 26, itemCount: 1, orderGiftWrapAmt: 0, additionalDiscount: null, couponDiscount: 0, estimatedTax: 0.96, rewardPointsDiscount: null, estimatedTotal: 33.91, rewardPointsEarned: 208, currencyCode: 'USD'
            }
          }
        }
      }

      let expectedOutput = { shoppingCartCount: 1 }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should return existing state on moveToSaveForLater success if cart is null', () => {

      const state = {
        shoppingCartCount:0
      }
      let actionCreator = {
        type: getServiceType( 'moveToSaveForLater', 'success' ),
        data:{
          cart:null
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( state );
    } );

  } );

  describe( 'getGTI', () => {

    it( 'should return GTI attribute from the user reducer', () => {
      const state = {
        user:{
          ...initialState,
          GTI: 'UID12344'
        }
      }
      expect( getGTI( state ) ).toEqual( state.user.GTI );
    } );

  } );
  describe( 'getUserState', () => {

    it( 'should return getUserState attribute from the user reducer', () => {
      const state = {
        user:{
          ...initialState,
          GTI: 'UID12344'
        }
      }
      expect( getUserState( state ) ).toEqual( state.user );
    } );

  } );

  describe( 'cases for service failures during login', () => {

    const currentState = { isLoginFormSubmitting: true };

    it( 'should not set isLoginFormSubmitting to false when login failure is received with 409 status', () => {
      let actionCreator = {
        type: getServiceType( 'login', 'failure' ),
        data:{
          status:409
        }
      }

      let expected = { isLoginFormSubmitting: true };
      expect( reducer( currentState, actionCreator ) ).toEqual( expected );
    } );

    it( 'should set isLoginFormSubmitting to false when login failure is received with status not 409', () => {
      let actionCreator = {
        type: getServiceType( 'login', 'failure' ),
        data:{
          status:500
        }
      }

      let expected = { isLoginFormSubmitting: false };
      expect( reducer( currentState, actionCreator ) ).toEqual( expected );
    } );

    it( 'should not set isLoginFormSubmitting to false when session failure is received with 409 status', () => {
      let actionCreator = {
        type: getServiceType( 'session', 'failure' ),
        data:{
          status:409
        }
      }

      let expected = { isLoginFormSubmitting: true };
      expect( reducer( currentState, actionCreator ) ).toEqual( expected );
    } );

    it( 'should set isLoginFormSubmitting to false when session failure is received with status not 409', () => {
      let actionCreator = {
        type: getServiceType( 'session', 'failure' ),
        data:{
          status:500
        }
      }

      let expected = { isLoginFormSubmitting: false };
      expect( reducer( currentState, actionCreator ) ).toEqual( expected );
    } );

    it( 'should not set isLoginFormSubmitting to false when user failure is received with 409 status', () => {
      let actionCreator = {
        type: getServiceType( 'user', 'failure' ),
        data:{
          status:409
        }
      }

      let expected = { isLoginFormSubmitting: true };
      expect( reducer( currentState, actionCreator ) ).toEqual( expected );
    } );

    it( 'should set isLoginFormSubmitting to false when login user is received with status not 409', () => {
      let actionCreator = {
        type: getServiceType( 'user', 'failure' ),
        data:{
          status:500
        }
      }

      let expected = { isLoginFormSubmitting: false };
      expect( reducer( currentState, actionCreator ) ).toEqual( expected );
    } );

    it( 'should not set isLoginFormSubmitting to false when profile failure is received with 409 status', () => {
      let actionCreator = {
        type: getServiceType( 'profile', 'failure' ),
        data:{
          status:409
        }
      }

      let expected = { isLoginFormSubmitting: true };
      expect( reducer( currentState, actionCreator ) ).toEqual( expected );
    } );

    it( 'should set isLoginFormSubmitting to false when profile failure is received with status not 409', () => {
      let actionCreator = {
        type: getServiceType( 'profile', 'failure' ),
        data:{
          status:500
        }
      }

      let expected = { isLoginFormSubmitting: false };
      expect( reducer( currentState, actionCreator ) ).toEqual( expected );
    } );

  } );

} );
