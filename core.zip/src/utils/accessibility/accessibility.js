
import maintain from 'ally.js/maintain/_maintain';

const initLiveRegion = '<div role=\'status\' id=\'globalAssertiveRegion\' aria-live=\'assertive\' aria-relevant=\'additions\' class=\'sr-only\'></div>'

let inActiveElements;

export const broadcastMessage = ( message ) => {
  if( document.getElementById( 'globalAssertiveRegion' ) === null ){
    document.getElementsByTagName( 'body' )[0].insertAdjacentHTML( 'beforeEnd', initLiveRegion );
  }

  const liveRegion = document.getElementById( 'globalAssertiveRegion' );
  let contentDivs = Array.from( liveRegion.getElementsByClassName( 'contents' ) ).map( function( contentDiv ){
    contentDiv.setAttribute( 'style', 'display:none' );
  } )
  let element = document.createElement( 'div' );
  element.innerHTML = message;
  element.setAttribute( 'style', 'display:block' );
  element.setAttribute( 'class', 'contents' );
  liveRegion.appendChild( element );
}

// the below method will provide a handle to focus on an element, and this is in specific to handle ADA.
// it takes as parameters an element ref and 'delay' a vaue of which can be passed in milliseconds to control the time which needs to be elapsed
// before focus should be triggered. the delay helps to wait until any messages which screen reader has to read, is read out
export const moveScreenReaderFocus = ( elementRef, delay = 0 ) => {
  setTimeout( () => {
    if( elementRef ){
      const x = window.scrollX, y = window.scrollY;
      elementRef.focus( );
      // scroll position is set to same position, where the window position was before the focus was triggered.
      // this will help to avoid the window scroll, for visual users
      window.scrollTo( x, y );
    }
  }, delay );
}

// disableBackgroundElements will inject aria-hidden='true' for all the elements except globalAssertiveRegion and the activeElements which is being passed
export const disableBackgroundElements = ( activeElements ) => {
  let globalAssertiveRegion = document.getElementById( 'globalAssertiveRegion' );
  if( globalAssertiveRegion ){
    activeElements.push( globalAssertiveRegion );
  }
  inActiveElements = maintain.hidden( {
    filter: activeElements
  } );
}

// when this method is called aria-hidden='true' will be removed from those elements
// to which it was applied when disableBackgroundElements was invoked
export const enableBackgroundElements = () => {
  if( inActiveElements ){
    inActiveElements.disengage();
  }
}
