import _ from 'lodash';
import maintain from 'ally.js/maintain/_maintain'
import {
  broadcastMessage, moveScreenReaderFocus, disableBackgroundElements, enableBackgroundElements
} from './accessibility';

describe( 'Accessibility test', () => {
  it( 'check if the function broadcastMessage is defined.', () => {
    expect( _.isFunction( broadcastMessage ) ).toBe( true );
  } );

  it( 'check if the aria-live region is getting created with proper message contents', () => {
    broadcastMessage( 'test message' );
    const divElement = document.createElement( 'div' );
    divElement.innerHTML = '<div role=\'status\' id=\'globalAssertiveRegion\' aria-live=\'assertive\' aria-relevant=\'additions\' class=\'sr-only\'>' +
                              '<div style=\'display:block\' class=\'contents\'>test message</div></div>';
    expect( document.body.innerHTML ).toBe( divElement.innerHTML );
  } );

  it( 'Should focus on element being passed and invoked scrollTo method when moveScreenReaderFocus is invoked', ()=> {
    const scrollToMock = jest.fn();
    window.scrollTo = scrollToMock;
    const bagHeader = {
      focus:jest.fn()
    }
    jest.useFakeTimers();
    moveScreenReaderFocus( bagHeader, 2000 )
    jest.runAllTimers();
    expect( bagHeader.focus ).toBeCalled();
    expect( scrollToMock ).toBeCalled();
  } );

  describe( 'disableBackgroundElements', () => {
    it( 'should call maintain.hidden with expected output', () => {
      maintain.hidden = jest.fn();

      const divElement = document.createElement( 'div' );
      divElement.id = 'SignInModal';
      document.body.appendChild( divElement );

      const divElement1 = document.createElement( 'div' );
      divElement1.id = 'globalAssertiveRegion';
      document.body.appendChild( divElement1 );

      const globalAssertiveRegion = document.getElementById( 'globalAssertiveRegion' );
      disableBackgroundElements( [divElement] );

      const expectedOutput = {
        filter: [divElement, globalAssertiveRegion]
      }
      expect( maintain.hidden ).toHaveBeenCalledWith( expectedOutput );
    } );
  } );

  describe( 'enableBackgroundElements', () => {
    it( 'should call disengage function', () => {
      const disengageMock = jest.fn();
      maintain.hidden = jest.fn( () => {
        return {
          disengage: disengageMock
        }
      } );

      const divElement = document.getElementById( 'SignInModal' );
      disableBackgroundElements( [divElement] );
      enableBackgroundElements();

      expect( disengageMock ).toBeCalled( );
    } );
  } );

} );
