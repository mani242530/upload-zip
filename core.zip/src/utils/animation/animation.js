export const scrollToTop = ( elem, scrollDuration = 800 )=> {
  var cosParameter = elem.scrollTop / 2,
      scrollCount = 0,
      oldTimestamp = performance.now();
  function step( newTimestamp ){
    scrollCount += Math.PI / ( scrollDuration / ( newTimestamp - oldTimestamp ) );
    if( scrollCount >= Math.PI ){
      elem.scrollTop = 0;
    }
    if( elem.scrollTop === 0 ){
      return;
    }
    elem.scrollTop = Math.round( cosParameter + cosParameter * Math.cos( scrollCount ) );
    oldTimestamp = newTimestamp;
    global.requestAnimationFrame( step );
  }
  global.requestAnimationFrame( step );
}

global.requestAnimFrame = ( function(){
  return global.requestAnimationFrame ||
          global.webkitRequestAnimationFrame ||
          global.mozRequestAnimationFrame ||
          function( callback ){
            global.setTimeout( callback, 1000 / 60 );
          };
} )();

export const scrollWindowToPosition = ( scrollTargetY = 0, easing = 'easeOutSine', speed = 1500 ) => {
  // scrollTargetY: the target scrollY property of the window
  // speed: time in pixels per second
  // easing: easing equation to use

  var scrollY = global.scrollY || document.documentElement.scrollTop,
      currentTime = 0;

  // min time .1, max time .8 seconds
  var time = Math.max( .1, Math.min( Math.abs( scrollY - scrollTargetY ) / speed, .8 ) );

  // easing equations from https://github.com/danro/easing-js/blob/master/easing.js
  var easingEquations = {
    easeOutSine: function( pos ){
      return Math.sin( pos * ( Math.PI / 2 ) );
    },
    easeInOutSine: function( pos ){
      return ( -0.5 * ( Math.cos( Math.PI * pos ) - 1 ) );
    },
    easeInOutQuint: function( pos ){
      let q = pos / 0.5;
      if( q < 1 ){
        return 0.5 * Math.pow( q, 5 );
      }
      return 0.5 * ( Math.pow( ( q - 2 ), 5 ) + 2 );
    }
  };

  // add animation loop
  function tick(){
    currentTime += 1 / 60;

    var p = currentTime / time;
    var t = easingEquations[easing]( p );

    if( p < 1 ){
      requestAnimationFrame( tick );

      global.scrollTo( 0, scrollY + ( ( scrollTargetY - scrollY ) * t ) );
    }
    else {
      global.scrollTo( 0, scrollTargetY );
    }
  }

  // call it once to get started
  tick();
}
