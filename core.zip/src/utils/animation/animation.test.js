import _ from 'lodash';
import { scrollToTop, scrollWindowToPosition } from './Animation';

describe( 'Animation test', () => {
  it( 'check if the functions scrollToTop and scrollWindowToPosition is defined.', () => {
    expect( _.isFunction( scrollToTop ) ).toBe( true );
    expect( _.isFunction( scrollWindowToPosition ) ).toBe( true );
  } );

  it( 'should invoke requestAnimationFrame when scrollToTop is called', () => {
    const requestAnimationFrameMock = jest.fn();
    window.performance = {
      now: jest.fn( () => 100000 )
    }
    window.requestAnimationFrame = requestAnimationFrameMock;
    requestAnimFrame();
    scrollToTop( { scrollTop:100 } );
    expect( requestAnimationFrameMock ).toBeCalled();
  } );

  it( 'should invoke scrollTo method when scrollWindowToPosition is called', () => {
    const scrollToMock = jest.fn();
    window.scrollTo = scrollToMock;
    scrollWindowToPosition();
    expect( scrollToMock ).toBeCalled();
  } );
} );