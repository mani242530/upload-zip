

export const appConstants = {

  FORMS:{
    LOGIN:'LogIn'
  },
  ROUTES:{
    ACCOUNT_PAGE:'/ulta/myaccount'
  }
}

export default appConstants;