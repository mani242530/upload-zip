

export const isServer = function( wndObj = {} ){

  if( typeof window === 'undefined' ){
    return true;
  }
  else {
    return wndObj === window
  }
}

export const checkIfIPhoneSafari = function( device, nav ){
  let uAgent = nav.userAgent;
  if( uAgent.indexOf( device ) !== -1 && uAgent.indexOf( 'Mac OS' ) !== -1 && uAgent.indexOf( 'Safari' ) !== -1 && uAgent.indexOf( 'CriOS' ) === -1 ){
    return true;
  }
  else {
    return false;
  }
}
export const checkDevice = function( device ){
  let uAgent = navigator.userAgent;
  return ( uAgent.indexOf( device ) !== -1 );
}
export var checkIfAndroidChrome = function(){
  let uAgent = navigator.userAgent;
  return ( uAgent.indexOf( 'Android' ) !== -1 && uAgent.indexOf( 'Chrome' ) !== -1 && !( uAgent.indexOf( 'SamsungBrowser' ) !== -1 ) );
}
