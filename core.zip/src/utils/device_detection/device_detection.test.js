
import _ from 'lodash';
import {
  checkIfIPhoneSafari,
  checkDevice,
  checkIfAndroidChrome,
  isServer
} from './device_detection';

describe( 'isServer', () => {
  it( 'should return false if window is defined', () => {
    expect( isServer( window ) ).toBeTruthy();
  } );

  it( 'should return true if window is undefined', () => {
    const wdw = {};
    expect( isServer( wdw ) ).not.toBeTruthy();
  } );

} );

describe( 'checkIfIPhoneSafari', () => {

  it( 'The function "checkIfIPhoneSafari" should be defined.', () => {

    expect( _.isFunction( checkIfIPhoneSafari ) ).toBe( true );
  } );

  it( 'should return true when device is "iPhone"', () => {

    let nav = { userAgent:'Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1' };
    expect( checkIfIPhoneSafari( 'iPhone', nav ) ).toBe( true );
  } );

  it( 'should return false when device is not "iPhone"', () => {

    let nav = { userAgent:'Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 windows/601.1' };
    expect( checkIfIPhoneSafari( 'iPhone', nav ) ).toBe( false );
  } );
} );

describe( 'checkDevice', () => {
  it( 'The function checkDevice should be defined', () => {
    expect( _.isFunction( checkDevice ) ).toBe( true );
  } );

  it( 'Checking whether the device is iPhone', () => {
    navigator.__defineGetter__( 'userAgent', function(){
      return 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1';
    } );

    expect( checkDevice( 'iPhone' ) ).toBe( true );
  } );
} );

describe( 'checkIfAndroidChrome', () => {
  it( 'The function checkIfAndroidChrome should be defined', () => {
    expect( _.isFunction( checkIfAndroidChrome ) ).toBe( true );
  } );

  it( 'Checking whether the device is  AndroidChrome', () => {
    navigator.__defineGetter__( 'userAgent', function(){
      return 'Mozilla/5.0 (Linux; Android 4.1.1; Galaxy Nexus Build/JRO03C) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19';
    } );

    expect( checkIfAndroidChrome() ).toBe( true );
  } );
} );
