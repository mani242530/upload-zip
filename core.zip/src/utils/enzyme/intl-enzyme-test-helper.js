/**
  * Components using the react-intl module require access to the intl context.
  * This is not available when mounting single components in Enzyme.
  * These helper functions aim to address that and wrap a valid,
  * English-locale intl context around them.
  */
import 'raf/polyfill';
import React from 'react';
import renderer from 'react-test-renderer';
import { IntlProvider, intlShape } from 'react-intl';
import Enzyme, { shallow, render, mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import createReducer from '../../models';
import Global from '../../views/Global/Global';
const intlProvider = new IntlProvider( { locale: 'en' }, {} );
const { intl } = intlProvider.getChildContext();

// Make Enzyme functions available in all test files without importing
global.shallow = shallow;
global.render = render;
global.mount = mount;

// React 16 Enzyme adapter
// configure( { adapter: new Adapter() } );
Enzyme.configure( { adapter: new Adapter() } );

/**
 * Wehn using React-Intl  `injectIntl` on componets, props.intl is required
 */
const getNode = ( node ) => {
  return React.cloneElement( node, { intl } );
}

export const shallowWithIntl = ( node ) => {
  return shallow(
    getNode( node ),
    {
      context: { intl }
    }
  );
}

export const mountWithIntlGlobal = ( node ) => {
  // console.log( node );
  return mount(
    getNode( node ),
    {
      context: { intl },
      childContextTypes:  { intl: intlShape }
    }
  );
}

export const configureStore = ( initialState = {} ) => {

  return createStore(
    createReducer(),
    initialState
  );
}

export const mountWithIntl = ( node ) => {
  let store = configureStore();
  mountWithIntlGlobal(
    <Provider store={ store }>
      <Global />
    </Provider>
  );
  return mount(
    node
  );
}


export const createComponentWithIntl = ( children, props = { locale: 'en' } ) => {
  return renderer.create(
    <IntlProvider { ...props }>
      { children }
    </IntlProvider>
  );
}
