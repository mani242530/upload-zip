import isUndefined from 'lodash/isUndefined';
import isArray from 'lodash/isArray';
import messages from './form_validations.messages';

import {
  removeSpecialCharacters
} from '../formatters/formatters';
import { formatMessage } from '../../views/Global/Global.js';

export const validationKeys = {
  required: 'required',
  showWarningMessage: 'showWarningMessage',
  passwordLength: 'passwordLength',
  passwordCase: 'passwordCase',
  passwordNumberExist: 'passwordNumberExist',
  passwordSplCharExist: 'passwordSplCharExist',
  passwordWithoutInvalidSymbol: 'passwordWithoutInvalidSymbol',
  memberIdLength: 'memberIdLength',
  shouldMatch: 'shouldMatch',
  validateCreditCardExpiry: 'validateCreditCardExpiry',
  validateSSN: 'validateSSN',
  validateSSNlastFour: 'validateSSNlastFour',
  validateZipCode: 'validateZipCode',
  validateAnnualIncome: 'validateAnnualIncome',
  validateDOB: 'validateDOB',
  validatePhone: 'validatePhone',
  validateEmail: 'validateEmail',
  validateCreditCard: 'validateCreditCard',
  validateSecurityCode: 'validateSecurityCode',
  validateGiftCard: 'validateGiftCard',
  validateCardPin: 'validateCardPin',
  requiredGiftCard: 'requiredGiftCard',
  requiredCardPin: 'requiredCardPin',
  firstValidateName: 'firstValidateName',
  lastValidateName: 'lastValidateName',
  adsPrescreenIdRequired: 'adsPrescreenIdRequired',
  validateADSprescreenID: 'validateADSprescreenID',
  validateLocationSearch: 'validateLocationSearch'
};

export const memberIdLengthValidation = ( val ) => {
  let message = formatMessage( messages.memberIdLength, { val } );
  return val && ( val.length === 13 ) ? undefined : message
};

export const checkoutPageMemberIdLengthValidation = ( val ) => {
  let message;
  if( !isUndefined( val ) ){
    message = formatMessage( messages.memberIdLength, { val } );
  }
  return val && ( val.length === 13 ) ? undefined : message
};

export const requiredValidation = ( val ) => {
  let message = formatMessage( messages.required );
  return val && val.length > 0 ? undefined : message
};

export const validateSecurityCode = ( ccNumber ) => val =>{
  var re;
  if( ccNumber === 'AmericanExpress' ){
    re = /([0-9]{4})$/;
  }
  else if( ccNumber.match( /^3[47]/ ) ){
    re = /([0-9]{4})$/;
  }
  else {
    re = /([0-9]{3})$/;
  }
  return re.test( val ) ? undefined : formatMessage( messages.validateSecurityCode );
};

export const validate = ( val, key, msg ) => {
  let itrKey = [], itrMsg = [];

  if( !isArray( key ) ){
    itrKey.push( key );
    itrMsg.push( msg );
  }
  else {
    itrKey = key;
    itrMsg = msg;
  }
  for ( var i = 0; i <= itrKey.length; i++ ){
    var returnValue;
    switch ( itrKey[i] ){
      case ( validationKeys.required ):
        returnValue = val && val.length > 0 ? undefined : itrMsg[i]
        break;

      case ( validationKeys.showWarningMessage ):
        // condition is set to show the message as long as there is a value in the field
        returnValue = val ? itrMsg[i] : undefined;
        break;

      case ( validationKeys.passwordLength ):
        returnValue = val && ( val.length >= 8 ) ? undefined : itrMsg[i]
        break;

      case ( validationKeys.validateADSprescreenID ):
        var re = /^(3|8)/;
        returnValue = re.test( val ) && ( val.length === 12 ) ? undefined : itrMsg[i];
        break;

      case ( validationKeys.validateEmail ):
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        returnValue = re.test( val ) ? undefined : itrMsg[i];
        break;

      case ( validationKeys.shouldMatch ):
        returnValue = ( val[0] && val[1] ) && val[0] === val[1] ? undefined : ( !val[1] ) ? undefined : itrMsg[i];
        break;

      case ( validationKeys.validateSSNlastFour ):
        var re = /(\d{4})$/;
        returnValue = re.test( val ) ? undefined : itrMsg[i];
        break;

      case ( validationKeys.validateSSN ):
        var re = /(\d{3}-\d{2}|\*{3}-\*{2})-\d{4}$/;
        returnValue = re.test( val ) ? undefined : itrMsg[i];
        break;

      case ( validationKeys.validatePhone ):
        returnValue = removeSpecialCharacters( val ).length === 10 ? undefined : itrMsg[i];
        break;

      case ( validationKeys.validateDOB ):
        var re = /^(?:(0[1-9]|1[012])[\/.](0[1-9]|[12][0-9]|3[01])[\/.](19|20)[0-9]{2})$/;
        returnValue = re.test( val ) ? undefined : itrMsg[i];
        break;

      case ( validationKeys.validateZipCode ):
        var re = /(\d{5})$/;
        returnValue = re.test( val ) ? undefined : itrMsg[i];
        break;

      case ( validationKeys.validateAnnualIncome ):
        returnValue = val === '$.00' ? itrMsg[i] : undefined;
        break;

      case ( validationKeys.firstValidateName ):
        var re = /^[A-z0-9‘ ?.,/@&()-]+$/;
        returnValue = re.test( val ) ? undefined : itrMsg[i];
        break;

      case ( validationKeys.lastValidateName ):
        var re = /^[A-z0-9‘ ?.,/@&()-]+$/;
        returnValue = re.test( val ) ? undefined : itrMsg[i];
        break;

      case ( validationKeys.requiredGiftCard ):
        returnValue = val && val.length > 0 ? undefined : itrMsg[i];
        break;

      case ( validationKeys.requiredCardPin ):
        returnValue = val && val.length > 0 ? undefined : itrMsg[i];
        break;

      case ( validationKeys.validateGiftCard ):
        var re = /([0-9]{4}\s[0-9]{4}\s[0-9]{4}\s[0-9]{4}\s*)$/;
        returnValue = re.test( val ) ? undefined : itrMsg[i];
        break;

      case ( validationKeys.validateCardPin ):
        var re = /([0-9]{8})$/;
        returnValue = re.test( val ) ? undefined : itrMsg[i];
        break;
      case ( validationKeys.validateCreditCardExpiry ):
        returnValue = validateCreditCardExpiry( val );
        break;
      case ( validationKeys.validateCreditCard ):
        returnValue = validateCreditCard( val );
        break;
      case ( validationKeys.validateLocationSearch ):
        returnValue = validateLocationSearch( val );
        break;
    }
    if( returnValue !== undefined ){
      return ( formatMessage( returnValue ) );
    }
  }
  if( returnValue !== undefined ){
    return ( formatMessage( returnValue ) );
  }
};


export const validateCreditCardExpiry = val =>{
  var re = /^(?:(0[1-9]|1[012])[\/.][1-9]{1}[0-9]{3})$/;
  let currentYear = parseInt( new Date().getFullYear().toString(), 10 );
  let currentMonth = parseInt( new Date().getMonth().toString(), 10 );
  let givenYear = parseInt( val.toString().substr( -4 ), 10 );
  let givenMonth = parseInt( val.toString().substring(), 10 );
  if( val.length < 7 ){
    return messages.validateCCExpiryOnLessDigit ;
  }
  let testdate = ( givenYear !== currentYear ) ? givenYear > currentYear : ( currentMonth < givenMonth );
  return ( re.test( val ) && testdate ) ? undefined : messages.validateCreditCardExpiry ;
};

export const validateCreditCard = val => {
  var re ;
  if( val.match( /^3[47]/ ) ){
    re = /([0-9]{4}\s[0-9]{6}\s[0-9]{5}\s*)$/;
  }
  else {
    re = /([0-9]{4}\s[0-9]{4}\s[0-9]{4}\s[0-9]{4}\s*)$/;
  }
  return re.test( val ) ? undefined : messages.validateCreditCard ;
};

export const validateLocationSearch = val => {
  let re ;
  if( isNaN( val ) ){ //eslint-disable-line 
    // Allow strings with length of at least 2 for state or city
    re = /^[A-Za-z0-9, ]{2,}$/
  }
  else {
    // Allow numeric string of exactly 5 characters for zip
    re = /^[0-9]{5}$/
  }

  // Allow undefined as valid string ( To support geo locate option )
  let trimmed = val && val.trim();
  return ( !trimmed || re.test( trimmed ) ) ? undefined : messages.validateLocationSearch ;
};

// Function will validate password for all the below given rules or each rules based on the input key(s):
// - Upper- and lowercase letters (e.g. Aa)
// - At least one number (e.g. 1234)
// - At least one special character (e.g. !@#$)
// - Cannot contain spaces or <> {} []
// - A minimum length of 8 characters
export const validatePassword = ( val, key ) => {
  let itrKey = [], returnValue = false;
  if( !isArray( key ) ){
    itrKey.push( key );
  }
  else {
    itrKey = key;
  }
  for ( var i = 0; i <= itrKey.length; i++ ){
    switch ( itrKey[i] ){
      case ( validationKeys.passwordCase ):
        // Regex to have atleast one capital and one small letter
        returnValue = val && /(?=.*[a-z])(?=.*[A-Z])/.test( val )
        break;

      case ( validationKeys.passwordNumberExist ):
        // Checking atleast one numeric exist in the value
        returnValue = val && /\d/.test( val )
        break;

      case ( validationKeys.passwordSplCharExist ):
        // Regex to have one special character in the specified list
        returnValue = val && /(?=.*[!"#$%&'()*+,-./:;=?@\^_`|~])/.test( val )
        break;

      case ( validationKeys.passwordWithoutInvalidSymbol ):
        // Regex to not have a special character which is in the exclude list
        returnValue = !( /(?=.*[\s<>{}\[\]])/.test( val ) )
        break;

      case ( validationKeys.passwordLength ):
        // Checking the length of value is greater that 8
        returnValue = val && val.length >= 8
        break;
    }
    if( !returnValue ){
      return returnValue;
    }
  }
  return returnValue;
}
