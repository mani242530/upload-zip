
/*
 * FormValidations Messages
 *
 * This contains all the text for the MobileBodi component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  required: {
    id: 'i18n.FormValidations.required',
    defaultMessage: 'Required'
  },
  requiredEmail: {
    id: 'i18n.FormValidations.requiredEmail',
    defaultMessage: 'Please enter email address'
  },
  invalidDate: {
    id: 'i18n.FormValidations.invalidDate',
    defaultMessage: 'Please enter a valid date'
  },
  invalidDOB: {
    id: 'i18n.FormValidations.invalidDOB',
    defaultMessage: 'Please enter a valid DOB'
  },
  invalidSSN:{
    id: 'i18n.FormValidations.invalidSSN',
    defaultMessage: 'Please enter a valid SSN'
  },
  invalidSSNlastFour:{
    id: 'i18n.FormValidations.invalidSSNlastFour',
    defaultMessage: 'Please enter the last 4 digits of your social security number.'
  },
  invalidAnnualIncome:{
    id: 'i18n.FormValidations.invalidAnnualIncome',
    defaultMessage: 'Income amount shoud be greater than $1.00'
  },
  invalidPhoneNumber:{
    id: 'i18n.FormValidations.invalidPhoneNUmber',
    defaultMessage: 'Please enter a valid phone number'
  },
  invalidZipCode: {
    id: 'i18n.FormValidations.invalidZipCode',
    defaultMessage: 'Please enter a valid zip code'
  },
  invalidEmail: {
    id: 'i18n.FormValidations.invalidPassword',
    defaultMessage: 'Please enter a valid email address'
  },
  passwordsMatch: {
    id: 'i18n.FormValidations.passwordsMatch',
    defaultMessage: 'Passwords match'
  },
  passwordsDoNotMatch: {
    id: 'i18n.FormValidations.passwordsDoNotMatch',
    defaultMessage: 'Passwords do not match'
  },
  passwordLength: {
    id: 'i18n.FormValidations.passwordLength',
    defaultMessage: 'Password should be minimum of 8 characters'
  },
  memberIdLength: {
    id: 'i18n.FormValidations.memberIdLength',
    defaultMessage: 'The Ultamate Rewards Member ID - {val} is not valid. Please ensure that you have entered the correct 13 digit number. If you require further assistance please contact Guest services at 866-983-ULTA(8582).'
  },

  invalidCoupon: {
    id: 'i18n.FormValidations.invalidCoupon',
    defaultMessage: 'Please enter a coupon'
  },


  validateGiftCard: {
    id: 'i18n.FormValidations.validateGiftCard',
    defaultMessage: 'Please enter a valid Gift Card Number'
  },
  validateCardPin: {
    id: 'i18n.FormValidations.validateCardPin',
    defaultMessage: 'Please enter a valid PIN Number'
  },

  validateCreditCard: {
    id: 'i18n.FormValidations.validateCard',
    defaultMessage: 'Please enter valid Credit Card number'
  },
  validateCreditCardExpiry:{
    id: 'i18n.FormValidations.validateCreditCardExpiry',
    defaultMessage: 'Please enter valid Credit Card Expiry in MM/YYYY format'
  },
  validateCCExpiryOnLessDigit:{
    id: 'i18n.FormValidations.validateCCExpiryOnLessDigit',
    defaultMessage: ' Please enter 4 digit year, MM/YYYY'
  },

  validateSecurityCode:{
    id: 'i18n.FormValidations.validateSecurityCode',
    defaultMessage: 'Please enter correct CVV code'
  },

  requiredGiftCard: {
    id: 'i18n.FormValidations.requiredGiftCard',
    defaultMessage: 'Please enter Gift Card number'
  },
  requiredCardPin: {
    id: 'i18n.FormValidations.requiredCardPin',
    defaultMessage: 'Please enter PIN Number'
  },

  requiredCreditCard: {
    id: 'i18n.FormValidations.requiredCard',
    defaultMessage: 'Please enter Credit Card number'
  },

  validateFirstName: {
    id: 'i18n.FormValidations.validateFirstName',
    defaultMessage: 'Please enter valid first name'
  },

  validateLastName: {
    id: 'i18n.FormValidations.validateFirstName',
    defaultMessage: 'Please enter valid last name'
  },

  invalidADSprescreenID: {
    id: 'i18n.FormValidations.invalidADSprescreenID',
    defaultMessage: 'Please enter a valid Prescreen ID Number.'
  },

  prescreenIdHelpTxt: {
    id: 'i18n.CreditcardPrescreenEntryForm.prescreenIdHelpTxt',
    defaultMessage: 'Please enter your 12-digit Prescreen ID Number.'
  },

  requiredSearchText: {
    id: 'i18n.FormValidations.requiredSearchText',
    defaultMessage: 'Oops!  Please enter a search location'
  },
  validateLocationSearch: {
    id: 'i18n.ChangeStoreModal.validateLocationSearch',
    defaultMessage: 'Please enter valid City, State or ZIP.'
  }

} );