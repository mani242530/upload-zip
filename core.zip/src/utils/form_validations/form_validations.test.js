import React from 'react';
import isUndefined from 'lodash/isUndefined';
import { Provider } from 'react-redux';

let store = configureStore( );

import { mountWithIntlGlobal, configureStore } from '../enzyme/intl-enzyme-test-helper';
import Global from '../../views/Global/Global';
import {
  validateSecurityCode,
  memberIdLengthValidation,
  checkoutPageMemberIdLengthValidation,
  requiredValidation,
  validate,
  validateCreditCardExpiry,
  validateCreditCard,
  validationKeys,
  validatePassword
} from './form_validations';

import messages from './form_validations.messages';


let wrapper = mountWithIntlGlobal(
  <Provider store={ store }>
    <Global />
  </Provider>
);

let formatMessage =  wrapper.props().intl.formatMessage;


describe( 'Form validation utility methods', () => {

  it( 'should return undefined if there is a message with a length greater than 0', () => {

    expect( isUndefined( requiredValidation( 'this is a test' ) ) ).toBeTruthy();
  } );

  it( 'should return the required error message if there is no value defined', () => {
    expect( requiredValidation( '' ) ).toBe( formatMessage( messages.required ) );
  } );

  it( 'should return the required error message if the password length is less than 8', () => {
    const val = 'test';
    expect( validate( val, validationKeys.passwordLength, messages.passwordLength ) ).toBe( formatMessage( messages.passwordLength ) );
  } );

  it( 'should return the required error message if the memberId length is not equal to 13', () => {
    const val = '1234';
    expect( memberIdLengthValidation( val ) ).toBe( formatMessage( messages.memberIdLength, { val } ) );
  } );

  it( 'should return undefined if the memberId is undefined', () => {
    const val = undefined;
    expect( checkoutPageMemberIdLengthValidation( val ) ).toBe( undefined );
  } );

  it( 'should return proper error message if the memberId is not undefined', () => {
    const val = '1234';
    expect( checkoutPageMemberIdLengthValidation( val ) ).toBe( formatMessage( messages.memberIdLength, { val } ) );
  } );

  it( 'should return proper error message if the passwords do not match', () => {
    const val1 = '1234';
    const val2 = '12345';
    expect( validate( [val1, val2], validationKeys.shouldMatch, messages.passwordsDoNotMatch ) ).toBe( formatMessage( messages.passwordsDoNotMatch ) );
  } );

  it( 'should return proper error message if no credit card expiry is given', () => {
    const val = ' ';
    expect( validateCreditCardExpiry( val ) ).toBe( messages.validateCCExpiryOnLessDigit );
  } );

  it( 'should return proper error message for invalid credit card expiry', () => {
    const val = '2020/01';
    expect( validateCreditCardExpiry( val ) ).toBe( messages.validateCreditCardExpiry );
  } );

  it( 'should return proper error message for invalid SSN', () => {
    const val = '333';
    expect( validate( val, validationKeys.validateSSN, messages.invalidSSN ) ).toBe( formatMessage( messages.invalidSSN ) );
  } );

  it( 'should return proper error message for invalid last four digits of SSN', () => {
    const val = '333';
    expect( validate( val, validationKeys.validateSSNlastFour, messages.invalidSSNlastFour ) ).toBe( formatMessage( messages.invalidSSNlastFour ) );
  } );

  it( 'should return proper error message for invalid zipcode', () => {
    const val = '333';
    expect( validate( val, validationKeys.validateZipCode, messages.invalidZipCode ) ).toBe( formatMessage( messages.invalidZipCode ) );
  } );

  it( 'should return proper error message for invalid annual income', () => {
    const val = '$.00';
    expect( validate( val, validationKeys.validateAnnualIncome, messages.invalidAnnualIncome ) ).toBe( formatMessage( messages.invalidAnnualIncome ) );
  } );

  it( 'should return proper error message for invalid date of birth', () => {
    const val = '01/';
    expect( validate( val, validationKeys.validateDOB, messages.invalidDOB ) ).toBe( formatMessage( messages.invalidDOB ) );
  } );

  it( 'should return proper error message for invalid phone number', () => {
    const val = '210-321-23';
    expect( validate( val, validationKeys.validatePhone, messages.invalidPhoneNumber ) ).toBe( formatMessage( messages.invalidPhoneNumber ) );
  } );

  it( 'should return proper error message for invalid email', () => {
    const val = 'test@test';
    expect( validate( val, validationKeys.validateEmail, messages.invalidEmail ) ).toBe( formatMessage( messages.invalidEmail ) );
  } );

  it( 'should return proper error message for invalid credit card number starting with 347', () => {
    const val = '347584698';
    expect( validateCreditCard( val ) ).toBe( messages.validateCreditCard );
  } );

  it( 'should return proper error message for invalid credit card number starting', () => {
    const val = '254584698';
    expect( validateCreditCard( val ) ).toBe( messages.validateCreditCard );
  } );

  it( 'should return proper error message for invalid security code having cc number as AmericanExpress', () => {
    const ccNumber = 'AmericanExpress';
    const val = '123';
    expect( validateSecurityCode( ccNumber )( val ) ).toBe( formatMessage( messages.validateSecurityCode ) );
  } );

  it( 'should return proper error message for invalid security code for cc number starting with 347', () => {
    const ccNumber = '347';
    const val = '123';
    expect( validateSecurityCode( ccNumber )( val ) ).toBe( formatMessage( messages.validateSecurityCode ) );
  } );

  it( 'should return proper error message for invalid security code for cc number', () => {
    const ccNumber = '447';
    const val = '123';
    expect( validateSecurityCode( ccNumber )( val ) ).toBe( undefined );
  } );

  it( 'should return proper error message for invalid gift card', () => {
    const val = '123456789';
    expect( validate( val, validationKeys.validateGiftCard, messages.validateGiftCard ) ).toBe( formatMessage( messages.validateGiftCard ) );
  } );

  it( 'should return proper error message for invalid credit card pin', () => {
    const val = '12345';
    expect( validate( val, validationKeys.validateCardPin, messages.validateCardPin ) ).toBe( formatMessage( messages.validateCardPin ) );
  } );

  it( 'should return proper error message if gift card number is not given', () => {
    const val = '';
    expect( validate( val, validationKeys.requiredGiftCard, messages.requiredGiftCard ) ).toBe( formatMessage( messages.requiredGiftCard ) );
  } );

  it( 'should return proper error message if credit card pin is not given', () => {
    const val = '';
    expect( validate( val, validationKeys.requiredCardPin, messages.requiredCardPin ) ).toBe( formatMessage( messages.requiredCardPin ) );
  } );

  it( 'should return proper error message for invalid first name', () => {
    const val = 'Test123#';
    expect( validate( val, validationKeys.firstValidateName, messages.validateFirstName ) ).toBe( formatMessage( messages.validateFirstName ) );
  } );

  it( 'should return proper error message for invalid last name', () => {
    const val = 'Test123#';
    expect( validate( val, validationKeys.lastValidateName, messages.validateLastName ) ).toBe( formatMessage( messages.validateLastName ) );
  } );

  it( 'should  not return error message for first name having numeric value', () => {
    const val = 'Test1234';
    expect( validate( val, validationKeys.firstValidateName, messages.validateFirstName ) ).toBe( undefined );
  } );

  it( 'should  not return error message for first name having numeric value', () => {
    const val = 'Test1234';
    expect( validate( val, validationKeys.lastValidateName, messages.validateLastName ) ).toBe( undefined );
  } );

  it( 'should return proper error message if adsPrescreenId length is greater than 0', () => {
    const message = formatMessage( messages.required );
    const val = '';
    expect( requiredValidation( val ) ).toBe( message );
  } );

  it( 'should return proper error message for invalid adsPrescreenId ', () => {
    const val = '12345';
    expect( validate( val, validationKeys.validateADSprescreenID, messages.invalidADSprescreenID ) ).toBe( formatMessage( messages.invalidADSprescreenID ) );
  } );

  it( 'should return proper warning message', () => {
    const message = formatMessage( messages.required );
    const val = 'test';
    expect( validate( val, validationKeys.showWarningMessage, messages.required ) ).toBe( message );
  } );

  it( 'should call validateCreditCardExpiry method and display proper error message if val is invalid', () => {
    const message = formatMessage( messages.validateCCExpiryOnLessDigit );
    const val = '21/21';
    expect( validate( val, validationKeys.validateCreditCardExpiry ) ).toBe( message );
  } );

  it( 'should call validateCreditCard method and display proper error message if val is invalid', () => {
    const message = formatMessage( messages.validateCreditCard );
    const val = '254584698';
    expect( validate( val, validationKeys.validateCreditCard ) ).toBe( message );
  } );
  it( 'should return proper error message if store location search text is blank', () => {
    const val = '';
    expect( validate( val, validationKeys.required, messages.requiredSearchText ) ).toBe( formatMessage( messages.requiredSearchText ) );
  } );

  it( 'should call validateLocationSearch method and display proper error message if val is invalid city/state', () => {
    const message = formatMessage( messages.validateLocationSearch );
    const val = 'a';
    expect( validate( val, validationKeys.validateLocationSearch, messages.validateLocationSearch ) ).toBe( message );
  } );

  it( 'should call validateLocationSearch method and display proper error message if val is invalid zip code', () => {
    const message = formatMessage( messages.validateLocationSearch );
    const val = '111';
    expect( validate( val, validationKeys.validateLocationSearch, messages.validateLocationSearch ) ).toBe( message );
  } );

  it( 'should call validateLocationSearch method and return undefined for valid city/state', () => {
    const val = 'IL';
    expect( validate( val, validationKeys.validateLocationSearch, messages.validateLocationSearch ) ).toBe( undefined );
  } );

  it( 'should call validateLocationSearch method and return undefined for valid city & state', () => {
    const val = 'New york, NY';
    expect( validate( val, validationKeys.validateLocationSearch, messages.validateLocationSearch ) ).toBe( undefined );
  } );

  it( 'should call validateLocationSearch method and return undefined for valid zip code', () => {
    const val = '60440';
    expect( validate( val, validationKeys.validateLocationSearch, messages.validateLocationSearch ) ).toBe( undefined );
  } );

  it( 'should call validatePassword method for checking password case(upper and lower) and return proper flag based on value', () => {
    // Validation Success
    let val = 'Ulta';
    expect( validatePassword( val, validationKeys.passwordCase ) ).toBe( true );
    // Validation Error
    val = 'ulta';
    expect( validatePassword( val, validationKeys.passwordCase ) ).toBe( false );
  } );

  it( 'should call validatePassword method for checking if number exist and return proper flag based on value', () => {
    // Validation Success
    let val = 'Ulta123';
    expect( validatePassword( val, validationKeys.passwordNumberExist ) ).toBe( true );
    // Validation Error
    val = 'ulta';
    expect( validatePassword( val, validationKeys.passwordNumberExist ) ).toBe( false );
  } );

  it( 'should call validatePassword method for checking if special characters(@,# etc..) exist and return proper flag based on value', () => {
    // Validation Success
    let val = 'Ulta@123';
    expect( validatePassword( val, validationKeys.passwordSplCharExist ) ).toBe( true );
    // Validation Error
    val = 'ulta';
    expect( validatePassword( val, validationKeys.passwordSplCharExist ) ).toBe( false );
  } );

  it( 'should call validatePassword method for checking if invalid symbols or spaces exist and return proper flag based on value', () => {
    // Validation Success
    let val = 'Ulta@123';
    expect( validatePassword( val, validationKeys.passwordWithoutInvalidSymbol ) ).toBe( true );
    // Validation Error
    val = 'u lta';
    expect( validatePassword( val, validationKeys.passwordWithoutInvalidSymbol ) ).toBe( false );
    val = 'u}lta';
    expect( validatePassword( val, validationKeys.passwordWithoutInvalidSymbol ) ).toBe( false );
    val = 'u[lta]';
    expect( validatePassword( val, validationKeys.passwordWithoutInvalidSymbol ) ).toBe( false );
    val = 'u>>>lta';
    expect( validatePassword( val, validationKeys.passwordWithoutInvalidSymbol ) ).toBe( false );
  } );

  it( 'should call validatePassword method for checking if length greater than 8 and return proper flag based on value', () => {
    // Validation Success
    let val = 'Ulta123456';
    expect( validatePassword( val, validationKeys.passwordLength ) ).toBe( true );
    // Validation Error
    val = 'ulta';
    expect( validatePassword( val, validationKeys.passwordLength ) ).toBe( false );
  } );


  it( 'should call validatePassword method for checking multiple validations if the validations keys are given as array', () => {
    const validationKeysArray = [
      validationKeys.passwordCase,
      validationKeys.passwordNumberExist,
      validationKeys.passwordSplCharExist,
      validationKeys.passwordWithoutInvalidSymbol,
      validationKeys.passwordLength
    ];
    // Validation Success
    let val = 'Ulta@123456';
    expect( validatePassword( val, validationKeysArray ) ).toBe( true );
    // Validation Error
    val = 'ulta111@';
    expect( validatePassword( val, validationKeysArray ) ).toBe( false );
  } );


} );
