import forEach from 'lodash/forEach';
import React from 'react';
import moment from 'moment';
import { isServer } from '../device_detection/device_detection';
import { formatNumber } from '../../views/Global/Global';

const protocol = isServer() ? 'http' : global.location.protocol;

export const removeSpecialCharacters = ( val ) => ( val.replace( /[^a-zA-Z0-9]/g, '' ) );

// for SSR, host will be initialized to undefined. the setServerHost method will be invoked from the appropriate controller to set the host value
export let host = isServer() ? undefined : ( global.location.hostname.search( /ir.ultabeauty.com|storead|creative/ ) !== -1 || global.location.hostname.search( 'ulta.com' ) === -1 ) ? 'www.ulta.com' : global.location.hostname;

export const setServerHost = ( serverHost )=>{
  host = serverHost;
}

export const isIntlSite = ( url = global.location.host ) => ( /global.*\.ulta\.com/ ).test( url );

/**
 * prepends the host the app is running on to the beginning of a URL
 * that starts with a single '/' or returns the original URL
 * or otherwise modified URL in special cases
 * @param {string} host - A string that describes the hostname the app is running on
 * @param {string} url - the original URL sent into the <Anchor /> component
 */
export const fullyQualifyLink = ( host, url ) => {

  let _url = typeof url === 'string' ? url : '';
  // this is for Canada shipping
  if( _url.indexOf( 'global-ulta.com' ) !== -1 ){

    if( host === 'ulta.com' || host === 'www.ulta.com' ){
      // handle canada shipping link for 3rd party pages
      return '//global.ulta.com';
    }
    else {
      // if a URL for Canada shipping comes in we want to modify it to go
      // to the host the app is running on
      return _url.replace( /\/\/global-ulta\.com/, `//global-${host}` );
    }

  }
  else if( !_url.match( /^\/\/|^http:|^https:|^#|^tel:|^data:|^mailto:/ ) ){

    // if URL starts with '//', 'http:', 'https:', or the URL is '#'
    // we skip this step and just return the original URL at the end of this function

    // if a URL starts with a single / we should modify it to
    // prepend '//' + host

    // does the _url start with a slash?
    if( _url.charAt( 0 ) === '/' ){
      _url = _url.substring( 1 );
    }

    return `//${ host }/${ _url }`;
  }

  // return default URL if there are no special cases met
  return _url;

}


export const maskFirstFiveSSN = ( fieldValue, ssnShowMask, ssnHistory ) => {
  // may need to check for password masking character for different OS/browsers
  let _ssnHistory = ssnHistory;
  let ssnValue;
  let ssnMask;
  let passCharacter = '\u2022';
  let passCharacterRegex = '\u{2022}'
  let regex = new RegExp( `[^\\d\\${ passCharacterRegex }]`, 'g' );
  let ssnFieldValue = fieldValue.replace( regex, '' );
  let lastDigit = ssnFieldValue.substr( ssnFieldValue.length - 1 );
  let lastFourDigits = ssnFieldValue.substr( 5, 4 ).replace( new RegExp( `\\${ passCharacterRegex }`, 'g' ), '' );

  if( ssnShowMask ){
    if( ssnFieldValue.length <= 5 ){

      if( _ssnHistory.length < ssnFieldValue.length ){
        let digitEnteredInMaskArea = false;
        for ( let i = 0; i < 5; i++ ){
          if( /\d/g.test( ssnFieldValue[i] ) ){
            _ssnHistory.splice( i, 0, ssnFieldValue[i] );
            digitEnteredInMaskArea = true;
          }
        }
        if( !digitEnteredInMaskArea ){
          _ssnHistory.push( lastDigit );
        }

      }
      else {

        for ( let i = 0; i < ssnFieldValue.length; i++ ){
          if( /\d/g.test( ssnFieldValue[i] ) ){
            _ssnHistory.splice( i, 0, ssnFieldValue[i] );
          }
        }
        _ssnHistory = _ssnHistory.slice( 0, ssnFieldValue.length );

        if( ssnFieldValue.length === 0 ){
          _ssnHistory.pop();
        }

      }

    }
    else {
      let re = /\d/g;
      if( ssnFieldValue.match( re ).length >= 5 && !ssnFieldValue.match( new RegExp( '[^\\d]', 'g' ) ) ){
        _ssnHistory = Array.from( ssnFieldValue.replace( new RegExp( `[^\\d]`, 'g' ), '' ).substr( 0, 5 ) );
      }
      else {
        for ( let i = 0; i < 5; i++ ){
          let poppedDigit = '';
          if( /\d/g.test( ssnFieldValue[i] ) ){
            _ssnHistory.splice( i, 0, ssnFieldValue[i] );
            poppedDigit = _ssnHistory.pop();
            if( ssnFieldValue.match( new RegExp( `\\${ passCharacterRegex }`, 'g' ) ).length >= 5 ){
              lastFourDigits = poppedDigit + lastFourDigits;
            }
          }
        }
      }

    }
  }
  else {
    _ssnHistory = Array.from( ssnFieldValue.substr( 0, 5 ) );
    ssnValue = ssnFieldValue;
  }

  ssnValue = _ssnHistory.toString().replace( /\,/g, '' ) + lastFourDigits;

  if( ssnValue.length > 5 ){
    ssnMask = `${ Array( 4 ).join( passCharacter )} - ${ Array( 3 ).join( passCharacter ) } - ${ ssnValue.substr( 5, 4 ) }`
  }
  else if( ssnValue.length > 3 ){
    ssnMask = `${ Array( 4 ).join( passCharacter ) } - ${ Array( ssnValue.substr( 3 ).length + 1 ).join( passCharacter ) }`
  }
  else {
    ssnMask = `${ Array( ssnValue.length + 1 ).join( passCharacter ) }`
  }

  return {
    ssnMask,
    ssnHistory,
    ssnValue
  }

}



export const replaceURIParams = ( endpoint, URIParams ) => {
  let url = endpoint;
  forEach( URIParams, ( val, key ) => {
    url = url.replace( ':' + key, val );
  } );
  return url;
}


// this method will take a price value as input and return the formatted output in USD currency
export const formatPrice = ( price ) => {
  return formatNumber( price, { style: 'currency', currency: 'USD' } );
}

// this method will take a date value as input and return the formatted output in MMM dd
export const formatDate = ( dateInput ) => {
  var date = moment( dateInput, 'YYYY-MM-DD HH:mm:ss' ).toDate();
  return new Intl.DateTimeFormat( 'en-US', { day: '2-digit', month: 'short' } ).format( date );
}
// NavDisplayContent trademark display changes
export const formatNavDisplayContentForTradeMark = ( navDisplayContent ) => {
  if( navDisplayContent && navDisplayContent.endsWith( '&trade;' ) ){
    return [navDisplayContent.replace( '&trade;', '' ), <span>&trade;</span>];
  }
  else {
    return navDisplayContent;
  }
}