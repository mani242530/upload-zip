import React, { Component } from 'react';
import { Provider } from 'react-redux';
import moment from 'moment';
import {
  fullyQualifyLink, replaceURIParams, maskFirstFiveSSN, setServerHost, host, formatPrice, isIntlSite, formatNavDisplayContentForTradeMark, formatDate
} from './formatters';
import Global, { formatNumber } from '../../views/Global/Global';
import { configureStore, mountWithIntlGlobal } from '../enzyme/intl-enzyme-test-helper';


jest.mock( 'moment', () =>{
  return {
    __esModule: true,
    default: jest.fn( () =>{
      return {
        toDate:jest.fn( () =>{
          return new Date( '2021-11-12T06:00:00.000Z' )
        } )
      }
    } )
  }
} );

describe( 'fully qualified links', () => {


  it( 'should return unmodifiedURL if it is a 3rd party link', () => {
    let url = '//careers.ulta.com';
    let host = 'da3.ulta.com';
    expect( fullyQualifyLink( host, url ) ).toBe( url );
  } );

  it( 'should return an unmodifiedURL if a protocol is defined in the URL', () => {
    let url = 'http://careers.ulta.com';
    let host = 'da3.ulta.com';

    expect( fullyQualifyLink( host, url ) ).toBe( url );
  } );

  it( 'should return an unmodifiedURL if the URL is #', () => {
    let url = '#';
    let host = 'ulta.com';

    expect( fullyQualifyLink( host, url ) ).toBe( url );
  } );

  it( 'should return an unmodifiedURL if the URL is # followed with id like #hello', () => {
    let url = '#hello';
    let host = 'ulta.com';

    expect( fullyQualifyLink( host, url ) ).toBe( url );
  } );

  it( 'should return an unmodifiedURL if the URL is tel:', () => {
    let url = 'tel:';
    let host = 'ulta.com';

    expect( fullyQualifyLink( host, url ) ).toBe( url );
  } );

  it( 'should return an unmodifiedURL if the URL is data:', () => {
    let url = 'data:';
    let host = 'ulta.com';

    expect( fullyQualifyLink( host, url ) ).toBe( url );
  } );

  it( 'should return an unmodifiedURL if the URL is mailto:', () => {
    let url = 'mailto:';
    let host = 'ulta.com';

    expect( fullyQualifyLink( host, url ) ).toBe( url );
  } );

  it( 'should return an unmodifiedURL if URL starts with //', () => {
    let url = '//da3.ulta.com/ulta';
    let host = 'qa1.ulta.com';

    expect( fullyQualifyLink( host, url ) ).toBe( url );
  } );

  it( 'should return a modified URL for Canada shipping links', () => {
    // allows for inserting hostname to form a new one
    // ex: `//global-ulta.com/`, => '//global-qa3.ulta.com/'
    let url = '//global-ulta.com';
    let host = 'da3.ulta.com';

    expect( fullyQualifyLink( host, url ) ).toBe( '//global-da3.ulta.com' );
  } )

  it( 'should return a modified URL when sent a link which starts with \'/\'', () => {
    // prepends environment to a link
    // ex: '/ulta/stores/storelocator.jsp' => '//www.ulta.com/ulta/stores/storelocator.jsp'
    let url = '/ulta/global/nav/allbrands.jsp';
    let host = 'qa1.ulta.com';

    expect( fullyQualifyLink( host, url ) ).toBe( '//' + host + url )
  } );

  it( 'should remove the slash from the first position for a URL', () => {
    let url = '/ulta/beautyservices/';
    let host = 'qa1.ulta.com';

    let res = '//' + host + url;
    expect( fullyQualifyLink( host, url ) ).toBe( res );
  } );

  it( 'should change global-ulta.com to global.ulta.com when on 3rd party pages', () => {
    let url = '/global-ulta.com';
    let host = 'ulta.com';

    let res = '//global.ulta.com';
    expect( fullyQualifyLink( host, url ) ).toBe( res );
  } );

  it( 'should change global-ulta.com to global.ulta.com when on production', () => {
    let url = '/global-ulta.com';
    let host = 'www.ulta.com';

    let res = '//global.ulta.com';
    expect( fullyQualifyLink( host, url ) ).toBe( res );
  } );

} );

describe( 'replaceURIParams', () => {

  it( 'should replace uri params with the values passed', () => {
    const endpoint = '/services/v5/catalog/product/:productid';
    const URIParams = { productid:1233 }
    expect( replaceURIParams( endpoint, URIParams ) ).toBe( '/services/v5/catalog/product/1233' );
  } );

} );

describe( 'mask First Five SSN', () => {

  it( 'should return masked field value - ssnShowMask true', () => {
    let fieldValue = 'test 123';
    let ssnShowMask = true;
    let ssnHistory = [];
    expect( JSON.stringify( maskFirstFiveSSN( fieldValue, ssnShowMask, ssnHistory ) ) ).toBe( '{\"ssnMask\":\"•••\",\"ssnHistory\":[\"1\",\"2\",\"3\"],\"ssnValue\":\"123\"}' );
  } );

  it( 'should return  masked field value - ssnShowMask false', () => {
    let fieldValue = 'test 123';
    let ssnShowMask = false;
    let ssnHistory = [];
    expect( JSON.stringify( maskFirstFiveSSN( fieldValue, ssnShowMask, ssnHistory ) ) ).toBe( '{\"ssnMask\":\"•••\",\"ssnHistory\":[],\"ssnValue\":\"123\"}' );
  } );

  it( 'should return  masked field value with last four digit', () => {
    let fieldValue = '123456789';
    let ssnShowMask = false;
    let ssnHistory = [];
    expect( JSON.stringify( maskFirstFiveSSN( fieldValue, ssnShowMask, ssnHistory ) ) ).toBe( '{\"ssnMask\":\"••• - •• - 6789\",\"ssnHistory\":[],\"ssnValue\":\"123456789\"}' );
  } );

  it( 'should return masked field value - ssnShowMask true and fieldValue digits length greater than 5', () => {
    let fieldValue = 'test 123456';
    let ssnShowMask = true;
    let ssnHistory = [];
    expect( JSON.stringify( maskFirstFiveSSN( fieldValue, ssnShowMask, ssnHistory ) ) ).toBe( '{\"ssnMask\":\"••• - •• - 6\",\"ssnHistory\":[],\"ssnValue\":\"123456\"}' );
  } );

  it( 'should return masked field value - ssnShowMask true and ssnHistory is not empty', () => {
    let fieldValue = 'test 1234';
    let ssnShowMask = true;
    let ssnHistory = ['1', '2', '3', '4'];
    expect( JSON.stringify( maskFirstFiveSSN( fieldValue, ssnShowMask, ssnHistory ) ) ).toBe( '{\"ssnMask\":\"••• - •\",\"ssnHistory\":[\"1\",\"2\",\"3\",\"4\",\"1\",\"2\",\"3\",\"4\"],\"ssnValue\":\"1234\"}' );
  } );

  it( 'should return expected masked field value - ssnShowMask true and fieldValue,ssnHistory is empty', () => {
    let fieldValue = '';
    let ssnShowMask = true;
    let ssnHistory = [];
    expect( JSON.stringify( maskFirstFiveSSN( fieldValue, ssnShowMask, ssnHistory ) ) ).toBe( '{\"ssnMask\":\"\",\"ssnHistory\":[],\"ssnValue\":\"\"}' );
  } );

  it( 'should set the host value when setServerHost is invoked', () => {
    const requestHost = 'ds3.ulta.com';
    setServerHost( requestHost );
    expect( host ).toBe( requestHost );
  } );

  it( 'should return the formated price with currency when formatPrice is invoked', () => {
    let store = configureStore( );
    mountWithIntlGlobal(
      <Provider store={ store }>
        <Global />
      </Provider>
    );
    expect( formatPrice( 12 ) ).toBe( '$12.00' );
  } );
  it( 'should return the formated date when formatDate is invoked', () => {
    let store = configureStore( );
    mountWithIntlGlobal(
      <Provider store={ store }>
        <Global />
      </Provider>
    );
    expect( formatDate( '11-12-2021 00:00:00.000-06:00' ) ).toBe( new Intl.DateTimeFormat( 'en-US', { day: '2-digit', month: 'short' } ).format( new Date( '2021-11-12T06:00:00.000Z' ) ) );
    expect( moment ).toHaveBeenCalledWith( '11-12-2021 00:00:00.000-06:00', 'YYYY-MM-DD HH:mm:ss' );
  } );
} );

describe( 'isIntlSite', () => {

  it( 'should return true for global site production urls', () => {
    expect( isIntlSite( 'global.ulta.com' ) ).toBe( true );
  } );

  it( 'should return true for global site QA urls', () => {

    expect( isIntlSite( 'global-qa1.ulta.com' ) ).toBe( true );
  } );

  it( 'should return false for non global site urls', () => {

    expect( isIntlSite( 'www.ulta.com' ) ).toBe( false );
  } );

} );

describe( 'format &trade; to ™', () => {

  it( 'should format trademark as ™ when appended as &trade; at the end of navDisplayContent text ', () => {
    let navDisplayContent = 'SampleText&trade;';
    expect( JSON.stringify( formatNavDisplayContentForTradeMark( navDisplayContent ) ) ).toBe( JSON.stringify( ['SampleText', <span>™</span>] ) );
  } );


} );
