/* eslint no-console: ["error", { allow: ["warn", "error", "log", "groupEnd", "group"] }] */
import merge from 'lodash/merge';
import Cookies from 'js-cookie';
import { isServer } from '../device_detection/device_detection';

export const formatOmnitureAttr = ( tag, message ) => {
  return `${tag} - ${message.toLowerCase()}`;
}

export const fireAnalyticsEvent = ( event, eventData, eventFactory = omnitureEventFactory ) => {
  if( !isServer() ){
    let analyticsTrigger = new CustomEvent( event, { 'detail': eventData } );

    eventFactory.triggerOmnitureEvent( analyticsTrigger );
    if( Cookies.get( 'showOmnitureLogs' ) === 'true' || global.TRACK_ANALYTICS_LOGS === true ){
      console.log( ':::Analytics Event (utils)::: ', [event, eventData] );
    }
  }

}

export const updateDataLayer = ( obj, eventFactory = omnitureEventFactory ) => {
  if( !isServer() ){
    if( obj.errorPageData !== undefined ){
      global.errorPageData = {
        ...global.errorPageData,
        ...obj.errorPageData
      };
      if( Cookies.get( 'showOmnitureLogs' ) === 'true' || global.TRACK_DATA_LAYER_LOGS === true ){
        console.log( ':::DataLayer Update Event (utils)::: ', ['GLOBAL::DATA_LAYER_UPATED', obj.globalPageData] );
      }
    }

    if( obj.globalPageData !== undefined ){
      global.globalPageData = {
        ...global.globalPageData,
        ...obj.globalPageData
      };
      // trigger a global event so that 3rd parties can interact with the globalPagedataObject
      let dataUpdateEvent = new CustomEvent( 'DATA_LAYER_UPDATED', {
        'detail': {
          globalPageData: global.globalPageData
        }
      } );
      eventFactory.triggerOmnitureEvent( dataUpdateEvent );
      if( Cookies.get( 'showOmnitureLogs' ) === 'true' || global.TRACK_DATA_LAYER_LOGS === true ){
        console.log( ':::DataLayer Update Event (utils)::: ', ['GLOBAL::DATA_LAYER_UPATED', obj.globalPageData] );
      }
    }
  }

}

export const getRoute = ( route ) => {
  if( !isServer() ){
    let location = global.location.pathname;

    switch ( route ){
      case 'bag':
        return location.indexOf( 'bag' ) > 0;
      case 'checkout':
        return location.indexOf( 'checkout' ) > 0;
      default:
        return false;
    }
  }
}

// this is the method which needs to be invoked at places where omniture event needs to be fired
// currently we will need to have this in omniture.js and analytics.sagas
// this will push the event to the queue, and invoke the method to dispatchEvents
const triggerOmnitureEvent = ( event ) => {
  omnitureEventFactory.omnitureEventQueue.push( event );
  omnitureEventFactory.dispatchEvents();
}

// dispatchEvents will check if signal is already loaded
// if signal is already loaded, will take out events one by one from the queue in FIFO manner and dispatch it
// if signal is not loaded, it will not dispatch the events, but wait until dispatchEvents is again called from listenSignalLoad
const dispatchEvents = () => {
  if( omnitureEventFactory.isSignalLoaded ){
    let event = omnitureEventFactory.omnitureEventQueue.shift();
    while ( event ){
      if( Cookies.get( 'showOmnitureLogs' ) === 'true' ){
        console.log(' ****************************** ' ); // eslint-disable-line
        console.log( event ); // eslint-disable-line
      }
      document.dispatchEvent( event );
      event = omnitureEventFactory.omnitureEventQueue.shift();
    }
  }
}

// this method will add the listener to lister for SIGNALReady events
// once SIGNALReady event is received it will set isSignalLoaded to true and will dispatch already captured events
const listenSignalLoad = () => {
  document.addEventListener( 'SIGNALReady', function( e ){
    omnitureEventFactory.isSignalLoaded = true;
    omnitureEventFactory.dispatchEvents();
  }, false );
}

export const omnitureEventFactory = {
  // omnitureEventQueue will hold all the events to be fired
  omnitureEventQueue:[],
  // isSignalLoaded will indicate whether signal is loaded, i.e if SIGNALReady is received
  isSignalLoaded:false,
  triggerOmnitureEvent,
  dispatchEvents,
  listenSignalLoad
}
