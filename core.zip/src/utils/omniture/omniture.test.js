

import isFunction from 'lodash/isFunction';
import Cookies from 'js-cookie';
import {
  formatOmnitureAttr,
  fireAnalyticsEvent,
  updateDataLayer,
  getRoute
} from './Omniture';
import { omnitureEventFactory } from './omniture';


describe( 'omniture attr formatting', () => {

  omnitureEventFactory.triggerOmnitureEvent = jest.fn();

  it( 'should be a function', () => {
    expect( isFunction( formatOmnitureAttr ) ).toBeTruthy();
  } );

  it( 'should format an omniture message and return the new output', () => {

    expect( formatOmnitureAttr( 'g', 'TESt' ) ).toBe( 'g - test' );
  } );

  it( 'should triggers fireAnalytics Event', () => {
    let analyticsTrigger = new CustomEvent( 'testAnalyticsEvent', { 'detail': '' } );
    global.TRACK_ANALYTICS_LOGS = true;
    fireAnalyticsEvent( analyticsTrigger, undefined, omnitureEventFactory ) ;
    expect( omnitureEventFactory.triggerOmnitureEvent ).toHaveBeenCalled();
  } );

  it( 'should triggers updateDataLayer Event', () => {
    Cookies.set( 'showOmnitureLogs', 'true' );
    const obj = {
      errorPageData: 'errorPageData',
      globalPageData: 'globalPageData'
    }
    global.TRACK_ANALYTICS_LOGS = true;
    updateDataLayer( obj, omnitureEventFactory ) ;
    expect( omnitureEventFactory.triggerOmnitureEvent ).toHaveBeenCalled();
  } );

  it( 'getRoute method should return false if route is not bag,checkout', () => {
    expect( getRoute( 'home' ) ).toBe( false );
  } );

} );
