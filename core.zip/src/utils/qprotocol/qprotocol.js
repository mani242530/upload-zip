import isUndefined from 'lodash/isUndefined';
import Cookies from 'js-cookie';


// listenQubitLoad is invoked from global.js component mount, and keeps polling is qubit uv is initialized
// this checks if window.uv is defined, which indicates the qubit script was initialized
// the method gets executed every 100 ms until window.uv is available, at which it does a clearInterval
// it then invokes triggerEvents method which triggers any events which were stored in the queue waiting for window.uv to be initialized
const listenQubitLoad = () => {
  let initalizeQprotocol = setInterval( () => {

    if( global.uv ){
      clearInterval( initalizeQprotocol );
      qProtocol.triggerEvents();
    }
  }, 100 ); // check every 100ms
}


// resetPageView provides a handle to reset the isPageViewFired variable
// this will be particularly used for reseting the isPageViewFired on route change
// also it will clear the queue of any events which remains
const resetPageView = () => {
  qProtocol.isPageViewFired = false;
  qProtocol.qubitChildEventsQueue = [];
  qProtocol.qubitEventsQueue = [];
};

// this method should be used for firing a page event.
// this will fire the event and mark isPageViewFired as true
// an trigger any child events which would have been waiting in the child events queue
const triggerPageEvent = ( type, data )=>{
  qProtocol.triggerEvent( type, data );
  qProtocol.isPageViewFired = true;
  qProtocol.triggerChildEvents();
}

// this method should be used for firing those events, which needs to be fired only after a pageView is fired
// it will first push the event to the queue
// and if the page view is already fired, it will trigger child events
// if the page view is not yet fired, it will no trigger the child event, and the child event will be triggered as part of triggerPageEvent
const triggerChildEvent = ( type, data )=>{
  qProtocol.qubitChildEventsQueue.push( { type, data } );
  if( qProtocol.isPageViewFired ){
    qProtocol.triggerChildEvents();
  }
}

// this method will take the child events one by one from the queue and trigger the same
// in FIFO order
const triggerChildEvents = ()=>{
  let event = qProtocol.qubitChildEventsQueue.shift();
  while ( event ){
    qProtocol.triggerEvent( event.type, event.data );
    event = qProtocol.qubitChildEventsQueue.shift();
  }
}

// this method will push the event to the qubitEventQueue and if
// window.uv is alread defined will invoke triggerEvents to fire the events
// if window.uv is not defined, it will not do anything, leaving the events in the queue waiting it to be fired when qubit is initialized
const triggerEvent = ( type, data )=>{
  qProtocol.qubitEventsQueue.push( { type, data } )
  if( global.uv ){
    qProtocol.triggerEvents();
  }
}

const triggerEvents = ()=>{
  let event = qProtocol.qubitEventsQueue.shift();
  while ( event ){
    if( global.location.search.indexOf( 'showQubitLogs=true' ) !== -1 ||
  Cookies.get( 'showQubitLogs' ) === 'true' ){
      if( isUndefined( Cookies.get( 'showQubitLogs' ) ) ){
        Cookies.set( 'showQubitLogs', 'true' );
      }
    }
    global.uv.emit( event.type, event.data );
    event = qProtocol.qubitEventsQueue.shift();
  }
}

const qProtocol = {
  // isPageViewFired will indicate whether the pageview event was already fired
  isPageViewFired:false,
  qubitChildEventsQueue:[],
  qubitEventsQueue:[],
  resetPageView,
  triggerPageEvent,
  triggerChildEvent,
  triggerChildEvents,
  triggerEvent,
  triggerEvents,
  listenQubitLoad
}

export default qProtocol;
