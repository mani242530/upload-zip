import Cookies from 'js-cookie';
import isFunction from 'lodash/isFunction';
import qProtocol from './QProtocol';

describe( 'QProtocol testing', () => {

  const {
    triggerPageEvent,
    resetPageView,
    isPageViewFired,
    triggerEvent,
    triggerEvents,
    triggerChildEvent,
    triggerChildEvents
  } = qProtocol

  it( 'should set isPageViewFired as false and clear the queue of any events when resetPageView is invoked', () => {
    qProtocol.isPageViewFired = true;
    qProtocol.qubitChildEventsQueue = [{ event:'test' }];
    qProtocol.qubitEventsQueue = [{ event:'test1' }];
    resetPageView();
    expect( qProtocol.isPageViewFired ).toBe( false );
    expect( qProtocol.qubitChildEventsQueue ).toEqual( [] );
    expect( qProtocol.qubitEventsQueue ).toEqual( [] );

  } );
  it( 'should invoke triggerEvent, set isPageViewFired to true and invoke triggerChildEvents on triggerPageEvent ', () => {
    qProtocol.triggerEvent = jest.fn();
    qProtocol.isPageViewFired = false;
    qProtocol.triggerChildEvents = jest.fn();
    triggerPageEvent();
    expect( qProtocol.triggerEvent ).toBeCalled();
    expect( qProtocol.isPageViewFired ).toBe( true );
    expect( qProtocol.triggerChildEvents ).toBeCalled();
  } );

  it( 'should push event to queue and should not invoke triggerChildEvents if isPageViewFired is false when triggerChildEvent is invoked', () => {
    qProtocol.qubitChildEventsQueue = [];
    qProtocol.isPageViewFired = false;
    qProtocol.triggerChildEvents = jest.fn();
    triggerChildEvent( { event:'test' } );
    expect( qProtocol.qubitChildEventsQueue.length ).toBe( 1 )
    expect( qProtocol.triggerChildEvents ).not.toBeCalled();
  } );

  it( 'should push event to queue and invoke triggerChildEvents if isPageViewFired is true when triggerChildEvent is invoked', () => {
    qProtocol.qubitChildEventsQueue = [];
    qProtocol.isPageViewFired = true;
    qProtocol.triggerChildEvents = jest.fn();
    triggerChildEvent( { event:'test' } );
    expect( qProtocol.qubitChildEventsQueue.length ).toBe( 1 )
    expect( qProtocol.triggerChildEvents ).toBeCalled();
  } );

  it( 'should invoke triggerEvent on the events in thee queue when triggerChildEvents is invoked', () => {
    const event = { type:'test', data:{ qty:1 } };
    qProtocol.qubitChildEventsQueue = [];
    qProtocol.qubitChildEventsQueue.push( event );
    qProtocol.triggerEvent = jest.fn();
    triggerChildEvents();
    expect( qProtocol.triggerEvent ).toHaveBeenLastCalledWith( event.type, event.data );
  } );

  it( 'should invoke window.uv.emit on the events in the queue when triggerEvents is invoked', () => {
    window.uv = {
      emit:jest.fn()
    }
    const event = { type:'test', data:{ qty:1 } };
    const event1 = { type:'test1', data:{ qty:2 } };
    qProtocol.qubitEventsQueue = [];
    qProtocol.qubitEventsQueue.push( event );
    qProtocol.qubitEventsQueue.push( event1 );
    triggerEvents();
    expect( window.uv.emit ).toHaveBeenCalledTimes( 2 );
    expect( window.uv.emit ).toBeCalledWith( event.type, event.data );
    expect( window.uv.emit ).toBeCalledWith( event1.type, event1.data );
  } );

  it( 'should invoke triggerEvents if window.uv is defined', () => {
    window.uv = {
      emit:jest.fn()
    }
    qProtocol.triggerEvents = jest.fn();
    const event = { type:'test', data:{ qty:1 } };
    triggerEvent( event.type, event.data );
    expect( qProtocol.qubitEventsQueue[ 0 ] ).toEqual( event );
    expect( qProtocol.triggerEvents ).toBeCalled();
  } );

  it( 'should not invoke triggerEvents if window.uv is not defined', () => {
    window.uv = undefined;
    qProtocol.triggerEvents = jest.fn();
    const event = { type:'test', data:{ qty:1 } };
    triggerEvent( event.type, event.data );
    expect( qProtocol.qubitEventsQueue[ 0 ] ).toEqual( event );
    expect( qProtocol.triggerEvents ).not.toBeCalled();
  } );

} );