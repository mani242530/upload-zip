/* eslint no-console: ["error", { allow: ["warn", "error", "log", "groupEnd", "group"] }] */

import { isServer } from '../device_detection/device_detection';

// IMPORTANT, PLEASE READ!
// The createScriptTag method expects an object in the following format:
// {
//   'attributes': {
//     'id': 'value', - Required
//     'type': 'value', - Required ('text/javascript', 'application/ld+json', etc.)
//     'src': 'value', - Required if no 'content' value
//     'async': 'async', - Optional
//     ... any other attributes needed for the script tag
//   },
//   'content': 'script block content', - Required if no attributes.src value
//   'options': {
//     'insertId': 'value', - Optional, for inserting the script before a specified element id
//     'onload': 'value', - Optional, for triggering another method call as an event
//     ... other options can be added as needed
//   }
// }

export const createScriptTag = ( obj ) => {
  if( !isServer() && document.getElementById( obj.attributes.id ) === null ){
    try {
      let elem = document.createElement( 'script' );

      // if options.onload exists, run that method after script load
      if( obj.options && obj.options.onload ){
        elem.addEventListener( 'load', obj.options.onload );
      }

      // parse the script tag attributes
      Object.entries( obj.attributes ).map( ( [key, value] ) => {
        elem.setAttribute( key, value );
      } );

      // if we have body content for the tag we will inject it
      if( obj.content ){
        elem.innerHTML = obj.content;
      }

      // add the element to the DOM.
      // If 'insertId' exists, the script will be inserted before that id
      if( obj.options && obj.options.insertId ){
        let parent = document.getElementById( obj.options.insertId ).parentNode;
        parent.insertBefore( elem, document.getElementById( obj.options.insertId ) );
      }
      else {
        document.getElementsByTagName( 'head' )[ 0 ].appendChild( elem );
      }

      const params = new URLSearchParams( global.location.search );
      if( global.SCRIPT_TAG_LOGS ){
        console.group( '3rd Party scripts' );
        if( obj.attributes.src ){
          console.log( `a script tag with the src attribute of %c${ obj.attributes.src } %chas been added to the dom with the ID of %c${ obj.attributes.id }`, 'font-weight: bold; color: #0000ff', 'font-weight: normal color: #000', 'font-weight: bold; color: #0000ff' );
        }
        else {
          console.log( `a script tag containing javascript has been added to the document with the ID of %c${ obj.attributes.id } `, 'font-weight: bold; color: #0000ff;' );
        }
        console.groupEnd();
      }
    }
    catch ( err ){
      if( process.env.NODE_ENV === 'development' ){
        throw `there was an issue adding the script ${ obj.attributes.src } to the document`;
      }
    }
  }
}

export const removeScriptTag = id => {
  let elem = document.getElementById( id );

  if( elem ){
    try {
      elem.parentNode.removeChild( elem );
      console.log( `the script with the id of %c${ id } %cwas sucessfully removed `, 'font-weight: bold; color: #ff0000;', 'font-weight: normal;, color: #000;' );
    }
    catch ( err ){
      console.log( `there was an error trying to remove the script with the ID of  %c${ id } `, 'font-weight: bold; color: #ff0000;' );
    }
  }
}
