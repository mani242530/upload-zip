import _ from 'lodash';
import {
  createScriptTag,
  removeScriptTag
} from './third_party_scripts';


describe( 'Third-Party Scripts', () => {
  window.SCRIPT_TAG_LOGS = true;
  describe( 'createScriptTag', () => {
    it( 'The function "createScriptTag" should be defined.', () => {
      expect( _.isFunction( createScriptTag ) ).toBe( true );
    } );
    const testScriptHandler = 'onScriptLoad()'
    createScriptTag(
      {
        'attributes': {
          'id': 'testScript',
          'type': 'text/javascript',
          'src': '/js/testScript.js',
          'async': 'async',
          'onload': `${ testScriptHandler }`
        }
      }
    );

    it( 'should have the correct src', () => {
      expect( document.getElementById( 'testScript' ).getAttribute( 'src' ) ).toEqual( '/js/testScript.js' );
    } );

    it( 'async should be defined', () => {
      expect( document.getElementById( 'testScript' ).getAttribute( 'async' ) ).toBeDefined();
    } );

    it( 'onload should be defined', () => {
      expect( document.getElementById( 'testScript' ).getAttribute( 'onload' ) ).toBe( 'onScriptLoad()' );
    } );

    createScriptTag(
      {
        'attributes': {
          'id': 'testScriptPre',
          'type': 'text/javascript'
        },
        'content': `var test='JibberJabber';`,
        'options': {
          'insertId': 'testScript'
        }
      }
    );

    it( 'testScriptPre should be defined above testScript', () => {
      expect( document.getElementById( 'testScript' ).previousSibling.innerHTML ).toEqual( `var test='JibberJabber';` );
    } );

    it( 'The function "removeScriptTag" should be defined.', () => {
      expect( _.isFunction( removeScriptTag ) ).toBe( true );
    } );

  } );

} );
