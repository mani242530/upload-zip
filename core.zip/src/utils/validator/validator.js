export const minlength = ( val, maxNumber ) => {
  var res = val, // grabs the value
      len = res.length, // grabs the length
      max = maxNumber, // sets a max chars
      result;

  if( len < max ){
    result = false
  }
  else {
    result = true;
  }

  return result;
}

export const email = ( val ) => {
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test( val );
}

export const dateofbirth = ( input ) => {
  let _input = input;
  var birthDate = new Date( _input );
  _input = _input.replace( /\D/g, '' );
  var today = new Date();

  // Trim the remaining _input to ten characters, to preserve dateofbirth
  _input = _input.substring( 0, 8 );

  // Based upon the length of the string, we add formatting as necessary
  var size = _input.length;
  if( size < 8 ){
    var result = false;
    _input = result;
  }
  else {
    var completeDate = '' + ( today.getMonth() + 1 ) + today.getDate() + today.getFullYear();
    var age = today.getFullYear() - birthDate.getFullYear();
    var month = today.getMonth() - birthDate.getMonth();
    if( month < 0 || ( month === 0 && today.getDate() < birthDate.getDate() ) ){
      age--;
    }
    _input = age;
  }

  return _input;
}

// return input; //check for undefined in the code where you use this
// }
export const emptyField = ( val ) => {
  let _val = val;

  if( val.length > 0 ){
    _val = true;
  }
  else {
    _val = false;
  }
  return _val;

}
