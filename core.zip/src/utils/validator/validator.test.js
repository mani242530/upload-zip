import {
  minlength, email, dateofbirth, emptyField
} from './validator';

describe( './../../utils/validator ', () => {

  it( 'test for minlength', () => {
    const output = minlength( '1234567', 5 );
    expect( output ).toBeTruthy();
    const output1 = minlength( '1234', 5 );
    expect( output1 ).toBeFalsy();
  } );

  it( 'test for email', () => {
    const output = email( 'test@test.com' );
    expect( output ).toBeTruthy();
  } );

  it( 'test for dateofbirth', () => {
    const output = dateofbirth( new Date() + '' );
    expect( output ).toBe( 0 );
  } );

  it( 'test for emptyField', () => {
    const output = emptyField( '1' );
    expect( output ).toBeTruthy();
    const output1 = emptyField( '' );
    expect( output1 ).toBeFalsy();
  } );

} );