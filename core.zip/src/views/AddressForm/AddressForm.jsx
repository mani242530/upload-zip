/**
 * AddressForm
 */

import React from 'react';
import PropTypes from 'prop-types';
import has from 'lodash/has';
import Collapse from 'react-bootstrap/lib/Collapse';
import { STATES } from '../StateDropDownList/data/states';
import './AddressForm.css';
import messages from './AddressForm.messages';

import InputField from '../InputField/InputField';
import Anchor from '../Anchor/Anchor';
import SelectField from '../SelectField/SelectField';
import { formatMessage } from '../Global/Global';
import {
  validationKeys,
  validate
} from '../../utils/form_validations/form_validations';
import FormValidationMessages from '../../utils/form_validations/form_validations.messages';
import PlusCircle from '../Icons/PlusCircle';

const propTypes = {
  addressData: PropTypes.object,
  addressFormTitle:PropTypes.string.isRequired,
  tabIndex: PropTypes.number,
  name: PropTypes.string,
  addressOneLabel: PropTypes.string,
  addressTwoLabel: PropTypes.string,
  trackAnalytics: PropTypes.bool
}

const defaultProps = {
  name: '',
  trackAnalytics: false,
  addressOneLabel: messages.AddressOne.defaultMessage,
  addressTwoLabel:messages.AddressTwo.defaultMessage
}

const validationTrigger = val => {
  return validate( val, validationKeys.required, FormValidationMessages.required );
}

const Address2Text = val => {
  let returnVal = validate( val, validationKeys.showWarningMessage, messages.Address2 );
  return returnVal;
}

const AddressForm = ( props ) => {

  const {
    addressData,
    addressOpen,
    address2Open,
    toggleAddressFieldDisplay,
    toggleAddress2FieldDisplay,
    addressFormTitle,
    name,
    trackAnalytics
  } = props;

  const formTitle = addressOpen ? props.addressOneLabel : addressFormTitle;



  const handleToggleAddress = () => {
    if( addressOpen === false ){
      toggleAddressFieldDisplay();
    }
  }

  const handleToggleAddress2  = () => {
    if( address2Open === false ){
      toggleAddress2FieldDisplay();
    }
  }


  if( has( props, 'addressData.address1.value' ) && props.addressData.address1.value ){
    if( props.addressOpen === false ){
      toggleAddressFieldDisplay();
    }
  }


  return (
    <div
      className='AddressForm'
      aria-expanded={ addressOpen }
    >
      <div
        className='AddressForm_AddressOne'
        onClick={ handleToggleAddress }
        onKeyUp={ handleToggleAddress }
      >
        <InputField
          { ...( addressData?.address1 && { value: addressData.address1.value } ) }
          label={ formTitle }
          type='text'
          name={ `address1${props.name}` }
          onFocus={ handleToggleAddress }
          autoCapitalize={ true }
          formName={ name }
          trackAnalytics={ trackAnalytics }
          onChange={ handleToggleAddress }
        />
      </div>

      <Collapse in={ addressOpen } >
        <div>
          {
            !address2Open &&
            (
              <div className='AddressForm_AddressTwo--text'>
                <Anchor
                  url='#'
                  clickHandler={
                    handleToggleAddress2
                  }
                >
                  <span><PlusCircle /></span>
                  { formatMessage( messages.Address2 ) }
                </Anchor>
              </div>
            )
          }
          {
            address2Open &&
            (
              <div className='AddressForm_AddressTwo'>
                <InputField
                  { ...( addressData?.address2 && addressData.address2 !== null && { value: addressData.address2.value } ) }
                  label={ props.addressTwoLabel }
                  type='text'
                  name={ `address2${props.name}` }
                  autoCapitalize={ true }
                  formName={ name }
                  trackAnalytics={ trackAnalytics }
                />
              </div>
            )
          }

          <div className='AddressForm_City'>
            <InputField
              { ...( addressData?.city && { value: addressData.city.value } ) }
              label={ formatMessage( messages.City ) }
              type='text'
              name={ `city${props.name}` }
              autoCapitalize={ true }
              formName={ name }
              trackAnalytics={ trackAnalytics }
            />
          </div>

          <div className='AddressForm__StateZipCode'>
            <div className='AddressForm_State'>
              <SelectField
                { ...( addressData?.state && { value: addressData.state.value } ) }
                options={ STATES.US }
                country='US'
                name='state'
                defaultOption={ formatMessage( messages.State ) }
                label={ formatMessage( messages.State ) }
                formName={ name }
                validate={ [validationTrigger] }
              />
            </div>

            <div className='AddressForm_ZipCode'>
              <InputField
                { ...( addressData?.postalCode && { value: addressData.postalCode.value } ) }
                label={ formatMessage( messages.ZipCode ) }
                formatter={ { pattern: '99999' } }
                type='tel'
                name={ `postalCode${props.name}` }
                autoCapitalize={ true }
                formName={ name }
                trackAnalytics={ trackAnalytics }
              />
            </div>

          </div>
        </div>
      </Collapse>
    </div>

  );

}

AddressForm.propTypes = propTypes;
AddressForm.defaultProps = defaultProps;


export default AddressForm;
