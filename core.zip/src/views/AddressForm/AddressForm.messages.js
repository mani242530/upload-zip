/*
 * AddressForm Messages
 *
 * This contains all the text for the AddressForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  AddressOne: {
    id: 'i18n.AddressForm.AddressOne',
    defaultMessage: 'Home Address'
  },
  AddressTwo: {
    id: 'i18n.AddressForm.AddressTwo',
    defaultMessage: 'Home Address 2 (Optional)'
  },
  AddressLineOne: {
    id: 'i18n.AddressForm.AddressLineOne',
    defaultMessage: 'Address Line 1'
  },
  AddressLineTwo: {
    id: 'i18n.AddressForm.AddressLineTwo',
    defaultMessage: 'Address Line 2'
  },
  ZipCode: {
    id: 'i18n.AddressForm.ZipCode',
    defaultMessage: 'ZIP Code'
  },
  City: {
    id: 'i18n.AddressForm.City',
    defaultMessage: 'City'
  },
  State: {
    id: 'i18n.AddressForm.State',
    defaultMessage: 'State'
  },
  Address2: {
    id: 'i18n.AddressForm.Address2',
    defaultMessage: 'Add an apartment, suite, unit, building, floor, etc.'
  },
  Address2PlaceHolder: {
    id: 'i18n.AddressForm.Address2PlaceHolder',
    defaultMessage: 'Apt,suite,unit,floor,etc'
  }

} );
