import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { reduxForm } from 'redux-form';
import AddressForm from './AddressForm';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';


describe( '<AddressForm />', () => {

  let props = {
    addressFormInfo:'ShippingAddress',
    addressFormTitle: 'Address',
    addressOneLabel: 'Address',
    addressTwoLabel: 'Address 2 (Optional)',
    addressOpen: true,
    address2Open: true,
    tabIndex: 23,
    addressData: {
      address1: {
        value:'1000 remngton blvd',
        message:null
      },
      address2: {
        value:'Ste 200',
        message:null
      },
      city: {
        value:'Boolingbrook',
        message:null
      },
      postalCode:{
        value:'07105',
        message:null
      },
      state:{
        value:'IL',
        message:null
      }
    },
    toggleAddressFieldDisplay: jest.fn(),
    toggleAddress2FieldDisplay: jest.fn(),
    handleToggleAddress: jest.fn(),
    Address2Text: jest.fn()
  };

  describe( 'AddressForm when we give form data', () => {
    let component = mountComponent( props );
    it( 'renders whole address form fields without crashing', () => {
      expect( component.find( '.AddressForm' ).length ).toBe( 1 ) ;
      expect( component.find( '.AddressForm_AddressOne' ).length ).toBe( 1 );
      expect( component.find( '.in' ).length ).toBe( 1 );
      expect( component.find( '.AddressForm__StateZipCode .AddressForm_State' ).length ).toBe( 1 );
      expect( component.find( '.AddressForm__StateZipCode .AddressForm_ZipCode' ).length ).toBe( 1 );
    } );
  } );


  describe( 'AddressForm when we dont give form data -- new address', () => {
    let tempProps = {
      ...props,
      addressData: {
        address1:{
          value: undefined,
          message:null
        },
        address2:{
          value:undefined,
          message:null
        },
        city:{
          value:undefined,
          message:null
        },
        postalCode:{
          value:undefined,
          message:null
        },
        state:{
          value:undefined,
          message:null
        }
      },
      addressFormTitle: 'Address',
      addressOpen: false,
      address2Open: true,
      handleToggleAddress: jest.fn(),
      handleToggleAddress2: jest.fn(),
      toggleAddressFieldDisplay: jest.fn(),
      toggleAddress2FieldDisplay: jest.fn()
    };

    // console.log( tempProps );
    it( 'renders whole address form fields without crashing', () => {
      let component = mountComponent( tempProps );
      expect( component.find( '.AddressForm' ).length ).toBe( 1 );
      expect( component.find( '.AddressForm_AddressOne' ).length ).toBe( 1 );
      expect( component.find( '.in' ).length ).toBe( 0 );
    } );

    it( 'handle click on address field collapses other fields', () => {
      let component = mountComponent( tempProps );
      expect( component.find( '.AddressForm_AddressOne' ).length ).toBe( 1 );
      expect( component.find( '.in' ).length ).toBe( 0 );
      component.find( '.AddressForm_AddressOne' ).simulate( 'click' );
      expect( component.find( '.AddressForm_AddressTwo' ).length ).toBe( 1 );
    } );

    it( 'Address 2 form field shouldnt render', () => {
      tempProps.addressData.address1 = '1000 Remington Blvd';
      tempProps.address2Open = false;
      let component = mountComponent( tempProps );
      expect( component.find( '.AddressForm_AddressTwo' ).length ).toBe( 0 );
      expect( component.find( '.AddressForm_AddressTwo--text' ).length ).toBe( 1 );
      expect( component.find( '.AddressForm_AddressTwo--text Anchor' ).find( 'SVG' ).length ).toBe( 1 );
      component.find( 'Anchor' ).simulate( 'click' );
      expect( tempProps.toggleAddress2FieldDisplay ).toBeCalled();
    } );
  } );
} );


function mountComponent( props ){
  const store = configureStore( );
  const Decorator = reduxForm( { form: 'testForm' } )( AddressForm );
  return mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props }/>
    </Provider>
  );
}
