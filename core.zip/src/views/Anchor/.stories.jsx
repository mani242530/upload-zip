import React from 'react';
import Anchor, { SELF, BLANK } from './Anchor';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { WithNotes } from '@storybook/addon-notes';

storiesOf( 'Anchor', module )
  .add( 'All attributes', () => (
    <WithNotes notes='A basic example'>
      <Anchor
        dataNavDescription='m - 1'
        dataSlotPosition='header::2'
        url='//www.ulta.com/mhp'
        target={ BLANK }
        tabIndex={ 1 }
        ariaLabel='do not forget ADA compliance'
        clickHander={ 
          () => { 
            console.log('i was clicked');
          } 
          }
          analyticsEvent={ 
          { testing: 'now' } }
          title='more ada stuff '
        > 
          ANCHOR
      </Anchor> 

    </WithNotes>
  ) )
  .add( 'example of using target \'self\'', () => (
    <div>
        This is an example of an 
        <Anchor
          dataNavDescription='m - 1'
          dataSlotPosition='header::2'
          url='//www.ulta.com/mhp'
          target={ SELF }
          tabIndex={ 1 }
          ariaLabel='do not forget ADA compliance'
          clickHander={ 
            () => { 
              console.log('i was clicked');
            } 
          }
          analyticsEvent={ 
            { testing: 'now' } }
          title='more ada stuff '
        > 
          ANCHOR
        </Anchor> component and how it should render
      </div>
  ) )
