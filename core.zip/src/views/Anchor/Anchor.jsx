import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './Anchor.css';
import classNames from 'classnames';
import {
  host,
  fullyQualifyLink
} from '../../utils/formatters/formatters';
import { fireAnalyticsEvent } from '../../utils/omniture/omniture';
import { formatMessage } from '../Global/Global';
import messages from './Anchor.messages';

export const SELF = '_self';
export const BLANK = '_blank';
export const PARENT = '_parent';
export const TOP = '_top';

const propTypes = {
  dataNavDescription: PropTypes.string,
  dataSlotPosition: PropTypes.string,
  url: PropTypes.string,
  target: PropTypes.string,
  tabIndex: PropTypes.oneOfType( [
    PropTypes.string,
    PropTypes.number
  ] ),
  ariaLabel: PropTypes.string,
  clickHandler: PropTypes.func,
  analyticsEvent: PropTypes.object, // see SamplesList.jsx for data object implementation
  title: PropTypes.string,
  id: PropTypes.string,
  openWindowSpecs: PropTypes.object,
  displayType:PropTypes.oneOf( [
    'primary',
    'secondary'
  ] )
};

const defaultProps = {
  tabIndex: 0,
  target: SELF,
  displayType: 'primary'
}

export const handleClick = ( props, e ) => {
  if( props.clickHandler ){
    props.clickHandler( e );
  }
}

/**
 * creates an ADA specific TAG if the configured element is used to navigate to a new blank page
 * @param {string} targetType - A string that describes where a link should open
 */
export const renderADASRTag = ( targetType, message ) => {
  if( targetType.toLowerCase() === BLANK ){
    return (
      <span className='sr-only sr-only-focusable'>
        { message }
      </span>
    );
  }
  return '';
}

// Set href value to set javascript link output (window.open)
// Because when anchor tag has 'data-' attributes then target attribute are not working as expect [Browser issue]
// target _top or _blank is not opening in new window when 'data-' attribute, So adding (window.open) in href attribute
export const setHref = function( props, serverHost = host ){
  if( ( props.dataSlotPosition || props.dataNavDescription ) && ( props.target.toLowerCase() === TOP || props.target.toLowerCase() === BLANK ) ){
    // In IE browser, window.open is blocked by popup blocker and returns null & page is getting redirected to empty or null page.
    // void() tells IE that nothing is coming, so don't expect anything. Meanwhile the window.open will request for the permission & open in new window
    return `javascript: void( window.open( '${ fullyQualifyLink( serverHost, props.url ) }' ) );`;
  }

  return fullyQualifyLink( serverHost, props.url );
}

/**
 * ULTA ADA compliant Anchor element
 */
class Anchor extends Component{
  constructor( props ){
    super();

    this.openPopupWindow = this.openPopupWindow.bind( this );
    this.focus = this.focus.bind( this );
  }

  anchor = undefined;

  openPopupWindow( config ){
    const defaultConfig = {
      url: undefined,
      target: undefined,
      width: 500,
      height: 500,
      scrollbars: 'yes',
      status: 'no',
      toolbar: 'no',
      menubar: 'no',
      resizable: 'yes'
    }

    const options = {
      ...defaultConfig,
      ...config
    };

    const windowSpecs  = `width=${options.width},height=${options.height},scrollbars=${ options.scrollbars },status=${options.status},toolbar=${options.toolbar},menubar=${options.menubar},resizable=${options.resizable}`;

    window.open( options.url, options.target, windowSpecs );
  }

  focus(){
    this.anchor.focus();
  }

  render(){

    /**
     * Create a Anchor
     */
    let tabIndex = 0;

    const classes = this.props.className ? `Anchor ${this.props.className}` : 'Anchor';
    const {
      analyticsEvent,
      ariaLabel,
      target,
      dataNavDescription,
      dataSlotPosition,
      id,
      openWindowSpecs,
      dataUrl,
      dataText,
      dataVia,
      dataShowCount,
      displayType
    } = this.props;
    tabIndex = ( this.props.tabIndex ) ? this.props.tabIndex : tabIndex;

    return (
      <a
        className={ classNames( classes,
          {
            'Anchor__withDivider':  displayType === 'secondary'
          } ) }
        id={ id }
        { ...( this.props.url && { href:setHref( this.props ) } ) }
        target={ target }
        tabIndex={ tabIndex }
        { ...( ariaLabel && { 'aria-label': ariaLabel } ) }
        ref={ ( anchor ) =>{
          this.anchor = anchor;
        } }
        onFocus={ this.props.onFocus }
        onClick={
          ( e )=>{
            if( analyticsEvent !== undefined ){
              fireAnalyticsEvent( analyticsEvent.eventName, analyticsEvent.data );
            }
            if( this.props.url === '#' || this.props.clickHandler ){
              e.preventDefault();
            }
            if( openWindowSpecs !== undefined ){
              e.preventDefault();

              const popupSpecs = {
                ...openWindowSpecs,
                url: this.props.url,
                target: this.props.target
              };

              this.openPopupWindow( popupSpecs );
            }

            handleClick( this.props, e )
          }
        }
        title={ this.props.title }
        { ...( dataNavDescription && { ['data-nav-description']: dataNavDescription } ) }
        { ...( dataSlotPosition && { ['data-slot-position']: dataSlotPosition } ) }
        { ...( dataUrl && { 'data-url': dataUrl } ) }
        { ...( dataText && { 'data-text': dataText } ) }
        { ...( dataVia && { 'data-via': dataVia } ) }
        { ...( dataShowCount && { 'data-show-count': dataShowCount } ) }
        { ...( ariaLabel && { 'aria-label': ariaLabel } ) }
      >
        { renderADASRTag( target, formatMessage( messages.opensInNewWindow ) ) }
        { this.props.children }
      </a>
    )
  }

}


Anchor.propTypes = propTypes;
Anchor.defaultProps = defaultProps;

export default Anchor ;
