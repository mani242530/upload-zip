/*
 * HamburgerBtn Messages
 *
 * This contains all the text for the HamburgerBtn component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  opensInNewWindow: {
    id: 'i18n.Anchor.opensInNewWindow',
    defaultMessage: 'Opens in a new window'
  }
} );
