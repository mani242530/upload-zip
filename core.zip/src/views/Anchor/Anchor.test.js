import React from 'react';
import _ from 'lodash';
import Anchor, { renderADASRTag, setHref } from './Anchor';
import messages from './Anchor.messages';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<Anchor /> ', () => {
  it( 'renders without crashing', () => {
    const component = mountWithIntl( <Anchor url='http://www.ulta.com/gorgeoushair/' >Hello</Anchor> );
    expect( _.isUndefined( component.find( 'a' ) ) ).toBe( false );
  } );

  it( 'should wrap text child in a anchor', () => {
    let component = mountWithIntl( <Anchor url='http://www.ulta.com/gorgeoushair/' >Hello</Anchor> );

    expect( component.find( 'a' ).length ).toBe( 1 );
    expect( component.find( 'a' ).props().href ).toEqual( 'http://www.ulta.com/gorgeoushair/' );
    expect( component.find( 'a' ).text() ).toBe( 'Hello' );
  } );

  it( 'should wrap img in a anchor', () => {
    let component = mountWithIntl( <Anchor url='http://www.ulta.com/gorgeoushair/' ><img src='asdf' className='App-logo' alt='logo' /></Anchor> );

    expect( component.find( 'img' ).length ).toBe( 1 );
  } );

  it( 'should add .Anchor class when no className is sent as a prop', () => {
    let component = mountWithIntl( <Anchor url='http://www.ulta.com/gorgeoushair/' >Hello</Anchor> );
    expect( component.find( 'a' ).props().className ).toEqual( 'Anchor' );
  } );

  it( 'should add classNames to the .Anchor class when extra classNames are present', () => {
    let component = mountWithIntl( <Anchor className='hello again' url='http://www.ulta.com/gorgeoushair/' >Hello</Anchor> );
    expect( component.find( 'a' ).props().className ).toEqual( 'Anchor hello again' );
  } );

  it( 'should open anchor in new window when showInNewPage === true', () => {
    let component = mountWithIntl( <Anchor target='_blank' url='http://www.ulta.com/gorgeoushair/'>Hello</Anchor> );
    expect( component.find( 'a' ).props().target ).toEqual( '_blank' );
  } );

  it( 'should have id same as prop', () => {
    let component = mountWithIntl( <Anchor id='anchorLink' /> );
    expect( component.find( 'a' ).props().id ).toEqual( 'anchorLink' );
  } );

  it( 'should open anchor in same window when target is not defined', () => {
    let component = mountWithIntl( <Anchor url='http://www.ulta.com/craziness/'>Hello</Anchor> );
    expect( component.find( 'a' ).props().target ).toEqual( '_self' );
  } );
  describe( 'click events', () => {
    let handleClickHandler = jest.fn();
    beforeEach( () =>{
      handleClickHandler.mockClear();
    } )

    it( 'should call clickHandler if the clickhandlerProp is provided', () => {
      let component = mountWithIntl( <Anchor clickHandler={ handleClickHandler }>Hello</Anchor> ).find( 'Anchor' );
      component.simulate( 'click' )
      expect( handleClickHandler ).toBeCalled();
    } )

    it( 'should not call clickHandler if the clickhandlerProp is provided', () => {
      let component = mountWithIntl( <Anchor>Hello</Anchor> ).find( 'Anchor' );
      component.simulate( 'click' );
      expect( handleClickHandler ).not.toBeCalled();
    } )

    it( 'should open a popup window when an openWindowSpecs object is passed', () => {
      const props = {
        url: 'http://www.ulta.com/gorgeoushair/',
        target: '_blank',
        openWindowSpecs: {
          width: 500,
          height: 500
        }
      }
      let openPopupWindowMock = jest.fn();
      let component = mountWithIntl( <Anchor clickHandler={ openPopupWindowMock } { ...props } /> ).find( 'Anchor' );
      component.simulate( 'click' );
      expect( openPopupWindowMock ).toBeCalled();
    } );

    it( 'should render all the data attributes when props are passed to it', () => {
      const props = {
        dataNavDescription : 'test desc',
        dataSlotPosition:'test pos',
        dataUrl:'test url',
        dataText:'test text',
        dataVia:'test via',
        dataShowCount:'test show count'
      }
      let component = mountWithIntl( <Anchor { ...props } ></Anchor> );
      let el = component.find( 'a' );
      expect( el.props()['data-nav-description'] ).toBe( props.dataNavDescription );
      expect( el.props()['data-slot-position'] ).toBe( props.dataSlotPosition );
      expect( el.props()['data-url'] ).toBe( props.dataUrl );
      expect( el.props()['data-text'] ).toBe( props.dataText );
      expect( el.props()['data-via'] ).toBe( props.dataVia );
      expect( el.props()['data-show-count'] ).toBe( props.dataShowCount );
    } );

  } )

  describe( 'setHref function', () => {

    it( 'should return a javascript string value when dataSlotPosition or dataNavDescription are in the props AND the target is either _top or _blank', () => {
      let props = {
        url: 'www.reddit.com'
      };

      // testing with dataSlotPosition property
      props.dataSlotPosition = 'asdf';
      props.target = '_blank';
      let href = setHref( props, 'www.ulta.com' );
      expect( href ).toBe( `javascript: void( window.open( '//www.ulta.com/www.reddit.com' ) );` );

      // testing with dataNavDescription property
      delete props.dataSlotPosition;
      props.dataNavDescription = '1234';
      props.target = '_top';
      href = setHref( props, 'www.test.com' );
      expect( href ).toBe( `javascript: void( window.open( '//www.test.com/www.reddit.com' ) );` );

      // testing with a target of _self
      delete props.dataNavDescription;
      props.dataSlotPosition = '1234';
      props.target = '_self';
      href = setHref( props, 'www.amazing.com' );
      expect( href ).toBe( '//www.amazing.com/www.reddit.com' );

    } );

    it( 'should have a href value thats created by the setHref method', () => {
      let props = {
        target: '_blank',
        url: 'index.jsp'
      }

      // testing for a pure href vale (www.ulta.com/index.jsp)
      let component = mountWithIntl( <Anchor { ...props } >Hello</Anchor> ).find( 'Anchor' );

      expect( component.instance().anchor.href ).toBe( 'http://www.ulta.com/index.jsp' ) ;

      // testing for javascript link output (window.open)
      props.dataSlotPosition = '1234';
      component = mountWithIntl( <Anchor { ...props } >Hello</Anchor> ).find( 'Anchor' );
      expect( component.instance().anchor.href ).toBe( setHref( props ) ) ;

    } );

  } );


  describe( 'ADA compliance methods', () => {

    let component ;

    it( 'should have a default tabindex of 0 if one isn\'t passed as an attribute', () => {
      let component = mountWithIntl( <Anchor url='http://www.ulta.com/gorgeoushair/' >Hello</Anchor> );

      expect( component.props().tabIndex ).toEqual( 0 );
    } );


    it( 'should set the tab index to the user specificed value', () => {
      component = mountWithIntl( <Anchor url='http://www.ulta.com/gorgeoushair/' tabIndex={ 33 }>Hello</Anchor> );
      expect( component.props().tabIndex ).toEqual( 33 );
    } );


    it( 'renderADASRTag should return an empty string if it shouldn\'t render', () => {

      component = mountWithIntl(
        <Anchor
          url='www.ulta.com'
        />
      );
      let val = renderADASRTag( '_SELF' );
      expect( val ).toBe( '' );
    } );

    it( 'should render a messge of \'Opens in a new window\' with SR css classeswhen ADA should show', () => {
      component = mountWithIntl(
        <Anchor
          url='www.ulta.com'
          target='_BLANK'
        />
      );
      let i = component.find( 'a' );
      let adaTag = i.find( 'span' );
      expect( adaTag.props().className ).toBe( 'sr-only sr-only-focusable' );
      expect( adaTag.props().children ).toBe( messages.opensInNewWindow.defaultMessage );
    } );

    it( 'the component should have a reference to it child element', ()=> {
      component = mountWithIntl(
        <Anchor
          url='www.ulta.com'
          target='_BLANK'
        />
      );
      const focusMock = jest.fn();
      component.instance().anchor.focus = focusMock;
      component.instance().focus();
      expect( component.instance() ).toBeTruthy();
      expect( focusMock ).toBeCalled();
    } );
    it( 'should render divider below the anchor tag with Anchor__divider css when displayType flag is true', () => {

      component = mountWithIntl(
        <Anchor
          displayType='secondary'
        />
      );
      let anchorTag = component.find( 'a' );
      expect( anchorTag.props().className ).toBe( 'Anchor Anchor__withDivider' );
    } );
    it( 'shouldn\'t render divider below the anchor tag with Anchor__divider css when displayType flag is false', () => {

      component = mountWithIntl(
        <Anchor
          displayType='primary'
        />
      );
      let anchorTag = component.find( 'a' );
      expect( anchorTag.props().className ).not.toBe( 'Anchor Anchor__withDivider' );
    } );
  } );
  describe( 'on Focus events', () => {
    let onFocus = jest.fn();
    beforeEach( () =>{
      onFocus.mockClear();
    } )

    it( 'should call On Focus function if the onFocus property is provided', () => {
      let component = mountWithIntl( <Anchor onFocus={ onFocus }>Hello</Anchor> ).find( 'Anchor' );
      component.simulate( 'focus' )
      expect( onFocus ).toBeCalled();
    } )

    it( 'should not call On Focus function if the onFocus property is not provided', () => {
      let component = mountWithIntl( <Anchor>Hello</Anchor> ).find( 'Anchor' );
      component.simulate( 'focus' );
      expect( onFocus ).not.toBeCalled();
    } )

  } )
} );
