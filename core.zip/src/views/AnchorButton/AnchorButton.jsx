/**
 * AnchorButton
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Anchor from '../Anchor/Anchor';
import Button20 from '../Button20/Button20';
import './AnchorButton.css';


const propTypes = {
  // Anchor propTypes
  url: PropTypes.string,
  dataSlotPosition: PropTypes.string,
  anchorTarget: PropTypes.string,
  anchorTabIndex: PropTypes.oneOfType( [
    PropTypes.string,
    PropTypes.number
  ] ),
  anchorTitle: PropTypes.string,
  anchorId: PropTypes.string,
  openWindowSpecs: PropTypes.object,
  anchorDisplayType:PropTypes.oneOf( [
    'primary',
    'secondary'
  ] ),

  // Button20 propTypes
  btnStyle: PropTypes.oneOf( ['primary', 'secondary', 'tertiary', 'ghost', 'icon', 'link'] ),
  btnSize: PropTypes.oneOf( ['small', 'medium', 'large'] ),
  btnBlock: PropTypes.bool,
  btnDisabled: PropTypes.bool,
  btnTabIndex: PropTypes.number,
  btnId: PropTypes.string,
  dataNavDescription: PropTypes.string,
  analyticsEvent: PropTypes.object,
  ariaPressed: PropTypes.bool,
  ariaLabel: PropTypes.string,
  ariaSelected: PropTypes.bool,
  ariaControls: PropTypes.string,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func
}

const defaultProps = {
  anchorDisplayType: 'primary',
  btnDisabled: false,
  btnBlock: false
}


/**
 * Class
 * @extends React.Component
 */
class AnchorButton extends Component{

  /**
   * Renders the AnchorButton component
   */
  render(){

    return (
      <div className='AnchorButton'>
        <Button20
          { ...( this.props.btnStyle && { btnStyle: this.props.btnStyle } ) }
          { ...( this.props.btnSize && { size: this.props.btnSize } ) }
          { ...( this.props.btnBlock && { block: this.props.btnBlock } ) }
          { ...( this.props.btnDisabled && { disabled: this.props.btnDisabled } ) }
          { ...( this.props.btnTabIndex && { tabIndex: this.props.btnTabIndex } ) }
          { ...( this.props.btnId && { id: this.props.btnId } ) }
          { ...( this.props.dataNavDescription && { dataNavDescription: this.props.dataNavDescription } ) }
          { ...( this.props.analyticsEvent && { analyticsEvent : this.props.analyticsEvent } ) }
          { ...( this.props.ariaPressed && { ariaPressed : this.props.ariaPressed } ) }
          { ...( this.props.ariaLabel && { ariaLabel : this.props.ariaLabel } ) }
          { ...( this.props.ariaSelected && { ariaSelected: this.props.ariaSelected } ) }
          { ...( this.props.ariaControls && { ariaControls: this.props.ariaControls } ) }
          { ...( this.props.onFocus && { onFocus: this.props.onFocus } ) }
          { ...( this.props.onBlur && { onBlur: this.props.onBlur } ) }
        >
          <Anchor
            { ...( this.props.url && { url: this.props.url } ) }
            { ...( this.props.dataSlotPosition && { dataSlotPosition: this.props.dataSlotPosition } ) }
            { ...( this.props.anchorTarget && { target: this.props.anchorTarget } ) }
            { ...( this.props.anchorTabIndex && { tabIndex: this.props.anchorTabIndex } ) }
            { ...( this.props.anchorTitle && { title: this.props.anchorTitle } ) }
            { ...( this.props.anchorId && { id: this.props.anchorId } ) }
            { ...( this.props.openWindowSpecs && { openWindowSpecs: this.props.openWindowSpecs } ) }
            { ...( this.props.anchorDisplayType && { displayType: this.props.anchorDisplayType } ) }
          >
            { this.props.children }
          </Anchor>
        </Button20>
      </div>
    );
  }
}

AnchorButton.propTypes = propTypes;
AnchorButton.defaultProps = defaultProps;

export default AnchorButton;
