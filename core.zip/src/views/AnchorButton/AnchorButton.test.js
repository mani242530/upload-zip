import React from 'react';
import AnchorButton from './AnchorButton';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<AnchorButton /> ', () => {
  it( 'renders without crashing', () => {
    const component = mountWithIntl( <AnchorButton /> );

    expect( component.find( '.AnchorButton' ).length ).toBe( 1 );
    expect( component.find( '.AnchorButton Button20' ).length ).toBe( 1 );
    expect( component.find( '.AnchorButton Button20 Anchor' ).length ).toBe( 1 );
  } );

  it( 'should render button20 and its props', () => {
    const component = mountWithIntl(
      <AnchorButton
        btnStyle='secondary'
        btnSize='large'
        btnBlock={ true }
        btnDisabled={ true }
        btnTabIndex={ 1 }
        btnId='test id'
        dataNavDescription='test dataNavDescription'
        analyticsEvent={ {
          eventName: 'test eventName'
        } }
        ariaPressed={ false }
        ariaLabel='test ariaLabel'
        ariaSelected={ false }
        ariaControls='test ariaControls'
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().btnStyle ).toBe( 'secondary' );
    expect( component.find( '.AnchorButton Button20' ).props().size ).toBe( 'large' );
    expect( component.find( '.AnchorButton Button20' ).props().block ).toBe( true );
    expect( component.find( '.AnchorButton Button20' ).props().disabled ).toBe( true );
    expect( component.find( '.AnchorButton Button20' ).props().tabIndex ).toBe( 1 );
    expect( component.find( '.AnchorButton Button20' ).props().id ).toBe( 'test id' );
    expect( component.find( '.AnchorButton Button20' ).props().dataNavDescription ).toBe( 'test dataNavDescription' );
    expect( component.find( '.AnchorButton Button20' ).props().analyticsEvent ).toEqual( { eventName: 'test eventName' } );
    expect( component.find( '.AnchorButton Button20' ).props().ariaPressed ).toBeFalsy();
    expect( component.find( '.AnchorButton Button20' ).props().ariaLabel ).toBe( 'test ariaLabel' );
    expect( component.find( '.AnchorButton Button20' ).props().ariaSelected ).toBeFalsy();
    expect( component.find( '.AnchorButton Button20' ).props().ariaControls ).toBe( 'test ariaControls' );
  } );

  it( 'should have btnStyle as primary for Button20', () => {
    const component = mountWithIntl(
      <AnchorButton
        btnStyle='primary'
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().btnStyle ).toBe( 'primary' );
  } );

  it( 'should have btnStyle as tertiary for Button20', () => {
    const component = mountWithIntl(
      <AnchorButton
        btnStyle='tertiary'
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().btnStyle ).toBe( 'tertiary' );
  } );

  it( 'should have btnStyle as ghost for Button20', () => {
    const component = mountWithIntl(
      <AnchorButton
        btnStyle='ghost'
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().btnStyle ).toBe( 'ghost' );
  } );

  it( 'should have btnStyle as icon for Button20', () => {
    const component = mountWithIntl(
      <AnchorButton
        btnStyle='icon'
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().btnStyle ).toBe( 'icon' );
  } );

  it( 'should have btnStyle as link for Button20', () => {
    const component = mountWithIntl(
      <AnchorButton
        btnStyle='link'
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().btnStyle ).toBe( 'link' );
  } );

  it( 'should have btnSize as medium for Button20', () => {
    const component = mountWithIntl(
      <AnchorButton
        btnSize='medium'
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().size ).toBe( 'medium' );
  } );

  it( 'should have btnSize as small for Button20', () => {
    const component = mountWithIntl(
      <AnchorButton
        btnSize='small'
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().size ).toBe( 'small' );
  } );

  it( 'button20 should have block as false when btnBlock is false', () => {
    const component = mountWithIntl(
      <AnchorButton
        btnBlock={ false }
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().block ).toBeFalsy();
  } );

  it( 'button20 should have disabled as false when btnDisabled is false', () => {
    const component = mountWithIntl(
      <AnchorButton
        btnDisabled={ false }
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().disabled ).toBeFalsy();
  } );

  it( 'button20 should have ariaPressed as true when ariaPressed is true', () => {
    const component = mountWithIntl(
      <AnchorButton
        ariaPressed={ true }
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().ariaPressed ).toBe( true );
  } );

  it( 'button20 should have ariaSelected as true when ariaSelected is true', () => {
    const component = mountWithIntl(
      <AnchorButton
        ariaSelected={ true }
      />
    );

    expect( component.find( '.AnchorButton Button20' ).props().ariaSelected ).toBe( true );
  } );

  it( 'should render button20 wrapped inside anchor and its props', () => {
    const component = mountWithIntl(
      <AnchorButton
        url='/bag'
        dataSlotPosition='test dataSlotPosition'
        anchorTarget='_self'
        anchorTabIndex={ 4 }
        anchorTitle='test title'
        anchorId='test id'
        openWindowSpecs={ {
          'width':500, 'height': 680
        } }
        anchorDisplayType='secondary'
      />
    );

    expect( component.find( '.AnchorButton Button20 Anchor' ).props().url ).toBe( '/bag' );
    expect( component.find( '.AnchorButton Button20 Anchor' ).props().dataSlotPosition ).toBe( 'test dataSlotPosition' );
    expect( component.find( '.AnchorButton Button20 Anchor' ).props().target ).toBe( '_self' );
    expect( component.find( '.AnchorButton Button20 Anchor' ).props().tabIndex ).toBe( 4 );
    expect( component.find( '.AnchorButton Button20 Anchor' ).props().title ).toBe( 'test title' );
    expect( component.find( '.AnchorButton Button20 Anchor' ).props().id ).toBe( 'test id' );
    expect( component.find( '.AnchorButton Button20 Anchor' ).props().openWindowSpecs ).toEqual( { 'width':500, 'height': 680 } );
    expect( component.find( '.AnchorButton Button20 Anchor' ).props().displayType ).toBe( 'secondary' );
  } );

  it( 'anchor should have displayType as primary when anchorDisplayType is primary', () => {
    const component = mountWithIntl(
      <AnchorButton
        anchorDisplayType='primary'
      />
    );

    expect( component.find( '.AnchorButton Button20 Anchor' ).props().displayType ).toBe( 'primary' );
  } );
} );