/**
 * BaseLayout
 */

import React from 'react';
import PropTypes from 'prop-types';
import './BaseLayout.css';
import classNames from 'classnames';

const propTypes = {
  hasLeftNav: PropTypes.bool
}

const defaultProps = {
  hasLeftNav: true
}

const BaseLayout = ( props ) => {

  const {
    children,
    hasLeftNav
  } = props;

  return (
    <div className={
      classNames( 'BaseLayout',
        {
          'BaseLayout--hasLeftNav': hasLeftNav
        } )
    }
    >
      { children }
    </div>
  );

}

BaseLayout.propTypes = propTypes;
BaseLayout.defaultProps = defaultProps;

export default BaseLayout;
