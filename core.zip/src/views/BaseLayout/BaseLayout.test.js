import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, mount } from 'enzyme';
import BaseLayout from './BaseLayout';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<BaseLayout />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = shallow( <BaseLayout /> );
    expect( component.find( '.BaseLayout' ).length ).toBe( 1 );
  } );

  it( 'it should have hasLeftNav defaulted to true if that is not passed. ', () => {
    component = mount( <BaseLayout /> );
    expect( component.find( 'BaseLayout' ).props().hasLeftNav ).toEqual( true );
  } );

  it( 'should not have BaseLayout--hasLeftNav if hasLeftNav prop is false', () => {
    component = shallow( <BaseLayout hasLeftNav={ false } /> );
    expect( component.find( '.BaseLayout.BaseLayout--hasLeftNav' ).length ).toBe( 0 );
  } );

  it( 'renders different class depending on has leftNav prop', () => {
    component = shallow( <BaseLayout hasLeftNav={ true } /> );
    expect( component.find( '.BaseLayout.BaseLayout--hasLeftNav' ).length ).toBe( 1 );
  } );

} );
