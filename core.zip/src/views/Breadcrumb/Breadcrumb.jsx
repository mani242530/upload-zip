/**
 * Breadcrumb
 */

import React from 'react';
import './Breadcrumb.css';
import classNames from 'classnames';
import Divider from '../Divider/Divider';
import Anchor from '../Anchor/Anchor';
import messages from './Breadcrumb.messages';
import { formatMessage } from '../Global/Global';
import { createScriptTag } from '../../utils/third_party_scripts/third_party_scripts';
import {
  fullyQualifyLink,
  host
} from '../../utils/formatters/formatters';

const Breadcrumb = ( props ) => {
  let omnitureAttribute = undefined;

  const breadCrumbData = props.breadCrumbLinks.map( ( breadCrumb, index ) => {
    return (
      {
        '@type':'ListItem',
        'position':index + 1,
        'item': {
          '@id': breadCrumb.url ? fullyQualifyLink( host, breadCrumb.url ) : props.currentPageUrl,
          'name': breadCrumb.format ? formatMessage( messages[breadCrumb.name] ) : breadCrumb.name
        }
      }
    )
  } );

  const seoBreadcrumbData = {
    '@context': 'http://schema.org',
    '@type': 'BreadcrumbList',
    'itemListElement': breadCrumbData
  }

  return (
    <div className='Breadcrumb'>
      <script
        type='application/ld+json'
        dangerouslySetInnerHTML={ { __html:JSON.stringify( seoBreadcrumbData ) } }
      >
      </script>
      <ul>
        <li>
          { props.breadCrumbLinks.map( ( breadCrumb, index ) => {
            if( breadCrumb.url ){
              return (
                <Anchor
                  className='Tertiary'
                  url={ fullyQualifyLink( host, breadCrumb.url ) }
                  key={ index }
                  dataNavDescription={ breadCrumb.dataNavDescription }
                >
                  { breadCrumb.format ? formatMessage( messages[breadCrumb.name] ) : breadCrumb.name }
                </Anchor>
              );
            }
            else {
              return (
                <span
                  className='Breadcrumb__displayName'
                  key={ index }
                >
                  { breadCrumb.name }
                </span>
              )
            }
          } )
          }
        </li>
      </ul>
      <div className='Breadcrumb__divider' role='separator'>
        <Divider dividerType='gray' />
      </div>
    </div>
  );
}

export default Breadcrumb;
