/*
 * Breadcrumb Messages
 *
 * This contains all the text for the Breadcrumb component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  home: {
    id: 'i18n.Breadcrumb.home',
    defaultMessage: 'Home'
  }

} );