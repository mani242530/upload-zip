
import React from 'react';
import ReactDOM from 'react-dom';
import Breadcrumb from './Breadcrumb';
import Anchor from '../Anchor/Anchor';
import messages from './Breadcrumb.messages';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
import Divider from '../Divider/Divider';
import { createScriptTag } from '../../utils/third_party_scripts/third_party_scripts';
import { formatMessage } from '../Global/Global';
import {
  fullyQualifyLink,
  host
} from '../../utils/formatters/formatters';

jest.mock( './../../utils/third_party_scripts/third_party_scripts', () =>{
  return {
    createScriptTag: jest.fn()
  }
} );

describe( '<Breadcrumb />', () => {
  let component;
  let props = {
    productDisplayName: 'Nicole Nail Lacquer',
    breadCrumbLinks: [
      {
        url:'/',
        dataNavDescription:'bc - home',
        name:'home',
        format:true
      },
      {
        name: 'Nails',
        url: 'https://qa1.ulta.com/nails?N=271o',
        dataNavDescription:'bc - nails'
      },
      {
        name: 'Nicole Nail Lacquer',
        dataNavDescription:'bc - nails:nail polish'
      }
    ],
    currentPageUrl: 'https://qa1.ulta.com/grease-nail-lacquer-collection?productId=xlsImpprod18201073'
  }
  component = mountWithIntl(
    <Breadcrumb { ...props }/>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'Breadcrumb' ).length ).toBe( 1 );
  } );

  it( 'Should render a link', () => {
    expect( component.find( 'li' ).length ).toBe( 1 );
  } );

  it( 'Should render 2 anchors with proper values', () => {
    expect( component.find( 'a' ).length ).toBe( 2 );
    expect( component.find( 'a' ).at( 0 ).text() ).toBe( 'Home' );
    expect( component.find( 'a' ).at( 0 ).props().href ).toBe( '//www.ulta.com/' );
    expect( component.find( 'a' ).at( 1 ).text() ).toBe( 'Nails' );
    expect( component.find( 'a' ).at( 1 ).props().href ).toBe( 'https://qa1.ulta.com/nails?N=271o' );
  } );

  it( 'Should render proper dataNavDescription', () => {
    let firstDataNavDescription = `bc - ${ props.breadCrumbLinks[1].name.toLowerCase() }`
    expect( component.find( Anchor ).at( 0 ).props().dataNavDescription ).toBe( `bc - ${ props.breadCrumbLinks[0].name.toLowerCase() }` );
    expect( component.find( Anchor ).at( 1 ).props().dataNavDescription ).toBe( firstDataNavDescription );
  } );

  it( 'Should  render displayname of the product as Breadcrumb__displayName', () => {
    expect( component.find( '.Breadcrumb__displayName' ).text() ).toBe( props.productDisplayName );
  } );

  it( 'Should render a Divider', () => {
    expect( component.find( Divider ).length ).toBe( 1 );
  } );

  it( 'should insert script element with type SEO JSON+LD data', () => {
    const breadCrumbData = component.props().breadCrumbLinks.map( ( breadCrumb, index ) => {
      return (
        {
          '@type':'ListItem',
          'position':index + 1,
          'item': {
            '@id': breadCrumb.url ? fullyQualifyLink( host, breadCrumb.url ) : props.currentPageUrl,
            'name': breadCrumb.format ? formatMessage( messages[breadCrumb.name] ) : breadCrumb.name
          }
        }
      )
    } );
    const seoBreadcrumbData = {
      '@context': 'http://schema.org',
      '@type': 'BreadcrumbList',
      'itemListElement': breadCrumbData
    }
    expect( component.find( 'script' ).at( 0 ).props().type ).toBe( 'application/ld+json' );
    expect( component.find( 'script' ).at( 0 ).text() ).toBe( JSON.stringify( seoBreadcrumbData ) );
  } );

} );
