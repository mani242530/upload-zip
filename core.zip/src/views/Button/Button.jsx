/**
 * Button
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './Button.css';
import classNames from 'classnames';
import ChevronRightSVG from '../Icons/chevron_right';
import Loader from '../Loader/Loader';
import {
  host,
  fullyQualifyLink
} from '../../utils/formatters/formatters';
import { fireAnalyticsEvent } from '../../utils/omniture/omniture';


const propTypes = {
  showLoader: PropTypes.bool,
  inputTag: PropTypes.oneOf( ['a', 'button', 'input'] ),
  id: PropTypes.string,
  dataNavDescription: PropTypes.string,
  clickEventHandler: PropTypes.func,
  analyticsEvent: PropTypes.object, // see SamplesList.jsx for data object implementation
  componentMounted: PropTypes.func,
  btnType: PropTypes.oneOf( ['submit', 'button', 'reset'] ),
  btnOutLine: PropTypes.bool,
  btnOption: PropTypes.oneOf( ['default', 'block', 'primary', 'single', 'secondary', 'tertiary', 'success', 'info', 'warning', 'danger', 'link', 'no-style'] ),
  btnSize: PropTypes.oneOf( ['xs', 'sm', 'lg'] ),
  btnURL: PropTypes.string,
  btnColor: PropTypes.string,
  target: PropTypes.oneOf( ['_blank', '_self', '_top', '_parent'] ),
  textLink: PropTypes.string,
  tabIndex: PropTypes.number,
  btnBlock: PropTypes.bool,
  disabled: PropTypes.bool,
  ariaLabel: PropTypes.string,
  className: PropTypes.string
}

const defaultProps = {
  inputTag: 'button',
  className: undefined,
  btnOutLine: false,
  btnOption: 'default',
  btnSize: 'sm',
  btnColor: 'orangepop',
  showLoader: false,
  disabled: false
}



/**
 * Class
 * @extends React.Component
 */
class Button extends Component{

  constructor( props ){
    super();
    this.focus = this.focus.bind( this );
  }

  input = undefined;

  focus(){
    this.input.focus();
  }

  componentDidMount(){
    if( this.props.componentMounted ){
      this.props.componentMounted();
    }
  }


  /**
   * Renders the Button component
   */
  render(){
    const InputTag = this.props.inputTag;

    const {
      btnOption,
      btnOutLine,
      btnURL,
      btnSize,
      btnType,
      className,
      clickEventHandler,
      analyticsEvent,
      target,
      btnColor,
      inputTag,
      textLink,
      tabIndex,
      dataNavDescription,
      btnBlock,
      id,
      disabled,
      role,
      ariaSelected,
      ariaPressed,
      ariaControls,
      ariaLabel,
      onFocus,
      onBlur,
      onMouseDown
    } = this.props;

    let opts = {};
    if( btnType ){
      opts['type'] = btnType;
    }

    let defaultTarget = null;

    if( inputTag === 'a' ){
      defaultTarget = '_self'
    }

    return (
      <InputTag
        { ...( dataNavDescription && { ['data-nav-description']: dataNavDescription } ) }
        { ...( id && { id } ) }
        { ...( role && { role } ) }
        { ...( ariaSelected && { 'aria-selected' : ariaSelected } ) }
        { ...( ariaPressed && { 'aria-pressed' : ariaPressed === 'true' } ) }
        { ...( ariaControls && { 'aria-controls' : ariaControls } ) }
        { ...( ariaLabel && { 'aria-label' : ariaLabel } ) }
        { ...( onFocus && { onFocus } ) }
        { ...( onBlur && { onBlur } ) }
        { ...( disabled && { 'aria-hidden' :true } ) }
        className={
          classNames( {
            'butn': true,
            [`butn-${btnOption}`]: !btnOutLine,
            [`butn-outline-${btnOption}`]: btnOutLine,
            [`butn-${btnSize}`]: btnSize,
            [`${className}`]: className,
            'butn-block': btnBlock,
            'disabled': this.props.showLoader || disabled
          } )
        }
        { ...( btnURL && { href: fullyQualifyLink( host, btnURL ) } ) }
        tabIndex={ tabIndex }
        target={ target || defaultTarget }
        { ...( clickEventHandler && {
          onClick: ( e )=> {
            if( analyticsEvent !== undefined ){
              fireAnalyticsEvent( analyticsEvent.eventName, analyticsEvent.data );
            }
            if( clickEventHandler ){
              clickEventHandler( e );
            }
          }
        } ) }
        { ...( onMouseDown && {
          onMouseDown : ( e )=> {
            if( analyticsEvent !== undefined ){
              fireAnalyticsEvent( analyticsEvent.eventName, analyticsEvent.data );
            }
            if( onMouseDown ){
              onMouseDown( e );
            }
          }
        } ) }
        ref={ ( input ) => {
          this.input = input;
        } }
        disabled={ disabled }
        { ...opts }
      >
        { ( () => {

          if( btnOption === 'link' && this.props.children ){
            return (
              <span className={ `text-${ btnColor }` } >

                { this.props.children }
                <span
                  className={
                    classNames(
                      'Button__links__chevron-right', {
                        'small': btnSize === 'sm'
                      }
                    )
                  }
                >
                  <ChevronRightSVG />
                </span>
              </span>
            )
          }
          else if( this.props.children ){
            // show the loader if the flag is set to tru
            if( this.props.showLoader ){
              return <Loader loaderType='spinner'/>
            }
            else {
              return this.props.children
            }
          }

        } )() }

      </InputTag>
    );
  }
}

Button.propTypes = propTypes;
Button.defaultProps = defaultProps;

export default Button;
