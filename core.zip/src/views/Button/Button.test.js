import React from 'react';
import ReactDOM from 'react-dom';
import Button from './Button';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
import { fireAnalyticsEvent } from '../../utils/omniture/omniture';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';

jest.mock( './../../utils/omniture/omniture', () => {
  return {
    fireAnalyticsEvent: jest.fn(),
    updateDataLayer:jest.fn()
  }
} );

describe( '<Button />', () => {
  let component;

  it( 'renders the component as a type specified by the \'inputTYpe\' attribute', () => {
    component = mountWithIntl( <Button inputTag='a' /> );
    let el = component.find( 'Button' );
    expect( el.find( 'a' ).length ).toBe( 1 );
  } );

  it( 'should render all the aria attributes when props are passed to it', () => {
    const props = {
      inputTag : 'a',
      role:'tab',
      ariaSelected:'true',
      ariaControls:'testControl',
      ariaPressed:'true'
    }
    component = mountWithIntl( <Button { ...props } /> );
    let el = component.find( 'a' );
    expect( el.props()['aria-selected'] ).toBe( 'true' );
    expect( el.props()['aria-controls'] ).toBe( 'testControl' );
    expect( el.props()['role'] ).toBe( 'tab' );
    expect( el.props()['aria-pressed'] ).toBe( true );
  } );

  it( 'should not render the aria attributes when props are not passed to it', () => {
    const props = {
      inputTag : 'a'
    }
    component = mountWithIntl( <Button { ...props } /> );
    let el = component.find( 'a' );
    expect( el.props()['aria-selected'] ).toBeFalsy();
    expect( el.props()['aria-controls'] ).toBeFalsy();
    expect( el.props()['role'] ).toBeFalsy();
  } );

  it( 'renders the btnType  as the \'type\' attribute of the element', () => {
    component = mountWithIntl( <Button inputTag='a' btnType='submit' /> );
    let el = component.find( 'Button' );
    expect( el.find( 'a' ).props().type ).toEqual( 'submit' );
  } );


  it( 'renders the btnOption as one of the classNames for the component', () => {
    component = mountWithIntl( <Button inputTag='a' btnOption='success' /> );
    let el = component.find( 'Button' );
    let cname = el.find( 'a' ).props().className;

    expect( cname.includes( 'success' ) ).toBeTruthy();
  } );

  it( 'renders the btnSize as one of the classNames for the component', () => {
    component = mountWithIntl( <Button inputTag='a' btnSize='sm' /> );
    let el = component.find( 'Button' );
    let cname = el.find( 'a' ).props().className;

    expect( cname.includes( 'sm' ) ).toBeTruthy();
  } );

  it( 'renders the btnOption as one of the classNames with no-style for the component', () => {
    component = mountWithIntl( <Button inputTag='button' btnType='button' btnOption='no-style' /> );
    let el = component.find( 'Button' );
    let cname = el.find( 'button' ).props().className;

    expect( cname.includes( 'no-style' ) ).toBeTruthy();
  } );

  it( 'renders the aria-label for the given ariaLabel prop', () => {
    component = mountWithIntl( <Button inputTag='button' btnType='submit' ariaLabel='Search'/> );
    let el = component.find( 'Button' );
    expect( el.find( 'button' ).props()['aria-label'] ).toBe( 'Search' );
  } );

  it( 'should call the user provided clickEventHandler when it is passed', () => {
    var eHandle = jest.fn();
    component = mountWithIntl( <Button inputTag='a' clickEventHandler={ eHandle } /> );
    let el = component.find( 'Button' );
    el.simulate( 'click' );
    expect( eHandle ).toHaveBeenCalled();
  } );

  it( 'should call the user provided onMouseDown when it is passed', () => {
    var eHandle = jest.fn();
    const analyticsEvent = {
      eventName:'eventName',
      data:'eventData'
    }
    component = mountWithIntl( <Button inputTag='a' onMouseDown={ eHandle } analyticsEvent={ analyticsEvent } /> );
    let el = component.find( 'Button' );
    el.simulate( 'mouseDown' );
    expect( eHandle ).toHaveBeenCalled();
    expect( fireAnalyticsEvent ).toHaveBeenCalledWith( analyticsEvent.eventName, analyticsEvent.data );
  } );

  it( 'button should have a ref to its child input element', () => {
    component = mountWithIntl( <Button inputTag='a' /> );
    expect( component.find( 'Button' ).instance().input ).toBeTruthy();
  } );

  it( 'should invoke the focus method of the input child element', () => {
    const focusMock = jest.fn();
    component = mountWithIntl( <Button inputTag='a' /> );
    component.find( 'Button' ).instance().input.focus = focusMock;
    component.find( 'Button' ).instance().focus();
    expect( focusMock ).toBeCalled();
  } );

  it( 'should apply disabled styles to a disabled button', () => {
    component = mountWithIntl(
      <Button
        inputTag='button'
        disabled={ true }
      />
    );
    let className = component.find( 'button' ).props().className;
    expect( className ).toContain( 'disabled' );
  } );

  it( 'should not apply disabled styles to a non disabled button', () => {
    component = mountWithIntl(
      <Button
        inputTag='button'
        disabled={ false }
      />
    );
    let className = component.find( 'button' ).props().className;
    expect( className ).not.toContain( 'disabled' );
  } );

  it( 'should set aria attributes aria-hidden as true if disabled is true', () => {
    const props = {
      inputTag : 'a',
      role:'tab',
      disabled:true
    }
    component = mountWithIntl( <Button { ...props } /> );
    let el = component.find( 'a' );
    expect( el.props()['aria-hidden'] ).toBe( true );
  } );

  it( 'should not pass aria attribute aria-hidden, if disabled is false', () => {
    const props = {
      inputTag : 'a',
      role:'tab',
      disabled:false
    }
    component = mountWithIntl( <Button { ...props } /> );
    let el = component.find( 'a' );
    expect( el.props()['aria-hidden'] ).toBe( undefined );
  } );

  it( 'should call the eHandle on componentDidMount', () => {
    var eHandle = jest.fn();
    component = mountWithIntl( <Button type='submit' btnStyle='primary' size='small' componentMounted={ eHandle } /> );
    let instance = component.find( 'Button' ).instance();
    instance.componentDidMount();
    expect( eHandle ).toHaveBeenCalled( );
  } );

} );
