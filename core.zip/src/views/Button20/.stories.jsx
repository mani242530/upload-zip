import React from 'react';
import Button from './Button';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { WithNotes } from '@storybook/addon-notes';

storiesOf( 'Button', module )
  .add( 'All attributes', () => (
    <WithNotes notes='A basic example'>
      <Button>
        hello world
      </Button>

    </WithNotes>
  ) )