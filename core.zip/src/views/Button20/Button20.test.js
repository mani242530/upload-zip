import React from 'react';
import ReactDOM from 'react-dom';
import Button20 from './Button20';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';

describe( '<Button20 />', () => {
  let component;


  it( 'renders a button with the correct style and size', () => {
    const props = {
      btnStyle : 'primary',
      size : 'large'
    }
    component = mountWithIntl( <Button20 { ...props } /> );

    expect( component.find( 'button' ).hasClass( 'Button' ) ).toBeTruthy();
    expect( component.find( 'button' ).hasClass( 'Button__primary' ) ).toBeTruthy();
    expect( component.find( 'button' ).hasClass( 'Button--large' ) ).toBeTruthy();

  } )


  it( 'should render all the aria attributes when props are passed to it', () => {
    const props = {
      btnStyle : 'primary',
      size : 'large',
      ariaSelected: true,
      ariaControls:'testControl',
      ariaPressed: true
    }
    component = mountWithIntl( <Button20 { ...props } /> );
    let el = component.find( 'button' );

    expect( el.props()['aria-selected'] ).toBe( true );
    expect( el.props()['aria-controls'] ).toBe( 'testControl' );
    expect( el.props()['aria-pressed'] ).toBe( true );

  } );

  it( 'should not render the aria attributes when props are not passed to it', () => {
    const props = {
      btnStyle : 'primary',
      size : 'large'
    }
    component = mountWithIntl( <Button20 { ...props } /> );
    let el = component.find( 'button' );
    expect( el.props()['aria-selected'] ).toBeFalsy();
    expect( el.props()['aria-controls'] ).toBeFalsy();
  } );

  it( 'renders the btnType  as the \'type\' attribute of the element', () => {
    component = mountWithIntl( <Button20 type='submit' /> );
    expect( component.find( 'button' ).props().type ).toEqual( 'submit' );
  } );


  it( 'renders the btnOption as one of the classNames for the component', () => {
    component = mountWithIntl( <Button20 btnStyle='primary' /> );
    expect( component.find( 'button' ).props().className.includes( 'Button__primary' ) ).toBeTruthy();
  } );

  it( 'renders the btnSize as one of the classNames for the component', () => {
    component = mountWithIntl( <Button20 size='small' /> );
    expect( component.find( 'button' ).props().className.includes( 'Button--small' ) ).toBeTruthy();
  } );


  it( 'renders the aria-label for the given ariaLabel prop', () => {
    component = mountWithIntl( <Button20 type='submit' ariaLabel='Search'/> );
    expect( component.find( 'button' ).props()['aria-label'] ).toBe( 'Search' );
  } );

  it( 'should call the user provided clickEventHandler when it is passed', () => {
    var eHandle = jest.fn();
    component = mountWithIntl( <Button20 type='submit' btnStyle='primary' size='small' clickEventHandler={ eHandle } /> );
    let el = component.find( 'button' );
    el.simulate( 'click' );
    expect( eHandle ).toHaveBeenCalled();

  } );

  it( 'button should have a ref to its child input element', () => {
    component = mountWithIntl( <Button20 type='submit' btnStyle='primary' size='small' /> );
    expect( component.find( 'Button20' ).instance().input ).toBe( component.find( 'button' ).instance() );
  } );

  it( 'should invoke the focus method of the input child element', () => {
    const focusMock = jest.fn();
    component = mountWithIntl( <Button20 type='button' btnStyle='primary' size='small' /> );
    component.find( 'Button20' ).instance().input.focus = focusMock;
    component.find( 'Button20' ).instance().focus();
    expect( focusMock ).toBeCalled();
  } );

  it( 'should call the eHandle on componentDidMount', () => {
    var eHandle = jest.fn();
    component = mountWithIntl( <Button20 type='submit' btnStyle='primary' size='small' componentMountedHandler={ eHandle } /> );
    let instance = component.find( 'Button20' ).instance();
    instance.componentDidMount();
    expect( eHandle ).toHaveBeenCalled( );
  } );

  it( 'button should render children elements', () => {
    component = mountWithIntl( <Button20 type='submit' btnStyle='primary' size='small'>sign in</Button20> );
    expect( component.find( 'button' ).props().children[1] ).toBe( 'sign in' );
  } );

  it( 'button should render loader children elements when showLoader is true', () => {
    let componenty = mountWithIntl( <Button20 type='submit' btnStyle='primary' showLoader={ true } /> );
    expect( componenty.find( 'Loader' ).length ).toBe( 1 );
  } );

  it( 'button should not render button text when showLoader is true', () => {
    let componenty = mountWithIntl( <Button20 type='submit' btnStyle='primary' showLoader={ true }>sign in</Button20> );
    expect( componenty.find( 'button' ).props().children[1] ).toBeFalsy();
  } );

  it( 'should render a button with the correct icon style', () => {
    const props = {
      btnStyle : 'icon'
    }
    component = mountWithIntl( <Button20 { ...props } /> );

    expect( component.find( 'button' ).hasClass( 'Button' ) ).toBeTruthy();
    expect( component.find( 'button' ).hasClass( 'Button__icon' ) ).toBeTruthy();

  } )
  it( 'should render a button with the correct link style', () => {
    const props = {
      btnStyle : 'link'
    }
    component = mountWithIntl( <Button20 { ...props } /> );

    expect( component.find( 'button' ).hasClass( 'Button' ) ).toBeTruthy();
    expect( component.find( 'button' ).hasClass( 'Button__link' ) ).toBeTruthy();

  } )
  it( 'should render a disabled button', () => {

    const props = {
      disabled : true
    }
    component = mountWithIntl( <Button20 { ...props } /> );
    expect( component.find( 'button' ).props().disabled ).toBe( true );


  } )

  it( 'should render button with sr-only classname if srOnly is true', () => {
    const props = {
      srOnly : true
    }
    const component = mountWithIntl( <Button20 { ...props } /> );
    expect( component.find( 'button' ).hasClass( 'sr-only' ) ).toBeTruthy();
  } );

  it( 'should not render button with sr-only classname if srOnly is false', () => {
    const props = {
      srOnly : false
    }
    const component = mountWithIntl( <Button20 { ...props } /> );
    expect( component.find( 'button' ).hasClass( 'sr-only' ) ).toBeFalsy();
  } )
} );
