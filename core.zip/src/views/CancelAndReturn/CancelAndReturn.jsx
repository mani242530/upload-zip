/**
 * CancelAndReturn
 */

import React from 'react';
import PropTypes from 'prop-types';
import './CancelAndReturn.css';

import { formatMessage } from '../Global/Global';
import Anchor from '../Anchor/Anchor';
import ChevronLeftSVG from '../Icons/chevronleft';
import {
  host,
  fullyQualifyLink
} from '../../utils/formatters/formatters';

const propTypes = {
  cancelSteps: PropTypes.number,
  history: PropTypes.object.isRequired,
  cancelText: PropTypes.string.isRequired
}


export const goBack = ( props ) => {
  if( document.referrer.indexOf( '/' ) >= 0 ){
    props.history.go( props.cancelSteps );
  }
  else {
    global.location.assign( fullyQualifyLink( host, '/' ) );
  }
}

export const CancelAndReturn = function( goBack ){
  return (
    ( props ) => {
      /**
       * Renders the CancelAndReturn component
       */
      return (
        <div className='CancelAndReturn'>
          <Anchor
            clickHandler={ () => goBack( props ) }
          >
            <div className='CancelAndReturn CancelAndReturn--chevronImg'>
              <ChevronLeftSVG />
              <span className='CancelAndReturn CancelAndReturn--cancelText'>{ props.cancelText }</span>
            </div>
          </Anchor>
        </div>
      );
    }
  )
}
CancelAndReturn.propTypes = propTypes;


export const CancelAndReturnComponent = ( goBack ) => {
  return CancelAndReturn( goBack );
};
export default CancelAndReturnComponent( goBack );
