import React from 'react';
import ReactDOM from 'react-dom';
import CancelAndReturn, { goBack, CancelAndReturnComponent } from './CancelAndReturn';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
import {
  host,
  fullyQualifyLink
} from '../../utils/formatters/formatters';

describe( '<CancelAndReturn />', () => {

  beforeEach( () => {
    global.location.assign = jest.fn();
  } );
  let component;
  component = mountWithIntl( <CancelAndReturn history={ {} } cancelText='' /> );

  it( 'renders without crashing', () => {
    expect( component.find( '.CancelAndReturn Anchor' ).length ).toBe( 1 );
  } );

  it( 'should render cancel and return component with a chevornLeftSvg', () => {
    expect( component.find( '.CancelAndReturn.CancelAndReturn--chevronImg' ).length ).toBe( 1 );
  } );

  it( 'should render cancel and return component with a Anchor component', () => {
    expect( component.find( 'Anchor' ).length ).toBe( 1 );
  } );

  it( 'should render cancel and return component with a chevornLeftSvg component', () => {
    expect( component.find( 'svg' ).length ).toBe( 1 );
  } );

  it( 'should render cancel and return component with a clickHandler', () => {
    expect( component.find( 'Anchor' ).length ).toBe( 1 );
  } );

  it( 'should change window.location.href if the go back is out of ulta domain', () => {
    component.find( 'Anchor' ).simulate( 'click' );
    expect( global.location.assign ).toHaveBeenCalledWith( fullyQualifyLink( 'www.ulta.com', '/' ) );
  } );

  it( 'should invoke the goBack function on click of the anchor', () => {
    let history = {
      location : {
        pathname : '/checkout'
      },
      go: jest.fn(),
      replace:jest.fn()
    }
    Object.defineProperty( document, 'referrer', {
      value: '/creditcards'
    } );
    let goBackMock = jest.fn();
    let CancelAndReturnMock = CancelAndReturnComponent( goBackMock )
    let component4 = mountWithIntl( <CancelAndReturnMock history={ history } cancelText='Test Name' /> );
    component4.find( 'Anchor' ).simulate( 'click' );
    expect( goBackMock ).toBeCalled();
  } );

  it( 'should goBack number of steps mentioned when we click on cancel within ulta domain', () => {
    Object.defineProperty( document, 'referrer', {
      value: '/creditcards'
    } );
    let history = {
      location : {
        pathname : '/checkout'
      },
      go: jest.fn(),
      replace:jest.fn()
    }
    let component2 = mountWithIntl( <CancelAndReturn history={ history } cancelText='Test Name' cancelSteps={ 2 }/> );
    component2.find( 'Anchor' ).simulate( 'click' );
    expect( history.go ).toBeCalled();
    expect( history.go ).toBeCalledWith( 2 );
  } );

  it( 'should render cancel and return component with a Test Name as the text for the button', () => {
    let component1 = mountWithIntl( <CancelAndReturn history={ {} } cancelText='Test Name' /> );
    expect( component1.find( 'Anchor' ).at( 0 ).props().children.props.children[1].props.children ).toBe( 'Test Name' );
  } );
} );
