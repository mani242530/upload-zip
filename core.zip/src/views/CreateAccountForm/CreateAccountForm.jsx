/**
 * CreateAccountForm
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import './CreateAccountForm.css';

import isUndefined from 'lodash/isUndefined';
import VMasker from 'vanilla-masker';
import InputField from '../InputField/InputField';
import ToggleButton from '../ToggleButton/ToggleButton';
import Button from '../Button/Button';
import {
  validate as validationMethod,
  validationKeys
} from '../../utils/form_validations/form_validations';
import FormValidationMessages from '../../utils/form_validations/form_validations.messages';
import {
  removeSpecialCharacters
} from '../../utils/formatters/formatters';
import { formatMessage } from '../Global/Global';
import ResponseMessages from '../ResponseMessages/ResponseMessages';
import {
  getActionDefinition
} from '../../events/services/services.events';

import {
  removeValidationMessages
} from '../../events/forms/forms.events';

import { scrollWindowToPosition } from '../../utils/animation/animation';
import messages from './CreateAccountForm.messages';

const propTypes = {
  successPath: PropTypes.string,
  title: PropTypes.string,
  formMessage: PropTypes.string,
  messageBeans: PropTypes.array,
  scrollElementSelector: PropTypes.string,
  buttonText: PropTypes.string,
  useRouter: PropTypes.bool, // used if needs to go to a different page with using router
  userData: PropTypes.object,
  defaultEmail: PropTypes.string,
  sourcePage: PropTypes.string,
  analyticsSourcePage: PropTypes.string
}

const defaultProps = {
  successPath: '/',
  useRouter: true,
  defaultEmail: null,
  analyticsSourcePage:''
}

const validationTriggerForEmailField = ( val ) => {
  return validationMethod( val, [validationKeys.required, validationKeys.validateEmail], [FormValidationMessages.required, FormValidationMessages.invalidEmail] );
}

const validationTriggerForPasswordField = ( val ) => {
  return validationMethod( val, [validationKeys.required, validationKeys.passwordLength], [FormValidationMessages.required, FormValidationMessages.passwordLength] );
}

const validationTriggerForPasswordMatchField = ( val ) => {
  return validationMethod( val, validationKeys.required, FormValidationMessages.required );
}

const warnMessageForPassword = ( val ) => {
  return validationMethod( val, validationKeys.showWarningMessage, messages.passwordWarning );
}

const warnMessageForPasswordMatch = ( val ) => {
  return validationMethod( val, validationKeys.showWarningMessage, messages.passwordMatchWarning );
}
/**
 * Class
 * @extends React.Component
 */
class CreateAccountForm extends Component{

  /**
   * Create a CreateAccountForm
   */
  constructor( props ){
    super( props );
    this.createAccount = this.createAccount.bind( this );


  }

  createAccount( values ){
    let uData = values;
    // function to make service call to create account
    this.props.removeValidationMessages();
    if( this.props.userData ){
      uData.firstName = this.props.userData.firstName;
      uData.lastName = this.props.userData.lastName;
      uData.address1 = this.props.userData.address1;
      uData.address2 = this.props.userData.address2;
      uData.city = this.props.userData.city;
      uData.state = this.props.userData.state;
      uData.dateOfBirth = this.props.userData.dateOfBirth;
      uData.postalCode = this.props.userData.postalCode;
      uData.phoneNumber = VMasker.toPattern( removeSpecialCharacters( this.props.userData.phoneNumber ), '999-999-9999' );
    }
    uData.sourcePage = this.props.sourcePage;
    const Data = {
      values: uData,
      history: this.props.history,
      paths:{
        successPath: this.props.successPath
      },
      useRouter: this.props.useRouter,
      analyticsSourcePage: this.props.analyticsSourcePage
    }
    this.props.submitCreateAccount( Data );
  }

  componentDidUpdate( prevProps ){

    // to bring errors into focus
    if( this.props.messageBeans && isUndefined( prevProps.messageBeans ) ){
      const scrollElemPos = document.getElementById( this.props.scrollElementSelector );
      if( scrollElemPos ){
        scrollWindowToPosition( scrollElemPos.offsetTop, 'easeInOutQuint' );
      }
      this.props.change( 'password', '' );
      this.props.change( 'passwordMatch', '' );
    }
  }

  /**
   * Renders the CreateAccountForm component
   */
  render(){

    const {
      messageBeans,
      handleSubmit
    } = this.props;


    return (
      <div className='CreateAccountForm'>
        { ( () => {
          if( messageBeans ){
            return (
              <div className='CreateAccountForm__errors'>
                { messageBeans.map( ( message, index ) => {
                  return (
                    <ResponseMessages
                      key={ index }
                      message={ message.messageDesc }
                    />
                  )
                } ) }
              </div>
            )
          }
        } )() }
        <form onSubmit={ this.props.handleSubmit( this.createAccount ) }>
          <div className='CreateAccountForm__userName'>
            <InputField
              tabIndex={ 1 }
              name='emailOrUsername'
              type='text'
              label={ formatMessage( messages.emailOrUsername ) }
              validate={ validationTriggerForEmailField }
              value={ this.props.defaultEmail }
            />
          </div>
          <div className='CreateAccountForm__CreatePassword'>
            <InputField
              tabIndex={ 2 }
              name='password'
              type='password'
              label={ formatMessage( messages.createPassword ) }
              validate={ validationTriggerForPasswordField }
              warn={ [warnMessageForPassword] }
              clearFields={ ['password', 'passwordMatch'] }
              maskedToggleTarget='password'
              showMaskedValue={ this.props.formConfig.fieldShowHideToggleData.password }
            />
          </div>
          <div className='CreateAccountForm__ConfirmPassword'>
            <InputField
              tabIndex={ 3 }
              name='passwordMatch'
              type='password'
              label={ formatMessage( messages.confirmPassword ) }
              validate={ validationTriggerForPasswordMatchField }
              warn={ [warnMessageForPasswordMatch] }
              maskedToggleTarget='password'
              showMaskedValue={ this.props.formConfig.fieldShowHideToggleData.password }
            />
          </div>
          <div className='CreateAccountForm__Subscribe'>
            <ToggleButton
              name='subscribeForEmail'
              label={ formatMessage( messages.subscribeText ) }
              tabIndex={ 4 }
              isChecked={ this.props.formData?.values?.subscribeForEmail ?? false }
            />
          </div>
          <div className='CreateAccountForm__Submit'>

            <Button
              inputTag='button'
              btnType='submit'
              btnSize='lg'
              btnOption='single'
              btnOutLine={ false }
              tabIndex={ 5 }
              btnBlock={ true }
              onClick={ () => {
              } }
            >
              { this.props.buttonText }
            </Button>
          </div>
        </form>
      </div>
    );
  }
}

CreateAccountForm.propTypes = propTypes;
CreateAccountForm.defaultProps = defaultProps;

export const mapStateToProps = ( state ) => {
  return {
    formConfig: state.pagedata.formConfig,
    formData: state.form.createAccount,
    messageBeans: state.user.messageBeans
  }
}

export const mapDispatchToProps = dispatch => {
  return {
    submitCreateAccount : data => {
      dispatch( getActionDefinition( 'createAccount', 'requested' )( data ) );
    },

    removeValidationMessages: () => {
      dispatch( removeValidationMessages() )
    }
  }
}

export const onSubmitFail = ( errors, dispatch ) => {

}

export const validate = ( values, props ) => {
  const errors = {};

  errors.passwordMatch = validationMethod( [values.password, values.passwordMatch], validationKeys.shouldMatch, FormValidationMessages.passwordsDoNotMatch );
  return errors;
}

export const initialFormData = {
  subscribeForEmail: true
}


export const connectFunction = ( mapStateToProps, mapDispatchToProps, submitFail, validateArg, initialValuesArg ) => {
  return reduxForm( {
    form: 'createAccount',
    initialValues: initialValuesArg,
    onSubmitFail: submitFail,
    validate: validateArg
  } )( connect( mapStateToProps, mapDispatchToProps )( CreateAccountForm ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps, onSubmitFail, validate, initialFormData );
