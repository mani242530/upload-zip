/*
 * CreateAccountForm Messages
 *
 * This contains all the text for the CreateAccountForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.CreateAccountForm.header',
    defaultMessage: 'This is the CreateAccountForm component !'
  },
  emailOrUsername: {
    id: 'i18n.CreateAccountForm.emailOrUsername',
    defaultMessage: 'Email Address or Username'
  },
  createPassword: {
    id: 'i18n.CreateAccountForm.createPassword',
    defaultMessage: 'Create Password'
  },
  confirmPassword: {
    id: 'i18n.CreateAccountForm.confirmPassword',
    defaultMessage: 'Confirm Password'
  },
  subscribeText: {
    id: 'i18n.CreateAccountForm.subscribeText',
    defaultMessage: 'Subscribe to emails about sales, new arrivals & special offers'
  },
  passwordWarning: {
    id: 'i18n.CreateAccountForm.passwordWarning',
    defaultMessage: 'Minimum of 8 characters and must include an upper case, lower case, number and special character'
  },
  passwordMatchWarning: {
    id: 'i18n.CreateAccountForm.passwordMatchWarning',
    defaultMessage: 'Please re-enter your password'
  }

} );
