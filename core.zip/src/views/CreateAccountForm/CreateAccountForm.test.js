import React from 'react';
import { Provider } from 'react-redux';
import { reduxForm } from 'redux-form';
import CreateAccountForm, { connectFunction, mapStateToProps, mapDispatchToProps } from './CreateAccountForm';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';


import {
  removeValidationMessages
} from '../../events/forms/forms.events';

import {
  registerServiceName,
  getActionDefinition
} from '../../events/services/services.events';

describe( '<CreateAccountForm />', () => {
  registerServiceName( 'createAccount' );
  let component;
  let props = {};
  props.buttonText = 'Create Account';
  const store = configureStore( );
  const Decorator = reduxForm( {
    form: 'createAccount',
    initialValues: {
      subscribeForEmail: false
    },
    onSubmitFail:jest.fn(),
    validate:jest.fn()
  } )( CreateAccountForm );

  component = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props }/>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'CreateAccountForm' ).length ).toBe( 1 );
  } );
  it( 'renders ResponseMessages component when the service returns any errors', () => {
    let props = {};
    store.getState().user.messageBeans = [{
      'messageKey': 'validateFormDataError',
      'messageDesc': 'Please enter a valid SSN'
    }]
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <Decorator { ...props }/>
      </Provider>
    );
    expect( component1.find( 'ResponseMessages' ).length ).toBe( 1 );
  } );

  it( 'should have ToggleButton', () => {
    expect( component.find( 'ToggleButton' ).length ).toBe( 1 );
  } );

  it( 'should have ToggleButton which is initially set to false', () => {
    expect( component.find( 'ToggleButton' ).at( 0 ).props().isChecked ).toBe( false );
  } );

  it( 'should render input field component', () => {
    expect( component.find( 'InputField' ).length ).toBe( 3 );
  } );

  it( 'should render input field component with name emailoruserName', () => {
    expect( component.find( 'InputField' ).at( 0 ).props().name ).toBe( 'emailOrUsername' );
  } );

  it( 'should render input field component with name password', () => {
    expect( component.find( 'InputField' ).at( 1 ).props().name ).toBe( 'password' );
  } );

  it( 'should render input field component with name passwordMatch', () => {
    expect( component.find( 'InputField' ).at( 2 ).props().name ).toBe( 'passwordMatch' );
  } );

  it( 'should render one button', () => {
    expect( component.find( 'Button' ).length ).toBe( 1 );
  } );

  it( 'should render one button with text Create Account', () => {
    expect( component.find( 'Button' ).at( 0 ).props().children ).toBe( 'Create Account' );
  } );

  const submitCreateAccountMock = jest.fn();

  let mapDispatchToPropsMock = ( dispatch ) =>{
    return {
      submitCreateAccount: submitCreateAccountMock,
      removeValidationMessages: jest.fn()
    }
  }
  const onSubmitFailMock = jest.fn();
  const validateMock = jest.fn();
  const initialFormData = {
    subscribeForEmail: true,
    emailOrUsername: 'test@test.com',
    password: 'password',
    passwordMatch: 'password'
  };

  const handleSubmitMock = jest.fn();

  let CreateAccountFormMock = connectFunction( mapStateToProps, mapDispatchToPropsMock, onSubmitFailMock, validateMock, initialFormData );

  let component2 = mountWithIntl(
    <Provider store={ store }>
      <CreateAccountFormMock { ...props } />
    </Provider>
  );

  const createAccountMock = jest.fn();

  it( 'should invoke submitCreateAccount Method on click of button', () => {

    var CreateAccountFormWrapper = component2.find( 'CreateAccountForm' ).instance();

    CreateAccountFormWrapper.createAccount = createAccountMock;

    component2.find( 'form' ).simulate( 'submit', createAccountMock( CreateAccountFormWrapper.props.initialValues ) );

    expect( createAccountMock ).toHaveBeenCalled();

  } );

  it( 'should call the submitCreateAccount function', () => {

    let component1 = mountWithIntl(
      <Provider store={ store }>
        <CreateAccountFormMock { ...props } />
      </Provider>
    );

    var CreateAccountFormWrapper = component1.find( 'CreateAccountForm' ).instance();

    CreateAccountFormWrapper.createAccount( CreateAccountFormWrapper.props.formData.initial );

    expect( submitCreateAccountMock ).toHaveBeenCalled();
  } )

} );


describe( '<CreateAccountForm />', () => {
  let dispatch = jest.fn();

  beforeEach( () => {
    dispatch.mockClear();
  } );

  let dispatchprops = mapDispatchToProps( dispatch );

  it( 'should dispatch proper action for removeValidationMessages', () => {
    let func = dispatchprops.removeValidationMessages();
    expect( dispatch ).toHaveBeenCalledWith( removeValidationMessages() );
  } );

  it( 'should dispatch proper action for submitCreateAccount', () => {
    let data = {
      name: 'xyz',
      email: 'xyz@ulta.com'
    }
    let func = dispatchprops.submitCreateAccount( data );
    expect( dispatch ).toHaveBeenCalledWith( getActionDefinition( 'createAccount', 'requested' )( data ) );
  } );

} );

describe( 'check for the componentDidUpdate method', () => {
  const store = configureStore( );
  const Decorator = reduxForm( {
    form: 'createAccount',
    initialValues: {
      subscribeForEmail: false,
      password: '1234',
      passwordMatch: '123'
    },
    onSubmitFail:jest.fn(),
    validate:jest.fn()
  } )( CreateAccountForm );
  let props = {};
  let props1 = {};
  props1.messageBeans = [{
    'messageKey': 'validateFormDataError',
    'messageDesc': 'Please enter a valid SSN'
  }]
  let component3 = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props }/>
    </Provider>
  );
  it( 'clears the password and passwordMatch fileds', ( ) => {
    let comp = mountWithIntl(
      <Provider store={ store }>
        <Decorator { ...props1 }/>
      </Provider>
    );
    comp.update();
    expect( comp.find( 'InputField' ).at( 2 ).prop( 'value' ) ).toBe( undefined );
  } );

} );

describe( '<CreateAccountForm />', () => {
  let component;
  let props = {
    formData:{
      values:{
        subscribeForEmail: false
      }
    },
    userData: {
      firstName: 'Pushpendra',
      lastName: 'Kabdaula',
      address1: '1000 remngton blvd',
      address2: 'Suite # 120',
      city: 'Bolingbrook',
      state: 'IL',
      dateOfBirth: '04/04/1984',
      postalCode: '60564',
      phoneNumber: '(510)-213-8347'
    },
    intl: {
      formatMessage: 'dsghvokm'
    }
  }
  const store = configureStore( );
  const Decorator = reduxForm( {
    form: 'createAccount',
    initialValues: {
      subscribeForEmail: false
    },
    onSubmitSuccess:jest.fn(),
    onSubmitFail:jest.fn(),
    validate:jest.fn()
  } )( CreateAccountForm );
  component = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props } />
    </Provider>
  );

  it( 'should render toggle button component when CreateAccountForm Subscribe is true', () => {
    const props2 = {
      formData: {
        values: {
          subscribeForEmail : true
        }
      }
    }
    let component = mountCreateAccountForm( props );
    expect( component.find( '.CreateAccountForm__Subscribe' ).length ).toBe( 1 );
    expect( component.find( '.CreateAccountForm__Subscribe ToggleButton' ).length ).toBe( 1 );
  } );

  it( 'should check whether userData is present', () => {
    const component2 = mountCreateAccountForm( props );
    const node2 = component2.find( 'CreateAccountForm' );
    const values = {
      firstName: '',
      lastName: '',
      address1: '',
      address2: '',
      city: '',
      state: '',
      dateOfBirth: '',
      postalCode: '',
      phoneNumber: ''
    }
    const instance = node2.instance();
    instance.createAccount( values );
    expect( node2.at( 0 ).props().userData.firstName ).toEqual( 'Pushpendra' );
    expect( node2.at( 0 ).props().userData.lastName ).toEqual( 'Kabdaula' );
    expect( node2.at( 0 ).props().userData.address1 ).toEqual( '1000 remngton blvd' );
    expect( node2.at( 0 ).props().userData.address2 ).toEqual( 'Suite # 120' );
    expect( node2.at( 0 ).props().userData.city ).toEqual( 'Bolingbrook' );
    expect( node2.at( 0 ).props().userData.state ).toEqual( 'IL' );
    expect( node2.at( 0 ).props().userData.dateOfBirth ).toEqual( '04/04/1984' );
    expect( node2.at( 0 ).props().userData.postalCode ).toEqual( '60564' );
    expect( node2.at( 0 ).props().userData.phoneNumber ).toEqual( '(510)-213-8347' );
  } );

} );

function mountCreateAccountForm( props ){
  const store = configureStore( );
  return mountWithIntl(
    <Provider store={ store }>
      <CreateAccountForm
        { ...props }
      />
    </Provider>
  );
}
