import React from 'react';
import AmexSVG from '../Icons/americanexpress';
import DiscoverSVG from '../Icons/discover';
import MasterCardSVG from '../Icons/mastercard';
import VisaSVG from '../Icons/visa';
import URCCSVG from '../Icons/ultamaterewardscreditcard';
import URMCSVG from '../Icons/ultamaterewardsmastercard';
import DefaultCreditCard from '../Icons/creditcarddefault';

const CreditCardIcon = ( props ) => {

  const {
    creditCardType
  } = props;
  let creditCardIcon;

  let creditCardTypeLower = creditCardType.toLowerCase();

  if( creditCardTypeLower === 'visa' ){
    creditCardIcon = <VisaSVG/>
  }
  else if( creditCardTypeLower === 'mastercard' ){
    creditCardIcon = <MasterCardSVG/>
  }
  else if( creditCardTypeLower === 'discover' ){
    creditCardIcon = <DiscoverSVG/>
  }
  else if( creditCardTypeLower === 'americanexpress' ){
    creditCardIcon = <AmexSVG/>
  }
  else if( creditCardTypeLower === 'ultamate rewards mastercard' ){
    creditCardIcon = <URMCSVG/>
  }
  else if( creditCardTypeLower === 'ultamate rewards credit card' ){
    creditCardIcon = <URCCSVG/>
  }
  else if( creditCardTypeLower === 'defaultcreditcard' ){
    return ( <DefaultCreditCard/> );
  }

  return creditCardIcon;

}

export default CreditCardIcon;