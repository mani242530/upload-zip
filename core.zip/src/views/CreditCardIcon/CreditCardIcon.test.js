import React from 'react';
import ReactDOM from 'react-dom';
import CreditCardIcon from './CreditCardIcon';
import VisaSVG from '../Icons/visa';
import MasterCardSVG from '../Icons/mastercard';
import DiscoverSVG from '../Icons/discover';
import AmexSVG from '../Icons/americanexpress';
import URMCSVG from '../Icons/ultamaterewardsmastercard';
import URCCSVG from '../Icons/ultamaterewardscreditcard';
import DefaultCreditCard from '../Icons/creditcarddefault';

describe( '<CreditCardIcon />', () => {

  it( 'should render VisaSVG if creditCardType is Visa', () => {

    let props = {
      creditCardType: 'Visa'
    }
    let VisaIcon = <VisaSVG/>
    expect( CreditCardIcon( props ) ).toEqual( VisaIcon );
  } );

  it( 'should render MasterCardSVG if creditCardType is Mastercard', () => {

    let props = {
      creditCardType: 'Mastercard'
    }
    let MasterCardIcon = <MasterCardSVG/>
    expect( CreditCardIcon( props ) ).toEqual( MasterCardIcon );
  } );

  it( 'should render DiscoverSVG if creditCardType is Discover', () => {

    let props = {
      creditCardType: 'Discover'
    }
    let DiscoverIcon = <DiscoverSVG/>
    expect( CreditCardIcon( props ) ).toEqual( DiscoverIcon );
  } );

  it( 'should render AmexSVG if creditCardType is AmericanExpress', () => {

    let props = {
      creditCardType: 'AmericanExpress'
    }
    let AmexIcon = <AmexSVG/>
    expect( CreditCardIcon( props ) ).toEqual( AmexIcon );
  } );

  it( 'should render URMCSVG if creditCardType is Ultamate Rewards MasterCard', () => {

    let props = {
      creditCardType: 'Ultamate Rewards MasterCard'
    }
    let URMCIcon = <URMCSVG/>
    expect( CreditCardIcon( props ) ).toEqual( URMCIcon );
  } );

  it( 'should render URCCSVG if creditCardType is Ultamate Rewards Credit Card', () => {

    let props = {
      creditCardType: 'Ultamate Rewards Credit Card'
    }
    let URCCIcon = <URCCSVG/>
    expect( CreditCardIcon( props ) ).toEqual( URCCIcon );
  } );

  it( 'should render DefaultCreditCard if creditCardType is DefaultCreditCard', () => {

    let props = {
      creditCardType: 'DefaultCreditCard'
    }
    let DefaultCreditCardIcon = <DefaultCreditCard/>
    expect( CreditCardIcon( props ) ).toEqual( DefaultCreditCardIcon );
  } );

} );
