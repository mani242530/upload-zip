/**
* Divider
*/

import React from 'react';
import PropTypes from 'prop-types';
import './Divider.css';
import classNames from 'classnames';
import ColorBarSVG from '../Icons/ColorBand';
import ColorBarThickSVG from '../Icons/ColorBandThick';
import GraphicPatternSVG from '../Icons/GraphicPattern';


const propTypes = {
  displayLine: PropTypes.bool,
  dividerType: PropTypes.string,
  marginTop: PropTypes.string,
  marginBottom: PropTypes.string,
  marginRight: PropTypes.string,
  marginLeft: PropTypes.string,
  paddingBottom: PropTypes.string,
  shouldAddStyleDivider: PropTypes.bool
};

const defaultProps = {
  displayLine: true,
  dividerType: undefined,
  shouldAddStyleDivider: false
}


const Divider = ( props ) => {

  const style = {
    ...( props.marginTop && { marginTop: props.marginTop } ),
    ...( props.marginBottom && { marginBottom: props.marginBottom } ),
    ...( props.marginRight && { marginRight: props.marginRight } ),
    ...( props.marginLeft && { marginLeft: props.marginLeft } ),
    ...( props.paddingBottom && { paddingBottom: props.paddingBottom } )
  }

  const {
    displayLine,
    dividerType,
    shouldAddStyleDivider
  } = props

  return (
    <div
      className='Divider'
      role='presentation'
      aria-hidden={ true }
      style={ shouldAddStyleDivider ? style : {} }
    >
      <div
        className={
          classNames( {
            'Divider__Default' : displayLine && dividerType === undefined,
            'Divider__Gray' : dividerType && dividerType === 'gray',
            'Divider__Gray--secondary' : dividerType && dividerType === 'gray-secondary',
            'Divider__MultiColored': dividerType && dividerType === 'multi-color',
            'Divider__Orange' : dividerType && dividerType === 'orangeHorizontal',
            'Divider__Gray__Default' : dividerType && dividerType === 'gray-default',
            'Divider__GraphicPattern': dividerType && dividerType === 'graphic-pattern'
          } )
        }
        style={ style }
      >
        { dividerType === 'multi-color' &&
          <ColorBarSVG />
        }
        { dividerType === 'multi-color-thick' &&
          <ColorBarThickSVG />
        }
        { dividerType === 'graphic-pattern' &&
          <GraphicPatternSVG />
        }

      </div>
    </div>
  );

}


Divider.propTypes = propTypes;
Divider.defaultProps = defaultProps;
export default Divider;
