import React from 'react';
import ReactDOM from 'react-dom';
import { shallow } from 'enzyme';
import { shallowToJson } from 'enzyme-to-json'
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
import Divider from './Divider';

describe( '<Divider /> ', () => {
  it( 'renders without crashing', () => {
    const div = document.createElement( 'div' );
    ReactDOM.render( <Divider displayLine={ true } />, div );
  } );

  it( 'should have aria-hidden to be true', () => {
    const component = shallowDivider( );
    expect( component.props()['aria-hidden'] ).toBeTruthy();
  } );

  it( 'should render appropriate defaults when passed only displayLine prop set to true', () => {
    const component = shallowDivider( { displayLine: true } );
    expect( shallowToJson( component ) ).toMatchSnapshot();
  } );

  it( 'should add appropriate classes when displayLine prop is set to false', () => {
    const component = shallowDivider( { displayLine: false } );
    expect( shallowToJson( component ) ).toMatchSnapshot();
  } );

  it( 'should render svg if multi-color is passed in', () => {
    const component = shallowDivider( { displayType: 'muli-color' } );
    expect( shallowToJson( component ) ).toMatchSnapshot();
  } );

  it( 'should render svg if multi-color is passed in', () => {
    const component = shallowDivider( { displayType: 'gray-default' } );
    expect( shallowToJson( component ) ).toMatchSnapshot();
  } );

  it( 'should render blank divder if displayLine is false and not type is passed in', () => {
    const component = shallowDivider( { displayLine: false } );
    expect( shallowToJson( component ) ).toMatchSnapshot();
  } );

  it( 'should render svg if multi-color-thick is passed in', () => {
    const component = shallowDivider( { displayLine: true, dividerType: 'multi-color-thick' } );
    expect( component.find( 'SVG' ).length ).toBe( 1 );
  } );

  it( 'should render Divider with inline style if shouldAddStyleDivider is true and margin style attribute is passed', () => {
    const component = shallowDivider( { dividerType: 'graphic-pattern', shouldAddStyleDivider: true, marginTop: '0em' } );
    expect( component.find( '.Divider' ).props().style ).toEqual( { marginTop: '0em' } );
  } );

  it( 'should render Divider with empty style if shouldAddStyleDivider is false even if margin style attribute is passed', () => {
    const component = shallowDivider( { dividerType: 'graphic-pattern', shouldAddStyleDivider: false, marginTop: '0em' } );
    expect( component.find( '.Divider' ).props().style ).toEqual( { } );
  } );

  it( 'should render svg if graphic-pattern is passed in', () => {
    const component = shallowDivider( { dividerType: 'graphic-pattern' } );
    expect( component.find( '.Divider__GraphicPattern' ).length ).toBe( 1 );
    expect( component.find( 'SVG' ).length ).toBe( 1 );
  } );



} );

/**
 * Uses enzyme to shallow the Divider component
 * @param {Object} props - the props to shallow the component with
 * @return {Object} - the enzyme wrapper
 */
function shallowDivider( props = {} ){
  return shallow(
    <Divider
      { ...props }
    />
  )
}
