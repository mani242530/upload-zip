/**
 * FullScreenOverlay
 */

import React from 'react';
import './FullScreenOverlay.css';


const FullScreenOverlay = ( props ) => {

  return (
    <div className='FullScreenOverlay'>
    </div>
  );

}


export default FullScreenOverlay;
