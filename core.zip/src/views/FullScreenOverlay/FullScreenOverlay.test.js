import React from 'react';
import ReactDOM from 'react-dom';
import FullScreenOverlay from './FullScreenOverlay';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';

describe( '<FullScreenOverlay />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <FullScreenOverlay /> );
    expect( component.find( 'FullScreenOverlay' ).length ).toBe( 1 );
  } );
} );
