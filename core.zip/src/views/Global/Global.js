/**
 * Global
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import { injectIntl } from 'react-intl';
import Modal from 'react-modal';
import defaults from 'lodash/defaults';
import { isServer } from '../../utils/device_detection/device_detection';
import {
  alertWindowResize,
  alertDocumentScroll,
  enableQubitReadyFlag,
  closeStatusErrorPopUp
} from '../../events/global/global.events';
import {
  setESUModelOpenedFlag,
  setESUModelClosedFlag
} from '../../events/email_sign_up/email_sign_up.events';
import {
  sessionTokenRequested,
  getActionDefinition
} from '../../events/services/services.events';
import { broadcastMessage } from '../../utils/accessibility/accessibility';
import { updateDataLayer } from '../../utils/omniture/omniture';
import CloseSVG from '../Icons/close';
import './Global.css';
import messages from './Global.messages';
import ResponseMessages from '../ResponseMessages/ResponseMessages';


export var pageDataObj = {
  'globalPageData': {
    'navigation': {
      'pageName':'',
      'channel':'',
      'pageType':'',
      'registerType':'',
      'brandName':'',
      'hierarchy':''
    },
    'order': {
      'itemCount':''
    },
    'profile': {
      'email':'',
      'firstName':'',
      'lastName':''
    },
    'rewards': {
      'loyaltyId':'',
      'programId':'',
      'clubPoints':'',
      'pointsToRedeem':'',
      'pointsExpiring':'',
      'pointsExpireDate':'',
      'memberSince':'',
      'platinumMember':'',
      'platinumMemberType':'',
      'userType':'Guest'
    },
    'cart': {
      'autoRemovedItems':''
    },
    'errorPageData':{
      'error':''
    },
    'info': {
      'saga':''
    }
  }
};

let intl;

class Global extends Component{

  constructor( props ){
    super( props );
    intl = props.intl;
    this.trackDocumentScroll = this.trackDocumentScroll.bind( this );
    this.trackWindowResize = this.trackWindowResize.bind( this );
    this.setWindowSize = this.setWindowSize.bind( this );
    this.bindReduxToDomEvents = this.bindReduxToDomEvents.bind( this );

    // Global page data object
    // Check if globalPageData object is defined in page
    if( typeof globalPageData !== 'undefined' ){
      defaults( globalPageData, pageDataObj.globalPageData );
    }
    else {
      updateDataLayer( pageDataObj );
    }

    if( !isServer() ){

      // event listener for checking if the QUBIT is loaded and update the store
      // this is exceptional case where we have to add event listener in the constructer, to avoid timing issues for the qubit loading before the app starts rendering. This listener being here could solve the timing issue.

      document.addEventListener( 'QUBIT_READY', () => {
        this.props.enableQubitReadyFlag();
      } );

      document.addEventListener( 'UpdateReactESUOverlayOpenedEvent', () => {
        this.props.setESUModelOpenedFlag();
      } );
      document.addEventListener( 'UpdateReactESUOverlayClosedEvent', () => {
        this.props.setESUModelClosedFlag();
      } );

      // request a sessionID
      props.requestSessionToken();

    }
  }

  componentDidMount(){

    if( !isServer() ){
      this.trackWindowResize();
      // when the page is rendered from the server, the device type would have been already set from the server type
      // the window size will not be checked here, as we need to allow the page to be rendered the same as it was served from the server
      if( !this.props.isServerSideRendered ){
        this.setWindowSize();
      }
      this.enableDisableTouchMove();
      this.bindReduxToDomEvents();

      // This is to address a specific issue where in the bag page in IPAD the mobile header is shown in the Landscape mode
      setTimeout( () => {
        this.setWindowSize();
      }, 1000 );

    }
  }


  componentWillReceiveProps( nextProps ){
    // enable/disable the full page scroll
    document.getElementsByTagName( 'html' )[0].className = nextProps.HTML_ELEMENT_CLASS;
  }

  componentDidUpdate( prevProps ){

    // check for differences in live regions and notify the user
    if( prevProps.assertiveMessageAdd !== this.props.assertiveMessageAdd ){
      broadcastMessage( this.props.assertiveMessageAdd );
    }
  }

  bindReduxToDomEvents(){

    document.addEventListener( 'UpdateReactCartEvent', ()=>{
      this.props.updateUserData();
    } );

    // DO NOT REMOVE THE FOLLOWING
    // it forces a refresh of the browser if we're coming back to a cahced back-forward state
    window.onpageshow = e => {
      if( e.persisted ){
        global.location.reload();
      }
    }
  }


  trackDocumentScroll(){

    document.addEventListener( 'scroll', ( e )=> {
      this.props.alertDocumentScroll( global.scrollY );
    } );

  }

  enableDisableTouchMove(){

    document.addEventListener( 'touchmove', e =>{
      if( this.props.blockDocumentScroll ){
        let isTouchMoveAllowed = false;
        let p = e.target;

        while ( p !== null ){
          if( p.classList && p.classList.contains( 'touchMoveAllowed' ) ){
            isTouchMoveAllowed = true;
            break;
          }
          p = p.parentNode;
        }

        if( !isTouchMoveAllowed ){
          e.preventDefault();
        }
      }
      else {
        return true;
      }
    } );
  }

  setWindowSize(){
    let isMobileDevice = document.documentElement.clientWidth < this.props.mobileWidth;
    this.props.alertWindowResize(
      window.innerHeight,
      document.documentElement.clientWidth,
      isMobileDevice,
      this.props.isMobileDevice !== isMobileDevice
    );
  }

  trackWindowResize(){

    global.addEventListener( 'resize', ( e ) =>{

      this.setWindowSize();
    } );

  }


  render(){
    return (
      <div className='Global'>
        { this.props.children }
        { this.props.displayStatusErrorPopUp &&
        // Added condition because in server-side rendering, react-modal is trying to attach modal to dom before it is being constructed in test case
        // which is causing test case to freeze. To avoid that we have added a flag to not to render the modal if the flag is turned off.
        (
          <Modal
            isOpen
            className='GlobalModal'
            role='dialog'
          >
            <button className='GlobalModal__CloseButton'
              onClick={ this.props.closeStatusErrorPopUp }
            >
              <CloseSVG/>
            </button>
            <div className='GlobalModal__Message' >
              <ResponseMessages
                message={ formatMessage( messages.badRequest ) }
              />
            </div>
          </Modal>
        )
        }
      </div>
    )
  }

}

export const dumbComponent = Global;

export const mapStateToProps = ( state ) => {
  return {
    ...state.global,
    ...state.session,
    ...state.typeaheadsearch
  }
}



export const mapDispatchToProps = ( dispatch ) => {
  return {
    alertWindowResize: ( screenHeight, screenWidth, isMobileDevice, hasInflectionChanged ) => dispatch( alertWindowResize( screenHeight, screenWidth, isMobileDevice, hasInflectionChanged ) ),
    alertDocumentScroll: ( scrollPosition ) => dispatch( alertDocumentScroll( scrollPosition ) ),
    requestSessionToken: () => dispatch( sessionTokenRequested() ),
    updateUserData: () => dispatch( getActionDefinition( 'user', 'requested' )() ),
    enableQubitReadyFlag: () => dispatch( enableQubitReadyFlag() ),
    setESUModelOpenedFlag: () => dispatch( setESUModelOpenedFlag() ),
    setESUModelClosedFlag: () => dispatch( setESUModelClosedFlag() ),
    closeStatusErrorPopUp: () => dispatch( closeStatusErrorPopUp() )
  };
}

// this is to mock the data for test cases
export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( injectIntl( Global ) ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );

export function formatMessage( ...args ){
  return intl.formatMessage( ...args );
}

export function formatNumber( ...args ){
  return intl.formatNumber( ...args );
}
