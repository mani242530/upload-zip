/*
 * Global Messages
 *
 * This contains all the text for the Global component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  badRequest: {
    id: 'i18n.Global.badRequest',
    defaultMessage: 'There was an issue processing your request. Please try again later'
  }

} );





































