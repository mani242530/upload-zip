import React from 'react';
import { Provider } from 'react-redux';
import { shallow, mount } from 'enzyme';
import Global, {
  formatNumber, connectFunction, mapStateToProps, mapDispatchToProps, pageDataObj
} from './Global';
import { mountWithIntlGlobal, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';
import {
  sessionTokenRequested,
  getActionDefinition,
  registerServiceName
} from '../../events/services/services.events';
import {
  alertWindowResize,
  alertDocumentScroll
} from '../../events/global/global.events';
import { broadcastMessage } from '../../utils/accessibility/accessibility';
import { omnitureEventFactory } from '../../utils/omniture/omniture';
import messages from './Global.messages';

let store = configureStore( );
const initialState = {};
jest.mock( './../../utils/accessibility/accessibility', () =>{
  return {
    broadcastMessage : jest.fn()
  }
} )
omnitureEventFactory.listenSignalLoad = jest.fn();
omnitureEventFactory.triggerOmnitureEvent = jest.fn();


Global.prototype.componentDidMount = jest.fn();
describe( '<Global />', () => {
  registerServiceName( 'user' );
  it( 'renders without crashing', () => {
    let props = initialState;
    let component = mountWithIntlGlobal(
      <Provider store={ store }>
        <Global { ...props }/>
      </Provider>
    );

    expect( component.find( 'Global' ).length ).toBe( 1 );
    component.unmount();
  } );


  it( 'should contain a properly formatted globalPageData json object for analytics tracking', () => {

    let Obj = {
      'globalPageData': {
        'navigation': {
          'pageName':'',
          'channel':'',
          'pageType':'',
          'registerType':'',
          'brandName':'',
          'hierarchy':''
        },
        'order': {
          'itemCount':''
        },
        'profile': {
          'email':'',
          'firstName':'',
          'lastName':''
        },
        'rewards': {
          'loyaltyId':'',
          'programId':'',
          'clubPoints':'',
          'pointsToRedeem':'',
          'pointsExpiring':'',
          'pointsExpireDate':'',
          'memberSince':'',
          'platinumMember':'',
          'platinumMemberType':'',
          'userType':'Guest'
        },
        'cart': {
          'autoRemovedItems':''
        },
        'errorPageData':{
          'error':''
        },
        'info': {
          'saga':''
        }
      }
    };

    expect( pageDataObj ).toEqual( Obj );


  } )

  it( 'should render modal with correct props', () => {
    store.getState().global = {
      displayStatusErrorPopUp: true
    }
    let component = mountWithIntlGlobal(
      <Provider store={ store }>
        <Global
          displayStatusErrorPopUp={ true }
        />
      </Provider>
    );
    expect( component.find( 'Modal' ).length ).toBe( 1 );
    expect( component.find( 'Modal' ).props().isOpen ).toBe( true );
    expect( component.find( 'Modal' ).props().className ).toBe( 'GlobalModal' );
    expect( component.find( 'Modal' ).props().role ).toBe( 'dialog' );
    component.unmount();
  } );

  it( 'should render Response messages if displayStatusErrorPopUp is true', () => {
    store.getState().global = {
      displayStatusErrorPopUp: true
    }
    let component = mountWithIntlGlobal(
      <Provider store={ store }>
        <Global
          displayStatusErrorPopUp={ true }
        />
      </Provider>
    );
    expect( component.find( '.GlobalModal__Message' ).length ).toBe( 1 );
    expect( component.find( 'ResponseMessages' ).length ).toBe( 1 );
    expect( component.find( 'ResponseMessages' ).props().message ).toBe( messages.badRequest.defaultMessage );
    component.unmount();
  } );

  it( 'should Invoke componentDidMount method', () => {

    let props = initialState;
    let component = mountWithIntlGlobal(
      <Provider store={ store }>
        <Global { ...props }/>
      </Provider>
    );
    expect( Global.prototype.componentDidMount ).toBeCalled();
    component.unmount();
  } );

  let alertWindowResizeMock = jest.fn();
  let alertDocumentScrollMock = jest.fn();
  let setESUModelClosedFlagMock = jest.fn();
  let setESUModelOpenedFlagMock = jest.fn();
  it( 'should Invoke enableQubitReadyFlag method', () => {
    let enableQubitReadyFlagMock = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) => {
      return {
        ...mapDispatchToProps( dispatch ),
        enableQubitReadyFlag: enableQubitReadyFlagMock,
        requestSessionToken: () => dispatch( sessionTokenRequested() ),
        alertWindowResize: alertWindowResizeMock,
        setESUModelOpenedFlag: setESUModelOpenedFlagMock,
        setESUModelClosedFlag: setESUModelClosedFlagMock,
        alertDocumentScroll: alertDocumentScrollMock
      }
    }
    let GlobalMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let abc = new CustomEvent( 'QUBIT_READY' );
    let props = initialState;
    let component = mountWithIntlGlobal(
      <Provider store={ store }>
        <GlobalMock { ...props }/>
      </Provider>
    );
    document.dispatchEvent( abc );
    expect( enableQubitReadyFlagMock ).toBeCalled();
    component.unmount();

  } );

  it( 'should invoke methods on componentDidMount call', () => {
    let props = initialState;
    let component = mountWithIntlGlobal(
      <Provider store={ store }>
        <Global { ...props }/>
      </Provider>
    );
    jest.useFakeTimers();
    let node = component.find( 'Global' ).instance();
    node.setWindowSize = jest.fn();
    node.enableDisableTouchMove = jest.fn();
    node.bindReduxToDomEvents = jest.fn();
    node.componentDidMount();
    expect( node.setWindowSize ).toBeCalled();
    expect( node.enableDisableTouchMove ).toBeCalled();
    expect( node.bindReduxToDomEvents ).toBeCalled();
    node.setWindowSize.mockReset(); // this will reset the mock method so that if will not be considered as called
    jest.runAllTimers();
    expect( node.setWindowSize ).toBeCalled(); // this is to test the setWindowSize call inside the setTimeOut call
    component.unmount();
  } );

  it( 'should not invoke setWindowSize when isServerSideRendered is true', () => {
    store.getState().global.isServerSideRendered = true;
    let props = initialState;
    const component = mountWithIntlGlobal(
      <Provider store={ store }>
        <Global { ...props }/>
      </Provider>
    );
    let node = component.find( 'Global' ).instance();
    node.setWindowSize = jest.fn();
    node.componentDidMount();
    expect( node.setWindowSize ).not.toBeCalled();
    component.unmount();
  } );

  it( 'should Invoke alertWindowResize method', () => {
    let props = initialState;
    const component = mountWithIntlGlobal(
      <Provider store={ store }>
        <Global { ...props }/>
      </Provider>
    );
    const event = new CustomEvent( 'resize' );
    document.dispatchEvent( event );
    expect( alertWindowResizeMock ).toBeCalled();
    component.unmount();
  } );

  it( 'should Invoke alertDocumentScroll method', () => {
    let props = initialState;
    let mapDispatchToPropsMock = ( dispatch ) => {
      return {
        ...mapDispatchToProps( dispatch ),
        requestSessionToken: () => dispatch( sessionTokenRequested() ),
        alertWindowResize: alertWindowResizeMock,
        setESUModelOpenedFlag: setESUModelOpenedFlagMock,
        alertDocumentScroll: alertDocumentScrollMock
      }
    }
    let GlobalMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    const component = mountWithIntlGlobal(
      <Provider store={ store }>
        <GlobalMock { ...props }/>
      </Provider>
    );
    component.find( 'Global' ).instance().trackDocumentScroll();
    const event = new CustomEvent( 'scroll' );
    document.dispatchEvent( event );
    expect( alertDocumentScrollMock ).toBeCalled();
  } );

  it( 'should format Number', ()=>{
    expect( formatNumber( 1234567 ) ).toBe( '1,234,567' );
  } );

  it( 'it should invoke broadcastMessage() if there is any change in assertiveMessageAdd', () => {

    let props = {
      assertiveMessageAdd : '$5 Gift Card (****1212 1212 1212 1212) Applied!'
    }
    let componenet1 = mountWithIntlGlobal(
      <Provider store={ store }>
        <Global { ...props }/>
      </Provider>
    );
    let prevProps = {
      noRubberEffect: []
    }
    componenet1.find( 'Global' ).instance().componentDidUpdate( prevProps );
    expect( broadcastMessage ).toBeCalled();
  } );

  it( 'should Invoke setESUModelOpenedFlag method when UpdateReactESUOverlayOpenedEvent dispatched', () => {
    const openFlagMock = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) => {
      return {
        ...mapDispatchToProps( dispatch ),
        setESUModelOpenedFlag: openFlagMock,
        requestSessionToken: () => dispatch( sessionTokenRequested() ),
        alertWindowResize: ( screenHeight, screenWidth, isMobileDevice, hasInflectionChanged ) => dispatch( alertWindowResize( screenHeight, screenWidth, isMobileDevice, hasInflectionChanged ) )
      }
    }

    let GlobalMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let testCustEvent = new CustomEvent( 'UpdateReactESUOverlayOpenedEvent' );
    let props = initialState;
    let element = mountWithIntlGlobal(
      <Provider store={ store }>
        <GlobalMock />
      </Provider>
    );
    let elemProps = element.find( 'Global' ).props();

    document.dispatchEvent( testCustEvent );

    expect( openFlagMock ).toBeCalled();
  } );

  it( 'should Invoke setESUModelClosedFlag method when UpdateReactESUOverlayClosedEvent dispatched', () => {
    let setESUModelClosedFlagMock = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) => {
      return {
        ...mapDispatchToProps( dispatch ),
        setESUModelClosedFlag: setESUModelClosedFlagMock,
        requestSessionToken: () => dispatch( sessionTokenRequested() ),
        alertWindowResize: ( screenHeight, screenWidth, isMobileDevice, hasInflectionChanged ) => dispatch( alertWindowResize( screenHeight, screenWidth, isMobileDevice, hasInflectionChanged ) )
      }
    }
    let GlobalMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let testCustEvent = new CustomEvent( 'UpdateReactESUOverlayClosedEvent' );
    let props = initialState;
    let component = mountWithIntlGlobal(
      <Provider store={ store }>
        <GlobalMock { ...props }/>
      </Provider>
    );
    document.dispatchEvent( testCustEvent );
    expect( setESUModelClosedFlagMock ).toBeCalled();
    component.unmount();
  } );

  it( 'should Invoke updateUserData method when UpdateReactCartEvent dispatched', () => {
    let updateUserDataMock = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) => {
      return {
        ...mapDispatchToProps( dispatch ),
        updateUserData: updateUserDataMock,
        requestSessionToken: () => dispatch( sessionTokenRequested() ),
        alertWindowResize: ( screenHeight, screenWidth, isMobileDevice, hasInflectionChanged ) => dispatch( alertWindowResize( screenHeight, screenWidth, isMobileDevice, hasInflectionChanged ) )
      }
    }
    let GlobalMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let component = mountWithIntlGlobal(
      <Provider store={ store }>
        <GlobalMock />
      </Provider>
    );

    let testCustEvent = new CustomEvent( 'UpdateReactCartEvent' );
    document.dispatchEvent( testCustEvent );

    expect( updateUserDataMock ).toHaveBeenCalled();
    component.unmount();
  } );

  let dispatch = jest.fn();
  const mdp  = mapDispatchToProps( dispatch );

  it( 'alertDocumentScroll should dispatch the proper action', () => {
    const scrollPosition = jest.fn();
    const event = mdp.alertDocumentScroll( scrollPosition );
    expect( dispatch ).toHaveBeenCalledWith(
      alertDocumentScroll( scrollPosition )
    );
  } );

  it( 'updateUserData should dispatch the proper action', () => {

    const event = mdp.updateUserData( );
    expect( dispatch ).toHaveBeenCalledWith(
      getActionDefinition( 'user', 'requested' )( )
    );
  } );


  it( 'should call the bindReduxToDomEvents method', () => {
    let props = initialState;
    let component = mountWithIntlGlobal(
      <Provider store={ store }>
        <Global { ...props }/>
      </Provider>
    );

    let instance = component.find( 'Global' ).instance();
    window.location.reload = jest.fn();
    let event = jest.fn();
    instance.bindReduxToDomEvents();
    event.persisted = true;
    window.onpageshow( event );
    expect( window.location.reload ).toHaveBeenCalled( );
  } );

  it( 'should Invoke alertWindowResize method with isMobileDevice as true if clientWidth < mobileWidth on setWindowSize', () => {
    const props = {
      ...initialState,
      mobileWidth:100
    }
    const mapDispatchToPropsMock = ( dispatch ) => {
      return {
        ...mapDispatchToProps( dispatch ),
        requestSessionToken: () => dispatch( sessionTokenRequested() ),
        alertWindowResize: alertWindowResizeMock,
        setESUModelOpenedFlag: setESUModelOpenedFlagMock,
        alertDocumentScroll: alertDocumentScrollMock
      }
    }
    const GlobalMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    const component = mountWithIntlGlobal(
      <Provider store={ store }>
        <GlobalMock { ...props }/>
      </Provider>
    );
    const isMobileDevice = true

    component.find( 'Global' ).instance().setWindowSize();
    expect( alertWindowResizeMock ).toHaveBeenCalledWith( window.innerHeight, 0, isMobileDevice, true );
  } );

  it( 'should Invoke alertWindowResize method with isMobileDevice as false if clientWidth > mobileWidth on setWindowSize', () => {
    const props = {
      ...initialState,
      mobileWidth:-1
    }
    const mapDispatchToPropsMock = ( dispatch ) => {
      return {
        ...mapDispatchToProps( dispatch ),
        requestSessionToken: () => dispatch( sessionTokenRequested() ),
        alertWindowResize: alertWindowResizeMock,
        setESUModelOpenedFlag: setESUModelOpenedFlagMock,
        alertDocumentScroll: alertDocumentScrollMock
      }
    }
    const GlobalMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    const component = mountWithIntlGlobal(
      <Provider store={ store }>
        <GlobalMock { ...props }/>
      </Provider>
    );
    const isMobileDevice = false

    component.find( 'Global' ).instance().setWindowSize();
    expect( alertWindowResizeMock ).toHaveBeenCalledWith( window.innerHeight, 0, isMobileDevice, false );
  } );

} );
