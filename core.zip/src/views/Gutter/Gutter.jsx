/**
 * Gutter
 */

import React from 'react';
import './Gutter.css';

import classNames from 'classnames';

const Gutter = props => (
  <div className='Gutter'>

    { props.children }

  </div>
)

export default Gutter;
