import React from 'react';
import ReactDOM from 'react-dom';
import Gutter from './Gutter';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';

describe( '<Gutter />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <Gutter /> );
    expect( component.find( 'Gutter' ).length ).toBe( 1 );
  } );
} );
