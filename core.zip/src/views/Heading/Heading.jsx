/**
* Heading Component
* For Headers h1, h2, h3, h4, h5 and h6
* Usage:
* import Heading from './../../views/Heading/Heading';
* <Heading
    rank={ 1 }
    type='primary'
  >TEXT HERE
  </Heading>
* or
  <Heading
    rank={ 1 }
    type='primary'
  >TEXT HERE<span>extra markup here</span>
  </Heading>
*/

import React from 'react';
import PropTypes from 'prop-types';
import './Heading.css';

const Heading = ( {
  rank = 2,
  children,
  type = 'primary',
  id,
  tabIndex,
  headerRef
} ) => {
  const Tag = rank > 6 ? 'h6' : `h${rank}`;
  return (
    <Tag
      className={ `${type}` }
      { ...( id && { id } ) }
      { ...( tabIndex && { tabIndex } ) }
      { ...( headerRef && { ref:headerRef } ) }
    >
      { children }
    </Tag>
  );
};
Heading.propTypes = {
  rank: PropTypes.oneOf( [
    1,
    2,
    3,
    4,
    5,
    6
  ] ),
  type: PropTypes.oneOf( [
    'primary',
    'secondary',
    'tertiary'
  ] )
};
export default Heading;