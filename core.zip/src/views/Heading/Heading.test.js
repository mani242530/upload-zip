import React from 'react';
import ReactDOM from 'react-dom';
import Heading from './Heading';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<Heading /> ', () => {
  it( 'renders without crashing', () => {
    const div = document.createElement( 'div' );
    ReactDOM.render( <Heading />, div );
  } );

  it( 'should pass the tabIndex props to the h element, if it is passed', () => {
    const props = {
      tabIndex:-1
    }
    const component = mountWithIntl( <Heading { ...props }/> );
    expect( component.find( 'h2' ).props().tabIndex ).toBe( props.tabIndex );
  } );

  it( 'should invoke the method passed to headerRef prop with the instance of the compoenent itself', () => {
    const props = {
      headerRef:jest.fn()
    }
    const component = mountWithIntl( <Heading { ...props }/> );
    expect( props.headerRef ).toHaveBeenCalledWith( component.find( 'h2' ).instance() )
  } );

} );