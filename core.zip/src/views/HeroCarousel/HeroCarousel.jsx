/**
 * HeroCarousel
 */

import React, { Component } from 'react';
import './HeroCarousel.css';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

import { connect } from 'react-redux';
import Slider from 'react-slick';
import isUndefined from 'lodash/isUndefined';
import forEach from 'lodash/forEach';
import includes from 'lodash/includes';
import messages from './HeroCarousel.messages';

import { formatMessage } from '../Global/Global';
import Spinner from '../Icons/spinner';
import Button from '../Button/Button';
import Anchor from '../Anchor/Anchor';
import Image from '../Image/Image';
import PlaySVG from '../Icons/play';
import PauseSVG from '../Icons/pause';

import {
  toggleAutoPlay,
  setCurrentCarouselSlide
} from '../../events/hero_carousel/hero_carousel.events';

/**
 * Class
 * @extends React.Component
 */
class HeroCarousel extends Component{
  /**
   * Create a HeroCarousel
   */
  constructor( props ){
    super( props );

    this.sliderContainer = undefined;
    this.innerSliderContainer = [];
    this.isSlickClonedElemsHidden = false; // This flag is used to stop re-render the componentDidUpdate
    this.carouselAfterChange = this.carouselAfterChange.bind( this );
    this.carouselCustomPaging = this.carouselCustomPaging.bind( this );
    this.sliderOnFocusEventListener = this.sliderOnFocusEventListener.bind( this );
  }

  // To set the tabindex for ADA screen reader to read only the current side content
  // Pass custom function to react-slick
  carouselAfterChange( currentSlide ){
    this.props.setCurrentCarouselSlide( currentSlide );
  }

  // To set content for ADA screen reader to read dot content
  // Pass custom function to react-slick
  carouselCustomPaging( index ){
    const {
      heroCarousel
    } = this.props;

    return (
      <button
        className='js_carousel-indicators-item' // This class name is used as a identifier, to add click event handler to pause the animation
        type='button'
      >
        <span className='sr-only'>
          { ( () => {
            let currentSlide = parseInt( ( index + 1 ), 10 );
            let carouselLength = parseInt( heroCarousel.carouselList.length, 10 );
            return ( heroCarousel.currentSlide === index ) ? formatMessage( messages.carouselDotActiveTxt, { currentSlide, carouselLength } ) : formatMessage( messages.carouselDotTxt, { currentSlide, carouselLength } )
          } )() }
        </span>
      </button>
    );
  }

  componentDidUpdate(){
    // To fix, Rotator images are getting swapped or becoming blank on navigating through the rotator images using voice over navigation.
    // react-slick module creates two cloned div to display infinite carousel rotation. Added aria-hidden attr not to read the two duplicated cloned divs
    // add event listerens for handling the slide selection based on focus events
    if( !this.isSlickClonedElemsHidden ){
      const thisObj = this;

      // Find the carousel dots using css class name and attach the click event to pause the animation
      // forEach not working in IE browsers and changed the logic from forEach to for loop
      let jsCarouselIndicatorsItemElem = document.querySelectorAll( 'button.js_carousel-indicators-item' );
      for ( let i = 0; i < jsCarouselIndicatorsItemElem.length; i++ ){
        jsCarouselIndicatorsItemElem[i].addEventListener( 'click', function( e ){
          thisObj.props.toggleAutoPlay( false ); // Set to auto play to false to stop animation when click on carousel dots
        } );
      }

      this.innerSliderContainer.forEach(
        function( item, index ){
          if( includes( item.className, 'slick-cloned' ) ){
            item.setAttribute( 'aria-hidden', 'true' );
          }

          item.addEventListener( 'focus', function( e ){
            thisObj.sliderOnFocusEventListener( parseInt( item.getAttribute( 'data-index' ), 10 ) );
          } );
        }
      );
      this.isSlickClonedElemsHidden = true;
    }
  }

  // This method will invoke on slider focus when voice over turned on
  sliderOnFocusEventListener( currentSlide ){
    let autoPlayFlag = this.props.heroCarousel.settings.autoplay;
    this.props.toggleAutoPlay( false ); // Set to auto play to false to stop animation before display the current slide
    this.sliderContainer.innerSlider.slickGoTo( currentSlide );
    this.props.toggleAutoPlay( autoPlayFlag ); // Set to auto play to current state value to restart or stop animation after display the current slide
  }

  // This method will invoke the play or pause method of the slider based on the value of the
  // autoPlay parameter passed to the method. the parameter sliderReference will have reference to the
  // slider component loaded from the HeroCarousel component
  playOrPauseCarousel( autoPlay, sliderReference ){
    if( autoPlay ){
      sliderReference.innerSlider.autoPlay();
    }
    else {
      sliderReference.innerSlider.pause();
    }
  }

  /**
   * Renders the HeroCarousel component
   */
  render(){
    const {
      heroCarousel
    } = this.props;

    return (
      <div className='HeroCarousel'>
        { ( () => {
          if( !isUndefined( heroCarousel.carouselList ) ){

            let settings = {
              ...heroCarousel.settings,
              afterChange: this.carouselAfterChange,
              customPaging: this.carouselCustomPaging
            };

            return (
              <div className='HeroCarousel-container'>
                <Slider
                  className='slider'
                  ref={ elem => this.sliderContainer = elem }
                  { ...settings }
                >
                  {
                    heroCarousel.carouselList && heroCarousel.carouselList.map( ( carouselItem, index ) => {
                      this.innerSliderContainer = [];
                      return (
                        <div
                          key={ index }
                          className='carousel-slide'
                          ref={ elem => {
                            ( elem ) ? this.innerSliderContainer.push( elem ) : null;
                          } }
                          style={ { background: `${carouselItem.colorHtmlTag}` } }
                        >
                          {
                            !isUndefined( carouselItem.link ) &&
                            (
                              <Anchor
                                url={ carouselItem.link.url }
                                target={ carouselItem.link.showInNewPage ? '_blank' : '_self' }
                                dataSlotPosition={ carouselItem.link.dataSlotPosition }
                                { ...( ( heroCarousel.currentSlide === index ) ? { tabIndex: '0' } : { tabIndex: '-1' } ) }
                              >
                                <Image
                                  src={ carouselItem.url }
                                  alt={ carouselItem.imageAlt }
                                />
                              </Anchor>
                            )
                          }
                          {
                            isUndefined( carouselItem.link ) &&
                              (
                                <Image
                                  src={ carouselItem.url }
                                  alt={ carouselItem.imageAlt }
                                />
                              )
                          }
                        </div>
                      )
                    } )
                  }
                </Slider>
                <Button
                  className='carousel-indicators-play-pause'
                  inputTag='button'
                  btnType='button'
                  btnOption='no-style'
                  clickEventHandler={ () => {
                    const playOrPause = !heroCarousel.settings.autoplay;
                    this.props.toggleAutoPlay( playOrPause );
                    // toggleAutoPlay method invoked above will set the autoplay value in the slider settings
                    // but the in the library the actual autoplay method to trigger the carousel play will be invoked only on mouseleave event.
                    // this is a constraint when navigating through keyboard, as mouseleave event will not be triggered
                    // therefore we are invoking playOrPauseCarousel to explicitly trigger the play and pause functionality
                    // even if we are explicitly triggering the autoPlay method, the play will resume only if the value of the autoplay attribute settings is set as true
                    // a timeout of 1000 ms is provided to give enough time for the toggleAutoPlay method invokation to set the value of the autoPlay attribute.
                    setTimeout( this.playOrPauseCarousel, 1000, playOrPause, this.sliderContainer );
                  } }
                >
                  <span>{ heroCarousel.settings.autoplay ? <PauseSVG /> : <PlaySVG /> }</span>
                  <span className='sr-only'>{ heroCarousel.settings.autoplay ? formatMessage( messages.carouselPauseTxt ) : formatMessage( messages.carouselPlayTxt ) }</span>
                </Button>
              </div>
            );
          }
          else {
            return (
              <div className='Loading__spinner'>
                <Spinner />
              </div>
            );
          }
        } )() }
      </div>
    );
  }
}

export const mapStateToProps = ( state ) => {
  return {
    ...state.global,
    heroCarousel: state.heroCarousel
  };
}

export const mapDispatchToProps = ( dispatch ) => {
  return {
    toggleAutoPlay: ( data ) => {
      dispatch( toggleAutoPlay( data ) );
    },
    setCurrentCarouselSlide: ( data ) => {
      dispatch( setCurrentCarouselSlide( data ) );
    }
  };
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return connect( mapStateToProps, mapDispatchToProps )( HeroCarousel );
};

export default connectFunction( mapStateToProps, mapDispatchToProps );
