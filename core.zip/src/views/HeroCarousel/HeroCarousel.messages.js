/*
 * HeroCarousel Messages
 *
 * This contains all the text for the HeroCarousel component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  carouselDotActiveTxt: {
    id: 'i18n.HeroCarousel.carouselDotActive',
    defaultMessage: 'Carousel Page { currentSlide } of { carouselLength } active'
  },
  carouselDotTxt: {
    id: 'i18n.HeroCarousel.carouselDotTxt',
    defaultMessage: 'Carousel Page { currentSlide } of { carouselLength } click here to move to this page'
  },
  carouselPlayTxt: {
    id: 'i18n.HeroCarousel.carouselPlayTxt',
    defaultMessage: 'play slide animation'
  },
  carouselPauseTxt: {
    id: 'i18n.HeroCarousel.carouselPlayTxt',
    defaultMessage: 'pause slide animation'
  }
} );
