import React from 'react';

import { Provider } from 'react-redux';
import HeroCarousel, { connectFunction, mapStateToProps, mapDispatchToProps } from './HeroCarousel';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';
import messages from './HeroCarousel.messages';
import { formatMessage } from '../Global/Global';

import {
  toggleAutoPlay,
  setCurrentCarouselSlide
} from '../../events/hero_carousel/hero_carousel.events';

const dispatch = jest.fn();
let mockJestFn = jest.fn();

let mapDispatchToPropsMock = ( dispatch ) =>{
  return {
    toggleAutoPlay: mockJestFn,
    setCurrentCarouselSlide: mockJestFn
  }
};

let props = {
  heroCarousel: {
    currentSlide: 0,
    carouselList: undefined
  }
};


describe( '<HeroCarousel in Desktop with guest flow />', () => {

  let store = configureStore( );
  let HeroCarouselMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
  window.heroCarouselList = [
    {
      colorHtmlTag: '#69c2b5',
      url: '//images.ulta.com/is/image/Ulta/wk4717_d_hero_promo_makeup_anastasia?scl=1',
      link: {
        showInNewPage: false,
        url: '/modern-renaissance-eyeshadow-palette?productId=xlsImpprod14291015',
        dataSlotPosition: '1_wk4717_d_hero_promo_makeup_anastasia'
      }
    }
  ];

  store.getState().heroCarousel = {
    settings: {
      accessibility: true,
      arrows: false,
      dots: true,
      lazyLoad: true,
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 5000,
      pauseOnHover: true
    },
    currentSlide: 0,
    carouselList: [
      {
        colorHtmlTag: '#69c2b5',
        name: 'WK47_ROTATOR 1 ANASTASIA',
        imageAlt: '',
        url: '//images.ulta.com/is/image/Ulta/wk4717_d_hero_promo_makeup_anastasia?scl=1',
        link: {
          showInNewPage: false,
          name: 'Dynamic Link',
          linkText: '',
          label: null,
          url: '/modern-renaissance-eyeshadow-palette?productId=xlsImpprod14291015',
          dataSlotPosition: '1_wk4717_d_hero_promo_makeup_anastasia'
        }
      },
      {
        colorHtmlTag: '#f7a3af',
        name: 'WK47_ROTATOR 2 ROBE',
        imageAlt: '',
        url: '//images.ulta.com/is/image/Ulta/wk4617_d_hero_promo_frag_multibrand?scl=1',
        link: {
          showInNewPage: true,
          name: 'Dynamic Link',
          linkText: '',
          label: null,
          url: '/fragrance?N=26wa',
          dataSlotPosition: '2_wk4617_d_hero_promo_frag_multibrand'
        }
      }
    ]
  }

  let component = mountWithIntl(
    <Provider store={ store }>
      <HeroCarouselMock { ...props } />
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'HeroCarousel' ).length ).toBe( 1 );
  } );


  it( 'the component should have reference to its child component', () => {
    expect( component.find( 'HeroCarousel' ).instance().sliderContainer ).toBeTruthy();
    expect( component.find( 'HeroCarousel' ).instance().innerSliderContainer ).toBeTruthy();
  } );

  it( 'check carouselAfterChange class function to be called', () => {
    let node = component.find( 'HeroCarousel' ).instance();
    node.carouselAfterChange();

    expect( node.props.setCurrentCarouselSlide ).toBeCalled();
  } );

  it( 'check carouselAfterChange class function to be called', () => {
    let node = component.find( 'HeroCarousel' ).instance();
    let customButton = node.carouselCustomPaging( 0 );

    expect( customButton.props.type ).toBe( 'button' );
    expect( customButton.props.className ).toBe( 'js_carousel-indicators-item' );
    expect( customButton.props.children.props.className ).toBe( 'sr-only' );
    // expect( customButton.props.children.props.children ).toBe( messages.carouselDotActiveTxt.defaultMessage );

  } );

  it( 'Should renders hero carousel', () => {
    expect( component.find( 'HeroCarousel Slider' ).length ).toBe( 1 );
  } );

  it( 'Should renders hero carousel navigation dots', () => {
    expect( component.find( 'HeroCarousel ul.slick-dots' ).length ).toBe( 1 );
    expect( component.find( 'HeroCarousel ul.slick-dots li' ).length ).toBe( 2 );
  } );

  it( 'Should renders play pause button', () => {
    expect( component.find( 'HeroCarousel button.carousel-indicators-play-pause' ).length ).toBe( 1 );
    expect( component.find( 'HeroCarousel button.carousel-indicators-play-pause span' ).at( 1 ).text() ).toBe( messages.carouselPauseTxt.defaultMessage );
  } );

  it( 'Check the click event for play pause button', () => {
    component.find( 'HeroCarousel button.carousel-indicators-play-pause' ).simulate( 'click' );
    let node = component.find( 'HeroCarousel' ).instance();
    expect( node.props.toggleAutoPlay ).toBeCalled();
  } );

  it( 'Check the click event for carousel dots button to pause the animation', () => {
    component.find( 'HeroCarousel button.js_carousel-indicators-item' ).at( 0 ).simulate( 'click' );
    let node = component.find( 'HeroCarousel' ).instance();
    expect( node.props.toggleAutoPlay ).toBeCalledWith( false );
  } );

  it( 'Should render the carousel with link when data is available', () => {
    expect( component.find( 'HeroCarousel a.Anchor' ).length ).toBe( 2 );
    expect( component.find( 'HeroCarousel a.Anchor' ).at( 0 ).props().href ).toContain( store.getState().heroCarousel.carouselList[0].link.url );
  } );

  it( 'Should render the carousel without link when link data is not available', () => {
    let store1 = configureStore( );
    store1.getState().heroCarousel = {
      settings: {
        dots: true,
        autoplay: true
      },
      currentSlide: 0,
      carouselList: [
        {
          colorHtmlTag: '#69c2b5',
          name: 'WK47_ROTATOR 1 ANASTASIA',
          imageAlt: '',
          url: '//images.ulta.com/is/image/Ulta/wk4717_d_hero_promo_makeup_anastasia?scl=1'
        },
        {
          colorHtmlTag: '#f7a3af',
          name: 'WK47_ROTATOR 2 ROBE',
          imageAlt: '',
          url: '//images.ulta.com/is/image/Ulta/wk4617_d_hero_promo_frag_multibrand?scl=1'
        }
      ]
    }

    let component1 = mountWithIntl(
      <Provider store={ store1 }>
        <HeroCarouselMock { ...props } />
      </Provider>
    );

    expect( component1.find( 'HeroCarousel a.Anchor' ).length ).toBe( 0 );
  } );

  it( 'Check isSlickClonedElemsHidden and aria-hidden attr set to be true after componentDidUpdate', () => {

    let props1 = {
      ...props,
      lazyLoad: false
    }

    let component2 = mountWithIntl(
      <Provider store={ store }>
        <HeroCarouselMock { ...props } />
      </Provider>
    );

    let node = component2.find( 'HeroCarousel' ).instance();
    expect( node.innerSliderContainer.length ).toBe( 2 );
    expect( node.isSlickClonedElemsHidden ).toBeFalsy();
    node.componentDidUpdate( props1 );
    expect( node.isSlickClonedElemsHidden ).toBeTruthy();
    expect( component2.find( 'HeroCarousel .slick-cloned.carousel-slide' ).html() ).toContain( 'aria-hidden' );

  } );

  it( 'Check the setAttribute, getAttribute and addEventListener function called in componentDidUpdate event', () => {
    let props1 = {
      ...props,
      lazyLoad: false
    }

    let component2 = mountWithIntl(
      <Provider store={ store }>
        <HeroCarouselMock { ...props } />
      </Provider>
    );

    const setAttributeMock = mockJestFn;
    const addEventListenerMock = mockJestFn;
    const getAttributeMock = mockJestFn;
    let node = component2.find( 'HeroCarousel' ).instance();
    node.innerSliderContainer = [
      {
        className:'slick-cloned',
        setAttribute:setAttributeMock,
        addEventListener:addEventListenerMock,
        getAttribute: getAttributeMock
      }
    ];
    node.componentDidUpdate( props1 );
    expect( setAttributeMock ).toBeCalledWith( 'aria-hidden', 'true' )
    expect( addEventListenerMock ).toBeCalled();

  } );

  it( 'Check focus addEventListener event called when focus event fired ', () => {
    let props1 = {
      ...props,
      lazyLoad: false
    }

    let component2 = mountWithIntl(
      <Provider store={ store }>
        <HeroCarouselMock { ...props } />
      </Provider>
    );

    let node = component2.find( 'HeroCarousel' ).instance();
    node.sliderOnFocusEventListener = mockJestFn;
    node.componentDidUpdate( props1 );

    let testCustEvent = new CustomEvent( 'focus' );
    node.innerSliderContainer[0].dispatchEvent( testCustEvent );
    expect( node.sliderOnFocusEventListener ).toBeCalled();

  } );

  it( 'check sliderOnFocusEventListener class function to be called with autoplay true flag', () => {

    let sliderReferenceMock = {
      innerSlider: {
        slickGoTo: mockJestFn
      }
    };

    let node = component.find( 'HeroCarousel' ).instance();
    node.sliderOnFocusEventListener( 1 );

    expect( node.props.toggleAutoPlay ).toBeCalledWith( false );
    expect( sliderReferenceMock.innerSlider.slickGoTo ).toBeCalled();
    expect( node.props.toggleAutoPlay ).toBeCalledWith( true );

  } );

  it( 'check sliderOnFocusEventListener class function to be called with autoplay false flag', () => {
    let store1 = store;
    store1.getState().heroCarousel = {
      ...store1.getState().heroCarousel,
      settings: {
        ...store1.getState().heroCarousel.settings,
        autoplay: false
      }
    }

    let component1 = mountWithIntl(
      <Provider store={ store1 }>
        <HeroCarouselMock { ...props } />
      </Provider>
    );

    let sliderReferenceMock = {
      innerSlider: {
        slickGoTo: mockJestFn
      }
    };

    let node = component1.find( 'HeroCarousel' ).instance();
    node.sliderOnFocusEventListener( 1 );

    expect( node.props.toggleAutoPlay ).toBeCalledWith( false );
    expect( sliderReferenceMock.innerSlider.slickGoTo ).toBeCalled();
    expect( node.props.toggleAutoPlay ).toBeCalledWith( false );

  } );

  it( 'should invoke autoplay and pause metod of innderSlider when playOrPauseCarousel method is invoked', () => {
    const sliderReferenceMock = {
      innerSlider:{
        autoPlay:jest.fn(),
        pause:jest.fn()
      }
    }
    component.find( 'HeroCarousel' ).instance().playOrPauseCarousel( true, sliderReferenceMock );
    expect( sliderReferenceMock.innerSlider.autoPlay ).toBeCalled();
    component.find( 'HeroCarousel' ).instance().playOrPauseCarousel( false, sliderReferenceMock );
    expect( sliderReferenceMock.innerSlider.pause ).toBeCalled();
  } );

  it( 'should invoke playOrPauseCarousel when play or pause is clicked', () => {
    jest.useFakeTimers();
    const playOrPauseCarouselMock = jest.fn();
    component.find( 'HeroCarousel' ).instance().playOrPauseCarousel = playOrPauseCarouselMock;
    component.update();
    component.find( 'HeroCarousel button.carousel-indicators-play-pause' ).simulate( 'click' );
    let node = component.find( 'HeroCarousel' ).instance();
    jest.runAllTimers();
    expect( playOrPauseCarouselMock ).toBeCalled();
  } );

  it( 'Check autoplay false should render pause button', () => {
    store.getState().heroCarousel = {
      ...store.getState().heroCarousel,
      settings: {
        ...store.getState().heroCarousel.settings,
        autoplay: false
      }
    }
    let component = mountWithIntl(
      <Provider store={ store }>
        <HeroCarouselMock { ...props } />
      </Provider>
    );

    expect( component.find( 'HeroCarousel button.carousel-indicators-play-pause span' ).at( 1 ).text() ).toBe( messages.carouselPlayTxt.defaultMessage );
  } );

  it( 'Should be display loader when carouselList is empty', () => {
    store.getState().heroCarousel = {
      carouselList: undefined
    }
    let component = mountWithIntl(
      <Provider store={ store }>
        <HeroCarouselMock { ...props } />
      </Provider>
    );

    expect( component.find( 'HeroCarousel .Loading__spinner' ).length ).toBe( 1 );
  } );

  it( 'mapDispatchToProps should dispatch the proper action', () => {
    const heroCarouselDispatch = mapDispatchToProps( dispatch );
    heroCarouselDispatch.toggleAutoPlay( true );
    heroCarouselDispatch.setCurrentCarouselSlide( 1 );

    expect( dispatch ).toHaveBeenCalledWith( toggleAutoPlay( true ) );
    expect( dispatch ).toHaveBeenCalledWith( setCurrentCarouselSlide( 1 ) );
  } );

} );
