import React from 'react';


const SVG = () => {

  return (
    <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'>
      <defs>
      </defs>
      <title>Circle-Check</title>
      <g data-name='Layer 2'>
        <g data-name='Layer 2'>
          <path d='M32,0A32,32,0,1,0,64,32,32,32,0,0,0,32,0ZM50,24.15,28.67,45.46a3.86,3.86,0,0,1-2.82,1.16A4,4,0,0,1,23,45.46l-9-9a4,4,0,1,1,5.59-5.62l6.25,6.24L44.39,18.54A4,4,0,0,1,50,24.15Z'/>
        </g>
      </g>
    </svg>
  )

}

export default SVG;