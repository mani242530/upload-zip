import React from 'react';

const SVG = () => {

  return (
    <svg viewBox='0 0 194 121'>
      <g>
        <g>
          <rect
            style={ { fill:'#0078a9' } }
            width='194'
            height='121'
            rx='5'
            ry='5'
          />
          <path
            style={ { fill:'#fff' } }
            d='M86.58,65,78.69,47.28H68.61V72.7L57.22,47.28H48.6L37.2,73.72h6.87l2.34-6h13l2.48,6H75V54l8.62,19.72h6l8.77-19.28V73.72h6.43V47.28H94.47ZM53,62H49L53,52.83v.29L56.92,62Z'
          />
          <path
            style={
              {
                fill:'#fff',
                fillRule:'evenodd'
              }
            }
            d='M145.31,60.06l4.67-5,6.82-7.74h-8.13l-7.31,8-7.3-8H108.49V73.5h24.83l7.74-8.62,7.6,8.76h8.13l-6.82-8Zm-15.48,8H115.07V62.84h14.32v-5H115.07V53h14.75l7.3,7Z'
          />
        </g>
      </g>
    </svg>
  )
}

export default SVG;
