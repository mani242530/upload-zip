
import React from 'react';


const SVG = () => {

  return (
    <svg viewBox='0 0 36.51 64.02'>
      <g>
        <path d='M35,29,7.31,1.25a4.28,4.28,0,1,0-6.06,6L26,32,1.25,56.71a4.28,4.28,0,0,0,6.06,6L35,35a4.4,4.4,0,0,0,1.25-3A4.25,4.25,0,0,0,35,29' transform='translate(0.26 0.29)'/>
      </g>
    </svg>
  )

}

export default SVG;

