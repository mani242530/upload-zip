import React from 'react';


const SVG = () => {

  return (
    <svg viewBox='0 0 64 36.26'>
      <g>
        <path d='M35,35,62.75,7.31a4.28,4.28,0,1,0-6-6.06L32,26,7.29,1.25a4.28,4.28,0,0,0-6,6.06L29,35a4.4,4.4,0,0,0,3,1.25A4.26,4.26,0,0,0,35,35Zm0,0'/>
      </g>
    </svg>
  )

}

export default SVG;
