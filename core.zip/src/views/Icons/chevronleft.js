
import React from 'react';


const SVG = () => {

  return (
    <svg viewBox='0 0 35.99 63.44'>
      <g>
        <path
          d='M1.25,35,28.94,62.7a4.28,4.28,0,0,0,6.06-6L10.3,32,35,7.29a4.28,4.28,0,0,0-6.06-6L1.25,29A4.4,4.4,0,0,0,0,32a4.26,4.26,0,0,0,1.25,3'
          transform='translate(0 -0.27)'
        />
      </g>
    </svg>
  )
}

export default SVG;
