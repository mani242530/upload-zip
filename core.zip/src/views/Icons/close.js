
import React from 'react';

const SVG = () => {

  return (
    <svg viewBox='0 0 63.57 63.57' role='img' aria-label='Close'>
      <title>Close</title>
      <desc>Large black X</desc>
      <g>
        <path d='M62.75,56.7,38,32,62.75,7.29a4.28,4.28,0,0,0-6.06-6L32,26,7.31,1.26a4.28,4.28,0,0,0-6.06,6L26,32,1.25,56.71a4.27,4.27,0,0,0,6.06,6L32,38,56.69,62.7a4.28,4.28,0,0,0,6.06-6' transform='translate(-0.17 -0.24)'/>
      </g>
    </svg>
  )

}

export default SVG;
