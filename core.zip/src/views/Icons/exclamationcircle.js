import React from 'react';

const SVG = () => {

  return (
    <svg viewBox='0 0 63.5 63.5' role='img' aria-label='information'>
      <g >
        <g >
          <path d='M31.75,0A31.75,31.75,0,1,0,63.5,31.75,31.79,31.79,0,0,0,31.75,0Zm0,51A4.29,4.29,0,1,1,36,46.74,4.29,4.29,0,0,1,31.75,51Zm3.07-16.59a3.07,3.07,0,1,1-6.13,0L27.2,17a4.55,4.55,0,1,1,9.09,0Z' />
        </g>
      </g>
    </svg>
  )
}

export default SVG;
