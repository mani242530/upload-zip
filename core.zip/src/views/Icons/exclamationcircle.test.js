import React from 'react';
import ExclamationCircleSVG from './exclamationcircle';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<ExclamationCircleSVG />', () => {
  const component = mountWithIntl( <ExclamationCircleSVG /> );
  it( 'renders without crashing', () => {
    expect( component.find( 'svg' ).length ).toBe( 1 );
  } );
  it( 'svg should have the aria-label property', () => {
    expect( component.find( 'svg' ).props()['aria-label'] ).toBe( 'information' );
    expect( component.find( 'svg' ).props()['role'] ).toBe( 'img' );
  } );
} );

