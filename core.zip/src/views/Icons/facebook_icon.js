import React from 'react';

const SVG = ( props ) => {

  return (
    <svg viewBox='0 0 64 64' role='img' aria-label='Facebook logo'>
      <title>Share on Facebook</title>
      <desc>{ props.description }</desc>
      <g >
        <path d='M32,0A32,32,0,1,0,64,32,32,32,0,0,0,32,0m9.81,18.14h-3.9c-3.06,0-3.65,1.46-3.65,3.59v4.71h7.3l-1,7.38H34.25V52.74H26.63V33.82H20.27V26.44h6.37V21c0-6.31,3.85-9.75,9.49-9.75a52.28,52.28,0,0,1,5.69.29Z'/>
      </g>
    </svg>
  )
}

export default SVG;

