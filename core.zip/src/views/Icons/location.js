import React from 'react';

const SVG = () => {

  return (
    <svg viewBox='0 0 48 64'>
      <g className='b'>
        <path d='M24,0A24,24,0,0,0,0,24C0,40,24,64,24,64S48,40,48,24A24,24,0,0,0,24,0m0,8A16,16,0,1,1,8,24,16,16,0,0,1,24,8'/>
      </g>
    </svg>
  )
}

export default SVG;
