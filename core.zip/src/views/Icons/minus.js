import React from 'react';

const SVG = () => {

  return (
    <svg viewBox='0 0 64 8'>
      <path
        d='M432.56,275a4,4,0,0,0,0-8H379.15a4,4,0,0,0,0,8Z'
        transform='translate(-374 -267)'
      />
    </svg>
  )
}

export default SVG;
