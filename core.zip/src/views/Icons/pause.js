
import React from 'react';

const SVG = () => {

  return (
    <svg viewBox='0 0 26 36' role='img'>
      <g>
        <g>
          <path
            d='M17.44,31.84a4.28,4.28,0,0,0,8.56,0V4.16a4.28,4.28,0,0,0-8.55,0Z'
          />
          <path
            d='M0,31.84A4.22,4.22,0,0,0,4.28,36a4.24,4.24,0,0,0,4.28-4.18V4.16A4.21,4.21,0,0,0,4.28,0,4.24,4.24,0,0,0,0,4.18Z'
          />
        </g>
      </g>
    </svg>
  );

}

export default SVG;
