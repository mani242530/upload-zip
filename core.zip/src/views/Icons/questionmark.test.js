import React from 'react';
import QuestionMark from './questionmark';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<QuestionMark />', () => {
  const props = {
    description : 'The location your items ship from can change between the time your order is placed and when it ships, which may result in a sales tax charge that differs from the original estimate.'
  }
  const component = mountWithIntl( <QuestionMark { ...props } /> );
  it( 'renders without crashing', () => {
    expect( component.find( 'svg' ).length ).toBe( 1 );
  } );
  it( 'svg should have the aria-label property', () => {
    expect( component.find( 'svg' ).props()['aria-label'] ).toBe( 'Question Mark' );
  } );
} );

