import React from 'react';

const SVG = () => {

  return (
    <svg viewBox='0 0 63.18 60.09' role='img' aria-hidden>
      <title>star</title>
      <polygon points='31.59 0 21.83 19.78 0 22.95 15.8 38.35 12.07 60.09 31.59 49.83 51.12 60.09 47.39 38.35 63.18 22.95 41.35 19.78 31.59 0'/>
    </svg>
  )
}

export default SVG;
