import React from 'react';

const SVG = () => {

  return (
    <svg viewBox='0 0 64.1 60.99'>
      <g>
        <g>
          <path d='M32,0,41.9,19.92,64.1,23.3l-16,15.5L51.86,61,32.15,50.41,12.24,61,16,38.8,0,23.3l22-3.38L32,0'/>
        </g>
      </g>
    </svg>
  )
}

export default SVG;
