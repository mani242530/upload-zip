/**
 * Image
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import Loader from '../Loader/Loader';
import './Image.css';
import { ModalContext } from '../ModalWrapper/ModalWrapper';

const propTypes = {
  preloadSrc: PropTypes.string,
  src: PropTypes.string.isRequired,
  alt: PropTypes.string.isRequired,
  width: PropTypes.oneOfType( [
    PropTypes.number,
    PropTypes.string
  ] ),
  height: PropTypes.number,
  className: PropTypes.string,
  lazyLoad: PropTypes.bool,
  scale: PropTypes.string,
  rootMargin: PropTypes.string,
  threshold: PropTypes.number,
  root: PropTypes.object
}

const defaultProps = {
  preloadSrc: '',
  lazyLoad: process.env.NODE_ENV !== 'test',
  // If the image gets within 50px in the Y axis, start the download.
  rootMargin:'50px 50px',
  root : null,
  threshold: 0.01
}


// The observer for the images on the page



class Image extends Component{

  observer = undefined;

  imageRef = undefined;

  constructor( props ){
    super( props );
    this.state = {
      displayImage:false
    }
    this.observeIntersection = this.observeIntersection.bind( this );
  }

  onIntersection =( entries ) => {
    // Loop through the entries
    entries.forEach( entry => {
    // Are we in viewport?
      if( entry.intersectionRatio > 0 ){
        // Stop watching and load the image
        this.observer.unobserve( entry.target );
        this.setState( { displayImage:true } );
        // preloadImage( entry.target );
      }
    } );
  }

  observeIntersection = () =>{

    if( !this.props.lazyLoad || !( 'IntersectionObserver' in window ) || this.context?.type === 'Modal' ){
      this.setState( { displayImage:true } );
    }
    else {
      const config = {
        root:this.props.root,
        rootMargin:this.props.rootMargin,
        threshold:this.props.threshold
      }
      this.observer = new IntersectionObserver( this.onIntersection, config );
      // It is supported, load the images
      this.observer.observe( this.imageRef );
    }
  }

  componentDidMount(){
    this.observeIntersection();
  }

  render(){

    const {
      src,
      alt,
      width,
      height,
      scale
    } = this.props;
    const props = this.props;
    const className = props.className ? props.className : '';

    const s7Presets = ['scl=1', 'scl=2', 'scl=3', '$tn$', '$md$', '$lg$', '$xl$', '$detail$',
      '$sm$', '$testviewer$', '$mm_large$', '$s7product$', 'swatch', '$tiny$',
      '50px', '$fbshare$', '$PNG$', '$Campaign$', '$sharpening$', '$DC$',
      '$png-alpha$', '$app-sq-1200$', '$app-sq-600$'
    ];

    let url = src;

    if( props.scale ){
      for ( let i = 0; i < s7Presets.length; i++ ){
        let preset = '?' + s7Presets[i];
        if( url.includes( preset ) ){
          url = url.replace( preset, '' );
        }
      }
      url = `${ url }?${ scale }`;
    }

    return (
      <div
        className={
          classNames( {
            'Image': true,
            [className]: className
          } )
        }
        ref={ ( elem )=>{
          this.imageRef = elem;
        } }
      >
        { this.state.displayImage &&
          (
            <Loader handleLoadComplete={ props.handleLoadComplete }>
              <img
                src={ url }
                alt={ alt }
                width={ width }
                height={ height }
              />
            </Loader>
          )
        }
      </div>
    );
  }
}

Image.propTypes = propTypes;
Image.defaultProps = defaultProps;
Image.contextType = ModalContext;

export default Image;
