import React from 'react';
import ReactDOM from 'react-dom';
import { shallow, mount } from 'enzyme';
import Image from './Image';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
import ModalWrapper from '../ModalWrapper/ModalWrapper';

describe( '<Image />', () => {
  beforeEach( ()=> {


  } );

  it( 'renders without crashing', () => {
    const div = document.createElement( 'div' );
    ReactDOM.render( <Image src='' alt='' lazyLoad={ true }/>, div );
  } );


  describe( 'setting properties', () => {

    it( 'should concat the class name when a className is passed', () => {
      let component = renderImage( {
        src:'', alt:'', className:'mainImage', lazyLoad:true
      } );
      expect( component.find( 'div' ).at( 0 ).hasClass( 'Image mainImage' ) ).toBeTruthy();
    } );

    it( 'should set the src attribute on the img tag to match the prop: src', ()=> {
      let component = renderImage( {
        src:'tmp', alt:'', className:'mainImage', lazyLoad:true
      } );
      expect( component.find( 'img' ).prop( 'src' ) ).toBe( 'tmp' );
    } );

    it( 'should set the alt attribute on the img tag to match the prop: alt', ()=> {
      let component = renderImage( {
        src:'', alt:'test', className:'mainImage', lazyLoad:true
      } );
      expect( component.find( 'img' ).prop( 'alt' ) ).toBe( 'test' );
    } );

    it( 'should set the height attribute on the img tag to match the prop: height', ()=> {
      let component = renderImage( {
        src:'', alt:'', height:20, className:'mainImage', lazyLoad:true
      } );
      expect( component.find( 'img' ).prop( 'height' ) ).toBe( 20 );
    } );

    it( 'should call handleLoadComplete ', ()=> {
      const handleLoadComplete = jest.fn();
      let component = renderImage( {
        src:'', alt:'', height:20, className:'mainImage', lazyLoad:true, handleLoadComplete
      } );
      expect( component.find( 'Loader' ).prop( 'handleLoadComplete' ) ).toBe( handleLoadComplete );
    } );

    it( 'should set the width attribute on the img tag to match the prop: width', ()=> {
      let component = renderImage( {
        src:'', alt:'', width:20, className:'mainImage', lazyLoad:true
      } );
      expect( component.find( 'img' ).prop( 'width' ) ).toBe( 20 );
      component = renderImage( {
        src:'', alt:'', width:'100%', className:'mainImage', lazyLoad:true
      } );
      expect( component.find( 'img' ).prop( 'width' ) ).toBe( '100%' );
    } );

    it( 'should invoke observeIntersection when componentDidMount is called', ()=> {
      const observeIntersectionMock = jest.fn();
      let component = mountWithIntl( <Image lazyLoad={ false } /> );
      component.find( 'Image' ).instance().observeIntersection = observeIntersectionMock;
      component.find( 'Image' ).instance().componentDidMount();
      expect( observeIntersectionMock ).toBeCalled();
    } );

    it( 'should set displayImage as true when onIntersection is invoked', ()=> {
      const entries = [{
        intersectionRatio:0.1,
        target:{
          image:{
            src:'test.jpg'
          }
        }
      }];
      const unobserveMock = jest.fn();
      let component = mountWithIntl( <Image lazyLoad={ true } /> );
      component.find( 'Image' ).instance().observer = {
        unobserve:unobserveMock
      }
      expect( component.find( 'Image' ).instance().state.displayImage ).toBe( false );
      component.find( 'Image' ).instance().onIntersection( entries );
      expect( unobserveMock ).toHaveBeenCalledWith( entries[0].target );
      expect( component.find( 'Image' ).instance().state.displayImage ).toBe( true );
    } );

    it( 'should observe the image element when observeIntersection is invoked', ()=> {
      const observeMock = jest.fn();
      window.IntersectionObserver = function(){
      }
      window.IntersectionObserver.prototype.observe = observeMock;
      let component = mountWithIntl( <Image lazyLoad={ true } /> );
      expect( observeMock ).toBeCalled();
    } );

    it( 'should set the displayImage as true if the image is loaded inside a modal even if lazyLoad is true', ()=> {
      let component = mountWithIntl( <ModalWrapper isOpen={ true }><Image lazyLoad={ true } /></ModalWrapper> );
      expect( component.find( 'Image' ).instance().state.displayImage ).toBe( true );
    } );

    it( 'should set the displayImage as true observeIntersection is invoked and when IntersectionObserver is not defined', ()=> {
      delete window.IntersectionObserver;
      let component = mountWithIntl( <Image lazyLoad={ false } /> );
      expect( component.find( 'Image' ).instance().state.displayImage ).toBe( true );
    } );

    it( 'should set the displayImage as true observeIntersection is invoked and when lazyLoad is false', ()=> {
      let component = mountWithIntl( <Image lazyLoad={ false } /> );
      expect( component.find( 'Image' ).instance().state.displayImage ).toBe( true );
    } );
  } );

  const renderImage = ( props ) => {
    let component = mountWithIntl( <Image { ...props }/> );
    component.find( 'Image' ).instance().setState( { displayImage:true } );
    component.update();
    return component;
  }




} );
