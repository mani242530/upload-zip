/**
 * InputField
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './InputField.css';


import classNames from 'classnames';

import { Field } from 'redux-form';
import reduxFormActions from 'redux-form/es/actions';
import VMasker from 'vanilla-masker';
import isUndefined from 'lodash/isUndefined';
import has from 'lodash/has';
import cloneDeep from 'lodash/cloneDeep';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faQuestionCircle } from '@fortawesome/pro-solid-svg-icons/faQuestionCircle';
import { faTimesCircle } from '@fortawesome/pro-solid-svg-icons/faTimesCircle';
import { formatMessage } from '../Global/Global';
import messages from './InputField.messages';
import Button from '../Button/Button';
import Anchor from '../Anchor/Anchor';
import Text from '../Text/Text';
import { fireAnalyticsEvent, updateDataLayer } from '../../utils/omniture/omniture';
import {
  removeSpecialCharacters, maskFirstFiveSSN
} from '../../utils/formatters/formatters'

import {
  toggleInputFieldDisplay
} from '../../events/forms/forms.events';

import ResponseMessages from '../ResponseMessages/ResponseMessages';
import { checkIfAndroidChrome } from '../../utils/device_detection/device_detection';

const propTypes = {
  type: PropTypes.oneOf( ['hidden', 'text', 'number', 'password', 'email', 'tel', 'date'] ),
  autoComplete: PropTypes.string,
  autoCorrect: PropTypes.string,
  spellCheck: PropTypes.bool,
  defaultPlaceholder:PropTypes.bool,
  name: PropTypes.string.isRequired,
  formName: PropTypes.string,
  trackAnalytics: PropTypes.bool,
  value: PropTypes.string,
  label: PropTypes.string,
  tabIndex: PropTypes.number,
  formatter: PropTypes.object,
  maxLength: PropTypes.number,
  helpmessage: PropTypes.object,
  hintText: PropTypes.string,
  hintTextLink: PropTypes.string,
  placeholder: PropTypes.string,
  autoCapitalize: PropTypes.bool,
  showMaskedValue : PropTypes.bool,
  disablePaste: PropTypes.bool,
  showValidationMessage: PropTypes.bool // Show or Hide Response Message component
}

const defaultProps = {
  type: 'text',
  autoComplete: 'on',
  autoCorrect: 'on',
  spellCheck: true,
  showMaskedValue: false,
  showValidationMessage: true,
  defaultPlaceholder:false
}


/* Class
 * @extends React.Component
 */
class InputField extends Component{

  /**
   * Create a InputField
   */

  constructor( props ){
    super( props );

    this.state = {
      expandHintText: false,
      isValidErrorToDisplay: false
    };

    this.maskInput = this.maskInput.bind( this );
    this.renderInputField = this.renderInputField.bind( this );
    this.expandHintText = this.expandHintText.bind( this );
    this.isSsnFieldToMask = this.isSsnFieldToMask.bind( this );
    this.focus = this.focus.bind( this );

    if( this.isSsnFieldToMask() ){
      this.ssnValue = '';
      this.ssnMask = '';
      this.ssnShowMask = true;
      this.ssnHistory = [];
    }
  }

  instanceOnChangeEvt = undefined;

  focus(){
    this.input.focus();
  }

  /*
   *The below logic will ensure that the 'value' property will be set to the redux form field, on component load
   */
  componentDidMount(){
    if( this.props.value && this.props.value.length > 0 ){
      let nVal = this.maskInput( this.props.value );
      this.instanceOnChangeEvt( nVal );
    }
  }

  /*
   *if we are using 'value' property of the component to set the value of the input, below logic ensure that
   * the input field gets the new value whenever there is a change in the value property.
   * This will ensure that the input gets the new value from the redxus store whenever the field is wired to a property in the redux store.
   * Should accept empty value so that clearing a value clears the same from the redxus store
  */
  componentDidUpdate( prevProps ){
    let nVal = this.props.value;
    if( prevProps.value !== this.props.value ){
      if( this.props.value && this.props.value.length > 0 ){
        nVal = this.maskInput( this.props.value );
      }
      this.instanceOnChangeEvt( nVal );
    }
  }

  componentWillUnmount(){
    if( this.props.clearOnUnmount ){
      this.props.clearOnUnmount( this.props.name );
    }
  }

  isSsnFieldToMask(){
    return ( has( this.props.formatter, 'maskLastFourSSN' ) );
  }

  maskInput( val ){
    const {
      formatter
    } = this.props;

    let data = val;

    if( formatter ){
      switch ( true ){
        case has( formatter, 'pattern' ):
          return VMasker.toPattern( data, formatter.pattern );

        case has( formatter, 'money' ):
          if( data.length > 1 ){
            let index = data.lastIndexOf( '.' );
            if( data.substring( index ).length > 2 ){
              if( !checkIfAndroidChrome() ){
                data = removeSpecialCharacters( data.substring( 0, index ) + data.substring( index + 3 ) );
              }
              else {
                data = index === -1 ? removeSpecialCharacters( data.substring( index ) ) : removeSpecialCharacters( data.substring( 0, index ) );
              }
              data = data.replace( /\D/g, '' );
            }
            else {
              data = removeSpecialCharacters( data.substring( 0, index - 1 ) );
              data = data.replace( /\D/g, '' );
            }
          }
          if( data === '' && checkIfAndroidChrome() ){
            return
          }
          else {
            return `$${data.replace( /(\d)(?=(\d{3})+(?!\d))/g, '$1,' )}.00`;
          }

        case has( formatter, 'creditcard' ):
          if( data ){
            if( data.match( /^3[47]/ ) ){
              return VMasker.toPattern( data, '9999 999999 99999' );
            }
            else {
              return VMasker.toPattern( data, '9999 9999 9999 9999' );
            }
          }

        case has( formatter, 'expiry' ):
          if( data ){
            if( data.length === 2 && data.match( /^[0-9]{2}/ ) ){
              return data + '/'
            }
            else {
              return VMasker.toPattern( data, '99/99' );

            }
          }
      }
    }
    return data;

  }

  expandHintText( e ){
    this.setState( { expandHintText: !this.state.expandHintText } );
  }

  renderInputField( props ){
    const {
      input,
      label,
      formName,
      trackAnalytics,
      formatter,
      placeholder,
      tabIndex,
      handleBlur,
      disablePaste,
      handleChange,
      syncFieldsForClear,
      clearFields,
      maskedToggleTarget,
      showMaskedValue,
      warnMethod,
      name,
      meta: {
        touched, error, warning, dispatch, form, active, instructionalText
      },
      ...custom
    } = props;
    this.instanceOnChangeEvt = input.onChange;
    const resetVal = e => {
      if( syncFieldsForClear ){
        syncFieldsForClear .map( val => {
          dispatch(
            {
              type: '@@redux-form/CHANGE',
              meta: {
                form,
                field: val,
                touch: false,
                persistentSubmitErrors: false
              },
              payload: ''
            }
          );
        } )

      }
      else {
        input.onChange( '' );
        if( handleChange ){
          handleChange( '' );
        }
        if( this.isSsnFieldToMask() ){
          dispatch( reduxFormActions.change( form, 'virtualSSN', '' ) );
          this.ssnHistory = [];
        }
      }
      this.focus();
    }

    const onBlur = e => {
      let val;
      if( checkIfAndroidChrome() ){
        val = this.maskInput( e.target.value ).trim();
      }
      else {
        val = e.target.value.trim();
      }

      if( this.isSsnFieldToMask() ){
        if( checkIfAndroidChrome() ){
          if( this.ssnShowMask ){
            val = this.ssnMask;
          }
          else {
            val = this.maskInput( this.ssnValue );
          }
        }
        else {
          val = e.target.value;
        }

      }

      var eventObject = cloneDeep( e );
      eventObject.target.value = val;
      input.onChange( val );
      input.onBlur( eventObject );

      if( handleBlur ){
        handleBlur();
      }

      this.setState( {
        isValidErrorToDisplay: true
      } );
    }

    const onChange = e => {

      if( this.isSsnFieldToMask() ){

        let passCharacterRegex = '\u{2022}'

        let ssnData = maskFirstFiveSSN( e.target.value, this.ssnShowMask, this.ssnHistory )

        this.ssnValue = ssnData.ssnValue;
        this.ssnHistory = ssnData.ssnHistory;
        this.ssnMask = ssnData.ssnMask;



        if( this.ssnShowMask ){

          if( checkIfAndroidChrome() ){
            input.onChange( this.ssnMask.replace( new RegExp( `[^\\d\\${ passCharacterRegex }]`, 'g' ), '' ) );
          }
          else {
            input.onChange( this.ssnMask );
          }
        }
        else if( checkIfAndroidChrome() ){
          if( e.target.value.match( /\d/g ).length <= 9 ){
            input.onChange( this.ssnValue );
          }
        }
        else {
          input.onChange( this.maskInput( this.ssnValue ) )
        }
        dispatch( reduxFormActions.change( form, 'virtualSSN', this.maskInput( this.ssnValue ) ) );

      }
      else if( checkIfAndroidChrome() ){
        if( has( this.props, 'formatter.pattern' ) ){

          let formatterValueLength = removeSpecialCharacters( this.props.formatter.pattern ).length;
          let textCharValueLength = removeSpecialCharacters( e.target.value ).length;

          if( textCharValueLength <= formatterValueLength ){
            input.onChange( removeSpecialCharacters( e.target.value ) );
          }
        }
        else {
          input.onChange( e.target.value );
        }
        if( handleChange ){
          handleChange( e.target.value );
        }

      }
      else {
        let val = this.maskInput( e.target.value );
        input.onChange( val );
        if( handleChange ){
          handleChange( val );
        }
      }

      this.setState( {
        isValidErrorToDisplay: false
      } );

    }

    const onPaste = e => {
      if( this.props.disablePaste ){
        e.preventDefault();
        return false
      }
    }

    const onFocus = e => {
      // if the inputfield has a value on focus we show the clear icon immediately
      this.input.focus();

      if( this.props.onFocus ){
        this.props.onFocus( e );
      }
      input.onFocus( e );

      /** Analytics code **/
      if( this.props.trackAnalytics ){

        updateDataLayer(
          {
            'globalPageData': {
              'navigation': {
                'checkoutFormLocation': this.props.formName + ':' + this.props.label
              }
            }
          }
        );

        fireAnalyticsEvent( 'checkout-form-field-change', this.props.formName + ':' + this.props.label );

      }


      // if the input has a warning message we will manually force it to show on the field being active
      if( this.props.warn ){
        dispatch(
          {
            type: '@@redux-form/UPDATE_SYNC_WARNINGS',
            meta: {
              form// the form that this input is mounted on
            },
            payload: {
              syncWarnings: {
                [input.name]: warnMethod[0]( ' ' )// the inputfield and the warning message
              }
            }
          }
        );
      }

      const {
        formatter
      } = this.props;

      if( formatter && has( formatter, 'money' ) ){
        if( ( isUndefined( input.value ) || input.value === '' ) && !checkIfAndroidChrome() ){
          input.onChange( '$.00' );
        }
      }

      this.setState( {
        isValidErrorToDisplay: true
      } );
    }

    const handleShowHideClick = e => {
      e.preventDefault();

      if( this.isSsnFieldToMask() ){
        this.ssnShowMask = !this.ssnShowMask;
        if( this.ssnShowMask ){
          input.onChange( this.ssnMask );
        }
        else {
          input.onChange( this.maskInput( this.ssnValue ) );
        }
      }

      if( maskedToggleTarget ){
        dispatch( toggleInputFieldDisplay( maskedToggleTarget ) );
      }

    }

    const getInputType = ( ) => {

      if( isUndefined( this.props.maskedToggleTarget ) || this.isSsnFieldToMask() ){
        return this.props.type;
      }
      else {
        return this.props.showMaskedValue ? 'text' : this.props.type ;
      }

    }

    return (
      <div
        className={
          classNames(
            'InputField', {
              'InputField--info': active && !error,
              'InputField--error': touched && error && !active
            }
          )
        }
      >
        <div
          className={
            classNames(
              'InputField__content', {
                'InputField__content--active': active || !active && ( input.value && input.value !== '' ),
                'InputField__content--showHintText': this.props.hintTextMessage
              }
            )
          }
        >

          <label
            className={
              classNames(
                'InputField__label', {
                  'InputField__label--active': active || !active && ( input.value && input.value !== '' )

                }
              )
            }
            htmlFor={ this.props.name }
            aria-hidden={ true }
          >
            { label }
          </label>
          <div className='InputField__formControls'>

            <input
              ref={ ( input ) => this.input = input }
              className={
                classNames(
                  'form-control', {
                    'InputField--capitalize': this.props.autoCapitalize
                  },
                  {
                    'form-control--active': active || !active && ( input.value && input.value !== '' )
                  }
                )
              }
              name={ this.props.name }
              id={ this.props.name }
              autoComplete={ this.props.autoComplete }
              autoCorrect={ this.props.autoCorrect }
              spellCheck={ this.props.spellCheck }
              value={ input.value }
              tabIndex={ this.props.tabIndex }
              onFocus={ onFocus }
              onPaste={ onPaste }
              onBlur={ onBlur }
              onChange={ onChange }
              type={ getInputType() }
              aria-label={ label }
              // display placeholder if field is active or if defaultPlaceholder is true
              { ...( ( active || this.props.defaultPlaceholder ) && placeholder && { placeholder: placeholder } ) }
              { ...( this.props.maxLength && { maxLength: this.props.maxLength } ) }
            />

            { ( () => {
              return (
                <div
                  className={
                    classNames( 'InputField__actions', {} )
                  }
                >
                  { input.value && input.value !== '' &&
                    (
                      <Button
                        className={
                          classNames(
                            'InputField__Action--clear', {
                              'InputField__Action--hidden': !active
                            }
                          )
                        }
                        btnType='button'
                        btnOption='no-style'
                        tabIndex={ -1 }
                        ariaLabel={ formatMessage( messages.clear ) }
                        onMouseDown={ resetVal }
                      >
                        <FontAwesomeIcon
                          icon={ faTimesCircle }
                          title={ formatMessage( messages.clear ) }
                          className='fas fa-times-circle'
                        />
                      </Button>
                    )
                  }

                  { ( () => {

                    if( ( this.props.type === 'password' || this.isSsnFieldToMask() ) && ( input.value && input.value !== '' ) ){
                      const label = !this.props.showMaskedValue ? formatMessage( messages.Show ) : formatMessage( messages.hide );
                      return (
                        <div
                          className='InputField__Action--showhide'
                          aria-label={ label }
                          onMouseDown={ handleShowHideClick }
                        >
                          { label }
                        </div>
                      )
                    }
                  } )() }

                </div>
              )

            } )() }
          </div>
        </div>
        {
          this.props.hintTextMessage &&
            <span className='tooltip'>
              <FontAwesomeIcon
                icon={ faQuestionCircle }
                title={ this.props.hintTextMessage }
                className='fas fa-question-circle'
              />
              <div className='tooltip__hide' role='tooltip'>
                <Text type='caption'>{ this.props.hintTextMessage }</Text>
              </div>
            </span>
        }
        { ( () => {
          // showValidationMessage flag is added to render the InputField border and background in red color without a field level response message
          if( touched && ( props.error || error ) && ( !active || this.state.isValidErrorToDisplay ) && this.props.showValidationMessage ){
            return (
              <ResponseMessages
                message={ props.error || error }
                fieldName={ label }
              />
            )
          }
          else if( warning ){
            return (
              <ResponseMessages
                messageType='warning'
                message={ warning }
              />
            )
          }
          else if( touched && this.props.instructionalText ){
            return (
              <div className='InputField__instructionalText'>
                { this.props.instructionalText }
              </div>
            )
          }
        } )() }

        { ( () => {
          if( this.props.hintText ){
            return (
              <div className='InputField__hintText'>
                { ( () => {
                  if( this.state.expandHintText ){
                    return (
                      <div className='InputField__hintTextMessage'>
                        { this.props.hintTextExpandMsg }
                      </div>
                    )
                  }
                } )() }
                { ( () => {
                  return (
                    <Anchor
                      url={ this.props.hintTextLink ? this.props.hintTextLink : '#' }
                      { ...( this.props.hintTextExpandMsg && { clickHandler: this.expandHintText } ) }
                      className={
                        classNames(
                          'hintTextBtn', {
                            'hintTextBtn--close': this.state.expandHintText
                          }
                        )
                      }
                    >
                      { !this.state.expandHintText ? this.props.hintText : this.props.hintTextCloseBtnTxt }
                    </Anchor>
                  )
                } )() }
              </div>
            )
          }
        } )() }
      </div>
    )
  }

  /**
   * Renders the InputField component
   */
  render(){
    const {
      type,
      name,
      errorMsg,
      label,
      tabIndex,
      placeholder,
      validate,
      warn,
      formatter,
      handleBlur,
      handleChange,
      syncFieldsForClear,
      clearFields,
      showMaskedValue,
      maskedToggleTarget,
      instructionalText,
      clearOnUnmount
    } = this.props;

    return (
      <Field
        name={ name }
        label={ label }
        placeholder={ placeholder }
        formatter={ formatter }
        type={ type }
        tabIndex={ tabIndex }
        component={ this.renderInputField }
        { ...( instructionalText && { instructionalText } ) }
        { ...( handleBlur && { handleBlur } ) }
        { ...( handleChange && { handleChange } ) }
        { ...( syncFieldsForClear && { syncFieldsForClear } ) }
        { ...( clearFields && { clearFields } ) }
        { ...( showMaskedValue && { showMaskedValue } ) }
        { ...( maskedToggleTarget && { maskedToggleTarget } ) }
        { ...( warn && { warnMethod: warn } ) }
        { ...( validate && { validate } ) }
        { ...( errorMsg && { error:errorMsg } ) }
        { ...( this.props.hintTextExpandMsg && { expandHintText: this.state.expandHintText } ) }
      />
    );
  }
}

InputField.propTypes = propTypes;
InputField.defaultProps = defaultProps;

export default InputField;
