/*
 * InputField Messages
 *
 * This contains all the text for the InputField component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.InputField.header',
    defaultMessage: 'This is the InputField component !'
  },
  cancel: {
    id: 'i18n.InputField.cancel',
    defaultMessage: 'CANCEL & RETURN CHECKOUT'
  },
  Show: {
    id: 'i18n.InputField.show',
    defaultMessage: 'SHOW'
  },
  hide: {
    id: 'i18n.InputField.hide',
    defaultMessage: 'HIDE'
  },
  clear: {
    id: 'i18n.InputField.clear',
    defaultMessage: 'Clear'
  }
} );
