import React from 'react';
import { reduxForm } from 'redux-form';
import { Provider } from 'react-redux';
import InputField from './InputField';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';
import { checkIfAndroidChrome } from '../../utils/device_detection/device_detection';

jest.mock( './../../utils/device_detection/device_detection', () =>{
  return {
    checkIfAndroidChrome: jest.fn( () => true ),
    isServer: jest.fn( () => true )
  }
} );

jest.mock( 'lodash/cloneDeep', () => {
  return ( e ) => {
    return {
      target : {
        value : e.target.value
      }
    }
  }
} );


const store = configureStore( );
const Decorator = reduxForm( { form:'testForm' } )( InputField );

const renderInput = Field => {
  const FormElement = reduxForm( { form:'testForm' } )( Field );
  return mountWithIntl(
    <Provider store={ store }>
      <FormElement name='InputField'/>
    </Provider>
  );
}
describe( '<InputField />', () => {


  let component;
  component = mountWithIntl(
    <Provider store={ store }>
      <Decorator name='InputField'/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    const El = renderInput( ()=> {
      return (
        <InputField />
      )
    } )
    expect( El.find( 'InputField' ).length ).toBe( 1 );
  } );

  it( 'should have a child input field', () => {
    expect( component.find( 'input' ).length ).toBe( 1 );
  } );

  describe( 'Input props', () => {
    it( 'the type is set by the prop', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator type='text' name='InputField'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().type ).toBe( 'text' );

      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator type='number' name='InputField'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().type ).toBe( 'number' );

      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator type='password' name='InputField'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().type ).toBe( 'password' );

      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator type='email' name='InputField'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().type ).toBe( 'email' );
    } );


    it( 'autocomplete is on', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator autoComplete='on' name='InputField'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().autoComplete ).toBe( 'on' );
    } );

    it( 'autocorrect is on', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator autoCorrect='on' name='InputField'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().autoCorrect ).toBe( 'on' );
    } );

    it( 'spellcheck is true', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator spellCheck={ true } name='InputField'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().spellCheck ).toBe( true );
    } );
    it( 'defaultPlaceholder is true', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator defaultPlaceholder={ true } name='InputField' placeholder='Search'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().placeholder ).toBe( 'Search' );
    } );

    it( 'name is present', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator name='InputField'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().name ).toBe( 'InputField' );
    } );

    it( 'value should be set', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator name='InputField' value='Ulta'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().value ).toBe( 'Ulta' );
    } );


    it( 'label should be set', () => {
      var label = mountWithIntl(
        <Provider store={ store }>
          <Decorator name='InputField' label='Ulta'/>
        </Provider>
      ).find( 'label' );
      expect( label.text() ).toBe( 'Ulta' );
    } );

    it( 'tabIndex should be set', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator name='InputField' tabIndex={ 1 }/>
        </Provider>
      ).find( 'input' );
      expect( input.props().tabIndex ).toBe( 1 );
    } );

    it( 'maxLength should be set', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator name='InputField' maxLength={ 10 }/>
        </Provider>
      ).find( 'input' );
      expect( input.props().maxLength ).toBe( 10 );
    } );

    it( 'aria-label should be set when label is given', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator name='InputField' label='Ulta'/>
        </Provider>
      ).find( 'input' );
      expect( input.props()['aria-label'] ).toBe( 'Ulta' );
    } );

    it( 'should render error message if there is any error ', () => {
      let component2 = mountWithIntl(
        <Provider store={ store }>
          <Decorator
            name='couponName'
            errorMsg='test error'
          />
        </Provider>
      );
      let input = component2.find( 'InputField' );
      input.props().touch( 'testForm', 'couponName' );
      component2.update();
      expect( component2.find( 'ResponseMessages' ).text() ).toBe( 'test error' );
    } );

    it( 'should render error message if there is any error when input field is not empty', () => {
      let component2 = mountWithIntl(
        <Provider store={ store }>
          <Decorator
            name='firstName'
            value=':'
            errorMsg='Please enter a valid first name'
          />
        </Provider>
      );
      let input = component2.find( 'InputField' );
      input.props().touch( 'testForm', 'firstName' );
      component2.update();
      expect( component2.find( 'ResponseMessages' ).text() ).toBe( 'Please enter a valid first name' );
    } );

    it( 'should render error message based on showValidationMessage', () => {
      const component1 = mountWithIntl(
        <Provider store={ store }>
          <Decorator
            name='firstName'
            value=':'
            errorMsg='Please enter a valid first name'
            showValidationMessage={ true }
          />
        </Provider>
      );
      const component2 = mountWithIntl(
        <Provider store={ store }>
          <Decorator
            name='firstName'
            value=':'
            errorMsg='Please enter a valid first name'
            showValidationMessage={ false }
          />
        </Provider>
      );
      expect( component1.find( 'ResponseMessages' ).length ).toBe( 1 );
      expect( component2.find( 'ResponseMessages' ).length ).toBe( 0 );
    } );

    describe( 'Cancel and Hide Actions', () => {
      it( 'should display the clear component if the input field is active and has any value', () => {

        var AnchorField = mountWithIntl(
          <Provider store={ store }>
            <Decorator

              name='InputField'
              label='test'
              type='text'
            />
          </Provider>
        );
        let input = AnchorField.find( '.InputField' );
        input.simulate( 'focus' );
        input.value = 'foo';

        expect( AnchorField.find( 'div.InputField__Action--clear' ) ).toBeTruthy();
      } );

      it( 'should clear the input field contents when cancel button is clicked and clear SVG should have title attr with clear value', () => {
        var AnchorField = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='InputField'
              label='test'
              type='text'
              value='foo'
            />
          </Provider>
        );

        // AnchorField.instance();
        expect( AnchorField.find( 'Button.InputField__Action--clear' ).length ).toBe( 1 );
        expect( AnchorField.find( 'Button.InputField__Action--clear svg' ).length ).toBe( 1 );
        expect( AnchorField.find( 'Button.InputField__Action--clear svg title' ).text() ).toBe( 'Clear' ) ;
        expect( AnchorField.find( 'Button' ).props().ariaLabel ).toBe( 'Clear' );
      } );

      it( 'should invoke handleChange method when cancel button is clicked', () => {
        let handleChangeMock = jest.fn();
        var AnchorField = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='InputField'
              label='test'
              type='text'
              value='foo'
              handleChange={ handleChangeMock }
            />
          </Provider>
        );

        AnchorField.find( 'Button' ).simulate( 'mouseDown' );
        expect( handleChangeMock ).toBeCalled();


        // console.log( clearBtn.props().onMouseDown );
        // console.log( AnchorField.find( 'button.InputField__Action--clear' ).instance()  );
      } );

      it( 'show and hide text content toggles when clicked on it and the input has a value', () => {
        var AnchorField = mountWithIntl(
          <Provider store={ store }>
            <Decorator

              name='InputField'
              type='password'
            />
          </Provider>
        );

        let input = AnchorField.find( 'input' );
        input.simulate( 'focus' );
        input.value = 'foo';

        var CancelField = AnchorField.find( 'div.InputField__Action--showhide' );
        expect( AnchorField.find( 'div.InputField__Action--showhide' ) ).toBeTruthy();

      } );

      it( 'the click action should toggle the input type between text and password', () => {
        var AnchorField = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='password'
              type='password'
              value='abc'
              maskedToggleTarget='password'
              showMaskedVaue='true'
            />
          </Provider>
        );

        let input = AnchorField.find( 'input' );
        input.simulate( 'focus' );
        input.value = 'foo';
        AnchorField.find( 'div.InputField__Action--showhide' ).simulate( 'mouseDown' );
        AnchorField.update();
        expect( input.props().type ).toBe( 'password' );
        AnchorField.find( '.InputField__Action--showhide' ).simulate( 'click' );
        expect( input.props().type ).toBe( 'password' );
      } );
    } )

    describe( 'Hint text', () => {
      it( 'Hint text is present and no message', () => {
        var hintTextContainer = mountWithIntl(
          <Provider store={ store }>
            <Decorator

              name='InputField'
              hintText='Ulta'
            />
          </Provider>
        ).find( 'div.InputField__hintText' );

        expect( hintTextContainer.text() ).toBe( 'Ulta' );
      } );
    } )
    describe( 'Hint Text  present', () => {
      it( 'Hint text  is present', () => {

        var hintTextContainer = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='InputField'
              hintText='Ulta'
            />
          </Provider>
        ).find( 'div.InputField__hintText' );
        expect( hintTextContainer.text() ).toBe( 'Ulta' );
      } );
    } )


    describe( 'Label element', () => {
      it( 'should have the active class when focused', () => {


        var labelContainer = mountWithIntl(
          <Provider store={ store }>
            <Decorator

              name='InputField'
              messageType='info'
              message='it is here'
            />
          </Provider>
        ).find( '.InputField__Message' );
      } );
      it( 'should have aria-hidden to be true in InputField__label', () => {
        expect( component.find( '.InputField__label' ).props()['aria-hidden'] ).toBeTruthy();
      } );
    } );

    describe( 'Formatter tests', () => {

      it( 'should format creditcard data', () => {
        const component = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='InputField'
              messageType='info'
              message='it is here'
              formatter={ { creditcard: 1 } }
            />
          </Provider>
        ).find( 'InputField' );
        let formattedOutPut = component.instance().maskInput( '1234567890123456' );
        expect( formattedOutPut ).toBe( '1234 5678 9012 3456' );
        formattedOutPut = component.instance().maskInput( '345678901234561' );
        expect( formattedOutPut ).toBe( '3456 789012 34561' );
      } );

      it( 'should format expiry data', () => {
        const component = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='InputField'
              messageType='info'
              message='it is here'
              formatter={ { expiry: 1 } }
            />
          </Provider>
        ).find( 'InputField' );
        let formattedOutPut = component.instance().maskInput( '1234' );
        expect( formattedOutPut ).toBe( '12/34' );
        formattedOutPut = component.instance().maskInput( '12' );
        expect( formattedOutPut ).toBe( '12/' );
      } );

      it( 'should format data based on pattern ', () => {
        const component = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='InputField'
              messageType='info'
              message='it is here'
              formatter={ { pattern: '9999-9999-9999-9999' } }
            />
          </Provider>
        ).find( 'InputField' );
        let formattedOutPut = component.instance().maskInput( '1234567890123456' );
        expect( formattedOutPut ).toBe( '1234-5678-9012-3456' );
      } );

      it( 'should format money data ', () => {

        const component = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='InputField'
              messageType='info'
              message='it is here'
              formatter={ { money: 1 } }
            />
          </Provider>
        ).find( 'InputField' );
        let formattedOutPut = component.instance().maskInput( '12.02' );
        expect( formattedOutPut ).toBe( '$12.00' );
        formattedOutPut = component.instance().maskInput( '' );
        expect( formattedOutPut ).toBeUndefined();
        formattedOutPut = component.instance().maskInput( '1234.2344' );
        expect( formattedOutPut ).toBe( '$1,234.00' );
        formattedOutPut = component.instance().maskInput( '12342344' );
        expect( formattedOutPut ).toBe( '$12,342,344.00' );
      } );

      it( 'should mask SSN and invoke onChange ', () => {
        const handleChange = jest.fn() ;
        const onChange = jest.fn() ;
        const component = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='InputField'
              messageType='info'
              message='it is here'
              formatter={ { maskLastFourSSN: true } }
              handleChange={ handleChange }
              onChange={ onChange }
            />
          </Provider>
        ).find( 'InputField' );
        component.find( 'input' ).simulate( 'click' );
        component.find( 'input' ).simulate( 'change', { target: { value: '4111' } } );
        expect( onChange ).toBeCalled();
        expect( handleChange ).not.toBeCalled();
      } );
      it( 'should invoke handleChange for formatter pattern ', () => {
        const handleChange = jest.fn() ;
        const onChange = jest.fn() ;
        const component = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='InputField'
              messageType='info'
              message='it is here'
              formatter={ { pattern: '9999' } }
              handleChange={ handleChange }
              onChange={ onChange }
            />
          </Provider>
        ).find( 'InputField' );
        component.find( 'input' ).simulate( 'click' );
        component.find( 'input' ).simulate( 'change', { target: { value: '4111' } } );
        expect( onChange ).toBeCalled();
        expect( handleChange ).toBeCalled();
      } );

      it( 'should invoke handleChange for other cases ', () => {
        const handleChange = jest.fn() ;
        const onChange = jest.fn() ;
        checkIfAndroidChrome.mockReturnValue( false );
        const component = mountWithIntl(
          <Provider store={ store }>
            <Decorator
              name='InputField'
              messageType='info'
              message='it is here'
              handleChange={ handleChange }
              onChange={ onChange }
            />
          </Provider>
        ).find( 'InputField' );
        component.instance().maskInput = jest.fn( ()=> 123 );
        component.find( 'input' ).simulate( 'click' );
        component.find( 'input' ).simulate( 'change', { target: { value: '4111' } } );
        expect( onChange ).toBeCalled();

        checkIfAndroidChrome.retu
        expect( component.instance().maskInput ).toBeCalled();
        expect( handleChange ).toHaveBeenCalledWith( 123 );
      } );
    } );

    it( 'does not allow inavlid types to be set', () => {
      var input = mountWithIntl(
        <Provider store={ store }>
          <Decorator name='boo'/>
        </Provider>
      ).find( 'input' );
      expect( input.props().type ).not.toBe( 'boo' );
    } )

    describe( 'Input Events', () => {
      let component1 = mountWithIntl(
        <Provider store={ store }>
          <Decorator
            name='InputField'
            type='text'
            value='foo'
          />
        </Provider>
      );

      let input = component1.find( 'input' );
      var node = component1.find( 'InputField' ).instance();

      it( 'Check on isValidErrorToDisplay state value on focus Event', () => {
        expect( node.state.isValidErrorToDisplay ).toBe( false );
        input.simulate( 'focus' );
        expect( node.state.isValidErrorToDisplay ).toBe( true );
      } );

      it( 'Check on isValidErrorToDisplay state value on change Event', () => {
        input.value = 'Test';
        input.simulate( 'change' );
        expect( node.state.isValidErrorToDisplay ).toBe( false );
      } );

      let props = {
        handleBlur : jest.fn( ()=> true ),
        disablePaste : true
      };
      let component2 = mountWithIntl(
        <Provider store={ store }>
          <Decorator { ...props }/>
        </Provider>
      );

      let input2 = component2.find( 'input' );
      var node2 = component2.find( 'InputField' ).instance();
      input2.value = 'Test';
      it( 'Check on isValidErrorToDisplay state value onBlur event if checkIfAndroidChrome is true', () => {


        checkIfAndroidChrome.mockReturnValueOnce( true )
        node2.isSsnFieldToMask = jest.fn( ()=> true );
        node2.ssnShowMask = true;
        let formattedOutPut = node2.maskInput( input2.value ).trim();
        input2.simulate( 'blur', node2.onBlur );
        expect( formattedOutPut ).toBe( 'Test' );

        expect( node2.state.isValidErrorToDisplay ).toBe( true );
      } );

      it( 'Check on isValidErrorToDisplay state value onBlur event if `checkIfAndroidChrome` is false', () => {
        checkIfAndroidChrome.mockReturnValueOnce( false )
        node2.isSsnFieldToMask = jest.fn( ()=> false );
        node2.ssnShowMask = false;
        let formattedOutPut = input2.value.trim();
        input2.simulate( 'blur', node2.onBlur );
        expect( formattedOutPut ).toBe( 'Test' );
        formattedOutPut = node2.maskInput( 'Test2' )
        expect( formattedOutPut ).toBe( 'Test2' );
        expect( node2.state.isValidErrorToDisplay ).toBe( true );
      } );

    } );

  } )

  let props = {
    maskInput : jest.fn(),
    instanceOnChangeEvt : jest.fn(),
    clearOnUnmount : jest.fn(),
    name: 'InputField'
  };
  component = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props }/>
    </Provider>
  );
  const instance = component.find( 'InputField' ).instance();

  it( 'should call the componentWillUnmount', () => {
    instance.componentWillUnmount();
    expect( props.clearOnUnmount ).toHaveBeenCalledWith( props.name );
  } );

  it( 'should call the instanceOnChangeEvt on componentDidUpdate', () => {
    const component3 = mountWithIntl(
      <Provider store={ store }>
        <Decorator name='InputField' value='Ulta'/>
      </Provider>
    )
    const instance = component3.find( 'InputField' ).instance();
    const prevProps = { value: 'test' };
    instance.instanceOnChangeEvt = jest.fn();
    instance.componentDidUpdate( prevProps );
    expect( instance.instanceOnChangeEvt ).toHaveBeenCalledWith( 'Ulta' );
  } );

  it( 'should call the instanceOnChangeEvt with empty value on componentDidUpdate if input value is empty', () => {
    const component3 = mountWithIntl(
      <Provider store={ store }>
        <Decorator name='InputField' value=''/>
      </Provider>
    )
    const instance = component3.find( 'InputField' ).instance();
    const prevProps = { value: 'test' };
    instance.instanceOnChangeEvt = jest.fn();
    instance.componentDidUpdate( prevProps );
    expect( instance.instanceOnChangeEvt ).toHaveBeenCalledWith( '' );
  } );

  it( 'should call the expandHintText', () => {
    expect( instance.state.expandHintText ).toEqual( false );
    instance.expandHintText();
    expect( instance.state.expandHintText ).toEqual( true );
  } );

  it( 'should invoke the focus method of the input child element', () => {
    const focusMock = jest.fn();
    component.find( 'InputField' ).instance().input.focus = focusMock;
    component.find( 'InputField' ).instance().focus();
    expect( focusMock ).toBeCalled();
  } );
  it( 'should invoke the focus method of the input child element when user touches the clear button field', () => {
    const focusMock = jest.fn();
    const handleChangeMock = jest.fn();
    var anchorField = mountWithIntl(
      <Provider store={ store }>
        <Decorator
          name='InputField'
          label='test'
          type='text'
          value='foo'
          handleChange={ handleChangeMock }
        />
      </Provider>
    );
    anchorField.find( 'InputField' ).instance().focus = focusMock;
    anchorField.find( 'Button' ).simulate( 'mouseDown' );
    expect( focusMock ).toBeCalled();
  } );
  describe( 'hintTextMessage Message', () => {
    it( 'Should render tooltip if Tooltip message is passed as props', () => {
      const hintTextMessage = 'test';
      const component = mountWithIntl(
        <Provider store={ store }>
          <Decorator

            name='InputField'
            hintTextMessage={ hintTextMessage }
          />
        </Provider>
      )

      expect( component.find( '.InputField__content--showHintText' ).length ).toBe( 1 );
      expect( component.find( '.tooltip' ).length ).toBe( 1 );
      expect( component.find( '.tooltip svg' ).length ).toBe( 1 );
      expect( component.find( '.tooltip__hide' ).text() ).toBe( hintTextMessage );
    } );
    it( 'Should not render tooltip if Tooltip message is undefined', () => {

      const component = mountWithIntl(
        <Provider store={ store }>
          <Decorator

            name='InputField'
            hintTextMessage={ undefined }
          />
        </Provider>
      )

      expect( component.find( '.tooltip' ).length ).toBe( 0 );
    } );
  } )
} );
