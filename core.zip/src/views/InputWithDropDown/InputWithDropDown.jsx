/**
 * InputWithDropDown
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './InputWithDropDown.css';
import { Field } from 'redux-form';
import Select from 'react-select';
import 'react-select/dist/react-select.css';
import isUndefined from 'lodash/isUndefined';
import classNames from 'classnames';
import InputField from '../InputField/InputField';


const propTypes = {
  options : PropTypes.array.isRequired,
  nameForDropdown: PropTypes.string.isRequired,
  labelForInput: PropTypes.string.isRequired,
  warningForInputField: PropTypes.array,
  formValue: PropTypes.string,
  inputBlurFunction: PropTypes.func,
  inputTabIndex: PropTypes.number,
  inputFieldValue: PropTypes.string,
  instructionalTextForInput:PropTypes.string
}

const initialState = {
  selectValue: 'M'

}
/**
 * Class
 * @extends React.Component
 */
class InputWithDropDown extends Component{

  /**
   * Create a InputWithDropDown
   */
  constructor( props ){
    super( props );
    this.state = initialState;
    this.updateValue = this.updateValue.bind( this );
  }

  updateValue( value ){
    let iVal = isUndefined( value ) ? null : value;
    this.setState( {
      selectValue: iVal
    } );


    this.props.change( this.props.nameForDropdown, iVal );
  }

  /**
   * Renders the InputWithDropDown component
   */
  render(){


    const renderField = ( {
      input, onBlur, label, type, meta: { touched, error, warning }
    } ) => (
      <div
        className={
          classNames( 'InputWithDropDown__field__select', {
            'InputWithDropDown__field__select--error': touched && error
          } )
        }
      >
        <Select
          autoBlur
          openOnFocus={ true }
          tabSelectsValue={ false }
          simpleValue
          options={ this.props.options }
          clearable={ false }
          name={ this.props.name }
          value={ this.state.selectValue }
          onChange={ this.updateValue }
          className='InputWithDropDown__field__select'
          autoload={ false }
        />
        <input
          { ...input }
          ref={ input => this.selectInput = input }
          type={ type }
        />
        { ( () => {
          if( touched && error ){
            return (
              <div className={ classNames( 'AuthorizedBuyers__SignupField__Select__message', {
                'AuthorizedBuyers__SignupField__Select__message--error': error
              } ) }
              >
                <Exclamation />
                { error }
              </div>
            )
          }
        } )() }
      </div>

    );

    return (
      <div className='InputWithDropDown'>
        <div className={
          classNames( 'InputWithDropDown__field',
            'InputWithDropDown__field--active' )
        }
        >
          <div className='InputWithDropDown__field--dropDown'>
            <Field
              name={ this.props.nameForDropdown }
              component={ renderField }
              type='hidden'
            />
          </div>

          <div className='InputWithDropDown__field--input'>
            <InputField
              label={ this.props.labelForInput }
              component={ this.renderInputField }
              formatter={ { pattern: '(999) 999-9999' } }
              type='tel'
              onFocus={ ( e )=> {
                e.preventDefault();
              } }
              handleBlur={
                ( e ) => {
                  if( this.props.inputBlurFunction ){
                    this.props.inputBlurFunction()
                  }
                }
              }
              value={ this.props.inputFieldValue }
              name={ this.props.nameForInput }
              tabIndex={ this.props.inputTabIndex }
              warn={ this.props.warningForInputField }
              instructionalText={ this.props.instructionalTextForInput }
            />
          </div>

        </div>
      </div>
    );
  }
}

InputWithDropDown.propTypes = propTypes;

export default InputWithDropDown;
