import React from 'react';
import ReactDOM from 'react-dom';
import { reduxForm } from 'redux-form';
import { Provider } from 'react-redux';
import InputWithDropDown from './InputWithDropDown';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';


const Decorator = reduxForm( { form:'testForm' } )( InputWithDropDown );
describe( '<InputWithDropDown />', () => {
  const store = configureStore( );

  it( 'renders without crashing', () => {
    const component = mountWithIntl(
      <Provider store={ store }>
        <Decorator />
      </Provider>
    );
    expect( component.find( 'InputWithDropDown' ).length ).toBe( 1 );
  } );

  it( 'tests updateValue', () => {
    const props = {
      change: jest.fn(),
      nameForDropdown: 'test',
      meta: {
        touched: true,
        error: true,
        warning: false
      }
    };
    const component = mountWithIntl(
      <Provider store={ store }>
        <Decorator { ... props } />
      </Provider>
    );
    component.find( 'InputWithDropDown' ).instance().updateValue( '123' );
    expect( component.find( 'InputWithDropDown' ).instance().state.selectValue ).toBe( '123' );
  } );

} );
