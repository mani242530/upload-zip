/**
 * LanguageProvider
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createSelector } from 'reselect';
import { IntlProvider } from 'react-intl';
import { getLocale } from '../../models/language/language.model';


const propTypes = {
  locale: PropTypes.string,
  messages: PropTypes.object,
  children: PropTypes.element.isRequired
}

export const LanguageProvider = ( props ) =>{

  const {
    locale,
    messages,
    children
  } = props;

  return (
    <IntlProvider
      locale={ locale }
      key={ locale }
      message={ messages[locale] }
    >
      { React.Children.only( children ) }
    </IntlProvider>
  );

}

LanguageProvider.propTypes = propTypes;

const mapStateToProps = createSelector(
  getLocale(),
  ( locale ) => ( { locale } )
);

export default connect( mapStateToProps )( LanguageProvider );
