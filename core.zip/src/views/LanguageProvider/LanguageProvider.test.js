import React from 'react';
import { Provider } from 'react-redux';
import { shallow } from 'enzyme';

import { FormattedMessage, defineMessages } from 'react-intl';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';
import { translationMessages } from './i18n';

import LanguageProvider from './LanguageProvider';



describe( '<LanguageProvider />', () => {
  let store;
  let component;

  beforeEach( () => {
    store = configureStore( );
  } );

  it( 'should render the default language message', () => {
    const messages = defineMessages(
      {
        someMessage: {
          id: 'some.id',
          defaultMessage: 'This is a default message'
        }
      }
    );

    component = shallow(
      <Provider store={ store }>
        <LanguageProvider messages={ translationMessages }>
          <FormattedMessage { ...messages.someMessage } />
        </LanguageProvider>
      </Provider>
    );

    expect( component.contains( <FormattedMessage { ...messages.someMessage } /> ) ).toBe( true );
  } );
} );
