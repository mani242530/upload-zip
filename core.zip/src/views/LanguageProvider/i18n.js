/**
 * i18n.js
 *
 * This file sets up the i18n language files and locale data
 *
 */

import { addLocaleData } from 'react-intl';
import enLocaleData from 'react-intl/locale-data/en';
import enTranslationMessages from './translations/en.json';

const DEFAULT_LOCALE = 'en';

addLocaleData( enLocaleData );

export const appLocales = [
  'en'
];

export const formatTranslationMessages = ( locale, messages ) => {
  // if the passed locale doesn't match the DEFAULT locale set an empty object fro the messages
  const defaultFormattedMessages = locale !== DEFAULT_LOCALE ? formatTranslationMessages( DEFAULT_LOCALE, enTranslationMessages ) : {};
  const formattedMessages = {};
  const messageKeys = Object.keys( messages );
  for ( const messageKey of messageKeys ){
    if( locale === DEFAULT_LOCALE ){
      formattedMessages[messageKey] = messages[messageKey];
    }
    else {
      formattedMessages[messageKey] = messages[messageKey] || defaultFormattedMessages[messageKey];
    }
  }

  return formattedMessages;
}

export const translationMessages = {
  en: formatTranslationMessages( 'en', enTranslationMessages )
};
