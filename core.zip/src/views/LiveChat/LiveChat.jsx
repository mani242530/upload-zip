import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import find from 'lodash/find';

import { createScriptTag } from '../../utils/third_party_scripts/third_party_scripts';

const propTypes = {
  liveChatAccount: PropTypes.number,
  liveChatUrl: PropTypes.string
}

const LiveChat = ( props ) => {
  window._ = { find };
  const prObj = {
    'attributes': {
      'id': 'tagscript',
      'type': 'text/javascript',
      'src': '//static.atgsvcs.com/js/atgsvcs.js'
    },
    'options': {
      'onload': () => {
        initialzeLiveChat( props )
      }
    }
  };
  createScriptTag( prObj );
  return ( null );
}

export const initialzeLiveChat = ( props ) => {
  createScriptTag(
    {
      'attributes': {
        'id': 'livechatscript',
        'type': 'text/javascript'
      },
      'content': `
    ATGSvcs.setEEID('${props.liveChatAccount}');
    (function() { // Enable EE driven widgets
        var l = '${props.liveChatUrl}',d=document,ss='script',s=d.getElementsByTagName(ss)[0];
        function r(u) {
          var rn=d.createElement(ss);
          rn.type='text/javascript';
          rn.defer=rn.async=!0;
          rn.src = "//" + l + u;
          s.parentNode.insertBefore(rn,s);
        }
        r('/rnt/rnw/javascript/vs/1/vsapi.js');
        r('/vs/1/vsopts.js');
        })();`
    }
  );
}

LiveChat.propTypes = propTypes;
export const mapStateToProps = ( state ) => {
  return {
    liveChatAccount: state.global.switchData.switches.liveChatAccount,
    liveChatUrl: state.global.switchData.switches.liveChatUrl
  };
}

// this is to mock the data for test cases
export const connectFunction = ( mapStateToProps ) => {
  return ( connect( mapStateToProps )( LiveChat ) );
};
export default connectFunction( mapStateToProps );