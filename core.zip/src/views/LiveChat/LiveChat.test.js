import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { find } from 'lodash/find';
import LiveChat, { initialzeLiveChat } from './LiveChat'
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';
import { createScriptTag } from '../../utils/third_party_scripts/third_party_scripts';
jest.mock( './../../utils/third_party_scripts/third_party_scripts', () => {
  return {
    createScriptTag: jest.fn()
  }
} );
describe( '<LiveChat/>', () => {
  window._ = {};
  const store = configureStore( );
  store.getState().global = {
    switchData:{
      switches:{
        liveChatUrl:'www.livechat.com/url'
      }
    }
  }

  it( 'should render without crashing and should invoke createScriptTag to insert live chat script', () => {
    const component = mountWithIntl(
      <Provider store={ store }>
        <LiveChat />
      </Provider>
    );
    expect( component ).toBeTruthy();
    expect( createScriptTag ).toBeCalledWith( expect.objectContaining( { 'attributes': { 'id': 'tagscript', 'src': '//static.atgsvcs.com/js/atgsvcs.js', 'type': 'text/javascript' } } ) );
  } );

  it( 'should invoke createScriptTag to initalize live chat when initialzeLiveChat is invoked', () => {
    createScriptTag.mockClear();
    const props = {
      liveChatAccount:'1232132',
      liveChatUrl:'www.livechat.com/url'
    }
    const createScriptParam = {
      'attributes': {
        'id': 'livechatscript',
        'type': 'text/javascript'
      },
      'content': `
    ATGSvcs.setEEID('${props.liveChatAccount}');
    (function() { // Enable EE driven widgets
        var l = '${props.liveChatUrl}',d=document,ss='script',s=d.getElementsByTagName(ss)[0];
        function r(u) {
          var rn=d.createElement(ss);
          rn.type='text/javascript';
          rn.defer=rn.async=!0;
          rn.src = "//" + l + u;
          s.parentNode.insertBefore(rn,s);
        }
        r('/rnt/rnw/javascript/vs/1/vsapi.js');
        r('/vs/1/vsopts.js');
        })();`
    }

    initialzeLiveChat( props );
    expect( createScriptTag ).toBeCalledWith( createScriptParam );
  } );

} )
