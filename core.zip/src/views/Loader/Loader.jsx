

/**
 * Loader
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { isServer } from '../../utils/device_detection/device_detection';

import './Loader.css';


import Spinner from '../Icons/spinner';

const propTypes = {
  loaderType: PropTypes.oneOf( ['skeleton', 'spinner', 'twoBarSkeleton', 'threeBarSkeleton'] ),
  assetCount: PropTypes.number
}


const defaultProps = {
  loaderType: 'skeleton',
  assetCount: 1
}

const initialState = {
  loading: true,
  loaderType: 'skeleton',
  loaderWidth: 0,
  assetsLoaded: 0
}


/**
 * Class
 * @extends React.Component
 */
class Loader extends Component{

  /**
   * Create a Loader
   */
  constructor( props ){
    super( props );

    this.state = initialState;

    this.handleImageLoad = this.handleImageLoad.bind( this );
    this.handleImageError = this.handleImageError.bind( this );
    this.renderSkeletonLoader = this.renderSkeletonLoader.bind( this );
    this.renderTwoBarSkeletonLoader = this.renderTwoBarSkeletonLoader.bind( this );
    this.renderThreeBarSkeletonLoader = this.renderThreeBarSkeletonLoader.bind( this );
  }

  handleImageError(){
  }

  handleImageLoad(){
    let increase = this.state.assetsLoaded + 1;
    this.setState( { assetsLoaded: increase } );

    if( increase === this.props.assetCount ){
      this.setState( { loading: false } );
    }
  }

  renderSkeletonLoader(){
    return (
      <div className='Loading'>
        <div className='Loading__container'>
          <div className='Loading__bar  Loading__bar--1'></div>
          <div className='Loading__bar  Loading__bar--2'></div>
          <div className='Loading__bar  Loading__bar--3'></div>
          <div className='Loading__bar  Loading__bar--4'></div>
          <div className='Loading__bar  Loading__bar--5'></div>
          <div className='Loading__bar  Loading__bar--6'></div>
          <div className='Loading__bar  Loading__bar--7'></div>
          <div className='Loading__bar  Loading__bar--8'></div>
          <div className='Loading__bar  Loading__bar--9'></div>
          <div className='Loading__bar  Loading__bar--10'></div>
          <div className='Loading__bar  Loading__bar--11'></div>
          <div className='Loading__bar  Loading__bar--12'></div>
        </div>
      </div>
    )
  }

  renderTwoBarSkeletonLoader(){
    return (
      <div className='Loading'>
        <div className='Loading__container Loading__twoBarLoader'>
          <div className='Loading__bar  Loading__bar--13'></div>
          <div className='Loading__bar  Loading__bar--14'></div>
          <div className='Loading__bar  Loading__bar--15'></div>
          <div className='Loading__bar  Loading__bar--16'></div>
          <div className='Loading__bar  Loading__bar--17'></div>
        </div>
      </div>
    )
  }

  renderThreeBarSkeletonLoader(){
    return (
      <div className='Loading'>
        <div className='Loading__container Loading__threeBarLoader'>
          <div className='Loading__bar  Loading__bar--18'></div>
          <div className='Loading__bar  Loading__bar--19'></div>
          <div className='Loading__bar  Loading__bar--20'></div>
          <div className='Loading__bar  Loading__bar--21'></div>
          <div className='Loading__bar  Loading__bar--22'></div>
          <div className='Loading__bar  Loading__bar--23'></div>
          <div className='Loading__bar  Loading__bar--24'></div>
        </div>
      </div>
    )
  }

  componentDidMount(){
    this.loaderWidth = this.loader.clientWidth;
    // we need to run a forceUpdate to set the clientWidth for the component
    // this.forceUpdate();
  }

  componentDidUpdate( prevProps, prevState ){
    if( this.props.handleLoadComplete ){
      if( this.state.loading !== true && prevState.loading === true ){
        this.props.handleLoadComplete( this );
      }
    }
  }


  /**
   * Renders the Loader component
   */
  render(){

    const {
      loaderType,
      assetCount
    } = this.props;

    return (
      <div
        ref={ ( loader ) => this.loader = loader }
        className={
          classNames( {
            'Loader': this.state.loading,
            'Loader__small': this.loaderWidth < 150
          } )
        }
      >
        {
          ( ()=>{
            for ( var i = 0; i < assetCount; i++ ){
              if( this.state.loading && !isServer() ){
                switch ( loaderType ){
                  case 'skeleton':
                    return this.renderSkeletonLoader()

                  case 'twoBarSkeleton':
                    return this.renderTwoBarSkeletonLoader()

                  case 'threeBarSkeleton':
                    return this.renderThreeBarSkeletonLoader()

                  case 'spinner':
                    return ( <Spinner /> )

                  default: return
                }
              }
            }
          } )()
        }
        {
          ( ()=>{
            if( this.props.children ){

              if( isServer() ){

                return (
                  <div className='Loader__content--loaded'>
                    { this.props.children }
                  </div>
                )
              }
              else {
                const childrenWithProps = React.Children.map( this.props.children,
                  ( child ) => React.cloneElement( child, {
                    onLoad: this.handleImageLoad,
                    onError: this.handleImageError
                  } ) );

                return (
                  <div
                    className={
                      classNames( {
                        'Loader__content': this.state.loading
                      } )
                    }
                    ref={ ( elem )=>{
                      this.renderedContent = elem;
                    } }
                  >
                    { childrenWithProps }
                  </div>
                )
              }

            }
          } )()
        }
      </div>
    );
  }
}

Loader.propTypes = propTypes;
Loader.defaultProps = defaultProps;

export default Loader;
