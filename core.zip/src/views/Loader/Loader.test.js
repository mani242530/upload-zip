import React from 'react';
import ReactDOM from 'react-dom';
import Loader from './Loader';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<Loader />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <Loader /> );
    expect( component.find( 'Loader' ).length ).toBe( 1 );
  } );

  it( 'should render Loading__twoBarLoader when loaderType is twoBarSkeleton', () => {
    const component = mountWithIntl( <Loader loaderType='twoBarSkeleton'/> );

    expect( component.find( '.Loading__container' ).find( '.Loading__twoBarLoader' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--13' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--14' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--15' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--16' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--17' ).length ).toBe( 1 );
  } );


  it( 'should not render Loading__twoBarLoader when loaderType is not twoBarSkeleton', () => {
    const component = mountWithIntl( <Loader loaderType='skeleton'/> );

    expect( component.find( '.Loading__twoBarLoader' ).length ).toBe( 0 );
  } );

  it( 'should render Loading__threeBarLoader when loaderType is threeBarSkeleton', () => {
    const component = mountWithIntl( <Loader loaderType='threeBarSkeleton'/> );

    expect( component.find( '.Loading__container' ).find( '.Loading__threeBarLoader' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--18' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--19' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--20' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--21' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--22' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--23' ).length ).toBe( 1 );
    expect( component.find( '.Loading__bar.Loading__bar--24' ).length ).toBe( 1 );
  } );

  it( 'should not render Loading__threeBarLoader when loaderType is not threeBarSkeleton', () => {
    const component = mountWithIntl( <Loader loaderType='skeleton'/> );

    expect( component.find( '.Loading__threeBarLoader' ).length ).toBe( 0 );
  } );

  it( 'should invoke  handleLoadComplete', () => {
    const handleLoadComplete = jest.fn();
    component = mountWithIntl( <Loader handleLoadComplete={ handleLoadComplete } /> );
    const node = component.find( 'Loader' ).instance();
    const prevState = { loading: true };
    node.state.loading = false;
    node.componentDidUpdate( {}, prevState );
    expect( handleLoadComplete ).toBeCalled();
  } );

  it( 'should set assetsloaded to 2 when state.assetsLoaded is 1', () => {
    component = mountWithIntl( <Loader /> );
    const node = component.find( 'Loader' ).instance();
    node.state.assetsLoaded = 1;
    node.handleImageLoad();
    expect( node.state.assetsLoaded ).toBe( 2 );
  } );

  it( 'should set the loading to false when both increase and assetcount are equal', () => {
    const props = { assetCount : 3 };
    component = mountWithIntl( <Loader { ...props }/> );
    const node = component.find( 'Loader' ).instance();
    node.state.assetsLoaded = 2;
    node.handleImageLoad();
    expect( node.state.loading ).toBe( false );
  } );

} );
