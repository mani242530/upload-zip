/**
 * LoginForm
 */

import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import './LoginForm.css';

import omitBy from 'lodash/omitBy';
import isNil from 'lodash/isNil';
import isUndefined from 'lodash/isUndefined';
import isEqual from 'lodash/isEqual';
import classNames from 'classnames';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronDown } from '@fortawesome/pro-solid-svg-icons/faChevronDown';
import { faSignOut } from '@fortawesome/pro-solid-svg-icons/faSignOut';
import InputField from '../InputField/InputField';
import Anchor from '../Anchor/Anchor';
import Title from '../Title/Title';
import Button from '../Button/Button';
import Button20 from '../Button20/Button20';
import { getRoute } from '../../utils/omniture/omniture'

import {
  requiredValidation
} from '../../utils/form_validations/form_validations';

import ResponseMessages from '../ResponseMessages/ResponseMessages';
import messages from './LoginForm.messages';

import {
  triggerAnalyticsEvent
} from '../../events/analytics/analytics.events';
import {
  getActionDefinition
} from '../../events/services/services.events';
import {
  removeValidationMessages,
  removeLoginMessages
} from '../../events/forms/forms.events';
import { scrollWindowToPosition } from '../../utils/animation/animation';
import { formatMessage } from '../Global/Global';
import {
  setBroadcastMessage
} from '../../events/global/global.events';
import Text from '../Text/Text'
import ToggleButton from '../ToggleButton/ToggleButton';
import { logoutUser } from '../../events/profile/profile.events';
import appConstants from '../../utils/constants/appConstants';
import {
  host,
  fullyQualifyLink
} from '../../utils/formatters/formatters';

const propTypes = {
  // an indicator for the login service so it knows what URL the request is coming from.
  sourcePage: PropTypes.string.isRequired,
  successPath: PropTypes.string,
  loginMessages: PropTypes.array,
  analyticsPageName: PropTypes.string,
  analyticsSourcePage: PropTypes.string,
  analyticsChannel: PropTypes.string,
  scrollElementSelector: PropTypes.string,
  loginSuccessHandler: PropTypes.function,
  title: PropTypes.string,
  formMessage: PropTypes.string,
  btnStyle: PropTypes.string,
  useRouter: PropTypes.bool, // used if needs to go to a different page with using router
  redirectPage: PropTypes.bool,
  defaultEmail: PropTypes.string,
  openForgetPasswordLinkInNewPage: PropTypes.bool,
  autoComplete: PropTypes.oneOf( ['on', 'off'] ),
  reauth: PropTypes.bool,
  loginUserName: PropTypes.string,
  isReauthFlow: PropTypes.bool
}
const defaultProps = {
  successPath: '/',
  btnStyle: 'primary',
  useRouter: true,
  redirectPage:true,
  defaultEmail: null,
  analyticsSourcePage: '',
  openForgetPasswordLinkInNewPage: false,
  autoComplete:'off',
  reauth:false,
  loginUserName: undefined,
  isReauthFlow: false
}



/**
 * Class
 * @extends React.Component
 */
class LoginForm extends Component{



  /**
   * Create a LoginForm
   */
  constructor( props ){
    super( props );
    this.submit = this.submit.bind( this );
    this.toggleStaySignedInFlag = this.toggleStaySignedInFlag.bind( this );
    this.toggleStaySignedInDetailsDisplay = this.toggleStaySignedInDetailsDisplay.bind( this );

    this.state = {
      staySignedIn: false,
      showDetails: false
    };
    this.staySignedInDescriptionRef = React.createRef();
  }

  loginFormSubmitButtonRef = undefined;

  submit( values ){

    let _values = values;

    const reauthRetry = !!this.props.isReauthFlow && !!_values.username;

    _values.sourcePage = this.props.sourcePage;
    _values.staySignedIn = this.state.staySignedIn;
    this.props.removeValidationMessages();
    const data = {
      values: _values,
      history: this.props.history,
      analyticsSourcePage: this.props.analyticsSourcePage,
      paths:{
        successPath: this.props.successPath
      },
      useRouter: this.props.useRouter,
      redirectPage:this.props.redirectPage,
      loginSuccessHandler: this.props.loginSuccessHandler,
      reauth:this.props.isReauthFlow,
      reauthRetry
    }

    // if the user focus is inside the form, and if the user press enter, the redux form activates the first button
    // in the form with type submit. so in this case the loginform submit will be invoked
    // we have a logic to clear the server message, when the user tries to modify any input field, after the error is displayed.
    // this is based on the redux form CHANGE event
    // if the service returns an error, we also have the logic to put the focus to the username field.
    // so if the user focus was on password field, and if an error is returned, the error will be displayed and the focus will be change to username field
    // but when changing focus i.e on blur from password field, redux form triggers a CHANGE event for the password field which results in clearing the error message
    // the logic below will ensure that we are focussing the submit button before request is submitted, which will avoid the blur from password field after an error is received
    this.loginFormSubmitButtonRef.focus();

    this.props.submitUserLogin( data );
  }

  componentDidMount(){
    // if the user is already a hard login user, redirect the user to the myaccount page instead of showing the login form
    if( this.props.isHardLoginUser ){
      global.location.replace( fullyQualifyLink( host, appConstants.ROUTES.ACCOUNT_PAGE ) );
    }
  }

  componentDidUpdate( prevProps, prevState ){
    // if we just received errors and we didn't have them before scroll the user to them
    if( this.props.loginMessages && isUndefined( prevProps.loginMessages ) ){
      // scrolll user to top
      const scrollElemPos = document.getElementById( this.props.scrollElementSelector );
      if( scrollElemPos ){
        scrollWindowToPosition( scrollElemPos.offsetTop, 'easeInOutQuint' );
      }

      this.props.change( 'password', '' );
      this.props.untouch( 'LogIn', 'password' );
    }
    // Signin validation broadcast message
    if( ! isEqual( prevProps.loginMessages, this.props.loginMessages ) ){
      if( this.props.loginMessages ){
        this.props.loginMessages.map( ( item, index ) => {
          if( item.message ){
            this.usernameInputField.focus();
            this.props.broadcastMessage( item.message );
          }
        } );
      }
      else {
        this.props.broadcastMessage( '' );
      }
    }

    // the below logic will take care of ADA requirments for moving the focus to the staySignedIn description when the
    // use clicks on the showDetails button
    if( this.state.showDetails && !prevState.showDetails ){
      this.staySignedInDescriptionRef.current.focus();
    }
  }

  // Login error messages should be cleared on componentWillUnmount
  componentWillUnmount(){
    this.props.removeLoginMessages();
  }

  toggleStaySignedInDetailsDisplay(){
    const {
      showDetails
    } = this.state;

    this.setState( { showDetails: !showDetails } );
  }

  toggleStaySignedInFlag(){
    const {
      staySignedIn
    } = this.state;

    this.setState( { staySignedIn: !staySignedIn } )
  }

  /**
   * Renders the LoginForm component
   */
  render(){
    const {
      handleSubmit,
      loginMessages,
      isLoginFormSubmitting,
      reauth,
      history,
      isReauthFlow
    } = this.props;

    return (
      <div className='LoginForm'>
        <div className='LoginForm__Header'>
          <div
            className={
              classNames( 'LoginForm__getStartedMessage', {
                'LoginForm__getStartedMessage--relogin': isReauthFlow
              } )
            }
          >
            { this.props.title }
          </div>
          <div className='LoginForm__getApplicationMessage'>
            { this.props.formMessage }
          </div>
        </div>
        {
          reauth &&
          <Fragment>
            <div className='LoginForm__userName'>
              <Text
                type='bold'
                textAlign='center'
              >
                { this.props.loginUserName }
              </Text>
            </div>
            <div className='LoginForm__signOut'>
              <Text
                htmlTag='span'
              >
                { formatMessage( messages.notYou ) }
              </Text>
              <Button20
                type='button'
                btnStyle='icon'
                clickEventHandler={ ()=> this.props.userLogout( history ) }
              >
                <FontAwesomeIcon icon={ faSignOut } />
                { formatMessage( messages.signOut ) }
              </Button20>
            </div>
          </Fragment>
        }
        { loginMessages &&
          (
            <div className='LoginForm__errors' >
              { loginMessages.map( ( item, index ) => {
                return (
                  <ResponseMessages
                    key={ index }
                    message={ item.message }
                    broadCastAdaMessage={ false }
                  />
                )
              } ) }
            </div>
          )
        }
        <form
          onSubmit={ handleSubmit( this.submit ) }
          noValidate
        >
          {
            !reauth &&
            <div className='LoginForm__field'>
              <InputField
                name='username'
                type='email'
                label={ formatMessage( messages.emailOrUsername ) }
                validate={ requiredValidation }
                formName='login'
                trackAnalytics={ !!getRoute( 'checkout' ) }
                value={ this.props.defaultEmail }
                ref={ ( el ) => {
                  this.usernameInputField = el;
                } }
                autoComplete={ this.props.autoComplete }
              />
            </div>
          }
          <div className='LoginForm__field LoginForm__field--password'>
            <InputField
              name='password'
              type='password'
              label={ formatMessage( messages.password ) }
              validate={ requiredValidation }
              maskedToggleTarget='LoginPassword'
              showMaskedValue={ this.props.formConfig.fieldShowHideToggleData.LoginPassword }
              formName='login'
              trackAnalytics={ !!getRoute( 'checkout' ) }
              autoComplete={ this.props.autoComplete }
            />
          </div>
          { this.props.enablePersistentLogin &&
            <div className='LoginForm__staySignedIn'>
              <ToggleButton
                isCheckBox={ true }
                onClick={ this.toggleStaySignedInFlag }
                isChecked={ this.state.staySignedIn }
              />
              <div className='LoginForm__staySignedInText'>
                <Text type='body-2'>
                  { formatMessage( messages.staySignedIn ) }
                </Text>
              </div>
              <Button20
                type='button'
                btnStyle='icon'
                clickEventHandler={ this.toggleStaySignedInDetailsDisplay }
              >
                <div className='LoginForm__showHideDetails'>
                  <Text type='body-2'>
                    {
                      !this.state.showDetails ?
                        formatMessage( messages.showDetails ) :
                        formatMessage( messages.hideDetails )
                    }
                  </Text>
                </div>
                <div className={
                  classNames( 'LoginForm__staySignedInChevron', {
                    'LoginForm--staySignedInChevronDown': this.state.showDetails,
                    'LoginForm--staySignedInChevronUp': !this.state.showDetails
                  } )
                }
                >
                  <FontAwesomeIcon icon={ faChevronDown } />
                </div>
              </Button20>
              { this.state.showDetails &&
              <div className='LoginForm__staySignedInDescription'
                ref={ this.staySignedInDescriptionRef }
                tabIndex='-1'
              >
                <Text
                  htmlTag='p'
                  type='caption'
                >
                  { formatMessage( messages.staySignedInDescription ) }
                </Text>
              </div>
              }
            </div>
          }
          <div
            className={
              classNames( 'LoginForm__Submit', {
                'LoginForm__Submit--relogin': reauth
              } )
            }
          >
            <Button20
              showLoader={ isLoginFormSubmitting }
              type='submit'
              btnStyle={ this.props.btnStyle }
              size='large'
              block={ true }
              ref={ ( el ) => {
                this.loginFormSubmitButtonRef = el;
              } }
            >
              { this.props.buttonText }
            </Button20>
          </div>

          <div className='LoginForm__forgotCredentials'>
            { !reauth &&
              <Fragment>
                <Anchor
                  displayType='secondary'
                  url='/forgot-username'
                  target={ this.props.openForgetPasswordLinkInNewPage ? '_blank' : '_self' }
                >
                  { formatMessage( messages.forgotUsername ) }
                </Anchor>
                { formatMessage( messages.or ) }
              </Fragment>
            }
            <Anchor
              displayType='secondary'
              url='/forgot-password'
              target={ this.props.openForgetPasswordLinkInNewPage ? '_blank' : '_self' }
            >
              { formatMessage( messages.forgotPassword ) }
            </Anchor>
          </div>


        </form>
      </div>
    );
  }
}

LoginForm.propTypes = propTypes;
LoginForm.defaultProps = defaultProps;

export const mapStateToProps = ( state, props )=> {
  return {
    isLoginFormSubmitting: state.user.isLoginFormSubmitting,
    formConfig: state.pagedata.formConfig,
    loginMessages: state.user.loginMessages,
    enablePersistentLogin: state.global.switchData.switches.enablePersistentLogin && !props.reauth,
    isHardLoginUser:state.user.isSignedIn && !state.user.isSoftLoginUser
  }
}

export const mapDispatchToProps = dispatch => {
  return {
    submitUserLogin: data => {
      dispatch( getActionDefinition( 'login', 'requested' )( data ) );
    },

    removeValidationMessages: () => {
      dispatch( removeValidationMessages() )
    },

    broadcastMessage : function( message ){
      dispatch( setBroadcastMessage( message ) )
    },

    removeLoginMessages: () =>{
      dispatch( removeLoginMessages() )
    },

    userLogout: ( history ) =>{
      dispatch( logoutUser( history ) );
    }
  }
}

export const onSubmitSuccess = ( result, dispatch, props ) => {
  // go to the application form if there are no errors
}

export const onSubmitFail = ( errors, dispatch ) => {
  let analyticErrors = [];
  analyticErrors.push( { 'LoginFormErrors':  omitBy( errors, isNil ) } );

  let evt = {
    'name': 'trackErrorDisplayed',
    'data': analyticErrors
  }
  dispatch( triggerAnalyticsEvent( evt ) );
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return reduxForm( {
    form: appConstants.FORMS.LOGIN,
    onSubmitSuccess,
    onSubmitFail,
    touchOnBlur: false
  } )( connect( mapStateToProps, mapDispatchToProps )( LoginForm ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );
