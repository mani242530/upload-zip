/*
 * LoginForm Messages
 *
 * This contains all the text for the LoginForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  notYou: {
    id: 'i18n.LoginForm.notYou',
    defaultMessage: 'Not you?'
  },
  signOut:{
    id: 'i18n.LoginForm.signOut',
    defaultMessage: 'Sign Out'
  },
  haveAnAccount: {
    id: 'i18n.LoginForm.haveAnAccount',
    defaultMessage: 'Have an account?'
  },
  signInPrompt: {
    id: 'i18n.LoginForm.signInPrompt',
    defaultMessage: 'Sign in to see your saved bag.'
  },
  emailOrUsername: {
    id: 'i18n.LoginForm.emailOrUsername',
    defaultMessage: 'Email Address or Username'
  },
  password:{
    id: 'i18n.LoginForm.password',
    defaultMessage: 'Password'
  },
  forgotPassword: {
    id: 'i18n.LoginForm.forgotPassword',
    defaultMessage: 'Forgot Password?'
  },
  or: {
    id: 'i18n.LoginForm.or',
    defaultMessage: ' or '
  },
  forgotUsername: {
    id: 'i18n.LoginForm.forgotUsername',
    defaultMessage: 'Forgot Username'
  },
  noUltaAccountShort: {
    id: 'i18n.InputField.noUltaAccountShort',
    defaultMessage: ' No Ulta.com account?'
  },
  joinTheFun: {
    id: 'i18n.InputField.joinTheFun',
    defaultMessage: 'Create one and join the fun!'
  },
  createAccount: {
    id: 'i18n.InputField.createAccount',
    defaultMessage: 'CREATE ACCOUNT'
  },
  staySignedIn: {
    id: 'i18n.LoginForm.staySignedIn',
    defaultMessage: 'Stay signed in.'
  },
  showDetails: {
    id: 'i18n.LoginForm.showDetails',
    defaultMessage: 'Show Details'
  },
  hideDetails: {
    id: 'i18n.LoginForm.hideDetails',
    defaultMessage: 'Hide Details'
  },
  staySignedInDescription: {
    id: 'i18n.LoginForm.staySignedInDescription',
    defaultMessage: 'Choose this option if you want to sign in less often on this device. For your security, select this option only on your personal devices.'
  }
} );
