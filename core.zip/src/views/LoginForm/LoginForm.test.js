import React from 'react';
import { Provider } from 'react-redux';
import LoginForm, {
  onSubmitFail, mapDispatchToProps, mapStateToProps, connectFunction
} from './LoginForm';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';
import messages from './LoginForm.messages';
import {
  registerServiceName
} from '../../events/services/services.events';
import {
  setBroadcastMessage
} from '../../events/global/global.events';
import { logoutUser } from '../../events/profile/profile.events';
import appConstants from '../../utils/constants/appConstants';
import {
  host,
  fullyQualifyLink
} from '../../utils/formatters/formatters';


describe( '<LoginForm />', () => {
  registerServiceName( 'login' );

  const store = configureStore( );
  store.getState().global = {
    switchData:{
      switches:{
        enablePersistentLogin:true
      }
    }
  }

  let props = {
    submitUserLogin: jest.fn(),
    successPath:'/CreditCardApplyForm',
    history:'/CreditCardApplyForm',
    sourcePage:'test',
    autoComplete:'off'
  }
  let propsx = {
    btnStyle: 'secondary'
  }
  let component = mountWithIntl(
    <Provider store={ store }>
      <LoginForm { ...props }/>
    </Provider>
  );
  let componentx = mountWithIntl(
    <Provider store={ store }>
      <LoginForm { ...propsx }/>
    </Provider>
  );

  it( 'renders without crashing and the form name should be LogIn', () => {
    expect( component.find( 'LoginForm' ).length ).toBe( 1 );
    expect( component.find( 'LoginForm' ).props().form ).toBe( appConstants.FORMS.LOGIN );
  } );

  it( 'renders two input fields', () => {
    expect( component.find( 'InputField' ).length ).toBe( 2 );
  } );

  it( 'input field type should be text or email', () => {
    expect( component.find( 'InputField' ).at( 0 ).props().type ).toBe( 'email' );
  } );

  it( 'renders correct text for username field', () => {
    expect( component.find( 'InputField' ).at( 0 ).props().autoComplete ).toBe( props.autoComplete );
    expect( component.find( 'InputField' ).at( 0 ).props().label ).toBe( messages.emailOrUsername.defaultMessage )
  } );

  it( 'renders correct text for password field', () => {
    expect( component.find( 'InputField' ).at( 1 ).props().autoComplete ).toBe( props.autoComplete );
    expect( component.find( 'InputField' ).at( 1 ).props().label ).toBe( messages.password.defaultMessage )
  } );

  it( 'renders one submit button', () => {
    expect( component.find( '.LoginForm__Submit Button20' ).length ).toBe( 1 );
  } );

  it( 'renders one submit button with btnStyle primary', () => {
    expect( component.find( '.LoginForm__Submit Button20' ).props().btnStyle ).toBe( 'primary' );
  } );

  it( 'renders one submit button with btnStyle secondary', () => {
    expect( componentx.find( '.LoginForm__Submit Button20' ).props().btnStyle ).toBe( 'secondary' );
  } );

  it( 'should render a forget userName and password links', () => {
    expect( component.find( '.LoginForm__forgotCredentials Anchor' ).length ).toBe( 2 );
    expect( component.find( '.LoginForm__forgotCredentials Anchor' ).at( 0 ).text() ).toBe( messages.forgotUsername.defaultMessage );
    expect( component.find( '.LoginForm__forgotCredentials Anchor' ).at( 1 ).text() ).toBe( messages.forgotPassword.defaultMessage );
  } );

  it( 'should render a forget userName URL link', () => {
    expect( component.find( '.LoginForm__forgotCredentials Anchor' ).at( 0 ).props().url ).toBe( '/forgot-username' );
  } );

  it( 'should render a forget password URL link', () => {
    expect( component.find( '.LoginForm__forgotCredentials Anchor' ).at( 1 ).props().url ).toBe( '/forgot-password' );
  } );

  it( 'should render a forget userName and password links with target as _self by default', () => {
    expect( component.find( '.LoginForm__forgotCredentials Anchor' ).at( 0 ).props().target ).toBe( '_self' );
    expect( component.find( '.LoginForm__forgotCredentials Anchor' ).at( 1 ).props().target ).toBe( '_self' );
  } );

  it( 'should render a forget userName and password links with target as _self when openForgetPasswordLinkInNewPage flag is false', () => {
    let props1 = {
      ...props,
      openForgetPasswordLinkInNewPage: false
    }
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <LoginForm { ...props1 }/>
      </Provider>
    );
    expect( component1.find( '.LoginForm__forgotCredentials Anchor' ).at( 0 ).props().target ).toBe( '_self' );
    expect( component1.find( '.LoginForm__forgotCredentials Anchor' ).at( 1 ).props().target ).toBe( '_self' );
  } );

  it( 'should render a forget userName and password links with target as _blank when openForgetPasswordLinkInNewPage flag is true', () => {
    let props1 = {
      ...props,
      openForgetPasswordLinkInNewPage: true
    }
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <LoginForm { ...props1 }/>
      </Provider>
    );
    expect( component1.find( '.LoginForm__forgotCredentials Anchor' ).at( 0 ).props().target ).toBe( '_blank' );
    expect( component1.find( '.LoginForm__forgotCredentials Anchor' ).at( 1 ).props().target ).toBe( '_blank' );
  } );

  it( 'should not render errortext for invalid username or password', () => {
    expect( component.find( '.LoginForm__errors' ).length ).toBe( 0 );
  } );

  const store1 = configureStore( );
  store1.getState().user = { loginMessages:[{ type:'Error', message:'The email address/username or password you entered is invalid. Please try again.' }] };
  store1.getState().global.switchData = {
    switches:{
      enablePersistentLogin:true
    }
  }
  let component1 = mountWithIntl(
    <Provider store={ store1 }>
      <LoginForm { ...props }/>
    </Provider>
  );

  it( 'should render errortext for invalid username or password', () => {
    expect( component1.find( '.LoginForm__errors' ).length ).toBe( 1 );
  } );

  it( 'should invoke broadcast message for invalid username or password and focus should go to username field after 5000ms', () => {
    const broadcastMessageMock = jest.fn();
    const mapDispatchToPropsMock = ()=>{
      return {
        broadcastMessage:broadcastMessageMock
      }
    }
    const LoginFormMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    let component2 = mountWithIntl(
      <Provider store={ store1 }>
        <LoginFormMock { ...props }/>
      </Provider>
    );
    const prevProps = {};
    const focusMock = jest.fn();
    const componentInstance = component2.find( 'LoginForm' ).instance();
    componentInstance.usernameInputField.focus = focusMock;
    componentInstance.componentDidUpdate( prevProps );
    store1.getState().user.loginMessages.map( ( message ) => {
      if( message.message ){
        expect( broadcastMessageMock ).toHaveBeenCalledWith( message.message );
        expect( componentInstance.usernameInputField.focus ).toBeCalled();
      }
    } );
  } );

  it( 'value should not return error when data is present', () => {
    props.defaultEmail = 'fdsfs';
    component = mountWithIntl(
      <Provider store={ store }>
        <LoginForm { ...props }/>
      </Provider>
    );
    expect( store.getState().form.LogIn.syncErrors.username ).toBe( undefined );
  } );

  it( 'Should have novalidate on the form element', () => {
    props.defaultEmail = 'fdsfs';
    component = mountWithIntl(
      <Provider store={ store }>
        <LoginForm { ...props }/>
      </Provider>
    );
    expect( component.find( 'form' ).props().noValidate ).toBe( true );
  } );

  const store2 = configureStore();
  store2.getState().global = {
    switchData:{
      switches:{
        enablePersistentLogin:true
      }
    }
  }
  it( 'value should return error when data is empty', () => {
    props.defaultEmail = '';
    component = mountWithIntl(
      <Provider store={ store2 }>
        <LoginForm { ...props }/>
      </Provider>
    );
    expect( store2.getState().form.LogIn.syncErrors.username ).toBe( 'Required' );
  } );

  it( 'invoke submit ', () => {
    const focusMock = jest.fn();
    const submitUserLoginMock = jest.fn();
    const mapDispatchToPropsMock = () => {
      return {
        submitUserLogin: submitUserLoginMock,
        removeValidationMessages: jest.fn()
      }
    }
    const LoginFormMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    component = mountWithIntl(
      <Provider store={ store2 }>
        <LoginFormMock { ...props }/>
      </Provider>
    );

    const componentInstance = component.find( 'LoginForm' ).instance();
    componentInstance.loginFormSubmitButtonRef.focus = focusMock;
    const values = { sourcePage: 'abc' };
    component.find( 'LoginForm' ).instance().submit( values );
    expect( submitUserLoginMock ).toBeCalled();
    expect( componentInstance.loginFormSubmitButtonRef.focus ).toBeCalled();
  } );

  it( 'submitUserLogin should be called with expected data on invoking submit function', () => {
    props.redirectPage = false;
    props.useRouter = false;
    props.loginSuccessHandler = undefined;
    props.isReauthFlow = false;
    props.loginUserName = 'pqr';

    const submitUserLoginMock = jest.fn();
    const mapDispatchToPropsMock = () => {
      return {
        submitUserLogin: submitUserLoginMock,
        removeValidationMessages: jest.fn()
      }
    }
    const LoginFormMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    component = mountWithIntl(
      <Provider store={ store2 }>
        <LoginFormMock { ...props }/>
      </Provider>
    );
    const values = { sourcePage: 'abc', username: 'xyz', staySignedIn: false };
    const expectedData = {
      values,
      history: props.history,
      analyticsSourcePage: '',
      paths:{
        successPath: props.successPath
      },
      useRouter: props.useRouter,
      redirectPage: props.redirectPage,
      loginSuccessHandler: props.loginSuccessHandler,
      reauth:props.isReauthFlow,
      reauthRetry: false
    }
    component.find( 'LoginForm' ).instance().submit( values );
    expect( submitUserLoginMock ).toHaveBeenCalledWith( expectedData );
  } );

  it( 'should invoke submitUserLogin with staySignedIn as false when the user has not opted for it', () => {
    props.redirectPage = false;
    props.useRouter = false;
    props.sourcePage = 'abc';
    props.loginSuccessHandler = undefined;
    props.isReauthFlow = false;
    props.loginUserName = undefined;

    const submitUserLoginMock = jest.fn();
    const mapDispatchToPropsMock = dispatch => {
      return {
        submitUserLogin: submitUserLoginMock,
        removeValidationMessages: jest.fn()
      }
    }
    const LoginFormMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    component = mountWithIntl(
      <Provider store={ store2 }>
        <LoginFormMock { ...props }/>
      </Provider>
    );
    const expectedData = {
      values:{
        sourcePage: 'abc',
        staySignedIn:false
      },
      history: props.history,
      loginSuccessHandler: props.loginSuccessHandler,
      reauth:props.isReauthFlow,
      reauthRetry: false,
      analyticsSourcePage: '',
      paths:{
        successPath: props.successPath
      },
      useRouter: props.useRouter,
      redirectPage: props.redirectPage
    }
    component.find( 'LoginForm' ).instance().submit( { username: undefined } );
    expect( submitUserLoginMock ).toHaveBeenCalledWith( expectedData );
  } );

  it( 'should invoke submitUserLogin with staySignedIn as true when the user has opted for it', () => {
    props.redirectPage = false;
    props.useRouter = false;
    props.sourcePage = 'abc';
    props.loginSuccessHandler = undefined;
    props.isReauthFlow = false;
    props.loginUserName = 'pqr';
    const values = { sourcePage: 'abc', staySignedIn: false, username: 'pqr' };
    const submitUserLoginMock = jest.fn();
    const mapDispatchToPropsMock = dispatch => {
      return {
        submitUserLogin: submitUserLoginMock,
        removeValidationMessages: jest.fn()
      }
    }
    const LoginFormMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    component = mountWithIntl(
      <Provider store={ store2 }>
        <LoginFormMock { ...props }/>
      </Provider>
    );
    component.find( 'LoginForm' ).instance().setState( { staySignedIn: true } );
    component.update();
    const expectedData = {
      values:{
        username: 'pqr',
        sourcePage: 'abc',
        staySignedIn:true
      },
      history: props.history,
      analyticsSourcePage: '',
      paths:{
        successPath: props.successPath
      },
      useRouter: props.useRouter,
      redirectPage: props.redirectPage,
      loginSuccessHandler: props.loginSuccessHandler,
      reauth:props.isReauthFlow,
      reauthRetry: false
    }
    component.find( 'LoginForm' ).instance().submit( values );
    expect( submitUserLoginMock ).toHaveBeenCalledWith( expectedData );
  } );

  it( 'submitUserLogin should be called with loginSuccessHandler data on invoking submit function if loginSuccessHandler is passed as props', () => {
    props.redirectPage = false;
    props.useRouter = false;
    props.isReauthFlow = false;
    props.loginSuccessHandler = {
      action:'moveToSFL'
    }
    const submitUserLoginMock = jest.fn();
    const mapDispatchToPropsMock = () => {
      return {
        submitUserLogin: submitUserLoginMock,
        removeValidationMessages: jest.fn()
      }
    }
    const LoginFormMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    component = mountWithIntl(
      <Provider store={ store2 }>
        <LoginFormMock { ...props }/>
      </Provider>
    );
    const values = { sourcePage: 'abc' };
    const expectedData = {
      values,
      history: props.history,
      analyticsSourcePage: '',
      paths:{
        successPath: props.successPath
      },
      useRouter: props.useRouter,
      redirectPage: props.redirectPage,
      loginSuccessHandler:props.loginSuccessHandler,
      reauth:props.isReauthFlow,
      reauthRetry: false
    }
    component.find( 'LoginForm' ).instance().submit( values );
    expect( submitUserLoginMock ).toHaveBeenCalledWith( expectedData );
  } );

  it( 'should redirect to myaccount page if hard logged in user is trying to access login form', () => {
    global.location.replace = jest.fn();
    const mapStateToPropsMock = ( state ) => {
      return {
        isHardLoginUser:true,
        formConfig:{
          fieldShowHideToggleData:{}
        }
      }
    }
    const LoginFormMock = connectFunction( mapStateToPropsMock, mapDispatchToProps );
    mountWithIntl(
      <Provider store={ store2 }>
        <LoginFormMock { ...props }/>
      </Provider>
    );
    expect( global.location.replace ).toBeCalledWith( fullyQualifyLink( host, appConstants.ROUTES.ACCOUNT_PAGE ) );
  } );

  it( 'should not redirect to myaccount page if the user is not hard logged in', () => {
    global.location.replace = jest.fn();
    const mapStateToPropsMock = ( state ) => {
      return {
        isHardLoginUser:false,
        formConfig:{
          fieldShowHideToggleData:{}
        }
      }
    }
    const LoginFormMock = connectFunction( mapStateToPropsMock, mapDispatchToProps );
    mountWithIntl(
      <Provider store={ store2 }>
        <LoginFormMock { ...props }/>
      </Provider>
    );
    expect( global.location.replace ).not.toBeCalled();
  } );


  it( 'invoke onSubmitFail  ', () => {
    const dispatch = jest.fn();
    const errors = { test: 'error' }
    onSubmitFail( errors, dispatch );
    expect( dispatch ).toBeCalled();
  } );

  it( 'test mapDispatchToProps  ', () => {
    const dispatch = jest.fn();
    mapDispatchToProps( dispatch ).submitUserLogin( 'test' );
    expect( dispatch ).toBeCalled();
    mapDispatchToProps( dispatch ).removeValidationMessages();
    expect( dispatch ).toHaveBeenCalledWith( { type:'FORMS::CLEAR_VALIDATION_MESSAGES' } );
    const message = 'Test message';
    mapDispatchToProps( dispatch ).broadcastMessage( message );
    expect( dispatch ).toHaveBeenCalledWith( setBroadcastMessage( message ) );
    mapDispatchToProps( dispatch ).removeLoginMessages();
    expect( dispatch ).toHaveBeenCalledWith( { type:'FORMS::CLEAR_LOGIN_ERROR_MESSAGES' } );
    mapDispatchToProps( dispatch ).userLogout( props.history );
    expect( dispatch ).toHaveBeenCalledWith( logoutUser( props.history ) );
  } );

  it( 'should render the toggle button for stay signed in if enablePersistentLogin is true', () => {
    expect( component.find( '.LoginForm__staySignedIn' ).length ).toBe( 1 );
    expect( component.find( 'ToggleButton' ).length ).toBe( 1 );
    expect( component.find( '.ToggleButton__checkBoxField' ).length ).toBe( 1 )
  } );

  it( 'should render staySignedIn and  showDetails text components when showDetails is false', () => {
    expect( component.find( 'Text' ).length ).toBe( 2 );
    expect( component.find( 'Text' ).at( 0 ).text() ).toBe( messages.staySignedIn.defaultMessage )
    expect( component.find( 'Text' ).at( 1 ).text() ).toBe( messages.showDetails.defaultMessage )
  } );

  it( 'should render staySignedInDescription and  hideDetails text components when showDetails is true', () => {
    component.find( 'LoginForm' ).instance().setState( { showDetails: true } );
    component.update();
    expect( component.find( 'Text' ).length ).toBe( 3 );
    expect( component.find( 'Text' ).at( 1 ).text() ).toBe( messages.hideDetails.defaultMessage )
    expect( component.find( 'Text' ).at( 2 ).text() ).toBe( messages.staySignedInDescription.defaultMessage )
  } );

  it( 'should render chevron down when showDetails state is false ', () => {
    expect( component.find( '.LoginForm__staySignedInChevron' ).length ).toBe( 1 );
    expect( component.find( 'FontAwesomeIcon' ).length ).toBe( 1 );
    expect( component.find( '.LoginForm--staySignedInChevronDown' ).length ).toBe( 1 );
  } );

  it( 'should render chevron up when show details state is true', () => {
    component.find( 'LoginForm' ).instance().setState( { showDetails: true } );
    component.update();
    expect( component.find( '.LoginForm--staySignedInChevronDown' ).length ).toBe( 1 );
  } );

  it( 'should toggle the value in showDetails when toggleStaySignedInDetailsDisplay() is called', () => {
    const showDetailsValue = component.find( 'LoginForm' ).state().showDetails;
    component.find( 'LoginForm' ).instance().toggleStaySignedInDetailsDisplay();
    component.update();
    expect( component.find( 'LoginForm' ).state().showDetails ).toEqual( !showDetailsValue );
  } );

  it( 'should toggle the value in staySignedIn when toggleStaySignedInFlag() is called', () => {
    const staySignedIn = component.find( 'LoginForm' ).state().staySignedIn;
    component.find( 'LoginForm' ).instance().toggleStaySignedInFlag();
    component.update();
    expect( component.find( 'LoginForm' ).state().staySignedIn ).toEqual( !staySignedIn );
  } );

  it( 'should not render the toggle button for stay signed in if enablePersistentLogin is false', () => {
    const store3 = configureStore();
    store3.getState().global = {
      switchData:{
        switches:{
          enablePersistentLogin:false
        }
      }
    }
    let component3 = mountWithIntl(
      <Provider store={ store3 }>
        <LoginForm { ...props }/>
      </Provider>
    );
    expect( component3.find( '.LoginForm__staySignedIn' ).length ).toBe( 0 );
    expect( component3.find( 'ToggleButton' ).length ).toBe( 0 );
    expect( component3.find( '.ToggleButton__checkBoxField' ).length ).toBe( 0 )
  } );

  it( 'should render button20 and its props to toggle show/hide stay signed in description', () => {
    let button20Component = '.LoginForm__staySignedIn Button20';
    expect( component.find( button20Component ).length ).toBe( 1 );
    expect( component.find( button20Component ).props().type ).toBe( 'button' );
    expect( component.find( button20Component ).props().btnStyle ).toBe( 'icon' );
    component.find( 'LoginForm' ).instance().setState( { showDetails: true } );
    component.find( button20Component ).simulate( 'click' );
    expect( component.find( 'LoginForm' ).state().showDetails ).toBe( false );

  } );

  it( 'should set the focus to stay signed in description if user clicks on show details', () => {

    let component = mountWithIntl(
      <Provider store={ store2 }>
        <LoginForm { ...props }/>
      </Provider>
    );

    const prevState = { showDetails: true };
    const componentInstance = component.find( 'LoginForm' ).instance();

    componentInstance.componentDidUpdate( {}, prevState );
    componentInstance.setState( { showDetails: true } );

    expect( document.activeElement ).toBe( componentInstance.staySignedInDescriptionRef.current );
  } );

  describe( 'componentWillUnmount', () => {

    it( 'should invoke removeLoginMessages on componentWillUnmount', () => {
      let props = {};
      const removeLoginMessagesMock = jest.fn();
      const mapDispatchToPropsMock = () => {
        return {
          removeLoginMessages: removeLoginMessagesMock
        }
      }

      const LoginFormMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
      let component = mountWithIntl(
        <Provider store={ store }>
          <LoginFormMock { ...props }/>
        </Provider>
      );
      component.find( 'LoginForm' ).instance().componentWillUnmount();
      expect( removeLoginMessagesMock ).toBeCalled();
    } );
  } );

  describe( 'mapStateToProps', () => {
    it( 'should return enablePersistentLogin as true when enablePersistentLogin from global state is true and reauth is false', () => {
      const mockState = {
        global : {
          switchData:{
            switches:{
              enablePersistentLogin:true
            }
          }
        },
        user: {
          isLoginFormSubmitting : true
        },
        pagedata: {
          formConfig: {
            fieldShowHideToggleData: {
              LoginPassword: 'password'
            }
          }
        }
      };
      const propsMock = {
        reauth: false
      }
      expect( mapStateToProps( mockState, propsMock ).enablePersistentLogin ).toEqual( true );
    } );
    it( 'should return enablePersistentLogin as false when enablePersistentLogin from global state is false', () => {
      const mockState = {
        global : {
          switchData:{
            switches:{
              enablePersistentLogin:false
            }
          }
        },
        user: {
          isLoginFormSubmitting : true
        },
        pagedata: {
          formConfig: {
            fieldShowHideToggleData: {
              LoginPassword: 'password'
            }
          }
        }
      };
      const propsMock = {
        reauth: false
      }
      expect( mapStateToProps( mockState, propsMock ).enablePersistentLogin ).toEqual( false );
    } );
    it( 'should return enablePersistentLogin as false when props reauth is true', () => {
      const mockState = {
        global : {
          switchData:{
            switches:{
              enablePersistentLogin:true
            }
          }
        },
        user: {
          isLoginFormSubmitting : true
        },
        pagedata: {
          formConfig: {
            fieldShowHideToggleData: {
              LoginPassword: 'password'
            }
          }
        }
      };
      const propsMock = {
        reauth: true
      }
      expect( mapStateToProps( mockState, propsMock ).enablePersistentLogin ).toEqual( false );
    } );
    it( 'should return enablePersistentLogin as false when enablePersistentLogin from global state is false', () => {
      const mockState = {
        global : {
          switchData:{
            switches:{
              enablePersistentLogin:false
            }
          }
        },
        user: {
          isLoginFormSubmitting : true
        },
        pagedata: {
          formConfig: {
            fieldShowHideToggleData: {
              LoginPassword: 'password'
            }
          }
        }
      };
      expect( mapStateToProps( mockState ).enablePersistentLogin ).toEqual( false );
    } );

    it( 'should return isHardLoginUser as false when isSignedIn is false', () => {
      const mockState = {
        global : {
          switchData:{
            switches:{}
          }
        },
        user: {
          isSignedIn : false,
          isSoftLoginUser:false
        },
        pagedata: {}
      };
      expect( mapStateToProps( mockState ).isHardLoginUser ).toEqual( false );
      mockState.user.isSoftLoginUser = true;
      expect( mapStateToProps( mockState ).isHardLoginUser ).toEqual( false );
    } );

    it( 'should return isHardLoginUser as true when isSignedIn is true and isSoftLoginUser is false', () => {
      const mockState = {
        global : {
          switchData:{
            switches:{}
          }
        },
        user: {
          isSignedIn : true,
          isSoftLoginUser:true
        },
        pagedata: {}
      };
      expect( mapStateToProps( mockState ).isHardLoginUser ).toEqual( false );
      mockState.user.isSoftLoginUser = false;
      expect( mapStateToProps( mockState ).isHardLoginUser ).toEqual( true );
    } );

  } );

  describe( 'relogin form', () => {
    it( 'should render relogin title class LoginForm__getStartedMessage--relogin if isReauthFlow is true', () => {
      props.redirectPage = false;
      props.useRouter = false;
      props.loginSuccessHandler = undefined;
      props.isReauthFlow = true;
      props.reauth = true;

      component = mountWithIntl(
        <Provider store={ store2 }>
          <LoginForm { ...props }/>
        </Provider>
      );
      expect( component.find( 'LoginForm' ).find( '.LoginForm__getStartedMessage--relogin' ).length ).toBe( 1 );
    } );

    it( 'should NOT render Login form stay signed in if isReauthFlow is true', () => {
      expect( component.find( 'LoginForm' ).find( '.LoginForm__staySignedIn' ).length ).toBe( 0 );
    } );

    it( 'should NOT render forgot username link if isReauthFlow is true', () => {
      expect( component.find( 'LoginForm' ).find( '.LoginForm__forgotCredentials Anchor' ).at( 0 ).props().url ).not.toBe( '/forgot-username' );
    } );


    it( 'should render relogin form userName and sign out if reauth is true', () => {
      expect( component.find( 'LoginForm' ).find( '.LoginForm__userName' ).length ).toBe( 1 );
      expect( component.find( 'LoginForm' ).find( '.LoginForm__signOut' ).length ).toBe( 1 );
    } );

    it( 'should render sign out button if reauth is true', () => {
      const signOutBtn = component.find( 'LoginForm' ).find( '.LoginForm__signOut Button20' );
      expect( signOutBtn.length ).toBe( 1 );
      expect( signOutBtn.props().btnStyle ).toBe( 'icon' );
    } );

    it( 'should NOT render email input field if reauth is true', () => {
      expect( component.find( 'LoginForm' ).find( '.LoginForm__field InputField' ).at( 0 ).props().type ).not.toBe( 'email' );
    } );

    it( 'should render email input field if reauth is true', () => {
      expect( component.find( 'LoginForm' ).find( '.LoginForm__Submit--relogin' ).length ).toBe( 1 );
    } );


    it( 'should NOT render relogin title class LoginForm__getStartedMessage--relogin if isReauthFlow is false', () => {
      props.redirectPage = false;
      props.useRouter = false;
      props.loginSuccessHandler = undefined;
      props.isReauthFlow = false;
      props.enablePersistentLogin = true;
      props.reauth = false;

      component = mountWithIntl(
        <Provider store={ store2 }>
          <LoginForm { ...props }/>
        </Provider>
      );
      expect( component.find( 'LoginForm' ).find( '.LoginForm__getStartedMessage--relogin' ).length ).toBe( 0 );
    } );

    it( 'should render forgot username link if isReauthFlow is false', () => {
      expect( component.find( 'LoginForm' ).find( '.LoginForm__forgotCredentials Anchor' ).at( 0 ).props().url ).toBe( '/forgot-username' );
    } );

    it( 'should render Login form stay signed in if isReauthFlow is false and enablePersistentLogin is true', () => {
      expect( component.find( 'LoginForm' ).find( '.LoginForm__staySignedIn' ).length ).toBe( 1 );
    } );

    it( 'should NOT render relogin form userName and sign out option if reauth is false', () => {
      expect( component.find( 'LoginForm' ).find( '.LoginForm__userName' ).length ).toBe( 0 );
      expect( component.find( 'LoginForm' ).find( '.LoginForm__signOut' ).length ).toBe( 0 );
    } );

    it( 'should NOT render sign out button if reauth is true', () => {
      const signOutBtn = component.find( 'LoginForm' ).find( '.LoginForm__signOut Button20' );
      expect( signOutBtn.length ).toBe( 0 );
    } );

    it( 'should render email input field if reauth is false', () => {
      expect( component.find( 'LoginForm' ).find( '.LoginForm__field InputField' ).at( 0 ).props().type ).toBe( 'email' );
    } );

    it( 'should render email input field if reauth is false', () => {
      expect( component.find( 'LoginForm' ).find( '.LoginForm__Submit--relogin' ).length ).toBe( 0 );
    } );

  } );

} );
