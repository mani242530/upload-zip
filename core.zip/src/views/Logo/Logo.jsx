/**
 * Logo
 */

import React from 'react';
import PropTypes from 'prop-types';
import './Logo.css';

import Anchor from '../Anchor/Anchor';
import UltaLogo from '../Icons/ultalogo';
import { formatMessage } from '../Global/Global';
import messages from './Logo.messages';

const propTypes = {
  dataNavDescription: PropTypes.string,
  title: PropTypes.string,
  url: PropTypes.string
}

const defaultProps = {
  title: undefined,
  dataNavDescription: 'h - home',
  url: '/'
}

const Logo = ( props ) => {

  return (
    <div className='Logo'>
      <Anchor
        dataNavDescription={ props.dataNavDescription }
        className='Logo__anchor'
        url={ props.url }
        title={ props.title || formatMessage( messages.UltaLogoText ) }
      >
        <UltaLogo />
      </Anchor>
    </div>
  );

}

Logo.propTypes = propTypes;
Logo.defaultProps = defaultProps;

export default Logo;
