/*
 * Logo Messages
 *
 * This contains all the text for the Logo component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  UltaLogoText: {
    id: 'i18n.Logo.UltaLogoText',
    defaultMessage: 'Ulta Beauty Logo'
  }
} );