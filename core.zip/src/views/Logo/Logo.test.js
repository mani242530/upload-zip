import React from 'react';
import ReactDOM from 'react-dom';
import { shallow } from 'enzyme';
import Logo from './Logo';
import Anchor from '../Anchor/Anchor';
import { formatMessage } from '../Global/Global';
// import renderer from 'react-test-renderer';
import messages from './Logo.messages';

import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<Logo />', () => {
  let component;
  let props = {
    title:'Ulta Beauty Logo'
  }
  it( 'renders without crashing', () => {
    component = mountWithIntl(
      <Logo />
    );
  } );

  it( 'should have a Anchor child element with a link to the home page defined', () => {
    component = mountWithIntl(
      <Logo
        title='Ulta'
      />
    );
    expect( component.find( Anchor ).length ).toEqual( 1 );
    expect( component.find( Anchor ).props().title ).toEqual( 'Ulta' );

  } );

  it( 'should render default message for Logo if the title prop is undefined', () => {
    component = mountWithIntl(
      <Logo
        title={ undefined }
      />
    );
    expect( component.find( Anchor ).length ).toEqual( 1 );
    expect( component.find( Anchor ).props().title ).toEqual( 'Ulta Beauty Logo' );

  } );

} );
