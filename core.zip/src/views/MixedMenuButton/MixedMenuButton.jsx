/**
 * MixedMenuButton
 */

import React from 'react';
import PropTypes from 'prop-types';
import './MixedMenuButton.css';
import delay from 'lodash/delay';
import classNames from 'classnames';
import Anchor from '../Anchor/Anchor';
import PlusMinus from '../PlusMinus/PlusMinus';
import ChevronRightSVG from '../Icons/chevron_right';
import { fireAnalyticsEvent } from '../../utils/omniture/omniture';

const propTypes = {
  fontIcon: PropTypes.object,
  label: PropTypes.string.isRequired,
  url: PropTypes.string,
  pointerType: PropTypes.oneOf( ['link', 'collapse', 'none'] ),
  dataNavDescription: PropTypes.string,
  pointerMinus: PropTypes.bool,
  onClick: PropTypes.func,
  details: PropTypes.string,
  hasPointerChanged: PropTypes.bool,
  // showActiveOnText: takes a boolean and defaults to true
  // when set to false, this attribute disables the active
  // state by NOT applying the '.MixedMenuButton--showActiveOnText' class
  showActiveOnText: PropTypes.bool,

  // showGrayBackgroundOnTap: takes a boolean and defaults to false
  // when set to true, gray background will show on tap state
  // via enabling the '.MixedMenuButton--showGrayBackgroundOnTap' class
  showGrayBackgroundOnTap: PropTypes.bool,
  disabled: PropTypes.bool
}

const defaultProps = {
  url: '#',
  pointerType: 'link',
  pointerMinus: false,
  hasPointerChanged: false,
  showActiveOnText: true,
  showGrayBackgroundOnTap: false,
  disabled: false
}

/**
 * Class
 * @extends React.Component
 */
const MixedMenuButton = ( props ) => {

  let hasPointerChanged = false;

  const handleButtonClick = ( e ) => {
    hasPointerChanged = true;

    delay( () => {
      hasPointerChanged = false;
    }, 100 );

    if( props.onClick ){
      props.onClick( e );
    }
    if( props.analyticsEvent ){
      fireAnalyticsEvent( props.analyticsEvent.eventName, props.analyticsEvent.data );
    }
  }

  const {
    fontIcon,
    label,
    details,
    url,
    pointerType,
    pointerMinus,
    showActiveOnText,
    showGrayBackgroundOnTap,
    dataNavDescription,
    disabled
  } = props;


  return (
    <div
      className={
        classNames( 'MixedMenuButton', {
          'MixedMenuButton--hasDetails': details,
          'MixedMenuButton--noDetails': !details,
          'MixedMenuButton--highlight': pointerMinus,
          'MixedMenuButton--reShowhighlight': !pointerMinus && hasPointerChanged,
          'MixedMenuButton--showActiveOnText': showActiveOnText,
          'MixedMenuButton--showGrayBackgroundOnTap': showGrayBackgroundOnTap,
          'MixedMenuButton--disabled': disabled
        } )
      }
      onClick={ handleButtonClick }
      role='link'
      aria-expanded={ pointerMinus }
      tabIndex='0'
    >
      <Anchor
        dataNavDescription={ dataNavDescription }
        url={ url }
      >
        { fontIcon &&
          (
            <div className='MixedMenuButton__Icon'>
              { fontIcon }
            </div>
          )
        }
        <div
          className='MixedMenuButton__TextWrap'
        >
          <p className='MixedMenuButton__Text MixedMenuButton__Text--label'>
            { label }
          </p>
          {
            ( ()=>{
              if( details ){
                return (
                  <p className='MixedMenuButton__Text MixedMenuButton__Text--details'>
                    { details }
                  </p>
                )
              }
            } )()
          }
        </div>
        {
          ( ()=>{
            if( pointerType === 'link' ){
              let Svg = ChevronRightSVG;
              return (
                <div className='MixedMenuButton__pointer MixedMenuButton__pointer--chevron'>
                  <Svg />
                </div>
              )
            }
            else if( pointerType === 'collapse' ){
              return (
                <div className='MixedMenuButton__pointer MixedMenuButton__pointer--plusminus'>
                  <PlusMinus minus={ pointerMinus } />
                </div>
              )
            }
          } )()
        }
      </Anchor>
    </div>
  )

}

MixedMenuButton.propTypes = propTypes;
MixedMenuButton.defaultProps = defaultProps;

export default MixedMenuButton;
