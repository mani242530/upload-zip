import React from 'react';
import ReactDOM from 'react-dom';
import _ from 'lodash';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPhone } from '@fortawesome/pro-light-svg-icons/faPhone';
import { shallow } from 'enzyme';
import MixedMenuButton from './MixedMenuButton';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
import { fireAnalyticsEvent } from '../../utils/omniture/omniture';
import Anchor from '../Anchor/Anchor';

jest.mock( './../../utils/omniture/omniture', () => {
  return {
    fireAnalyticsEvent: jest.fn(),
    updateDataLayer: jest.fn()
  }
} );

describe( '<MixedMenuButton />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <MixedMenuButton label='hi' /> );
    expect( component.find( 'MixedMenuButton' ).length ).toBe( 1 );
  } );

  it( 'should render a second row when details data is passed', () => {

    component = mountWithIntl( <MixedMenuButton label='hi' details='test' /> );
    var details = component.find( '.MixedMenuButton__Text--details' )

    expect( details.length ).toBe( 1 );
  } );

  it( 'should render a collapse when configured to do so', () => {

    component = mountWithIntl( <MixedMenuButton label='hi' pointerType='collapse' /> );
    var plusminus = component.find( '.MixedMenuButton__pointer--plusminus' )

    expect( plusminus.length ).toBe( 1 );
  } );

  it( 'should render a chevron if the type is link', () => {
    component = mountWithIntl( <MixedMenuButton label='hi' pointerType='link' /> );
    var chevron = component.find( '.MixedMenuButton__pointer--chevron' );
    expect( chevron.length ).toBe( 1 );
  } )

  it( 'should render no pointer if the type is none', () => {

    component = mountWithIntl( <MixedMenuButton label='hi' pointerType='none' /> );
    var chevron = component.find( '.MixedMenuButton__pointer--chevron' )
    var plusminus = component.find( '.MixedMenuButton__pointer--plusminus' )

    expect( chevron.length ).toBe( 0 );
    expect( plusminus.length ).toBe( 0 );
  } );

  it( 'should render no icon if no icon is passed', () => {

    component = mountWithIntl( <MixedMenuButton label='hi' pointerType='none' /> );
    var icon = component.find( '.MixedMenuButton__Icon' )

    expect( icon.length ).toBe( 0 );
  } );

  it( 'should not have an font awesome icon  as a child if fontIcon is not passed', () => {

    component = shallow( <MixedMenuButton label='hi' pointerType='none' /> );
    let childAnchor1 = component.children( Anchor );
    let fontAwsomeTag = childAnchor1.find( FontAwesomeIcon );

    expect( fontAwsomeTag.length ).toBe( 0 );
  } );

  it( 'should have an font awesome icon  as a child if fontIcon is passed', () => {

    component = shallow( <MixedMenuButton label='hi' fontIcon={ <FontAwesomeIcon fontIcon={ faPhone } /> } /> );
    let childAnchor1 = component.children( Anchor );
    let fontAwsomeTag = childAnchor1.find( FontAwesomeIcon );

    expect( fontAwsomeTag.length ).toBe( 1 );
  } );

  it( 'should call the prop onClick when passed and clicked', () => {

    var mockClick = jest.fn();
    component = mountWithIntl( <MixedMenuButton label='hi' fontIcon={ <FontAwesomeIcon fontIcon={ faPhone } /> } onClick={ mockClick } /> );
    let wrapped = component.find( 'MixedMenuButton' );
    component.simulate( 'click' )
    expect( mockClick ).toHaveBeenCalled();
    // expect(component.props().hasPointerChanged).toBe(true);


  } );

  it( 'role and aria-expanded attribute is present for the mixedmenu component', () => {

    component = mountWithIntl(
      <MixedMenuButton
        label='Pick One Free Sample'
        fontIcon={ <FontAwesomeIcon fontIcon={ faPhone } /> }
        pointerType='collapse'
      />
    );

    expect( component.find( '.MixedMenuButton' ).props().role ).toBe( 'link' );
    expect( component.find( '.MixedMenuButton' ).props()['aria-expanded'] ).toBe( false );
    expect( component.find( '.MixedMenuButton' ).props()['tabIndex'] ).toBe( '0' );

  } );

  it( 'aria-expanded attribute should have the value true for mixedmenu component when pointerMinus prop is true', () => {

    component = mountWithIntl(
      <MixedMenuButton
        label='Pick One Free Sample'
        fontIcon={ <FontAwesomeIcon fontIcon={ faPhone } /> }
        pointerType='collapse'
        pointerMinus={ true }
      />
    );

    expect( component.find( '.MixedMenuButton' ).props()['aria-expanded'] ).toBe( true );

  } );


  it( ' Should trigger fireAnalyticsEvent if MixedMenuButton component is  having analyticsEvent prop', () => {

    let props = {
      analyticsEvent:{
        eventName: 'pdpContentClick',
        data: {
          'productSku':'2305872',
          'pdpContentSection': 'how to use',
          'pdpContentClickAction': 'expand'
        }
      }
    }
    const component1 =  mountWithIntl(
      <MixedMenuButton
        label='Pick One Free Sample'
        fontIcon={ <FontAwesomeIcon fontIcon={ faPhone } /> }
        pointerType='collapse'
        pointerMinus={ true }
        { ...props }
      />
    );
    component1.find( 'MixedMenuButton' ).simulate( 'click' )
    expect( fireAnalyticsEvent ).toBeCalled();

  } );

} );
