import React, { Component } from 'react';
import Modal from 'react-modal';

// make a new context
export const ModalContext = React.createContext();

// create a provider Component
class ModalWrapper extends Component{

  constructor( props ){
    super( props );
    if( this.props.appElement ){
      Modal.setAppElement( this.props.appElement );
    }
  }


  render(){
    return (
      <div className='ModalWrapper'>
        <ModalContext.Provider value={ {
          type:'Modal'
        } }
        >
          <Modal
            { ...( this.props.isOpen && { isOpen:this.props.isOpen } ) }
            { ...( this.props.contentLabel && { contentLabel:this.props.contentLabel } ) }
            { ...( this.props.className && { className:this.props.className } ) }
            { ...( this.props.onRequestClose && { onRequestClose:this.props.onRequestClose } ) }
            { ...( this.props.role && { role:this.props.role } ) }
            { ...( this.props.style && { style:this.props.style } ) }
          >
            { this.props.children }
          </Modal>
        </ModalContext.Provider>
      </div>
    )
  }
}

export default ModalWrapper;