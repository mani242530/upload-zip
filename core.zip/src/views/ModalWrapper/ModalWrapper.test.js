import React from 'react';
import _ from 'lodash';
import Modal from 'react-modal';
import ModalWrapper, { ModalContext } from './ModalWrapper';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';


describe( '<ModalProvider /> ', () => {
  it( 'should render without crashing and any componenet who is set up as a consumer should received the type prop with the value modal', () => {
    const mockMethod = jest.fn( ( value )=> <div>test</div> );
    const component = mountWithIntl( <ModalWrapper isOpen={ true }><ModalContext.Consumer>{ mockMethod }</ModalContext.Consumer></ModalWrapper> );
    expect( component.find( 'ModalWrapper' ) ).toBeTruthy();
    expect( mockMethod ).toHaveBeenCalledWith( { type:'Modal' } );
  } );

  it( 'should pass those props which was passed to the Modal component to the Modal', () => {
    const props = {
      isOpen: true,
      contentLabel:'label',
      className:'AddToBag__Modal',
      onRequestClose:jest.fn(),
      role:'dialog',
      style:{
        overlay: {
          backgroundColor: 'rgba(0,0,0,0.55)'
        }
      }

    }
    const component = mountWithIntl( <ModalWrapper { ...props }/> );
    expect( component.find( 'Modal' ).props().isOpen ).toBe( props.isOpen );
    expect( component.find( 'Modal' ).props().contentLabel ).toBe( props.contentLabel );
    expect( component.find( 'Modal' ).props().className ).toBe( props.className );
    expect( component.find( 'Modal' ).props().onRequestClose ).toBe( props.onRequestClose );
    expect( component.find( 'Modal' ).props().role ).toBe( props.role );
    expect( component.find( 'Modal' ).props().style ).toBe( props.style );
  } );

  it( 'should render without crashing and any componenet who is set up as a consumer should received the type prop with the value modal', () => {
    Modal.setAppElement = jest.fn();
    const component = mountWithIntl( <ModalWrapper isOpen={ true } appElement='#js-container'/> );
    expect( Modal.setAppElement ).toHaveBeenCalledWith( '#js-container' );
  } );

} )