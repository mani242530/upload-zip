/**
* Paragraph Component
* For Paragraph with class primary, secondary and tertiary
* Usage:
* import Paragraph from './../../views/Paragraph/Paragraph';
* <Paragraph
    type='primary'
  >TEXT HERE
  </Paragraph>
* or
  <Paragraph
    type='secondary'
  >TEXT HERE<span>extra markup here</span>
  </Paragraph>
* or
  <Paragraph
    type='tertiary'
  >TEXT HERE
  </Paragraph>
*/

import React from 'react';
import PropTypes from 'prop-types';
import './Paragraph.css';

const Paragraph = ( {
  children,
  type = 'primary'
} ) => {
  const Tag = `p`;
  return (
    <Tag className={ `${type}` }>
      { children }
    </Tag>
  );
};
Paragraph.propTypes = {
  type: PropTypes.oneOf( [
    'primary',
    'secondary',
    'tertiary'
  ] )
};
export default Paragraph;
