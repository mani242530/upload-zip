import React from 'react';
import ReactDOM from 'react-dom';
import Paragraph from './Paragraph';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<Paragraph /> ', () => {
  it( 'renders without crashing', () => {
    const div = document.createElement( 'div' );
    ReactDOM.render( <Paragraph />, div );
  } );
  it( 'should render the component with the class .primary when primary is passed as the type', () => {
    let component = mountWithIntl( <Paragraph type='primary' /> );
    expect( component.find( 'Paragraph' ).props().type ).toBe( 'primary' );
    expect( component.find( '.primary' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .secondary when secondary is passed as the type', () => {
    let component = mountWithIntl( <Paragraph type='secondary' /> );
    expect( component.find( 'Paragraph' ).props().type ).toBe( 'secondary' );
    expect( component.find( '.secondary' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .tertiary when tertiary is passed as the type', () => {
    let component = mountWithIntl( <Paragraph type='tertiary' /> );
    expect( component.find( 'Paragraph' ).props().type ).toBe( 'tertiary' );
    expect( component.find( '.tertiary' ).length ).toBe( 1 );
  } );

} );
