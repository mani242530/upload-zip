/**
 * PlusMinus
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './PlusMinus.css';


const propTypes = {
  minus: PropTypes.bool
}

const defaultProps = {
  minus: false
}

/**
 * Class
 * @extends React.Component
 */
class PlusMinus extends Component{

  /**
   * Renders the PlusMinus component
   */
  render(){
    let classModifier = this.props.minus ? 'horizontal' : 'vertical';
    return (
      <div className='PlusMinus'>
        <div className='PlusMinus__crossbar PlusMinus__crossbar--horizontal'></div>
        <div className={ `PlusMinus__crossbar PlusMinus__crossbar--${classModifier}` }></div>
      </div>
    );
  }
}

PlusMinus.propTypes = propTypes;
PlusMinus.defaultProps = defaultProps;

export default PlusMinus;
