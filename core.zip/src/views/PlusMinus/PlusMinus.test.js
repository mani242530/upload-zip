import React from 'react';
import ReactDOM from 'react-dom';
import { shallow } from 'enzyme';
import ShallowRenderer from 'react-test-renderer/shallow';
import { IntlProvider } from 'react-intl';
import PlusMinus from './PlusMinus';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<PlusMinus />', () => {
  let component;

  const renderer = new ShallowRenderer();

  it( 'renders without crashing', () => {
    component = shallow( <PlusMinus /> );
    expect( component.length ).toBe( 1 );
  } );

  let crossbar1, crossbar2, classes;

  describe( 'minus is true', () => {
    it( 'renders a "-" sign when passed this.props.minus = true', () => {
      component = shallow( <PlusMinus minus={ true } /> );

      crossbar2 = component.find( '.PlusMinus__crossbar' ).at( 1 );


      classes = crossbar2.props().className;
      expect( classes.indexOf( 'PlusMinus__crossbar--horizontal' ) ).not.toBe( -1 );

    } );

    it( 'should match the snapshot', () => {
      renderer.render( <PlusMinus minus={ true } /> );
      expect( renderer.getRenderOutput() ).toMatchSnapshot();
    } );

  } );

  describe( 'minus is false', () => {
    it( 'renders a "+" sign when passed this.props.minus = false', () => {
      component = shallow( <PlusMinus minus={ false } /> );

      crossbar2 = component.find( '.PlusMinus__crossbar' ).at( 1 );


      classes = crossbar2.props().className;
      expect( classes.indexOf( 'PlusMinus__crossbar--vertical' ) ).not.toBe( -1 );
    } );

    it( 'matches the snapshot', () => {
      renderer.render( <PlusMinus minus={ false } /> );
      expect( renderer.getRenderOutput() ).toMatchSnapshot();
    } );
  } );


} );
