/**
 * Product
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './Product.css';
import classNames from 'classnames';
import { connect } from 'react-redux';
import { formatMessage, formatNumber } from '../Global/Global';
import messages from './Product.messages';
import Image from '../Image/Image';
import Anchor from '../Anchor/Anchor';
import RatingPanel from '../RatingPanel/RatingPanel';
import Button from '../Button/Button';
import Text from '../Text/Text';
import {
  getActionDefinition
} from '../../events/services/services.events';
import {
  triggerReflektionEvents
} from '../../events/reflektion/reflektion.events';
import {
  host,
  fullyQualifyLink
} from '../../utils/formatters/formatters';
const propTypes = {
  clickURL:PropTypes.string.isRequired,
  brandName:PropTypes.string,
  productDisplayName:PropTypes.string.isRequired,
  productImageUrl:PropTypes.string.isRequired,
  lowRangeListPrice:PropTypes.number,
  highRangeListPrice:PropTypes.number,
  powerReviewRating:PropTypes.number,
  badges:PropTypes.any,
  productVariant:PropTypes.string,
  numReviews:PropTypes.number,
  promotion:PropTypes.any,
  variantCount:PropTypes.number,
  productId:PropTypes.string,
  skuId:PropTypes.string,
  section:PropTypes.string,
  isQuickShopEnabled:PropTypes.bool,
  crossSellLocation: PropTypes.string,
  productIndex: PropTypes.number,
  sectionWidgetId: PropTypes.string
}



/**
 * Class
 * @extends React.Component
 */
class Product extends Component{


  getVariantLink( variant, variantCount ){
    if( variant === null ){
      return ' ';
    }
    else {
      return `${variantCount} ${variant}` ;
    }
  }

  productBadge( badges ){
    if( badges === null ){
      return ( <div></div> );
    }
    else {
      for ( let i = 0;i < badges.length;i++ ){

        // image url property for badges in MHP service is different from productrecs service .
        // will revert this once homepage service is updated .
        const badgeImageUrl = ( badges[i].badgeImageUrl ) ? badges[i].badgeImageUrl : badges[i].imageURL ;
        return (

          <div className='Product Product__badgeImage' key={ i }>
            <Image
              className=''
              src={ `${badgeImageUrl}?fmt=png-alpha` }
              alt=''
              injectSVG={ true }
              lazyLoad={ false }
            />
          </div>
        );
      }
    }
  }

  getProductRating( rating ){
    return ( rating * 15 )
  }


  getProductHighPrice( lowPrice, highPrice ){
    if( lowPrice === highPrice ){
      return formatNumber( highPrice, { style: 'currency', currency: 'USD' } );
    }
    else {
      return `${ formatNumber( lowPrice, { style: 'currency', currency: 'USD' } ) }-${ formatNumber( highPrice, { style: 'currency', currency: 'USD' } ) }` ;
    }
  }

  // formatting promotion props
  getPromotion( promotion ){
    if( promotion === null ){
      return '';
    }
    else {
      // the structure of promotion from prodcuctrecs service is different from home page service  .
      if( typeof promotion === 'string' ){
        return promotion;
      }
      for ( let i = 0;i < promotion.length;i++ ){
        return promotion[i].offerDescription + '\n';
      }

    }
  }

  /**
  * Use to track cross sell clicks for omniture.
  */
  isCrossSell( section, skuId, crossSellLocation ){
    let analyticsEvent = undefined;
    if( section ){
      analyticsEvent = {
        eventName: 'crossSellClick',
        data: {
          crossSellType: section,
          crossSellLocation:crossSellLocation,
          crossSellSku:skuId
        }
      };
      return ( analyticsEvent );
    }
  }

  // Generate the reflektionData for reflektion widget click event
  constructReflektionWidgetClickData( sectionWidgetId, productIndex, skuId ){
    const reflektionData = {
      'type': 'widget',
      'name': 'click',
      'value': {
        'rfkid': sectionWidgetId,
        'index': productIndex,
        'f': 'rw',
        'products': [
          {
            'sku': skuId
          }
        ]
      }
    } ;
    this.props.triggerReflektionWidgetClickEvent( reflektionData );
  }

  render(){


    const {
      clickURL,
      brandName,
      productDisplayName,
      productImageUrl,
      lowRangeListPrice,
      highRangeListPrice,
      lowRangeSalePrice,
      highRangeSalePrice,
      powerReviewRating,
      badges,
      productVariant,
      numReviews,
      promotion,
      variantCount,
      productId,
      skuId,
      section,
      showOnlyListPrice,
      listPrice,
      salePrice,
      isQuickShopEnabled,
      crossSellLocation,
      sectionWidgetId,
      productIndex
    } = this.props;


    return (
      <div className='Product'>
        <Anchor
          analyticsEvent={ this.isCrossSell( section, skuId, crossSellLocation ) }
          clickHandler={ () => {
            this.constructReflektionWidgetClickData( sectionWidgetId, productIndex, skuId );
            // Redirecting to the specified product detail page specified in the clickURL . in order ot handle the click event ,
            // prevent the default behaviour of Anchor tag
            global.location.href = fullyQualifyLink( host, clickURL ) ;
          } }
        >
          <div>
            <div className='Product__details'>
              <div className='Product Product__details Product__productImage'>
                { this.productBadge( badges ) }
                <Image
                  src={ productImageUrl }
                  alt={ brandName }
                  injectSVG={ true }
                  lazyLoad={ false }
                />
                { isQuickShopEnabled &&
                  (
                    <Button
                      className='Product__QShopButton'
                      btnOption='single'
                      inputTag='button'
                      btnSize='sm'
                      analyticsEvent={ this.isCrossSell( section, skuId, crossSellLocation ) }
                      clickEventHandler={ ( e )=> {
                        e.preventDefault();
                        e.stopPropagation();
                        this.constructReflektionWidgetClickData( sectionWidgetId, productIndex, skuId );
                        this.props.displayQuickShop( productId, section );

                      } }
                    >
                      { formatMessage( messages.quickShop ) }
                    </Button>
                  )
                }
              </div>
              { numReviews > 0 &&
                (
                  <div className='Product__ratingPanelContainer' >
                    <RatingPanel
                      reviews={ numReviews }
                      width={ this.getProductRating( powerReviewRating ) }
                    />
                  </div>
                )
              }
              <div
                className={
                  classNames(
                    'Product Product__details Product__brandName', {
                      'Product__brandName--noRating': numReviews <= 0
                    }
                  )
                }
              >
                <Text
                  htmlTag='p'
                  type='caption'
                  fontWeight='bold'
                  textAlign='center'
                >
                  { ( brandName ).toUpperCase() }
                </Text>
              </div>
              <div className='Product Product__details  Product__productName'>
                <Text
                  htmlTag='p'
                  type='caption'
                  textAlign='center'
                  lineHeight='large'
                >
                  { productDisplayName }
                </Text>
              </div>
              <div className='Product Product__details Product__price'>
                { !salePrice &&
                  (
                    <span className='Product__price--range'>
                      { this.getProductHighPrice( lowRangeListPrice, highRangeListPrice ) }
                    </span>
                  )
                }
                { !!salePrice &&
                  (
                    <div className='Product__saleprice'>
                      <span className='Product__saleprice--regular'>
                        { this.getProductHighPrice( lowRangeListPrice, highRangeListPrice ) }
                      </span>
                      <span className='Product__saleprice--sale'>
                        { this.getProductHighPrice( lowRangeSalePrice, highRangeSalePrice ) }
                      </span>
                    </div>
                  )
                }
              </div>
              <div className='Product Product__details Product__variants'>
                <Text
                  htmlTag='p'
                  type='caption'
                  textAlign='center'
                >
                  { this.getVariantLink( productVariant, variantCount ) }
                </Text>
              </div>
              <div className='Product Product__details Product__promo'>
                <Text
                  htmlTag='p'
                  type='caption'
                  textAlign='center'
                  fontWeight='bold'
                >
                  { this.getPromotion( promotion ) }
                </Text>
              </div>
            </div>
          </div>
        </Anchor>
      </div>
    )
  }

}

Product.propTypes = propTypes;



export const mapDispatchToProps = ( dispatch ) => {
  return {
    displayQuickShop:( productId, section )=>{
      dispatch( getActionDefinition( 'qsProductDetails', 'requested' )( { productId, section } ) );
    },
    triggerReflektionWidgetClickEvent : ( reflektionData ) =>{
      dispatch( triggerReflektionEvents( reflektionData ) );
    }
  }
}

export const connectFunction = ( mapDispatchToProps ) => {
  return ( connect( null, mapDispatchToProps )( Product ) );
};
export default connectFunction( mapDispatchToProps );
