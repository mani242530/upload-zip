/*
 * Product Messages
 *
 * This contains all the text for the Product component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  variantMessage:{
    id:'i18n.Product.variantMessage',
    defaultMessage:'\\\\  Shop  {variantCount} {variant}  \\\\'
  },
  quickShop: {
    id: 'i18n.QuickShopModal.quickShop',
    defaultMessage: 'Quick Shop'
  }
} );
