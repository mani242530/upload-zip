import React from 'react';
import { Provider } from 'react-redux';
import {
  connectFunction,
  mapDispatchToProps
} from './Product';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';
import messages from './Product.messages';
import {
  getActionDefinition,
  registerServiceName
} from '../../events/services/services.events';
import {
  triggerReflektionEvents
} from '../../events/reflektion/reflektion.events';
jest.mock( './../../events/reflektion/reflektion.events', () => {
  return {
    triggerReflektionEvents: jest.fn()
  }
} );
let mockJestFn = jest.fn();

let displayQuickShopMock = jest.fn();

let mapDispatchToPropsMock = ( dispatch ) =>{
  return {
    displayQuickShop: mockJestFn,
    triggerReflektionWidgetClickEvent : mockJestFn
  }
};

let props = {
  'clickURL':'/theyre-real-lengthening-mascara?productId=xlsImpprod3460265',
  'brandName':'Benefit Cosmetics',
  'productDisplayName':'They\'re Real! Lengthening Mascara',
  'productImageUrl':'http://images.ulta.com/is/image/Ulta/2289451?$md$',
  'lowRangeListPrice':24,
  'highRangeListPrice':24,
  'powerReviewRating':0,
  'badges':[
    {
      'badgeName':'gwp_badge',
      'badgeImageUrl':'http://images.ulta.com/is/image/Ulta/badge-free-gift',
      'priority':4
    }
  ],
  'productVariant': 'Colors',
  'numReviews':0,
  'promotion':[
    {
      'promoType':'G',
      'offerDescription':'Special Free Gift with Purchase'
    }
  ],
  'variantCount':3,
  'intl':{
    'locale':'en',
    'formats':{

    },
    'messages':{

    },
    'textComponent':'span',
    'defaultLocale':'en',
    'defaultFormats':{

    },
    'formatters':{

    },
    isCrossSell:jest.fn()
  },
  productId: '123',
  skuId:'123',
  crossSellLocation:'Product',
  section:'People Also Viewed',
  sectionWidgetId:'abc',
  tabIndex:2,
  isQuickShopEnabled : true,
  displayQuickShop:displayQuickShopMock,
  salePrice : 9.99
}
let store = configureStore( );

let ProductMock = connectFunction( mapDispatchToPropsMock );

describe( '<Product />', () => {


  it( 'renders without crashing', () => {
    let component = mountProduct( props );
    expect( component.find( 'Product' ).length ).toBe( 1 );

  } );
  describe( '<Product /> props', ()=>{
    it( 'Should contain analyticsEvent as props for Product Anchor', () => {
      let component = mountProduct( props );
      expect( component.find( 'Product Anchor' ).props().analyticsEvent ).toEqual( component.find( 'Product' ).instance().isCrossSell( props.section, props.skuId, props.crossSellLocation ) );
    } );
  } );

  it( 'should render product badge images', ()=>{
    let component = mountProduct( props );
    expect( component.find( '.Product__productImage' ).find( 'Image' ).length ).toBe( 2 );
    expect( component.find( '.Product__productImage' ).find( 'Image' ).at( 0 ).props().src ).toBe( props.badges[0].badgeImageUrl + '?fmt=png-alpha' );
  } );

  describe( 'Component display', ()=>{

    it( 'should render brand name when it is passed as prop', ()=>{
      let component = mountProduct( props );
      expect( component.find( '.Product__brandName' ).text() ).toBe( props.brandName.toUpperCase() );
      expect( component.find( '.Product__brandName Text' ).props() ).toEqual( {
        'children': 'BENEFIT COSMETICS',
        'fontWeight': 'bold',
        'htmlTag': 'p',
        'textAlign': 'center',
        'type': 'caption'
      } );
    } );
    it( 'should render product name', ()=>{
      let component = mountProduct( props );
      expect( component.find( '.Product__productName' ).text() ).toBe( props.productDisplayName );
      expect( component.find( '.Product__productName Text' ).props() ).toEqual( {
        'children': 'They\'re Real! Lengthening Mascara',
        'htmlTag': 'p',
        'textAlign': 'center',
        'type': 'caption',
        'lineHeight': 'large'
      } );
    } );
    it( 'should render product badge images', ()=>{
      let component = mountProduct( props );
      expect( component.find( '.Product__productImage' ).find( 'Image' ).length ).toBe( 2 );
      expect( component.find( '.Product__productImage' ).find( 'Image' ).at( 0 ).props().src ).toBe( props.badges[0].badgeImageUrl + '?fmt=png-alpha' );
    } );
    it( 'should render product image', ()=>{
      let component = mountProduct( props );
      expect( component.find( '.Product__productImage' ).find( 'Image' ).at( 1 ).props().src ).toBe( props.productImageUrl );
      expect( component.find( '.Product__productImage' ).find( 'Image' ).at( 1 ).props().alt ).toBe( props.brandName );
    } );
    it( 'Should render single price of product', ()=>{
      props.listprice = 19.95;
      props.salePrice = 0;
      props.lowRangeListPrice = 19.95;
      props.highRangeListPrice = 19.95;
      props.lowRangeSalePrice = 0;
      props.highRangeSalePrice = 0;
      let component = mountProduct( props );
      expect( component.find( '.Product__price--range' ).text() ).toBe( '$19.95' );
    } );

    it( 'Should render range  price of product', ()=>{
      props.listprice = 19.95;
      props.salePrice = 0;
      props.lowRangeListPrice = 19.95;
      props.highRangeListPrice = 39.95;
      props.lowRangeSalePrice = 0;
      props.highRangeSalePrice = 0;
      let component = mountProduct( props );
      expect( component.find( '.Product__price--range' ).text() ).toBe( '$19.95-$39.95' );
    } );

    it( 'Should render range price of product with sales price range', ()=>{
      let props1 = props;
      props.listprice = 19.95;
      props.salePrice = 44;
      props.lowRangeListPrice = 19.95;
      props.highRangeListPrice = 39.95;
      props.lowRangeSalePrice = 2;
      props.highRangeSalePrice = 5;
      let component2 =  mountProduct( props1 );
      expect( component2.find( '.Product__saleprice--regular' ).text() ).toBe( '$19.95-$39.95' );
      expect( component2.find( '.Product__saleprice--sale' ).text() ).toBe( '$2.00-$5.00' );
    } );

    it( 'Should render regular price product with sales price', ()=>{
      let props1 = props;
      props.listprice = 19.95;
      props.salePrice = 2;
      props.lowRangeListPrice = 19.95;
      props.highRangeListPrice = 19.95;
      props.lowRangeSalePrice = 2;
      props.highRangeSalePrice = 2;
      let component2 =  mountProduct( props1 );
      expect( component2.find( '.Product__saleprice--regular' ).text() ).toBe( '$19.95' );
      expect( component2.find( '.Product__saleprice--sale' ).text() ).toBe( '$2.00' );
    } );
    it( 'should render the variants of the product', () => {


      let message = `${props.variantCount} ${props.productVariant}`;
      let component = mountProduct( props );
      expect( component.find( '.Product__variants' ).text() ).toBe( message );
      expect( component.find( '.Product__variants Text' ).props() ).toEqual( {
        'children': message,
        'htmlTag': 'p',
        'textAlign': 'center',
        'type': 'caption'
      } );
    } );
    it( 'Should render promotion text', () => {
      let component = mountProduct( props );
      expect( component.find( '.Product__promo' ).text() ).toBe( props.promotion[0].offerDescription + '\n' );
      expect( component.find( '.Product__promo Text' ).props() ).toEqual( {
        'children': props.promotion[0].offerDescription + '\n',
        'htmlTag': 'p',
        'textAlign': 'center',
        'type': 'caption',
        'fontWeight':'bold'
      } );
    } );
    it( 'Should render promotion text if typeof promotion is string', () => {
      let props1 = props;
      props1.promotion = 'Special Free Gift with Purchase';

      let testElement = mountProduct( props1 );
      expect( testElement.find( '.Product__promo' ).text() ).toBe( props.promotion );
    } );
    it( 'Should render quick shop button and pass appropriate props to trigger analytics while clicking the quickshop button', () => {
      let props1 = props;
      let expectedData = { 'eventName':'crossSellClick', 'data':{ 'crossSellType':'People Also Viewed', 'crossSellLocation':'Product', 'crossSellSku':'123' } };
      props1.isQuickShopEnabled = true;
      let component = mountProduct( props1 );
      expect( component.find( '.Product__productImage Button' ).length ).toBe( 1 );
      expect( component.find( '.Product__productImage Button' ).props().analyticsEvent ).toEqual( expectedData );
    } ) ;
  } );

  describe( '<Product /> clickHandlers', () => {
    it( 'should invoke displayQuickShop on click of quick shop button passing productId as paramter', () =>{
      let component = mountProduct( props );
      let node = component.find( 'Product' ).instance();
      component.find( '.Product__productImage button' ).simulate( 'click' );
      expect( node.props.displayQuickShop ).toHaveBeenCalledWith( props.productId, props.section );
    } );
    it( 'should invoke constructReflektionWidgetClickData on click of quick shop button passing sectionWidgetId, productIndex and skuId as paramter', () =>{
      let component = mountProduct( props );
      let node = component.find( 'Product' ).instance();
      node.constructReflektionWidgetClickData = jest.fn() ;
      component.find( '.Product__productImage button' ).simulate( 'click' );
      expect( node.constructReflektionWidgetClickData ).toHaveBeenCalledWith( props.sectionWidgetId, props.productIndex, props.skuId );
    } );
    it( 'should call the  triggerReflektionWidgetClickEvent  with reflektionData when constructReflektionWidgetClickData is executed', () => {
      const component2 = mountProduct( props );
      let node = component2.find( 'Product' ).instance();
      node.constructReflektionWidgetClickData( props.sectionWidgetId, props.productIndex, props.skuId );
      const reflektionData = {
        'type': 'widget',
        'name': 'click',
        'value': {
          'rfkid': props.sectionWidgetId,
          'index': props.productIndex,
          'f': 'rw',
          'products': [
            {
              'sku': props.skuId
            }
          ]
        }
      } ;
      expect( node.props.triggerReflektionWidgetClickEvent ).toHaveBeenCalledWith( reflektionData );
    } );
    it( 'should invoke constructReflektionWidgetClickData on click of product recs passing sectionWidgetId, productIndex and  skuId as paramter', () =>{
      let component = mountProduct( props );
      component.find( 'Product' ).instance().constructReflektionWidgetClickData = jest.fn() ;
      expect( component.find( 'Product' ).instance().constructReflektionWidgetClickData ).not.toBeCalled();
      component.find( 'Product Anchor' ).simulate( 'click' );
      expect( component.find( 'Product' ).instance().constructReflektionWidgetClickData ).toHaveBeenCalledWith( props.sectionWidgetId, props.productIndex, props.skuId );
    } );
  } );
  describe( '<Product /> MapDispatchToProps', () => {
    it( 'should dispatch the proper action when displayQuickShop is invoked ', () => {
      const dispatch = jest.fn();
      const mdp  = mapDispatchToProps( dispatch );
      const productId = 'sdfg123';
      const section = 'People Also Viewed';
      registerServiceName( 'qsProductDetails' );
      mdp.displayQuickShop( productId, section );
      expect( dispatch ).toHaveBeenCalledWith(
        getActionDefinition( 'qsProductDetails', 'requested' )( { productId, section } )
      );
    } );
    it( 'should dispatch the reflektionEvents when triggerReflektionWidgetClickEvent is invoked ', () => {
      const reflektionData = {
        'type': 'widget',
        'name': 'click',
        'value': {
          'rfkid': 'rfkid_6',
          'index': 2,
          'f': 'rw',
          'products': [
            {
              'sku': '113456'
            }
          ]
        }
      } ;
      const dispatch = jest.fn();
      const mdp  = mapDispatchToProps( dispatch );
      mdp.triggerReflektionWidgetClickEvent( reflektionData );
      expect( dispatch ).toHaveBeenCalledWith(
        triggerReflektionEvents( reflektionData )
      );
    } );
  } );
} );

it( 'Should return proper value  when getProductRating method is executed ', () => {
  let props1 = props;
  props1.powerReviewRating = 0;
  let component = mountProduct( props1 );
  expect( component.find( 'Product' ).instance().getProductRating( 0 ) ).toBe( 0 );
  expect( component.find( 'Product' ).instance().getProductRating( 2 ) ).toBe( 30 );
} );

function mountProduct( props ){
  return mountWithIntl(
    <Provider store={ store }>
      <ProductMock { ...props } />
    </Provider>
  );
}
