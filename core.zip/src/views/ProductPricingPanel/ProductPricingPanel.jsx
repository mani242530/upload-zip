/**
 * Product Pricing Panel
 */

import React from 'react';
import classNames from 'classnames';
import './ProductPricingPanel.css';
import Text from '../Text/Text';
import messages from './ProductPricingPanel.messages';
import { formatMessage } from '../Global/Global';

export const getPriceInCurrency = ( priceObject, showFraction ) => {
  return (
    new Intl.NumberFormat( 'en-US', {
      style: 'currency',
      ...( !showFraction && {
        maximumFractionDigits: 0,
        minimumFractionDigits: 0
      } ),
      currency: priceObject.currencyCode
    } ).format( priceObject.amount )
  )
}

const ProductPricingPanel = ( props ) => {
  const {
    listPrice,
    salePrice,
    marketValue,
    hasOnlyListPrice
  } = props;
  const displayAmountForMarketValue = marketValue && getPriceInCurrency( marketValue, false ) ;
  return (
    <div className='ProductPricingPanel'>
      { hasOnlyListPrice &&
      <Text
        type='title-6'
        htmlTag='span'
        fontWeight='bold'
        colorOverride='neutral-80'
      >
        <label className='sr-only'>Price</label>
        { getPriceInCurrency( listPrice, true ) }
      </Text>
      }
      { salePrice &&
        <div className='ProductPricingPanel__salePrice'>
          <Text
            type='title-6'
            htmlTag='span'
            colorOverride='neutral-80'
            fontWeight='bold'
          >
            <label className='sr-only'>{ formatMessage( messages.salePrice ) }</label>
            { getPriceInCurrency( salePrice, true ) }
          </Text>

          <Text
            type='body-2'
            htmlTag='span'
            textDecoration='line-through'
            colorOverride='neutral-70'
          >
            <label className='sr-only'>{ formatMessage( messages.originalPrice ) }</label>
            { getPriceInCurrency( listPrice, true ) }
          </Text>

        </div>
      }

      { marketValue &&
      <div className={
        classNames( 'ProductPricingPanel__marketValue',
          {
            'ProductPricingPanel__marketValue--noWrap': salePrice
          } )
      }
      >
        <Text
          type='body-2'
          htmlTag='span'
          colorOverride='neutral-80'
        >
          <label className='sr-only'>{ formatMessage( messages.marketValueLabel ) }</label>
          { formatMessage( messages.marketValueDetails, { marketValue:displayAmountForMarketValue } ) }
        </Text>
      </div>
      }
    </div>
  );
}

export default ProductPricingPanel;


