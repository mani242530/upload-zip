/*
 * Product Pricing Messages
 *
 * This contains all the text for the Product Pricing component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  originalPrice:{
    id:'i18n.ProductPricingPanel.originalPrice',
    defaultMessage:'Original Price'
  },
  salePrice:{
    id:'i18n.ProductPricingPanel.salePrice',
    defaultMessage:'Sale Price'
  },
  marketValueLabel:{
    id:'i18n.ProductPricingPanel.marketValue',
    defaultMessage:'Market Value'
  },
  marketValueDetails:{
    id:'i18n.ProductPricingPanel.displayMarketValue',
    defaultMessage:'({ marketValue } value)'
  }
} );
