import React from 'react';
import ReactDOM from 'react-dom';
import ProductPricingPanel, { getPriceInCurrency } from './ProductPricingPanel';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
import { formatMessage } from '../Global/Global';
import messages from './ProductPricingPanel.messages';
describe( '<ProductPricingPanel />', () => {
  let component;
  let props = {
    listPrice:{
      price:15.00,
      currencyCode: 'USD'
    },
    salePrice:{
      price:10.00,
      currencyCode: 'USD'
    },
    hasOnlyListPrice:false
  }
  component = mountWithIntl(
    <ProductPricingPanel { ...props }/>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'ProductPricingPanel' ).length ).toBe( 1 );
  } );

  it( 'should render ProductPricingPanel if item has only list price', () => {
    let props1 = {
      listPrice:{
        price:15.00,
        currencyCode: 'USD'
      },
      hasOnlyListPrice:true
    }
    let component1 = mountWithIntl(
      <ProductPricingPanel { ...props1 }/>
    );
    expect( component1.find( 'ProductPricingPanel' ).length ).toBe( 1 );
    expect( component1.find( '.ProductPricingPanel' ).find( 'Text' ).at( 0 ).length ).toBe( 1 );
    expect( component1.find( '.ProductPricingPanel' ).find( 'Text' ).at( 0 ).props( ).type ).toBe( 'title-6' );
    expect( component1.find( '.ProductPricingPanel' ).find( 'Text' ).at( 0 ).props( ).htmlTag ).toBe( 'span' );
    expect( component1.find( '.ProductPricingPanel' ).find( 'Text' ).at( 0 ).props( ).fontWeight ).toBe( 'bold' );
    expect( component1.find( '.ProductPricingPanel' ).find( 'Text' ).at( 0 ).props( ).colorOverride ).toBe( 'neutral-80' );
  } );

  describe( 'Sale Price', () => {

    it( 'should render ProductPricingPanel__salePrice div', ()=>{
      expect( component.find( '.ProductPricingPanel__salePrice' ).length ).toBe( 1 );
    } );

    it( 'should render text component for sale price', ()=>{
      expect( component.find( '.ProductPricingPanel__salePrice' ).find( 'Text' ).at( 0 ).length ).toBe( 1 );
      expect( component.find( '.ProductPricingPanel__salePrice' ).find( 'Text' ).at( 0 ).props( ).type ).toBe( 'title-6' );
      expect( component.find( '.ProductPricingPanel__salePrice' ).find( 'Text' ).at( 0 ).props( ).colorOverride ).toBe( 'neutral-80' );
      expect( component.find( '.ProductPricingPanel__salePrice' ).find( '.sr-only' ).at( 0 ).text() ).toBe( formatMessage( messages.salePrice ) );
    } );

    it( 'should render text component for original price', ()=>{
      expect( component.find( '.ProductPricingPanel__salePrice' ).find( 'Text' ).at( 1 ).length ).toBe( 1 );
      expect( component.find( '.ProductPricingPanel__salePrice' ).find( 'Text' ).at( 1 ).props( ).type ).toBe( 'body-2' );
      expect( component.find( '.ProductPricingPanel__salePrice' ).find( 'Text' ).at( 1 ).props( ).textDecoration ).toBe( 'line-through' );
      expect( component.find( '.ProductPricingPanel__salePrice' ).find( '.sr-only' ).at( 1 ).text() ).toBe( formatMessage( messages.originalPrice ) );
    } );

  } );

  describe( 'List Price', () => {

    it( 'should render ProductPricingPanel__price if hasOnlyListPrice is true', ()=>{
      props.salePrice = null;
      props.hasOnlyListPrice = true;
      component = mountWithIntl( <ProductPricingPanel { ...props } /> );
      expect( component.find( '.ProductPricingPanel' ).find( 'Text' ).length ).toBe( 1 );
      expect( component.find( '.ProductPricingPanel' ).find( '.sr-only' ).length ).toBe( 1 );
      expect( component.find( '.ProductPricingPanel' ).find( '.sr-only' ).text() ).toBe( 'Price' );
    } );

    it( 'should not render ProductPricingPanel__price hasOnlyListPrice is false', ()=>{
      props.hasOnlyListPrice = false;
      component = mountWithIntl( <ProductPricingPanel { ...props } /> );
      expect( component.find( '.ProductPricingPanel__price' ).length ).toBe( 0 );
    } );

  } );

  describe( 'getPriceInCurrency', () => {
    it( 'should return price prepend with $ if currentcyCode is USD', () => {
      expect( getPriceInCurrency( { amount:6.99, currencyCode:'USD' }, true ) ).toBe( '$6.99' );
    } );
    it( 'should return price without $ prepended, if currentcyCode is not USD', () => {
      expect( getPriceInCurrency( { amount:6.99, currencyCode:'INR' }, true ) ).toBe( '₹6.99' );
    } );
    it( 'should return price in proper format ', () => {
      expect( getPriceInCurrency( { amount:6, currencyCode:'USD' }, false ) ).toBe( '$6' );
      expect( getPriceInCurrency( { amount:6.5, currencyCode:'USD' }, true ) ).toBe( '$6.50' );
    } );

    describe( 'ShowFraction tests', () => {
      it( 'should return price with fraction value if the showFraction value is true', () => {
        expect( getPriceInCurrency( { amount:6.00, currencyCode:'USD' }, true ) ).toBe( '$6.00' );
        expect( getPriceInCurrency( { amount:6.78, currencyCode:'USD' }, true ) ).toBe( '$6.78' );
      } );
      it( 'should return price without fraction value if the showFraction value is false', () => {
        expect( getPriceInCurrency( { amount:6.00, currencyCode:'USD' }, false ) ).toBe( '$6' );
        expect( getPriceInCurrency( { amount:7.30, currencyCode:'USD' }, false ) ).toBe( '$7' );
      } );
    } );

  } );

  describe( 'market value', () => {
    it( 'should render ProductPricingPanel__marketValue in next line if sale and list price is available', ()=>{
      let props1 = {
        listPrice:{
          price:15.00,
          currencyCode: 'USD'
        },
        salePrice:{
          price:10.00,
          currencyCode: 'USD'
        },
        hasOnlyListPrice:false,
        marketValue:{
          price:20.00,
          currencyCode: 'USD'
        }
      }
      component = mountWithIntl( <ProductPricingPanel { ...props1 } /> );
      expect( component.find( '.ProductPricingPanel__marketValue' ).find( 'Text' ).length ).toBe( 1 );
      expect( component.find( '.ProductPricingPanel__marketValue--noWrap' ).length ).toBe( 1 );
      expect( component.find( '.ProductPricingPanel__marketValue' ).find( '.sr-only' ).length ).toBe( 1 );
      expect( component.find( '.ProductPricingPanel__marketValue' ).find( 'Text' ).props( ).type ).toBe( 'body-2' );
      expect( component.find( '.ProductPricingPanel__marketValue' ).find( '.sr-only' ).text() ).toBe( 'Market Value' );
    } );
    it( 'should render ProductPricingPanel__marketValue in same line if it has Only ListPrice', ()=>{
      let props2 = {
        listPrice:{
          price:15.00,
          currencyCode: 'USD'
        },
        marketValue:{
          price:20.00,
          currencyCode: 'USD'
        },
        hasOnlyListPrice:true
      }
      component = mountWithIntl( <ProductPricingPanel { ...props2 } /> );
      expect( component.find( '.ProductPricingPanel__marketValue' ).find( 'Text' ).length ).toBe( 1 );
      expect( component.find( '.ProductPricingPanel__marketValue' ).find( '.sr-only' ).length ).toBe( 1 );
      expect( component.find( '.ProductPricingPanel__marketValue' ).find( 'Text' ).props( ).type ).toBe( 'body-2' );
      expect( component.find( '.ProductPricingPanel__marketValue' ).find( '.sr-only' ).text() ).toBe( 'Market Value' );
    } );
  } );



} );

