/**
 * DesktopProductsList
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './DesktopProductsList.css';
import Slider from 'react-slick';
import Product from '../../../Product/Product';
import Anchor from '../../../Anchor/Anchor';
import Image from '../../../Image/Image';
import chevronRightSVG from '../../../Icons/chevron_right';
import 'slick-carousel/slick/slick-theme.css';
import 'slick-carousel/slick/slick.css';

const propTypes = {
  productData: PropTypes.any,
  settings: PropTypes.object,
  marginTop: PropTypes.string,
  marginBottom: PropTypes.string,
  showTitle: PropTypes.bool,
  isQuickShopEnabled:PropTypes.bool
}

const defaultProps = {
  marginTop: '0px',
  marginBottom: '0px',
  settings: {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 2.5,
    slidesToScroll: 1.5,
    arrows: false
  },
  showTitle: false
}

/**
 * Class
 * @extends React.Component
 */
class DesktopProductsList extends Component{

  /**
   * Renders the DesktopProductsList component
   */

  render(){
    const {
      productData,
      marginTop,
      marginBottom,
      settings,
      section,
      showTitle,
      isQuickShopEnabled,
      crossSellLocation,
      sectionWidgetId
    } = this.props;

    const style = {
      marginTop: marginTop,
      marginBottom: marginBottom
    }

    return (
      <div
        className='DesktopProductsList'
        style={ style }
      >
        {
          !showTitle &&
            (
              <div className='DesktopProductsList__heading'>
                { productData.title }
              </div>
            )

        }

        <Slider { ...settings } >

          {
            productData &&
                productData.map( ( productDetail, index ) => {
                  return (
                    <div
                      className='DesktopProductsList__products'
                      key={ index }
                    >
                      <Product
                        clickURL={ productDetail.product.actionUrl }
                        brandName={ productDetail.brand.brandName }
                        productDisplayName={ productDetail.product.displayName }
                        productImageUrl={ productDetail.sku.images.largeImage }
                        lowRangeListPrice={ productDetail.sku.price.lowRangeListPrice }
                        highRangeListPrice={ productDetail.sku.price.highRangeListPrice }
                        lowRangeSalePrice={ productDetail.sku.price.lowRangeSalePrice }
                        highRangeSalePrice={ productDetail.sku.price.highRangeSalePrice }
                        powerReviewRating={ productDetail.reviewSummary?.rating || 0 }
                        badges={ productDetail.sku?.badges?.items || null }
                        productVariant={ productDetail.sku?.variant?.variantType || null }
                        numReviews={ productDetail.reviewSummary?.reviewCount || 0 }
                        promotion={ productDetail.promotion?.description || null }
                        variantCount={ productDetail.product.activeSkusCount }
                        productId={ productDetail.product.id }
                        skuId={ productDetail.product.defaultSku || productDetail.product.schildSkuId }
                        section={ section }
                        sectionWidgetId={ sectionWidgetId }
                        productIndex={ index }
                        salePrice={ productDetail.sku?.price?.salePrice?.amount || 0 }
                        isQuickShopEnabled={ isQuickShopEnabled }
                        crossSellLocation={ crossSellLocation }
                      />
                    </div>
                  )
                } )
          }
          {
            !showTitle &&
            (
              <Anchor
                url={ productData.shopAllLink.navTargetLink || '#' }
                tabIndex={ 1 }
              >
                <div className='ProductList__shopAll'>
                  { ( productData.shopAllLink.linkText ).replace( /(?=[A-Z])/g, ' ' ).toUpperCase() }
                  <div className='ProductList__right-chevron'>
                    <Image
                      injectSVG={ true }
                      src={ chevronRightSVG }
                      alt=''
                      lazyLoad={ false }
                    />
                  </div>
                </div>
              </Anchor>
            )
          }

        </Slider>

      </div>
    )
  }
}

DesktopProductsList.propTypes = propTypes;
DesktopProductsList.defaultProps = defaultProps;

export default DesktopProductsList;
