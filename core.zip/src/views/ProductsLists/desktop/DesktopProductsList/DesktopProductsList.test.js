import React from 'react';
import { Provider } from 'react-redux';
import DesktopProductsList from './DesktopProductsList';
import { mountWithIntl, configureStore } from '../../../../utils/enzyme/intl-enzyme-test-helper';

const store = configureStore( );


describe( '<DesktopProductsList />', () => {
  let props;
  let component;
  let settings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 2,
    slidesToScroll: 1,
    arrows: true
  }

  it( 'renders without crashing', () => {
    props = {
      productData:[],
      settings: {},
      showTitle: false
    }
    props.productData = [
      {
        'product': {
          'id': 'xlsImpprod15931211'
        },
        'category': {
          'displayName': 'Contouring',
          'id': 'cat510002'
        },
        'sku': {
          'badges': {
            'items': [
              {
                'badgeName': 'Online Only',
                'priority': 7,
                'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
              }
            ]
          },
          'images': {
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2511222?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2511222?$md$'
          },
          'price': {
            'listPrice': {
              'displayAmount': '$110.00',
              'amount': 110,
              'currencyCode': 'USD'
            },
            'salePrice': {
              'displayAmount': '$110.00',
              'amount': 110,
              'currencyCode': 'USD'
            }
          },
          'variant': null,
          'id': '2511222'
        },
        'brand': {
          'brandName': 'Ofra Cosmetics',
          'brandId': 'xlsImp52500002'
        }
      }
    ];
    props.settings = settings;
    props.showTitle = true;
    component = mountProductList( props );
    expect( component.find( 'DesktopProductsList' ).length ).toBe( 1 );
  } );
  it( 'it should render and show Products in a slider when one set of products data is passed as props from product recs', () =>{
    props = {
      productData: [
        {
          'product': {
            'id': 'xlsImpprod15931211'
          },
          'category': {
            'displayName': 'Contouring',
            'id': 'cat510002'
          },
          'sku': {
            'badges': {
              'items': [
                {
                  'badgeName': 'Online Only',
                  'priority': 7,
                  'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
                }
              ]
            },
            'images': {
              'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2511222?$tn$',
              'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2511222?$md$'
            },
            'price': {
              'listPrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              },
              'salePrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              }
            },
            'variant': null,
            'id': '2511222'
          },
          'brand': {
            'brandName': 'Ofra Cosmetics',
            'brandId': 'xlsImp52500002'
          }
        }
      ],
      settings: {},
      showTitle: false
    }
    props.showTitle = true;
    component = mountProductList( props );
    expect( component.find( 'DesktopProductsList' ).length ).toBe( 1 );

  } )
  it( 'it should render showTitle information', () =>{
    props = {
      productData: [
        {
          'product': {
            'id': 'xlsImpprod15931211'
          },
          'category': {
            'displayName': 'Contouring',
            'id': 'cat510002'
          },
          'sku': {
            'badges': {
              'items': [
                {
                  'badgeName': 'Online Only',
                  'priority': 7,
                  'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
                }
              ]
            },
            'images': {
              'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2511222?$tn$',
              'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2511222?$md$'
            },
            'price': {
              'listPrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              },
              'salePrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              }
            },
            'variant': null,
            'id': '2511222'
          },
          'brand': {
            'brandName': 'Ofra Cosmetics',
            'brandId': 'xlsImp52500002'
          }
        }
      ],
      settings: {},
      showTitle: false
    }
    props.showTitle = true;
    let component1 = mountProductList( props );
    expect( component1.find( 'DesktopProductsList' ).length ).toBe( 1 );

  } );

  it( 'it should render Product component and pass proper props to it', () =>{
    let props = {
      productData: [
        {
          'product': {
            'id': 'xlsImpprod15931211'
          },
          'category': {
            'displayName': 'Contouring',
            'id': 'cat510002'
          },
          'sku': {
            'badges': {
              'items': [
                {
                  'badgeName': 'Online Only',
                  'priority': 7,
                  'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
                }
              ]
            },
            'images': {
              'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2511222?$tn$',
              'largeImage': 'https://images.ulta.com/is/image/Ulta/2511222?$lg$',
              'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2511222?$md$'
            },
            'lowRangeListPrice': 110,
            'showListAndSaleRange': false,
            'highRangeSalePrice': 0,
            'lowRangeSalePrice': 0,
            'highRangeListPrice': 110,
            'price': {
              'listPrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              },
              'salePrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              }
            },
            'variant': null,
            'id': '2511222'
          },
          'brand': {
            'brandName': 'Ofra Cosmetics',
            'brandId': 'xlsImp52500002'
          },
          'promotion': {
            'type': 'weekend',
            'description': 'week end offer zone',
            'promotionDiscount': 0,
            'id': 'wks1032656'
          }
        },
        {
          'product': {
            'id': 'xlsImpprod15931212'
          },
          'category': {
            'displayName': 'Contouring',
            'id': 'cat510002'
          },
          'sku': {
            'badges': {
              'items': [
                {
                  'badgeName': 'Online Only',
                  'priority': 7,
                  'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
                }
              ]
            },
            'images': {
              'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2511222?$tn$',
              'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2511222?$md$'
            },
            'price': {
              'listPrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              },
              'salePrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              }
            },
            'variant': null,
            'id': '2511222'
          },
          'brand': {
            'brandName': 'Ofra Cosmetics',
            'brandId': 'xlsImp52500002'
          }
        },
        {
          'product': {
            'id': 'xlsImpprod15931213'
          },
          'category': {
            'displayName': 'Contouring',
            'id': 'cat510002'
          },
          'sku': {
            'badges': {
              'items': [
                {
                  'badgeName': 'Online Only',
                  'priority': 7,
                  'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
                }
              ]
            },
            'images': {
              'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2511222?$tn$',
              'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2511222?$md$'
            },
            'price': {
              'listPrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              },
              'salePrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              }
            },
            'variant': null,
            'id': '2511222'
          },
          'brand': {
            'brandName': 'Ofra Cosmetics',
            'brandId': 'xlsImp52500002'
          }
        },
        {
          'product': {
            'id': 'xlsImpprod15931214'
          },
          'category': {
            'displayName': 'Contouring',
            'id': 'cat510002'
          },
          'sku': {
            'badges': {
              'items': [
                {
                  'badgeName': 'Online Only',
                  'priority': 7,
                  'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
                }
              ]
            },
            'images': {
              'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2511222?$tn$',
              'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2511222?$md$'
            },
            'price': {
              'listPrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              },
              'salePrice': {
                'displayAmount': '$110.00',
                'amount': 110,
                'currencyCode': 'USD'
              }
            },
            'variant': null,
            'id': '2511224'
          },
          'brand': {
            'brandName': 'Ofra Cosmetics',
            'brandId': 'xlsImp52500002'
          }
        }
      ],
      isQuickShopEnabled:true,
      sectionWidgetId:'12345',
      crossSellLocation:'true',
      productRecsWidgetClick:jest.fn()
    }
    props.showTitle = true;
    let component1 = mountProductList( props );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products' ).length ).toBe( 4 );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().isQuickShopEnabled ).toBe( props.isQuickShopEnabled );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().lowRangeListPrice ).toBe( props.productData[0].sku.price.lowRangeListPrice );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().highRangeListPrice ).toBe( props.productData[0].sku.price.highRangeListPrice );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().lowRangeSalePrice ).toBe( props.productData[0].sku.price.lowRangeSalePrice );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().highRangeListPrice ).toBe( props.productData[0].sku.price.highRangeListPrice );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().salePrice ).toBe( props.productData[0].sku.price.salePrice.amount );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().productId ).toBe( props.productData[0].product.id );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().productVariant ).toBe( props.productData[0].sku.variant );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().numReviews ).toBe( 0 );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().promotion ).toBe( props.productData[0].promotion.description );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().variantCount ).toBe( props.productData[0].product.activeSkusCount );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().crossSellLocation ).toBe( props.crossSellLocation );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().sectionWidgetId ).toBe( props.sectionWidgetId );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().productIndex ).toBe( 0 );
    expect( component1.find( 'Slider' ).find( '.DesktopProductsList__products Product' ).at( 0 ).props().productImageUrl ).toBe( props.productData[0].sku.images.largeImage );
  } );


} );

function mountProductList( props ){
  return mountWithIntl(
    <Provider store={ store }>
      <DesktopProductsList
        { ...props }
      />
    </Provider>
  );
}
