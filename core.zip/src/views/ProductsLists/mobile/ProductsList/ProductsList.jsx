/**
 * ProductsList
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './ProductsList.css';
import isEmpty from 'lodash/isEmpty';
import has from 'lodash/has';
import get from 'lodash/get';
import Product from '../../../Product/Product';
import Anchor from '../../../Anchor/Anchor';
import ChevronRightSVG from '../../../Icons/chevron_right';


const propTypes = {
  productData: PropTypes.object,
  marginTop: PropTypes.string,
  marginBottom: PropTypes.string,
  productsToShow: PropTypes.number,
  displayShopall: PropTypes.bool
}

const defaultProps = {
  marginTop: '0px',
  marginBottom: '0px',
  productsToShow: 2.5,
  displayShopall: true
}

const initialState = {
  productWidth: 0,
  listWidth: 0,
  scrollContainerHeight: 'auto'
}

/**
 * Class
 * @extends React.Component
 */
class ProductsList extends Component{

  /**
   * Create a ProductsList
   */
  constructor( props ){
    super( props );

    this.state = initialState;

    this.handleWindowResize = this.handleWindowResize.bind( this );
  }

  list = undefined;

  shopAll = undefined;

  componentDidMount(){
    global.addEventListener( 'resize', this.handleWindowResize() );
    this.handleWindowResize();
  }

  componentDidUpdate(){
    this.handleWindowResize();
  }

  componentWillUnmount(){
    global.removeEventListener( 'resize', this.handleWindowResize() );
  }

  handleWindowResize(){
    if( this.props.productData && this.props.productData.records && this.props.productData.shopAllLink ){
      let screenWidth = window.innerWidth;
      let products = has( this.list, 'querySelectorAll' ) ? this.list.querySelectorAll( '.ProductsList__product' ) : '';
      var heights = [];
      for ( var i = 0; i < products.length; i++ ){
        heights.push( products[i].clientHeight );
      }

      let scrollContainerHeight = Math.max( ...heights );// find the tallest lement in the group and get it's height

      let productWidth = ( screenWidth / this.props.productsToShow );
      let listWidth = productWidth * this.props.productData.records.length;
      listWidth = has( this.shopAll, 'clientWidth' ) ? listWidth + this.shopAll.clientWidth : listWidth;

      if( `${productWidth}px` !== this.state.productWidth ){
        this.setState( { listWidth: `${listWidth}px` } );
        this.setState( { productWidth: `${productWidth}px` } );
      }

      if( `${scrollContainerHeight}px` !== this.state.scrollContainerHeight ){
        this.setState( { scrollContainerHeight: `${scrollContainerHeight}px` } );
      }
    }
  }


  /**
   * Renders the ProductsList component
   */

  render(){
    const {
      productData,
      marginTop,
      marginBottom,
      section,
      productsToShow,
      sectionWidgetId
    } = this.props;

    const style = {
      marginTop: marginTop,
      marginBottom: marginBottom
    }
    const productRecords = get( productData, 'records.items.product' ) || get( productData, 'records' )
    if( productRecords && productRecords.length > 0 && !isEmpty( productRecords[0] ) ){
      let sliderWidth = productRecords.length * ( 100 / productsToShow );
    }

    return (
      <div
        ref={ ( list ) => this.list = list }
        className='ProductsList'
        style={ style }
      >

        {
          productData && productData.title &&
          (
            <div className='ProductsList__heading'>
              { productData.title }
            </div>
          )
        }

        {
          productRecords && productRecords.length > 0 && !isEmpty( productRecords[0] ) &&
          (
            <div
              className='ProductList__scrollContainer'
              style={
                {
                  height: this.state.scrollContainerHeight
                }
              }
            >
              <div className='ProductsList__container'>
                <div
                  className='ProductsList__products'
                  style={
                    {
                      width: this.state.listWidth
                    }
                  }
                >
                  { productRecords &&
                  productRecords.map( ( productDetail, index ) => {
                    return (
                      <div
                        className='ProductsList__product'
                        style={
                          {
                            width: this.state.productWidth
                          }
                        }
                        key={ index }
                      >

                        { !! productDetail.product &&
                        // Home page servic is returning different response structure compared to product recs  .
                        // So Product deetails from recommendation service is handled here
                          (
                            <Product
                              clickURL={ productDetail.product.actionUrl }
                              brandName={ productDetail.brand.brandName }
                              productDisplayName={ productDetail.product.displayName }
                              productImageUrl={ productDetail.sku.images.thumbnailImage }
                              lowRangeListPrice={ productDetail.sku?.price?.lowRangeListPrice || 0 }
                              highRangeListPrice={ productDetail.sku?.price?.highRangeListPrice || 0 }
                              lowRangeSalePrice={ productDetail.sku?.price?.lowRangeSalePrice || 0 }
                              highRangeSalePrice={ productDetail.sku?.price?.highRangeSalePrice || 0 }
                              powerReviewRating={ productDetail.reviewSummary?.rating || 0 }
                              badges={ productDetail.sku?.badges?.items || null }
                              productVariant={ productDetail.sku?.variant?.variantType || null }
                              numReviews={ productDetail.reviewSummary?.reviewCount || 0 }
                              promotion={ productDetail.promotion?.description || null }
                              variantCount={ productDetail.product.activeSkusCount }
                              productId={ productDetail.product.id }
                              skuId={ productDetail.product.defaultSku || productDetail.product.schildSkuId }
                              section={ section }
                              sectionWidgetId={ sectionWidgetId }
                              productIndex={ index }
                              salePrice={ productDetail.sku?.price?.salePrice?.amount || 0 }
                            />
                          )
                        }
                        { !productDetail.product &&
                        // Product details from mobile home page service is handled here
                        // Will revert this changes once homepage service is updated .
                          (
                            <Product
                              clickURL={ productDetail.clickURL }
                              brandName={ productDetail.brandName }
                              productDisplayName={ productDetail.productDisplayName }
                              productImageUrl={ productDetail.productImageUrl }
                              lowRangeListPrice={ productDetail.lowRangeListPrice || 0 }
                              highRangeListPrice={ productDetail.highRangeListPrice || 0 }
                              lowRangeSalePrice={ productDetail.lowRangeSalePrice || 0 }
                              highRangeSalePrice={ productDetail.highRangeSalePrice || 0 }
                              powerReviewRating={ !Number.isNaN( productDetail.powerReviewRating ) ? Number( productDetail.powerReviewRating ) : 0 }
                              badges={ productDetail.badges }
                              productVariant={ productDetail.varaintDispName }
                              numReviews={ !Number.isNaN( productDetail.numReviews ) ? Number( productDetail.numReviews ) : 0 }
                              promotion={ ( productDetail.promotionDO ) ? productDetail.promotionDO : null }
                              variantCount={ productDetail.activeSkusCount }
                              productId={ productDetail.productId }
                              skuId={ productDetail.dfltSkuId || productDetail.schildSkuId }
                              section={ section }
                              salePrice={ productDetail.salePrice || 0 }
                            />
                          )
                        }
                      </div>
                    )
                  } )
                  }

                  {
                    productData.shopAllLink && !isEmpty( productData.shopAllLink ) && this.props.displayShopall &&

                  (
                    <div
                      className='ProductsList__product ProductsList__product--shop'
                      ref={ ( shopAll ) => this.shopAll = shopAll }
                    >
                      <Anchor
                        url={ productData.shopAllLink.navTargetLink || '#' }
                        tabIndex={ 1 }
                      >
                        <div className='ProductList__shopAll' >
                          { productData.shopAllLink?.linkText }
                          <div className='ProductList__right-chevron'>
                            <ChevronRightSVG />
                          </div>
                        </div>
                      </Anchor>
                    </div>
                  )
                  }
                </div>
              </div>
            </div>
          )
        }
      </div>
    )
  }
}

ProductsList.propTypes = propTypes;
ProductsList.defaultProps = defaultProps;

export default ProductsList;
