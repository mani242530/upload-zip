import React from 'react';
import ReactDOM from 'react-dom';
import { IntlProvider } from 'react-intl';
import { Provider } from 'react-redux';
import ProductsList from './ProductsList';
import { mountWithIntl, configureStore } from '../../../../utils/enzyme/intl-enzyme-test-helper';

const store = configureStore( );

describe( '<ProductsList />', () => {
  let props;
  let component;
  let ProductsListDataFromHomePageService = {
    'priorityTag':'h2',
    'topMargin':'0px',
    'subTitle':'',
    'records':[
      {
        'clickURL': 'https://da1.ulta.com/excellence-creme?productId=VP00039',
        'skuImageUrl': null,
        'childSkuId': null,
        'numReviews': null,
        'rating': null,
        'productBrandName': null,
        'isGwp': 0,
        'adbugMessage': null,
        'showListRange': true,
        'lowRangeListPrice': 8.99,
        'reviewCount': null,
        'showListAndSaleRange': false,
        'highRangeSalePrice': 0,
        'onSale': false,
        'multiSku': true,
        'productImageUrl': 'https://images.ulta.com/is/image/Ulta/2085840?$md$',
        'prodParentCatId': 'cat110142',
        'brandName': 'LOréal',
        'activeSkusCount': 35,
        'productId': 'VP00039',
        'dfltSkuId': '2085840',
        'salePrice': 0,
        'parentCatDispName': 'Hair Color',
        'badges': [],
        'badge': null,
        'powerReviewRating': null,
        'productDisplayName': 'Excellence Crème',
        'lowRangeSalePrice': 0,
        'skuDisplayName': null,
        'ratingDecimal': null,
        'highRangeListPrice': 8.99,
        'listPrice': 8.99,
        'promotionDO': null,
        'varaintDispName': 'Colors'
      },
      {
        'clickURL': 'https://da1.ulta.com/one-coat-thickening-mascara?productId=423',
        'skuImageUrl': null,
        'childSkuId': null,
        'numReviews': null,
        'rating': null,
        'productBrandName': null,
        'isGwp': 0,
        'adbugMessage': null,
        'showListRange': true,
        'lowRangeListPrice': 8.99,
        'reviewCount': null,
        'showListAndSaleRange': false,
        'highRangeSalePrice': 0,
        'onSale': false,
        'multiSku': true,
        'productImageUrl': 'https://images.ulta.com/is/image/Ulta/1011045?$md$',
        'prodParentCatId': 'cat80040',
        'brandName': 'Almay',
        'activeSkusCount': 3,
        'productId': '423',
        'dfltSkuId': '1011045',
        'salePrice': 0,
        'parentCatDispName': 'Mascara',
        'badges': [],
        'badge': null,
        'powerReviewRating': null,
        'productDisplayName': 'One Coat Thickening Mascara',
        'lowRangeSalePrice': 0,
        'skuDisplayName': null,
        'ratingDecimal': null,
        'highRangeListPrice': 8.99,
        'listPrice': 8.99,
        'promotionDO': null,
        'varaintDispName': 'Colors'
      }
    ],
    'navDisplayContent':'NEW ARRIVALS',
    'bottomMargin':'15px',
    'navElementType':'MobileRecordSpotlight',
    'title':'NEW ARRIVALS',
    'sectionPriorityTag':'h2',
    'shopAllLink':{
      'showInNewPage':false,
      'navTargetLink':'http://qa1.ulta.com/ulta/a/Makeup/_/N-6Z26y1?Ns=product.startDate%7C1&ciSelector=searchResults&pgName=whatsnew',
      'linkText':'Shop All'
    }
  };
  let productsListDataFromPrductRecs = {
    'records':[
      {
        'adbugMessage': null,
        'product': {
          'activeSkusCount': 1,
          'displayName': 'Online Only On The Glow Highlighting Palette',
          'actionUrl': '/on-glow-highlighting-palette?productId=xlsImpprod15931211',
          'isGWP': false,
          'id': 'xlsImpprod15931211',
          'title': 'Ofra Cosmetics Online Only On The Glow Highlighting Palette | Ulta Beauty',
          'multiSku': false,
          'defaultSku': '2511222'
        },
        'category': {
          'displayName': 'Contouring',
          'id': 'cat510002'
        },
        'sku': {
          'badges': {
            'items': [
              {
                'badgeName': 'Online Only',
                'priority': 7,
                'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
              }
            ]
          },
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2511222?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2511222',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2511222?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2511222?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2511222?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2511222?$md$'
          },
          'displayName': null,
          'price': {
            'showListRange': true,
            'lowRangeListPrice': 110,
            'showListAndSaleRange': false,
            'highRangeSalePrice': 0,
            'lowRangeSalePrice': 0,
            'highRangeListPrice': 110,
            'listPrice': {
              'displayAmount': '$110.00',
              'amount': 110,
              'currencyCode': 'USD'
            },
            'salePrice': {
              'displayAmount': '$110.00',
              'amount': 110,
              'currencyCode': 'USD'
            }
          },
          'variant': null,
          'id': '2511222'
        },
        'brand': {
          'brandName': 'Ofra Cosmetics',
          'brandId': 'xlsImp52500002'
        },
        'reviewSummary': {
          'reviewCount': 0,
          'rating': 0
        },
        'promotion': {
          'type': 'weekend',
          'description': 'week end offer zone',
          'promotionDiscount': 0,
          'id': 'wks1032656'
        }
      },
      {
        'adbugMessage': null,
        'product': {
          'activeSkusCount': 5,
          'displayName': 'Cameo Contour Dual-Ended Contour Stick',
          'actionUrl': '/cameo-contour-dual-ended-contour-stick?productId=xlsImpprod13161073',
          'isGWP': false,
          'id': 'xlsImpprod13161073',
          'title': 'PÜR Cameo Contour Dual-Ended Contour Stick | Ulta Beauty',
          'multiSku': true,
          'defaultSku': '2293998'
        },
        'category': {
          'displayName': 'Contouring',
          'id': 'cat510002'
        },
        'sku': {
          'badges': null,
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2293998?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2293998',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2293998?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2293998?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2293998?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2293998?$md$'
          },
          'displayName': null,
          'price': {
            'showListRange': true,
            'lowRangeListPrice': 39.5,
            'salePrice': null,
            'showListAndSaleRange': false,
            'highRangeSalePrice': 0,
            'lowRangeSalePrice': 0,
            'highRangeListPrice': 39.5,
            'listPrice': {
              'displayAmount': '$39.50',
              'amount': 39.5,
              'currencyCode': 'USD'
            }
          },
          'variant': {
            'variantType': 'Colors',
            'variantDesc': 'Light'
          },
          'id': '2293998'
        },
        'brand': {
          'brandName': 'PÜR',
          'brandId': '24464'
        },
        'reviewSummary': {
          'reviewCount': 0,
          'rating': 0
        },
        'promotion': null
      },
      {
        'adbugMessage': null,
        'product': {
          'activeSkusCount': 4,
          'displayName': 'Online Only Skin Sculpting Wand',
          'actionUrl': '/skin-sculpting-wand?productId=xlsImpprod16801688',
          'isGWP': false,
          'id': 'xlsImpprod16801688',
          'title': 'Ofra Cosmetics Online Only Skin Sculpting Wand | Ulta Beauty',
          'multiSku': true,
          'defaultSku': '2517605'
        },
        'category': {
          'displayName': 'Contouring',
          'id': 'cat510002'
        },
        'sku': {
          'badges': {
            'items': [
              {
                'badgeName': 'Online Only',
                'priority': 7,
                'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
              }
            ]
          },
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2517605?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2517605',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2517605?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2517605?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2517605?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2517605?$md$'
          },
          'displayName': null,
          'price': {
            'showListRange': true,
            'lowRangeListPrice': 11,
            'salePrice': null,
            'showListAndSaleRange': false,
            'highRangeSalePrice': 0,
            'lowRangeSalePrice': 0,
            'highRangeListPrice': 11,
            'listPrice': {
              'displayAmount': '$11.00',
              'amount': 11,
              'currencyCode': 'USD'
            }
          },
          'variant': {
            'variantType': 'Colors',
            'variantDesc': 'Sunrise (warm medium tone)'
          },
          'id': '2517605'
        },
        'brand': {
          'brandName': 'Ofra Cosmetics',
          'brandId': 'xlsImp52500002'
        },
        'reviewSummary': {
          'reviewCount': 0,
          'rating': 0
        },
        'promotion': null
      },
      {
        'adbugMessage': null,
        'product': {
          'activeSkusCount': 1,
          'displayName': 'Crystalline Glow Bronzer & Highlighter Palette',
          'actionUrl': '/crystalline-glow-bronzer-highlighter-palette?productId=xlsImpprod17781039',
          'isGWP': false,
          'id': 'xlsImpprod17781039',
          'title': 'BareMinerals Crystalline Glow Bronzer & Highlighter Palette | Ulta Beauty',
          'multiSku': false,
          'defaultSku': '2524225'
        },
        'category': {
          'displayName': 'Bronzer',
          'id': 'cat80030'
        },
        'sku': {
          'badges': {
            'items': [
              {
                'badgeName': 'New',
                'priority': 8,
                'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-whats-new'
              }
            ]
          },
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2524225?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2524225',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2524225?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2524225?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2524225?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2524225?$md$'
          },
          'displayName': null,
          'price': {
            'showListRange': true,
            'lowRangeListPrice': 34,
            'salePrice': null,
            'showListAndSaleRange': false,
            'highRangeSalePrice': 0,
            'lowRangeSalePrice': 0,
            'highRangeListPrice': 34,
            'listPrice': {
              'displayAmount': '$34.00',
              'amount': 34,
              'currencyCode': 'USD'
            }
          },
          'variant': null,
          'id': '2524225'
        },
        'brand': {
          'brandName': 'BareMinerals',
          'brandId': '9015'
        },
        'reviewSummary': {
          'reviewCount': 0,
          'rating': 0
        },
        'promotion': null
      }
    ],
    'shopAllLink':{
    },
    section: 'People Also Bought',
    sectionWidgetId:'12345',
    showTitle: true,
    showOnlyListPrice: true
  };

  it( 'renders without crashing', () => {
    props = {
      productData: productsListDataFromPrductRecs
    }
    component = mountProductList( props );
    expect( component.find( 'ProductsList' ).length ).toBe( 1 );
  } );
  it( 'it should render and show Products in a slider when one set of products data is passed as props from mobile home page ', () =>{
    props = {
      productData: ProductsListDataFromHomePageService
    }
    component = mountProductList( props );
    expect( component.find( 'ProductsList' ).length ).toBe( 1 );
    expect( component.find( '.ProductsList__product' ).length ).toBe( 3 ) ;

  } )
  it( 'it should render and show Products in a slider when one set of products data is passed as props from product recommendations ', () =>{
    props = {
      productData: productsListDataFromPrductRecs,
      sectionWidgetId:'12345'
    }
    component = mountProductList( props );
    expect( component.find( 'ProductsList' ).length ).toBe( 1 );
    expect( component.find( '.ProductsList__product Product' ).at( 0 ).props().sectionWidgetId ).toBe( props.sectionWidgetId );
    expect( component.find( '.ProductsList__product Product' ).at( 0 ).props().productIndex ).toBe( 0 );
  } );
  it( 'it should render Product component when productData is passed from ProductRecs ', () =>{
    let props = {
      productData: productsListDataFromPrductRecs
    }

    let component1 = mountProductList( props );
    expect( component1.find( 'Product' ).length ).toBe( 4 );
    expect( component1.find( 'Product' ).at( 0 ).props().lowRangeListPrice ).toBe( props.productData.records[0].sku.price.lowRangeListPrice );
    expect( component1.find( 'Product' ).at( 0 ).props().highRangeListPrice ).toBe( props.productData.records[0].sku.price.highRangeListPrice );
    expect( component1.find( 'Product' ).at( 0 ).props().lowRangeSalePrice ).toBe( props.productData.records[0].sku.price.lowRangeSalePrice );
    expect( component1.find( 'Product' ).at( 0 ).props().highRangeSalePrice ).toBe( props.productData.records[0].sku.price.highRangeSalePrice );
    expect( component1.find( 'Product' ).at( 0 ).props().salePrice ).toBe( props.productData.records[0].sku.price.salePrice.amount );
    expect( component1.find( 'Product' ).at( 0 ).props().productId ).toBe( props.productData.records[0].product.id );
    expect( component1.find( 'Product' ).at( 0 ).props().productVariant ).toBe( props.productData.records[0].sku.variant );
    expect( component1.find( 'Product' ).at( 0 ).props().numReviews ).toBe( 0 );
    expect( component1.find( 'Product' ).at( 0 ).props().promotion ).toBe( props.productData.records[0].promotion.description );
    expect( component1.find( 'Product' ).at( 0 ).props().variantCount ).toBe( props.productData.records[0].product.activeSkusCount );

  } );
  it( 'it should render Product component when productData is passed from Mobile Home Page ', () =>{
    let props = {
      productData: ProductsListDataFromHomePageService
    }

    let component1 = mountProductList( props );
    expect( component1.find( 'Product' ).length ).toBe( 2 );
    expect( component1.find( 'Product' ).at( 0 ).props().lowRangeListPrice ).toBe( props.productData.records[0].lowRangeListPrice );
    expect( component1.find( 'Product' ).at( 0 ).props().highRangeListPrice ).toBe( props.productData.records[0].highRangeListPrice );
    expect( component1.find( 'Product' ).at( 0 ).props().lowRangeSalePrice ).toBe( props.productData.records[0].lowRangeSalePrice );
    expect( component1.find( 'Product' ).at( 0 ).props().highRangeSalePrice ).toBe( props.productData.records[0].highRangeSalePrice );
    expect( component1.find( 'Product' ).at( 0 ).props().salePrice ).toBe( 0 );
    expect( component1.find( 'Product' ).at( 0 ).props().productId ).toBe( props.productData.records[0].productId );
    expect( component1.find( 'Product' ).at( 0 ).props().productVariant ).toBe( props.productData.records[0].varaintDispName );
    expect( component1.find( 'Product' ).at( 0 ).props().numReviews ).toBe( 0 );
    expect( component1.find( 'Product' ).at( 0 ).props().promotion ).toBe( props.productData.records[0].promotionDO );
    expect( component1.find( 'Product' ).at( 0 ).props().variantCount ).toBe( props.productData.records[0].activeSkusCount );

  } );

} );



function mountProductList( props ){
  return mountWithIntl(
    <Provider store={ store }>
      <ProductsList
        { ...props }
      />
    </Provider>
  );
}
