/**
 * RadioButton
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './RadioButton.css';
import { Field } from 'redux-form';
import classNames from 'classnames';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBan } from '@fortawesome/pro-regular-svg-icons/faBan';

const propTypes = {
  isChecked: PropTypes.bool,
  isDisabled: PropTypes.bool,
  id: PropTypes.string.isRequired,
  name: PropTypes.string,
  onChange: PropTypes.func,
  value: PropTypes.oneOfType( [
    PropTypes.string,
    PropTypes.number
  ] ).isRequired
};

/**
 * Class
 * @extends React.Component
 */
class RadioButton extends Component{

  /**
   * Create a RadioButton
   */
  constructor( props ){
    super( props );
    this.renderField = this.renderField.bind( this );
  }

  renderField( props ){
    const {
      children,
      id,
      name,
      value,
      isChecked,
      isDisabled,
      onChange,
      onClick,
      className
    } = this.props;

    const opts = {
      defaultChecked : isChecked,
      ...( isDisabled && { disabled: true } ),
      ...( ( onClick && typeof onClick === 'function' ) && { onClick } )
    };

    return (
      <div className={
        classNames( `RadioButton ${ className || '' }`, {
          'RadioButton--disabled': isDisabled,
          className : isDisabled
        } )
      }
      >
        <div className='form-radio'>
          <input
            type='radio'
            className='form--control'
            { ...props.input }
            value={ value }
            id={ id }
            name={ name }
            { ...opts }
          />
          <label htmlFor={ id } className='form--label'>
            { children }
            { isDisabled &&
              <FontAwesomeIcon icon={ faBan } />
            }
          </label>
        </div>
      </div>
    );
  }

  /**
   * Renders the RadioButton component
   */
  render(){
    const {
      children,
      id,
      name,
      value,
      isChecked,
      isDisabled,
      onChange
    } = this.props;

    const opts = {
      ...( isChecked && { defaultChecked: true } ),
      ...( isDisabled && { disabled: true } ),
      ...( ( onChange && typeof onChange === 'function' ) && { onChange } )
    };

    return (
      <Field
        type='radio'
        component={ this.renderField }
        value={ value }
        id={ id }
        name={ name }
        { ...opts }
      />
    );
  }
}

RadioButton.propTypes = propTypes;

export default RadioButton;

