import React from 'react';
import { reduxForm } from 'redux-form';
import { Provider } from 'react-redux';
import RadioButton from './RadioButton';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';

const Decorator = reduxForm( { form:'testForm' } )( RadioButton );

describe( '<RadioButton/> Component', () => {
  let component;
  let reduxFormMocks = {
    id: 'temp_id-0',
    name: 'temp_name-radio',
    value: 'Temp Radio Value'
  };

  const store = configureStore( );
  component = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...reduxFormMocks }/>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'RadioButton' ).length ).toBe( 1 );
  } );

  it( 'should have a child input field', () => {
    expect( component.find( 'input' ).length ).toBe( 1 );
  } );

  describe( 'When radioButton Enable', () => {
    const wrapper = mountWithIntl(
      <Provider store={ store }>
        <Decorator
          name='InputField'
          id='InputFieldId'
          value='InputFieldValue'
          isDisabled={ true }
          isChecked={ true }
          onClick={ jest.fn() }
          className='test'
        />
      </Provider>
    );

    const input = wrapper.find( 'input' );


    it( 'should have FontAwesomeIcon when radio is disable', () => {
      expect( wrapper.find( 'FontAwesomeIcon' ).length ).toBe( 1 );
    } );

    it( 'should have className fa-ban', () => {
      expect( wrapper.find( 'FontAwesomeIcon svg' ).props().className ).toContain( 'fa-ban' );
    } );
    it( 'the type is set by the prop', () => {
      expect( input.props().type ).toBe( 'radio' );
    } );

    it( 'name is present', () => {
      expect( input.props().name ).toBe( 'InputField' );
    } );

    it( 'value should be set', () => {
      expect( input.props().value ).toBe( 'InputFieldValue' );
    } );

    it( 'id should be set', () => {
      expect( input.props().id ).toBe( 'InputFieldId' );
    } );

    it( 'isChecked should be set', () => {
      expect( input.props().defaultChecked ).toBe( true );
    } );

    it( 'isDisabled should be set', () => {
      expect( input.props().disabled ).toBe( true );
    } );

    it( 'className should be set when present in props', () => {
      expect( wrapper.find( '.RadioButton.test' ).length ).toBe( 1 );
    } );

    it( 'onClick should be set', () => {
      expect( input.props().onClick.toString() ).toEqual( jest.fn().toString() );
    } );
  } );

  describe( 'When radioButton Disable', () => {
    const wrapper1 = mountWithIntl(
      <Provider store={ store }>
        <Decorator
          isDisabled={ false }
          name='InputField'
          id='InputFieldId'
          value='InputFieldValue'
          isChecked={ false }
          onClick='invalid'
        />
      </Provider>
    );

    const input1 = wrapper1.find( 'input' );

    it( 'should not have FontAwesomeIcon when radio is enable', () => {
      expect( wrapper1.find( 'FontAwesomeIcon' ).length ).toBe( 0 );
    } );

    it( 'className should not be set if not present in props', () => {
      expect( wrapper1.find( '.RadioButton' ).length ).toBe( 1 );
    } );

    it( 'does not allow invalid types to be set for isChecked', () => {
      expect( input1.props().defaultChecked ).not.toBe( 'test' );
    } );

    it( 'does not allow invalid types to be set for isDisabled', () => {
      expect( input1.props().disabled ).not.toBe( 'test' );
    } );

    it( 'does not allow invalid types to be set for onClick', () => {
      expect( input1.props().onClick ).toBe( undefined );
    } );
  } );
} );
