/**
 * RatingPanel
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './RatingPanel.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar } from '@fortawesome/pro-solid-svg-icons/faStar';
import { formatMessage } from '../Global/Global';
import messages from './RatingPanel.messages';


const propTypes = {
  reviews: PropTypes.number,
  width: PropTypes.number,
  starWidth: PropTypes.number,
  starCount: PropTypes.number

}

const defaultProps = {
  starWidth: 15,
  starCount: 5
}

/**
 * Class
 * @extends React.Component
 */
class RatingPanel extends Component{


  /**
   * Renders the RatingPanel component
   */

  getStars( starCount, starWidth ){
    let stars = [];
    let initialStarWidth = 0;
    for ( let i = 0; i < starCount; i++ ){
      stars.push(
        <div
          className='RatingPanel__image'
          key={ i }
          style={ { left: initialStarWidth } }
        >
          <FontAwesomeIcon icon={ faStar }/>
        </div>
      );
      initialStarWidth += starWidth;
    }
    return stars;
  }

  render(){
    const {
      reviews,
      width,
      starWidth,
      starCount
    } = this.props;



    let initalStarCount = starCount;
    return (
      <div className='RatingPanel'>
        <div className='RatingPanel__container '>
          <div className='RatingPanel__panel RatingPanel__panel--background'>
            { this.getStars( initalStarCount, starWidth ) }
          </div>

          <div
            className='RatingPanel__panel RatingPanel__panel--foreground'
            style={ { width: width } }
          >
            <label className='sr-only'>
              { formatMessage( messages.ratingStarCount, { originalRating:( ( width / starWidth ).toFixed( 1 ) ).toString(), maxRating:starCount } ) }
            </label>
            { this.getStars( initalStarCount, starWidth ) }
          </div>
          { reviews &&
            (
              <div className='RatingPanel__reviewsCount'>
                <label className='sr-only'>
                  { formatMessage( messages.numberOfReviews ) }
                </label>
              (
                { reviews }
)
              </div>
            )
          }
        </div>
      </div>
    );
  }
}

RatingPanel.propTypes = propTypes;
RatingPanel.defaultProps = defaultProps;

export default RatingPanel;
