/*
 * ProductSamples Messages
 *
 * This contains all the text for the ProductSamples component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {

  numberOfReviews: {
    id: 'i18n.RatingPanel.numberOfReviews',
    defaultMessage: 'Number Of Reviews'
  },
  ratingStarCount: {
    id: 'i18n.RatingPanel.ratingStarCount',
    defaultMessage: '{originalRating} out of {maxRating} stars'
  }

} );
