import React from 'react';
import ReactDOM from 'react-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import RatingPanel from './RatingPanel';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
import messages from './RatingPanel.messages';

describe( '<RatingPanel />', () => {
  let component;
  let props = {
    reviews: 234,
    width: 60,
    starWidth: 15,
    starCount: 5
  }
  it( 'renders without crashing', () => {
    component = mountRatingPanel( props );
    expect( component.find( 'RatingPanel' ).length ).toBe( 1 );
  } );
  // RatingPanel__container
  it( 'Should contain 5 stars in the background', () => {
    component = mountRatingPanel( props );
    expect( component.find( '.RatingPanel__panel.RatingPanel__panel--background' ).find( 'svg' ).length ).toBe( props.starCount );
  } );
  it( 'Should contain 5 stars in the foreground', () => {
    component = mountRatingPanel( props );
    expect( component.find( '.RatingPanel__panel.RatingPanel__panel--foreground' ).find( 'svg' ).length ).toBe( props.starCount );
  } );
  it( 'Should contain review count', () => {
    component = mountRatingPanel( props );
    expect( component.find( '.RatingPanel__reviewsCount' ).text() ).toBe( messages.numberOfReviews.defaultMessage + '(' + props.reviews + ')' );
  } );
  it( 'Should render proper aria-label for review count', () => {
    component = mountRatingPanel( props );
    expect( component.find( '.RatingPanel__reviewsCount label' ).text() ).toBe( messages.numberOfReviews.defaultMessage );
  } );
  it( 'Should render proper aria-label for star ratings', () => {
    component = mountRatingPanel( props );
    expect( component.find( '.RatingPanel__panel--foreground label' ).text() ).toBe( '4.0 out of 5 stars' );
  } );
  it( 'should render fontAwesome icon faStar', () => {
    component = mountRatingPanel( props );
    let fontAwesomeIcon = component.find( '.RatingPanel__image' ).find( FontAwesomeIcon );
    expect( fontAwesomeIcon.at( 0 ).props().icon.iconName ).toEqual( 'star' );
  } );

} );

function mountRatingPanel( props ){
  return mountWithIntl(
    <RatingPanel
      { ...props }
    />
  );
}
