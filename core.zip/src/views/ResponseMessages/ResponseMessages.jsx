/**
 * Response Messages
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import classNames from 'classnames';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faExclamationCircle } from '@fortawesome/pro-solid-svg-icons/faExclamationCircle';
import { faExclamationTriangle } from '@fortawesome/pro-solid-svg-icons/faExclamationTriangle';
import { faCheckCircle } from '@fortawesome/pro-solid-svg-icons/faCheckCircle';
import { faTimesCircle } from '@fortawesome/pro-solid-svg-icons/faTimesCircle';
import { formatMessage } from '../Global/Global';
import Text from '../Text/Text';
import Exclamation from '../Icons/exclamationcircle';
import CloseSVG from '../Icons/close';
import './ResponseMessages.css';
import {
  setBroadcastMessage
} from '../../events/global/global.events';


const propTypes = {
  messageType : PropTypes.string,
  message: PropTypes.string,
  fieldName: PropTypes.string,
  broadCastAdaMessage: PropTypes.bool,
  closeResponseMessage: PropTypes.func,
  messageSize: PropTypes.string
};

const defaultProps = {
  messageType: 'error',
  broadCastAdaMessage: true,
  messageSize: 'small'
};

class ResponseMessages extends Component{
/**
 * Class
 * @extends React.Component
 */

  broadcastMessageTimer = undefined;

  invokeBroadcastMessage( broadcastMessage, message ){
    broadcastMessage( message );
  }

  componentDidUpdate( prevProps ){
    if( this.props.broadCastAdaMessage ){
      if( this.props.message !== prevProps.message ){
        // this will trigger an event to populat thee global ara-live region with the message, but with a delay of 1000 ms, so that it can be nullified if the component gets unmounted
        this.broadcastMessageTimer = setTimeout( this.invokeBroadcastMessage, 1000, this.props.broadcastMessage, `${this.props.fieldName ? this.props.fieldName : ''} ${this.props.message}` );
      }
    }
  }


  componentDidMount(){
    if( this.props.broadCastAdaMessage ){
      // this will trigger an event to populat thee global ara-live region with the message, but with a delay of 1000 ms, so that it can be nullified if the component gets unmounted
      this.broadcastMessageTimer = setTimeout( this.invokeBroadcastMessage, 1000, this.props.broadcastMessage, `${this.props.fieldName ? this.props.fieldName : ''} ${this.props.message}` );
    }
  }

  componentWillUnmount(){
    if( this.props.broadCastAdaMessage ){
      // this will nullify the broadcast message function invocation
      clearTimeout( this.broadcastMessageTimer );
      // this will be useful in scenarios where same broadcast message needs to be repeated multiple times
      this.props.broadcastMessage( '' );
    }
  }

  render(){
    const {
      message
    } = this.props;

    const messageType = this.props.messageType.toLowerCase();
    return (
      <div className='ResponseMessages'>
        <div
          className={
            classNames(
              'ResponseMessages__message', {
                'ResponseMessages__message--error': messageType === 'error',
                'ResponseMessages__message--error-alert': messageType === 'error-alert',
                'ResponseMessages__message--warning': messageType === 'warning',
                'ResponseMessages__message--warning-alert': messageType === 'warning-alert',
                'ResponseMessages__message--error-message': messageType === 'error-message',
                'ResponseMessages__message--warning-message': messageType === 'warning-message',
                'ResponseMessages__message--success-message': messageType === 'success-message',
                'ResponseMessages__message--notavailable-message': messageType === 'notavailable-message',
                'ResponseMessages__message--error ResponseMessages__message--error-checkout': messageType === 'checkout-error'
              }
            )
          }
        >
          {
            messageType &&
            <span className='ResponseMessages__message--icon'>
              { ( messageType === 'error' || messageType === 'error-alert' || messageType === 'checkout-error' || messageType === 'warning-alert' || messageType === 'error-message' ) &&
                <FontAwesomeIcon
                  icon={ faExclamationCircle }
                  className='ResponseMessages__message--errorIcon'
                />
              }
              {
                messageType === 'warning-message' &&
                <FontAwesomeIcon
                  icon={ faExclamationTriangle }
                  className='ResponseMessages__message--warningIcon'
                />
              }
              {
                messageType === 'success-message' &&
                <FontAwesomeIcon
                  icon={ faCheckCircle }
                  className='ResponseMessages__message--successIcon'
                />
              }
              {
                messageType === 'notavailable-message' &&
                <FontAwesomeIcon
                  icon={ faTimesCircle }
                  className='ResponseMessages__message--notAvailableIcon'
                />
              }
            </span>

          }
          {
            messageType !== 'notavailable-message' &&
            <span className={
              classNames(
                'ResponseMessages__message--text',
                {
                  [`ResponseMessages__message--text--${this.props.messageSize}`]: this.props.messageSize
                }
              )
            }
            dangerouslySetInnerHTML={ { __html: message } }
            />
          }

          {
            messageType === 'notavailable-message' &&
            <Text type='body-2'
              colorOverride='neutral-80'
              htmlTag='span'
            >
              { message }
            </Text>
          }
        </div>
      </div>
    );

  }
}

export const mapDispatchToProps = ( dispatch ) => {
  return {
    broadcastMessage : function( message ){
      dispatch( setBroadcastMessage( message ) )
    }
  };
}

ResponseMessages.propTypes = propTypes;
ResponseMessages.defaultProps = defaultProps;

export const connectFunction = ( mapDispatchToProps ) => {
  return connect( null, mapDispatchToProps )( ResponseMessages );
};

export default connectFunction( mapDispatchToProps );
