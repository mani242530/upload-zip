/**
 * Created by satchuyutuni on 6/6/17.
 */
import React from 'react';
import ReactDOM from 'react-dom';
import { IntlProvider } from 'react-intl';
import { Provider } from 'react-redux';
import ResponseMessages, { mapDispatchToProps, connectFunction } from './ResponseMessages';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';
import {
  setBroadcastMessage
} from '../../events/global/global.events';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';
import qProtocol from '../../utils/qprotocol/qprotocol';
qProtocol.listenQubitLoad = jest.fn();


const intlProvider = new IntlProvider( { locale: 'en' }, {} );
const { intl } = intlProvider.getChildContext();
describe( '<ResponseMessages />', () => {

  const store = configureStore( );

  let props = {
    intl
  }

  let component = mountWithIntl(
    <Provider store={ store }>
      <ResponseMessages
        { ...props }
      />
    </Provider>
  );

  it( 'renders without crashing', ()=>{
    expect( component.find( '.ResponseMessages' ).length ).toBe( 1 );
  } );

  it( 'should have one ResponseMessages__message', ()=>{
    expect( component.find( '.ResponseMessages__message' ).length ).toBe( 1 );
  } );

  it( 'should have ResponseMessages__message with warning-alert class', ()=>{
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessages
          message='hi'
          messageType='warning-alert'
        />
      </Provider>
    );

    expect( component1.find( '.ResponseMessages__message--warning-alert' ).length ).toBe( 1 );
  } );

  it( 'should contain aria-label when field name is passed', ()=>{
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessages
          message='Required'
          fieldName='First Name'
        />
      </Provider>
    );
    let spanTag = component1.find( '.ResponseMessages__message--text' );
    expect( spanTag.html() ).toContain( '<span class="ResponseMessages__message--text ResponseMessages__message--text--small">Required</span>' );
  } );

  it( 'should not contain aria-label when field name is not passed.', ()=>{
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessages
          message='hi'
        />
      </Provider>
    );
    let spanTag = component1.find( '.ResponseMessages__message--text' );
    expect( spanTag.html() ).not.toContain( 'aria-label' );
  } )

  it( 'the broadcastMessage mapped to props should dispatch the broadcastmessage action', ()=>{
    const message = 'item removed';
    const dispatchMock = jest.fn();
    const mapDispatchToPropsMock = mapDispatchToProps( dispatchMock );
    mapDispatchToPropsMock.broadcastMessage( message );
    expect( dispatchMock ).toBeCalledWith( setBroadcastMessage( message ) )
  } )


  it( 'should invoke broadcastMessage once the component is mounted', ()=>{
    jest.useFakeTimers();
    const broadcastmessageMock = jest.fn();
    const mapDispatchToPropsMock = () => {
      return {
        broadcastMessage : broadcastmessageMock
      }
    }
    const ResponseMessagesMock = connectFunction( mapDispatchToPropsMock );
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessagesMock
          message='Required'
          fieldName='First Name'
        />
      </Provider>
    );
    const node = component1.find( 'ResponseMessages' ).instance();
    jest.runAllTimers();
    expect( node.broadcastMessageTimer ).toBeTruthy();
    expect( broadcastmessageMock ).toBeCalled();
  } )

  it( 'should invoke blank broadcastMessage if the component was unmounted', ()=>{
    const broadcastmessageMock = jest.fn();
    const mapDispatchToPropsMock = () => {
      return {
        broadcastMessage : broadcastmessageMock
      }
    }
    const ResponseMessagesMock = connectFunction( mapDispatchToPropsMock );
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessagesMock
          message='Required'
          fieldName='First Name'
        />
      </Provider>
    );
    const node = component1.find( 'ResponseMessages' ).instance();
    node.componentWillUnmount();
    expect( broadcastmessageMock ).toBeCalledWith( '' );
  } )

  it( 'should contain ResponseMessages__message--error-checkout if message type is checkout-eror', ()=>{
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessages
          message='hi'
          messageType='checkout-error'
        />
      </Provider>
    );

    expect( component1.find( '.ResponseMessages__message--error-checkout' ).length ).toBe( 1 );
    expect( component1.find( '.ResponseMessages__message--error' ).length ).toBe( 1 );
    expect( component1.find( 'svg' ).length ).toBe( 1 );
  } )

  it( 'should contain ResponseMessages__message--error-alert with the view changes if message type is error-alert', ()=>{
    const component = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessages
          message='test message'
          messageType='error-alert'
        />
      </Provider>
    );
    expect( component.find( '.ResponseMessages__message--error-alert' ).length ).toBe( 1 );
    expect( component.find( 'svg' ).length ).toBe( 1 );
  } );

  it( 'should invoke the setTimeout  on componentDidUpdate', ()=>{
    jest.useFakeTimers();
    const broadcastmessageMock = jest.fn();
    const invokeBroadcastMessageMock = jest.fn();
    const mapDispatchToPropsMock = () => {
      return {
        broadcastMessage : broadcastmessageMock
      }
    }
    const ResponseMessagesMock = connectFunction( mapDispatchToPropsMock );
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessagesMock
          message='Required'
          fieldName='First Name'
        />
      </Provider>
    );
    const node = component1.find( 'ResponseMessages' ).instance();
    node.invokeBroadcastMessage = invokeBroadcastMessageMock;
    const prevProps = { message: 'test message' };
    node.componentDidUpdate( prevProps );
    jest.runAllTimers();
    expect( node.broadcastMessageTimer ).toBeTruthy();
    expect( broadcastmessageMock ).toBeCalled();
    expect( setTimeout ).toBeCalledWith( invokeBroadcastMessageMock, 1000, broadcastmessageMock, 'First Name Required' );

  } )

  it( 'should contain ResponseMessages__message--error-message if message type is error-message', ()=>{
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessages
          message='hi'
          messageType='error-message'
        />
      </Provider>
    );

    expect( component1.find( '.ResponseMessages__message--error-message' ).length ).toBe( 1 );
    expect( component1.find( '.ResponseMessages__message--text' ).length ).toBe( 1 );
    expect( component1.find( '.ResponseMessages__message--errorIcon svg' ).length ).toBe( 1 );
  } )

  it( 'should contain ResponseMessages__message--successIcon if message type is success-message', ()=>{
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessages
          message='hi'
          messageType='success-message'
        />
      </Provider>
    );

    expect( component1.find( '.ResponseMessages__message--success-message' ).length ).toBe( 1 );
    expect( component1.find( '.ResponseMessages__message--text' ).length ).toBe( 1 );
    expect( component1.find( '.ResponseMessages__message--successIcon svg' ).length ).toBe( 1 );
  } )
  it( 'should contain ResponseMessages__message--notavailable-message if message type is notavailable-message', ()=>{
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessages
          message='Not Available'
          messageType='notavailable-message'
        />
      </Provider>
    );

    expect( component1.find( '.ResponseMessages__message--notavailable-message' ).length ).toBe( 1 );
    expect( component1.find( '.Text' ).at( 0 ).text() ).toBe( 'Not Available' );
    expect( component1.find( '.ResponseMessages__message--notAvailableIcon svg' ).length ).toBe( 1 );
  } )
  it( 'should contain ResponseMessages__message--warning-message if message type is warning-message', ()=>{
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessages
          message='hi'
          messageType='warning-message'
        />
      </Provider>
    );

    expect( component1.find( '.ResponseMessages__message--warning-message' ).length ).toBe( 1 );
    expect( component1.find( '.ResponseMessages__message--text' ).length ).toBe( 1 );
    expect( component1.find( '.ResponseMessages__message--warningIcon svg' ).length ).toBe( 1 );
  } )
  it( 'should contain ResponseMessages__message--text--large if message size is large', ()=>{
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <ResponseMessages
          message='hi'
          messageType='success-message'
          messageSize='large'
        />
      </Provider>
    );

    expect( component1.find( '.ResponseMessages__message--success-message' ).length ).toBe( 1 );
    expect( component1.find( '.ResponseMessages__message--text' ).length ).toBe( 1 );
    expect( component1.find( '.ResponseMessages__message--text--large' ).length ).toBe( 1 );
  } )
} );
