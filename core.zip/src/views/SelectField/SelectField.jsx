import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './SelectField.css';
import { Field } from 'redux-form';
import classNames from 'classnames';
import ResponseMessages from '../ResponseMessages/ResponseMessages';
import ChevronDownSVG from '../Icons/chevrondown';


const propTypes = {
  options: PropTypes.array,
  name: PropTypes.string.isRequired,
  defaultOption: PropTypes.string,
  ariaLabel: PropTypes.string
}

const defaultProps = {
  options: ['no options provided']
}

class SelectField extends Component{

  constructor( props ){
    super( props );
    this.state = {
      selectTouched: false
    }
  }

  instanceOnChangeEvt = undefined;

  componentDidMount(){
    if( this.props.value && this.props.value.length > 0 ){
      this.instanceOnChangeEvt( this.props.value );
    }
  }

  /*
   * If we are using 'value' property of the component to set the value of the input, below logic ensures that
   * the select field gets the new value whenever there is a change in the value property
   * This method ensures that select field gets new value whenever the property linked to this field in redux store changes.
  */

  componentDidUpdate( prevProps ){
    if( prevProps.value !== this.props.value ){
      this.instanceOnChangeEvt( this.props.value );
    }
  }


  renderSelectField = props => {
    const {
      input,
      name,
      options,
      autoComplete,
      tabIndex,
      meta: { error, touched },
      defaultOption,
      ariaLabel
    } = props;

    this.instanceOnChangeEvt = input.onChange;

    return (
      <div
        className={
          classNames(
            'SelectField', {
              'SelectField--error': error && ( this.state.selectTouched || touched )
            }
          )
        }
        onClick={
          ()=>{
            this.setState( { 'selectTouched': true } )
          }
        }
      >
        <select
          className={
            classNames(
              'SelectInput__select', {
                'SelectInput__select--active':( props.input.value !== '' )
              }
            )
          }
          name={ input.name }
          id={ input.name }
          autoComplete={ autoComplete }
          onChange={ input.onChange }
          value={ input.value }
          tabIndex={ tabIndex }
          { ...( ariaLabel && { 'aria-label': ariaLabel } ) }
        >

          { props.defaultOption && <option value=''>{ props.defaultOption }</option> }

          {
            options.map( ( option, index ) => {
              return (
                <option
                  key={ index }
                  value={ option.value }
                >
                  { option.label }
                </option>
              )
            } )
          }
        </select>

        <label
          className={
            classNames(
              'SelectField__label', {
                'SelectField__label--active': ( props.input.value !== '' )
              }
            )
          }
          htmlFor={ input.name }
        >
          { props.input.value && this.props.label }

        </label>

        <div className={
          classNames(
            'SelectField__chevron', {
              'SelectField__chevron--active': ( props.input.value !== '' )
            }
          )
        }
        >
          <ChevronDownSVG />
        </div>

      </div>
    )
  }

  render(){
    const {
      options,
      name,
      tabIndex,
      autoComplete,
      validate,
      defaultOption,
      ariaLabel
    } = this.props;

    return (
      <Field
        name={ name }
        tabIndex={ tabIndex }
        ariaLabel={ ariaLabel }
        type='select'
        component={ this.renderSelectField }
        { ...( options && { options } ) }
        { ...( autoComplete && { autoComplete } ) }
        { ...( validate && { validate } ) }
        { ...( defaultOption && { defaultOption } ) }
      />
    )
  }
}

SelectField.propTypes = propTypes;
SelectField.defaultProps = defaultProps;

export default SelectField;
