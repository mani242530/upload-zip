import React from 'react';
import ReactDOM from 'react-dom';
import { reduxForm } from 'redux-form';
import { Provider } from 'react-redux';
import SelectField from './SelectField';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';


const Decorator = reduxForm( { form:'testForm' } )( SelectField );
describe( '<SelectField />', () => {
  let component;
  let props = {
    name: 'select',
    value: 'IL'
  }

  let store = configureStore( );
  component = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props } />
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'SelectField' ).length ).toBe( 1 );
  } );

  it( 'Should contain selectField label if selectField have value', () => {
    expect( component.find( 'SelectField .SelectField__label.SelectField__label--active' ).length ).toBe( 1 );
  } );

  it( 'Should contain active selectInput Field if selectField have value', () => {
    expect( component.find( 'SelectField .SelectInput__select.SelectInput__select--active' ).length ).toBe( 1 );
  } );

  it( 'Should contain active SelectField chevron Field if selectField have value', () => {
    expect( component.find( 'SelectField .SelectField__chevron.SelectField__chevron--active' ).length ).toBe( 1 );
  } );

  store = configureStore( );
  let props1 = {
    name: 'select',
    ariaLabel: 'Select Field',
    defaultOption:'Select'
  }

  let component1 = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props1 } />
    </Provider>
  );
  it( 'Should not contain selectField label if selectField doesnot have value', () => {
    expect( component1.find( 'SelectField .SelectField__label .SelectField__label--active' ).length ).toBe( 0 );
  } );

  it( 'Should not contain active selectInput Field if selectField have value', () => {
    expect( component1.find( 'SelectField .SelectInput__select .SelectInput__select--active' ).length ).toBe( 0 );
  } );

  it( 'Should not contain active SelectField chevron Field if selectField have value', () => {
    expect( component1.find( 'SelectField .SelectField__chevron .SelectField__chevron--active' ).length ).toBe( 0 );
  } );

  it( 'Should render the aria-label for the given ariaLabel prop', () => {
    expect( component1.find( 'select' ).props()['aria-label'] ).toBe( 'Select Field' );
  } );

  it( 'Should render the default option if defaultOption props value is present', () => {
    expect( component1.find( 'option' ).at( 0 ).props().children ).toBe( props1.defaultOption );
    expect( component1.find( 'select' ).find( 'option' ).length ).toBe( 2 );
  } );

  it( 'Should not render the default option if defaultOption props value is not passed', () => {
    let propsWithNoDefault = {
      name: 'select'
    }
    let componentWithNoDefault = mountWithIntl(
      <Provider store={ store }>
        <Decorator { ...propsWithNoDefault } />
      </Provider>
    );
    expect( componentWithNoDefault.find( 'select' ).find( 'option' ).length ).toBe( 1 );
  } );

  it( 'should call the instanceOnChangeEvt on componentDidUpdate', () => {
    const component2 = mountWithIntl(
      <Provider store={ store }>
        <Decorator name='SelectField' value='CO'/>
      </Provider>
    )
    const instance = component2.find( 'SelectField' ).instance();
    const prevProps = { value: 'IL' };
    instance.instanceOnChangeEvt = jest.fn();
    instance.componentDidUpdate( prevProps );
    expect( instance.instanceOnChangeEvt ).toHaveBeenCalledWith( 'CO' );
  } );
} );
