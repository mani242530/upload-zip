/**
 * SignInMenu
 */

import React, { Component } from 'react';
import './SignInMenu.css';
import PropTypes from 'prop-types';
import Anchor from '../Anchor/Anchor';
import { formatMessage } from '../Global/Global';
import messages from './SignInMenu.messages';
import { formatOmnitureAttr } from '../../utils/omniture/omniture';

/**
 * Class
 * @extends React.Component
 */

const propTypes = {
  userLogout: PropTypes.func
}

class SignInMenu extends Component{


  /**
   * Renders the SignInMenu component
   */

  getUserLogout = ( e ) =>{
    e.preventDefault();
    this.props.userLogout( this.props.history );
  }

  render(){



    return (
      <div className='SignInMenu'>
        <div className='SignInMenu__userOptions'>
          <Anchor
            url='/ulta/myaccount/'
            dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.myAccount ) ) }
          >
            { formatMessage( messages.myAccount ) }
          </Anchor>
        </div>
        <div className='SignInMenu__userOptions'>
          <Anchor
            url='/ulta/myaccount/template.jsp?page=orderstatus'
            dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.orderStatus ) ) }
          >
            { formatMessage( messages.orderStatus ) }
          </Anchor>
        </div>
        <div className='SignInMenu__userOptions'>
          <Anchor
            url='/ulta/myaccount/template.jsp?page=favorites'
            dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.myFavorites ) ) }
          >
            { formatMessage( messages.myFavorites ) }
          </Anchor>
        </div>
        <div className='SignInMenu__userOptions'>
          <Anchor
            url='/ulta/myaccount/addressbook.jsp'
            dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.addressBook ) ) }
          >
            { formatMessage( messages.addressBook ) }
          </Anchor>
        </div>
        <div className='SignInMenu__userOptions'>
          <Anchor
            url='/ulta/myaccount/template.jsp?page=payment'
            dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.payment ) ) }
          >
            { formatMessage( messages.payment ) }
          </Anchor>
        </div>
        <div className='SignInMenu__userOptions'>
          <Anchor
            url='/ulta/myaccount/template.jsp?page=preferences'
            dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.beautyPrefrences ) ) }
          >
            { formatMessage( messages.beautyPrefrences ) }
          </Anchor>
        </div>
        <div className='SignInMenu__userOptions'>
          <Anchor
            url='#'
            dataNavDescription={ formatOmnitureAttr( 'h', formatMessage( messages.signOut ) ) }
            clickHandler={ this.getUserLogout }
          >
            { formatMessage( messages.signOut ) }
          </Anchor>
        </div>


      </div>
    );
  }
}


export default SignInMenu;
