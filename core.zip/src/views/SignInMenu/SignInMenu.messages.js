/*
 * SignInMenu Messages
 *
 * This contains all the text for the SignInMenu component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  myAccount: {
    id: 'i18n.SignInMenu.myAccount',
    defaultMessage: 'My Account'
  },
  orderStatus: {
    id: 'i18n.SignInMenu.orderStatus',
    defaultMessage: 'Order Status'
  },
  myFavorites: {
    id: 'i18n.SignInMenu.myFavorites',
    defaultMessage: 'My Favorites'
  },
  addressBook: {
    id: 'i18n.SignInMenu.addressBook',
    defaultMessage: 'Address Book'
  },
  payment: {
    id: 'i18n.SignInMenu.payment',
    defaultMessage: 'Payment'
  },
  beautyPrefrences: {
    id: 'i18n.SignInMenu.beautyPrefrences',
    defaultMessage: 'Beauty Preferences'
  },
  signOut: {
    id: 'i18n.SignInMenu.signOut',
    defaultMessage: 'Sign Out'
  }

} );
