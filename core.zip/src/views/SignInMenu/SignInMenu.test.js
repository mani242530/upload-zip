import React from 'react';
import ReactDOM from 'react-dom';
import SignInMenu from './SignInMenu';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<SignInMenu />', () => {
  let component;
  let userLogoutMock = jest.fn();
  let props = {
    userLogout:userLogoutMock
  }
  it( 'renders without crashing', () => {
    component = mountWithIntl( <SignInMenu { ...props } /> );
    expect( component.find( 'SignInMenu' ).length ).toBe( 1 );
  } );

  it( 'renders without crashing', () => {
    component.find( 'SignInMenu .SignInMenu__userOptions' ).find( 'Anchor' ).at( 6 ).simulate( 'click' );
    expect( userLogoutMock ).toBeCalled();
  } );

} );
