/**
 * SignInModal
 */
import Modal from 'react-modal';
import React, { Component } from 'react';
import './SignInModal.css';
import PropTypes from 'prop-types';
import CloseSVG from '../Icons/close';
import LoginForm from '../LoginForm/LoginForm';
import Button from '../Button/Button';
import Button20 from '../Button20/Button20';
import Divider from '../Divider/Divider';
import Anchor from '../Anchor/Anchor';
import Text from '../Text/Text';
import Heading from '../Heading/Heading';
import { formatMessage } from '../Global/Global';
import messages from './SignInModal.messages';
import { disableBackgroundElements, enableBackgroundElements } from '../../utils/accessibility/accessibility';

const propTypes = {
  signInMessageBeans: PropTypes.object,
  handleOnClick: PropTypes.func,
  handleOnRequestClose: PropTypes.func,
  a11yLabel: PropTypes.string,
  signInHeader: PropTypes.string,
  analyticsSourcePageLabel: PropTypes.string,
  closeModalLabel: PropTypes.string,
  isOpen: PropTypes.bool,
  redirectPage: PropTypes.bool
}

const defaultProps = {
  isOpen: true,
  redirectPage: false
}


class SignInModal extends Component{

  constructor(){
    super();
    this.afterOpenModal = this.afterOpenModal.bind( this );
  }

  afterOpenModal(){
    let modalElement = document.getElementsByClassName( 'SignInModal' )[0];
    disableBackgroundElements( [modalElement] );
  }

  componentWillUnmount(){
    enableBackgroundElements();
  }

  /**
   * Renders the SignInModal component
   */
  render(){
    return (
      <Modal
        isOpen={ this.props.isOpen }
        contentLabel={ this.props.a11yLabel }
        onRequestClose={ this.props.handleOnRequestClose }
        onAfterOpen={ this.afterOpenModal }
        className='SignInModal'
        role='dialog'
        ariaHideApp={ false }
      >
        <Button
          className='SignInModal__CloseButton'
          clickEventHandler={ this.props.handleOnClick }
          ariaLabel={ this.props.closeModalLabel }
        >
          <CloseSVG/>
        </Button>
        <div className='SignInModal__loginForm'>
          <div className='SignInModal__leftPanel'>
            <div className='SignInModal__signInHeader'>
              <Heading
                rank={ 2 }
                type='tertiary'
              >
                { formatMessage( messages.signIn ) }
              </Heading>
            </div>
            <LoginForm
              messageBeans={ this.props.signInMessageBeans }
              successPath={ this.props.successPath }
              sourcePage={ this.props.sourcePage }
              redirectPage={ this.props.redirectPage }
              useRouter={ false }
              buttonText={ formatMessage( messages.signIn ) }
              analyticsSourcePage={ this.props.analyticsSourcePageLabel }
              openForgetPasswordLinkInNewPage={ false }
              history={ this.props.history }
              loginSuccessHandler={ this.props.loginSuccessHandler }
            />
          </div>
          <div className='SignInModal__rightPanel'>
            <div className='SignInModal__mobileDivider'>
              <Divider dividerType='gray'/>
            </div>
            <div className='SignInModal__createAccountHeader'>
              <Heading
                rank={ 2 }
                type='tertiary'
              >
                { formatMessage( messages.createAccountHeader ) }
              </Heading>
            </div>
            <div className='SignInModal__benefitContainer'>
              <div className='SignInModal__benefitTitle'>
                <Text type='body-1'>
                  { formatMessage( messages.benefitTitle ) }
                </Text>
              </div>
              <div className='SignInModal__benefitDescription'>
                <ul>
                  <li>
                    <Text type='body-2'>
                      { formatMessage( messages.benefitDescriptionOne ) }
                    </Text>
                  </li>
                  <li>
                    <Text type='body-2'>
                      { formatMessage( messages.benefitDescriptionTwo ) }
                    </Text>
                  </li>
                  <li>
                    <Text type='body-2'>
                      { formatMessage( messages.benefitDescriptionThree ) }
                    </Text>
                  </li>
                </ul>
              </div>
            </div>
            <div className='SignInModal__createAccountButton'>
              <Button20
                type='button'
                btnStyle='secondary'
                size='large'
                block={ true }
              >
                <Anchor
                  url='ulta/myaccount/register.jsp'
                  title={ formatMessage( messages.createAccountButton ) }
                  displayType='primary'
                >
                  { formatMessage( messages.createAccountButton ) }
                </Anchor>
              </Button20>
            </div>
          </div>
        </div>
      </Modal>
    )
  }
}

SignInModal.propTypes = propTypes;
SignInModal.defaultProps = defaultProps;

export default SignInModal;
