/*
 * SignInModal Messages
 *
 * This contains all the text for the SignInModal component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  signIn: {
    id: 'i18n.SignInModal.signIn',
    defaultMessage: 'Sign In'
  },
  createAccountHeader: {
    id: 'i18n.SignInModal.createAccountHeader',
    defaultMessage: 'Create an Account'
  },
  createAccountButton: {
    id: 'i18n.SignInModal.createAccountButton',
    defaultMessage: 'Create an Account'
  },
  benefitTitle: {
    id: 'i18n.SignInModal.benefitTitle',
    defaultMessage: 'Take advantage of these benefits:'
  },
  benefitDescriptionOne: {
    id: 'i18n.SignInModal.benefitDescriptionOne',
    defaultMessage: 'Faster checkout'
  },
  benefitDescriptionTwo: {
    id: 'i18n.SignInModal.benefitDescriptionTwo',
    defaultMessage: 'Earn points on every purchase'
  },
  benefitDescriptionThree: {
    id: 'i18n.SignInModal.benefitDescriptionThree',
    defaultMessage: 'Save products to your favorites'
  }
} );
