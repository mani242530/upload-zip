
import React from 'react';
import { Provider } from 'react-redux';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';
import SignInModal from './SignInModal';
import messages from './SignInModal.messages';

import LoginForm from '../LoginForm/LoginForm';
import { disableBackgroundElements, enableBackgroundElements } from '../../utils/accessibility/accessibility';

jest.mock( '../../utils/accessibility/accessibility', () => {
  return {
    disableBackgroundElements: jest.fn(),
    enableBackgroundElements: jest.fn()
  }
} );

let appElement = document.createElement( 'div' );
appElement.id = 'js-cartpage';
document.body.appendChild( appElement );

describe( '<SignInModal />', () => {
  const store = configureStore();
  store.getState().global = {
    switchData:{
      switches:{
        enablePersistentLogin:true
      }
    }
  }

  let props = {
    setAppElement:'#js-cartpage',
    a11yLabel: 'asdfasdf',
    handleOnRequestClose: jest.fn(),
    signInHeader: '1232321asdfasd',
    signInMessageBeans: {
      'messageKey': 'validateFormDataError',
      'messageDesc': 'Please enter a valid username'
    },
    closeModalLabel: 'close the modal',
    analyticsSourcePageLabel: 'saveForLaterMessages.saveForLaterLabel',
    handleOnClick: jest.fn(),
    successPath: '/bag',
    sourcePage: 'checkoutLogin',
    loginSuccessHandler:{
      action:'moveToSFL'
    },
    redirectPage: false
  }
  let component = mountWithIntl(
    <Provider store={ store }>
      <SignInModal { ...props }/>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'SignInModal' ).length ).toBe( 1 );
    expect( component.find( 'Modal' ).length ).toBe( 1 );
  } );

  it( 'should have correct value for default props', () => {
    const component = mountWithIntl(
      <Provider store={ store }>
        <SignInModal { ...props }/>
      </Provider>
    );
    const node = component.find( 'SignInModal' ).instance();

    expect( component.find( 'SignInModal' ).props().isOpen ).toBe( true );
    expect( component.find( 'Modal' ).props().ariaHideApp ).toBe( false );
    expect( component.find( 'Modal' ).props().onAfterOpen ).toBe( node.afterOpenModal );
    expect( component.find( 'SignInModal' ).props().redirectPage ).toBe( false );
  } );

  it( 'should render ( close modal ) anchor with SVG and ariaLabel', () => {
    expect( document.body.getElementsByTagName( 'button' )[0].innerHTML.indexOf( '<title>Close</title>' ) ).toBeGreaterThan( 0 );
  } );

  it( 'it should show the sign in header message', () => {
    expect( component.find( '.SignInModal__signInHeader' ).length ).toBe( 1 );
    expect( component.find( '.SignInModal__signInHeader' ).text() ).toBe( messages.signIn.defaultMessage );
  } );

  it( 'it should render LoginForm component', () => {
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).length ).toBe( 1 );
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).props().successPath ).toBe( props.successPath );
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).props().sourcePage ).toBe( props.sourcePage );
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).props().analyticsSourcePage ).toBe( props.analyticsSourcePageLabel );
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).props().buttonText ).toBe( messages.signIn.defaultMessage );
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).props().messageBeans ).toBe( props.signInMessageBeans );
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).props().openForgetPasswordLinkInNewPage ).toBe( false );
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).props().redirectPage ).toBe( props.redirectPage );
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).props().useRouter ).toBe( false );
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).props().loginSuccessHandler ).toBe( props.loginSuccessHandler );
  } );

  it( 'should render Sign In button in LoginForm in the Modal', () => {
    expect( component.find( '.SignInModal__loginForm' ).find( LoginForm ).find( 'Button20' ).at( 1 ).text() ).toBe( messages.signIn.defaultMessage );
  } );

  it( 'should render forget username and password in the Modal', () => {
    expect( component.find( '.LoginForm__forgotCredentials a' ).length ).toBe( 2 );
  } );

  it( 'should render ( close modal ) button with SVG and ariaLabel', () => {
    expect( component.find( 'Modal' ).length ).toBe( 1 );
    expect( component.find( 'Modal' ).find( 'Button' ).at( 0 ).props().ariaLabel ).toBe( props.closeModalLabel );
    expect( document.body.getElementsByTagName( 'button' )[0].innerHTML.indexOf( '<title>Close</title>' ) ).toBeGreaterThan( 0 );
  } );

  it( 'should close the Modal when close Button clicked', () => {
    expect( component.find( 'Modal' ).length ).toBe( 1 );
    component.find( 'Modal' ).find( 'Button' ).at( 0 ).simulate( 'click' );
    expect( props.handleOnClick ).toHaveBeenCalled();
  } );

  it( 'should show create account header message', () => {
    expect( component.find( '.SignInModal__createAccountHeader' ).length ).toBe( 1 );
    expect( component.find( '.SignInModal__createAccountHeader' ).text() ).toBe( messages.createAccountHeader.defaultMessage );
  } );

  it( 'should show benefits container with benefits title and description ', () => {
    expect( component.find( '.SignInModal__benefitContainer' ).length ).toBe( 1 );
    expect( component.find( '.SignInModal__benefitTitle' ).length ).toBe( 1 );
    expect( component.find( '.SignInModal__benefitDescription li' ).length ).toBe( 3 );

    expect( component.find( '.SignInModal__benefitTitle' ).text() ).toBe( messages.benefitTitle.defaultMessage );
    expect( component.find( '.SignInModal__benefitDescription li' ).at( 0 ).text() ).toBe( messages.benefitDescriptionOne.defaultMessage );
    expect( component.find( '.SignInModal__benefitDescription li' ).at( 1 ).text() ).toBe( messages.benefitDescriptionTwo.defaultMessage );
    expect( component.find( '.SignInModal__benefitDescription li' ).at( 2 ).text() ).toBe( messages.benefitDescriptionThree.defaultMessage );
  } );

  it( 'should render create account button in Modal', () => {
    expect( component.find( '.SignInModal__createAccountButton Button20' ).at( 0 ).props().btnStyle ).toEqual( 'secondary' );
    expect( component.find( '.SignInModal__createAccountButton Button20' ).at( 0 ).props().size ).toEqual( 'large' );
    expect( component.find( '.SignInModal__createAccountButton Button20' ).at( 0 ).props().block ).toEqual( true );
    expect( component.find( '.SignInModal__createAccountButton Anchor' ).at( 0 ).props().url ).toEqual( 'ulta/myaccount/register.jsp' );
    expect( component.find( '.SignInModal__createAccountButton Anchor' ).at( 0 ).props().displayType ).toEqual( 'primary' );
    expect( component.find( '.SignInModal__createAccountButton' ).text() ).toBe( messages.createAccountButton.defaultMessage );
  } );

  it( 'should call disableBackgroundElements when afterOpenModal is invoked', () => {
    let divElement = document.createElement( 'div' );
    divElement.className = 'SignInModal';
    document.body.appendChild( divElement );
    const signInModalElement = document.getElementsByClassName( 'SignInModal' )[0];

    const component = mountWithIntl(
      <Provider store={ store }>
        <SignInModal { ...props }/>
      </Provider>
    );
    const instance = component.find( 'SignInModal' ).instance();
    instance.afterOpenModal();

    expect( disableBackgroundElements ).toHaveBeenCalledWith( [signInModalElement] );
  } );

  it( 'should call enableBackgroundElements on componentWillUnmount', () => {
    let component = mountWithIntl(
      <Provider store={ store }>
        <SignInModal { ...props }/>
      </Provider>
    );
    let node = component.find( 'SignInModal' ).instance();
    node.componentWillUnmount();
    expect( enableBackgroundElements ).toHaveBeenCalled( );
  } );

} );
