/**
* SocialIcon
*/

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './SocialIcon.css';
import Anchor from '../Anchor/Anchor';
import facebookSVG from '../Icons/facebook_icon';
import instagramSVG from '../Icons/instagram_icon';
import pinterestSVG from '../Icons/pinterest_icon';
import twitterSVG from '../Icons/twitter_icon';
import youtubeSVG from '../Icons/youtube_icon';
import { formatOmnitureAttr } from '../../utils/omniture/omniture';
import messages from './SocialIcon.messages';
import { formatMessage } from '../Global/Global';

const propTypes = {
  type: PropTypes.string.isRequired,
  preloadSrc: PropTypes.string,
  lazyLoad: PropTypes.bool
}

const defaultProps = {
  preloadSrc: '',
  lazyLoad: true
}

/**
* Class
 * @extends React.Component
*/
class SocialIcon extends Component{

  /**
   * Create a SocialIcon
   */
  constructor( props ){
    super( props );

    this.getSocialIcon = this.getSocialIcon.bind( this );
  }

  getSocialIcon( type ){

    let icon = {
      url: undefined,
      src: undefined,
      alt: undefined,
      omniture: undefined
    };
    switch ( type.toLowerCase() ){
      case 'facebook':
        icon.svg = facebookSVG;
        icon.url = '//facebook.com/UltaBeauty/';
        icon.alt = 'facebook';
        icon.title = formatMessage( messages.FacebookTitle )
        break;
      case 'pinterest':
        icon.svg = pinterestSVG;
        icon.url = '//pinterest.com/follow/ultabeauty/';
        icon.alt = 'pinterest'
        icon.title = formatMessage( messages.PinterestTitle )
        break;
      case 'twitter':
        icon.svg = twitterSVG;
        icon.url = '//twitter.com/ultabeauty';
        icon.alt = 'twitter'
        icon.title = formatMessage( messages.TwitterTitle )
        break;
      case 'instagram':
        icon.svg = instagramSVG;
        icon.url = '//instagram.com/ultabeauty/';
        icon.alt = 'instagram'
        icon.title = formatMessage( messages.InstagramTitle )
        break;
      case 'youtube':
        icon.svg = youtubeSVG;
        icon.url = '//youtube.com/user/ultabeauty';
        icon.alt = 'youtube'
        icon.title = formatMessage( messages.YoutubeTitle )
        break;
    }

    icon.omniture = formatOmnitureAttr( 'f', icon.alt );

    return icon;
  }

  /**
   * Renders the SocialIcon component
   */
  render(){
    const {
      type
    } = this.props;

    let icon = this.getSocialIcon( type );
    let Svg = icon.svg;


    return (
      <span className='SocialIcon'>
        <Anchor
          url={ icon.url }
          dataNavDescription={ icon.omniture }
          target='_self'
          title={ icon.title }
        >
          <Svg description={ icon.title } />
        </Anchor>
      </span>
    );
  }
}

SocialIcon.propTypes = propTypes;
SocialIcon.defaultProps = defaultProps;

export default SocialIcon;
