/*
 * SocialIcon Messages
 *
 * This contains all the text for the SocialIcon component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  FacebookTitle: {
    id: 'i18n.SocialIcon.FacebookTitle',
    defaultMessage: 'Ulta Beauty on Facebook'
  },
  TwitterTitle: {
    id: 'i18n.SocialIcon.TwitterTitle',
    defaultMessage: 'Ulta Beauty on Twitter'
  },
  InstagramTitle: {
    id: 'i18n.SocialIcon.InstagramTitle',
    defaultMessage: 'Ulta Beauty on Instagram'
  },
  PinterestTitle: {
    id: 'i18n.SocialIcon.PinterestTitle',
    defaultMessage: 'Ulta Beauty on Pinterest'
  },
  YoutubeTitle: {
    id: 'i18n.SocialIcon.YoutubeTitle',
    defaultMessage: 'Ulta Beauty on Youtube'
  }


} );
