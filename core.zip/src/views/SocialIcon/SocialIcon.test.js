import React from 'react';
import ReactDOM from 'react-dom';
import { shallow } from 'enzyme';
import { intlProvider } from 'react-intl';
import _ from 'lodash';
import SocialIcon from './SocialIcon';
import facebookSVG from '../Icons/facebook_icon';
import pinterestSVG from '../Icons/pinterest_icon';
import twitterSVG from '../Icons/twitter_icon';
import instagramSVG from '../Icons/instagram_icon';
import youtubeSVG from '../Icons/youtube_icon';
// import { shallowToJson } from 'enzyme-to-json';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';


describe( '<SocialIcon />', () => {

  let component;

  it( 'renders without crashing', () => {
    expect( component.find( 'SocialIcon' ).length ).toBe( 1 );
  } );

  describe( 'Facebook config', () => {
    component = mountWithIntl( <SocialIcon type='facebook' /> );

    it( 'should set the proper url value', () => {
      expect( component.find( 'Anchor' ).at( 0 ).props().url ).toEqual( '//facebook.com/UltaBeauty/' );
    } );

    it( 'should contain a class method called \'getSocialIcon\'', () => {
      expect( _.isFunction( component.instance().getSocialIcon ) ).toBe( true );
    } );

    it( 'should return the proper icon data when passing facebook', () => {

      let expectedResult = {
        svg: facebookSVG,
        url: '//facebook.com/UltaBeauty/',
        alt: 'facebook',
        title: 'Ulta Beauty on Facebook',
        omniture: 'f - facebook'
      };
      expect( returnIconData( component, 'facebook' ) ).toEqual( expectedResult );

    } );

    it( 'should open in the same window', () => {
      expect( component.find( 'Anchor' ).at( 0 ).props().target ).toBe( '_self' )
    } );
  } );

  describe( 'pinterest config', () => {

    let component = mountWithIntl( <SocialIcon type='pinterest' /> );

    it( 'should set the proper url value', () => {
      expect( component.find( 'Anchor' ).at( 0 ).props().url ).toEqual( '//pinterest.com/follow/ultabeauty/' );
    } );

    it( 'should contain a class method called \'getSocialIcon\'', () => {
      expect( _.isFunction( component.instance().getSocialIcon ) ).toBe( true );
    } );

    it( 'should return the proper icon data when passing pinterest', () => {

      let expectedResult = {
        svg: pinterestSVG,
        url: '//pinterest.com/follow/ultabeauty/',
        alt: 'pinterest',
        title: 'Ulta Beauty on Pinterest',
        omniture: 'f - pinterest'
      };

      expect( returnIconData( component, 'pinterest' ) ).toEqual( expectedResult );

    } );

    it( 'should open in the same window', () => {
      expect( component.find( 'Anchor' ).at( 0 ).props().target ).toBe( '_self' )
    } );
  } );

  describe( 'Twitter config', () => {

    let component = mountWithIntl( <SocialIcon type='twitter' /> );

    it( 'should set the proper url value', () => {
      expect( component.find( 'Anchor' ).at( 0 ).props().url ).toEqual( '//twitter.com/ultabeauty' );
    } );

    it( 'should contain a class method called \'getSocialIcon\'', () => {
      expect( _.isFunction( component.instance().getSocialIcon ) ).toBe( true );
    } );

    it( 'should return the proper icon data when passing twitter', () => {

      let expectedResult = {
        svg: twitterSVG,
        url: '//twitter.com/ultabeauty',
        alt: 'twitter',
        title: 'Ulta Beauty on Twitter',
        omniture: 'f - twitter'
      };
      expect( returnIconData( component, 'twitter' ) ).toEqual( expectedResult );

    } );

    it( 'should open in the same window', () => {
      expect( component.find( 'Anchor' ).at( 0 ).props().target ).toBe( '_self' )
    } );
  } );


  describe( 'instagram config', () => {

    let component = mountWithIntl( <SocialIcon type='instagram' /> );

    it( 'should set the proper url value', () => {
      expect( component.find( 'Anchor' ).at( 0 ).props().url ).toEqual( '//instagram.com/ultabeauty/' );
    } );

    it( 'should contain a class method called \'getSocialIcon\'', () => {
      expect( _.isFunction( component.instance().getSocialIcon ) ).toBe( true );
    } );

    it( 'should return the proper icon data when passing instagram', () => {

      let expectedResult = {
        svg: instagramSVG,
        url: '//instagram.com/ultabeauty/',
        alt: 'instagram',
        title: 'Ulta Beauty on Instagram',
        omniture: 'f - instagram'
      };
      expect( returnIconData( component, 'instagram' ) ).toEqual( expectedResult );

    } );

    it( 'should open in the same window', () => {
      expect( component.find( 'Anchor' ).at( 0 ).props().target ).toBe( '_self' )
    } );
  } );

  describe( 'Youtube config', () => {

    let component = mountWithIntl( <SocialIcon type='youtube' /> );

    it( 'should set the proper url value', () => {
      expect( component.find( 'Anchor' ).at( 0 ).props().url ).toEqual( '//youtube.com/user/ultabeauty' );
    } );

    it( 'should contain a class method called \'getSocialIcon\'', () => {
      expect( _.isFunction( component.find( 'SocialIcon' ).instance().getSocialIcon ) ).toBe( true );
    } );

    it( 'should return the proper icon data when passing youtube', () => {

      let expectedResult = {
        svg: youtubeSVG,
        url: '//youtube.com/user/ultabeauty',
        alt: 'youtube',
        title: 'Ulta Beauty on Youtube',
        omniture: 'f - youtube'
      };
      expect( returnIconData( component, 'youtube' ) ).toEqual( expectedResult );

    } );

    it( 'should open in the same window', () => {
      expect( component.find( 'Anchor' ).props().target ).toBe( '_self' )
    } );
  } );
} );

function returnIconData( component, type ){
  let iconData  = component.instance().getSocialIcon( type );
  return iconData;
}
