import React from 'react';
import PropTypes from 'prop-types';
import './Text.css';
import classNames from 'classnames';

const Text = ( {
  children,
  fontWeight,
  colorOverride,
  fontStyle,
  textDecoration,
  lineHeight = 'small',
  type = 'body-2',
  htmlTag = 'p',
  textAlign = 'left'
} ) => {
  const Tag = htmlTag;
  return (
    <Tag className={ classNames( `Text Text--${type}`, {
      ...( textAlign && { [`Text--${ textAlign}`]: textAlign } ),
      ...( fontWeight && { [`Text--${ fontWeight}`]: fontWeight } ),
      ...( lineHeight && { [`Text--${ lineHeight }`]: lineHeight } ),
      ...( colorOverride && { [`Text--${ colorOverride }`]: colorOverride } ),
      ...( fontStyle && { [`Text--${ fontStyle }`]: fontStyle } ),
      ...( textDecoration && { [`Text--${ textDecoration }`]: textDecoration } )
    } ) }
    >
      { children }
    </Tag>
  );
};
Text.propTypes = {
  type: PropTypes.oneOf( [
    'legal',
    'caption',
    'body-2',
    'body-1',
    'subtitle-2',
    'subtitle-1',
    'title-1',
    'title-2',
    'title-3',
    'title-4',
    'title-5',
    'title-6'
  ] ),
  htmlTag: PropTypes.oneOf( [
    'p',
    'span',
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6'
  ] ),
  fontWeight: PropTypes.oneOf( [
    'bold',
    'light'
  ] ),
  lineHeight: PropTypes.oneOf( [
    'small',
    'large'
  ] ),
  textAlign: PropTypes.oneOf( [
    'left',
    'center',
    'right'
  ] )
};
export default Text;
