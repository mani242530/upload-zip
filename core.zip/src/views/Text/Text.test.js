import React from 'react';
import ReactDOM from 'react-dom';
import Text from './Text';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<Text /> ', () => {
  it( 'renders without crashing', () => {
    const div = document.createElement( 'div' );
    ReactDOM.render( <Text />, div );
  } );
  it( 'should render the component with the class .legal when legal is passed as the type', () => {
    let component = mountWithIntl( <Text type='legal'/> );
    expect( component.find( 'Text' ).props().type ).toBe( 'legal' );
    expect( component.find( '.Text--legal' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .caption when caption is passed as the type', () => {
    let component = mountWithIntl( <Text type='caption' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'caption' );
    expect( component.find( '.Text--caption' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .body-1 when body-1 is passed as the type', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'body-1' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( '.Text--body-1' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .body-2 when body-2 is passed as the type', () => {
    let component = mountWithIntl( <Text type='body-2' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'body-2' );
    expect( component.find( '.Text--body-2' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .subtitle-1 when subtitle-1 is passed as the type', () => {
    let component = mountWithIntl( <Text type='subtitle-1' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'subtitle-1' );
    expect( component.find( '.Text--subtitle-1' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .subtitle-2 when subtitle-2 is passed as the type', () => {
    let component = mountWithIntl( <Text type='subtitle-2' htmlTag='span' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'subtitle-2' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( '.Text--subtitle-2' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .subtitle-2 with fontWeight bold when subtitle-2 is passed as the type and bold as fontWeight', () => {
    let component = mountWithIntl( <Text type='subtitle-2' htmlTag='span' fontWeight='bold' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'subtitle-2' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( 'Text' ).props().fontWeight ).toBe( 'bold' );
    expect( component.find( '.Text--bold' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .subtitle-2 with fontWeight light when subtitle-2 is passed as the type and light as fontWeight', () => {
    let component = mountWithIntl( <Text type='subtitle-2' htmlTag='span' fontWeight='light' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'subtitle-2' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( 'Text' ).props().fontWeight ).toBe( 'light' );
    expect( component.find( '.Text--light' ).length ).toBe( 1 );
  } );

  it( 'should render the component with the class .subtitle-2 when subtitle-2 is passed as the type', () => {
    let component = mountWithIntl( <Text type='subtitle-2' htmlTag='span' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'subtitle-2' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( '.Text--subtitle-2' ).length ).toBe( 1 );
  } );

  it( 'should render the component with the class .title-1 when title-1 is passed as the type', () => {
    let component = mountWithIntl( <Text type='title-1' htmlTag='span' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'title-1' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( '.Text--title-1' ).length ).toBe( 1 );
  } );

  it( 'should render the component with the class .title-2 when title-2 is passed as the type', () => {
    let component = mountWithIntl( <Text type='title-2' htmlTag='span' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'title-2' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( '.Text--title-2' ).length ).toBe( 1 );
  } );

  it( 'should render the component with the class .title-3 when title-3 is passed as the type', () => {
    let component = mountWithIntl( <Text type='title-3' htmlTag='span' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'title-3' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( '.Text--title-3' ).length ).toBe( 1 );
  } );

  it( 'should render the component with the class .title-4 when title-4 is passed as the type', () => {
    let component = mountWithIntl( <Text type='title-4' htmlTag='span' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'title-4' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( '.Text--title-4' ).length ).toBe( 1 );
  } );

  it( 'should render the component with the class .title-5 when title-5 is passed as the type', () => {
    let component = mountWithIntl( <Text type='title-5' htmlTag='span' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'title-5' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( '.Text--title-5' ).length ).toBe( 1 );
  } );

  it( 'should render the component with the class .title-6 when title-6 is passed as the type', () => {
    let component = mountWithIntl( <Text type='title-6' htmlTag='span' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'title-6' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( '.Text--title-6' ).length ).toBe( 1 );
  } );

  it( 'should render the component with a default line height', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' fontWeight='light' /> );
    expect( component.find( 'Text' ).props().type ).toBe( 'body-1' );
    expect( component.find( 'Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( 'Text' ).props().fontWeight ).toBe( 'light' );
    expect( component.find( '.Text--small' ).length ).toBe( 1 );
  } );

  it( 'should render the component with the correct line height', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' fontWeight='light' lineHeight='large' /> );
    expect( component.find( '.Text--large' ).length ).toBe( 1 );
    expect( component.find( '.Text--left' ).length ).toBe( 1 );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'fontWeight': 'light', 'htmlTag': 'span', 'lineHeight': 'large', 'type': 'body-1'
    } );
  } );

  it( 'should render the component with the correct line height', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' fontWeight='light' lineHeight='large' textAlign='center' /> );
    expect( component.find( '.Text--large' ).length ).toBe( 1 );
    expect( component.find( '.Text--center' ).length ).toBe( 1 );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'fontWeight': 'light', 'htmlTag': 'span', 'lineHeight': 'large', 'textAlign': 'center', 'type': 'body-1'
    } );
  } );

  it( 'should render the component with the correct line height', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' fontWeight='light' lineHeight='large' textAlign='right' /> );
    expect( component.find( '.Text--large' ).length ).toBe( 1 );
    expect( component.find( '.Text--right' ).length ).toBe( 1 );
    expect( component.find( '.Text--neutral-40' ).length ).toBe( 0 );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'fontWeight': 'light', 'htmlTag': 'span', 'lineHeight': 'large', 'textAlign': 'right', 'type': 'body-1'
    } );
  } );

  it( 'should render the component with the correct line height', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' fontWeight='light' lineHeight='large' textAlign='right' colorOverride='neutral-40' /> );
    expect( component.find( '.Text--large' ).length ).toBe( 1 );
    expect( component.find( '.Text--right' ).length ).toBe( 1 );
    expect( component.find( '.Text--neutral-40' ).length ).toBe( 1 );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'colorOverride': 'neutral-40', 'fontWeight': 'light', 'htmlTag': 'span', 'lineHeight': 'large', 'textAlign': 'right', 'type': 'body-1'
    } );
  } );
  it( 'should render the component with the correct color ', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' fontWeight='light' lineHeight='large' textAlign='right' colorOverride='neutral-30' /> );

    expect( component.find( '.Text--neutral-30' ).length ).toBe( 1 );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'colorOverride': 'neutral-30', 'fontWeight': 'light', 'htmlTag': 'span', 'lineHeight': 'large', 'textAlign': 'right', 'type': 'body-1'
    } );
  } );
  it( 'should render the component with the correct color ', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' fontWeight='light' lineHeight='large' textAlign='right' colorOverride='neutral-70' /> );

    expect( component.find( '.Text--neutral-70' ).length ).toBe( 1 );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'colorOverride': 'neutral-70', 'fontWeight': 'light', 'htmlTag': 'span', 'lineHeight': 'large', 'textAlign': 'right', 'type': 'body-1'
    } );
  } );
  it( 'should render the component with the correct color ', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' fontWeight='light' lineHeight='large' textAlign='right' colorOverride='neutral-50' /> );

    expect( component.find( '.Text--neutral-50' ).length ).toBe( 1 );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'colorOverride': 'neutral-50', 'fontWeight': 'light', 'htmlTag': 'span', 'lineHeight': 'large', 'textAlign': 'right', 'type': 'body-1'
    } );
  } );

  it( 'should render the component with the correct color ', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' fontWeight='light' lineHeight='large' textAlign='right' colorOverride='plum-70' /> );
    expect( component.find( '.Text--plum-70' ).length ).toBe( 1 );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'colorOverride': 'plum-70', 'fontWeight': 'light', 'htmlTag': 'span', 'lineHeight': 'large', 'textAlign': 'right', 'type': 'body-1'
    } );
  } );

  it( 'should render the component with the correct color ', () => {
    let component = mountWithIntl( <Text type='body-1' htmlTag='span' fontWeight='light' lineHeight='large' textAlign='right' colorOverride='text-20' /> );
    expect( component.find( '.Text--text-20' ).length ).toBe( 1 );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'colorOverride': 'text-20', 'fontWeight': 'light', 'htmlTag': 'span', 'lineHeight': 'large', 'textAlign': 'right', 'type': 'body-1'
    } );
  } );
  it( 'should render the component with the class .legal with fontStyle italic when legal is passed as the type and italic as fontStyle', () => {
    let component = mountWithIntl( <Text type='subtitle-2' htmlTag='span' fontStyle='italic' /> );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'fontStyle': 'italic', 'htmlTag': 'span', 'type': 'subtitle-2'
    } );
  } );
  it( 'should render the component with the class .legal with textDecoration underline when legal is passed as the type and underline as textDecoration', () => {
    let component = mountWithIntl( <Text type='subtitle-2' htmlTag='span' textDecoration='underline' /> );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'textDecoration': 'underline', 'htmlTag': 'span', 'type': 'subtitle-2'
    } );
  } );

  it( 'should render the heading tag when h1 is passed in', () => {
    let component = mountWithIntl( <Text type='title-1' htmlTag='H1' fontWeight='light' lineHeight='large' /> );
    expect( component.find( 'Text' ).props() ).toEqual( {
      'fontWeight': 'light', 'htmlTag': 'H1', 'lineHeight': 'large', 'type': 'title-1'
    } );
  } );



} );
