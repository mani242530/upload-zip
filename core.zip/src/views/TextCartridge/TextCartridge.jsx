import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './TextCartridge.css';
import Image from '../Image/Image';
import Anchor from '../Anchor/Anchor';

const propTypes = {
  marginTop: PropTypes.string,
  marginBottom: PropTypes.string,
  headlineTag: PropTypes.string,
  headlineText: PropTypes.string,
  headlineColor: PropTypes.string,
  headlineLink: PropTypes.string,
  headlineLinkTarget: PropTypes.string,
  sectionTag: PropTypes.string,
  sectionHeadingText: PropTypes.string,
  sectionHeadingImageUri: PropTypes.string,
  sectionHeadingImageAltText: PropTypes.string,
  sectionHeadingLink: PropTypes.string,
  sectionHeadingLinkTarget: PropTypes.string,
  subHeading: PropTypes.string,
  subHeadingLink: PropTypes.string,
  subHeadingLinkTarget: PropTypes.string,
  shortHR: PropTypes.bool,
  hrColor: PropTypes.string,
  subAndCalloutTextColor: PropTypes.string,
  calloutText: PropTypes.string,
  subTag: PropTypes.string,
  subText: PropTypes.string,
  subTextSize: PropTypes.string,
  subTextColor: PropTypes.string
};

/** Class for Mobile Text Cartridge / TextCartridge */
class TextCartridge extends Component{
  /**
    * because this is a subclass, we must call super to initialize this and must pass props to super to
    * be able to access this.props - http://cheng.logdown.com/posts/2016/03/26/683329
    */
  constructor( props ){
    super( props );

    this.renderTextSection = this.renderTextSection.bind( this );
  }

  /**
    * takes an object 'htmlProperties' and returns either an Image component
    * or html to display the specific text element
    */
  renderHtml( htmlProperties, DynamicTag ){

    if( typeof( htmlProperties.html ) === 'object' ){
      return (
        <Image
          src={ htmlProperties.html.url }
          alt={ htmlProperties.html.alt }
        />
      )
    }
    else {
      return (
        <div>
          <DynamicTag
            style={ htmlProperties.style }
            className={ htmlProperties.extraClasses }
            dangerouslySetInnerHTML={ { __html: htmlProperties.html } }
          >
          </DynamicTag>
          { htmlProperties.textSectionType === 'headlineText' && htmlProperties.shortHR === true ? <hr className={ htmlProperties.hrClasses } /> : null }
        </div>
      )
    }
  }

  /**
    * sets the header element tag dynamically and injects the appropriate html
    * into the element and returns element to be rendered
    */
  renderTextSection( textSectionType ){

    let DynamicTag;
    let html;
    let style;
    // we must use two different variables for classes as 'headlineText' applies
    // extra classes to two different elements
    let hrClasses;
    let extraClasses;
    let url;
    let target;

    // sets dynamic className for the DynamicTag wrapper <div> and the 'wrapperClassName' variable
    // allows for reuse in setting BEM compliant dynamic className for hrClasses and extraClasses
    const wrapperClassName = `TextCartridge__${textSectionType}`;

    switch ( textSectionType ){

      case 'headlineText':

        html = `${this.props.headlineText}`;
        DynamicTag = this.props.headlineTag ? `${this.props.headlineTag}` : 'p';
        extraClasses = `${wrapperClassName}__heading--${this.props.headlineColor}`;
        hrClasses = `${wrapperClassName}__hr--${this.props.hrColor}`;
        url = this.props.headlineLink;
        target = this.props.headlineLinkTarget;
        break;

      case 'sectionHeading':

        if( this.props.sectionHeadingText ){

          html = this.props.sectionHeadingText
          DynamicTag = this.props.sectionTag ? this.props.sectionTag : 'p';
          url = this.props.sectionHeadingLink;
          target = this.props.sectionHeadingLinkTarget;

        }
        else if( this.props.sectionHeadingImageUri ){

          url = this.props.sectionHeadingLink;
          target = this.props.sectionHeadingLinkTarget;
          html = {
            url: this.props.sectionHeadingImageUri,
            alt: this.props.sectionHeadingImageAltText || ''
          }
          DynamicTag = 'div';

        }
        break;

      case 'subHeading':

        html = this.props.subHeading;
        DynamicTag = 'p';
        url = this.props.subHeadingLink;
        target = this.props.subHeadingLinkTarget;

        break;

      case 'calloutText':

        html = this.props.calloutText;
        DynamicTag = 'p';
        extraClasses = `${wrapperClassName}__heading ${this.props.subAndCalloutTextColor}`;

        break;

      case 'subText':

        html = this.props.subText
        style = {
          fontSize: this.props.subTextSize ? this.props.subTextSize : null,
          lineHeight: this.props.subTextSize === '14px' ? '18px' : '20px'
        };
        DynamicTag = this.props.subTag ? this.props.subTag : 'p';
        extraClasses = `${wrapperClassName}__heading--${this.props.subAndCalloutTextColor}`;

        break;

      default:
        break;

    }

    let htmlProperties = {
      style,
      extraClasses,
      html,
      // url: html.url,
      // alt: html.alt || 'hello',
      textSectionType,
      shortHR: this.props.shortHR,
      hrClasses
    }

    if( url ){

      return (
        <div className={ wrapperClassName } >
          <Anchor
            url={ url }
            target={ target }
          >
            { this.renderHtml( htmlProperties, DynamicTag ) }
          </Anchor>
        </div>
      )

    }
    else {

      return (
        <div className={ wrapperClassName } >
          { this.renderHtml( htmlProperties, DynamicTag ) }
        </div>
      )

    }
  }

  render(){

    let marginTop = undefined;
    let marginBottom = undefined;

    if( this.props.marginTop ){
      marginTop = this.props.marginTop
    }

    if( this.props.marginBottom ){
      marginBottom = this.props.marginBottom
    }

    let style = {
      marginTop: marginTop,
      marginBottom: marginBottom
    };

    return (
      <div className='TextCartridge' style={ style } >

        { this.props.headlineText && this.renderTextSection( 'headlineText' ) }

        { ( this.props.sectionHeadingText || this.props.sectionHeadingImageUri ) && this.renderTextSection( 'sectionHeading' ) }

        { this.props.subHeading && this.renderTextSection( 'subHeading' ) }

        { this.props.calloutText && this.renderTextSection( 'calloutText' ) }

        { this.props.subText && this.renderTextSection( 'subText' ) }

      </div>
    );
  }
}

TextCartridge.propTypes = propTypes;

export default TextCartridge;
