import React from 'react';
import ReactDOM from 'react-dom';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer'
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
import TextCartridge from './TextCartridge';

describe( '<TextCartridge /> ', () => {
  it( 'renders without crashing', () => {
    const div = document.createElement( 'div' );
    ReactDOM.render( <TextCartridge>Hello</TextCartridge>, div );
  } );

  it( 'should render all 5 sections in the proper order when passed props for all 5', () => {
    let component = shallow( <TextCartridge headlineText='This is' sectionHeadingText='up sentence' subHeading='to prove this works.' calloutText="yep, it's really broken now" subText='a broken' /> );
    let children = component.at( 0 ).props().children;
    expect( children[0].props.className ).toBe( 'TextCartridge__headlineText' );
    expect( children[1].props.className ).toBe( 'TextCartridge__sectionHeading' );
    expect( children[2].props.className ).toBe( 'TextCartridge__subHeading' );
    expect( children[3].props.className ).toBe( 'TextCartridge__calloutText' );
    expect( children[4].props.className ).toBe( 'TextCartridge__subText' );
  } );

  it( 'should render all 5 sections in the proper order when passed props for all 5', () => {
    const component = renderer.create(
      <TextCartridge headlineText='This is' sectionHeadingText='up sentence' subHeading='to prove this works.' calloutText="yep, it's really broken now" subText='a broken' />
    );
    expect( component ).toMatchSnapshot();
  } );

  it( 'should call the renderTextSection method if headlineText is passed as a prop', () => {
    let component = shallow( <TextCartridge headlineText='This is' sectionHeadingText='up sentence' subHeading='to prove this works.' calloutText="yep, it's really broken now" subText='a broken' /> );
    let inst = component.instance();
    inst.renderTextSection = jest.fn();
    inst.render();
    expect( inst.renderTextSection ).toHaveBeenCalled();
  } );

  describe( 'top and bottom margin', () => {
    it( 'should set a default top margin and bottom margin of undefined when no margins are passed in props', () => {
      let component = shallow( <TextCartridge headlineText='this is' /> );
      let marginTop = component.props().style.marginTop;
      let marginBottom = component.at( 0 ).props().style.marginBottom;
      expect( marginTop ).toBe( undefined );
      expect( marginBottom ).toBe( undefined );
    } );

    it( 'should set top margin of 16px and bottom margin of 48px when appropriate margins are passed in props', () => {
      let component = shallow( <TextCartridge headlineText='this is' marginTop='16px' marginBottom='48px' /> );
      let marginTop = component.props().style.marginTop;
      let marginBottom = component.props().style.marginBottom;
      expect( marginTop ).toBe( '16px' );
      expect( marginBottom ).toBe( '48px' );
    } );
  } );

  describe( 'headlineText', () => {
    it( 'should render only headlineText elements when only headlineText is present', () => {
      let component = shallow( <TextCartridge headlineTag='h3' headlineText='hello again' /> );
      let children = component.props().children;
      expect( children[0].props.className ).toBe( 'TextCartridge__headlineText' );
    } );

    it( 'should render headlineText in <p> if headlineTag is not present', () => {
      let component = shallow( <TextCartridge headlineText='hello' /> );
      let children = component.props().children;
      expect( children[0].props.children.props.children[0].type ).toBe( 'p' );
    } );

    it( 'should add the appropriate className to set background-color to "orange-pop"', () => {
      let component = shallow( <TextCartridge shortHR={ true } headlineColor='orangepop' headlineText='hello' /> );
      let element = component.find( '.TextCartridge__headlineText__heading--orangepop' )
      expect( element.type() ).toBe( 'p' );
      expect( element.length ).toBe( 1 );
    } );
  } );

  describe( 'sectionHeading', () => {
    it( 'should render only sectionHeading elements when only sectionHeadingText is present', () => {
      let component = shallow( <TextCartridge sectionTag='h5' sectionHeadingText='hello again' /> );
      let children = component.props().children;
      expect( children[1].props.className ).toBe( 'TextCartridge__sectionHeading' );
    } );

    it( 'should render only sectionHeading elements when only sectionHeadingImageUri is present', () => {
      let component = shallow( <TextCartridge sectionTag='h5' sectionHeadingImageUri='http://images.ulta.com/is/image/Ulta/mktg_small1_101616' /> );
      let children = component.props().children;
      let tag = children[1].type;
      expect( tag ).toBe( 'div' );
    } );

    it( 'should render image inside a <div> tag when sectionHeadingImageUri is passed in props', () => {
      let component = shallow( <TextCartridge sectionTag='h5' sectionHeadingImageUri='theMix_section_header' /> );
      let children = component.props().children;
      let tag = children[1].type
      expect( tag ).toBe( 'div' );
    } );

    it( 'should add alt text to <img> when sectionHeadingImageAltText is passed in props', () => {
      let component = shallow( <TextCartridge sectionTag='h5' sectionHeadingImageAltText='this is alt text' sectionHeadingImageUri='theMix_section_header' /> );
      let children = component.props().children;
      let actualAltText = children[1].props.children.props.alt
      expect( actualAltText ).toMatch( /this is alt text/ );
    } );

    it( 'should render sectionHeading in <p> if sectionTag is not present', () => {
      let component = shallow( <TextCartridge sectionHeadingText='hello again' /> );
      let children = component.props().children;
      expect( children[1].props.children.props.children[0].type ).toBe( 'p' );
    } );
  } );

  describe( 'subHeading', () => {
    it( 'should render only subHeading elements when only subHeading is present', () => {
      let component = shallow( <TextCartridge subHeading='hello again' /> );
      let children = component.props().children;
      expect( children[2].props.className ).toBe( 'TextCartridge__subHeading' );
    } );
  } );

  describe( 'shortHR', () => {
    it( 'should not render shortHR when shortHR is not passed', () => {
      let component = shallow( <TextCartridge headlineText='hello' /> );
      let children = component.props().children;
      let element = children[0].props.children[1];
      expect( element ).toBe( undefined );
    } );

    it( 'should not render shortHR when shortHR is false', () => {
      let component = shallow( <TextCartridge shortHR={ false } headlineText='hello' /> );
      let children = component.props().children;
      let element = children[0].props.children[1];
      expect( element ).toBe( undefined );
    } );

    it( 'should render shortHR when shortHR is true', () => {
      let component = shallow( <TextCartridge shortHR={ true } headlineText='hello' /> );
      let children = component.props().children;
      let element = children[0].props.children.props.children[1].type;
      expect( element ).toBe( 'hr' );
    } );

    it( 'should add the appropriate className to set background-color to "flirting-with-fire"', () => {
      let component = shallow( <TextCartridge shortHR={ true } hrColor='flirtingwithfire' headlineText='hello' /> );
      let children = component.props().children;
      let element = children[0].props.children;
      expect( element.props.children[1].type ).toBe( 'hr' );
      expect( element.props.children[1].props.className ).toBe( 'TextCartridge__headlineText__hr--flirtingwithfire' );
    } );
  } );

  describe( 'calloutText', () => {
    it( 'should render only calloutText elements when only calloutText is present', () => {
      let component = shallow( <TextCartridge calloutText='hello again' /> );
      let children = component.props().children;
      expect( children[3].props.className ).toBe( 'TextCartridge__calloutText' );
    } );

    it( 'should render calloutText in <p>', () => {
      let component = shallow( <TextCartridge calloutText='hello again' /> );
      let children = component.props().children;
      expect( children[3].props.children.props.children[0].type ).toBe( 'p' );
    } );

    it( 'should add the appropriate className to set color to "digitalgray"', () => {
      let component = shallow( <TextCartridge subAndCalloutTextColor='digitalgray' calloutText='hello again' /> );
      let children = component.props().children;
      let calloutTextHeaderTag = children[3].props.children.props.children[0];
      let actualclassName = calloutTextHeaderTag.props.className
      expect( actualclassName ).toBe( 'TextCartridge__calloutText__heading digitalgray' );
    } );
  } );

  describe( 'subText', () => {
    it( 'should render only subText elements when only subText is present', () => {
      let component = shallow( <TextCartridge subTag='h3' subText='hello again' /> );
      let children = component.props().children;
      expect( children[4].props.className ).toBe( 'TextCartridge__subText' );
    } );

    it( 'should render subText in <p> if subTag is not present', () => {
      let component = shallow( <TextCartridge subText='hello again' /> );
      let children = component.props().children;
      expect( children[4].props.children.props.children[0].type ).toBe( 'p' );
    } );

    it( 'should render subText with font-size of 38px if subTextSize of 38px is passed through props', () => {
      let component = shallow( <TextCartridge subText='hello again' subTextSize='38px' /> );
      let children = component.props().children;
      let subTextHeaderTag = children[4].props.children.props.children[0];
      let actualStyle = subTextHeaderTag.props.style.fontSize
      expect( actualStyle ).toBe( '38px' );
    } );

    it( 'should render lineHeight of 18px if subTextSize is 14px is passed through props', () => {
      let component = shallow( <TextCartridge subText='hello again' subTextSize='14px' /> );
      let children = component.props().children;
      let subTextHeaderTag = children[4].props.children.props.children[0];
      let actualStyle = subTextHeaderTag.props.style.lineHeight;
      expect( actualStyle ).toBe( '18px' );
    } );

    it( 'should render lineHeight of 20px if subTextSize is 16px is passed through props', () => {
      let component = shallow( <TextCartridge subText='hello again' subTextSize='16px' /> );
      let children = component.props().children;
      let subTextHeaderTag = children[4].props.children.props.children[0];
      let actualStyle = subTextHeaderTag.props.style.lineHeight;
      expect( actualStyle ).toBe( '20px' );
    } );

    it( 'should add the appropriate className to set color to "digitalgray"', () => {
      let component = shallow( <TextCartridge subAndCalloutTextColor='digitalgray' subText='hello again' /> );
      let children = component.props().children;
      let calloutTextHeaderTag = children[4].props.children.props.children[0];
      let actualclassName = calloutTextHeaderTag.props.className
      expect( actualclassName ).toBe( 'TextCartridge__subText__heading--digitalgray' );
    } );
  } );
} );
