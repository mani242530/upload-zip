/**
 * ThreeColumn
 */

import React from 'react';
import PropTypes from 'prop-types';
import './ThreeColumn.css';
import Divider from '../Divider/Divider';


const propTypes = {
  split: PropTypes.string,
  columnOne: PropTypes.object,
  columnTwo: PropTypes.object,
  columnThree: PropTypes.object
}

const defaultProps = {
  split: 'oneThird|oneThird|oneThird'
}

const ThreeColumn = ( props ) => {

  const {
    columnOne,
    columnTwo,
    columnThree
  } = props;

  return (
    <div className='ThreeColumn'>
      <div className='ThreeColumn__columnOne'>
        { columnOne }
      </div>

      <Divider dividerType='gray' />

      <div className='ThreeColumn__columnTwo'>
        { columnTwo }
      </div>

      <Divider dividerType='gray' />

      <div className='ThreeColumn__columnThree'>
        { columnThree }
      </div>
    </div>
  );
}

ThreeColumn.propTypes = propTypes;
ThreeColumn.defaultProps = defaultProps;

export default ThreeColumn;
