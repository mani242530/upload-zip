import React from 'react';
import ReactDOM from 'react-dom';
import ThreeColumn from './ThreeColumn';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';

describe( '<ThreeColumn />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <ThreeColumn /> );
    expect( component.find( 'ThreeColumn' ).length ).toBe( 1 );
  } );
} );
