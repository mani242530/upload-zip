
import React from 'react';
import PropTypes from 'prop-types';
import './Title.css';
import classNames from 'classnames';

const Title = ( {
  children,
  fontWeight,
  type = 'title-1',
  htmlTag = 'h1',
  lineHeight = 'small'
} ) => {
  const Tag = htmlTag;
  return (
    <Tag className={ classNames( 'Title', {
      [`Title--${ type}`]: type,
      [`Title--${ fontWeight}`]: fontWeight,
      [`Title--${ lineHeight}`]: lineHeight
    } ) }
    >
      { children }
    </Tag>
  );
};
Title.propTypes = {
  type: PropTypes.oneOf( [
    'title-1',
    'title-2',
    'title-3',
    'title-4',
    'title-5',
    'title-6',
    'subtitle-1'
  ] ),
  htmlTag: PropTypes.oneOf( [
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6'
  ] ),
  fontWeight: PropTypes.oneOf( [
    'bold',
    'light'
  ] ),
  lineHeight: PropTypes.oneOf( [
    'small',
    'large'
  ] )
};
export default Title;