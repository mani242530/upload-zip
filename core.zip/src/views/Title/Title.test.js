import React from 'react';
import ReactDOM from 'react-dom';
import Title from './Title';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '<Title /> ', () => {
  it( 'renders without crashing', () => {
    const div = document.createElement( 'div' );
    ReactDOM.render( <Title />, div );
  } );
  it( 'should render the component with the class .Title--title-1 when title-1 is passed as the type', () => {
    let component = mountWithIntl( <Title type='title-1'/> );
    expect( component.find( 'Title' ).props().type ).toBe( 'title-1' );
    expect( component.find( '.Title--title-1' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .Title--title-2 when title-1 is passed as the type', () => {
    let component = mountWithIntl( <Title type='title-2' /> );
    expect( component.find( 'Title' ).props().type ).toBe( 'title-2' );
    expect( component.find( '.Title--title-2' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .Title--title-1 when title-1 is passed as the type', () => {
    let component = mountWithIntl( <Title type='title-1' htmlTag='h3' /> );
    expect( component.find( 'Title' ).props().type ).toBe( 'title-1' );
    expect( component.find( 'Title' ).props().htmlTag ).toBe( 'h3' );
    expect( component.find( '.Title--title-1' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .Title--title-3 when title-1 is passed as the type', () => {
    let component = mountWithIntl( <Title type='title-3' /> );
    expect( component.find( 'Title' ).props().type ).toBe( 'title-3' );
    expect( component.find( '.Title--title-3' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .Title--title-1 when title-1 is passed as the type', () => {
    let component = mountWithIntl( <Title type='title-1' /> );
    expect( component.find( 'Title' ).props().type ).toBe( 'title-1' );
    expect( component.find( '.Title--title-1' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .Title--title-1 when title-1 is passed as the type', () => {
    let component = mountWithIntl( <Title type='title-1' htmlTag='h1' /> );
    expect( component.find( 'Title' ).props().type ).toBe( 'title-1' );
    expect( component.find( 'Title' ).props().htmlTag ).toBe( 'h1' );
    expect( component.find( '.Title--title-1' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .Title--title-1 with fontWeight light when title-1 is passed as the type and light as fontWeight', () => {
    let component = mountWithIntl( <Title type='title-1' htmlTag='h1' fontWeight='light' /> );
    expect( component.find( 'Title' ).props().type ).toBe( 'title-1' );
    expect( component.find( 'Title' ).props().htmlTag ).toBe( 'h1' );
    expect( component.find( '.Title--light' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .Title--title-1 with fontWeight bold when .title-1 is passed as the type and bold as fontWeight', () => {
    let component = mountWithIntl( <Title type='title-1' htmlTag='h1' fontWeight='bold' /> );
    expect( component.find( 'Title' ).props().type ).toBe( 'title-1' );
    expect( component.find( 'Title' ).props().htmlTag ).toBe( 'h1' );
    expect( component.find( '.Title--bold' ).length ).toBe( 1 );
  } );
  it( 'should render the component with the class .Title--title-6 with lineHeight small and fontWeight bold, when title-6 is passed as the type and lineHeight as small, fontWeight as bold', () => {
    let component = mountWithIntl( <Title type='title-6' htmlTag='h3' lineHeight='small' fontWeight='bold'/> );
    expect( component.find( 'Title' ).props().type ).toBe( 'title-6' );
    expect( component.find( 'Title' ).props().htmlTag ).toBe( 'h3' );
    expect( component.find( '.Title--small' ).length ).toBe( 1 );
    expect( component.find( '.Title--bold' ).length ).toBe( 1 );
    expect( component.find( 'Title' ).props() ).toEqual( {
      'htmlTag': 'h3', 'lineHeight': 'small', 'type': 'title-6', 'fontWeight':'bold'
    } );
  } );
  it( 'should render the component with the class .Title--title-5 with lineHeight large and fontWeight light, when title-5 is passed as the type and lineHeight as large, fontWeight as light', () => {
    let component = mountWithIntl( <Title type='title-5' htmlTag='h2' lineHeight='large' fontWeight='light'/> );
    expect( component.find( 'Title' ).props().type ).toBe( 'title-5' );
    expect( component.find( 'Title' ).props().htmlTag ).toBe( 'h2' );
    expect( component.find( '.Title--large' ).length ).toBe( 1 );
    expect( component.find( '.Title--light' ).length ).toBe( 1 );
    expect( component.find( 'Title' ).props() ).toEqual( {
      'htmlTag': 'h2', 'lineHeight': 'large', 'type': 'title-5', 'fontWeight':'light'
    } );
  } );
  it( 'should render the component with the class .Title--subtitle-1 with fontWeight bold when .subtitle-1 is passed as the type and bold as fontWeight', () => {
    let component = mountWithIntl( <Title type='subtitle-1' htmlTag='h1' fontWeight='bold' /> );
    expect( component.find( 'Title' ).props().type ).toBe( 'subtitle-1' );
    expect( component.find( 'Title' ).props().htmlTag ).toBe( 'h1' );
    expect( component.find( '.Title--bold' ).length ).toBe( 1 );
  } );
} );