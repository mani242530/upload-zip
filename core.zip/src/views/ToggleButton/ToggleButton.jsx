/**
 * ToggleButton
 */

import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { Field } from 'redux-form';
import Exclamation from '../Icons/exclamationcircle';
import './ToggleButton.css';



const propTypes = {
  handleClick: PropTypes.func,
  isDisabled: PropTypes.bool,
  name: PropTypes.string.isRequired,
  id: PropTypes.oneOfType( [PropTypes.string, PropTypes.number] ),
  tabIndex: PropTypes.number,
  value: PropTypes.oneOfType( [PropTypes.string, PropTypes.bool] ),
  isChecked:PropTypes.bool,
  ariaLabelledBy:PropTypes.string,
  isCheckBox:PropTypes.bool
};

const defaultProps = {
  tabIndex: 0,
  isCheckBox: false
}

const renderToggleField = ( props ) =>{
  const {
    input,
    name,
    id,
    onChange,
    ariaLabelledBy
  } = props.input;

  const {
    onClick,
    meta: { touched, error },
    isDisabled,
    isCheckBox,
    ...custom
  } = props;

  return (
    <div
      className={
        classNames(
          'ToggleButton', {
            'ToggleButton__checkBoxField': isCheckBox,
            'ToggleButton--error': error && touched,
            'ToggleButton--disabled': isDisabled
          }
        )
      }
    >
      <label className='ToggleButton__label'>
        {
          props.label &&
          (
            <div className='ToggleButton__label--text'>
              { props.label }
            </div>
          )
        }

        <div className='ToggleButton__label--input'>
          <input
            id={ props.id }
            type='checkbox'
            tabIndex={ props.tabIndex }
            className='ToggleButton__checkbox'
            onChange={ onChange }
            { ...( props.onClick && { onClick: ( e ) => onClick( !props.isChecked ) } ) }
            name={ name }
            checked={ props.isChecked }
            { ...( isDisabled && { disabled: isDisabled } ) }
            aria-labelledby={ props.ariaLabelledBy }
          />
          <div className={
            classNames( {
              'ToggleButton__slider ToggleButton__slider--round': !isCheckBox,
              'ToggleButton__normalCheckBox': isCheckBox
            } )
          }
          >
            { !isCheckBox && <div className='ToggleButton__slider--switch'></div> }
          </div>
        </div>
      </label>
      { ( () => {
        if( touched && error ){
          return (
            <div
              className={
                classNames(
                  'ToggleButton--message', {
                    'ToggleButton--error': error && touched
                  }
                )
              }
            >
              <Exclamation />
              { error }
            </div>
          )
        }
      } )() }
    </div>
  )
}

const ToggleButton = ( props ) => {
  const {
    onClick,
    tabIndex,
    name,
    label,
    isChecked,
    isDisabled,
    id,
    ariaLabelledBy,
    isCheckBox
  } = props;

  return (

    <Field
      tabIndex={ tabIndex }
      name={ name }
      label={ label }
      ariaLabelledBy={ ariaLabelledBy }
      component={ renderToggleField }
      { ...( onClick && { onClick } ) }
      { ...( isDisabled && { isDisabled } ) }
      isChecked={ isChecked }
      normalize={ value => value || false }
      id={ id }
      isCheckBox={ isCheckBox }
    />

  );

}

ToggleButton.propTypes = propTypes;
ToggleButton.defaultProps = defaultProps;

export default ToggleButton ;
