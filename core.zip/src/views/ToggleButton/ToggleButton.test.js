import React from 'react';
import _ from 'lodash';
import { reduxForm } from 'redux-form'
import { Provider } from 'react-redux';
import { mountWithIntl, configureStore } from '../../utils/enzyme/intl-enzyme-test-helper';
import ToggleButton from './ToggleButton';


describe( '<ToggleButton />', () => {
  const store = configureStore( );
  const props = {
    name: 'abc',
    onClick: jest.fn(),
    tabIndex:0,
    label:'abc',
    value:'',
    isChecked:false,
    id: 'testId',
    ariaLabelledBy: 'Test label',
    handleClick:jest.fn()
  }

  const Decorated = reduxForm( { form: 'testForm' } )( ToggleButton );
  const component = mountWithIntl(
    <Provider store={ store }>
      <Decorated { ...props } />
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component ).toBeTruthy();
  } );

  it( 'renders with the id field', () => {
    expect( component.find( 'input' ).props()['id'] ).toBe( 'testId' );
  } );

  it( 'id and aria-labelledby attribute is present for the toggle button', () => {
    expect( component.find( '.ToggleButton__checkbox' ).props().id ).toBe( 'testId' );
    expect( component.find( '.ToggleButton__checkbox' ).props()['aria-labelledby'] ).toBe( 'Test label' );
  } );

  it( 'should render slider and borders for toggle button', () => {
    expect( component.find( '.ToggleButton .ToggleButton__slider' ).length ).toBe( 1 );
    expect( component.find( '.ToggleButton .ToggleButton__slider .ToggleButton__slider--switch' ).length ).toBe( 1 );
  } );

  it( 'should render ToggleButton--disabled and set input disabled attribute as true if isDisabled is true', () => {
    const props = {
      isDisabled: true
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <Decorated { ...props } />
      </Provider>
    );

    expect( component.find( '.ToggleButton.ToggleButton--disabled' ).length ).toBe( 1 );
    expect( component.find( 'input' ).props().disabled ).toBe( true );
    expect( component.find( 'Field' ).at( 0 ).props().isDisabled ).toBe( true );
  } );

  it( 'should not render ToggleButton--disabled and not set input disabled attribute as true if isDisabled is false', () => {
    const props = {
      isDisabled: false
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <Decorated { ...props } />
      </Provider>
    );
    expect( component.find( '.ToggleButton.ToggleButton--disabled' ).length ).toBe( 0 );
    expect( component.find( 'input' ).props().disabled ).toBeFalsy();
    expect( component.find( 'Field' ).at( 0 ).props().isDisabled ).toBeFalsy();
  } );

  it( 'should render ToggleButton__checkBoxField only if isCheckBox is true', () => {
    const props = {
      isCheckBox: true
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <Decorated { ...props } />
      </Provider>
    );
    expect( component.find( '.ToggleButton.ToggleButton__checkBoxField' ).length ).toBe( 1 );

    const props1 = {
      isCheckBox: false
    }
    const component1 = mountWithIntl(
      <Provider store={ store }>
        <Decorated { ...props1 } />
      </Provider>
    );
    expect( component1.find( '.ToggleButton.ToggleButton__checkBoxField' ).length ).toBe( 0 );

  } );
} );
