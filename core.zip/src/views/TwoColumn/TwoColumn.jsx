/**
 * TwoColumn Content Container Layout
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './TwoColumn.css';
import classNames from 'classnames';
import Divider from '../Divider/Divider';

const propTypes = {
  split: PropTypes.oneOf( ['half|half', 'twoThirds|oneThird'] ),
  columnOne: PropTypes.object,
  columnTwo: PropTypes.object
}

const defaultProps = {
  split: 'half|half'
}

/**
 * Class
 * @extends React.Component
 */
class TwoColumn extends Component{


  /**
   * Renders the TwoColumn component
   */
  render(){
    const {
      split,
      columnOne,
      columnTwo
    } = this.props;

    const halves = ( split === 'half|half' );
    const thirds = ( split === 'twoThirds|oneThird' );

    return (
      <div className='TwoColumn'>
        <div className={
          classNames( 'TwoColumn--left',
            {
              'TwoColumn--half': halves,
              'TwoColumn--twothirds': thirds
            } )
        }
        >
          { columnOne }
        </div>

        <Divider dividerType='gray'/>

        <div className={
          classNames( 'TwoColumn--right',
            {
              'TwoColumn--half': halves,
              'TwoColumn--onethird': thirds
            } )
        }
        >
          { columnTwo }
        </div>
      </div>
    );
  }
}

TwoColumn.propTypes = propTypes;
TwoColumn.defaultProps = defaultProps;

export default TwoColumn;
