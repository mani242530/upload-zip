import React from 'react';
import ReactDOM from 'react-dom';
import TwoColumn from './TwoColumn';
import { mountWithIntl } from '../../utils/enzyme/intl-enzyme-test-helper';
// import { shallow } from 'enzyme';
// import renderer from 'react-test-renderer';
//
// import { IntlProvider } from 'react-intl';

describe( '<TwoColumn />', () => {
  let component = mountWithIntl( <TwoColumn /> );

  it( 'renders without crashing', () => {
    expect( component.find( 'TwoColumn' ).length ).toBe( 1 );
    expect( component.find( '.TwoColumn--left' ).length ).toBe( 1 );
    expect( component.find( '.TwoColumn--right' ).length ).toBe( 1 );
  } );


} );
