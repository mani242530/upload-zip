const fs = require( 'fs' );
const path = require( 'path' );

// using the pdp as the holder of the timestamp since currently PDP is one of the few SSR pages
const contents = fs.readFileSync( path.join( __dirname, '../build/buildHash.txt' ), 'utf8' );
const buildHash = contents;

module.exports = buildHash;