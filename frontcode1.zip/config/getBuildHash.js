const currentTimeStamp = Date.now();
module.exports = currentTimeStamp;