// import 'regenerator-runtime/runtime'; 
window.scrollTo = () => { };

global.requestAnimationFrame = function (callback) {
  return setTimeout(callback, 0);
};

global.cancelAnimationFrame = function (id) {
  clearTimeout(id);
};
