var ultahost = ( window.location.hostname.search( /ir.ultabeauty.com|storead|creative/ ) !== -1 || window.location.hostname.search( 'ulta.com' ) === -1 ) ? 'www.ulta.com' : window.location.hostname;

function loadExternal( result ){
  console.log( result ); //eslint-disable-line
  let elem = document.createElement( 'script' );
  elem.setAttribute( 'type', 'text/javascript' );
  elem.setAttribute( 'src', "https://"+ultahost+"/ui/static/javascripts/external."+result.version+".js" );
  const externalElement = document.getElementById( 'uhfjs' );
  externalElement.parentNode.insertBefore( elem, externalElement );
}


( function(){
  $.ajax( {
    url: "https://"+ultahost+"/ui/external/version.json",
    dataType: 'jsonp'
  } );
} )()



