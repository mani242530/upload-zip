import mergeWith from 'lodash/mergeWith';
import isArray from 'lodash/isArray';
import { getLocation } from './utils/domain/domain';


export const commonConfig = {

  DEBUGGING: {
    LOGGING: {
      SCRIPT_TAG_LOGS: false,
      TRACK_DATA_LAYER_LOGS: false,
      TRACK_ANALYTICS_LOGS : false,
      DISABLE_SESSIONCAM: false,
      TRACK_REDUX_EVENTS: true,
      TRACK_SAGA_FAILURES: false
    },
    USER: {
      isSignedIn: true,
      isRewardsMember: true,
      rewardStatus: 'Member', // Member/Platinum/Diamond
      isEmailOptIn: false,
      isSoftLoginUser: false
    },
    CART: {
      cartQty: '4'
    },
    CHECKOUT: {
      hasSmsCommunicationInfo: false
    },
    isStagingEnvironment: false
  },

  PURCHASE_ELIGIBILITY_STATE_MAPPING:{
    ADD_TO_CART_ELIGIBLE:0,
    COMING_SOON:1,
    PLATINUM_PRODUCT_ANONYMOUS_USER :2,
    PLATINUM_PRODUCT_NONPLATINUM_MEMBER :3,
    PLATINUM_SALE_END :4,
    OUT_OF_STOCK:5,
    NOTIFY_ME:6,
    NOTIFY_ME_SIGNEDUP:7,
    IN_STORE_ONLY:8
  },

  BOPIS: {
    showPickupOption: true,
    geoLocationOption: {
      enableHighAccuracy: true,
      maximumAge: 30000
    }
  },
  SAVEFORLATER: {
    saveForLaterItemLimit : 20 // maximum number for SFL products shown on page load
  },
  TRANSITION_DURATION : 3000, // CSSTransitionGroup transition duration
  ENABLE_QUBIT: true,
  ENABLE_QUEUEIT:true,
  ENABLE_MESOBASE: false,
  ENABLE_REFLEKTION: true,
  ENABLE_SESSIONCAM: true,
  ACCESS_TOKEN:'pk.eyJ1Ijoic3dlZXRpcSIsImEiOiJjamdlMWZ4cnozZTJ6MnFzMDhpZXVwaDR5In0.gnizgEdqMS1-mpCYP7TBTw',

  QUAZI_API_KEY:'XyyS9ghuVrNjZWoU5lBw6RI4elrSHth7Kg0TmQ42',

  SECONDS_TO_WAIT_FOR_SIGNAL_TIMEOUT: 2,

  REDIRECTS: {
    404: '/404.jsp'
  },

  SERVICES: {

    HOST_BLACK_LIST: [ // Host names that should make api calls to production
      'ir.ultabeauty.com',
      'storead.ulta.com',
      'pages.exacttarget.com',
      'creative.ulta.com' // Creative page local dev
    ],

    SESSION_BLACK_LIST: [
      'session',
      'navigation',
      'switches',
      'page',
      'productDetails',
      'skuDynamicData',
      'skuDetails',
      'reflektionSearch',
      'findLocation',
      'invalidate',
      'quaziEventAPI',
      'deviceID'
    ],

    searchTypeAhead:  ( process.env.NODE_ENV === 'production' ) ? `${ getLocation().origin }/ulta/assembler?assemblerContentCollection=/content/Shared/Search%20box` : '/services/search/typeAhead',

    banner: '/services/v1/page/section/banner',

    page: '/services/v1/page',

    productRecs: '/services/v6/prodrecs',

    session: '/services/v1/session/token',

    invalidate: '/services/v6/user/session/invalidate',

    switches: '/services/v1/global/config',

    applyForm: '/services/v1/user/cc/apply',

    prescreenApply: '/services/v1/user/cc/prescreenApply',

    lpsLookUp : '/services/v1/user/rewards/lookup',

    lpsLookupByPrescreenId: '/services/v1/user/cc/rewards/lookupByPrescreenId',

    user: '/services/v2/user/lite',

    login: '/services/v5/user/login',

    createAccount: '/services/v1/user/create',

    addressbook: '/services/v5/user/profile/addressbook',

    profileCreditCards: '/services/v5/user/profile/creditcards',

    RealtimeOLPS: '/services/v1/user/cc/prescreen',

    preScreenLPSEvent: '/services/v1/user/cc/event/prescreenoffer',

    profile: '/services/v1/user/profile',

    rewardsLookup:'/services/v5/user/rewards/lookupMember',

    initCart: '/services/v5/cart/init',

    readCart: '/services/v5/cart/init',

    loadCart: '/services/v6/cart/load',

    initiateCheckout: '/services/v6/cart/validateCheckout',

    shippingUpdate: '/services/v5/cart/shipping/update',

    estimatedDeliveryDate: '/services/v5/cart/shipping/edd',

    addProductSamples: '/services/v6/cart/sample/add',

    removeProductSamples: '/services/v6/cart/sample/remove',

    removeItemFromCart: '/services/v6/cart/items/remove',

    addItemToCart: '/services/v6/cart/giftitems/add',

    selectGiftVariant: '/services/v6/cart/gwp/update',

    updateCartItems: '/services/v6/cart/items/update',

    removeGiftFromCart: '/services/v6/cart/items/remove',

    applycoupon: '/services/v6/cart/coupon/add',

    removecoupon: '/services/v6/cart/coupon/remove',

    addGiftNote: '/services/v6/cart/giftoptions/update',

    addGiftWrap: '/services/v6/cart/giftoptions/update',

    redeemPoints : '/services/v5/cart/rewards/redeemLevels',

    paymentServiceResponse: '/services/v5/cart/payments/update',

    paypalToken: '/services/v5/cart/payments/paypal/token',

    afterpayToken: '/services/v5/cart/payments/afterpay/token',

    applyPayPalPayment: '/services/v5/cart/payments/update',

    applyExpressPayPalPayment: '/services/v6/cart/payments/paypal/express',

    removePaymentService: '/services/v5/cart/payments/remove',

    submitOrderService : '/services/v5/cart/submit',

    miniCart: '/services/v5/cart',

    navigation: '/services/v2/page/nav',

    logout: '/services/v1/user/logout',

    userRewards: '/services/v1/user/rewards/create',

    cartPickupInfoUpdate: '/services/v6/cart/pickupInfo/update',

    paymentsCCKey: '/services/v5/payments/cc/key',

    addItem: '/services/v5/cart/items/add',

    deliveryOptionsUpdate: '/services/v6/cart/deliveryOption/update',

    pickupStoreInfoUpdate: '/services/v6/cart/pickupStoreInfo/update',

    pickupStores: '/services/v6/stores/pickupStores',

    findLocation:'https://api.mapbox.com/geocoding/v5/mapbox.places/:searchValue.json',

    pickupContactInfoUpdate: '/services/v5/cart/pickupContactInfo/update',

    multipleItemsAdd: '/services/v6/cart/items/add',

    saveForLater: '/services/v5/user/saveForLater',

    moveToSaveForLater:'/services/v6/cart/moveToSaveForLater',

    saveForLaterItemRemove:'/services/v5/user/saveForLater/remove',

    moveToBagFromSaveForLater: '/services/v6/user/saveForLater/moveToCart',

    productDetails: '/services/v5/catalog/product/:productid',

    skuDetails: '/services/v5/catalog/sku/:skuid',

    purchaseEligibility:'/services/v5/purchase-eligibility',

    skuDynamicData: '/services/v5/pdp/dynamicdata',

    emailNotification:'/services/v5/inv/notification/add',

    addFavorite:'/services/v5/user/profile/favorites/add',

    removeFavorite:'/services/v5/user/profile/favorites/remove',

    findFavorite:'/services/v5/user/profile/favorites/find',

    storeDetail: '/services/v7/stores',

    storeProductAvailability: '/services/v5/store/:storeId/sku/:skuId/availability',

    addToSaveForLater:'/services/v5/user/saveForLater/add',

    reflektionSearch:'/services/v5/search/typeAhead',

    fetchOrderDetails: '/services/v6/user/order',

    removeBagUpdateMessage: '/services/v6/cart/messages/remove',

    deviceID:'/services/v1/clientId'

  }
}

// this method is used to customize the way array properties are merged
// instead of using the default lodash merge method, the logic in this method will return the array from the module config
export const customizer = ( objValue, srcValue ) => {
  if( isArray( srcValue ) ){
    return srcValue;
  }
}

export const mergeConfig = ( moduleConfig ) => {
  // accepts a customizer which is invoked to produce the merged values of the destination and source properties.
  return mergeWith( {}, commonConfig, moduleConfig, customizer );
}

export default commonConfig;
