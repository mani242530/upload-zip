
import commonConfig, { mergeConfig } from './config';
describe( 'config test cases', () => {

  it( 'should only overwride the properties which are present in moduleConfig, and the commonConfig properties should not get modified', () => {
    expect( commonConfig.BOPIS.geoLocationOption.maximumAge ).toBe( 30000 );
    expect( commonConfig.BOPIS.showPickupOption ).toBe( true );
    const moduleConfig = {
      BOPIS: {
        showPickupOption: true,
        geoLocationOption: {
          maximumAge: 40000
        }
      }
    }
    const newConfig = mergeConfig( moduleConfig );
    expect( newConfig.BOPIS.geoLocationOption.maximumAge ).toBe( 40000 );
    expect( commonConfig.BOPIS.geoLocationOption.maximumAge ).toBe( 30000 );
    expect( commonConfig.BOPIS.showPickupOption ).toBe( true );
  } );

  it( 'should retain the value of properties in commonConfig with array type, if module config does not have that property', () => {
    const moduleConfig = {
      BOPIS: {
        showPickupOption: true,
        geoLocationOption: {
          maximumAge: 40000
        }
      }
    }
    const SESSION_BLACK_LIST = [
      'session',
      'navigation',
      'switches',
      'page',
      'productDetails',
      'skuDynamicData',
      'skuDetails',
      'reflektionSearch',
      'findLocation',
      'invalidate',
      'quaziEventAPI',
      'deviceID'
    ];
    const HOST_BLACK_LIST = [
      'ir.ultabeauty.com',
      'storead.ulta.com',
      'pages.exacttarget.com',
      'creative.ulta.com'
    ];
    expect( commonConfig.SERVICES.SESSION_BLACK_LIST ).toEqual( SESSION_BLACK_LIST );
    const newConfig = mergeConfig( moduleConfig );
    expect( newConfig.SERVICES.SESSION_BLACK_LIST ).toEqual( SESSION_BLACK_LIST );
    expect( commonConfig.SERVICES.SESSION_BLACK_LIST ).toEqual( SESSION_BLACK_LIST );
    expect( commonConfig.SERVICES.HOST_BLACK_LIST ).toEqual( HOST_BLACK_LIST );
  } );

  it( 'should override the value of properties in commonConfig with array type, if modue config has the same property', () => {
    const moduleConfig = {
      SERVICES: {
        SESSION_BLACK_LIST: [
          'session'
        ]
      }
    }
    const SESSION_BLACK_LIST = [
      'session',
      'navigation',
      'switches',
      'page',
      'productDetails',
      'skuDynamicData',
      'skuDetails',
      'reflektionSearch',
      'findLocation',
      'invalidate',
      'quaziEventAPI',
      'deviceID'
    ];
    expect( commonConfig.SERVICES.SESSION_BLACK_LIST ).toEqual( SESSION_BLACK_LIST );
    const newConfig = mergeConfig( moduleConfig );
    expect( newConfig.SERVICES.SESSION_BLACK_LIST ).toEqual( moduleConfig.SERVICES.SESSION_BLACK_LIST );
    expect( commonConfig.SERVICES.SESSION_BLACK_LIST ).toEqual( SESSION_BLACK_LIST );
  } );
} )
