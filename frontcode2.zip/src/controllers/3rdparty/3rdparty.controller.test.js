/**
 * LoadScripts.sagas
 */
import {
  takeEvery, call, select, put
} from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/lib/utils';
import {
  createScriptTag
} from 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts';
import {
  LOAD_SCRIPTS
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { omnitureEventFactory } from 'ulta-fed-core/dist/js/utils/omniture/omniture';
import qProtocol from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import CONFIG from '../../config';
import saga, { loadScripts } from './3rdparty.controller';
import { triggerMesobaseEvents } from '../../events/mesobase/mesobase.events';
import reflektion from '../../utils/reflektion/reflektion';


describe( 'LoadScripts Saga', () => {
  const loadScriptsSaga = saga( CONFIG )();
  let listenerSagaClone1;
  let listenerSagaClone2;
  let listenerSagaClone3;
  it( 'should listen for the LoadScripts requested method', () => {

    const takeEveryDescriptor = loadScriptsSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( LOAD_SCRIPTS, loadScripts, CONFIG ) );
  } );

  describe( 'LoadScripts method success/failure path', () => {
    CONFIG.ENABLE_MESOBASE = true;
    const listenerSaga = cloneableGenerator( loadScripts )( CONFIG );

    it( 'should do a select on makeGetSwitchesData', () => {

      const selectDescriptor = listenerSaga.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );
    const switchData = {
      switches:{
        brightTagSiteID:111,
        qubitScriptURLSync:'test',
        qubitScriptURL:'test',
        mesobaseScriptUrl: 'test',
        refBeaconScriptUrl:'test',
        sessionCamScriptURL:'test',
        enableSessionCamTag:true,
        enableQubitTag:true,
        enableQueueIt:true,
        mesobaseEnabled: true,
        enableRefBeaconScript:true,
        enableRfkEvents:true,
        queueItScriptUrl: 'test',
        queueItConfigLoaderUrl: 'test'

      }
    }

    it( 'should add queue-it queueclient javascript to page', () => {

      var queueitObj = {
        'attributes': {
          'type': 'text/javascript',
          'src': `${ switchData.switches.queueItScriptUrl }`,
          'async': 'async'
        }
      };
      const callDescriptor = listenerSaga.next( switchData ).value;
      expect( callDescriptor ).toEqual( call( createScriptTag, queueitObj ) );
    } );

    it( 'should add queue-it queueconfigloader javascript to page', () => {
      var queueitObj1 = {
        'attributes': {
          'data-queueit-c': 'ulta',
          'type': 'text/javascript',
          'src': `${ switchData.switches.queueItConfigLoaderUrl }`,
          'async': 'async'
        }
      };
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( createScriptTag, queueitObj1 ) );
    } );

    it( 'should create brighttag scripts', () => {
      omnitureEventFactory.listenSignalLoad = jest.fn();
      listenerSagaClone2 = listenerSaga.clone();
      var btObj = {
        'attributes': {
          'id': 'brightTag',
          'type': 'text/javascript',
          'src': `//s.btstatic.com/tag.js#site=${ switchData.switches.brightTagSiteID }&referrer=${ encodeURIComponent( document.location.href ) }`
        }
      };
      const callDescriptor = listenerSaga.next( ).value;
      expect( omnitureEventFactory.listenSignalLoad ).toBeCalled();
      expect( callDescriptor ).toEqual( call( createScriptTag, btObj ) );
    } );

    it( 'should add qubit to page', () => {
      qProtocol.listenQubitLoad = jest.fn();

      const callDescriptor  = listenerSaga.next( ).value;
      const query = {};

      expect( qProtocol.listenQubitLoad ).toBeCalled();
      expect( callDescriptor ).toEqual( call( createScriptTag, expect.objectContaining( { 'attributes': { 'id': 'qubitUvApi', 'type': 'text/javascript' } } ) ) );
    } );

    it( 'should add qubit to page', () => {

      var qubitSyncObj = {
        'attributes': {
          'id': 'qubitScriptURLSync',
          'type': 'text/javascript',
          'src': `${ switchData.switches.qubitScriptURLSync }`,
          'async': 'async'
        }
      };
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( createScriptTag, qubitSyncObj ) );
    } );

    it( 'should add qubit to page', () => {
      var qubitObj = {
        'attributes': {
          'id': 'qubitScriptURL',
          'type': 'text/javascript',
          'src': `${ switchData.switches.qubitScriptURL }`,
          'async': 'async'
        }
      };
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( createScriptTag, qubitObj ) );
    } );

    it( 'should add mesobase to page when switches.mesobaseEnabled and CONFIG.ENABLE_MESOBASE is true ', () => {
      listenerSagaClone3 = listenerSaga.clone();
      var mesobaseScriptObj = {
        'attributes': {
          'id': 'mesobaseScriptUrl',
          'type': 'text/javascript',
          'src': `${ switchData.switches.mesobaseScriptUrl }`,
          'async': 'async'
        }
      };
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( createScriptTag, mesobaseScriptObj ) );
    } );

    it( 'should dispatch action to triggerMesobaseEvents', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( triggerMesobaseEvents() ) );
    } );

    describe( 'Load reflektion beacon test cases', () => {
      it( 'should call listenReflektionLoad when enableRfkEvents is true', () => {
        reflektion.listenReflektionLoad = jest.fn();
        var refBeaconObj = {
          'attributes': {
            'id': 'refBeaconScriptUrl',
            'type': 'text/javascript',
            'src': `${ switchData.switches.refBeaconScriptUrl }`,
            'async': 'async'
          }
        };
        listenerSagaClone1 = listenerSaga.clone();
        const callDescriptor = listenerSaga.next().value;
        expect( reflektion.listenReflektionLoad ).toBeCalled();
        expect( callDescriptor ).toEqual( call( createScriptTag, refBeaconObj ) );
      } );
      it( 'should not call  listenReflektionLoad  when enableRfkEvents is false', () => {
        reflektion.listenReflektionLoad = jest.fn();
        switchData.switches.enableRfkEvents = false;
        var refBeaconObj = {
          'attributes': {
            'id': 'refBeaconScriptUrl',
            'type': 'text/javascript',
            'src': `${ switchData.switches.refBeaconScriptUrl }`,
            'async': 'async'
          }
        };
        const callDescriptor = listenerSagaClone1.next( switchData ).value;
        expect( reflektion.listenReflektionLoad ).not.toBeCalled();
        expect( callDescriptor ).toEqual( call( createScriptTag, refBeaconObj ) );
      } );
    } );
    it( 'should add sessionCam to page', () => {
      var sessionCamObj = {
        'attributes': {
          'id': 'sessionCamScriptURL',
          'type': 'text/javascript',
          'src': `${ switchData.switches.sessionCamScriptURL }`,
          'async': 'async'
        }
      };
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( createScriptTag, sessionCamObj ) );
    } );

    it( 'should add powerReviewsObj to page', () => {
      var powerReviewsObj = {
        'attributes': {
          'id': 'powerReviewsUI',
          'type': 'text/javascript',
          'src': '//ui.powerreviews.com/stable/4.0/ui.js',
          'async': 'async'
        }
      };
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( createScriptTag, powerReviewsObj ) );
    } );

    it( 'should add the Google Tag Manager script to page', () => {
      var gtmObj = {
        'attributes': {
          'id': 'gtmTag',
          'type': 'text/javascript',
          'async': 'async'
        },
        'content':
      `
      (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
      new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
      j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
      'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
      })(window,document,'script','dataLayer','GTM-W3P24LV');
      `
      };
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( createScriptTag, gtmObj ) );
    } );

    it( 'should add the Google site Tag script 1 to page', () => {
      var gTagObj1 = {
        'attributes': {
          'async': 'async',
          'src': `${ switchData.switches.googleSiteTagUrl }`
        }
      };
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( createScriptTag, gTagObj1 ) );
    } );

    it( 'should add the Google site Tag script 2 to page', () => {
      var gTagObj2 = {
        'attributes': {
        },
        'content':
    `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'AW-992679742');
    gtag('config', 'DC-1957541');
    `
      };
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( createScriptTag, gTagObj2 ) );
    } );

    it( 'should not add reflektion and proceed to include sessionCamScriptURL to page when enableRefBeaconScript is false', () => {
      switchData.switches.enableRefBeaconScript = false;
      switchData.switches.enableQubitTag = false;
      listenerSagaClone2.next( switchData );
      var refBeaconObj = {
        'attributes': {
          'id': 'sessionCamScriptURL',
          'type': 'text/javascript',
          'src': `${ switchData.switches.sessionCamScriptURL }`,
          'async': 'async'
        }
      };
      expect( listenerSagaClone2.next().value ).toEqual( call( createScriptTag, refBeaconObj ) );
    } );

    it( 'should not add reflektion and proceed to include sessionCamScriptURL to page when ENABLE_REFLEKTION is false in the config', () => {
      CONFIG.ENABLE_REFLEKTION = false;
      const loadScriptsSaga2 = loadScripts( CONFIG );
      switchData.switches.enableRefBeaconScript = true;
      switchData.switches.enableQubitTag = false;
      loadScriptsSaga2.next();
      loadScriptsSaga2.next( switchData );
      loadScriptsSaga2.next();
      loadScriptsSaga2.next();
      var refBeaconObj = {
        'attributes': {
          'id': 'sessionCamScriptURL',
          'type': 'text/javascript',
          'src': `${ switchData.switches.sessionCamScriptURL }`,
          'async': 'async'
        }
      };
      expect( loadScriptsSaga2.next().value ).toEqual( call( createScriptTag, refBeaconObj ) );
    } );

    it( 'should not add mesobase to page when path name is not /', () => {
      window.history.pushState( {}, 'Bag Page', '/bag' );
      switchData.switches.enableRefBeaconScript = false;
      switchData.switches.enableQubitTag = false;
      switchData.switches.enableSessionCamTag = false;
      switchData.switches.mesobaseEnabled = true;
      listenerSagaClone3.next();
      listenerSagaClone3.next( switchData );
      listenerSagaClone3.next();
      listenerSagaClone3.next();
      expect( listenerSagaClone3.next().done ).toEqual( true );
    } );

  } );

} );
