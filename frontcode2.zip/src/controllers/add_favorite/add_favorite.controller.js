import {
  takeEvery,
  call,
  put,
  select,
  cancelled
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';


import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import reflektion from '../../utils/reflektion/reflektion';
import { ajax } from '../../utils/ajax/ajax';
import appConstants from '../../shared/appConstants';
export const addToFavorites = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const res = yield call(
      ajax, {
        type:'addFavorite',
        method:'post',
        values:action.data
      }
    );
    yield put( getActionDefinition( type, 'success' )( res.body.data ) );

    if( res.body.data.success ){

      const evt = {
        'name': 'addToFavoritesClick',
        'data': {
          'productSku' : action.data.skuId
        }
      }
      yield put( triggerAnalyticsEvent( evt ) );
      // get global switch data to get reflektion  related flag data.
      const switchData = yield select( makeGetSwitchesData() );
      // trigger AddToWishList is called only when enableRfkEvents is true. which is turned on
      // only when either if Reflektion Search and Refektion Recommendation is turned on
      if( switchData.switches.enableRfkEvents ){
        yield call( triggerAddToFavouriteReflektionEvent, type, action.data );
      }
      // request to trigger QuaziEvent when enableQuaziEvents is true.
      if( switchData.switches.enableQuaziEvents ){
        const quaziData = {
          event: appConstants.EVENT_NAMES.ADD_TO_FAVORITES,
          sku:[action.data.skuId]
        }
        yield put( getActionDefinition( 'quaziEvent', 'requested' )( quaziData ) );
      }
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}
// poulate the payload needed for firing the AddToWishList reflektion events ,
// call the reflektion utlity method for handling to fire the events
export const triggerAddToFavouriteReflektionEvent = function* ( type, data ){
  let sourcePage;
  if( type === 'pdpAddFavorite' ){
    sourcePage = 'pdp';
  }
  else if( type === 'qsAddFavorite' ){
    sourcePage = 'qview';
  }
  const reflektionData = {
    'type': 'a2w', // Type of event
    'name': sourcePage, // Add to favourites is  avaialble  from pdp page.
    'value': {
      'products': [
        {
          'sku': data.skuId // skuId of product added to wishlist
        }
      ]
    }
  }
  yield put( triggerReflektionEvents( reflektionData ) );
}
export default function(){
  return function*( ){
    const pdpServiceType = 'pdpAddFavorite';
    registerServiceName( pdpServiceType );
    yield takeEvery( getServiceType( pdpServiceType, 'requested' ), addToFavorites, pdpServiceType )

    const qsServiceType = 'qsAddFavorite';
    registerServiceName( qsServiceType );
    yield takeEvery( getServiceType( qsServiceType, 'requested' ), addToFavorites, qsServiceType )
  }
}
