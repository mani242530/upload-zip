import {
  takeEvery,
  call,
  put,
  select,
  cancelled,
  take
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { cloneableGenerator } from 'redux-saga/utils';
import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { ajax } from '../../utils/ajax/ajax';
import CONFIG from '../../modules/pdp/pdp.config';
import saga, {
  addToFavorites,
  triggerAddToFavouriteReflektionEvent
} from './add_favorite.controller';
import appConstants from '../../shared/appConstants';

const type = 'pdpAddFavorite';
const serviceType = 'qsAddFavorite';

var action = {
  data:{
    sessionID : 44432,
    skuId: 2241934,
    productId : 123567,
    quantity: 1
  }
}

const listenerSaga = cloneableGenerator( addToFavorites )( type, action );
let listenerSagaClone1;
describe( 'AddToFavorites sagas', () => {
  const coreSaga = saga( CONFIG )();
  registerServiceName( type );
  registerServiceName( 'quaziEvent' );

  it( 'should take every addToFavorites request from pdp', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), addToFavorites, type ) );
  } );
  it( 'should take every addToFavorites request from quick shop', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( serviceType, 'requested' ), addToFavorites, serviceType ) );
  } );

  describe( 'addToFavorites saga success path', () => {

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      let values = action.data;

      expect( callDescriptor ).toEqual( call( ajax, { type:'addFavorite', method:'post', values } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should fire a trigger named addToFavoritesClick ', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const evt = {
        'name': 'addToFavoritesClick',
        'data': {
          'productSku' : action.data.skuId
        }
      }
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );
    it( 'should select swithces data', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      listenerSagaClone1 = listenerSaga.clone();
      expect( JSON.stringify( listenerSaga.next( res ).value ) ).toBe( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should call triggerQuaziEvents when enableQuaziEvents is true', () => {
      const switchData = {
        switches:{
          enableQuaziEvents:true
        }
      };
      const quaziData = {
        event: appConstants.EVENT_NAMES.ADD_TO_FAVORITES,
        sku:[2241934]
      }
      listenerSagaClone1.next( switchData );
      const callDescriptor = listenerSagaClone1.next( switchData ).value;
      expect( callDescriptor ).toEqual( put( getActionDefinition( 'quaziEvent', 'requested' )( quaziData ) ) );
    } );
    it( 'should not call triggerQuaziEvents when enableQuaziEvents is false', () => {
      const switchData = {
        switches:{
          enableQuaziEvents:false
        }
      };
      const quaziData = {
        event: appConstants.EVENT_NAMES.ADD_TO_FAVORITES,
        sku:[
          {
            sessionID : 44432,
            skuId: 2241934,
            productId : 123567,
            quantity: 1
          }
        ]
      }
      listenerSagaClone1.next( switchData );
      const callDescriptor = listenerSagaClone1.next( switchData );
      expect( callDescriptor.value ).not.toEqual( put( getActionDefinition( 'quaziEvent', 'requested' )( quaziData ) ) );
      expect( callDescriptor.done ).toEqual( true );

    } );

    describe( 'scenarios for enableRfkEvents flag ', () => {
      let listenerSagaCloneReflektion1;
      it( 'should invoke triggerAddToFavouriteReflektionEvent if enableRfkEvents is enabled ', () => {
        listenerSagaCloneReflektion1 = listenerSaga.clone();
        const switchData = {
          switches:{
            enableRfkEvents:true
          }
        }
        const callDescriptor = listenerSaga.next( switchData ).value;
        expect( callDescriptor ).toEqual( call( triggerAddToFavouriteReflektionEvent, 'pdpAddFavorite', action.data ) );

      } );

      it( 'should not invoke triggerAddToFavouriteReflektionEvent if enableRfkEvents is disabled ', () => {
        const switchData = {
          switches:{
            enableRfkEvents:false
          }
        }
        const callDescriptor = listenerSagaCloneReflektion1.next( switchData );
        expect( callDescriptor.done ).toEqual( true );
      } );

    } );
  } );

  describe( 'triggerAddToFavouriteReflektionEvent test cases', () => {
    var action = {
      data:{
        sessionID : 44432,
        skuId: 2241934,
        productId : 123567,
        quantity: 1
      }
    }
    const triggerAddToFavouriteReflektionEventSaga = triggerAddToFavouriteReflektionEvent( type, action.data );
    it( 'should call reflektion.triggerEvent with reflektionData', () => {
      const reflektionData = {
        'type': 'a2w', // Type of event
        'name': 'pdp', // Add to favourites is  avaialble  from pdp page
        'value': {
          'products': [
            {
              'sku': 2241934 // skuId of product added to wishlist
            }
          ]
        }
      }
      const callDescriptor = triggerAddToFavouriteReflektionEventSaga.next().value;
      expect( callDescriptor ).toEqual( put( triggerReflektionEvents( reflektionData ) ) );
    } );
  } );

  describe( 'addToFavorites saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );


} );
