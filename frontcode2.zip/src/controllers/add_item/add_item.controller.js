/**
 * Created by Sreekala on 8/3/18.
 */
import {
  takeEvery,
  select,
  call,
  put,
  cancelled
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import { setDataLayer } from '../../events/data_layer/data_layer.events';
import { ajax } from '../../utils/ajax/ajax';
import { getProductDetailsState } from '../../models/view/product_page/product_page.model';
import { getQuickShopProductDetailsState } from '../../models/view/quick_shop/quick_shop.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getCartState } from '../../models/view/cart/cart.model';
import appConstants from '../../shared/appConstants';


export const addItem = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const cartState = yield select( getCartState );
    const evt = {
      name:'addToBag',
      data: {
        'productSku':action.data.skuId,
        'productQuantity':action.data.quantity
      }
    }

    const data = {
      'globalPageData': {
        'order':{
          'previousItemCount':cartState.quantity
        }
      }
    };
    yield put( setDataLayer( data, evt ) );

    const res = yield call(
      ajax, {
        type:'addItem',
        method:'post',
        values:{
          skuId:action.data.skuId,
          quantity:action.data.quantity
        }
      }
    );

    let responseData = res.body.data;

    if( res.body.data.success ){
      let productDetails;
      if( type === 'pdpAddItem' ){
        productDetails = yield select( getProductDetailsState );
      }
      else if( type === 'qsAddItem' ){
        productDetails = yield select( getQuickShopProductDetailsState );
      }

      // get global switch data
      const switchData = yield select( makeGetSwitchesData() );
      responseData = {
        ...responseData,
        ...( res.body.data.success && {
          // enableAddToBagModal is set to true if enableAddToBagOverlay switch is true on add item success response
          enableAddToBagModal:switchData.switches.enableAddToBagOverlay,
          productImage:productDetails.sku.images.smallImage,
          brandName:productDetails.brand.brandName,
          displayName:productDetails.product.displayName,
          variant:productDetails.sku.variant,
          listPrice:productDetails.sku.price.listPrice,
          salePrice:productDetails.sku.price.salePrice,
          skuId:productDetails.sku.id
        } )
      }

      // if prodcRecs value is true then display product recommendations
      const recTestEnabled = switchData.switches.recTestEnabled;
      if( action.data.showProdRecs && !recTestEnabled ){
        yield put( getActionDefinition( 'addToBagModalProductRecs', 'requested' )( action.data.skuId ) );
      }
      // trigger AddToCartReflektionEvent is called only when enableRfkEvents is true. which is turned on
      // only when either if Reflektion Search and Refektion Recommendation is turned on
      if( switchData.switches.enableRfkEvents ){
        yield call( triggerAddToCartReflektionEvent, type, action.data );
      }
      // request to trigger QuaziEvent when enableQuaziEvents is true.
      if( switchData.switches.enableQuaziEvents ){
        const quaziData = {
          event: appConstants.EVENT_NAMES.ADD_TO_CART,
          sku:[action.data.skuId]
        }
        yield put( getActionDefinition( 'quaziEvent', 'requested' )( quaziData ) );
      }
    }
    yield put( getActionDefinition( type, 'success' )( { responseData, history:action.data.history } ) );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
  finally {
    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'canceled' )() );
    }
  }
}
// poulate the payload needed for firing the AddToCart reflektion events ,
// call the reflektion utlity method for handling to fire the events
export const triggerAddToCartReflektionEvent = function* ( type, data ){
  let sourcePage;
  if( type === 'pdpAddItem' ){
    sourcePage = 'pdp';
  }
  else if( type === 'qsAddItem' ){
    sourcePage = 'qview';
  }
  // Trigger Reflektion analytic Event
  const reflektionData = {
    'type': 'a2c',
    'name': sourcePage, // value can be home|pdp|cart|category|qview
    'value': {
      'products': [
        {
          'sku': data.skuId
        }
      ]
    }
  }
  yield put( triggerReflektionEvents( reflektionData ) );
}
export default function(){
  return function*( ){
    const pdpServiceType = 'pdpAddItem';
    registerServiceName( pdpServiceType );
    yield takeEvery( getServiceType( pdpServiceType, 'requested' ), addItem, pdpServiceType )

    const qsServiceType = 'qsAddItem';
    registerServiceName( qsServiceType );
    yield takeEvery( getServiceType( qsServiceType, 'requested' ), addItem, qsServiceType )
  }
}
