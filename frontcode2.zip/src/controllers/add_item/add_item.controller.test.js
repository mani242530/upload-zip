/**
 * Created by Sreekala on 8/3/18.
 */
import {
  takeEvery,
  call,
  put,
  cancelled,
  take,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';

import { cloneableGenerator } from 'redux-saga/utils';
import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import { ajax } from '../../utils/ajax/ajax';
import saga, {
  addItem,
  triggerAddToCartReflektionEvent
} from './add_item.controller';
import CONFIG from '../../modules/pdp/pdp.config';
import { getProductDetailsState } from '../../models/view/product_page/product_page.model';
import { getQuickShopProductDetailsState } from '../../models/view/quick_shop/quick_shop.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getCartState } from '../../models/view/cart/cart.model';
import appConstants from '../../shared/appConstants';


const type = 'pdpAddItem';
const serviceType = 'qsAddItem';
var action = {
  data:{
    quantity: 1,
    skuId: 12312312,
    showProdRecs:true,
    history: {
      location: {
        pathname: '/bag'
      }
    }
  }
}
const listenerSaga = cloneableGenerator( addItem )( type, action );
let listenerSagaClone;
let listenerSagaClone1;
let listenerSagaClone2;
let listenerSagaClone3;
describe( 'AddItem sagas', () => {
  const coreSaga = saga( CONFIG )();
  registerServiceName( type );
  registerServiceName( 'user' );
  registerServiceName( 'addToBagModalProductRecs' );
  registerServiceName( serviceType );

  it( 'should take every addItem request from pdp', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), addItem, type ) );
  } );

  it( 'should take every addItem request from quick shop', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( serviceType, 'requested' ), addItem, serviceType ) );
  } );

  describe( 'addItem saga success path', () => {
    registerServiceName( 'quaziEvent' );

    const productDetails = {
      sku:{
        variant: {
          'variantType': 'Color',
          'variantDesc': 'Violetta Darling (light purple crème)'
        },
        price:{
          listPrice:{
            'displayAmount': '$8.99',
            'amount': 8.99,
            'currencyCode': 'USD'
          },
          salePrice:{
            'displayAmount': '$8.99',
            'amount': 8.99,
            'currencyCode': 'USD'
          }

        },
        images:{
          smallImage:'https://images.ulta.com/is/image/Ulta/2236259?$sm$'
        },
        id:'8342348'
      },
      brand:{
        brandName:'Red Carpet Manicure'
      },
      product:{
        displayName:'Purple LED Gel Nail Polish Collection',
        id:1234
      }
    };

    const switchData = {
      switches:{
        enableAddToBagOverlay:true,
        enableRfkEvents:true,
        recTestEnabled:false
      }
    };

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should do a a select against getMiniCartState', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( selectDescriptor ).toEqual( select( getCartState ) );
    } );

    it( 'should do a put against datalayer', () => {
      const cartState = {
        quantity:5
      }
      const data = {
        'globalPageData': {
          'order':{
            'previousItemCount':cartState.quantity
          }
        }
      };

      const evt = {
        name:'addToBag',
        data: {
          'productSku':12312312,
          'productQuantity':1
        }
      }
      const putDescriptor = listenerSaga.next( cartState ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;
      let values = {
        skuId:action.data.skuId,
        quantity:action.data.quantity
      }

      expect( callDescriptor ).toEqual( call( ajax, { type:'addItem', method:'post', values } ) );
    } );

    it( 'should do a select again the productdetail state', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const selectDescriptor = listenerSaga.next( res ).value;
      expect( selectDescriptor ).toEqual( select( getProductDetailsState ) );
    } );

    it( 'should do a select again the quick shop productdetail state', () => {
      const listenerSaga = addItem( serviceType, action );
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      listenerSaga.next();
      listenerSaga.next();
      listenerSaga.next( {} );
      listenerSaga.next();
      const selectDescriptor = listenerSaga.next( res ).value;
      expect( selectDescriptor ).toEqual( select( getQuickShopProductDetailsState ) );
    } );

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga.next( productDetails ).value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put a addToBagModalProductRecs requested event when recTestEnabled is false', () => {
      // Clone saga before addToBagModalProductRecs requested call so that we can pass modified switch data
      listenerSagaClone = listenerSaga.clone();
      listenerSagaClone1 = listenerSaga.clone();
      listenerSagaClone2 = listenerSaga.clone();
      listenerSagaClone3 = listenerSaga.clone();

      const selectDescriptor = listenerSaga.next( switchData ).value;
      expect( selectDescriptor ).toEqual( put( getActionDefinition( 'addToBagModalProductRecs', 'requested' )( action.data.skuId ) ) );
    } );

    it( 'should not  put a addToBagModalProductRecs requested event when recTestEnabled is true', () => {
      switchData.switches.recTestEnabled = true;
      const selectDescriptor = listenerSagaClone1.next( switchData ).value;
      expect( selectDescriptor ).toEqual( call( triggerAddToCartReflektionEvent, type, action.data ) );
    } );

    it( 'should call triggerAddToCartReflektionEvent on success of addToCart call for triggering reflektion analytic event', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( triggerAddToCartReflektionEvent, type, action.data ) );
    } );

    it( 'should not call triggerAddToCartReflektionEvent when enableRfkEvents is false', () => {
      // Pass modified switch data with enableRfkEvents false
      const switchData1 = {
        switches:{
          enableRfkEvents:false
        }
      };
      listenerSagaClone.next( switchData1 ); // addToBagModalProductRecs requested action
      listenerSagaClone.next(); // pdpAddItem success action
      // when enableRfkEvents is false, triggerAddToCartReflektionEvent won't be called and execution will got to cancelled yield on addItem saga finally block
      const cancelDescriptor = listenerSagaClone.next().value; // addItem saga cancelled
      expect( cancelDescriptor ).toEqual( cancelled() );
    } );

    it( 'should call triggerQuaziEvents when enableQuaziEvents is true', () => {
      const switchData = {
        switches:{
          enableQuaziEvents:true
        }
      };
      const quaziData = {
        event: appConstants.EVENT_NAMES.ADD_TO_CART,
        sku:[12312312]
      }
      listenerSagaClone2.next( switchData );
      const callDescriptor = listenerSagaClone2.next( switchData ).value;
      expect( callDescriptor ).toEqual( put( getActionDefinition( 'quaziEvent', 'requested' )( quaziData ) ) );
    } );
    it( 'should not call triggerQuaziEvents when enableQuaziEvents is false', () => {
      const switchData = {
        switches:{
          enableQuaziEvents:false
        }
      };
      listenerSagaClone3.next( switchData );
      listenerSagaClone3.next( );
      const cancelDescriptor = listenerSagaClone3.next( switchData ).value;
      expect( cancelDescriptor ).toEqual( cancelled() );
    } );

    it( 'should put a success event after data is called', () => {
      const responseData = {
        responseData :{
          success:true,
          enableAddToBagModal:switchData.switches.enableAddToBagOverlay,
          productImage:'https://images.ulta.com/is/image/Ulta/2236259?$sm$',
          brandName:'Red Carpet Manicure',
          displayName:'Purple LED Gel Nail Polish Collection',
          variant:{
            'variantType': 'Color',
            'variantDesc': 'Violetta Darling (light purple crème)'
          },
          listPrice:{
            'displayAmount': '$8.99',
            'amount': 8.99,
            'currencyCode': 'USD'
          },
          salePrice:{
            'displayAmount': '$8.99',
            'amount': 8.99,
            'currencyCode': 'USD'
          },
          skuId:'8342348'
        }
      }
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { responseData:responseData.responseData, history:action.data.history } ) ) );
    } );

  } );

  describe( 'triggerAddToCartReflektionEvent function', () => {
    it( 'should invoke triggerAddToCartReflektionEvent with proper object for pdpAddItem service type', () => {
      const listenerSagaReflektion = triggerAddToCartReflektionEvent( type, action.data );
      const reflektionData = {
        'type': 'a2c',
        'name': 'pdp',
        'value': {
          'products': [
            {
              'sku': 12312312
            }
          ]
        }
      }
      const callDescriptor = listenerSagaReflektion.next( ).value;
      expect( callDescriptor ).toEqual( put( triggerReflektionEvents( reflektionData ) ) );
    } );

    it( 'should invoke triggerAddToCartReflektionEvent with proper object for qsAddItem service type', () => {
      const listenerSagaReflektion = triggerAddToCartReflektionEvent( serviceType, action.data );
      const reflektionData = {
        'type': 'a2c',
        'name': 'qview',
        'value': {
          'products': [
            {
              'sku': 12312312
            }
          ]
        }
      }
      const callDescriptor = listenerSagaReflektion.next( ).value;
      expect( callDescriptor ).toEqual( put( triggerReflektionEvents( reflektionData ) ) );
    } );

  } );
  describe( 'addItem saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

  describe( 'addItem saga finally block', () => {

    it( 'addItem cancel the event if an error occured in the service', () => {
      const cancelDescriptor = listenerSaga.next().value;
      expect( cancelDescriptor ).toEqual( cancelled() );
    } );

    it( 'should put a cancel action', () => {
      const putDescriptor = listenerSaga.next( true, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'canceled' )() ) );
    } );

  } );

} );
