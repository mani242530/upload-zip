import {
  takeEvery,
  take,
  select,
  call,
  put,
  cancelled
} from 'redux-saga/effects';
import {
  SESSION_TOKEN_REQUESTED,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import has from 'lodash/has';
import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  persistExternalAddInput,
  removeExternalAddInput
} from '../../utils/local_storage/local_storage';
import { ajax } from '../../utils/ajax/ajax';

export const oakMirrorListener = function* ( action ){

  let addToBag;
  if( global.location.search !== '' ){
    const params = global.location.search.substring( 1 ).split( '&' );
    let paramKey;
    for ( let param of params ){
      paramKey = param.split( '=' )[0];
      if( paramKey === 'addToBag' ){
        addToBag = decodeURIComponent( param.split( '=' )[1] );
      }
    }
  }
  if( addToBag ){
    persistExternalAddInput( addToBag );
  }


}

export const multipleItemsAdd = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const cartItems = action.data.split( ',' ).map( product => {
      const skuData = product.split( '|' );
      return {
        productId: skuData[0],
        skuId : skuData[1],
        // Default quantity as 1 if quantity is undefined
        quantity: skuData[2] || '1'
      }
    } )

    const res = yield call(
      ajax, {
        type,
        method:'post',
        values:{
          data: {
            cartItems
          }
        }
      }
    );
    // add multiple items response has list of cart items added. Filtering the skuId's from response and populating in itemsAdded
    let itemsAdded = has( res.body, 'data.cartItems' ) &&
      res.body.data.cartItems.filter( cartItem => cartItem.success ).map( ( cartItem ) => ( cartItem.skuId ) );

    yield call( removeExternalAddInput );
    yield put( getActionDefinition( type, 'success' )( { itemsAdded, cartSummary:res.body.data.cartSummary } ) );
    // get global switch data
    const switchData = yield select( makeGetSwitchesData() );
    // trigger AddToCartReflektionEvent is called only when enableRfkEvents is true. which is turned on
    // only when either if Reflektion Search and Refektion Recommendation is turned on
    if( switchData.switches.enableRfkEvents ){
      yield call( triggerAddToCartReflektionEvent, itemsAdded );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}
// poulate the payload needed for firing the AddToCart reflektion events ,
// call the reflektion utlity method for handling to fire the events
export const triggerAddToCartReflektionEvent = function* ( itemsAdded ){
  let products = itemsAdded.map( ( skuId ) => ( { 'sku':skuId } ) )
  // Trigger Reflektion analytic Event
  const reflektionData = {
    'type': 'a2c',
    'name': 'other',
    'value': { products }
  }
  yield put( triggerReflektionEvents( reflektionData ) );
}
export default function(){
  return function*( ){
    const addItemsServiceType = 'multipleItemsAdd';
    registerServiceName( addItemsServiceType );
    yield takeEvery( getServiceType( addItemsServiceType, 'requested' ), multipleItemsAdd, addItemsServiceType );
    yield takeEvery( SESSION_TOKEN_REQUESTED, oakMirrorListener );
  }
}
