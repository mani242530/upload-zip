/**
 * PaypalToken  sagas
 */

import {
  takeEvery, take, call, put, select, cancelled
} from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import {
  registerServiceName,
  getServiceType,
  SESSION_TOKEN_REQUESTED,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { cloneableGenerator } from 'redux-saga/utils';

import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  ajax
} from '../../utils/ajax/ajax';
import {
  persistExternalAddInput,
  removeExternalAddInput
} from '../../utils/local_storage/local_storage';
import CONFIG from '../../modules/pdp/pdp.config';
import saga, { multipleItemsAdd, oakMirrorListener, triggerAddToCartReflektionEvent } from './add_multiple_items_to_bag.controller';

jest.mock( '../../utils/local_storage/local_storage', ()=>{
  return {
    persistExternalAddInput:jest.fn(),
    removeExternalAddInput:jest.fn()
  }
} );

const addItemReponse = {
  body:{
    data:{
      cartItems: [
        {
          success: true,
          messages: null,
          skuId: '2242016'
        },
        {
          success: true,
          messages: null,
          skuId: '2525117'
        },
        {
          success: false,
          messages: null,
          skuId: '2525881'
        }
      ],
      cartSummary:{
        itemCount:3
      }
    }
  }
}

describe( 'MultipleItemsAdd Saga', () => {
  const type = 'multipleItemsAdd';
  const type2 = 'user';

  registerServiceName( type );
  registerServiceName( type2 );

  const coreSaga = saga( CONFIG )();

  const action = {
    data : 'xlsImpprod13561011|2242016|2,xlsImpprod13561234|2525117,xlsImpprod13565678|2525881|5'
  }

  it( 'should take every multipleItemsAdd request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), multipleItemsAdd, type ) );
  } );

  describe( 'multipleItemsAdd saga success/failure path', () => {

    const listenerSaga = cloneableGenerator( multipleItemsAdd )( type, action );
    let listenerSagaCloneRes;
    let listenerSagaCloneForReflektion;

    it( 'should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const cartItems = [
        {
          productId: 'xlsImpprod13561011',
          skuId : '2242016',
          quantity: '2'
        },
        {
          productId: 'xlsImpprod13561234',
          skuId : '2525117',
          quantity: '1'
        },
        {
          productId: 'xlsImpprod13565678',
          skuId : '2525881',
          quantity: '5'
        }
      ]

      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values:{ data: { cartItems } } } ) );
    } );

    it( 'should yield on removing the ExternalAddInput', () => {
      listenerSagaCloneRes = listenerSaga.clone();
      const callDescriptor = listenerSaga.next( addItemReponse ).value;
      expect( callDescriptor ).toEqual( call( removeExternalAddInput ) );

    } );

    it( 'success event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )(
        {
          itemsAdded:['2242016', '2525117'],
          cartSummary:{
            itemCount:3
          }
        }
      ) ) );

    } );

    it( 'success event has been put when cartItems is empty', () => {
      const addItemReponse1 = {
        body:{
          data:{
            cartItems: []
          }
        }
      }
      listenerSagaCloneRes.next( addItemReponse1 ).value;
      const putDescriptor = listenerSagaCloneRes.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { itemsAdded:[] } ) ) );
    } );
    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga.next( ).value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should call triggerAddToCartReflektionEvent for triggering reflektion analytic event', () => {
      listenerSagaCloneForReflektion = listenerSaga.clone();
      const switchData = {
        switches:{
          enableRfkEvents:true
        }
      };
      const callDescriptor = listenerSaga.next( switchData ).value;
      const itemsAdded = ['2242016', '2525117']
      expect( callDescriptor ).toEqual( call( triggerAddToCartReflektionEvent, itemsAdded ) );
    } );

    it( 'should not call triggerAddToCartReflektionEvent when enableRfkEvents is false', () => {
      // Pass modified switch data with enableRfkEvents false
      const switchData1 = {
        switches:{
          enableRfkEvents:false
        }
      };
      // when enableRfkEvents is false, triggerAddToCartReflektionEvent won't be called and generator function execution reaches done
      expect( listenerSagaCloneForReflektion.next( switchData1 ).done ).toEqual( true );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

  describe( 'triggerAddToCartReflektionEvent function', () => {

    const listenerSagaReflektion = triggerAddToCartReflektionEvent( ['2242016', '2525117'] );
    it( 'should invoke triggerAddToCartReflektionEvent if enableRfkEvents is enabled ', () => {
      const reflektionData = {
        'type': 'a2c',
        'name': 'other',
        'value': {
          'products': [
            {
              'sku': '2242016'
            },
            {
              'sku': '2525117'
            }
          ]
        }
      }
      const callDescriptor = listenerSagaReflektion.next( ).value;
      expect( callDescriptor ).toEqual( put( triggerReflektionEvents( reflektionData ) ) );

    } );

  } );

  describe( 'oakMirrorListener', () => {
    const listenerSaga1 = oakMirrorListener( action );
    it( 'should listen for SESSION_TOKEN_REQUESTED', () => {
      global.location.search = '/bag?addToBag=123';
      const type = 'session';
      const takeEveryDescriptor = coreSaga.next( type ).value;
      expect( takeEveryDescriptor ).toEqual( takeEvery( SESSION_TOKEN_REQUESTED, oakMirrorListener ) );
    } );

  } );

} );
