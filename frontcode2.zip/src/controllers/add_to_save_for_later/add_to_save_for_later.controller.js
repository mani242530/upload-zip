/*
* addToSaveForLater saga: calls the api to add items to SaveForLater section
* */

import {
  takeEvery,
  call,
  put
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';



import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { ADD_TO_SFL, sflItemAdded } from '../../events/save_for_later/save_for_later.events';
import { ajax } from '../../utils/ajax/ajax';
import {
  openSignInModal
} from '../../events/sign_in_modal/sign_in_modal.events';
import ProductCellItemMessages from '../../views/ProductCellItem/ProductCellItem.messages';


export const listener = function* ( type, CONFIG, action ){
  try {
    const {
      skuId,
      isSignedIn,
      saveForLaterLocation,
      updateSaveForLaterItems
    } = action.data;

    // add to save for later call need to be triggered only for registered user
    if( isSignedIn ){

      yield put( getActionDefinition( type, 'loading' )( { skuId } ) );
      // we are broadCasting an empty message because the screen reader will not read the same message which is populated in the globalAssertiveRegion div( which is in index.html).
      yield put( setBroadcastMessage( '' ) );

      const res = yield call(
        ajax, {
          type,
          method:'post',
          query: {
            skuIds: [skuId]
          }
        }
      );
      if( res.body.data ){
        yield put( sflItemAdded() );
        yield put( setBroadcastMessage( formatMessage( ProductCellItemMessages.movedToSaveForLaterLabel ) ) );
        // if res has no error, addToSaveForLater action will be triggered
        if( updateSaveForLaterItems !== false ){
          yield put( getActionDefinition( type, 'success' )( { skuId, movedItems: res.body.data } ) );
        }
        /* Trigger Analytics event on addToSaveForLater success */
        const evt = {
          'name': 'bagSaveForLater',
          'data': {
            'productSku' : skuId,
            saveForLaterLocation
          }
        }
        yield put( triggerAnalyticsEvent( evt ) );
      }
    }
    else {
      // if user is not logged in trigger action to open SignIn Modal
      // passing loginSuccessHandler as parameter to trigger add to SFL action after successful login
      const loginSuccessHandler = {
        action:ADD_TO_SFL,
        skuId,
        saveForLaterLocation,
        updateSaveForLaterItems: false
      }
      yield put( openSignInModal( { loginSuccessHandler, sourcePage: action.data.sourcePage } ) )
    }
  }

  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    console.log( err ); // eslint-disable-line
  }
};

export default function( CONFIG ){
  return function* (){
    let serviceType = 'addToSaveForLater';
    // register events for the request
    registerServiceName( serviceType );
    yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType, CONFIG );
  }
}
