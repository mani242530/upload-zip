import { takeEvery, call, put } from 'redux-saga/effects';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { cloneableGenerator } from 'redux-saga/utils';


import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';

import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';


import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { initializeIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import React from 'react';
import {
  initialState as initialStateGlobal
} from '../../models/view/global/global.model';
import {
  openSignInModal
} from '../../events/sign_in_modal/sign_in_modal.events';
import {
  ajax
} from '../../utils/ajax/ajax';
import configureStore from '../../modules/ccr/ccr.store';
import ProductCellItemMessages from '../../views/ProductCellItem/ProductCellItem.messages';
import CONFIG from '../../modules/ccr/ccr.config';
import { ADD_TO_SFL, sflItemAdded } from '../../events/save_for_later/save_for_later.events';
import saga, { listener } from './add_to_save_for_later.controller';

describe( 'AddToSaveForLater Saga', () => {
  const type = 'addToSaveForLater';
  registerServiceName( type );
  const addToSaveForLaterSaga = saga( CONFIG )();

  // TO test formatMessage function, need to initialzie intl
  initializeIntl();

  describe( 'default saga', () => {
    it( 'should listen for the AddToSaveForLater request method', () => {
      const takeEveryDescriptor = addToSaveForLaterSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), listener, type, CONFIG )
      );
    } );
  } );

  describe( 'listener saga success path - For Signed in user', () => {
    let action = {
      data: {
        skuId: 'testId', history: '/bag', isSignedIn:true, saveForLaterLocation:'bag'
      }
    };
    const hasSaveForLaterItemsResponse = {
      body: {
        data: {
          saveForLaterItems: {
            items: [
              {
                product: {
                  id: 'xlsImpprod12251073'
                },
                messages: null,
                sflItemId: 'gi101920006'
              }
            ]
          }
        }
      }
    };

    const listenerSaga = cloneableGenerator( listener )( type, CONFIG, action );
    let listenerSagaClone;

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { skuId: action.data.skuId } ) ) );
    } );

    it( 'should put setBroadcastMessage action with empty message', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( '' ) ) );
    } );

    it( 'should call addToSaveForLater API', () => {
      const callDescriptor = listenerSaga.next( ).value;
      listenerSagaClone = listenerSaga.clone();
      expect( callDescriptor ).toEqual( call( ajax, {
        type,
        method: 'post',
        query: {
          skuIds: [action.data.skuId]
        }
      } ) );
    } );

    it( 'should put sflItemAdded action', () => {
      const putDescriptor = listenerSaga.next( hasSaveForLaterItemsResponse ).value;
      expect( putDescriptor ).toEqual( put( sflItemAdded() ) );
    } );

    it( 'should put setBroadcastMessage action with addToSaveForLater message', () => {
      const putDescriptor = listenerSaga.next( hasSaveForLaterItemsResponse ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( formatMessage( ProductCellItemMessages.movedToSaveForLaterLabel ) ) ) );
    } );

    it( 'should put a addToSaveForLater success event', () => {
      const putDescriptor = listenerSaga.next( hasSaveForLaterItemsResponse ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { skuId: action.data.skuId, movedItems:hasSaveForLaterItemsResponse.body.data } ) ) );
    } );

    it( 'should put an analytic event on moveToSaveForLater success passing skuId and saveForLaterLocation (bag or bag update) passed in the action as parameter', () => {
      const putDescriptor = listenerSaga.next().value;
      const evt = {
        'name': 'bagSaveForLater',
        'data': {
          'productSku' : action.data.skuId,
          saveForLaterLocation:action.data.saveForLaterLocation
        }
      }
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );


    it( 'should not put a addToSaveForLater success event or analytic event if there is no response', () => {
      const res = {
        body:{}
      }
      const putDescriptor = listenerSagaClone.next( res ).done;
      expect( putDescriptor ).toEqual( true );
    } );

    describe( 'failure path', () => {
      const failureSaga = listener( type, CONFIG, action );
      failureSaga.next();
      window.console = {
        log:jest.fn()
      }
      const err = {
        statusText:'some failure message'
      };

      it( 'should put a failure event if any error occurs during the sagas execution', () => {
        const putDescriptor = failureSaga.throw( err ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );

      it( 'should log the error to the console', () => {
        const putDescriptor = failureSaga.next();
        expect( window.console.log ).toHaveBeenCalledWith( err );
      } );

    } );
  } );

  describe( 'listener saga path after login flow', () => {
    let action = {
      data: {
        skuId: 'testId',
        history: '/bag',
        isSignedIn:true,
        saveForLaterLocation:'bag',
        updateSaveForLaterItems: false
      }
    };
    const hasSaveForLaterItemsResponse = {
      body: {
        data: {
          saveForLaterItems: {
            items: [
              {
                product: {
                  id: 'xlsImpprod12251073'
                },
                messages: null,
                sflItemId: 'gi101920006'
              }
            ]
          }
        }
      }
    };

    const listenerSaga = cloneableGenerator( listener )( type, CONFIG, action );
    let listenerSagaClone;

    it( 'should wait until the loading event has been put after login is successful', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { skuId: action.data.skuId } ) ) );
    } );

    it( 'should put setBroadcastMessage action with empty message', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( '' ) ) );
    } );

    it( 'should call addToSaveForLater API after login', () => {
      const callDescriptor = listenerSaga.next( ).value;
      listenerSagaClone = listenerSaga.clone();
      expect( callDescriptor ).toEqual( call( ajax, {
        type,
        method: 'post',
        query: {
          skuIds: [action.data.skuId]
        }
      } ) );
    } );

    it( 'should put sflItemAdded action in login success flow', () => {
      const putDescriptor = listenerSaga.next( hasSaveForLaterItemsResponse ).value;
      expect( putDescriptor ).toEqual( put( sflItemAdded() ) );
    } );

    it( 'should put setBroadcastMessage action with addToSaveForLater message', () => {
      const putDescriptor = listenerSaga.next( hasSaveForLaterItemsResponse ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( formatMessage( ProductCellItemMessages.movedToSaveForLaterLabel ) ) ) );
    } );

    it( 'should put an analytic event on moveToSaveForLater success', () => {
      const putDescriptor = listenerSaga.next().value;
      const evt = {
        'name': 'bagSaveForLater',
        'data': {
          'productSku' : action.data.skuId,
          saveForLaterLocation:action.data.saveForLaterLocation
        }
      }
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );

    it( 'should not put a addToSaveForLater success event or analytic event if there is no response', () => {
      const res = {
        body:{}
      }
      const putDescriptor = listenerSagaClone.next( res ).done;
      expect( putDescriptor ).toEqual( true );
    } );

    describe( 'failure path', () => {
      const failureSaga = listener( type, CONFIG, action );
      failureSaga.next();
      window.console = {
        log:jest.fn()
      }
      const err = {
        statusText:'some failure message'
      };

      it( 'should put a failure event if any error occurs during the sagas execution', () => {
        const putDescriptor = failureSaga.throw( err ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );

      it( 'should log the error to the console', () => {
        const putDescriptor = failureSaga.next();
        expect( window.console.log ).toHaveBeenCalledWith( err );
      } );

    } );
  } );

  describe( 'listener saga success path - For Anonymous user', () => {
    let action = {
      data: {
        skuId: 'testId', history: '/bag', isSignedIn:false, saveForLaterLocation: 'bag', sourcePage: 'bag:save for later'
      }
    };

    const listenerSaga = listener( type, CONFIG, action );

    it( 'should put action to open SignIn Modal', () => {
      const putDescriptor = listenerSaga.next( ).value;
      const data = {
        loginSuccessHandler: {
          action:ADD_TO_SFL,
          saveForLaterLocation: 'bag',
          skuId:action.data.skuId,
          updateSaveForLaterItems: false
        },
        sourcePage:action.data.sourcePage
      }

      expect( putDescriptor ).toEqual( put( openSignInModal( data ) ) );
    } );

  } );

} );
