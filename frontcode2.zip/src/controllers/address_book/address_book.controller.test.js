/**
 * Created by rush on 5/3/17.
 */

/**
 * LoadCart  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import Cookies from 'js-cookie';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  ajax
} from '../../utils/ajax/ajax';
import saga, { listener } from './address_book.controller';



const type = 'addressbook';

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );

  const addressBookSaga = saga();

  it( 'should listen for the addressbook requested method', () =>{

    const takeEveryDescriptor = addressBookSaga.next().value;

    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );

  } );

  describe( 'listener saga success path', () => {
    const listenerSaga = listener( type, {} );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor  = listenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( ajax, { type } ) );

    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        body:{
          data: {
            title: 'test',
            status: 'ok'
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( 'addressbook', 'success' )( res.body.data ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should throw the error', () => {

      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }

      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );



  } );


} );
