/**
 * Afterpay sagas
 */
import {
  takeEvery,
  put,
  call
} from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  createScriptTag
} from 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts';
import { eventChannel, END } from 'redux-saga';

export const listener = function*( type ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const afterpayScriptObj = {
      'attributes': {
        'id': 'AfterpayScript',
        'type': 'text/javascript',
        'src': `https://static-us.afterpay.com/javascript/present-afterpay.js`,
        'async': 'async'
      }
    }

    yield call( createScriptTag, afterpayScriptObj );
    const presentAfterpayLoadingStatusChannel = yield call( watchPresentAfterpayLoading );
    yield takeEvery( presentAfterpayLoadingStatusChannel, emittingPresentAfterpayScript, type );

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
      console.log( err ); // eslint-disable-line
  }
}


export const emittingPresentAfterpayScript =  function* ( type ){
  yield put( getActionDefinition( type, 'success' )() );
}

// This channel emit flag as true only when present-afterpay script is loaded completely.
export const watchPresentAfterpayLoading = () => {
  return eventChannel( emitter => {
    const interval = setInterval( () => {
      // presentAfterpay script is loaded , it emit flag to the event channel .
      if( global.presentAfterpay ){
        // emit flag to the subscribing channel .
        emitter( true )
        // Stop the emiiter channel
        emitter( END )
      }
    }, 100 );
    // The subscriber must return an unsubscribe function
    return () => {
      clearInterval( interval )
    }
  } )
}

export default function*(){
  let serviceType = 'afterpay';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( 'afterpay', 'requested' ), listener, serviceType );
}
