/**
 * After Pay saga
 */

import {
  takeEvery,
  call,
  put
} from 'redux-saga/effects';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  createScriptTag
} from 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts';

import saga, { listener, watchPresentAfterpayLoading, emittingPresentAfterpayScript } from './afterpay.controller';


describe( 'afterpay Saga', () => {
  const type = 'afterpay';

  registerServiceName( type );
  const afterpaySaga = saga();

  describe( 'default saga', () => {
    it( 'should listen for the afterpay request method', () => {
      const takeEveryDescriptor = afterpaySaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), listener, type )
      );
    } );
  } );

  describe( 'listener afterpay saga success path', () => {
    const listenerSaga = listener( type );

    it( 'should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should load the present-afterpay script for afterpay', () => {
      const callDescriptor = listenerSaga.next().value;
      const afterpayScriptObj = {
        'attributes': {
          'id': 'AfterpayScript',
          'type': 'text/javascript',
          'src': `https://static-us.afterpay.com/javascript/present-afterpay.js`,
          'async': 'async'
        }
      }
      expect( callDescriptor ).toEqual( call( createScriptTag, afterpayScriptObj ) );
    } );

    it( 'should call watchPresentAfterpayLoading method', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( watchPresentAfterpayLoading ) );
    } );

    it( 'should listen for emittingPresentAfterpayScript method', () => {
      const presentAfterpayLoadingStatusChannel = true;
      const takeEveryDescriptor = listenerSaga.next( presentAfterpayLoadingStatusChannel ).value;
      expect( takeEveryDescriptor ).toEqual( takeEvery( presentAfterpayLoadingStatusChannel, emittingPresentAfterpayScript, type ) );
      expect( listenerSaga.next().done ).toBe( true );
    } );
  } );

  describe( 'listener afterpay saga failure path', () => {
    const failureSaga = listener( type );
    failureSaga.next();
    window.console = {
      log:jest.fn()
    }
    const err = {
      statusText:'some failure message'
    };
    it( 'should put a failure event if no data is returned from the service', () => {
      const putDescriptor = failureSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );
    it( 'should log the error to the console', () => {
      failureSaga.next();
      expect( window.console.log ).toHaveBeenCalledWith( err );
    } );
  } );

  describe( 'emittingPresentAfterpayScript', () => {
    const emittingPresentAfterpayScriptSaga = emittingPresentAfterpayScript( type );
    it( 'should put afterpay success event', () => {
      const putDescriptor = emittingPresentAfterpayScriptSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )() ) );
    } );
  } );

  describe( 'watchPresentAfterpayLoading', () => {
    it( 'should emit flag as true and call clearInterval when presentAfterpay is available', () => {
      window.presentAfterpay = {};
      window.clearInterval = jest.fn();
      jest.useFakeTimers();
      const eventChannel = watchPresentAfterpayLoading( )
      const spy = isLoaded => {
        expect( isLoaded ).toEqual( true )
      }
      eventChannel.take( spy )
      jest.runTimersToTime( 100 );
      expect( window.clearInterval ).toBeCalled();
    } );
    it( 'should not call clearInterval when presentAfterpay is not available', () => {
      window.presentAfterpay = undefined;
      window.clearInterval = jest.fn();
      jest.useFakeTimers();
      watchPresentAfterpayLoading();

      jest.runTimersToTime( 100 );
      expect( window.clearInterval ).not.toBeCalled();
    } );
  } );
} );
