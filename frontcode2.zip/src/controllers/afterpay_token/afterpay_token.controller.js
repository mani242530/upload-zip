/**
 * AfterpayToken sagas
 */
import {
  takeEvery,
  call,
  put
} from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  createScriptTag
} from 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts';
import {
  ajax
} from '../../utils/ajax/ajax';

export const listener = function*( type ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const res = yield call( ajax, { type } );
    if( res.body.data ){
      if( res.body.data.afterpayClientToken ){
        const afterpaySandboxScriptObj = {
          'attributes': {
            'id': 'AfterpaySandboxScript',
            'type': 'text/javascript',
            'src': `https://portal.sandbox.afterpay.com/afterpay.js`,
            'async': 'async'
          }
        }
        yield call( createScriptTag, afterpaySandboxScriptObj );
      }
      yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    console.log( err ); // eslint-disable-line
  }
}

export default function*(){
  let serviceType = 'afterpayToken';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( 'afterpayToken', 'requested' ), listener, serviceType );
}
