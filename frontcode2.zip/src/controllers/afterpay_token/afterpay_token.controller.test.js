/**
 * After Pay Token saga
 */

import {
  takeEvery,
  call,
  put
} from 'redux-saga/effects';

import { cloneableGenerator } from 'redux-saga/lib/utils';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  createScriptTag
} from 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts';

import {
  ajax
} from '../../utils/ajax/ajax';
import saga, { listener } from './afterpay_token.controller';


describe( 'afterpayToken Saga', () => {
  const type = 'afterpayToken';

  registerServiceName( type );
  const afterpayTokenSaga = saga();

  describe( 'default saga', () => {
    it( 'should listen for the afterpayToken request method', () => {
      const takeEveryDescriptor = afterpayTokenSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), listener, type )
      );
    } );
  } );

  describe( 'listener afterpayToken saga success path', () => {
    const listenerSaga = cloneableGenerator( listener )( type );

    it( 'should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should call afterpayToken API', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( ajax, { type } ) );
    } );
    let listenerSagaClone = listenerSaga.clone();
    let listenerSagaCloneA = listenerSaga.clone();
    it( 'should load the script for afterpay redirection if the response has afterpayClientToken', () => {
      let res = {
        body: {
          data: {
            afterpayClientToken: 'testToken'
          }
        }
      }
      const callDescriptor = listenerSaga.next( res ).value;
      const data = {
        'attributes': {
          'id': 'AfterpaySandboxScript',
          'type': 'text/javascript',
          'src': `https://portal.sandbox.afterpay.com/afterpay.js`,
          'async': 'async'
        }
      }
      expect( callDescriptor ).toEqual( call( createScriptTag, data ) );
    } );

    it( 'should not load the script for afterpay redirection if the response does not have afterpayClientToken', () => {
      let res = {
        body: {
          data: {}
        }
      }
      listenerSagaClone.next();// loading event
      listenerSagaClone.next();// call to get token info
      const callDescriptor = listenerSagaClone.next( res ).value;
      expect( callDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should not load the script for afterpay redirection and also shouldnot put success if the response doesnot have data in response body', () => {
      let res = {
        body: {}
      }
      listenerSagaCloneA.next();// loading event
      listenerSagaCloneA.next();// call to get token info
      const callDescriptor = listenerSagaClone.next( res ).done;
      expect( callDescriptor ).toEqual( true );
    } );

    it( 'should put afterpayToken success', () => {
      const res = {
        body: {
          data: {
            afterpayClientToken: 'testToken'
          }
        }
      }
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );
  } );

  describe( 'listener afterpayToken saga failure path', () => {
    const failureSaga = listener( type );
    failureSaga.next();
    window.console = {
      log:jest.fn()
    }
    const err = {
      statusText:'some failure message'
    };
    it( 'should put a failure event if no data is returned from the service', () => {
      const putDescriptor = failureSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );
    it( 'should log the error to the console', () => {
      failureSaga.next();
      expect( window.console.log ).toHaveBeenCalledWith( err );
    } );
  } );
} );
