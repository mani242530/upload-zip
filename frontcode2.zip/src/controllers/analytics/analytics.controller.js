/* eslint no-console: ["error", { allow: ["warn", "error", "log"] }] */
import { takeEvery, call, put } from 'redux-saga/effects';
import Cookies from 'js-cookie';

import isUndefined from 'lodash/isUndefined';
import {
  TRIGGER_ANALYTICS_EVENT,
  triggerAnalyticsEvent,
  analyticsEventFired,
  analyticsEventFailure
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';

import {
  updateDataLayer,
  omnitureEventFactory
} from 'ulta-fed-core/dist/js/utils/omniture/omniture';


import {
  dataLayerUpdated,
  dataLayerUpdateFailed,
  SET_DATA_LAYER
} from '../../events/data_layer/data_layer.events';



export const fireAnalyticsEvent = ( evt ) => {
  let analyticsTrigger = new CustomEvent( evt.name, { 'detail': evt.data } );
  omnitureEventFactory.triggerOmnitureEvent( analyticsTrigger );
  if( Cookies.get( 'showOmnitureLogs' ) === 'true' || global.TRACK_ANALYTICS_LOGS === true ){
    console.log( ':::Analytics Event (saga)::: ', [evt.name, evt.data] );
  }

}

// Individual exports for testing
export const analyticsSagaListener = function*( action ){
  try {
    // check to see if we need to trigger an event
    if( action.evt ){
      yield call( fireAnalyticsEvent, action.evt );
      yield put( analyticsEventFired( action.evt ) );
    }
    else {
      yield put( analyticsEventFailure( 'insufficient data to trigger analytics event' ) );
    }

  }
  catch ( err ){
    yield put( analyticsEventFailure( err ) );
  }
}


export const handleSetDataLayer = function*( action ){

  if( global.location.search.indexOf( 'showOmnitureLogs=true' ) > 0 ){
    if( isUndefined( Cookies.get( 'showOmnitureLogs' ) ) ){
      Cookies.set( 'showOmnitureLogs', true );
    }
  }

  try {
    // check to see if the dataObj was passed
    if( action.data ){
      yield call( updateDataLayer, action.data );
      yield put( dataLayerUpdated( action.data ) );
    }
    else {
      yield put( dataLayerUpdateFailed( 'insufficient data to udpate data layer' ) );
      return
    }
    // check to see if there should be a subsequent event fired after the data layer update
    if( action.evt ){
      yield put( triggerAnalyticsEvent( action.evt ) );
    }

  }
  catch ( err ){
    console.log( err );
    yield put( dataLayerUpdateFailed( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
};

export default function*(){
  yield [
    takeEvery( SET_DATA_LAYER, handleSetDataLayer ),
    takeEvery( TRIGGER_ANALYTICS_EVENT, analyticsSagaListener )
  ];
}
