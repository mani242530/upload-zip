import Cookies from 'js-cookie';

import {
  put,
  call,
  takeEvery
} from 'redux-saga/effects';

import {
  TRIGGER_ANALYTICS_EVENT,
  analyticsEventFired,
  analyticsEventFailure
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';

import { registerServiceName } from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  updateDataLayer,
  omnitureEventFactory
} from 'ulta-fed-core/dist/js/utils/omniture/omniture';
import {
  dataLayerUpdated,
  dataLayerUpdateFailed,
  SET_DATA_LAYER
} from '../../events/data_layer/data_layer.events';


import saga, {
  fireAnalyticsEvent,
  handleSetDataLayer,
  analyticsSagaListener
} from './analytics.controller';


omnitureEventFactory.triggerOmnitureEvent = jest.fn();



document.dispatchEvent = jest.fn();
const mockFn = jest.fn();


global.console = {
  log: mockFn
}

describe( 'Analytics.saga', () => {

  registerServiceName( SET_DATA_LAYER );
  registerServiceName( TRIGGER_ANALYTICS_EVENT );

  const analyticsSaga = saga();

  it( 'should listen for the navigation requested method', () => {

    const takeEveryDescriptor = analyticsSaga.next().value;

    expect( takeEveryDescriptor ).toEqual( [
      takeEvery( SET_DATA_LAYER, handleSetDataLayer ),
      takeEvery( TRIGGER_ANALYTICS_EVENT, analyticsSagaListener )
    ] );
  } );

  describe( 'fireAnalytics Event', () => {

    const evt = {
      name: 'testAnalyticsEvent',
      data: ''
    }

    const cookieHandler = new Cookies( { showOmnitureLogs: 'true' } );
    window.TRACK_ANALYTICS_LOGS = true;
    it( 'triggers fireAnalytics Event', () => {
      const analyticsTrigger = new CustomEvent( evt.name, { 'detail': evt.data } );

      fireAnalyticsEvent( analyticsTrigger );
      expect( omnitureEventFactory.triggerOmnitureEvent ).toHaveBeenCalled();

    } );

    it( 'should call console log', () => {
      expect( mockFn ).toHaveBeenCalled();
    } );
  } );

  describe( 'listener saga', () => {

    describe( 'listener saga success/failure path', () => {

      const evt = {
        name: 'testAnalyticsEvent',
        data: ''
      }
      const listenerSaga = analyticsSagaListener( { evt } );

      it( 'should call fire analytics event', () => {

        const callDescriptor = listenerSaga.next().value;
        expect( callDescriptor ).toEqual( call( fireAnalyticsEvent, evt ) );
      } );

      it( 'should put analyticsEventFired action', () => {

        const putDescriptor = listenerSaga.next().value;
        expect( putDescriptor ).toEqual( put( analyticsEventFired( evt ) ) );
      } );

      it( 'should put a failure event if no data is returned from the service', () => {

        const listenerSaga = analyticsSagaListener( '' );
        const putDescriptor = listenerSaga.next().value;
        expect( putDescriptor ).toEqual( put( analyticsEventFailure( 'insufficient data to trigger analytics event' ) ) );
      } );
      it( 'should put a failure event if no data is returned from the service', () => {

        let err = {
          statusText:'some failure message'
        }
        const putDescriptor = listenerSaga.throw( err ).value;
        expect( putDescriptor ).toEqual( put( analyticsEventFailure( err ) ) );
      } );
    } );
  } );

  describe( 'handleSetDataLayer function', () => {

    const action = {
      data: {
        globalPageData: ''
      }
    };
    const setDataLayerFunction = handleSetDataLayer( action );

    it( 'should call updateDataLayer event', () => {

      const callDescriptor = setDataLayerFunction.next().value;
      expect( callDescriptor ).toEqual( call( updateDataLayer, action.data ) );
    } );

    it( 'should put dataLayerUpdated action', () => {

      const putDescriptor = setDataLayerFunction.next().value;
      expect( putDescriptor ).toEqual( put( dataLayerUpdated( action.data ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const setDataLayerFunction = handleSetDataLayer( '' );
      const putDescriptor = setDataLayerFunction.next().value;
      expect( putDescriptor ).toEqual( put( dataLayerUpdateFailed( 'insufficient data to udpate data layer' ) ) );
    } );
    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = setDataLayerFunction.throw( err ).value;
      expect( putDescriptor ).toEqual( put( dataLayerUpdateFailed( err ) ) );
      expect( () => {
        setDataLayerFunction.next()
      } ).toThrow();
    } );

  } );

} );
