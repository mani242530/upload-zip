import {
  takeLatest, takeEvery, call, put
} from 'redux-saga/effects';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition,
  pageRedirect,
  checkoutRedirectListener
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { ajax } from '../../utils/ajax/ajax';
import saga, { listener } from './apply_express_paypal_payment.controller';


describe( 'applyExpressPayPalPayment Saga', () => {

  jest.mock( '../../utils/ajax/ajax', ()=>{
    return { ajax:jest.fn() }
  } );
  const type = 'applyExpressPayPalPayment';
  registerServiceName( type );

  describe( 'default saga', () =>{

    const coreSaga = saga();

    it( 'should listen for the applyPayPalPayment requested method', () =>{

      const takeLatestDescriptor = coreSaga.next().value;

      expect( takeLatestDescriptor ).toEqual( [
        takeEvery( getServiceType( 'applyExpressPayPalPayment', 'requested' ), listener, type )
      ] );
    } );

  } );

  describe( 'listener saga success and error path', () =>{

    const data = {
      data: {
        nonce : '',
        details: {
          email:'test',
          payerId: 'LUT2LJSVTJR5N',
          firstName:'test',
          lastName:'test',
          billingAddress :{
            line1:'700 keeaumoku st',
            line2:'',
            city:'Honolulu',
            state:'HI',
            countryCode:'',
            postalCode:'96814'
          },
          shippingAddress: {
            recipientName: 'test test',
            line1:'700 keeaumoku st',
            line2:'',
            city:'Honolulu',
            state:'HI',
            countryCode:'',
            postalCode:'96814'
          },
          phone:''
        },
        history: undefined
      }
    }
    const values = {
      nonce : '',
      email:'test',
      payerId: 'LUT2LJSVTJR5N',
      paymentType: 'paypal',
      firstName:'test',
      lastName:'test',
      address1:'700 keeaumoku st',
      address2:'',
      city:'Honolulu',
      state:'HI',
      country:'',
      postalCode:'96814',
      phoneNumber:'',
      shipFirstName: 'test',
      shipLastName: 'test',
      shipAddressLine1: '700 keeaumoku st',
      shipAddressLine2: '',
      shipCity: 'Honolulu',
      shipState: 'HI',
      shipCountry: '',
      shipPostalCode: '96814',
      shipPhoneNumber: ''
    }
    const listenerSaga = listener( type, data );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        status: 'ok',
        body: {
          data:{
            cartSummary: {
              itemCount: '3'
            },
            messages: 'test'
          }
        }
      }
      const {
        pathname
      } = '';
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );
    it( 'After the success event - redirect to checkout', () => {

      const putDescriptor = listenerSaga.next().value;
      const res = {
        status: 'ok',
        body: {
          data:{
            cartSummary: {
              itemCount: '3'
            },
            messages: 'test'
          }
        }
      }
      const {
        pathname
      } = '';
      const qty = 3;
      const loadCartMessages = 'test';

      expect( putDescriptor ).toEqual( put( checkoutRedirectListener( data.history, qty, loadCartMessages ) ) );
    } );
    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

  describe( 'listener saga success and error path', () =>{

    const action = {
      data: {
        nonce : '',
        details: {
          email:'test',
          payerId: 'LUT2LJSVTJR5N',
          firstName:'test',
          lastName:'test',
          billingAddress :{
            line1:'700 keeaumoku st',
            line2:'',
            city:'Honolulu',
            state:'HI',
            countryCode:'',
            postalCode:'96814'
          },
          shippingAddress: {
            recipientName: 'test test',
            line1:'700 keeaumoku st',
            line2:'',
            city:'Honolulu',
            state:'HI',
            countryCode:'',
            postalCode:'96814'
          },
          phone:''
        },
        history: {
          location: {
            'pathname': '/bag'
          },
          replace:jest.fn()
        }
      }
    }
    const values = {
      nonce : '',
      email:'test',
      payerId: 'LUT2LJSVTJR5N',
      paymentType: 'paypal',
      firstName:'test',
      lastName:'test',
      address1:'700 keeaumoku st',
      address2:'',
      city:'Honolulu',
      state:'HI',
      country:'',
      postalCode:'96814',
      phoneNumber:'',
      shipFirstName: 'test',
      shipLastName: 'test',
      shipAddressLine1: '700 keeaumoku st',
      shipAddressLine2: '',
      shipCity: 'Honolulu',
      shipState: 'HI',
      shipCountry: '',
      shipPostalCode: '96814',
      shipPhoneNumber: ''
    }
    const listenerSaga = listener( type, action );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        status: 'ok',
        body: {
          data :{
            result:'true'
          }
        }
      }
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'After the success event should redirect to checkout', () => {
      const pathname = '/bag';
      const checkoutPath = '/checkout';
      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( pageRedirect( pathname, checkoutPath ) ) );
    } );
  } );


} );
