/**
 * Created by rush on 5/16/17.
 */
import {
  takeEvery, take, call, put
} from 'redux-saga/effects';
import { delay } from 'redux-saga';


import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import { cloneableGenerator } from 'redux-saga/utils';
import {
  ajax
} from '../../utils/ajax/ajax';

import saga, { listener } from './apply_form_credit_card.controller';

const type = 'applyForm';
const UserserviceType = 'user';
const preapprovedServiceType = 'prescreenApply';

describe( 'defaultSaga Saga', () => {
  registerServiceName( type );
  registerServiceName( UserserviceType );
  registerServiceName( preapprovedServiceType );
  describe( 'default saga', () => {

    const applyformcreditcardsaga = saga();
    it( 'should listen for the navigation request method', () => {
      const takeEveryDescriptor = applyformcreditcardsaga.next().value;
      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), listener, type )
      );
    } );

    it( 'should listen for the preapprovedServiceType request method', () => {
      const takeEveryDescriptor = applyformcreditcardsaga.next().value;
      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( preapprovedServiceType, 'requested' ), listener, preapprovedServiceType )
      );
    } );

  } );
  describe( 'listener saga success path', () => {

    const action = {
      data: {
        history:{
          replace :jest.fn()
        }
      }
    }

    // const listenerSaga = listener( type, action );
    const listenerSaga = cloneableGenerator( listener )( type, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should call a delay when submitting the form', () => {
      const delayDescriptor = listenerSaga.next().value;
      expect( delayDescriptor ).toEqual( call( delay, 2000 ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      let method = 'post';
      let values;

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );

    } );
    let listenerSagaCloneRes01 ;
    let listenerSagaCloneRes02 ;
    let listenerSagaCloneRes03 ;
    let listenerSagaCloneRes04 ;
    let listenerSagaCloneRes05 ;
    let listenerSagaCloneRes06 ;
    it( 'should put a success event after data is called', () => {
      listenerSagaCloneRes01 = listenerSaga.clone();
      listenerSagaCloneRes02 = listenerSaga.clone();
      listenerSagaCloneRes03 = listenerSaga.clone();
      listenerSagaCloneRes04 = listenerSaga.clone();
      listenerSagaCloneRes05 = listenerSaga.clone();
      listenerSagaCloneRes06 = listenerSaga.clone();
      let res = {
        title: 'test',
        status: 'ok',
        instantCreditResponse:{
          responseType: '01'
        }
      }

      const putDescriptor = listenerSaga.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );

    } );
    it( 'should put a user request event after data received and response have instantCreditResponse ', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'user', 'requested' )() ) );

    } );

    it( 'should put a success event after user request data is called ', () => {

      const serviceType = listenerSaga.next( ).value;
      expect( serviceType ).toEqual( take( getServiceType( 'user', 'success' ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'listener saga success path for responseType = 01', () => {

      let res = {
        title: 'test',
        status: 'ok',
        instantCreditResponse:{
          responseType: '01'
        }
      }

      const putDescriptor = listenerSagaCloneRes01.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
      listenerSagaCloneRes01.next();
      listenerSagaCloneRes01.next();
      const profileData = {
        data:{}
      }

      listenerSagaCloneRes01.next( { profileData:profileData } );
      expect( action.data.history.replace ).toHaveBeenCalled();

    } );

    it( 'listener saga success path for responseType = 02', () => {

      let res = {
        title: 'test',
        status: 'ok',
        instantCreditResponse:{
          responseType: '02'
        }
      }

      const putDescriptor = listenerSagaCloneRes02.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
      listenerSagaCloneRes02.next();
      listenerSagaCloneRes02.next();
      const profileData = {
        data:{}
      }

      listenerSagaCloneRes02.next( { profileData:profileData } );
      expect( action.data.history.replace ).toHaveBeenCalled();

    } );

    it( 'listener saga success path for responseType = 03', () => {

      let res = {
        title: 'test',
        status: 'ok',
        instantCreditResponse:{
          responseType: '03'
        }
      }

      const putDescriptor = listenerSagaCloneRes03.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
      listenerSagaCloneRes03.next();
      listenerSagaCloneRes03.next();
      const profileData = {
        data:{}
      }

      listenerSagaCloneRes03.next( { profileData:profileData } );
      expect( action.data.history.replace ).toHaveBeenCalled();

    } );

    it( 'listener saga success path for responseType = 04', () => {

      let res = {
        title: 'test',
        status: 'ok',
        instantCreditResponse:{
          responseType: '04'
        }
      }

      const putDescriptor = listenerSagaCloneRes04.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
      listenerSagaCloneRes04.next();
      listenerSagaCloneRes04.next();
      const profileData = {
        data:{}
      }

      listenerSagaCloneRes04.next( { profileData:profileData } );
      expect( action.data.history.replace ).toHaveBeenCalled();

    } );

    it( 'listener saga success path for responseType = 05', () => {

      let res = {
        title: 'test',
        status: 'ok',
        instantCreditResponse:{
          responseType: '05'
        }
      }

      const putDescriptor = listenerSagaCloneRes05.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
      listenerSagaCloneRes05.next();
      listenerSagaCloneRes05.next();
      const profileData = {
        data:{}
      }

      listenerSagaCloneRes05.next( { profileData:profileData } );
      expect( action.data.history.replace ).toHaveBeenCalled();

    } );

    it( 'listener saga success path for responseType = 06', () => {

      let res = {
        title: 'test',
        status: 'ok',
        instantCreditResponse:{
          responseType: '06'
        }
      }

      const putDescriptor = listenerSagaCloneRes06.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
      listenerSagaCloneRes06.next();
      listenerSagaCloneRes06.next();
      const profileData = {
        data:{}
      }

      listenerSagaCloneRes06.next( { profileData:profileData } );
      expect( action.data.history.replace ).toHaveBeenCalled();

    } );

  } );

} )
