import {
  takeLatest, takeEvery, call, put
} from 'redux-saga/effects';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { ajax } from '../../utils/ajax/ajax';
import saga, { listener } from './apply_paypal_payment.controller';

describe( 'applyPayPalPayment Saga', () => {

  jest.mock( '../../utils/ajax/ajax', ()=>{
    return { ajax:jest.fn() }
  } );
  const type = 'applyPayPalPayment';
  registerServiceName( type );

  describe( 'default saga', () =>{

    const coreSaga = saga();

    it( 'should listen for the applyPayPalPayment requested method', () =>{

      const takeLatestDescriptor = coreSaga.next().value;

      expect( takeLatestDescriptor ).toEqual( [
        takeEvery( getServiceType( 'applyPayPalPayment', 'requested' ), listener, type )
      ] );
    } );

  } );

  describe( 'listener saga success and error path', () =>{

    const data = {
      data: {
        nonce : '',
        details: {
          email:'test',
          firstName:'test',
          lastName:'test',
          billingAddress :{
            line1:'700 keeaumoku st',
            line2:'',
            city:'Honolulu',
            state:'HI',
            countryCode:'',
            postalCode:'96814'
          },
          phone:''
        }
      }
    }
    const values = {
      nonce : '',
      email:'test',
      paymentType: 'paypal',
      firstName:'test',
      lastName:'test',
      address1:'700 keeaumoku st',
      address2:'',
      city:'Honolulu',
      state:'HI',
      country:'',
      postalCode:'96814',
      phoneNumber:''
    }
    const listenerSaga = listener( type, data );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        body:{
          data :{
            status: 'ok'
          }
        }
      }
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );
  } );
} );
