/**
 * Created by rush on 5/3/17.
 */
import {
  takeEvery, call, put, take, select, cancel, cancelled
} from 'redux-saga/effects';

import {
  host,
  fullyQualifyLink
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import find from 'lodash/find';

import {
  registerServiceName,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { getUserState } from '../../models/view/user/user.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';

import getHistory from '../../utils/history/history';
import { saveAuthSuccessUrlDetails } from '../../utils/local_storage/local_storage';




export const authorize = function* ( type, CONFIG, action ){
  try {

    yield put( getActionDefinition( type, 'loading' )( action.data ) );

    const history = getHistory();

    // forceAuthorize will come as true only for case when a service returns a 401
    let authorizeUrl = action.data.forceAuthorize;

    // if forceAuthorize is not true, then we need to check if the user has access to the url being loaded
    if( !action.data.forceAuthorize ){

      const userData = yield select( getUserState );
      // if the user is a softLoginUser, then a check is done if the URL is a restricted URL
      // i.e a URL restricted for soft login users
      if( userData.isSoftLoginUser ){
        authorizeUrl = yield call( isRestrictedUrl, action.data.url );
      }
    }

    // if the URL is to be authorzied, the url which the user is trying to access will be saved in localstorage
    // and the user will be redirected to the reauthorize screen, where the user will have to enter the password
    if( authorizeUrl ){
      const secureEntry = {
        url: action.data.url + ( action.data.search || '' )
      }

      saveAuthSuccessUrlDetails( secureEntry );
      const reauthorizeUrl = fullyQualifyLink( host, '/myaccount/reauthorize' );
      // if the original action was replace or load, the reauthorize page will also be loaded by invoking the replace method
      // this will help to take care of navigation through back button, as the original intent was to skip the current url from history
      // using replace over here will help acheive the same
      if( action.data.action === 'replace' || action.data.action === 'load' ){
        global.location.replace( reauthorizeUrl );
      }
      else {
        global.location.assign( reauthorizeUrl );
      }

      yield cancel();
    }

    // if the user is not soft logged in or if the URL is not restricted, the URL will be allowed to be loaded
    // based on the original action, forceReplace or forcePush will be invoked, which will change the route
    // replace and push methods in the history object support an additional parameter which is the state
    // so we will be invoking the forceReplace and forceReplace methods as well passing the state object with which it was originally invoked
    if( action.data.action === 'replace' ){
      history.forceReplace( action.data.route, action.data.state );
    }
    else if( action.data.action === 'push' ){
      history.forcePush( action.data.route, action.data.state );
    }
    // action will come as pageLoad when the user has to be redirected to a new page
    // so in cases where it doesnt need to be authorized we redirect the page to the original requested url
    else if( action.data.action === 'pageLoad' ){
      global.location.href = fullyQualifyLink( host, action.data.url + ( action.data.search || '' ) );
    }

    yield put( getActionDefinition( type, 'success' )() );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    console.log( err ); // eslint-disable-line
  }
}

// this method will return true if the url is restricted for soft logged in users
export const isRestrictedUrl = function*( url ){

  const switchData = yield select( makeGetSwitchesData() );

  const restrictedUrls = switchData.switches.securePageList;

  const isRestricted = restrictedUrls.includes( url );

  return isRestricted;

}

export default function( CONFIG ){
  return function* (){
    let serviceType = 'authorize';
    // register events for the request
    registerServiceName( serviceType );

    yield takeEvery( 'AUTHORIZE_URL', authorize, serviceType, CONFIG );
  }
}
