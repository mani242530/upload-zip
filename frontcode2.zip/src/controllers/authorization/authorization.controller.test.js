
import {
  takeEvery,
  put,
  call,
  select,
  cancel
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import { cloneableGenerator } from 'redux-saga/utils';
import {
  host,
  fullyQualifyLink
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import find from 'lodash/find';
import { getUserState } from '../../models/view/user/user.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import saga, {
  authorize,
  isRestrictedUrl
} from './authorization.controller';
import CONFIG from '../../modules/myAccount/myAccount.config';
import { saveAuthSuccessUrlDetails } from '../../utils/local_storage/local_storage';
import getHistory from '../../utils/history/history';

jest.mock( 'ulta-fed-core/dist/js/utils/formatters/formatters', () => {
  return { fullyQualifyLink:jest.fn(), host: undefined }
} );

jest.mock( '../../utils/local_storage/local_storage', () => {
  return { saveAuthSuccessUrlDetails:jest.fn() }
} );

const type = 'authorize';

let history = getHistory();

describe( 'Authorization Saga', () => {

  registerServiceName( type );
  const authorizationSaga = saga( CONFIG )();

  describe( 'default saga', () => {
    it( 'should listen for the AUTHORIZE_URL event', () => {
      const takeEveryDescriptor = authorizationSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( 'AUTHORIZE_URL', authorize, type, CONFIG )
      );
    } );
  } );

  describe( 'authorize saga success path - action.data.action is neither replace nor push and forceAuthorize is undefined', () => {
    const action = {
      data: {
        action: undefined,
        url: '/checkout',
        route: '/home',
        forceAuthorize: undefined
      }
    };
    const authorizeSaga = cloneableGenerator( authorize )( type, CONFIG, action );
    let authorizeSagaClone1;
    let authorizeSagaClone2;

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = authorizeSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( action.data ) ) );
    } );

    it( 'should select getUserState event to fetch userData', () => {
      const selectDescriptor = authorizeSaga.next().value;
      authorizeSagaClone1 = authorizeSaga.clone();
      expect( selectDescriptor ).toEqual( select( getUserState ) );
    } );

    it( 'should not call isRestrictedUrl with url after select getUserState if userData.isSoftLoginUser is false', () => {
      const userData = {
        isSoftLoginUser: false
      }
      const putDescriptor = authorizeSagaClone1.next( userData ).value; // this is after select getUserState

      expect( putDescriptor ).not.toEqual( call( isRestrictedUrl, action.data.url ) );
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( ) ) );
      expect( authorizeSagaClone1.next().done ).toEqual( true );
    } );

    it( 'should call isRestrictedUrl with url after select getUserState if userData.isSoftLoginUser is true', () => {
      const userData = {
        isSoftLoginUser: true
      }
      const callDescriptor = authorizeSaga.next( userData ).value;
      authorizeSagaClone2 = authorizeSaga.clone();
      expect( callDescriptor ).toEqual( call( isRestrictedUrl, action.data.url ) );
    } );

    it( 'should put authorize success event after isRestrictedUrl call if isRestrictedUrl method returns entry as false', () => {
      const entry = false;
      const putDescriptor = authorizeSaga.next( entry ).value;

      expect( putDescriptor ).not.toEqual( cancel() );
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( ) ) );
      expect( authorizeSaga.next().done ).toEqual( true );
    } );

    it( 'should call saveAuthSuccessUrlDetails, fullyQualifyLink methods and cancel event after isRestrictedUrl call if isRestrictedUrl method returns entry as true', () => {
      let entry = { url:'/checkout' };
      const cancelDescriptor = authorizeSagaClone2.next( entry ).value; // this is after isRestrictedUrl call

      const secureEntry = {
        url: action.data.url
      }
      expect( saveAuthSuccessUrlDetails ).toHaveBeenCalledWith( secureEntry );
      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, '/myaccount/reauthorize' );
      expect( cancelDescriptor ).toEqual( cancel() );
    } );
  } );

  describe( 'authorize saga success path - action.data.action is neither replace nor push and forceAuthorize is true', () => {
    const action = {
      data: {
        action: undefined,
        url: '/checkout',
        route: '/home',
        search: '?test=test',
        forceAuthorize: true
      }
    };
    const authorizeSaga = authorize( type, CONFIG, action );

    it( 'should call saveAuthSuccessUrlDetails, fullyQualifyLink methods and cancel event after authorize loading event if forceAuthorize is true', () => {
      authorizeSaga.next( ); // this is authorize loading event
      const cancelDescriptor = authorizeSaga.next().value;

      const secureEntry = {
        url: action.data.url + action.data.search
      }
      expect( saveAuthSuccessUrlDetails ).toHaveBeenCalledWith( secureEntry );
      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, '/myaccount/reauthorize' );
      expect( cancelDescriptor ).toEqual( cancel() );
    } );
  } );

  describe( 'authorize saga success path - action.data.action is replace or load and forceAuthorize is true', () => {
    beforeEach( ()=> {
      global.location.assign = jest.fn();
      global.location.replace = jest.fn();
    } );
    const action = {
      data: {
        action: 'replace',
        url: '/creditcards',
        route: '/home',
        search: '?test=test',
        forceAuthorize: true
      }
    };
    const authorizeSaga =  cloneableGenerator( authorize )( type, CONFIG, action ); // authorize( type, CONFIG, action );
    const authorizeSaga1 = authorizeSaga.clone();
    const authorizeSaga2 = authorizeSaga.clone();

    it( 'should call location replace if action type is reload with fullyQualifyLink and cancel event after authorize loading event if forceAuthorize is true', () => {
      authorizeSaga.next( ); // this is authorize loading event
      const cancelDescriptor = authorizeSaga.next().value;

      expect( window.location.replace ).toHaveBeenCalled();
      expect( cancelDescriptor ).toEqual( cancel() );
    } );
    it( 'should call location replace if action type is load with fullyQualifyLink and cancel event after authorize loading event if forceAuthorize is true', () => {
      action.data.action = 'load';
      authorizeSaga1.next( ); // this is authorize loading event
      const cancelDescriptor = authorizeSaga1.next().value;

      expect( window.location.replace ).toHaveBeenCalled();
      expect( cancelDescriptor ).toEqual( cancel() );
    } );

    it( 'should call location assign if action type is niether load nor reload with fullyQualifyLink and cancel event after authorize loading event if forceAuthorize is false and is soft login user', () => {
      action.data.action = 'pageLoad';
      action.data.url = '/creditcards/c/application';

      authorizeSaga2.next( ); // this is authorize loading event
      const cancelDescriptor = authorizeSaga2.next( ).value; // cancel yield
      expect( window.location.assign ).toHaveBeenCalled();
      expect( cancelDescriptor ).toEqual( cancel() );
    } );

  } );

  describe( 'authorize saga success path - action.data.action is replace and forceAuthorize is undefined', () => {
    const action = {
      data: {
        action: 'replace',
        url: '/checkout',
        route: '/home',
        state:{ key:'value' },
        forceAuthorize: undefined
      }
    };
    const authorizeSaga = cloneableGenerator( authorize )( type, CONFIG, action );
    let authorizeSagaClone1;

    it( 'should call history.forceReplace with action.data.route after isRestrictedUrl call if userData.isSoftLoginUser is true', () => {
      const userData = {
        isSoftLoginUser: true
      }
      const entry = false;
      history.forceReplace = jest.fn();

      authorizeSaga.next( ); // this is authorize loading event
      authorizeSaga.next( ); // this is select getUserState event
      authorizeSagaClone1 = authorizeSaga.clone();
      authorizeSaga.next( userData ); // this is isRestrictedUrl call
      const putDescriptor = authorizeSaga.next( entry ).value;

      expect( history.forceReplace ).toHaveBeenCalledWith( action.data.route, action.data.state );
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( ) ) );
      expect( authorizeSaga.next().done ).toEqual( true );
    } );

    it( 'should call history.forceReplace with action.data.route after select getUserState event if userData.isSoftLoginUser is false', () => {
      const userData = {
        isSoftLoginUser: false
      }
      history.forceReplace = jest.fn();

      const putDescriptor = authorizeSagaClone1.next( userData ).value; // this is after select getUserState event

      expect( history.forceReplace ).toHaveBeenCalledWith( action.data.route, action.data.state );
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( ) ) );
      expect( authorizeSagaClone1.next().done ).toEqual( true );
    } );
  } );

  describe( 'authorize saga success path - action.data.action is push and forceAuthorize is undefined', () => {
    const action = {
      data: {
        action: 'push',
        url: '/checkout',
        route: '/home',
        state:{ key:'value' },
        forceAuthorize: undefined
      }
    };
    const authorizeSaga = cloneableGenerator( authorize )( type, CONFIG, action );
    let authorizeSagaClone1;

    it( 'should call history.push with action.data.route after isRestrictedUrl call if userData.isSoftLoginUser is true', () => {
      const userData = {
        isSoftLoginUser: true
      }
      const entry = false;
      history.forcePush = jest.fn();

      authorizeSaga.next( ); // this is authorize loading event
      authorizeSaga.next( ); // this is select getUserState event
      authorizeSagaClone1 = authorizeSaga.clone();
      authorizeSaga.next( userData ); // this is isRestrictedUrl call
      const putDescriptor = authorizeSaga.next( entry ).value;

      expect( history.forcePush ).toHaveBeenCalledWith( action.data.route, action.data.state );
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( ) ) );
      expect( authorizeSaga.next().done ).toEqual( true );
    } );

    it( 'should call history.push with action.data.route after select getUserState event if userData.isSoftLoginUser is false', () => {
      const userData = {
        isSoftLoginUser: false
      }
      history.forcePush = jest.fn();

      const putDescriptor = authorizeSagaClone1.next( userData ).value; // this is after select getUserState event

      expect( history.forcePush ).toHaveBeenCalledWith( action.data.route, action.data.state );
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( ) ) );
      expect( authorizeSagaClone1.next().done ).toEqual( true );
    } );
  } );

  describe( 'authorize saga success path - action.data.action is pageLoad and forceAuthorize is undefined', () => {
    const action = {
      data: {
        action: 'pageLoad',
        url: '/ulta/myaccount/rewards',
        search: '#bonus_offer',
        forceAuthorize: undefined
      }
    };
    const authorizeSaga = cloneableGenerator( authorize )( type, CONFIG, action );
    let authorizeSagaClone1;

    it( 'should call fullyQualifyLink with url and search param after isRestrictedUrl call if userData.isSoftLoginUser is true', () => {
      const userData = {
        isSoftLoginUser: true
      };

      authorizeSaga.next( ); // this is authorize loading event
      authorizeSaga.next( ); // this is select getUserState event
      authorizeSagaClone1 = authorizeSaga.clone();
      authorizeSaga.next( userData ); // this is isRestrictedUrl call
      const putDescriptor = authorizeSaga.next().value;

      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, '/ulta/myaccount/rewards#bonus_offer' );
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( ) ) );
      expect( authorizeSaga.next().done ).toEqual( true );
    } );

    it( 'should call fullyQualifyLink with url and search param after select getUserState event if userData.isSoftLoginUser is false', () => {
      const userData = {
        isSoftLoginUser: false
      }

      const putDescriptor = authorizeSagaClone1.next( userData ).value; // this is after select getUserState event
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( ) ) );
      expect( authorizeSagaClone1.next().done ).toEqual( true );
    } );
  } );


  describe( 'authorize saga failure path', () => {
    let action = {
      url:'/checkout'
    };
    const failureSaga = authorize( type, CONFIG, action );
    failureSaga.next();

    window.console = {
      log:jest.fn()
    }

    const err = {
      statusText:'some failure message'
    };

    it( 'should put a failure event if any error occurs during the sagas execution', () => {
      const putDescriptor = failureSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

    it( 'should log the error to the console', () => {
      failureSaga.next();
      expect( window.console.log ).toHaveBeenCalledWith( err );
    } );
  } );

  describe( 'isRestrictedUrl function', () => {
    const switchData = {
      switches:{
        securePageList:['/checkout', '/creditcards/c/application', '/ulta/myaccount/rewards']
      }
    }

    it( 'should return restricted url if url is present in the securePageList', () => {
      const securePageList = switchData.switches.securePageList;
      // we are fetching a random value from the securePageList
      const url = securePageList[ Math.floor( Math.random() * securePageList.length )];
      const isRestrictedUrlListener = isRestrictedUrl( url );
      const selectDescriptor = isRestrictedUrlListener.next().value;
      const isRestrictedUrlValue = isRestrictedUrlListener.next( switchData ).value;

      expect( JSON.stringify( selectDescriptor ) ).toBe( JSON.stringify( select( makeGetSwitchesData() ) ) );
      expect( isRestrictedUrlValue ).toEqual( true );
    } );

    it( 'should not return restricted url if url given is not in the securePageList', () => {
      const url = '/bag';

      const isRestrictedUrlListener = isRestrictedUrl( url );
      const selectDescriptor = isRestrictedUrlListener.next().value;
      const isRestrictedUrlValue = isRestrictedUrlListener.next( switchData ).value;

      expect( JSON.stringify( selectDescriptor ) ).toBe( JSON.stringify( select( makeGetSwitchesData() ) ) );
      expect( isRestrictedUrlValue ).toEqual( false );
    } );
  } );
} )