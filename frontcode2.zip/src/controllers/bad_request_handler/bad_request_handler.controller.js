import {
  takeEvery, take, call, put, select, cancel
} from 'redux-saga/effects';
import has from 'lodash/has';

import {
  openStatusErrorPopUp
} from 'ulta-fed-core/dist/js/events/global/global.events';
import {
  ajax
} from '../../utils/ajax/ajax';



export const errorManager = function*(){
  yield takeEvery( '*', watchAllBadRequests );
}

export const watchAllBadRequests = function*( action ){
  // We are looking for 400 and 403 status code because ATG out of the box detects malicious scripts and return 403 as the service status code
  if( has( action, 'data.status' ) && ( action.data.status === 400 || action.data.status === 403 ) ){
    yield put( openStatusErrorPopUp() );
  }
}
