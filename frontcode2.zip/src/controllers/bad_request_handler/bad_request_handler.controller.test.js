/**
 * BadRequestHandler  sagas
 */

import {
  takeEvery, call, put, select, take
} from 'redux-saga/effects';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  openStatusErrorPopUp
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { errorManager, watchAllBadRequests } from './bad_request_handler.controller';


import {
  ajax
} from '../../utils/ajax/ajax';



describe( 'errorManager Saga', () => {

  const errorManagerSaga = errorManager( );

  it( 'should invoke watchAllBadRequests', () => {
    const putDescriptor = errorManagerSaga.next().value;
    expect( putDescriptor ).toEqual( takeEvery( '*', watchAllBadRequests ) );
  } );

} )

describe( 'watchAllBadRequests Saga', () => {
  const action = {
    data:{
      status: 400
    }
  }
  const action1 = {
    data:{
      status: 403
    }
  }
  const watchAllBadRequestsSaga = watchAllBadRequests( action );
  const watchAllBadRequestsSaga1 = watchAllBadRequests( action1 );

  it( 'should put openStatusErrorPopUp action for 400 staus', () => {
    const putDescriptor = watchAllBadRequestsSaga.next().value;
    expect( putDescriptor ).toEqual( put( openStatusErrorPopUp() ) );
  } );

  it( 'should put openStatusErrorPopUp action for 403 staus', () => {
    const putDescriptor = watchAllBadRequestsSaga1.next().value;
    expect( putDescriptor ).toEqual( put( openStatusErrorPopUp() ) );
  } );

} )
