/**
 * Created by rush on 5/3/17.
 */
import {
  takeEvery, call, put, take, select, cancelled
} from 'redux-saga/effects';
import get from 'lodash/get';
import isNumber from 'lodash/isNumber';
import find from 'lodash/find';
import concat from 'lodash/concat';
import isEmpty from 'lodash/isEmpty';


import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';


import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getUserState } from '../../models/view/user/user.model';

import {
  loadLiveChat
} from '../../events/live_chat/live_chat.events';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import { loadCart } from '../load_cart/load_cart.controller';
import { getCartState } from '../../models/view/cart/cart.model';
import { getSaveForLaterState } from '../../models/view/save_for_later/save_for_later.model';



// Individual exports for testing
export const cart = function* ( type, CONFIG, action ){
  try {

    yield put( getActionDefinition( type, 'loading' )( action.data ) );
    // get global switch data to check the BOPIS flag turned on or not.
    const switchData = yield select( makeGetSwitchesData() );
    const userData = yield select( getUserState );
    const saveforLaterEnabled = userData.isSignedIn && get( switchData, 'switches.saveForLaterEnabled' );


    let saveForLaterResponse;
    let saveForLaterCount = 0;
    const loadCartType = 'loadCart';

    let cartData = yield call( loadCart, loadCartType, CONFIG, action );

    // save for later call needs to be triggered only if saveforLaterEnabled is enabled and saveForLaterItems doesn't exist in the state
    if( saveforLaterEnabled ){
      const saveForLaterState = yield select( getSaveForLaterState ) ;

      if( !saveForLaterState.saveForLaterItems ){
        yield put( getActionDefinition( 'saveForLater', 'requested' )() )
        saveForLaterResponse = yield take( getServiceType( 'saveForLater', 'success' ) );
        saveForLaterCount = get( saveForLaterResponse, 'data.totalNumRecs', 0 );
      }
      else {
        saveForLaterCount = saveForLaterState.saveForLaterQuantity;
      }
    }


    yield put( getActionDefinition( type, 'success' )( cartData ) );

    // hasPageNavigated flag will be true only on inital page load or if there is re-routing
    // pageNavigation event will be triggered only if hasPageNavigated flag is true
    if( action.data.hasPageNavigated ){

      // populateDataLayer will update the globalPageDaga
      yield call( populateDataLayer, cartData, saveForLaterCount );

      // will load livechat in cart page only if enableUltaChat is true
      if( switchData.switches.enableUltaChat ){
        yield put( loadLiveChat() );
      }
    }

    yield call( handleAnalytics, cartData );

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    console.log( err ); // eslint-disable-line

  }
  finally {

    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'canceled' )() );
    }
  }
}

export const populateDataLayer = function* ( cartData, saveForLaterCount ){

  const {
    cartSummary,
    cartItems,
    messages
  } = cartData;


  const isOrderBopisEligible = !!get( cartData, 'pickupStoreInfo.available' );

  // Analytics tracking code begin
  const giftItems = cartData.giftItems ? cartData.giftItems.items : []

  let cartContents = {};

  if( cartItems && cartItems.items ){
    cartContents = concat(
      ( cartItems.items.filter( cartItem => cartItem.displayType === 'default' ).map( ( commerceItem, index ) => {
        return {
          ...( commerceItem.productId && { 'productId': commerceItem.productId } ),
          ...( commerceItem.catalogRefId && { 'skuId': commerceItem.catalogRefId } ),
          ...( commerceItem.productDisplayName && { 'productName': commerceItem.productDisplayName } ),
          'pageURL': '/bag/',
          ...( commerceItem.brandName && { 'manufacturer': commerceItem.brandName } ),
          ...( commerceItem.productURL && { 'pageURL': commerceItem.productURL } ),
          ...( commerceItem.imageURL && { 'imageURL': commerceItem.imageURL } ),
          ...( commerceItem.priceInfo.salePrice && { 'unit_sale_price': commerceItem.priceInfo.salePrice } ),
          ...( commerceItem.quantity && { 'quantity': commerceItem.quantity } ),
          ...( commerceItem.priceInfo.regularPrice && { 'price': commerceItem.priceInfo.regularPrice.replace( '$', '' ) } ),
          ...( commerceItem.adbugMessageMap !== null && { 'promotions': commerceItem.adbugMessageMap.adbugMessage } )
        };
      } ) ),
      giftItems.filter( ( giftObject ) => {
        return ( find( giftObject.freeGifts, { 'selected': 'true' } ) )
      } ).map( ( filteredGifts ) => {
        const temp = find( filteredGifts.freeGifts, { 'selected': 'true' } )
        return {
          ...( temp.giftCatalogRefId && { 'skuId': temp.giftCatalogRefId } ),
          ...( temp.giftDisplayName && { 'productName': temp.giftDisplayName } ),
          ...( temp.giftBrandName && { 'manufacturer': temp.giftBrandName } ),
          ...( temp.giftPDPUrl && { 'pageURL': temp.giftPDPUrl } ),
          ...( temp.giftImageURL && { 'imageURL': temp.giftImageURL } )
        }
      } )
    );
  }



  const data = {
    'globalPageData': {
      'navigation': {
        ...globalPageData.navigation,
        'pageName': ( parseInt( cartSummary.itemCount, 10 ) > 0 ? 'bag' : 'empty bag' ),
        'channel' : 'checkout',
        'pageType' : 'bag'
      },
      'order': {
        'currency': cartSummary.currencyCode,
        'total': ( cartSummary.estimatedTotal ).toFixed( 2 ),
        'subtotal': ( cartSummary.subTotal ).toFixed( 2 ),
        'shipping': ( isNumber( cartSummary.shippingCost ) ? ( cartSummary.shippingCost ).toFixed( 2 ) : cartSummary.shippingCost ),
        'itemCount': cartSummary.itemCount,
        'voucher_discount': cartSummary.couponDiscount,
        'orderItems': cartContents
      },
      'cart': {
        'bopisEligible':isOrderBopisEligible.toString(),
        'saveForLaterCount':saveForLaterCount.toString()
      },
      'messages': messages
    }
  }
  const evt = {
    'name': 'pageNavigation'
  }
  yield put( setDataLayer( data, evt ) );

}

export const handleAnalytics = function* ( cartData ){

  // update remove items in data layer
  let removedItemsData = cartData.cartItems?.items.filter( cartItem => cartItem.displayType === 'removed' ).map( ( product ) => {
    return {
      'skuId': product.catalogRefId,
      'quantityRemoved': product.quantity.value,
      'reasonForRemoval': product.messages.items.map( item => ( item.message ) ).toString()
    };
  } ) ;

  if( !isEmpty( removedItemsData ) ){
    const data = {
      'globalPageData': {
        'cart': {
          'autoRemovedItems':removedItemsData
        }
      }
    }
    const evt = {
      'name': 'autoRemovedItems'
    }
    // Update globalPageData with data passed and trigger the event (autoRemovedItems)
    yield put( setDataLayer( data, evt ) );
  }
}

// This method will refresh the cart when quick shop add to bag is success
export const refreshCart = function* ( serviceType, CONFIG, action ){
  yield call( cart, serviceType, CONFIG, action )
}
export default function( CONFIG ){
  return function* (){
    let serviceType = 'cart';
    // register events for the request
    registerServiceName( serviceType );
    yield takeEvery( getServiceType( 'cart', 'requested' ), cart, serviceType, CONFIG );
    yield takeEvery( getServiceType( 'qsAddItem', 'success' ), refreshCart, serviceType, CONFIG );
  }
}
