/**
 * Created on 26/11/18.
 */

/**
 * Cart  sagas
 */
import { cloneableGenerator } from 'redux-saga/utils';
import {
  takeEvery,
  call,
  take,
  put,
  select,
  cancelled
} from 'redux-saga/effects';


import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getUserState } from '../../models/view/user/user.model';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';


import {
  loadLiveChat
} from '../../events/live_chat/live_chat.events';
import saga, {
  cart,
  refreshCart,
  handleAnalytics,
  populateDataLayer
} from './cart.controller';
import { getSaveForLaterState } from '../../models/view/save_for_later/save_for_later.model';
import CONFIG from '../../modules/ccr/ccr.config';
import { loadCart } from '../load_cart/load_cart.controller';


jest.mock( '../../utils/ajax/ajax', ()=>{
  return {
    ajax:jest.fn()
  }
} );

jest.mock( '../../utils/local_storage/local_storage', ()=>{
  return { retrieveExternalAddInput:()=> 'addToBag' }
} );

const prodRecsServiceType = 'productRecs';
registerServiceName( prodRecsServiceType );

const loadCartServiceType = 'loadCart'
registerServiceName( loadCartServiceType );

const saveForLaterServiceType = 'saveForLater';
registerServiceName( saveForLaterServiceType );

describe( 'Cart sagas', () => {

  const type = 'cart';

  registerServiceName( type );
  registerServiceName( 'cartPickupInfoUpdate' );

  const cartSaga = saga( CONFIG )();

  it( 'should listen to cart service calls', () => {

    const takeEveryDescriptor = cartSaga.next().value;

    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), cart, type, CONFIG ) );

  } );
  it( 'should listen to quickshop add item success calls', () => {

    const takeEveryDescriptor = cartSaga.next().value;

    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( 'qsAddItem', 'success' ), refreshCart, type, CONFIG ) );

  } );


  describe( 'populateDataLayer listener', () => {

    window.globalPageData = {
      navigation: {
        location : 'bag:save for later'
      }
    }
    const saveForLaterCount = 1;
    const cartData = {
      cartSummary: {
        shippingCost: 'FREE',
        subTotal: 286,
        itemCount: 5,
        orderGiftWrapAmt: 0,
        additionalDiscount: null,
        couponDiscount: 0,
        estimatedTax: 'TBD',
        estimatedTotal: 286,
        currencyCode: 'USD',
        couponCode: null
      },
      messages: {
        items: [
          {
            type: 'Info',
            message: 'Looks like you have items in your bag from before. They\'ve been added below.'
          }
        ]
      },
      giftItems: {
        items: [{
          freeGifts: [{
            giftVariant: 'Signature Black',
            giftPDPUrl: '/go-curl-pocket-curler-pink?productId=xlsImpprod641081&sku=2161712',
            giftCatalogRefId: '2161712',
            giftDisplayName: 'Go Curl Pocket Curler - Pink',
            giftImageURL: 'http://images.ulta.com/is/image/Ulta/2161712?$sm$',
            selected: 'false',
            giftBrandName: 'Japonesque'
          },
          {
            giftVariant: 'Signature Red',
            giftPDPUrl: '/slant-tweezer?productId=prod2041233&sku=2145941',
            giftCatalogRefId: '2145941',
            giftDisplayName: 'Slant Tweezer',
            giftImageURL: 'http://images.ulta.com/is/image/Ulta/2145941?$sm$',
            selected: 'false',
            giftBrandName: 'Tweezerman'
          },
          {
            giftVariant: '1.7 oz',
            giftPDPUrl: '/eternity-men-eau-de-toilette?productId=2232&sku=2023775',
            giftCatalogRefId: '2023775',
            giftDisplayName: 'Eternity for Men Eau de Toilette',
            giftImageURL: 'http://images.ulta.com/is/image/Ulta/2023775?$sm$',
            selected: 'default',
            giftBrandName: 'Calvin Klein'
          }],
          promoValidity: 'offer valid 03/11/2015-12/30/2018 or while supplies last',
          bfxPriceMap: null,
          promoId: '0000071454',
          induldge: true
        },
        {
          freeGifts: [{
            giftPDPUrl: '/brazilliance-maracuja-self-tanner-mitt?productId=xlsImpprod5250035&sku=2258052',
            giftCatalogRefId: '2258052',
            giftDisplayName: 'Brazilliance Maracuja Self-Tanner & Mitt',
            giftImageURL: 'http://images.ulta.com/is/image/Ulta/2258052?$sm$',
            selected: 'true',
            giftBrandName: 'Tarte'
          },
          {
            giftPDPUrl: '/brazilliance-maracuja-self-tanner-mitt?productId=xlsImpprod5250035&sku=2258052',
            giftCatalogRefId: '2258052',
            giftDisplayName: 'Brazilliance Maracuja Self-Tanner & Mitt',
            giftImageURL: 'http://images.ulta.com/is/image/Ulta/2258052?$sm$',
            selected: 'default',
            giftBrandName: 'Tarte'
          }],
          promoValidity: 'offer valid 04/24/2017-07/31/2017 or while supplies last',
          bfxPriceMap: [
            {
              bfxQty: '1',
              bfxPrice: '$0.00'
            }
          ],
          promoId: '1000014332',
          induldge: true
        }]
      },
      cartItems: {
        items: [
          {
            displayType: 'removed',
            messages:{
              items:[
                {
                  type:'Info',
                  message:'Out of Stock'
                }
              ]
            },
            couponApplied: false,
            brandName: 'OPI',
            quantity: {
              value:2
            },
            productId: 'xlsImpprod13631063',
            excludedFromCoupon: false,
            adbugMessageMap: {
              adbugMessage: null,
              promoUrl: 'https://qa3.ulta.com/ulta/promotion/buy-more-save-more/detail/0000153130'
            },
            catalogRefId: '2299339',
            categoryName: 'Nail Polish',
            discountMessage: '',
            errorMsg: '',
            commerceItemid: 'ci14980000220',
            priceInfo: {
              salePrice: '$10.00',
              regularPrice: '$20.00',
              bfxPriceMap: [
                {
                  bfxQty: '2.0',
                  bfxPrice: '$5.00'
                }
              ],
              unitPriceMessage: '2 @ $5.00'
            },
            productDisplayName: 'New Orleans Nail Lacquer Collection',
            imageURL: 'https://images.ulta.com/is/image/Ulta/2299339?$md$',
            variantInfo: {
              Color: 'Spare Me A French Quarter? (mellowed raspberry crÃ¨me)'
            },
            skuDisplayName: 'New Orleans Nail Lacquer Collection',
            shippingRestriction: 'Cannot ship to your selected address',
            maxQty: 10,
            productURL: '/new-orleans-nail-lacquer-collection?productId=xlsImpprod13631063&sku=2299339'
          },
          {
            displayType: 'default',
            couponApplied: false,
            brandName: 'Dior',
            quantity: 3,
            productId: 'xlsImpprod13231211',
            excludedFromCoupon: false,
            adbugMessageMap: {
              adbugMessage: null,
              promoUrl: 'https://qa3.ulta.com/ulta/promotion/buy-more-save-more/detail/0000153130'
            },
            catalogRefId: '2291498',
            categoryName: 'Cologne',
            discountMessage: '',
            errorMsg: '',
            commerceItemid: 'ci14980000221',
            priceInfo: {
              salePrice: null,
              regularPrice: '$276.00',
              bfxPriceMap: [
                {
                  bfxQty: '3',
                  bfxPrice: '$92.00'
                }
              ],
              unitPriceMessage: '3 @ $92.00'
            },
            productDisplayName: 'Dior Homme Eau for Men Eau de Toilette',
            imageURL: 'https://images.ulta.com/is/image/Ulta/2291498?$md$',
            variantInfo: {
              Size: '3.4 oz'
            },
            skuDisplayName: 'Dior Homme Eau for Men Eau de Toilette',
            shippingRestriction: 'Cannot ship to your selected address',
            maxQty: 3,
            productURL: '/dior-homme-eau-men-eau-de-toilette?productId=xlsImpprod13231211&sku=2291498'
          }
        ]
      }
    };
    let data = {
      'globalPageData': {
        'navigation': {
          'location' : 'bag:save for later',
          'pageName': 'bag',
          'channel': 'checkout',
          'pageType': 'bag'
        },
        'order': {
          'currency': 'USD',
          'total': '286.00',
          'subtotal': '286.00',
          'shipping': 'FREE',
          'itemCount': 5,
          'voucher_discount': 0,
          'orderItems': [
            {
              'productId': 'xlsImpprod13231211',
              'skuId': '2291498',
              'productName': 'Dior Homme Eau for Men Eau de Toilette',
              'pageURL': '/dior-homme-eau-men-eau-de-toilette?productId=xlsImpprod13231211&sku=2291498',
              'manufacturer': 'Dior',
              'imageURL': 'https://images.ulta.com/is/image/Ulta/2291498?$md$',
              'quantity': 3,
              'price': '276.00',
              'promotions': null
            },
            {
              'skuId': '2258052',
              'productName': 'Brazilliance Maracuja Self-Tanner & Mitt',
              'manufacturer': 'Tarte',
              'pageURL': '/brazilliance-maracuja-self-tanner-mitt?productId=xlsImpprod5250035&sku=2258052',
              'imageURL': 'http://images.ulta.com/is/image/Ulta/2258052?$sm$'
            }
          ]
        },
        'cart': {
          'bopisEligible':'false',
          'saveForLaterCount': '1'
        },
        'messages': {
          'items': [
            {
              'type': 'Info',
              'message': 'Looks like you have items in your bag from before. They\'ve been added below.'
            }
          ]
        }
      }
    };
    const populateDataLayerListener = populateDataLayer( cartData, saveForLaterCount );

    it( 'should put setDataLayer action with a non-numeric value for shipping cost i.e.Free', () => {
      const evt = {
        'name': 'pageNavigation'
      }
      const putDescriptor = populateDataLayerListener.next( ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
      expect( populateDataLayerListener.next().done ).toEqual( true );
    } );

    it( 'should put setDataLayer action with orderItems as empty and pageName as \'empty bag\' if there are no items in the cart', () => {
      const evt = {
        'name': 'pageNavigation'
      }
      const cartData = {

        cartSummary: {
          shippingCost: 'FREE',
          subTotal: 0,
          itemCount: 0,
          couponDiscount: 0,
          estimatedTotal: 0,
          currencyCode: 'USD'
        },
        messages: null,
        cartItems: null

      };

      let data = {
        'globalPageData': {
          'navigation': {
            'location' : 'bag:save for later',
            'pageName': 'empty bag',
            'channel': 'checkout',
            'pageType': 'bag'
          },
          'order': {
            'currency': 'USD',
            'total': '0.00',
            'subtotal': '0.00',
            'shipping': 'FREE',
            'itemCount': 0,
            'voucher_discount': 0,
            'orderItems': {}
          },
          'cart': {
            'bopisEligible':'false',
            'saveForLaterCount': '1'
          },
          'messages': null
        }
      };
      const populateDataLayerListener2 = populateDataLayer( cartData, saveForLaterCount );
      const putDescriptor = populateDataLayerListener2.next( ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
      expect( populateDataLayerListener2.next().done ).toEqual( true );

    } );

    it( 'should put setDataLayer action with orderItems as empty, if there are only removed items in the cart', () => {
      const cartData = {
        cartSummary: {
          shippingCost: 'FREE',
          subTotal: 0,
          itemCount: 0,
          couponDiscount: 0,
          estimatedTotal: 0,
          currencyCode: 'USD'
        },
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Item(s) were removed'
            }
          ]
        },
        cartItems: {
          items: [
            {
              displayType: 'removed',
              messages:{
                items:[
                  {
                    type:'Info',
                    message:'Out of Stock'
                  }
                ]
              },
              brandName: 'OPI',
              quantity: {
                value:2
              },
              productId: 'xlsImpprod13631063',
              adbugMessageMap: {
                adbugMessage: null
              },
              catalogRefId: '2299339',
              priceInfo: {
                salePrice: '$10.00',
                regularPrice: '$20.00'
              },
              productDisplayName: 'New Orleans Nail Lacquer Collection',
              imageURL: 'https://images.ulta.com/is/image/Ulta/2299339?$md$',
              productURL: '/new-orleans-nail-lacquer-collection?productId=xlsImpprod13631063&sku=2299339'
            }
          ]
        }


      };

      let data = {
        'globalPageData': {
          'navigation': {
            'location' : 'bag:save for later',
            'pageName': 'empty bag',
            'channel': 'checkout',
            'pageType': 'bag'
          },
          'order': {
            'currency': 'USD',
            'total': '0.00',
            'subtotal': '0.00',
            'shipping': 'FREE',
            'itemCount': 0,
            'voucher_discount': 0,
            'orderItems': []
          },
          'cart': {
            'bopisEligible':'false',
            'saveForLaterCount': '1'
          },
          'messages': {
            'items': [
              {
                'type': 'Info',
                'message': 'Item(s) were removed'
              }
            ]
          }
        }
      };
      const evt = {
        'name': 'pageNavigation'
      }
      const populateDataLayerListener3 = populateDataLayer( cartData, saveForLaterCount );
      const putDescriptor = populateDataLayerListener3.next( ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
      expect( populateDataLayerListener3.next().done ).toEqual( true );

    } );

  } );

  describe( 'cart method success/failure path - action.data.hasPageNavigated is true', () => {
    const action = {
      data: {
        history: {
          location: {
            pathname: '/bag'
          }
        },
        hasPageNavigated: true
      }
    };
    const listenerSaga = cloneableGenerator( cart )( type, CONFIG, action );
    let listenerSagaClone1;
    let listenerSagaCloneA;
    let listenerSagaClone2;
    let listenerSagaClone3;

    it( 'should until the loading event has been put', () => {

      const putDescriptor  = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( action.data ) ) );

    } );
    it( 'Should dispatch select event makeGetSwitchesData to fetch the switchData details', () => {
      const callDescriptor  = listenerSaga.next().value;
      listenerSagaCloneA = listenerSaga.clone();
      expect( JSON.stringify( callDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'Should select getUserState event to fetch user data', () => {
      const switchData = {
        switches:{
          storePickupEnabled:true,
          saveForLaterEnabled:true,
          enableUltaChat: true
        }
      }
      const callDescriptor  = listenerSaga.next( switchData ).value;
      listenerSagaClone1 = listenerSaga.clone();
      expect( callDescriptor ).toEqual( select( getUserState ) );
    } );

    it( 'Should call loadcart method to fetch the cart details', () => {
      const userData = {
        isSignedIn : true
      }
      const loadCartType = 'loadCart';
      const saveForLaterState = {
        saveForLaterItems: null,
        saveForLaterQuantity: 12
      }
      const putDescriptor  = listenerSaga.next( userData ).value;
      expect( putDescriptor ).toEqual( call( loadCart, loadCartType, CONFIG, action ) );
    } );

    it( 'Should select getSaveForLaterState event to fetch saveForLater state', () => {
      let loadCartResponse = {
        cartSummary:{
          itemCount:1
        },
        pickupStoreInfo:{
          available:true
        }
      }
      const callDescriptor  = listenerSaga.next( loadCartResponse ).value;
      listenerSagaClone3 = listenerSaga.clone();
      expect( callDescriptor ).toEqual( select( getSaveForLaterState ) );
    } );

    it( 'should put cart success event after calling loadCart method for guest user', () => {
      const userData = {
        isSignedIn : false
      }
      listenerSagaClone1.next( userData ); // this is loadCart method call

      let loadCartResponse = {
        cartSummary:{
          itemCount:1
        },
        pickupStoreInfo:{
          available:true
        }
      }
      const putDescriptor  = listenerSagaClone1.next( loadCartResponse ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( loadCartResponse ) ) );
    } )

    it( 'should put saveForLater requested for signedIn user if saveforlater enabled flag is on', () => {
      let loadCartResponse = {
        cartSummary:{
          itemCount:1
        },
        pickupStoreInfo:{
          available:true
        }
      }
      const putDescriptor  = listenerSaga.next( loadCartResponse ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'saveForLater', 'requested' )() ) );
    } )

    it( 'should take saveForLater success event - wait for saveForLater response', () => {
      const takeDescriptor  = listenerSaga.next( ).value;
      listenerSagaClone2 = listenerSaga.clone();
      expect( takeDescriptor ).toEqual( take( getServiceType( 'saveForLater', 'success' ) ) );
    } )

    const cartData = {
      cartSummary:{
        itemCount:1
      },
      pickupStoreInfo:{
        available:true
      }
    }

    it( 'should put cart success event ', () => {
      const saveForLaterResponse = {
        data:{
          totalNumRecs:10
        }
      }
      const putDescriptor  = listenerSaga.next( saveForLaterResponse ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( cartData ) ) );
    } )

    it( 'should call populateDataLayer method - updates the globalPageDta ', () => {
      const saveForLaterCount = 10;
      const putDescriptor  = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( call( populateDataLayer, cartData, saveForLaterCount ) );

    } );

    it( 'Should call populateDataLayer with saveForLaterCount as 0 if saveForLaterItems is null and totalNumRecs is undefined in saveForLater success response', () => {
      const saveForLaterResponse = {
        data:{
          saveForLaterItems: null,
          messages: null,
          totalNumRecs: undefined
        }
      }

      listenerSagaClone2.next( saveForLaterResponse ); // this is cart success

      const saveForLaterCount = 0;
      const putDescriptor  = listenerSagaClone2.next( ).value;
      expect( putDescriptor ).toEqual( call( populateDataLayer, cartData, saveForLaterCount ) );
    } );

    it( 'Should call populateDataLayer with saveForLaterQuantity from response of getSaveForLaterState if saveForLaterItems is already present in state', () => {
      const saveForLaterState = {
        saveForLaterQuantity: 33,
        saveForLaterItems: {
          items:[
            { sku :'123' }
          ]
        }
      }

      listenerSagaClone3.next( saveForLaterState ); // this is cart success

      const saveForLaterCount = 33;
      const putDescriptor  = listenerSagaClone3.next( ).value;
      expect( putDescriptor ).toEqual( call( populateDataLayer, cartData, saveForLaterCount ) );
    } );

    it( 'should put event to load the liveChat', () => {

      const putDescriptor  = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( loadLiveChat() ) );
    } )

    it( 'should call handleAnalytics to trigger analytics event passing the cart details', () => {
      const putDescriptor  = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( call( handleAnalytics, cartData ) );
    } );

    it( 'should put a failure event if an error occurred', () => {
      const err = {
        statusText:'some failure message'
      };
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

    it( 'should call cart canceled event ', () => {
      const cancelDescriptor  = listenerSaga.next().value;
      expect( cancelDescriptor ).toEqual( cancelled() );
      expect( listenerSaga.next().done ).toEqual( true );
    } )

    it( 'Should select getUserState event to fetch user data even when enableUltaChat is false but should not load liveChat', () => {
      const switchData = {
        switches:{
          storePickupEnabled:true,
          saveForLaterEnabled:true,
          enableUltaChat: false
        }
      }
      const userData = {
        isSignedIn : true
      }
      let loadCartResponse = {
        cartSummary:{
          itemCount:1
        },
        pickupStoreInfo:{
          available:true
        }
      };
      const saveForLaterResponse = {
        data:{
          totalNumRecs:10
        }
      };
      const cartData = {
        cartSummary:{
          itemCount:1
        },
        pickupStoreInfo:{
          available:true
        }
      };
      const saveForLaterCount = 0;

      listenerSagaCloneA.next( switchData ); // this is select getUserState
      listenerSagaCloneA.next( userData ); // this is loadCart call
      listenerSagaCloneA.next( loadCartResponse ); //  this is select getSaveForLaterState
      listenerSagaCloneA.next( saveForLaterResponse ); // this is saveForLater success
      listenerSagaCloneA.next( ); // cart data requested
      listenerSagaCloneA.next( ); // cart data success
      expect( listenerSagaCloneA.next().value ).toEqual( call( populateDataLayer, cartData, saveForLaterCount ) ); // populateDataLayer
      const putDescriptor = listenerSagaCloneA.next( );
      expect( putDescriptor.value ).not.toEqual( put( loadLiveChat() ) );
      expect( putDescriptor.value ).toEqual( call( handleAnalytics, cartData ) );
      expect( putDescriptor.done ).toEqual( false );
    } );

  } );

  describe( 'cart method success path - action.data.isPageNavigation is false', () => {
    const action = {
      data: {
        history: {
          location: {
            pathname: '/bag'
          }
        },
        hasPageNavigated: false
      }
    };
    const listenerSaga = cloneableGenerator( cart )( type, CONFIG, action );

    const cartData = {
      cartSummary:{
        itemCount:1
      },
      pickupStoreInfo:{
        available:true
      }
    }

    it( 'should put cart success event ', () => {
      const switchData = {
        switches:{
          storePickupEnabled:true,
          saveForLaterEnabled:true,
          enableUltaChat: true
        }
      }

      const userData = {
        isSignedIn : true
      }

      const saveForLaterState = {
        saveForLaterItems: null
      }

      const loadCartResponse = {
        cartSummary:{
          itemCount:1
        },
        pickupStoreInfo:{
          available:true
        }
      }
      const saveForLaterResponse = {
        data:{
          totalNumRecs:10
        }
      }

      listenerSaga.next(); // this is cart loading
      listenerSaga.next(); // this is select makeGetSwitchesData
      listenerSaga.next( switchData ); // this is select getUserState
      listenerSaga.next( userData ); // this is loadCart call
      listenerSaga.next( loadCartResponse ); //  this is select getSaveForLaterState
      listenerSaga.next( saveForLaterState ); // this is saveForLater requested
      listenerSaga.next( saveForLaterResponse ); // this is saveForLater success

      const putDescriptor  = listenerSaga.next( saveForLaterResponse ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( cartData ) ) );
    } )

    it( 'should call handleAnalytics to trigger analytics event after cart success if action.data.hasPageNavigated is false', () => {
      const putDescriptor  = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( call( handleAnalytics, cartData ) );
    } );

    it( 'should call cart canceled event ', () => {
      const cancelDescriptor  = listenerSaga.next().value;
      expect( cancelDescriptor ).toEqual( cancelled() );
      expect( listenerSaga.next().done ).toEqual( true );
    } )

  } );

  describe( 'handleAnalytics test cases', () => {
    it( 'should put datalayer action with autoRemovedItems event if cartData.cartItems.items.displayType is removed', () => {
      const cartData = {
        cartItems: {
          items: [
            {
              displayType: 'removed',
              messages:{
                items:[
                  {
                    type:'Info',
                    message:'Out of Stock'
                  }
                ]
              },
              quantity: {
                value:2
              },
              catalogRefId: '2210015'
            }
          ]
        }
      }
      const handleAnalyticsListener = handleAnalytics( cartData );

      const evt = {
        'name': 'autoRemovedItems'
      }
      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': [
              {
                'skuId': '2210015',
                'reasonForRemoval': 'Out of Stock',
                'quantityRemoved': 2
              }
            ]
          }
        }
      }
      const putDescriptor = handleAnalyticsListener.next().value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
      expect( handleAnalyticsListener.next().done ).toEqual( true );
    } );

    it( 'should put datalayer action with reasonForRemoval as concanated message if cartData.cartItems.items.messages.items message is more than one', () => {
      const cartData = {
        cartItems: {
          items: [
            {
              displayType: 'removed',
              messages:{
                items:[
                  {
                    type:'Info',
                    message:'Out of Stock'
                  },
                  {
                    type:'Info',
                    message:'Item no longer available'
                  }
                ]
              },
              quantity: {
                value:2
              },
              catalogRefId: '2210015'
            }
          ]
        }
      }
      const handleAnalyticsListener = handleAnalytics( cartData );

      const evt = {
        'name': 'autoRemovedItems'
      }
      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': [
              {
                'skuId': '2210015',
                'reasonForRemoval': 'Out of Stock,Item no longer available',
                'quantityRemoved': 2
              }
            ]
          }
        }
      }
      const putDescriptor = handleAnalyticsListener.next().value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
      expect( handleAnalyticsListener.next().done ).toEqual( true );
    } );

    it( 'should not put datalayer action if cartData.cartItems.items.displayType is not removed', () => {
      const cartData = {
        cartItems: {
          items: [
            {
              displayType: 'default',
              messages:{
                items:[
                  {
                    type:'Info',
                    message:'Out of Stock'
                  }
                ]
              },
              quantity: {
                value:2
              },
              catalogRefId: '2210015'
            }
          ]
        }
      }
      const handleAnalyticsListener = handleAnalytics( cartData );
      const putDescriptor = handleAnalyticsListener.next();
      expect( putDescriptor.done ).toEqual( true );
    } );

    it( 'should not put datalayer action if cartData.cartItems.items is null', () => {
      const cartData = {
        cartItems: null
      }
      const handleAnalyticsListener = handleAnalytics( cartData );
      const putDescriptor = handleAnalyticsListener.next();
      expect( putDescriptor.done ).toEqual( true );
    } );
  } );
  describe( 'refreshCart test cases', () => {
    const action = {
      data: {
        history: {
          location: {
            pathname: '/bag'
          }
        },
        hasPageNavigated: true
      }
    }
    const listenerRefreshSaga = cloneableGenerator( refreshCart )( 'qsAddItem', CONFIG, action );
    it( 'should refresh the cart when item is added in empty cart page', () => {
      const callDescriptor  = listenerRefreshSaga.next().value;
      expect( callDescriptor ).toEqual( call( cart, 'qsAddItem', CONFIG, action ) );

    } );
  } );

} );
