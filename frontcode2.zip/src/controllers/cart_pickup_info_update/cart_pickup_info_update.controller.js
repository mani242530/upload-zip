import {
  takeEvery, call, put, cancel, cancelled, select
} from 'redux-saga/effects';

import {
  checkoutRedirectListener,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import isUndefined from 'lodash/isUndefined';
import has from 'lodash/has';
import { selectGlobal } from '../../models/view/global/global.model';
import {
  ajax
} from '../../utils/ajax/ajax';
import { getGeoLocation } from '../../utils/geo_location/geo_location';

// Individual exports for testing
export const cartPickupInfoUpdate = function*( type, CONFIG, data ){
  try {
    let isServiceCancelled = false;
    yield put( getActionDefinition( type, 'loading' )() );
    let values = {};
    if( process.env.NODE_ENV === 'development' ){
      values.__SHOW_PICKUP_OPTION = CONFIG.BOPIS.showPickupOption;
    }

    // Call Geo location & cartPickupInfoUpdate only if pickup store is not available
    if( !has( data, 'data.responseData.pickupStoreInfo' ) ){
      // get GEO location
      const global = yield select( selectGlobal );
      const position = yield call( getGeoLocation, global.switchData.switches.geoLocationTimeout );

      // call cartPickupInfoUpdate only if position is available
      if( !isUndefined( position ) ){

        values = {
          ...values,
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        };
      }
      else {
        // set isServiceCancelled flag to true, if user location not available or user block the location
        isServiceCancelled = true;
      }
    }
    if( isServiceCancelled ){
      // cancel saga if pickup store is already available or user position is not available
      yield cancel();
    }
    // Get cartPickupInfoUpdate which returns cart with pickup store info
    const res = yield call( ajax,
      {
        type,
        method:'post',
        values
      } );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );

    if( res.body.data ){
      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( checkoutRedirectListener( data.data.history, qty, loadCartMessages ) );
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
  finally {
    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'canceled' )() );
    }
  }
};

export default function( CONFIG ){
  return function* (){
    let serviceType = 'cartPickupInfoUpdate';
    // register events for the request
    registerServiceName( serviceType );
    yield takeEvery( getServiceType( 'cartPickupInfoUpdate', 'requested' ), cartPickupInfoUpdate, serviceType, CONFIG )

  }
}
