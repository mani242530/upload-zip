/**
 * CartPickupInfoUpdate sagas
 */

import { cloneableGenerator } from 'redux-saga/utils';

import {
  takeEvery,
  call,
  put,
  cancel,
  cancelled,
  select
} from 'redux-saga/effects';


import {
  checkoutRedirectListener,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  isEmpty,
  concat,
  find
} from 'lodash';
import { selectGlobal } from '../../models/view/global/global.model';
import { getGeoLocation } from '../../utils/geo_location/geo_location';
import { ajax } from '../../utils/ajax/ajax';
import saga, {
  cartPickupInfoUpdate
} from './cart_pickup_info_update.controller';
import CONFIG from '../../modules/ccr/ccr.config';

jest.mock( '../../utils/ajax/ajax', ()=>{
  return {
    ajax:jest.fn()
  }
} );

describe( 'CartPickupInfoUpdate sagas', () => {

  const type = 'cartPickupInfoUpdate';

  const res = {
    body: {
      data:{
        cartSummary: {
          shippingCost: 'FREE',
          subTotal: 286,
          itemCount: 5,
          orderGiftWrapAmt: 0,
          additionalDiscount: null,
          couponDiscount: 0,
          estimatedTax: 'TBD',
          estimatedTotal: 286,
          currencyCode: 'USD',
          couponCode: null
        },
        freeSamplesInfo: {},
        messages: {},
        giftItems: {},
        cartItems: {},
        deliveryOption: 'ship',
        pickupStoreInfo: {
          storeContactInfo: {
            displayName: 'Bolingbrook',
            email: 'test.store@ulta.com',
            phoneNumber: '(222) 222-2222',
            address: {
              address1: '641 East Boughtton Road, Suite 100',
              address2: '',
              city: 'Bolingbrook',
              state: 'IL',
              zipCode: 60440,
              country: 'US'
            }
          },
          storeTimings: '09:00 AM - 09:00PM',
          storeDistanceMiles: 2,
          storeId: 123
        }
      }
    }
  };

  const data = {
    data:{
      cartSummary: {
        shippingCost: 'FREE',
        subTotal: 286,
        itemCount: 5,
        orderGiftWrapAmt: 0,
        additionalDiscount: null,
        couponDiscount: 0,
        estimatedTax: 'TBD',
        estimatedTotal: 286,
        currencyCode: 'USD',
        couponCode: null
      },
      freeSamplesInfo: {},
      messages: {},
      giftItems: {},
      cartItems: {}
    }
  };

  const values = {
    latitude: 123,
    longitude: 456
  };

  describe( 'CartPickupInfoUpdate method success/failure path', () => {
    registerServiceName( type );

    const cartPickupInfoUpdateSaga = saga( CONFIG )();
    const pickupStoreNotAvailableSaga = cloneableGenerator( cartPickupInfoUpdate )( type, CONFIG, data );

    describe( 'pickup store info not available', () => {

      it( 'should listen to cartPickupInfoUpdate service calls', () => {
        const takeEveryDescriptor = cartPickupInfoUpdateSaga.next().value;
        expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), cartPickupInfoUpdate, type, CONFIG ) );
      } );

      it( 'should wait until the loading event has been put', () => {
        const putDescriptor  = pickupStoreNotAvailableSaga.next( ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
      } );

      it( 'should select selectGlobal', () => {
        const selectDescriptor = pickupStoreNotAvailableSaga.next( ).value;
        expect( selectDescriptor ).toEqual( select( selectGlobal ) );
      } );

      it( 'should call the getGeoLocation function', () => {
        const geoLocationTimeout = 90;
        const global = {
          switchData:{
            switches: {
              geoLocationTimeout
            }
          }
        }
        const callDescriptor = pickupStoreNotAvailableSaga.next( global ).value;
        expect( callDescriptor ).toEqual( call( getGeoLocation, geoLocationTimeout ) );
      } );

      it( 'should yield on requesting data and return that data with a sucess method', () => {
        const position = {
          coords: {
            latitude: 123,
            longitude: 456
          }
        };
        const callDescriptor = pickupStoreNotAvailableSaga.next( position ).value;
        const method = 'post';

        expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
      } );

      it( 'should put a success event after data is called', () => {
        const putDescriptor  = pickupStoreNotAvailableSaga.next( res ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
      } );

      it( 'should dispatch checkout redirect listener', () => {
        // create saga response
        let res = {
          body: {
            data: {
              cartSummary  : {
                shippingCost  : 5.95,
                subTotal  : 160.98999999999998,
                itemCount  : 5,
                orderGiftWrapAmt  : 3.99,
                additionalDiscount  : null,
                couponDiscount  : 0,
                estimatedTax  : 'TBD',
                estimatedTotal  : 170.93,
                currencyCode  : 'USD',
                rewardPointsEarned  :'100'
              },
              messages: {}
            }
          }
        };

        const putDescriptor = pickupStoreNotAvailableSaga.next( res ).value;
        expect( putDescriptor ).toEqual( put( checkoutRedirectListener( data.data.history, res.body.data.cartSummary.itemCount, res.body.data.messages ) ) );

      } );
    } );

    describe( 'pickup store info available if user location not available or user block the location', () => {
      const pickupStoreAvailableSaga = cloneableGenerator( cartPickupInfoUpdate )( type, CONFIG, { data: { ...data } } );
      it( 'should wait until the loading event has been put', () => {
        const putDescriptor  = pickupStoreAvailableSaga.next( ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
      } );

      it( 'should select selectGlobal', () => {
        const selectDescriptor = pickupStoreAvailableSaga.next( ).value;
        expect( selectDescriptor ).toEqual( select( selectGlobal ) );
      } );

      it( 'should call the getGeoLocation function', () => {
        const geoLocationTimeout = 90;
        const global = {
          switchData:{
            switches: {
              geoLocationTimeout
            }
          }
        }
        const callDescriptor = pickupStoreAvailableSaga.next( global ).value;
        expect( callDescriptor ).toEqual( call( getGeoLocation, geoLocationTimeout ) );
      } );

      it( 'should yield cancel method', () => {
        const position = undefined;
        const callDescriptor = pickupStoreAvailableSaga.next( position ).value;

        expect( callDescriptor ).toEqual( cancel() );
      } );

      it( 'should cancel the event if service calls are not performed', () => {
        pickupStoreAvailableSaga.next();
        pickupStoreAvailableSaga.next();
        const cancelDescriptor = pickupStoreAvailableSaga.next().value;
        expect( cancelDescriptor ).toEqual( cancelled() );
      } );
    } );

    describe( 'error case', () => {
      it( 'should put a failure event if no data is returned from the service', () => {
        global.TRACK_SAGA_FAILURES = true;
        const err = {
          statusText:'some failure message'
        };
        const putDescriptor = pickupStoreNotAvailableSaga.throw( err ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );

      it( 'should cancel the event if an error occured in the service', () => {
        const cancelDescriptor = pickupStoreNotAvailableSaga.next().value;
        expect( cancelDescriptor ).toEqual( cancelled() );
      } );

      it( 'should put a cancel action', () => {
        const putDescriptor = pickupStoreNotAvailableSaga.next( true, global ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'canceled' )() ) );
      } );
    } );
  } );
} );
