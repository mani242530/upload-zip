
import { takeEvery, call, put } from 'redux-saga/effects';
import isUndefined from 'lodash/isUndefined';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

// Individual exports for testing
export const listener = function*( type, data ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );

    let loyaltyMemberId = data.data.loyaltyMemberId;
    let values = {
      loyaltyMemberId:loyaltyMemberId
    };


    const res = yield call( ajax,
      {
        type,
        method:'post',
        values
      } );



    yield put( getActionDefinition( type, 'success' )( res.body.data ) );


    // Analytics tracking code begin
    if( !isUndefined( res.body.data ) ){

      let data = {};
      let evt = {};


      if( res.body.data.cartSummary ){
        // if cartSummary data is returned the member id was found.
        data = {
          'globalPageData': {
            'rewards': {
              'loyaltyId': loyaltyMemberId
            }
          }
        }

        evt = {
          'name': 'memberIDAdded'
        }

      }
      else {
        // if no cartSummary was found then the lookup failed
        data = {
          'globalPageData': {
            'messages': res.body.data.messages
          }
        }

        evt = {
          'name': 'serviceMessagesUpdated'
        }

      }

      yield put( setDataLayer( data, evt ) );


    }



  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'rewardsLookup';

  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
