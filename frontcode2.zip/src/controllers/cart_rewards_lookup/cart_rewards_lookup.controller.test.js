import { takeEvery, call, put } from 'redux-saga/effects';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';


import {
  ajax
} from '../../utils/ajax/ajax';
import saga, { listener } from './cart_rewards_lookup.controller';



const type  = 'rewardsLookup';



describe( 'rewardsLookup Saga', () => {
  registerServiceName( type );

  const rewardsLookupsaga = saga();

  it( 'should listen for the navigation request method', () => {

    const takeEveryDescriptor = rewardsLookupsaga.next().value;
    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );
  } );

  describe( 'listener saga success path', () => {

    const data = {
      'data': {
        'loyaltyMemberId': '2919032271518'
      }
    }

    const listenerSaga = listener( type, data );


    it( 'should  until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );



    it( 'should dispatch an analytics event', () => {

      listenerSaga.next();


      // create saga response
      let res = {
        'body': {
          'data': {
            'cartSummary': {
              'shippingCost': 5.95,
              'subTotal': 160.98999999999998,
              'itemCount': '9',
              'orderGiftWrapAmt': 3.99,
              'additionalDiscount': null,
              'couponDiscount': 0,
              'estimatedTax': 'TBD',
              'estimatedTotal': 170.93,
              'currencyCode': 'USD',
              'rewardPointsEarned':'100'
            }
          }
        }
      };

      const data = {
        'globalPageData': {
          'rewards': {
            'loyaltyId':'2919032271518'
          }
        }
      }

      // create dispatch event when loyalty member id added
      const evt = {
        'name': 'memberIDAdded'
      };


      const putDescriptor = listenerSaga.next( res );
      expect( listenerSaga.next().value ).toEqual( put( setDataLayer( data, evt ) ) );

    } );





    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

  describe( 'data layer test for server side messages', () => {

    const data1 = {
      'data': {
        'loyaltyMemberId': '2919032271518'
      }
    }

    const listenerSaga1 = listener( type, data1 );
    listenerSaga1.next();
    listenerSaga1.next();

    let res = {
      'body': {
        'data' : {
          'messages' : {
            'items': [
              {
                'type' : 'loyaltyerror',
                'message' : 'look up failed'
              }
            ]
          }
        }
      }
    };

    const data = {
      'globalPageData': {
        'messages' : {
          'items': [
            {
              'type' : 'loyaltyerror',
              'message' : 'look up failed'
            }
          ]
        }
      }
    }

    // create dispatch event when server side messages present
    const evt = {
      'name': 'serviceMessagesUpdated'
    };

    const putDescriptor = listenerSaga1.next( res );
    expect( listenerSaga1.next().value ).toEqual( put( setDataLayer( data, evt ) ) );

  } );

} )
