import {
  takeEvery, call, put, select
} from 'redux-saga/effects';
import isUndefined from 'lodash/isUndefined';


import {
  pageRedirect,
  checkoutRedirectListener,
  CHECKOUT_REDIRECT_LISTENER,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import appConstants from '../../shared/appConstants';
import { getUserState } from '../../models/view/user/user.model';
import {
  ajax
} from '../../utils/ajax/ajax';


import {
  INITIATE_CHECKOUT
} from '../../events/mini_cart/mini_cart.events';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

// Individual exports for testing
export const listener = function*( type, action ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );
    const res = yield call( ajax,
      {
        type,
        method: 'post'
      } );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );

    if( res.body.data ){

      if( res.body.data.result ){
        const {
          pathname
        } = action.data.history.location;
        let checkoutPath = '/checkout';
        action.data.history.push( checkoutPath );
        yield put( pageRedirect( pathname, checkoutPath ) );
      }
      else {
        const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );

        let loadCartMessages = [];
        if( res.body.data.messages ){
          loadCartMessages = res.body.data.messages.items;
        }

        // update remove items in data layer
        let removedItemsData = [];
        /** using &&'s short-circuiting , which is same as if statement.
        The removedItems array will be iterated only if it is not null
        */
        res.body.data.cartItems && res.body.data.cartItems.items.filter( cartItem => cartItem.displayType === 'removed' ).map( ( product, index ) => {
          const data = {
            'skuId': product.catalogRefId,
            'quantityRemoved': product.quantity.value,
            'reasonForRemoval': product.messages.items.map( item => ( item.message ) ).toString()
          };
          removedItemsData.push( data );
        } );


        // analtyics tracking code
        const data = {
          'globalPageData': {
            'cart': {
              'autoRemovedItems':removedItemsData
            },
            'messages': loadCartMessages
          }
        };

        let evt = {
          'name': 'autoRemovedItems'
        };

        // Only fire autoRemovedItems event if items were removed.
        if( removedItemsData.length > 0 ){
          yield put( setDataLayer( data, evt ) );
        }
        else {
          yield put( setDataLayer( data ) );
        }

        // if the service returns messages fire event
        if( loadCartMessages.length > 0 ){
          let evt = {
            'name': 'serviceMessagesUpdated'
          };

          yield put( setDataLayer( data, evt ) );
        }

        // end analytics code

        yield put( checkoutRedirectListener( action.data.history, qty, loadCartMessages ) );
      }
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'initiateCheckout';

  registerServiceName( serviceType );

  yield takeEvery( INITIATE_CHECKOUT, listener, serviceType );
}

export const handleRedirects = function*( action ){

  try {
    if( !isUndefined( action ) ){
      const UserData = yield select( getUserState );

      const {
        isSignedIn
      } = UserData;

      const {
        history,
        qty,
        loadCartMessages
      } = action;

      const {
        pathname
      } = action.history.location;

      let signedInEmptyBag = appConstants.ROUTES.BAG_EMPTY_PAGE;
      let signedOutEmptyBag = appConstants.ROUTES.BAG_LOGIN_PAGE;
      let signedInBag = appConstants.ROUTES.BAG_PAGE;

      if( qty <= 0 ){

        // if i am signed in, have no cart items, and I'm not on the signed emptyBagPage redirct me to the signedin emptyBagpage
        if( isSignedIn && qty === 0 && pathname !== signedInEmptyBag ){
          history.replace( signedInEmptyBag, {
            loadCartMessages
          } );
          yield put( pageRedirect( pathname, signedInEmptyBag ) );
        }


        // if i am not signed in, have no cart items, and I'm not on the signed out emptyBagPage redirect me to the signed out emptyBagpage
        if( !isSignedIn && qty === 0 && pathname !== signedOutEmptyBag ){
          history.replace( signedOutEmptyBag, {
            loadCartMessages
          } );
          yield put( pageRedirect( pathname, signedOutEmptyBag ) );
        }
      }
      // if i have cart items, and I'm on not in BagPage, redirect me to the bag page
      else if( qty > 0 && pathname !== signedInBag ){
        history.replace( signedInBag, {
          loadCartMessages
        } );
        yield put( pageRedirect( pathname, signedInBag ) );

      }
    }

  }
  catch ( err ){

    let evt = {
      type: 'REDIRECT_FAILURE'
    }
    yield put( evt );
  }

}

export const ccrRedirects = function*(){
  yield takeEvery( CHECKOUT_REDIRECT_LISTENER, handleRedirects );
};
