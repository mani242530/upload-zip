

import {
  takeLatest,
  takeEvery,
  put,
  call,
  select
} from 'redux-saga/effects';

import {
  pageRedirect,
  checkoutRedirectListener,
  CHECKOUT_REDIRECT_LISTENER,
  registerServiceName,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import { cloneableGenerator } from 'redux-saga/utils';
import { getUserState } from '../../models/view/user/user.model';

import { ajax } from '../../utils/ajax/ajax';
import {
  INITIATE_CHECKOUT
} from '../../events/mini_cart/mini_cart.events';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import saga, { listener, handleRedirects, ccrRedirects } from './checkout.controller';



jest.mock( '../../utils/ajax/ajax', ()=>{
  return {
    ajax:jest.fn()
  }
} );

describe( 'Checkout.sagas', () => {

  const type = 'CHECKOUT_REDIRECT_LISTENER';
  const serviceType = 'initiateCheckout';

  registerServiceName( serviceType );
  registerServiceName( type );
  describe( 'default saga to check success path', () =>{

    const coreSaga = saga();

    it( 'should listen for the applyPayPalPayment requested method', () =>{

      const takeLatestDescriptor = coreSaga.next().value;

      expect( takeLatestDescriptor ).toEqual(
        takeEvery( INITIATE_CHECKOUT, listener, serviceType )
      );
    } );
  } );

  describe( 'listener saga success/failure path', () => {

    const action = {
      data :{
        'history': {
          'location': {
            'pathname': '/bag'
          },
          replace:jest.fn(),
          push:jest.fn()
        }
      }
    }



    const listenerSaga = listener( type, action );
    let listenerSagaClone, listenerSagaClone2, listenerSagaClone3;

    it( 'should wait until the loading event has been put', () => {

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        data:
        {
          title: 'test',
          status: 'ok',
          result:{}
        }
      }
      const putDescriptor = listenerSaga.next( { body: res } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.data ) ) );
    } );



    it( 'should update the datalayer and dispatch and event', () => {

      const res = {
        data: {
          'cartSummary': {
            'shippingCost': 5.95,
            'subTotal': 8.99,
            'itemCount': 1,
            'additionalDiscount': '-$10.50',
            'couponDiscount': 0,
            'estimatedTax': 'TBD',
            'giftBox': '$3.99',
            'estimatedTotal': 14.94,
            'currencyCode': 'USD',
            'couponCode': null
          },
          'cartItems':{
            'items': [
              {
                'couponApplied': false,
                'displayType':'removed',
                'brandName': 'OPI',
                'quantity': {
                  value:2
                },
                'productId': 'xlsImpprod5180311',
                'excludedFromCoupon': false,
                'adbugMessageMap': null,
                'catalogRefId': '2056976',
                'categoryName': null,
                'commerceItemid': null,
                'priceInfo': {
                  'salePrice': null,
                  'regularPrice': '$10',
                  'unitPriceMessage': null,
                  'bfxPriceMap': null
                },
                'productDisplayName': 'Soft Shades Nail Lacquer Collection',
                'imageURL': 'http://images.ulta.com/is/image/Ulta/2154759?$md$',
                'variantInfo': {
                  'Color': 'Bubble Bath'
                },
                'skuDisplayName': 'Soft Shades Nail Lacquer Collection',
                'shippingRestriction': null,
                'maxQty': null,
                'productURL': null,
                'messages': {
                  'items': [
                    {
                      'type': 'Info',
                      'message': 'Item no longer available'
                    }
                  ]
                }
              }
            ]
          },
          'messages': {
            'items': [
              {
                'type': 'Info',
                'message': 'Looks like you have items in your bag from before. They have been added below.'
              }
            ]
          }
        }
      };

      const listenerSaga = cloneableGenerator( listener )( type, action );
      listenerSaga.next(); // CHECKOUT_REDIRECT_LISTENER loading event
      listenerSaga.next(); // CHECKOUT_REDIRECT_LISTENER ajax call
      listenerSagaClone = listenerSaga.clone();
      listenerSagaClone2 = listenerSaga.clone();
      listenerSagaClone3 = listenerSaga.clone();
      listenerSaga.next( { body: res } ); // CHECKOUT_REDIRECT_LISTENER success call

      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': [
              {
                'skuId': '2056976',
                'quantityRemoved': 2,
                'reasonForRemoval': res.data.cartItems.items[0].messages.items[0].message
              }
            ]
          },
          'messages': res.data.messages.items

        }
      };

      const evt = {
        'name': 'autoRemovedItems'
      };

      expect( listenerSaga.next().value ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put action to trigger data layer without passing event parameter, if no removed items in the cart', () => {

      const res = {
        data: {
          'cartSummary': {},
          'messages': {
            'items': [
              {
                'type': 'Info',
                'message': 'Test'
              }
            ]
          }
        }
      };

      listenerSagaClone.next( { body: res } )

      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': []
          },
          'messages': res.data.messages.items
        }
      };

      const putDescriptor = listenerSagaClone.next().value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data ) ) );
    } );

    it( 'should put action to trigger the datalayer with event parameter as serviceMessagesUpdated, if messages are available', () => {

      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': []
          },
          'messages': [
            {
              'type': 'Info',
              'message': 'Test'
            }
          ]
        }
      };

      const evt = {
        'name': 'serviceMessagesUpdated'
      };

      const putDescriptor = listenerSagaClone.next().value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put action to trigger the datalayer with event parameter as autoRemovedItems, if removed items is in the cart and no cart messages available', () => {

      const res = {
        data: {
          'cartSummary': {
            'itemCount': '10'
          },
          'cartItems':{
            'items': [
              {
                'displayType':'removed',
                'quantity': {
                  value:1
                },
                'catalogRefId': '2056976',
                'messages': {
                  'items': [
                    {
                      'type': 'Info',
                      'message': 'Item no longer available'
                    }
                  ]
                }
              }
            ]
          },
          'messages': null
        }
      };

      listenerSagaClone2.next( { body: res } );

      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': [
              {
                'skuId': '2056976',
                'quantityRemoved': 1,
                'reasonForRemoval': 'Item no longer available'
              }
            ]
          },
          'messages': []
        }
      };

      let evt = {
        'name': 'autoRemovedItems'
      };

      const putDescriptor = listenerSagaClone2.next( ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put setDataLayer with reasonForRemoval in autoRemovedItems as concatenated message, if there are removed items in res.body.data.cartItems with multiple messages', () => {

      const res = {
        body: {
          data: {
            'cartSummary': {
              'itemCount': '10'
            },
            'cartItems':{
              'items': [
                {
                  'displayType':'removed',
                  'quantity': {
                    'value':1
                  },
                  'catalogRefId': '2056976',
                  'messages': {
                    'items': [
                      {
                        'type': 'Info',
                        'message': 'Item no longer available'
                      },
                      {
                        'type': 'Info',
                        'message': 'Out of stock'
                      }
                    ]
                  }
                }
              ]
            },
            'messages': null
          }
        }
      };

      listenerSagaClone3.next( res );

      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': [
              {
                'skuId': '2056976',
                'quantityRemoved': 1,
                'reasonForRemoval': 'Item no longer available,Out of stock'
              }
            ]
          },
          'messages': []
        }
      };

      let evt = {
        'name': 'autoRemovedItems'
      };

      const putDescriptor = listenerSagaClone3.next( ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put checkoutRedirectListener without updating the datalayer with event parameter as serviceMessagesUpdated, if messages are not available', () => {

      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': [
              {
                'skuId': '2056976',
                'quantityRemoved': 1,
                'reasonForRemoval': [{
                  'type': 'Info',
                  'message': 'Item no longer available'
                }
                ]
              }
            ]
          },
          'messages': []
        }
      };

      const evt = {
        'name': 'serviceMessagesUpdated'
      };
      const putDescriptor = listenerSagaClone2.next().value;
      expect( putDescriptor ).not.toEqual( put( setDataLayer( data, evt ) ) );
      expect( putDescriptor ).toEqual( put( checkoutRedirectListener( action.data.history, 10, [] ) ) );
    } );


    it( 'After the success event should redirect to checkout', () => {

      const pathname = '/bag';
      const checkoutPath = '/checkout';
      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( pageRedirect( pathname, checkoutPath ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );
  } );

  describe( 'listener saga success path', () => {

    const action = {
      data :{
        'history': {
          'location': {
            'pathname': '/bag'
          },
          replace:jest.fn(),
          push:jest.fn()
        }
      }
    }

    const listenerSaga = listener( type, action );

    it( 'should wait until the loading event has been put', () => {

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        data: {
          title: 'test',
          status: 'ok',
          cartSummary:{
            itemCount :0
          },
          messages:{
            items:[]
          }
        }
      }
      const putDescriptor = listenerSaga.next( { body: res } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.data ) ) );
    } );

    it( 'After success event -update remove items in data layer', () => {

      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems': []
          },
          'messages': []
        }
      };

      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( setDataLayer( data ) ) );
    } );

    it( 'After the success event - redirect to checkout', () => {

      const putDescriptor = listenerSaga.next().value;
      const qty = 0;
      const loadCartMessages = [];

      expect( putDescriptor ).toEqual( put( checkoutRedirectListener( action.data.history, qty, loadCartMessages ) ) );
    } );

  } );

  describe( 'ccrRedirects saga to check success path', () =>{

    const ccrRedirectsSaga = ccrRedirects();

    it( 'should listen for the applyPayPalPayment requested method', () =>{

      const takeLatestDescriptor = ccrRedirectsSaga.next().value;

      expect( takeLatestDescriptor ).toEqual(
        takeEvery( CHECKOUT_REDIRECT_LISTENER, handleRedirects )
      );
    } );
  } );

  describe( 'handleRedirects saga', () => {

    describe( 'signedIn user flow - no items in bag', () =>{

      const actions = {
        'history': {
          'location': {
            'pathname': '/bag'
          },
          replace:jest.fn()
        },
        'qty': 0,
        'loadCartMessages': []
      }

      const handleRedirectsSaga = handleRedirects( actions );
      const pathname = '/bag';
      const signedInEmptyBag = '/bag/empty';

      it( 'should call select getUserState ', () =>{

        const selectDescriptor = handleRedirectsSaga.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'Should put a event to redirect the signed in user to empty bag page, if the quantity is 0 and the user is not already on empty bag  ', () =>{

        const UserData = {
          isSignedIn : true
        }

        const putDescriptor_loggedIn = handleRedirectsSaga.next( UserData ).value;
        expect( putDescriptor_loggedIn ).toEqual( put( pageRedirect( pathname, signedInEmptyBag ) ) );

      } );

    } );

    describe( 'guest user flow - no items in bag', () =>{

      const actions = {
        'history': {
          'location': {
            'pathname': '/bag'
          },
          replace:jest.fn()
        },
        'qty': 0,
        'loadCartMessages': []
      }


      const handleRedirectsSaga = handleRedirects( actions );
      const pathname = '/bag';
      const signedOutEmptyBag = '/bag/login';

      it( 'should call select getUserState ', () =>{

        const selectDescriptor = handleRedirectsSaga.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'Should put a event to redirect the guest user to bag login page, if the quantity is 0 and the user is not already on bag login page ', () =>{

        const UserData = {
          isSignedIn : false
        }

        const putDescriptor_loggedIn = handleRedirectsSaga.next( UserData ).value;
        expect( putDescriptor_loggedIn ).toEqual( put( pageRedirect( pathname, signedOutEmptyBag ) ) );

      } );

      it( 'Should put a failure event if no data is returned from the getUserState service  ', () =>{

        let evt = {
          type: 'REDIRECT_FAILURE'
        }
        const putDescriptor = handleRedirectsSaga.throw( evt ).value;
        expect( putDescriptor ).toEqual( put( evt ) );

      } );

    } );

    describe( 'signedIn user flow- having items in bag', () =>{

      const actions = {
        'history': {
          'location': {
            'pathname': '/bag/empty'
          },
          replace:jest.fn()
        },
        'qty': 1,
        'loadCartMessages': []
      }

      const handleRedirectsSaga = handleRedirects( actions );
      const pathname = '/bag/empty';
      const signedInBag = '/bag';

      it( 'should call select getUserState ', () =>{

        const selectDescriptor = handleRedirectsSaga.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'Should put a event to redirect user to bag page, if the quantity is greater than 0 and if the user is currently on empty bag page', () =>{

        const UserData = {
          isSignedIn : true
        }

        const putDescriptor_loggedIn = handleRedirectsSaga.next( UserData ).value;
        expect( putDescriptor_loggedIn ).toEqual( put( pageRedirect( pathname, signedInBag ) ) );

      } );

      it( 'Should put a event to redirect guest user to bag page, if the quantity is greater than 0 and if the user is currently on empty bag page', () =>{
        const UserData = {
          isSignedIn : false
        }
        const handleRedirectsSaga = handleRedirects( actions );
        handleRedirectsSaga.next(); // this is select getUserState event

        const putDescriptor = handleRedirectsSaga.next( UserData ).value;
        expect( putDescriptor ).toEqual( put( pageRedirect( pathname, signedInBag ) ) );
      } );
    } );
  } );

} );
