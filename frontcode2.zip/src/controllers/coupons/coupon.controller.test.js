
/**
 * GWP  sagas
 */

import {
  call, put, take, select
} from 'redux-saga/effects';

import {
  checkoutRedirectListener,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';


import { triggerChildEvent } from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import { getCheckoutPageState } from '../../models/view/checkout_page/checkout_page.model';
import { listener, remove_listener, triggerQProtocol } from './coupons.controller';

jest.mock( 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol', () => {
  return { triggerChildEvent:jest.fn() }
} );
const _dynSessConf = '12345';

const couponCode = 'CPW1234566';
const fromCheckout = true;


describe( 'defaultSaga Saga', () => {
  const type = 'applycoupon';

  let action = {
    'item': couponCode,
    'fromCheckout':true
  }
  let action2 = {
    'item': couponCode,
    '_dynSessConf': _dynSessConf,
    fromCheckout:false
  }
  registerServiceName( type );
  registerServiceName( 'initCart' );

  describe( 'listener saga success path if couponAppliedStatus response is true - valid coupon applied', () => {

    const listenerSaga = listener( type, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      let query = { couponCode, fromCheckout };

      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', query } ) );

    } );
    const res = {
      body: {
        data :{
          cartSummary: {
            itemCount :2
          },
          appliedCouponSummary:{
            couponAppliedStatus: true,
            couponCode:couponCode

          },
          messages:{}
        }
      }
    }
    it( 'should put success action', () => {

      const putDescriptor  = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );

    it( 'should put request action', () => {

      const putDescriptor  = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( 'initCart', 'requested' )( { history: action.history, hideSpinner: true } ) ) );

    } );

    it( 'should take initcart success event ', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( take( getServiceType( 'initcart', 'success' ) ) );
    } );
    it( 'should call getCheckoutPageState ', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( select( getCheckoutPageState ) );
    } );
    it( 'should put data layer request action', () => {
      const initCartData = {
        data:{
          result:{
            id:'1234'
          }
        }
      }
      const putDescriptor  = listenerSaga.next( initCartData ).value;
      const data = {
        globalPageData: {
          order: {
            couponSummary: {
              couponAppliedStatus: true,
              couponCode: 'CPW1234566'
            }
          }
        }
      };
      const evt = {
        data: {
          couponCode: 'CPW1234566',
          couponStatus: 'valid'
        },
        name: 'cartApplyCoupon'
      };
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should put checkoutRedirectListener listner', () => {

      const listenerSaga2 = listener( type, action2 );
      listenerSaga2.next();
      listenerSaga2.next();
      listenerSaga2.next( res );
      const putDescriptor = listenerSaga2.next().value;
      const qty = 2;
      const loadCartMessages = {};

      expect( putDescriptor ).toEqual( put( checkoutRedirectListener( action.history, qty, loadCartMessages ) ) );

    } );

  } );

  describe( 'triggerQProtocol sagas', () => {
    it( ' triggerChildEvent should be triggered with ecVoucher as object  ', () => {
      const data = {
        appliedCouponSummary:{
          couponCode:'ORAMT10QP',
          couponAppliedStatus: true,
          couponDescription:['test']
        },
        orderId:'12s121',
        cartSummary:{
          subTotal:'30',
          currencyCode:'USD',
          estimatedTotal:'30',
          itemCount:5,
          couponDiscount:'5.23659865663',
          additionalDiscount:'0',
          estimatedTax:'25',
          shippingCost:'0'
        },
        shippingInfo:{
          shipMethodInfo: {
            items: [
              {
                shipMethod: 'selected shipping address',
                isSelected: true
              },
              {
                shipMethod: 'NOT selected shipping address',
                isSelected: false
              }
            ]
          }
        }
      }
      triggerQProtocol( data );
      let qubitVoucherDetailsEventData = {
        entry:'ORAMT10QP',
        entrySuccess:true,
        voucher:{
          id: 'ORAMT10QP',
          label: 'test'
        },
        basket:{
          id: '12s121',
          subtotal:{
            value : '30',
            currency : 'USD'
          },
          total:{
            value: '30',
            currency: 'USD'
          },
          quantity: 5,
          discount:{
            value: 5.24,
            currency : 'USD'
          },
          tax:{
            value: '25',
            currency: 'USD'
          },
          shippingPrice:{
            value: '0',
            currency: 'USD'
          },
          shippingMethod: 'selected shipping address'
        }
      }
      expect( triggerChildEvent ).toHaveBeenCalledWith( 'ecVoucher', qubitVoucherDetailsEventData )

    } );

    it( ' triggerChildEvent should be triggered with ecVoucher as object even voucher code is not correct/invalid   ', () => {
      const data1 = {
        appliedCouponSummary:{
          couponCode:'12312XX',
          couponAppliedStatus: false,
          couponDescription:['test']
        },
        orderId:'12s121',
        cartSummary:{
          subTotal:'30',
          currencyCode:'USD',
          estimatedTotal:'30',
          itemCount:5,
          couponDiscount:'5.25999',
          additionalDiscount:'0',
          estimatedTax:'25',
          shippingCost:'0'
        },
        shippingInfo:{
          shipMethodInfo: {
            items: [
              {
                shipMethod: 'selected shipping address',
                isSelected: true
              },
              {
                shipMethod: 'NOT selected shipping address',
                isSelected: false
              }
            ]
          }
        }
      }
      triggerQProtocol( data1 );
      let qubitVoucherDetailsEventData1 = {
        entry:'12312XX',
        entrySuccess:false,
        basket:{
          id: '12s121',
          subtotal:{
            value : '30',
            currency : 'USD'
          },
          total:{
            value: '30',
            currency: 'USD'
          },
          quantity: 5,
          discount:{
            value: 5.26,
            currency : 'USD'
          },
          tax:{
            value: '25',
            currency: 'USD'
          },
          shippingPrice:{
            value: '0',
            currency: 'USD'
          },
          shippingMethod: 'selected shipping address'
        }
      }
      expect( triggerChildEvent ).toHaveBeenCalledWith( 'ecVoucher', qubitVoucherDetailsEventData1 )

    } );
  } )
  describe( 'listener saga success path if couponAppliedStatus response is false - invalid coupon applied', () => {

    const listenerSaga = listener( type, action );
    const res = {
      body: {
        data :{
          cartSummary: {
            itemCount :2
          },
          appliedCouponSummary:{
            couponAppliedStatus: false,
            couponCode:couponCode,
            messages:{
              items:[
                {
                  type: 'Error',
                  message: 'Code is not valid'
                }
              ]
            }
          },
          messages: {}
        }
      }
    }

    it( 'should put success action', () => {
      listenerSaga.next().value;
      listenerSaga.next().value
      const putDescriptor  = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should call getCheckoutPageState ', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( select( getCheckoutPageState ) );
    } );

    it( 'should put data layer request action with couponStatus as couponAppliedErrorMessage', () => {
      const initCartData = { checkoutServicesData: {} };
      const putDescriptor  = listenerSaga.next( initCartData ).value;
      const data = {
        globalPageData: {
          order: {
            couponSummary: res.body.data.appliedCouponSummary
          }
        }
      };
      const evt = {
        data: {
          couponCode: couponCode,
          couponStatus: 'Code is not valid'
        },
        name: 'cartApplyCoupon'
      };
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );
  } );
} );

describe( 'defaultSaga Saga', () => {

  const type = 'removecoupon';

  let action1 = {
    '_dynSessConf': _dynSessConf,
    fromCheckout:fromCheckout
  }

  let action2 = {
    '_dynSessConf': _dynSessConf,
    fromCheckout:false
  }

  registerServiceName( type );

  describe( 'listener saga success path', () => {

    const listenerSaga = remove_listener( type, action1 );
    const listenerSaga2 = remove_listener( type, action2 );

    it( 'should put the loading action ', () => {

      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;

      let query = { fromCheckout };
      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', query } ) );

    } );

    const res = {
      body: {
        data :{
          cartSummary: {
            itemCount :2
          },
          appliedCouponSummary:{
            couponAppliedStatus: true,
            couponCode:couponCode

          },
          messages:{}
        }
      }
    }
    it( 'should put success action', () => {

      const putDescriptor  = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );

    it( 'should put request action', () => {

      const putDescriptor  = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( 'initCart', 'requested' )( { history: action1.history, hideSpinner: true } ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should put checkoutRedirectListener listner', () => {

      listenerSaga2.next();
      listenerSaga2.next();
      listenerSaga2.next( res );
      const putDescriptor = listenerSaga2.next( ).value;
      const qty = 2;
      const loadCartMessages = {};

      expect( putDescriptor ).toEqual( put( checkoutRedirectListener( action2.history, qty, loadCartMessages ) ) );

    } );

  } );

} );
