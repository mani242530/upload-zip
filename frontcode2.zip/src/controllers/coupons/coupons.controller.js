import {
  takeEvery, call, put, take, select
} from 'redux-saga/effects';



import {
  checkoutRedirectListener,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';




import get from 'lodash/get';
import qProtocol from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import {
  ajax
} from '../../utils/ajax/ajax';
import { getCheckoutPageState } from '../../models/view/checkout_page/checkout_page.model';
import {
  COUPON_CODE,
  COUPON_CODE_REMOVED
} from '../../events/coupons/coupons.events';

const {
  triggerChildEvent
} = qProtocol;
// Individual exports for testing
export const listener = function*( type, action ){
  try {

    yield put( getActionDefinition( type, 'loading' )() );
    let trimmedCouponCode = action.item.trim();
    let query = {
      couponCode:  trimmedCouponCode
    }
    if( action.fromCheckout ){
      query.fromCheckout = action.fromCheckout;
    }
    const res = yield call( ajax,
      {
        type,
        method:'post',
        query
      } );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    const {
      appliedCouponSummary
    } = res.body.data;

    if( res.body.data ){
      let cartData = res.body.data;

      // should execute this logic only for the coupon flow in checkout page
      if( action.fromCheckout ){
        // should initiate initCart only if couponAppliedStatus is true(coupon applied)
        if( appliedCouponSummary.couponAppliedStatus ){
          yield put( getActionDefinition( 'initCart', 'requested' )( { history: action.history, hideSpinner: true } ) );
          yield take( getServiceType( 'initCart', 'success' ) );
        }
        let checkoutData = yield select( getCheckoutPageState );
        cartData = checkoutData.checkoutServicesData;
      }
      // need to execute this only for the coupon flow in cart page
      // this will handle the redirection to empty bag page if all the items gets removed as part of the api call
      else {
        const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
        const loadCartMessages = res.body.data.messages;
        yield put( checkoutRedirectListener( action.history, qty, loadCartMessages ) );
      }

      // Analytics tracking code begin
      let couponAppliedErrorMessage = appliedCouponSummary.messages && appliedCouponSummary.messages.items[0].message

      const evt = {
        'name': 'cartApplyCoupon',
        'data':{
          'couponCode': appliedCouponSummary.couponCode,
          'couponStatus': ( appliedCouponSummary.couponAppliedStatus ? 'valid' : couponAppliedErrorMessage )
        }
      }

      const data = {
        'globalPageData': {
          'order': {
            'couponSummary': appliedCouponSummary
          }
        }
      }

      yield put( setDataLayer( data, evt ) );
      // Analtyics tracking code end
      triggerQProtocol( cartData );
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}
export function triggerQProtocol( data ){

  let qubitVoucherDetailsEventData = getVoucherObject( data );
  triggerChildEvent( 'ecVoucher', qubitVoucherDetailsEventData );
}

// create and returns qubit ecVoucher object for firing quibit event from the saga reponse data
const getVoucherObject = ( data )=>{
// if shippingMethod Info is available it should calculate shiping information of selected item
  let shippingInfo = get( data, 'shippingInfo.shipMethodInfo.items' ) || [];
  let selectedShippingInfo = shippingInfo.find( ( item )=>{
    return item.isSelected;
  } ) || {};
  let cartSummary = data.cartSummary;
  let additionalDiscount = get( cartSummary, 'additionalDiscount' ) || 0;
  let couponDiscount = parseFloat( cartSummary.couponDiscount ).toFixed( 2 );
  additionalDiscount = parseFloat( additionalDiscount ).toFixed( 2 );
  let qubitVoucherDetailsEventData = {
    entry: data.appliedCouponSummary.couponCode,
    entrySuccess : data.appliedCouponSummary.couponAppliedStatus,
    // if couponApllied status is 'true' it should be set voucher id and voucher label otherwise not
    ...( data.appliedCouponSummary.couponAppliedStatus && {
      voucher:{
        id: data.appliedCouponSummary.couponCode,
        label: data.appliedCouponSummary.couponDescription && data.appliedCouponSummary.couponDescription.toString()
      }
    } ),
    basket:{
      id: data.orderId,
      subtotal:{
        value : cartSummary.subTotal,
        currency : cartSummary.currencyCode
      },
      total:{
        value: cartSummary.estimatedTotal,
        currency: cartSummary.currencyCode
      },
      quantity: cartSummary.itemCount,
      discount:{
        value: parseFloat( couponDiscount ) + parseFloat( additionalDiscount ),
        currency : cartSummary.currencyCode
      },
      tax:{
        value: cartSummary.estimatedTax,
        currency: cartSummary.currencyCode
      },
      shippingPrice:{
        value: cartSummary.shippingCost,
        currency: cartSummary.currencyCode
      },
      ...( selectedShippingInfo.shipMethod && { shippingMethod: selectedShippingInfo.shipMethod } )
    }
  }
  return qubitVoucherDetailsEventData;
}
export const remove_listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    let query = {};
    if( action.fromCheckout ){
      query.fromCheckout = action.fromCheckout;
    }
    const res = yield call( ajax,
      {
        type,
        method:'post',
        query
      } );
    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data ){



      if( action.fromCheckout ){
        yield put( getActionDefinition( 'initCart', 'requested' )( { history: action.history, hideSpinner: true } ) );
      }
      else {
        const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
        const loadCartMessages = res.body.data.messages;
        yield put( checkoutRedirectListener( action.history, qty, loadCartMessages ) );
      }

    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'applycoupon';

  registerServiceName( serviceType );

  yield takeEvery( COUPON_CODE, listener, serviceType );

  serviceType = 'removecoupon';

  registerServiceName( serviceType );

  yield takeEvery( COUPON_CODE_REMOVED, remove_listener, serviceType );
}
