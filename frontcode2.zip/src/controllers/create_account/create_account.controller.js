import {
  takeEvery, call, put, select
} from 'redux-saga/effects';


import has from 'lodash/has';
import isUndefined from 'lodash/isUndefined';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';


import {
  host,
  fullyQualifyLink
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';

import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';


// Individual exports for testing
export const listener = function*( type, action ){
  try {

    yield put( getActionDefinition( type, 'loading' )() );
    let values = {
      login: action.data.values.emailOrUsername,
      password: action.data.values.password,
      confirmPassword: action.data.values.passwordMatch,
      firstName: action.data.values.firstName,
      lastName: action.data.values.lastName,
      address1: action.data.values.address1,
      address2: action.data.values.address2,
      city: action.data.values.city,
      state: action.data.values.state,
      dateOfBirth: action.data.values.dateOfBirth,
      postalCode: action.data.values.postalCode,
      phoneNumber: action.data.values.phoneNumber,
      emailOptIn: action.data.values.subscribeForEmail,
      sourcePage: action.data.values.sourcePage
    };

    const res = yield call(
      ajax, {
        type,
        method:'post',
        values
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body ) ) ;

    if( !isUndefined( res.body ) && has( res.body, 'success' ) ){

      const data = {
        'globalPageData': {
          'action': {
            'accountCreated': ( res.body.success === 'true' ? 'true' : 'false' ),
            'emailOptIn': ( action.data.values.subscribeForEmail === '' ? 'false' : ( action.data.values.subscribeForEmail ).toString() )
          }
        }
      }
      const evt = {
        name: 'trackAccountCreatedSuccess'
      }
      if( res.body.success ){
        yield put( setDataLayer( data, evt ) );
        if( action.data.useRouter ){
          action.data.history.push( action.data.paths.successPath, {
            isSignedIn: true
          } );
        }
        else {
          global.location.href = fullyQualifyLink( host, action.data.paths.successPath );
        }
      }
      else {
        yield put( setDataLayer( data ) );
      }
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'createAccount';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( 'createAccount', 'requested' ), listener, serviceType );
}
