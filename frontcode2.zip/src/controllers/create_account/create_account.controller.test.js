
import {
  takeLatest, takeEvery, call, put
} from 'redux-saga/effects';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import saga, { listener } from './create_account.controller';
import { ajax } from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

describe( ' CreateAccount Saga', () => {

  const type = 'createAccount';
  registerServiceName( type );
  jest.mock( './../../utils/ajax/ajax', ()=>{
    return { ajax:jest.fn() }
  } );

  describe( 'default saga', () =>{

    const coreSaga = saga();

    it( 'should listen for the createAccount requested method', () =>{

      const takeLatestDescriptor = coreSaga.next().value;

      expect( takeLatestDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), listener, type ) );
    } );

  } );
  describe( 'listener saga success and error path', () =>{

    const values = {
      login : 'test',
      password:'test',
      confirmPassword :'test',
      firstName:'test',
      lastName:'test',
      address1:'700 keeaumoku st',
      address2:'',
      city:'Honolulu',
      state:'HI',
      dateOfBirth:'',
      postalCode:'96814',
      phoneNumber:'',
      emailOptIn: true

    };
    const action = {
      data: {
        values: {
          emailOrUsername : 'test',
          password:'test',
          passwordMatch :'test',
          firstName:'test',
          lastName:'test',
          address1:'700 keeaumoku st',
          address2:'',
          city:'Honolulu',
          state:'HI',
          dateOfBirth:'',
          postalCode:'96814',
          phoneNumber:'',
          subscribeForEmail: true
        },
        paths: {
          successPath: '/bag',
          failurePath: '/'
        }
      }
    }
    const listenerSaga = listener( type, action );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;
      const method = 'post';

      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        status: 'ok',
        success: true
      }
      const putDescriptor = listenerSaga.next( { body: res } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
    } );

    it( 'should dispatch an analytics event', () => {


      // create saga response
      let res1 = {
        'body': {
          'success': true
        }
      };

      const data = {
        'globalPageData': {
          'action': {
            'accountCreated': ( res1.body.success === 'true' ? 'true' : 'false' ),
            'emailOptIn': 'true'
          }
        }
      }

      // create dispatch event when loyalty member id added
      const evt = {
        name: 'trackAccountCreatedSuccess'
      }

      expect( listenerSaga.next( res1 ).value ).toEqual( put( setDataLayer( data, evt ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

    it( 'should throw the error', () => {

      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }

      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );

  } );

} );
