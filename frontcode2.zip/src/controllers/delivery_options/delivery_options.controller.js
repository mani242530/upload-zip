import { takeEvery, call, put } from 'redux-saga/effects';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  registerServiceName,
  getActionDefinition,
  checkoutRedirectListener
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ajax
} from '../../utils/ajax/ajax';


import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import {
  SET_DELIVERY_OPTIONS
} from '../../events/bopis/bopis.events';
import appConstants from '../../shared/appConstants';




// Individual exports for testing
export const listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )( { deliveryType:action.data } ) );
    let query = {
      deliveryType: action.data
    }
    const res = yield call( ajax,
      {
        type,
        method: 'post',
        query
      } );

    const data = res.body.data;

    yield put( getActionDefinition( type, 'success' )( data ) );

    // if deliveryOption is pickup fire analyticsEvent bopisPickupSelected
    if( data.deliveryOption === 'pickup' ){
      const evt = {
        'name': appConstants.ANALYTICS.BOPIS_PICKUP_SELECTED
      }
      yield put( triggerAnalyticsEvent( evt ) );
    }

    let restoreItemHandler = {
      // if the user switches to the 'ship' fulfillment, we will check if there were items which was removed from the bag when the user
      // had earlier opted for pickup.
      restoreItem:data.deliveryOption === 'ship',
      history:action.history,
      itemCount:data.cartSummary.itemCount,
      cartMessages: data.messages
    }

    const cartItemQuantity = parseInt( data?.cartSummary?.itemCount, 10 );

    // this will handle redirection if cart item quantity is greater than 0 and
    // user is not in bag page
    yield put( checkoutRedirectListener( action.history, cartItemQuantity, data.messages ) );

    let removedItemsData = [];

    // Populate removed items node
    data.cartItems && data.cartItems.items.filter( cartItem => cartItem.displayType === 'removed' ).map( ( product, index ) => {
      const data = {
        'skuId': product.catalogRefId,
        'quantityRemoved': product.quantity.value,
        'reasonForRemoval': product.messages.items[0].message
      };
      removedItemsData.push( data );
    } ) ;

    // If items were removed dispatch event (autoRemovedItems)
    if( removedItemsData.length > 0 ){
      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems':removedItemsData
          }
        }
      }
      const evt = {
        'name': 'autoRemovedItems'
      }
      // Update globalPageData with data passed and trigger the event (evt)
      yield put( setDataLayer( data, evt ) );
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'deliveryOptionsUpdate';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( SET_DELIVERY_OPTIONS, listener, serviceType );

}
