import {
  takeEvery, call, put, select
} from 'redux-saga/effects';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  registerServiceName,
  getActionDefinition,
  checkoutRedirectListener
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import {
  ajax
} from '../../utils/ajax/ajax';
import saga, { listener } from './delivery_options.controller';
import appConstants from '../../shared/appConstants';


import {
  SET_DELIVERY_OPTIONS
} from '../../events/bopis/bopis.events';
import { getCartState } from '../../models/view/cart/cart.model';


const type  = 'deliveryOptionsUpdate';

describe( 'deliveryOptions Saga', () => {
  registerServiceName( type );
  registerServiceName( 'loadCart' );

  const deliveryOptionssaga = saga();

  it( 'should listen for the navigation request method', () => {

    const takeEveryDescriptor = deliveryOptionssaga.next().value;
    expect( takeEveryDescriptor ).toEqual(
      takeEvery( SET_DELIVERY_OPTIONS, listener, type )
    );

  } );

  describe( 'listener saga success path- delivery Type is ship', () => {
    let res;
    const action = {
      data: 'ship'
    }
    const listenerSaga = listener( type, action );

    it( 'should put deliveryOptionsUpdate loading event', () => {

      const putDescriptor = listenerSaga.next( action ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { deliveryType:action.data } ) ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;
      const method = 'post';
      const query = {
        deliveryType: 'ship'
      }
      expect( callDescriptor ).toEqual( call( ajax, { type, method, query } ) );

    } );

    it( 'should put a success event after data is called', () => {

      res = {
        body: {
          data: {
            'cartSummary': {
              'shippingCost': 5.95,
              'subTotal': 160.98999999999998,
              'itemCount': 9,
              'orderGiftWrapAmt': 3.99,
              'additionalDiscount': null,
              'couponDiscount': 0,
              'estimatedTax': 'TBD',
              'estimatedTotal': 170.93,
              'currencyCode': 'USD',
              'rewardPointsEarned':'100'
            },
            cartItems:{
              items:[
                {
                  displayType:'removed',
                  catalogRefId:'1234',
                  quantity:{
                    value:3
                  },
                  messages:{
                    items:[
                      {
                        message:'Out of Stock'
                      }
                    ]
                  }
                }
              ]
            },
            'messages' : {
              'items': [
                {
                  'type' : 'string',
                  'message' : 'string'
                }
              ]
            },
            deliveryOption:'ship'
          }
        }
      };

      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );

    it( 'should put checkoutRedirectListener if there are bag updates depending on the bag count', () => {
      const history = undefined;
      const qty = res.body.data.cartSummary.itemCount;
      const loadCartMessages = {
        'items': [
          {
            'type' : 'string',
            'message' : 'string'
          }
        ]
      }
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( checkoutRedirectListener( history, qty, loadCartMessages ) ) );
    } );

    it( 'should put setDataLayer if items are removed as part of delivery option update', ()=>{
      const putDescriptor = listenerSaga.next( ).value;
      const data = {
        'globalPageData': {
          'cart': {
            'autoRemovedItems':[
              {
                quantityRemoved:3,
                reasonForRemoval:'Out of Stock',
                skuId:'1234'
              }
            ]
          }
        }
      }
      const evt = {
        'name': 'autoRemovedItems'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } )

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

  describe( 'listener saga success path - delivery Type is pickup', () => {
    let res;
    const action = {
      data: 'pickup'
    }
    const listenerSaga = listener( type, action );

    it( 'should  put the deliveryOptionsUpdate loading event', () => {
      const putDescriptor = listenerSaga.next( action ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { deliveryType:action.data } ) ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      const method = 'post';
      const query = {
        deliveryType: 'pickup'
      }

      expect( callDescriptor ).toEqual( call( ajax, { type, method, query } ) );
    } );

    it( 'should put a success event after data is called', () => {
      res = {
        body: {
          data: {
            'cartSummary': {
              'shippingCost': 5.95,
              'subTotal': 160.98999999999998,
              'itemCount': 9,
              'orderGiftWrapAmt': 3.99,
              'additionalDiscount': null,
              'couponDiscount': 0,
              'estimatedTax': 'TBD',
              'estimatedTotal': 170.93,
              'currencyCode': 'USD',
              'rewardPointsEarned':'100'
            },
            cartItems:{
              items:[
                {
                  displayType:'default',
                  catalogRefId:'1234',
                  quantity:{
                    value:3
                  }
                }
              ]
            },
            'messages' : {
              'items': [
                {
                  'type' : 'string',
                  'message' : 'string'
                }
              ]
            },
            'deliveryOption': 'pickup'
          }
        }
      };

      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should trigger analytics event bopisPickupSelected when deliveryOption is Pickup', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( { 'name': appConstants.ANALYTICS.BOPIS_PICKUP_SELECTED } ) ) );
    } )

    it( 'should put checkoutRedirectListener', () => {
      const history = undefined;
      const qty = res.body.data.cartSummary.itemCount;
      const loadCartMessages = {
        'items': [
          {
            'type' : 'string',
            'message' : 'string'
          }
        ]
      }
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( checkoutRedirectListener( history, qty, loadCartMessages ) ) );
    } );

    it( 'should not put setDataLayer if there is no items are removed as part of delivery option update', ()=>{
      const putDescriptor = listenerSaga.next( );
      expect( putDescriptor.done ).toEqual( true );
    } )

  } );

} )
