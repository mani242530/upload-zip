/**
 * Created by Sreekala on 8/3/18.
 */
import {
  takeEvery,
  call,
  put,
  cancelled
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { ajax } from '../../utils/ajax/ajax';

export const emailNotification = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const res = yield call(
      ajax, {
        type:'emailNotification',
        method:'post',
        values:action.data
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );

    /* Trigger Analytics event on email notify success */
    if( res.body.data.success ){
      const evt = {
        'name': 'outOfStockEmailMeSuccess',
        'data': {
          'productSku' : action.data.skuId
        }
      }
      yield put( triggerAnalyticsEvent( evt ) );
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
  finally {
    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'canceled' )() );
    }
  }
}
export default function(){
  return function*( ){
    const serviceType = 'pdpEmailNotification';
    registerServiceName( serviceType );
    yield takeEvery( getServiceType( serviceType, 'requested' ), emailNotification, serviceType )
  }
}
