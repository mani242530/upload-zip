import {
  takeEvery,
  call,
  put,
  cancelled,
  take
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { cloneableGenerator } from 'redux-saga/utils';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { ajax } from '../../utils/ajax/ajax';
import CONFIG from '../../modules/pdp/pdp.config';
import saga, {
  emailNotification
} from './email_notification.controller';

const type = 'pdpEmailNotification';
var action = {
  data:{
    skuId: 2241934
  }
};
const listenerSaga = emailNotification( type, action );
describe( 'emailNotification sagas', () => {
  const coreSaga = saga( CONFIG )();
  registerServiceName( type );

  it( 'should take every emailNotification request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), emailNotification, type ) );
  } );

  describe( 'emailNotification saga success path', () => {

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      let values = action.data;

      expect( callDescriptor ).toEqual( call( ajax, { type:'emailNotification', method:'post', values } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should trigger analytics event named outOfStockEmailMeSuccess after success', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const evt = {
        'name': 'outOfStockEmailMeSuccess',
        'data': {
          'productSku' : action.data.skuId
        }
      }
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );

  } );

  describe( 'emailNotification saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

} );
