import {
  takeEvery, take, call, put, select
} from 'redux-saga/effects';
import { delay } from 'redux-saga';
import has from 'lodash/has';

import {
  types,
  actions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';

import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

export const listener = function*( type, CONFIG, action ){
  try {

    yield put( getActionDefinition( type, 'loading' )() );

    yield call( delay, 2000 );

    let values = {
      email: action.data.emailaddress,
      firstName: action.data.firstName,
      lastName: action.data.lastName
    };

    if( process.env.NODE_ENV === 'development' ){
      values.__IS_NEW_USER_OPTIN = CONFIG.DEBUGGING.ESU.isNewUserOptIn;
      values.__IS_ERROR_MESSAGE = CONFIG.DEBUGGING.ESU.isErrorMessage;
    }

    const res = yield call(
      ajax, {
        type,
        method:'post',
        values
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body ) ) ;

    if( has( res.body, 'data.newUser' ) && res.body.data.newUser ){

      // analtyics tracking code
      const data = {
        'globalPageData': {
          'action': {
            'emailOptIn': true
          },
          'navigation': {
            'path': 'email:footer'
          }
        }
      };

      // Trigger the Email-Optin custom event to signial after successful email signup
      const evt = {
        'name': 'Email-Optin'
      };

      yield put( triggerAnalyticsEvent( data, evt ) );

    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function( CONFIG ){
  return function*( ){
    let serviceType = 'subscribe';

    // register events for the request
    registerServiceName( serviceType );

    yield takeEvery( getServiceType( 'subscribe', 'requested' ), listener, serviceType, CONFIG );
  }
}
