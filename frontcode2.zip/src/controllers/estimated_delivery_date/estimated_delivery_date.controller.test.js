/**
 * Created by rush on 5/3/17.
 */

/**
 * Estimated Delivery  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  ajax
} from '../../utils/ajax/ajax';
import saga, { listener } from './estimated_delivery_date.controller';



const type = 'estimatedDeliveryDate';
const sessionID = undefined;
describe( 'defaultSaga Saga', () => {

  registerServiceName( type );

  const estimatedDeliveryDateSaga = saga();

  it( 'should listen for the estimatedDeliveryDate requested method', () =>{

    const takeEveryDescriptor = estimatedDeliveryDateSaga.next().value;

    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );

  } );

  describe( 'listener saga success path', () => {

    const listenerSaga = listener( type, { data: sessionID } );

    it( 'should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor  = listenerSaga.next().value;


      expect( callDescriptor ).toEqual( call( ajax, { type } ) );

    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        body: {
          data:{
            title: 'test',
            status: 'ok',
            shippingInfo : {
              messages :[
                {
                  key : 'address error',
                  desc : 'error occurred'
                }
              ],
              shipMethodInfo : {
                items:[
                  {
                    'cost': 'FREE',
                    'displayName': 'Standard Shipping',
                    'shipMethod': 'free_shipping',
                    'isSelected': true,
                    'estimatedDelivery': null
                  }
                ]
              }
            }
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should throw the error', () => {

      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }

      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );

  } );


} );
