import {
  takeEvery,
  call,
  put
} from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  host,
  fullyQualifyLink
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import { ajax } from '../../utils/ajax/ajax';
import appConstants from '../../shared/appConstants';


export const listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const query = {
      orderId: action.data.orderId,
      emailId: action.data.email
    };

    const res = yield call(
      ajax, {
        type,
        method:'post',
        query
      }
    );

    const orderContentPage = `${ appConstants.ROUTES.ORDER_CONTENT_ANONYMOUS_PAGE }?orderId=${ action.data.orderId }&emailId=${ action.data.email }`;

    if( res.body.data ){
      // order status page will be redirected to order_content_anonymous.jsp
      // only when the id from fetchOrderDetails response is not null
      if( res.body.data.id ){
        global.location.href = fullyQualifyLink( host, orderContentPage );
      }
      else {
        yield put( getActionDefinition( type, 'success' )( res.body.data ) );
      }
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    console.log( err ); // eslint-disable-line
  }
};

export default function*(){
  let serviceType = 'fetchOrderDetails';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
