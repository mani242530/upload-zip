import {
  takeEvery,
  put,
  call
} from 'redux-saga/effects';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import { cloneableGenerator } from 'redux-saga/utils';
import {
  host,
  fullyQualifyLink
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import { ajax } from '../../utils/ajax/ajax';
import saga, { listener } from './fetch_order_details.controller';
import appConstants from '../../shared/appConstants';

jest.mock( 'ulta-fed-core/dist/js/utils/formatters/formatters', () => {
  return { fullyQualifyLink:jest.fn(), host: undefined }
} );

describe( 'FetchOrderDetails Saga', () => {
  const type = 'fetchOrderDetails';
  registerServiceName( type );
  const fetchOrderDetailsSaga = saga();

  const action = {
    data: {
      orderId: 'D12345',
      email: 'test@ulta.com'
    }
  };

  describe( 'default saga', () => {
    it( 'should listen for the fetchOrderDetails request method', () => {
      const takeEveryDescriptor = fetchOrderDetailsSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), listener, type )
      );
    } );
  } );

  describe( 'listener saga', () => {

    const listenerSaga = cloneableGenerator( listener )( type, action );
    let listenerSagaClone1;
    let listenerSagaClone2;

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( ) ) );
    } );

    it( 'should call fetchOrderDetails API', () => {
      const callDescriptor = listenerSaga.next( ).value;
      listenerSagaClone1 = listenerSaga.clone();
      listenerSagaClone2 = listenerSaga.clone();

      expect( callDescriptor ).toEqual( call( ajax, {
        type,
        method: 'post',
        query: {
          orderId: action.data.orderId,
          emailId: action.data.email
        }
      } ) );
    } );

    it( 'should not put fetchOrderDetails success event after fetchOrderDetails API call if res.body.data is null', () => {
      const res = {
        body: {
          data: null
        }
      }
      const putDescriptor = listenerSagaClone1.next( res );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
      expect( putDescriptor.done ).toEqual( true );
    } );

    it( 'should not call fullyQualifyLink after fetchOrderDetails success event if res.body.data.id is null', () => {
      const res = {
        body: {
          data: {
            id: null,
            message:{
              items:[
                {
                  type:'error',
                  message:'invalid record'
                }
              ]
            }
          }
        }
      }
      const putDescriptor = listenerSagaClone2.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
      const callDescriptor = listenerSagaClone2.next().done;

      expect( callDescriptor ).toEqual( true );
      expect( fullyQualifyLink ).not.toBeCalled( );
    } );

    it( 'should call fullyQualifyLink with orderContentPage url if the response has a valid id', () => {
      const orderContentPage = `${ appConstants.ROUTES.ORDER_CONTENT_ANONYMOUS_PAGE }?orderId=${action.data.orderId}&emailId=${action.data.email}`;
      const res = {
        body: {
          data: {
            id: 'test id'
          }
        }
      }
      const callDescriptor = listenerSaga.next( res ).done;

      expect( callDescriptor ).toEqual( true );
      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, orderContentPage );
    } );
  } );

  describe( 'failure path', () => {
    const failureSaga = listener( type, action );
    failureSaga.next();
    window.console = {
      log:jest.fn()
    }
    const err = {
      statusText:'failure message'
    };

    it( 'should put a failure event if any error occurs during the sagas execution', () => {
      const putDescriptor = failureSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

    it( 'should log the error to the console', () => {
      const putDescriptor = failureSaga.next();
      expect( window.console.log ).toHaveBeenCalledWith( err );
    } );

  } );
} );