import {
  takeEvery,
  call,
  put,
  cancelled
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { ajax } from '../../utils/ajax/ajax';

export const loadFavoriteSku = function* ( type, CONFIG, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const query = {};
    query.skuId = action.data;
    const res = yield call( ajax,
      {
        type:'findFavorite',
        query
      } );
    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}
export default function( CONFIG ){
  return function*( ){
    const pdpServiceType = 'pdpFindFavorite';
    registerServiceName( pdpServiceType );
    yield takeEvery( getServiceType( pdpServiceType, 'requested' ), loadFavoriteSku, pdpServiceType, CONFIG )

    const qsServiceType = 'qsFindFavorite';
    registerServiceName( qsServiceType );
    yield takeEvery( getServiceType( qsServiceType, 'requested' ), loadFavoriteSku, qsServiceType, CONFIG )
  }
}
