import {
  takeEvery,
  call,
  put,
  cancelled,
  take
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { cloneableGenerator } from 'redux-saga/utils';
import { ajax } from '../../utils/ajax/ajax';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import CONFIG from '../../modules/pdp/pdp.config';
import saga, {
  loadFavoriteSku
} from './find_favorite.controller';

const type = 'pdpFindFavorite';
const serviceType = 'qsFindFavorite';

var action = { data: 44432 }
const listenerSaga = loadFavoriteSku( type, CONFIG, action );
describe( 'loadFavoriteSku sagas', () => {
  const coreSaga = saga( CONFIG )();
  registerServiceName( type );

  it( 'should take every loadFavoriteSku request from pdp', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), loadFavoriteSku, type, CONFIG ) );
  } );
  it( 'should take every loadFavoriteSku request from quick shop', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( serviceType, 'requested' ), loadFavoriteSku, serviceType, CONFIG ) );
  } );

  describe( 'loadFavoriteSku saga success path', () => {

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      const query = {};
      query.skuId = action.data;

      expect( callDescriptor ).toEqual( call( ajax, { type:'findFavorite', query } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

  } );

  describe( 'addToFavorites saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );
} );
