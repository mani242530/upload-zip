import { takeEvery, call, put } from 'redux-saga/effects';

import {
  checkoutRedirectListener,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ajax
} from '../../utils/ajax/ajax';


import {
  REMOVE_GIFT_FROM_CART,
  ADD_TO_CART,
  SELECT_GIFT_VARIANT
} from '../../events/mini_cart/mini_cart.events';

// Individual exports for testing
export const listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let query = {
      promotionId: action.item
    }
    const res = yield call( ajax,
      {
        type,
        method: 'post',
        query
      } );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data ){

      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( checkoutRedirectListener( action.history, qty, loadCartMessages ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}
export const variantlistener = function*( type, action ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let query = {
      addGwpSkuId: action.skuid,
      promotionId: action.promotionid
    }
    const res = yield call( ajax,
      {
        type,
        method: 'post',
        query
      } );


    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data ){
      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( checkoutRedirectListener( action.history, qty, loadCartMessages ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }
}

export default function*(){
  let serviceType = 'removeGiftFromCart';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( REMOVE_GIFT_FROM_CART, listener, serviceType );

  serviceType = 'addItemToCart';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( ADD_TO_CART, listener, serviceType );

  serviceType = 'selectGiftVariant';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( SELECT_GIFT_VARIANT, variantlistener, serviceType );

}
