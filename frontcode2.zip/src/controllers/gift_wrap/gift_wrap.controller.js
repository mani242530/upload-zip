/**
 * Created by rush on 5/11/17.
 */
import { takeLatest, call, put } from 'redux-saga/effects';

import {
  checkoutRedirectListener,
  types as serviceActionTypes,
  registerServiceName,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  SET_GIFT_WRAP_GIFT_NOTE_SERVICE,
  SET_GIFT_WRAP_GIFT_BOX_SERVICE
} from '../../events/mini_cart/mini_cart.events';


// Individual exports for testing
export const listener = function*( type, action ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );
    let query;
    if( type === 'addGiftNote' ){
      let note = action.giftNote && action.giftNote.replace( /\n/g, ' ' ).trim();

      query = {
        giftNote: encodeURIComponent( note )
      }
    }
    else {
      let giftBoxStatus = action.giftboxStatus;
      query = {
        addGiftWrap:giftBoxStatus
      }
    }


    const res =      yield call( ajax,
      {
        type,
        method:'post',
        query
      } );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data ){
      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( checkoutRedirectListener( action.history, qty, loadCartMessages ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'addGiftNote';
  // register events for the request
  registerServiceName( serviceType );
  yield takeLatest( SET_GIFT_WRAP_GIFT_NOTE_SERVICE, listener, serviceType );

  serviceType = 'addGiftWrap';
  // register events for the request
  registerServiceName( serviceType );
  yield takeLatest( SET_GIFT_WRAP_GIFT_BOX_SERVICE, listener, serviceType );

}
