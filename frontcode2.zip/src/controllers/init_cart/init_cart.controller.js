/**
 * InitCart sagas
 */

import {
  take, takeEvery, call, put, select, cancel, cancelled
} from 'redux-saga/effects';
import { delay } from 'redux-saga';
import {
  pageRedirect,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import isUndefined from 'lodash/isUndefined';
import find from 'lodash/find';
import isEmpty from 'lodash/isEmpty';
import isNumber from 'lodash/isNumber';
import has from 'lodash/has';
import get from 'lodash/get';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  removeQueryString
} from '../../utils/remove_query_string/remove_query_string';
import appConstants from '../../shared/appConstants';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getUserState } from '../../models/view/user/user.model';
import {
  ajax
} from '../../utils/ajax/ajax';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import {
  loadLiveChat
} from '../../events/live_chat/live_chat.events';
import {
  setDisplayDavPopUp
} from '../../events/checkout_page/checkout_page.events';
import { getCartState } from '../../models/view/cart/cart.model';
import CONFIG from '../../config';
import getHistory from '../../utils/history/history';

export const checkForRedirect = function*( action ){

  const UserData = yield select( getUserState );
  const CartData = yield select( getCartState );

  const {
    isSignedIn,
    shoppingCartCount
  } = UserData;

  const {
    history
  } = action.data;

  const {
    pathname
  } = action.data.history.location;

  const cartCount = parseInt( shoppingCartCount, 10 );
  let signedInEmptyBag = appConstants.ROUTES.BAG_EMPTY_PAGE;
  let signedOutEmptyBag = appConstants.ROUTES.BAG_LOGIN_PAGE;
  const bagPage = appConstants.ROUTES.BAG_PAGE;
  const checkoutPage = appConstants.ROUTES.CHECKOUT_PAGE;

  // if the cart data or cartPageData is empty we must call load cart
  // to make sure that we have the information to determin
  // if the user has opted into AND selected a free gift item
  if( isEmpty( CartData ) || isEmpty( CartData.cartPageData ) ){

    yield put( getActionDefinition( 'loadCart', 'requested' )( { history } ) );
    const cartPageData = yield take( getServiceType( 'loadCart', 'success' ) );

    const {
      giftItems
    } = cartPageData.data;

    // check the loadCartData to see if any of the items are opted in AND the if they are
    // check to see if the freeGift is selected for that 'indulge'.  If it opted in
    // and not selected we should redirect the user to the cart page, so that they can
    // make their selections

    let isAllVariantsSelected = true;

    if( !isEmpty( giftItems ) ){
      for ( let giftItem of giftItems ){
        if( giftItem && giftItem.induldge && giftItem.freeGifts && giftItem.freeGifts.length > 2 ){
          let selectedItemVals = giftItem.freeGifts.map( ( freeGift ) => freeGift.selected );
          if( selectedItemVals.indexOf( 'true' ) < 0 ){
            isAllVariantsSelected = false;
            break;
          }
        }
      }
    }

    if( !isAllVariantsSelected ){
      history.replace( bagPage );
      yield put( pageRedirect( checkoutPage, bagPage ) );
      yield cancel();

    }
  }




  // if i am signed in, have no cart items, and I'm not on the signed emptyBagPage redirct me to the signedin emptyBagpage
  if( isSignedIn && cartCount === 0 && pathname !== signedInEmptyBag ){
    history.replace( signedInEmptyBag );
    yield put( pageRedirect( pathname, signedInEmptyBag ) );
    yield cancel();
  }

  // if i am not signed in, have no cart items, and I'm not on the signed out emptyBagPage redirct me to the signed out emptyBagpage
  if( !isSignedIn && cartCount === 0 && pathname !== signedOutEmptyBag ){
    history.replace( signedOutEmptyBag );
    yield put( pageRedirect( pathname, signedOutEmptyBag ) );
    yield cancel();
  }
}

// Individual exports for testing
export const listener = function*( type, action ){

  try {
    const UserData = yield select( getUserState );
    const switchData = yield select( makeGetSwitchesData() );
    const {
      isSignedIn
    } = UserData;

    const history = getHistory();

    // before we do anything we need to see if we need to redirect the user
    yield call( checkForRedirect, action );

    yield put( getActionDefinition( type, 'loading' )() );
    let query = {};
    if( process.env.NODE_ENV === 'development' ){
      const cartData = yield select( getCartState );
      query.deliveryOption = cartData.cartPageData.deliveryOption;
      query.__HAS_PICKUP_SMS_COMMUNICATION_INFO = CONFIG.DEBUGGING.CHECKOUT.hasSmsCommunicationInfo;
    }

    const res = yield call( ajax, { type, query } );
    const payPalDetails =  res.body.data.paymentInfo && find( res.body.data.paymentInfo.items, { paymentType:'paypal' } );
    const creditCardDetails = res.body.data.paymentInfo && find( res.body.data.paymentInfo.items, { paymentType:'creditCard' } );
    const afterpayDetails = res.body.data.paymentInfo && find( res.body.data.paymentInfo.items, { paymentType:'afterpay' } );

    // To create Present Afterpay script
    if( switchData.switches.enableAfterpay && res.body.data?.afterpay?.afterpayEligible ){
      yield put( getActionDefinition( 'afterpay', 'requested' )( ) );
      yield take( getServiceType( 'afterpay', 'success' ) );
    }

    yield put( getActionDefinition( type, 'success' )( { result:res.body.data, isSignedIn:isSignedIn } ) );

    // Need to check if the user have saved credit to determine the paymentInformation view on page load
    // Get user credit card details if the payment type is paypal or afterpay or if default credit card have an error.
    if( isSignedIn && ( payPalDetails || ( creditCardDetails && creditCardDetails.messages ) || afterpayDetails ) ){
      yield put( getActionDefinition( 'profileCreditCards', 'requested' )( { view: null } ) );
      yield take( getServiceType( 'profileCreditCards', 'success' ) );
    }

    // get the afterpay params (ordertoken and status) from history.location.search
    const params = new URLSearchParams( history.location.search );
    const afterpayOrderToken = params.get( 'orderToken' );
    const afterpayStatus = params.get( 'status' );

    // check whether afterpay order token is valid and order status is true which will be return
    // in search url after successful Afterpay payment
    if( afterpayOrderToken && afterpayStatus === 'SUCCESS' ){
      const afterpayData = {
        paymentType: 'afterpay',
        nonce: afterpayOrderToken
      }

      // Need to check if the user have saved credit to determine the paymentInformation view on page load after redirect from afterpay portal
      if( isSignedIn ){
        yield put( getActionDefinition( 'profileCreditCards', 'requested' )( { view: null } ) );
        yield take( getServiceType( 'profileCreditCards', 'success' ) );
      }

      // invoke the payment service call for afterpay paymentType
      // paymentInvokeFromInitCart flag is used to avoid updating afterpay widget in afterpay.model
      yield put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: afterpayData, paymentInvokeFromInitCart: true } ) );
      let paymentResponse =  yield take( getServiceType( 'paymentServiceResponse', 'success' ) );

      // getting the afterpay details from payment service success response
      const afterpayDetails = find( paymentResponse.data.result.paymentInfo?.items, ['paymentType', 'afterpay'] );
      // if payment service success call gives valid afterpayDetails in response, remove the afterpay params from search url
      if( afterpayDetails ){
        yield call( removeQueryString );
      }
    }

    // Analytics tracking code begin
    if( !isUndefined( res.body.data ) ){

      const {
        cartSummary,
        cartItems,
        freeSampleInfo,
        shippingInfo,
        paymentDetails
      } = res.body.data;

      let sampleAdded;
      let sampleSkuId;
      const cartContents = ( cartItems.items.map( ( item, index ) => {
        if( item.itemType === 'sample' ){
          sampleAdded = 'true';
          sampleSkuId = item.catalogRefId
        }
        return {
          ...( item.productId && { 'productId': item.productId } ),
          ...( item.catalogRefId && { 'skuId': item.catalogRefId } ),
          ...( item.productDisplayName && { 'productName': item.productDisplayName } ),
          'pageURL': '/checkout/',
          ...( item.brandName && { 'manufacturer': item.brandName } ),
          ...( item.productURL && { 'pageURL': item.productURL } ),
          ...( item.quantity && { 'quantity': item.quantity } ),
          ...( !isUndefined( item.adbugMessageMap ) && item.adbugMessageMap !== null && { 'promotions': item.adbugMessageMap.adbugMessage } ),
          ...( { 'itemType': item.itemType } )
        };

      } ) );

      let messages = [];
      if( !isEmpty( shippingInfo ) && !isEmpty( shippingInfo.messages ) ){
        messages.push( ...shippingInfo.messages.items );
      }

      if( !isEmpty( paymentDetails ) ){
        paymentDetails.forEach( function( payment ){
          if( !isEmpty( payment.messages ) ){
            messages.push( ...payment.messages.items );
          }
        } );
      }
      const data = {
        'globalPageData': {
          'action':{
            'sampleAdded': sampleAdded
          },
          'sampleSkuId': sampleSkuId,
          'order': {
            'currency': cartSummary.currencyCode,
            'total': ( cartSummary.estimatedTotal ) ? ( cartSummary.estimatedTotal ).toFixed( 2 ) : cartSummary.estimatedTotal,
            'subtotal': ( cartSummary.subTotal ) ? ( cartSummary.subTotal ).toFixed( 2 ) : cartSummary.subTotal,
            'shipping': ( isNumber( cartSummary.shippingCost ) ? ( cartSummary.shippingCost ).toFixed( 2 ) : cartSummary.shippingCost ),
            'itemCount': cartSummary.itemCount,
            'voucher_discount': cartSummary.couponDiscount,
            'orderItems': cartContents
          },
          'checkout': {
            'bopisStorePickup': `${!!res.body.data.pickupInfo}`
          },
          'messages' : messages
        }
      }

      const evt = {
        'name': 'pageNavigation'
      }
      const shippingStatus = shippingInfo && shippingInfo.shippingStatus;

      if( isSignedIn && shippingStatus === 'InvalidAddress' ){
        yield put( getActionDefinition( 'addressbook', 'requested' )( ) );
      }
      if( !isSignedIn && shippingStatus === 'CorrectedAddress' ){
        // on load of checkout page if the address applied to the order is an address which needs to be 'corrected'
        // address verification popup will be displayed for the anonymous users. For logged in users it will be displayed on place order
        // As per the business requirment when the page is being loaded there should be a small delay before the popup is displayed
        // initcart saga gets invoked during page load and the below logic will ensure
        // that the displayDavPopUp value in the store will be set only after a small delay, which will inturn delay popup display as well
        yield call( delay, 2000 );
        yield put( setDisplayDavPopUp() );
      }

      // Need to check if shipping details are present
      // if there is a selected addres and shipmode, and if the corresponding delivery date is not present,
      // a request needs to be initiated for estimatedDeliveryDate
      const shipMethodInfo = get( shippingInfo, 'shippingAddress' ) && get( shippingInfo, 'shipMethodInfo' ) &&
      shippingInfo.shipMethodInfo.items.find( shipMethodInfo => shipMethodInfo.isSelected && !shipMethodInfo.estimatedDelivery );
      if( shipMethodInfo ){
        yield put( getActionDefinition( 'estimatedDeliveryDate', 'requested' )() );
      }

      if( shippingStatus === 'IncompatibleShipping' ){
        let analyticsEvent =          {
          name: 'trackErrorDisplayed',
          data: {
            'errorType': 'form',
            'errorLabel': 'shipping',
            'errorDescription': shippingInfo.messages.items
          }
        };
        yield put( triggerAnalyticsEvent( analyticsEvent ) );
      }

      // Only dispatch page navigation event when loading of checkout.
      if( !isUndefined( action.data.firePageNavigation ) && action.data.firePageNavigation ){
        yield put( setDataLayer( data, evt ) );
      }
      else {
        yield put( setDataLayer( data ) );
      }

      if( !isEmpty( messages ) ){
        const messageEvent = {
          'name': 'serviceMessagesUpdated'
        }
        yield put( setDataLayer( data, messageEvent ) );
      }


    }
    // Analtyics tracking code end


    // will load livechat in checkout page only if enableUltaChat is true
    if( switchData.switches.enableUltaChat ){
      yield put( loadLiveChat() );
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
  finally {
    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'canceled' )() );
    }
  }
}

export default function*(){
  let serviceType = 'initCart';
  // register events for the request
  registerServiceName( serviceType );

  yield takeEvery( getServiceType( 'initCart', 'requested' ), listener, serviceType );

}
