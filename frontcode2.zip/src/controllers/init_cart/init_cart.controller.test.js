/**
 * InitCart sagas test
 */

import {
  takeEvery, call, select, put, take, cancelled
} from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/lib/utils';
import Cookies from 'js-cookie';
import { delay } from 'redux-saga';
import {
  pageRedirect,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  removeQueryString
} from '../../utils/remove_query_string/remove_query_string';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getUserState } from '../../models/view/user/user.model';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import {
  ajax
} from '../../utils/ajax/ajax';


import {
  loadLiveChat
} from '../../events/live_chat/live_chat.events';
import {
  setDisplayDavPopUp
} from '../../events/checkout_page/checkout_page.events';
import { getCartState } from '../../models/view/cart/cart.model';
import saga, { listener, checkForRedirect } from './init_cart.controller';
import CONFIG from '../../config';
import appConstants from '../../shared/appConstants';
import getHistory from '../../utils/history/history';

const type = 'initCart';
const type2 = 'profileCreditCards';
const history = getHistory();

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );
  registerServiceName( type2 );
  registerServiceName( 'estimatedDeliveryDate' );
  registerServiceName( 'paymentServiceResponse' );
  registerServiceName( 'afterpay' );

  const initCartSaga = saga();

  it( 'should listen to initCart service calls', () =>{

    const takeEveryDescriptor = initCartSaga.next().value;

    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );

  } );


  describe( 'listener saga success path', () => {
    const action = {
      data:{
        firePageNavigation: true,
        history: {
          location: {
            pathname: '/checkout',
            search: 'www.ulta.com/checkout'
          }
        }
      }
    };
    const listenerSaga = cloneableGenerator( listener )( type, action );
    let listenerSagaCloneA;
    const UserData = {
      isSignedIn: true
    }

    it( 'should select UserData', () =>{
      const selectDescriptor = listenerSaga.next().value;
      expect( selectDescriptor ).toEqual( select( getUserState ) );
    } );

    it( 'should select switchesData ', () => {
      const selectDescriptor = listenerSaga.next( UserData ).value;
      listenerSagaCloneA = listenerSaga.clone();
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'before we do anything we need to see if we need to redirect the user', () => {
      const switchData = {
        switches: {
          enableUltaChat: true,
          enableAfterpay: false
        }
      };
      const callDescriptor = listenerSaga.next( switchData ).value;
      expect( callDescriptor ).toEqual( call( checkForRedirect, action ) );
    } );

    it( 'should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      let query = {};
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );
    } );
    let listenerSagaClone;
    let listenerSagaClone1;
    let listenerSagaClone2;
    let listenerSagaClone3;
    it( 'should put success action', () => {
      const res = {
        body:{
          data:{
            cartItems: {
              items: []
            },
            cartSummary:{},
            shippingInfo:{
              shippingStatus:'CorrectedAddress'
            }
          }
        }
      }
      listenerSagaClone = listenerSaga.clone();
      listenerSagaClone1 = listenerSaga.clone();
      listenerSagaClone2 = listenerSaga.clone();
      listenerSagaClone3 = listenerSaga.clone();
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { result:res.body.data, isSignedIn:true } ) ) );
    } );


    it( 'should put dataLayerActions action for a order having fulfillment type as pickup - Shippinginfo=null', () => {
      const res = {
        body:{
          data:{
            cartItems: {
              items: []
            },
            cartSummary:{},
            shippingInfo:null,
            pickupInfo: {
              storeInfo: {
                storeTimings: '10:00 am - 9:00 pm'
              }
            },
            afterpay:{
              afterpayEligible : true
            }
          }
        }
      }
      listenerSagaClone3.next( res );
      const putDescriptor = listenerSagaClone3.next( ).value;
      const data = {
        'globalPageData': {
          'action': {
            'sampleAdded': undefined
          },
          'sampleSkuId': undefined,
          'order': {
            'currency': undefined,
            'total': undefined,
            'subtotal': undefined,
            'shipping': undefined,
            'itemCount': undefined,
            'voucher_discount': undefined,
            'orderItems': []
          },
          'checkout': {
            'bopisStorePickup': 'true'
          },
          'messages': []
        }
      }
      const evt = {
        'name': 'pageNavigation'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put liveChatActions action as the dataLayer is updated by now and enableUltaChat is true ', () => {
      const putDescriptor = listenerSagaClone3.next().value;
      expect( putDescriptor ).toEqual( put( loadLiveChat() ) );
    } );

    it( 'should not put liveChatActions action as the dataLayer is updated by now and if enableUltaChat is false', () => {
      const switchData = {
        switches: {
          enableUltaChat: false,
          enableAfterpay: false
        }
      };
      const res = {
        body:{
          data:{
            cartItems: {
              items: []
            },
            cartSummary:{},
            shippingInfo:null,
            pickupInfo: {
              storeInfo: {
                storeTimings: '10:00 am - 9:00 pm'
              }
            },
            afterpay:{
              afterpayEligible : true
            }
          }
        }
      }

      listenerSagaCloneA.next( switchData ); // this is call checkForRedirect method
      listenerSagaCloneA.next(); // this is init loading
      listenerSagaCloneA.next(); // this is init ajax call
      listenerSagaCloneA.next( res ); // this is init success
      listenerSagaCloneA.next(); // this is dataLayerActions action
      const putDescriptor = listenerSagaCloneA.next( ).value;
      expect( putDescriptor ).not.toEqual( put( loadLiveChat() ) );
    } );

    it( 'should put analytic action if the shippingstatus in the response is IncompatibleShipping', () => {

      const res = {
        body: {
          data: {
            cartItems: {
              items: []
            },
            cartSummary: {},
            shippingInfo: {
              messages: {
                items: [
                  {
                    key : 'address error',
                    desc : 'error occurred'
                  }
                ]
              },
              shippingStatus:'IncompatibleShipping'
            }
          }
        }
      };


      const putDescriptor = listenerSagaClone2.next( res ).value;
      let analyticsEvent =      {
        name: 'trackErrorDisplayed',
        data: {
          'errorType': 'form',
          'errorLabel': 'shipping',
          'errorDescription':[
            {
              key : 'address error',
              desc : 'error occurred'
            }
          ]
        }
      }
      expect( listenerSagaClone2.next().value ).toEqual( put( triggerAnalyticsEvent( analyticsEvent ) ) );
    } );


    describe( 'data layer actions', () => {
      const res = {
        body : {
          data: {
            cartItems: {
              items: [{
                itemType :'sample'
              }]
            },
            cartSummary: {
              itemCount: 1,
              estimatedTotal: 100,
              subTotal: 50,
              shippingCost: 10
            },
            shippingInfo: {
              messages:{
                items: [{
                  key: 'failure',
                  desc: 'error occurred'
                }]
              }
            },
            pickupInfo:null,
            paymentDetails: [
              {
                messages:{
                  items: [{
                    'messageDesc': 'Credit card is expired.',
                    'messageKey': 'CREDIT_CARD_NOT_VALID',
                    'messageType': 'Error'
                  }]
                }
              }
            ]
          }
        }
      }
      const messages = res.body.data.shippingInfo.messages.items.concat( res.body.data.paymentDetails[0].messages.items );

      const data = {
        'globalPageData': {
          'action': {
            'sampleAdded': 'true'
          },
          'sampleSkuId': undefined,
          'order': {
            'currency': undefined,
            'total': '100.00',
            'subtotal': '50.00',
            'shipping': '10.00',
            'itemCount': 1,
            'voucher_discount': undefined,
            'orderItems': [{
              'itemType':'sample',
              'pageURL':'/checkout/'
            }]
          },
          'checkout': {
            'bopisStorePickup': 'false'
          },
          'messages': messages
        }
      }
      const errEvent = {
        'name': 'serviceMessagesUpdated'
      }

      it( 'should put a datalayer action with a numeric value for shipping cost', () => {
        const callDescriptor = listenerSagaClone1.next( res ).value;
        listenerSagaClone1.next();
        expect( listenerSagaClone1.next().value ).toEqual( put( setDataLayer( data, errEvent ) ) );
      } );

      it( 'should put a datalayer action with a non numeric value for shipping cost', () => {
        res.body.data.cartSummary.shippingCost = 'FREE';
        data.globalPageData.order.shipping = 'FREE';
        listenerSagaClone.next( res );
        listenerSagaClone.next();
        expect( listenerSagaClone.next().value ).toEqual( put( setDataLayer( data, errEvent ) ) );
      } );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

    it( 'should cancel the event if an error occured in the service', () => {

      const cancelDescriptor = listenerSaga.next().value;

      expect( cancelDescriptor ).toEqual( cancelled() );

    } );

    it( 'should put a cancel action', () => {

      const putDescriptor = listenerSaga.next( true, global ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'canceled' )() ) );

    } )

  } );

  describe( 'listener saga success path for anonymous user', () => {
    const action = {
      data:{
        firePageNavigation: true,
        history: {
          location: {
            pathname: '/checkout',
            search: '?status=SUCCESS&orderToken=testToken'
          }
        }
      }
    };
    const listenerSaga = cloneableGenerator( listener )( type, action );
    let listenerSagaClone1;
    let listenerSagaClone2;
    let listenerSagaClone3;
    let listenerSagaClone4;
    const UserData = {
      isSignedIn: false
    }

    const res = {
      body:{
        data:{
          cartSummary:{},
          cartItems:{
            items:[]
          },
          shippingInfo:{
            shippingStatus:'CorrectedAddress',
            shippingAddress:{},
            shipMethodInfo:{
              items:[
                {
                  shipMethod: 'ups_ground',
                  isSelected:true,
                  estimatedDelivery:null
                }
              ]
            }
          }
        }
      }
    }
    it( 'should put delay action if the shippingstatus in the response is corrected address', () =>{
      const selectDescriptor = listenerSaga.next().value;
      expect( selectDescriptor ).toEqual( select( getUserState ) );
    } );

    it( 'should select switchesData ', () => {
      const selectDescriptor = listenerSaga.next( UserData ).value;
      listenerSagaClone2 = listenerSaga.clone();
      listenerSagaClone3 = listenerSaga.clone();
      listenerSagaClone4 = listenerSaga.clone();
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'before we do anything we need to see if we need to redirect the user', () => {
      const switchData = {
        switches: {
          enableUltaChat: true,
          enableAfterpay: false
        }
      };
      const callDescriptor = listenerSaga.next( switchData ).value;
      expect( callDescriptor ).toEqual( call( checkForRedirect, action ) );
    } );

    it( 'should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( ajax, { type, query:{} } ) );
    } );

    it( 'should put success action', () => {
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { result:res.body.data, isSignedIn:false } ) ) );
    } );

    it( 'should put paymentServiceResponse requested', () => {
      history.location.search = '?orderToken=testToken&status=SUCCESS';
      const afterpayData = {
        paymentType: 'afterpay',
        nonce:'testToken'
      }
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).not.toEqual( put( getActionDefinition( 'profileCreditCards', 'requested' )( { view: null } ) ) );
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: afterpayData, paymentInvokeFromInitCart: true } ) ) );
    } );

    it( 'should put paymentServiceResponse success', () => {
      const takeDescriptor = listenerSaga.next().value;
      listenerSagaClone1 = listenerSaga.clone();
      expect( takeDescriptor ).toEqual( take( getServiceType( 'paymentServiceResponse', 'success' ) ) );
    } );

    it( 'should call removeQueryString method if paymentResponse has paymentType as afterpay', () => {
      const paymentResponse = {
        data: {
          result: {
            paymentInfo: {
              items: [
                {
                  paymentType : 'afterpay'
                }
              ]
            }
          }
        }
      }
      const callDescriptor = listenerSaga.next( paymentResponse ).value;
      expect( callDescriptor ).toEqual( call( removeQueryString ) );
    } );

    it( 'should not call removeQueryString method if paymentInfo is null', () => {
      const paymentResponse = {
        data: {
          result: {
            paymentInfo: null
          }
        }
      }
      const callDescriptor = listenerSagaClone1.next( paymentResponse ).value;
      expect( callDescriptor ).not.toEqual( call( removeQueryString ) );
    } );

    it( 'should put delay action if the shippingstatus in the response is corrected address', () =>{
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( call( delay, 2000 ) );
    } );

    it( 'should put setDisplayDavPopUp action if the shippingstatus in the response is corrected address', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( setDisplayDavPopUp() ) );
    } );

    it( 'Should put estimated delivery dal call request', () =>{
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'estimatedDeliveryDate', 'requested' )() ) );
    } );

    it( 'should not put paymentServiceResponse requested after initcart success if history url search params does not contains orderToken or status', () =>{
      const action = {
        data:{
          firePageNavigation: true
        }
      };
      history.location.search = '';
      history.location.pathname = '/checkout';
      const afterpayData = {
        paymentType: 'afterpay',
        nonce: 'testToken',
        afterpayStatus: 'true'
      }

      const switchData = {
        switches: {
          enableUltaChat: true,
          enableAfterpay: false
        }
      };

      const listenerSaga = listener( type, action );
      listenerSaga.next(); // this is select getUserState method
      listenerSaga.next( UserData ); // this is select getUserState method
      listenerSaga.next( switchData ); // this is call checkForRedirect method
      listenerSaga.next(); // this is init loading
      listenerSaga.next(); // this is init ajax call
      listenerSaga.next( res ); // this is init success
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).not.toEqual( put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: afterpayData } ) ) );
      expect( putDescriptor ).toEqual( call( delay, 2000 ) );
    } );

    it( 'should not put paymentServiceResponse requested after initcart success if history url search params status is false', () =>{
      const action = {
        data:{
          firePageNavigation: true
        }
      };
      history.location.search = '?status=false&orderToken=testToken';
      history.location.pathname = '/checkout';
      const afterpayData = {
        paymentType: 'afterpay',
        nonce: 'testToken',
        afterpayStatus: 'true'
      }
      const switchData = {
        switches: {
          enableUltaChat: true,
          enableAfterpay: false
        }
      };

      const listenerSaga = listener( type, action );
      listenerSaga.next(); // this is select getUserState method
      listenerSaga.next( UserData ); // this is select getUserState method
      listenerSaga.next( switchData ); // this is call checkForRedirect method
      listenerSaga.next(); // this is init loading
      listenerSaga.next(); // this is init ajax call
      listenerSaga.next( res ); // this is init success
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).not.toEqual( put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: afterpayData } ) ) );
      expect( putDescriptor ).toEqual( call( delay, 2000 ) );
    } );

    it( 'should put afterpay requested if enableAfterpay and afterpayEligible is true', () =>{
      const res = {
        body: {
          data: {
            afterpay: {
              afterpayEligible: true
            }
          }
        }
      }
      const switchData = {
        switches: {
          enableUltaChat: true,
          enableAfterpay: true
        }
      };

      listenerSagaClone2.next( switchData ); // this is call checkForRedirect method
      listenerSagaClone2.next(); // this is init loading
      listenerSagaClone2.next(); // this is init ajax call
      const putDescriptor = listenerSagaClone2.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'afterpay', 'requested' )() ) );
    } );

    it( 'should take afterpay success after afterpay requested', () =>{
      const takeDescriptor = listenerSagaClone2.next( ).value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'afterpay', 'success' ) ) );
    } );

    it( 'should not put afterpay requested after init ajax call if enableAfterpay is false and afterpayEligible is true', () =>{
      const res = {
        body: {
          data: {
            afterpay: {
              afterpayEligible: true
            }
          }
        }
      }
      const switchData = {
        switches: {
          enableUltaChat: true,
          enableAfterpay: false
        }
      };

      listenerSagaClone3.next( switchData ); // this is call checkForRedirect method
      listenerSagaClone3.next(); // this is init loading
      listenerSagaClone3.next(); // this is init ajax call
      const putDescriptor = listenerSagaClone3.next( res ).value;
      expect( putDescriptor ).not.toEqual( put( getActionDefinition( 'afterpay', 'requested' )() ) );
    } );

    it( 'should not put afterpay requested after init ajax call if enableAfterpay is true and afterpayEligible is false', () =>{
      const res = {
        body: {
          data: {
            afterpay: {
              afterpayEligible: false
            }
          }
        }
      }
      const switchData = {
        switches: {
          enableUltaChat: true,
          enableAfterpay: true
        }
      };

      listenerSagaClone4.next( switchData ); // this is call checkForRedirect method
      listenerSagaClone4.next(); // this is init loading
      listenerSagaClone4.next(); // this is init ajax call
      const putDescriptor = listenerSagaClone4.next( res ).value;
      expect( putDescriptor ).not.toEqual( put( getActionDefinition( 'afterpay', 'requested' )() ) );
    } );

  } )

  describe( 'listener saga success path -development env', () => {
    beforeEach( () => {
      process.env.NODE_ENV = 'development';
    } );
    afterEach( () => {
      process.env.NODE_ENV = 'test';
    } );
    const action = { data:{ firePageNavigation: true } };
    const listenerSaga = cloneableGenerator( listener )( type );
    let listenerSaga1;
    const UserData = {
      isSignedIn: true
    }
    const switchData = {
      switches: {
        enableUltaChat: true,
        enableAfterpay: false
      }
    };

    it( 'should select cartData', () => {
      listenerSaga.next(); // select UserData
      listenerSaga.next( UserData ); // select makeGetSwitchesData
      listenerSaga.next( switchData ); // before we do anything we need to see if we need to redirect the user
      listenerSaga.next(); // loading event
      const selectDescriptor = listenerSaga.next().value;
      let query = {};
      expect( selectDescriptor ).toEqual( select( getCartState ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const cartData = {
        cartPageData:{
          deliveryOption:'pickup'
        }
      }
      const callDescriptor = listenerSaga.next( cartData ).value;
      listenerSaga1 = listenerSaga.clone();
      let query = {
        deliveryOption:'pickup',
        __HAS_PICKUP_SMS_COMMUNICATION_INFO: CONFIG.DEBUGGING.CHECKOUT.hasSmsCommunicationInfo
      }
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );
    } );

    it( 'should put profileCreditCards requested after initcart success if response has afterpayDetails and search is empty', () => {
      history.location.search = '';
      const res = {
        body:{
          data:{
            paymentInfo: {
              items: [
                {
                  paymentType: 'afterpay'
                }
              ]
            }
          }
        }
      }
      listenerSaga1.next( res ); // this is initcart success
      const putDescriptor = listenerSaga1.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'profileCreditCards', 'requested' )( { view: null } ) ) );
    } );

    it( 'should put profileCreditCards requested if paymentInfo is null and status is SUCCESS with valid orderToken in search', () => {
      history.location.search = '?orderToken=testToken&status=SUCCESS';
      const res = {
        body:{
          data:{
            paymentInfo: null
          }
        }
      }
      listenerSaga.next( res ); // this is initcart success
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'profileCreditCards', 'requested' )( { view: null } ) ) );
    } );

    it( 'should put profileCreditCards success', () => {
      const afterpayData = {
        paymentType: 'afterpay',
        nonce:'testToken'
      }
      const takeDescriptor = listenerSaga.next( ).value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'profileCreditCards', 'success' ) ) );

      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: afterpayData, paymentInvokeFromInitCart: true } ) ) );
    } );

  } );


} );


describe( 'checkforredirect test', () => {

  registerServiceName( 'loadCart' );

  const listenerSaga = cloneableGenerator( listener )( type );

  it( 'should select UserData', () =>{

    const selectDescriptor = listenerSaga.next().value;
    expect( selectDescriptor ).toEqual( select( getUserState ) );
  } );

  const action = {
    data: {
      history: {
        location: {
          pathname: '/checkout'
        },
        replace: jest.fn()
      }
    }
  }

  let giftItems = {
    'giftItems': [{
      'freeGifts': [{
        'giftProductId': 'xlsImpprod14051035',
        'giftPDPUrl': '/ulta/browse/productDetail.jsp?productId=xlsImpprod14051035&skuId=2275796',
        'giftCatalogRefId': '2275796',
        'giftDisplayName': 'Online Only FREE deluxe sample POREfessional w/any $35 Benefit purchase',
        'giftCategoryName': 'Gifts with Purchase',
        'giftImageURL': 'https://images.ulta.com/is/image/Ulta/2275796?$md$',
        'selected': 'false',
        'giftBrandName': 'Benefit Cosmetics'
      },
      {
        'giftProductId': 'xlsImpprod14051035',
        'giftPDPUrl': '/ulta/browse/productDetail.jsp?productId=xlsImpprod14051035&skuId=2275796',
        'giftCatalogRefId': '2275796',
        'giftDisplayName': 'Online Only FREE deluxe sample POREfessional w/any $35 Benefit purchase',
        'giftCategoryName': 'Gifts with Purchase',
        'giftImageURL': 'https://images.ulta.com/is/image/Ulta/2275796?$md$',
        'selected': 'false',
        'giftBrandName': 'Benefit Cosmetics'
      },
      {
        'giftProductId': 'xlsImpprod14051035',
        'giftPDPUrl': '/ulta/browse/productDetail.jsp?productId=xlsImpprod14051035&skuId=2275796',
        'giftCatalogRefId': '2275796',
        'giftDisplayName': 'Online Only FREE deluxe sample POREfessional w/any $35 Benefit purchase',
        'giftCategoryName': 'Gifts with Purchase',
        'giftImageURL': 'https://images.ulta.com/is/image/Ulta/2275796?$md$',
        'selected': 'default',
        'giftBrandName': 'Benefit Cosmetics'
      }],
      'promoValidity': 'offer valid 05/07/2017-05/14/2018 or while supplies last',
      'bfxPriceMap': [{ 'bfxQty': '1', 'bfxPrice': '$0.00' }],
      'promoId': '0000156262',
      'induldge': true
    }]
  };

  const bagPage = '/bag';
  const checkoutPage = '/checkout';

  it( 'ensure that redirect action is invoked if gift items not selected', () => {
    const checkForRedirectSaga = checkForRedirect( action );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next( {} );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next();
    const nextDescriptor = checkForRedirectSaga.next( { 'data': giftItems } ).value;
    expect( nextDescriptor ).toEqual( put( pageRedirect( checkoutPage, bagPage ) ) );
  } );

  it( 'ensure that redirect action is not invoked if gift items is selected', () => {
    giftItems.giftItems[0].freeGifts[0].selected = 'true';
    const checkForRedirectSaga = checkForRedirect( action );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next( {} );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next();
    const nextDescriptor = checkForRedirectSaga.next( { 'data': giftItems } ).value;
    expect( nextDescriptor ).toEqual( undefined );
  } );

  it( 'ensure that redirect action is not invoked if indulge is false and gift item is not selected', () => {
    giftItems.giftItems[0].freeGifts[0].selected = 'false';
    giftItems.giftItems[0].induldge = false;
    const checkForRedirectSaga = checkForRedirect( action );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next( {} );
    checkForRedirectSaga.next();
    checkForRedirectSaga.next();
    const nextDescriptor = checkForRedirectSaga.next( { 'data': giftItems } ).value;
    expect( nextDescriptor ).toEqual( undefined );
  } );

} );
