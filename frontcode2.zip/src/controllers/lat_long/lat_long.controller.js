/*
* LatLong saga: calls the SweetIQ api endpoint with
* user searchValue to retrieve geolocation information
* */

import {
  takeEvery,
  call,
  put,
  select,
  race
} from 'redux-saga/effects';
import { delay } from 'redux-saga';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import isEmpty from 'lodash/isEmpty';
import { selectGlobal } from '../../models/view/global/global.model';
import { getGeoLocation } from '../../utils/geo_location/geo_location';
import { getUserSessionData, saveUserSessionData } from '../../utils/user_storage/user_storage';
import appConstants from '../../shared/appConstants';
import { getLatLongState } from '../../models/view/lat_long/lat_long.model';

export const latLong = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let latLongData = yield call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA );
    let disableTimeout = !!action.data.disableTimeout;
    const currentLocationState = yield select( getLatLongState );

    /** *
     * fetch the current location only if the currentLocation is not requested in this page already
     * */
    if( !currentLocationState?.currentLocationRequested ){
      const global = yield select( selectGlobal );

      const resolvedData = yield race( {
        position: call( getGeoLocation, ( !disableTimeout && global.switchData.switches.geoLocationTimeout ) ),
        ...( !disableTimeout && { timeout: call( delay, global.switchData.switches.geoLocationTimeout ) } )
      } );

      let position = resolvedData?.position;

      if( position ){
        latLongData = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          geoLocationOverride: false,
          isLocationBlocked: false
        }
      }
      else if( !resolvedData?.timeout ){
        latLongData = {
          isLocationBlocked: true
        }
      }
      else {
        latLongData = {}
      }
      yield call( saveUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA, latLongData );

    }
    yield put( getActionDefinition( type, 'success' )( latLongData ) );
  }

  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
};

export default function*( ){
  const serviceType = 'latLong';
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), latLong, serviceType );
}