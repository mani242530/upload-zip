
import {
  takeEvery,
  call,
  put,
  select,
  race
} from 'redux-saga/effects';
import { delay } from 'redux-saga';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { cloneableGenerator } from 'redux-saga/utils';
import { selectGlobal } from '../../models/view/global/global.model';
import saga, {
  latLong
} from './lat_long.controller';
import { getGeoLocation } from '../../utils/geo_location/geo_location';
import {
  saveUserSessionData,
  getUserSessionData
} from '../../utils/user_storage/user_storage';
import appConstants from '../../shared/appConstants';
import { getLatLongState } from '../../models/view/lat_long/lat_long.model';

describe( 'LatLong sagas', () => {
  const type = 'latLong';
  const sessionType = 'session';
  const action = {
    data: {
      disableTimeout: false
    }
  };
  const listenerSaga = cloneableGenerator( latLong )( type, action );
  let listenerSagaClone1;
  let listenerSagaClone2;
  let listenerSagaClone3;

  const coreSaga = saga();
  registerServiceName( type );

  it( 'should take every latLong request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), latLong, type ) );
  } );

  describe( 'LatLong saga success path if disableTimeout is false', () => {
    const action = {
      data: {
        disableTimeout:false
      }
    };
    const listenerSaga = cloneableGenerator( latLong )( type, action );
    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should call getUserSessionData method with currentLocationData as a key', () => {
      const callDescriptor = listenerSaga.next( ).value;
      listenerSagaClone3 = listenerSaga.clone();
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should select latLongState', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( selectDescriptor ).toEqual( select( getLatLongState ) );
    } );

    it( 'should select selectGlobal', () => {
      const currentLocationState = {
        currentLocationRequested : false
      };
      const selectDescriptor = listenerSaga.next( currentLocationState ).value;
      expect( selectDescriptor ).toEqual( select( selectGlobal ) );
    } );

    it( 'should call the getGeoLocation function', () => {
      const geoLocationTimeout = 75;
      const global = {
        switchData:{
          switches: {
            geoLocationTimeout
          }
        }
      }
      const callDescriptor = listenerSaga.next( global ).value;
      listenerSagaClone1 = listenerSaga.clone();
      listenerSagaClone2 = listenerSaga.clone();
      expect( callDescriptor ).toEqual( race( {
        position: call( getGeoLocation, 75 ),
        timeout: call( delay, 75 )
      } ) );
    } );

    it( 'should save the latLongData into session', () => {
      const resolvedData = {
        position: {
          coords: {
            latitude: 80,
            longitude: 80
          }
        },
        timeout :false
      };

      const latLongData = {
        latitude: resolvedData.position.coords.latitude,
        longitude: resolvedData.position.coords.longitude,
        geoLocationOverride: false,
        isLocationBlocked: false
      };
      const callDescriptor = listenerSaga.next( resolvedData ).value;
      expect( callDescriptor ).toEqual( call( saveUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA, latLongData ) );
    } );

    it( 'should put a success event after data is called', () => {
      const latLongData = {
        latitude: 80,
        longitude: 80,
        geoLocationOverride: false,
        isLocationBlocked: false
      };

      const putDescriptor = listenerSaga.next( { latLongData } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( latLongData ) ) );
    } );

  } );

  describe( 'LatLong saga success path if ignoreLocalStorage is true', () => {
    const action = {
      data: {
        disableTimeout:false,
        ignoreLocalStorage:true
      }
    };
    const listenerSaga = cloneableGenerator( latLong )( type, action );
    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should call getUserSessionData method with currentLocationData as a key', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should select latLongState', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( selectDescriptor ).toEqual( select( getLatLongState ) );
    } );

    it( 'should select selectGlobal', () => {
      const latLongData = {
        latitude: 80,
        longitude: 80,
        geoLocationOverride: false,
        isLocationBlocked: false
      };
      const selectDescriptor = listenerSaga.next( latLongData ).value;
      expect( selectDescriptor ).toEqual( select( selectGlobal ) );
    } );

    it( 'should call the getGeoLocation function', () => {
      const geoLocationTimeout = 75;
      const global = {
        switchData:{
          switches: {
            geoLocationTimeout
          }
        }
      }
      const callDescriptor = listenerSaga.next( global ).value;
      expect( callDescriptor ).toEqual( race( {
        position: call( getGeoLocation, 75 ),
        timeout: call( delay, 75 )
      } ) );
    } );

    it( 'should save the latLongData into session', () => {
      const resolvedData = {
        position: {
          coords: {
            latitude: 80,
            longitude: 80
          }
        },
        timeout :false
      };

      const latLongData = {
        latitude: resolvedData.position.coords.latitude,
        longitude: resolvedData.position.coords.longitude,
        geoLocationOverride: false,
        isLocationBlocked: false
      };
      const callDescriptor = listenerSaga.next( resolvedData ).value;
      expect( callDescriptor ).toEqual( call( saveUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA, latLongData ) );
    } );

    it( 'should put a success event after data is called', () => {
      const latLongData = {
        latitude: 80,
        longitude: 80,
        geoLocationOverride: false,
        isLocationBlocked: false
      };

      const putDescriptor = listenerSaga.next( { latLongData } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( latLongData ) ) );
    } );

  } );

  describe( 'LatLong saga success path if ignoreLocalStorage false with localStorageData present', () => {
    const action = {
      data: {
        disableTimeout:false,
        ignoreLocalStorage:false
      }
    };
    const listenerSaga = cloneableGenerator( latLong )( type, action );
    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should call getUserSessionData method with currentLocationData as a key', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should select latLongState', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( selectDescriptor ).toEqual( select( getLatLongState ) );
    } );

    it( 'should select selectGlobal', () => {
      const latLongData = undefined;
      const selectDescriptor = listenerSaga.next( latLongData ).value;
      expect( selectDescriptor ).toEqual( select( selectGlobal ) );
    } );

    it( 'should call the getGeoLocation function', () => {
      const geoLocationTimeout = 75;
      const global = {
        switchData:{
          switches: {
            geoLocationTimeout
          }
        }
      }
      const callDescriptor = listenerSaga.next( global ).value;
      expect( callDescriptor ).toEqual( race( {
        position: call( getGeoLocation, 75 ),
        timeout: call( delay, 75 )
      } ) );
    } );

    it( 'should save the latLongData into session', () => {
      const resolvedData = {
        position: {
          coords: {
            latitude: 80,
            longitude: 80
          }
        },
        timeout :false
      };

      const latLongData = {
        latitude: resolvedData.position.coords.latitude,
        longitude: resolvedData.position.coords.longitude,
        geoLocationOverride: false,
        isLocationBlocked: false
      };
      const callDescriptor = listenerSaga.next( resolvedData ).value;
      expect( callDescriptor ).toEqual( call( saveUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA, latLongData ) );
    } );

    it( 'should put a success event after data is called', () => {
      const latLongData = {
        latitude: 80,
        longitude: 80,
        geoLocationOverride: false,
        isLocationBlocked: false
      };

      const putDescriptor = listenerSaga.next( { latLongData } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( latLongData ) ) );
    } );

  } );

  describe( 'LatLong saga success path if localStorage has the data', () => {
    const action = {
      data: {
        disableTimeout:false,
        ignoreLocalStorage:false
      }
    };
    const listenerSaga = cloneableGenerator( latLong )( type, action );
    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should call getUserSessionData method with currentLocationData as a key', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should select latLongState', () => {
      const latLongData = {
        latitude: 80,
        longitude: 80,
        geoLocationOverride: false,
        isLocationBlocked: false
      };
      const selectDescriptor = listenerSagaClone3.next( latLongData ).value;
      expect( selectDescriptor ).toEqual( select( getLatLongState ) );
    } );

    it( 'should put a success event after data is called', () => {
      const latLongData = {
        latitude: 80,
        longitude: 80,
        geoLocationOverride: false,
        isLocationBlocked: false
      };

      const currentLocationState = {
        currentLocationRequested : true
      };

      const putDescriptor = listenerSagaClone3.next( currentLocationState ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( latLongData ) ) );
    } );

  } );
  describe( 'LatLong saga failure path', () => {
    const action = {
      data: {
        disableTimeout:true
      }
    };
    const listenerSaga = latLong( type, action );

    it( 'should put a failure event if something went wrong during the geolocation fetching', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      };
      listenerSaga.next();
      listenerSaga.next();
      listenerSaga.next();
      listenerSaga.next();
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      expect( () => {
        listenerSaga.next();
      } ).toThrow();
    } );

  } );

  describe( 'LatLong saga success path if disableTimeout is true', () => {
    const action = {
      data: {
        disableTimeout:true
      }
    };
    const listenerSaga = latLong( type, action );

    it( 'should call the getGeoLocation function without passing geoLocationTimeout value as parameter since disableTimeout is true', () => {
      listenerSaga.next()
      listenerSaga.next()
      listenerSaga.next()
      listenerSaga.next()
      const geoLocationTimeout = 75;
      const global = {
        switchData:{
          switches: {
            geoLocationTimeout
          }
        }
      }
      const callDescriptor = listenerSaga.next( global ).value;
      expect( callDescriptor ).toEqual( race( {
        position: call( getGeoLocation, false )
      } ) );
    } );

  } );

  describe( 'LatLong saga success path location is Blocked', () => {
    it( 'should save the latLongData into session', () => {
      const resolvedData = {
        timeout :false
      };

      const latLongData = {
        isLocationBlocked: true
      };
      const callDescriptor = listenerSagaClone1.next( resolvedData ).value;
      expect( callDescriptor ).toEqual( call( saveUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA, latLongData ) );
    } );

    it( 'should put a success event after data is called', () => {
      const latLongData = {
        isLocationBlocked: true
      };

      const putDescriptor = listenerSagaClone1.next( latLongData ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( latLongData ) ) );
    } );

  } );

  describe( 'LatLong saga success path location timedOut', () => {
    it( 'should save the latLongData into session', () => {
      const resolvedData = {
        timeout :true
      };

      const latLongData = {};
      const callDescriptor = listenerSagaClone2.next( resolvedData ).value;
      expect( callDescriptor ).toEqual( call( saveUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA, latLongData ) );
    } );

    it( 'should put success for the latlong', () => {
      const latLongData = {};

      const putDescriptor = listenerSagaClone2.next( latLongData ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( latLongData ) ) );
    } );

  } );

} );
