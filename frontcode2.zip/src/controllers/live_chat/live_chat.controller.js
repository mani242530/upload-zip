import {
  takeEvery,
  select,
  call
} from 'redux-saga/effects';
import {
  ALERT_WINDOW_RESIZE
} from 'ulta-fed-core/dist/js/events/global/global.events';
import {
  createScriptTag
} from 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts';
import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  makeGetSwitchesData,
  selectGlobal
} from '../../models/view/global/global.model';
import {
  LOAD_LIVE_CHAT
} from '../../events/live_chat/live_chat.events';
import getHistory from '../../utils/history/history';
import appConstants from '../../shared/appConstants';

export const loadLiveChat = function*( action ){
  const switchData = action.switches || ( yield select( makeGetSwitchesData() ) );

  const prObj = {
    'attributes': {
      'id': 'tagscript',
      'type': 'text/javascript',
      'src': '//static.atgsvcs.com/js/atgsvcs.js'
    },
    'options': {
      'onload': () => {
        initialzeLiveChat( switchData.switches )
      }
    }
  };
  createScriptTag( prObj );
}

export const initialzeLiveChat = ( switches ) => {
  createScriptTag(
    {
      'attributes': {
        'id': 'livechatscript',
        'type': 'text/javascript'
      },
      'content': `
    ATGSvcs.setEEID('${switches.liveChatAccount}');
    (function() { // Enable EE driven widgets
        var l = '${switches.liveChatUrl}',d=document,ss='script',s=d.getElementsByTagName(ss)[0];
        function r(u) {
          var rn=d.createElement(ss);
          rn.type='text/javascript';
          rn.defer=rn.async=!0;
          rn.src = "//" + l + u;
          s.parentNode.insertBefore(rn,s);
        }
        r('/rnt/rnw/javascript/vs/1/vsapi.js');
        r('/vs/1/vsopts.js');
        })();`
    }
  );
}

export const shouldLoadLiveChat = function*( type, action ){

  const history = getHistory();

  const {
    pathname
  } = history.location;

  if( action.data.switches.enableGuestChat &&
    !pathname.includes( appConstants.ROUTES.BAG_PAGE ) &&
    !pathname.includes( appConstants.ROUTES.CHECKOUT_PAGE ) ){
    yield call( loadLiveChat, { switches : action.data } );
  }
}

export default function*(){
  let serviceType = 'switches';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'success' ), shouldLoadLiveChat, serviceType );
  yield takeEvery( LOAD_LIVE_CHAT, loadLiveChat );
}
