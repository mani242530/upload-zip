
import { takeEvery, select, call } from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/lib/utils';
import { createScriptTag } from 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts';

import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  makeGetSwitchesData
} from '../../models/view/global/global.model';
import saga, { loadLiveChat, initialzeLiveChat, shouldLoadLiveChat } from './live_chat.controller';
import {
  LOAD_LIVE_CHAT
} from '../../events/live_chat/live_chat.events';
import getHistory from '../../utils/history/history';
import appConstants from '../../shared/appConstants';

jest.mock( 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts', () => {
  return {
    createScriptTag: jest.fn()
  }
} );

describe( 'LoadScripts Saga', () => {
  const loadScriptsSaga = saga();

  it( 'should listen for LOAD_LIVE_CHAT action after switches is success', () => {
    registerServiceName( 'switches' )
    const takeEveryDescriptor = loadScriptsSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( 'switches', 'success' ), shouldLoadLiveChat, 'switches' ) );
  } );

  it( 'should listen for LOAD_LIVE_CHAT action', () => {
    const takeEveryDescriptor = loadScriptsSaga.next();
    expect( takeEveryDescriptor.value ).toEqual( takeEvery( LOAD_LIVE_CHAT, loadLiveChat ) );
    expect( takeEveryDescriptor.done ).toEqual( false );
    expect( loadScriptsSaga.next().done ).toEqual( true );
  } );

  describe( 'createScriptTag', () => {
    it( 'should invoke createScriptTag to initalize live chat when initialzeLiveChat is invoked', () => {
      createScriptTag.mockClear();
      const props = {
        liveChatAccount:'1232132',
        liveChatUrl:'www.livechat.com/url'
      }
      const createScriptParam =      {
        'attributes': {
          'id': 'livechatscript',
          'type': 'text/javascript'
        },
        'content': `
    ATGSvcs.setEEID('${props.liveChatAccount}');
    (function() { // Enable EE driven widgets
        var l = '${props.liveChatUrl}',d=document,ss='script',s=d.getElementsByTagName(ss)[0];
        function r(u) {
          var rn=d.createElement(ss);
          rn.type='text/javascript';
          rn.defer=rn.async=!0;
          rn.src = "//" + l + u;
          s.parentNode.insertBefore(rn,s);
        }
        r('/rnt/rnw/javascript/vs/1/vsapi.js');
        r('/vs/1/vsopts.js');
        })();`
      }

      initialzeLiveChat( props );
      expect( createScriptTag ).toBeCalledWith( createScriptParam );
    } );

  } );

  describe( 'shouldLoadLiveChat', ()=>{
    const history = getHistory();
    it( 'should call loadLiveChat when switches call is successful and switch data is available', ()=>{
      const globalData = {
        data: {
          switches: {
            enableGuestChat: true
          }
        }
      };
      history.location.pathname = '/pdp';
      const shouldLoadLiveChatGenerator = shouldLoadLiveChat( null, globalData );
      const valueOfGenerator = shouldLoadLiveChatGenerator.next();
      const data = {
        switches : {
          switches: {
            enableGuestChat: true
          }
        }
      }
      expect( JSON.stringify( valueOfGenerator.value ) ).toEqual( JSON.stringify( call( loadLiveChat, data ) ) );
      expect( JSON.stringify( valueOfGenerator.done ) ).toEqual( 'false' );
      expect( JSON.stringify( shouldLoadLiveChatGenerator.next().done ) ).toEqual( 'true' );
    } );

    it( 'should not call loadLiveChat when switches call is successful and switch data is not available', ()=>{
      const globalData = {
        data: {
          switches: {
            enableGuestChat: false
          }
        }
      };
      const shouldLoadLiveChatGenerator = shouldLoadLiveChat( null, globalData );
      expect( JSON.stringify( shouldLoadLiveChatGenerator.next().done ) ).toEqual( 'true' );
    } );

    it( 'should not call loadLiveChat when switches call is successful and switch data is available but page is bag', ()=>{
      const globalData = {
        data: {
          switches: {
            enableUltaChat: true
          }
        }
      };
      history.location.pathname = appConstants.ROUTES.BAG_PAGE;
      const shouldLoadLiveChatGenerator = shouldLoadLiveChat( null, globalData );
      expect( JSON.stringify( shouldLoadLiveChatGenerator.next().done ) ).toEqual( 'true' );
    } );

    it( 'should not call loadLiveChat when switches call is successful and switch data is available but page is checkout', ()=>{
      const globalData = {
        data: {
          switches: {
            enableUltaChat: true
          }
        }
      };
      history.location.pathname = appConstants.ROUTES.CHECKOUT_PAGE;
      const shouldLoadLiveChatGenerator = shouldLoadLiveChat( null, globalData );
      expect( JSON.stringify( shouldLoadLiveChatGenerator.next().done ) ).toEqual( 'true' );
    } );

  } );
} )
