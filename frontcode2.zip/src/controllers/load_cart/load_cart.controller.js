/**
 * Created by rush on 5/3/17.
 */
import {
  takeEvery, call, put, take, select, cancel, cancelled
} from 'redux-saga/effects';
import isUndefined from 'lodash/isUndefined';
import has from 'lodash/has';
import { isIntlSite } from 'ulta-fed-core/dist/js/utils/formatters/formatters';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';


import {
  pageRedirect,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getUserState } from '../../models/view/user/user.model';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  retrieveExternalAddInput
} from '../../utils/local_storage/local_storage';

import {
  updatedCartResponse
} from '../../events/mini_cart/mini_cart.events';
import appConstants from '../../shared/appConstants';

export const isCartPickupInfoUpdateAction = ( action )=>{
  return [getServiceType( 'cartPickupInfoUpdate', 'success' ),
    getServiceType( 'cartPickupInfoUpdate', 'failure' ),
    getServiceType( 'cartPickupInfoUpdate', 'canceled' )].includes( action.type );
}


export const checkForRedirect = function*( action, loadCartCount ){

  const UserData = yield select( getUserState );
  // #1. Check to see if the user is signed in
  // #2. If the user is signein look at the current URL and redirect the user to the right place
  // #3. Check the user's cart count
  // #4. If the cart count is 0 redirect to the empty bag if you aren't on the empty bag
  // #5. If the cart count is > 0 redirect to the bag if not on the bag
  // #6. No cart data returned from service redirect to homepage

  const {
    isSignedIn,
    shoppingCartCount
  } = UserData;

  const {
    history
  } = action.data;

  const {
    pathname
  } = action.data.history.location;


  const cartCount = loadCartCount || parseInt( shoppingCartCount, 10 );


  let bagPath = appConstants.ROUTES.BAG_PAGE;
  let checkoutPath = appConstants.ROUTES.CHECKOUT_PAGE;
  let signedInEmptyBag = appConstants.ROUTES.BAG_EMPTY_PAGE;
  let signedOutEmptyBag = appConstants.ROUTES.BAG_LOGIN_PAGE;
  let homePage = appConstants.ROUTES.BASE_PATH;

  // if the app is being redirected and no ajax call is made for loadCart we must fire
  // a pageNavigation event for analtyics tracking.
  const evt = {
    'name': 'pageNavigation'
  }


  // if the loadCartCount is null then the application did not receive any cartSummary data
  // therefore we redirect them to the homepage
  if( loadCartCount === null ){
    // redirect the user to the home page
    history.replace( homePage );
    yield put( pageRedirect( pathname, homePage ) );
    yield cancel();
  }

  // if the user has items in their cart and they are on an empty bag page send them to the bag
  // it is important to note that the signed in user status does not matter for this scenario
  if( cartCount > 0 && pathname !== bagPath && pathname !== checkoutPath ){
    // redirect the user to the bag page
    history.replace( bagPath );
    yield put( pageRedirect( pathname, bagPath ) );
    yield put( triggerAnalyticsEvent( {}, evt ) );
    yield cancel();
  }

  // if i am signed in, have no cart items, and I'm not on the signed emptyBagPage redirct me to the signedin emptyBagpage
  if( isSignedIn && cartCount === 0 && pathname !== signedInEmptyBag ){
    history.replace( signedInEmptyBag );
    yield put( pageRedirect( pathname, signedInEmptyBag ) );
    yield put( triggerAnalyticsEvent( {}, evt ) );
    yield cancel();
  }

  // if i am not signed in, have no cart items, and I'm not on the signed out emptyBagPage redirct me to the signed out emptyBagpage
  if( !isSignedIn && cartCount === 0 && pathname !== signedOutEmptyBag ){
    history.replace( signedOutEmptyBag );
    yield put( pageRedirect( pathname, signedOutEmptyBag ) );
    yield cancel();
  }
}

// method for handling oak mirror input data
export const checkItemsToAdd = function*( action ){


  // if there are no items to restore, check if there are items to be added as part of oak mirror flow
  const itemsToAdd = retrieveExternalAddInput();

  if( itemsToAdd ){

    yield put( getActionDefinition( 'multipleItemsAdd', 'requested' )( itemsToAdd ) );
    const addResponse = yield take( getServiceType( 'multipleItemsAdd', 'success' ) );

    const {
      pathname,
      search
    } = action.data.history.location;

    // Here we are retaining the source parameter which came in the original request when redirecting
    let bagPath = `${ appConstants.ROUTES.BAG_PAGE }?source=${ new URLSearchParams( search ).get( 'source' ) || '' }`;
    const history = action.data.history;
    history.replace( bagPath );
    yield put( pageRedirect( pathname, bagPath ) );

  }

}

// Individual exports for testing
export const loadCart = function* ( type, CONFIG, action ){
  try {

    yield put( getActionDefinition( type, 'loading' )( action.data ) );

    // checkItemsToAdd will handle any items to be restore as part of delivery option update
    // and any items which needs to be added as part of oak mirror flow
    yield call( checkItemsToAdd, action );

    // we need to see if we need to redirect the user
    yield call( checkForRedirect, action );

    let query = {};

    if( process.env.NODE_ENV === 'development' ){
      query.__CART_COUNT = CONFIG.DEBUGGING.CART.cartQty;
    }

    const res = yield call( ajax,
      {
        type,
        query
      } );


    yield put( getActionDefinition( type, 'success' )( res.body.data ) );


    let updatedLoadCartResponseData = res.body.data;

    const {
      cartSummary,
      cartItems
    } = res.body.data;

    // this check is to handle when there is no cart data sent from the service
    if( isUndefined( cartSummary ) || isUndefined( cartItems ) ){
      yield call( checkForRedirect, action, null );
    }

    // this check is to handles the scenario when cart had only one item, and it was removed as part of the load cart call
    // this logic is to ensure that the user will be directed to the empty bag page
    if( cartSummary.itemCount === 0 ){
      yield call( checkForRedirect, action, 0 );
    }

    // get global switch data to check the BOPIS flag turned on or not.
    const switchData = yield select( makeGetSwitchesData() );
    const storePickupEnabled = has( switchData, 'switches.storePickupEnabled' ) && switchData.switches.storePickupEnabled && !isIntlSite();

    if( storePickupEnabled && cartSummary.itemCount > 0 ){
      // get the cart pickup info update data and pass loadcart data response. Based on the response will get the user geo location
      let history = action.data.history;
      let responseData = res.body.data;
      yield put( getActionDefinition( 'cartPickupInfoUpdate', 'requested' )( {
        responseData,
        history
      } ) );
      const cartPickupInfoUpdateResponse = yield take( isCartPickupInfoUpdateAction );
      if( cartPickupInfoUpdateResponse.data ){
        updatedLoadCartResponseData = cartPickupInfoUpdateResponse.data
      }
    }

    yield put( updatedCartResponse( updatedLoadCartResponseData ) );

    const recTestEnabled = switchData.switches.recTestEnabled;
    // display product recommendations
    if( !recTestEnabled ){
      yield put( getActionDefinition( 'productRecs', 'requested' )( updatedLoadCartResponseData ) );
    }

    return updatedLoadCartResponseData;
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    console.log( err ); // eslint-disable-line
  }
  finally {

    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'canceled' )() );
    }
  }
}

export default function( CONFIG ){
  return function* (){
    let serviceType = 'loadCart';
    // register events for the request
    registerServiceName( serviceType );
    yield takeEvery( getServiceType( 'loadCart', 'requested' ), loadCart, serviceType, CONFIG );
  }
}
