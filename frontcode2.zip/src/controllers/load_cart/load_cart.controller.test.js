/**
 * Created by rush on 5/3/17.
 */

/**
 * LoadCart  sagas
 */
import { cloneableGenerator } from 'redux-saga/utils';
import * as formatters from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import {
  takeEvery,
  call,
  take,
  put,
  select,
  cancel,
  cancelled
} from 'redux-saga/effects';


import {
  pageRedirect,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  isEmpty,
  concat,
  find
} from 'lodash';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getUserState } from '../../models/view/user/user.model';
import {
  updatedCartResponse
} from '../../events/mini_cart/mini_cart.events';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import {
  retrieveExternalAddInput
} from '../../utils/local_storage/local_storage';
import { ajax } from '../../utils/ajax/ajax';
import {
  loadLiveChat
} from '../../events/live_chat/live_chat.events';
import saga, {
  loadCart,
  checkForRedirect,
  checkItemsToAdd,
  isCartPickupInfoUpdateAction
} from './load_cart.controller';
import CONFIG from '../../modules/ccr/ccr.config';


jest.mock( '../../utils/ajax/ajax', ()=>{
  return {
    ajax:jest.fn()
  }
} );

jest.mock( '../../utils/local_storage/local_storage', ()=>{
  return { retrieveExternalAddInput:()=> 'addToBag' }
} );

const prodRecsServiceType = 'productRecs';
registerServiceName( prodRecsServiceType );

const oakMirrorServiceType = 'multipleItemsAdd';
registerServiceName( oakMirrorServiceType );
registerServiceName( 'login' );

describe( 'LoadCart sagas', () => {

  const type = 'loadCart';

  registerServiceName( type );
  registerServiceName( 'cartPickupInfoUpdate' );

  const loadCartSaga = saga( CONFIG )();

  it( 'should listen to loadCart service calls', () => {

    const takeEveryDescriptor = loadCartSaga.next().value;

    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), loadCart, type, CONFIG ) );

  } );

  describe( 'checkForRedirect method', () => {

    const replace = ( path ) => {};
    const action = {
      data: {
        history: {
          location: {
            pathname: '/emptyBag'
          },
          replace: replace
        }
      }
    };

    describe( 'if the user has items in their cart and they are on an empty bag page send them to the bag', () => {

      const checkForRedirectWithItems = checkForRedirect( action );

      it( 'should select getUserState', () => {

        const selectDescriptor = checkForRedirectWithItems.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'should put redirect action', () => {

        const userData = {
          isSignedIn: true,
          shoppingCartCount: 4
        };
        const bagPath = '/bag';
        const selectDescriptor = checkForRedirectWithItems.next( userData ).value;

        expect( selectDescriptor ).toEqual( put( pageRedirect(
          action.data.history.location.pathname, bagPath
        ) ) );

      } );

      it( 'should put setDataLayer action', () => {

        const evt = {
          name: 'pageNavigation'
        };
        const selectDescriptor = checkForRedirectWithItems.next().value;

        expect( selectDescriptor ).toEqual( put( triggerAnalyticsEvent( {}, evt ) ) );

      } );

      it( 'should yield cancel', () => {

        const cancelDescriptor = checkForRedirectWithItems.next().value;

        expect( cancelDescriptor ).toEqual( cancel() );

      } );

    } );

    describe( 'if the user is signed in, have no cart items, and not on the signed emptyBagPage, redirect him to the signedin emptyBagpage', () => {

      const checkForRedirectNoItems = checkForRedirect( action );

      it( 'should select getUserState', () => {

        const selectDescriptor = checkForRedirectNoItems.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'should put redirect action', () => {

        const userData = {
          isSignedIn: true,
          shoppingCartCount: 0
        };
        const bagPath = '/bag/empty';
        const selectDescriptor = checkForRedirectNoItems.next( userData ).value;

        expect( selectDescriptor ).toEqual( put( pageRedirect(
          action.data.history.location.pathname, bagPath
        ) ) );

      } );

      it( 'should put setDataLayer action', () => {

        const evt = {
          name: 'pageNavigation'
        };
        const selectDescriptor = checkForRedirectNoItems.next().value;

        expect( selectDescriptor ).toEqual( put( triggerAnalyticsEvent( {}, evt ) ) );

      } );

      it( 'should yield cancel', () => {

        const cancelDescriptor = checkForRedirectNoItems.next().value;

        expect( cancelDescriptor ).toEqual( cancel() );

      } );

    } );

    describe( 'if the user is not signed in, have no cart items, and not on the signed out emptyBagPage redirct him to the signed out emptyBagpage', () => {

      const redirectNoItemsNotSigned = checkForRedirect( action );

      it( 'should select getUserState', () => {

        const selectDescriptor = redirectNoItemsNotSigned.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'should put redirect action', () => {

        const userData = {
          isSignedIn: false,
          shoppingCartCount: 0
        };
        const bagPath = '/bag/login';
        const selectDescriptor = redirectNoItemsNotSigned.next( userData ).value;

        expect( selectDescriptor ).toEqual( put( pageRedirect(
          action.data.history.location.pathname, bagPath
        ) ) );

      } );

      it( 'should yield cancel', () => {

        const cancelDescriptor = redirectNoItemsNotSigned.next().value;

        expect( cancelDescriptor ).toEqual( cancel() );

      } );

    } );

  } );

  describe( 'checkItemsToAdd method - Items to be added as part of oak mirror flow', () => {

    const replace = ( path ) => {};
    const action = {
      data: {
        history: {
          location: {
            pathname: '/bag',
            search:'?source=oak'
          },
          replace: replace
        }
      }
    };

    const handleOakMirrorInputValues = checkItemsToAdd( action );

    it( 'should put multipleItemsAdd requested', () => {

      const putDescriptor  = handleOakMirrorInputValues.next().value;
      const itemsToAdd = retrieveExternalAddInput();
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'multipleItemsAdd', 'requested' )( itemsToAdd ) ) );

    } );

    it( 'should listen to multipleItemsAdd success', () => {

      const takeDescriptor = handleOakMirrorInputValues.next().value;
      expect( takeDescriptor ).toEqual( take( getServiceType( oakMirrorServiceType, 'success' ) ) );

    } );

    it( 'should put redirect action', () => {

      const bagPath = '/bag?source=oak';
      const selectDescriptor = handleOakMirrorInputValues.next().value;

      expect( selectDescriptor ).toEqual( put( pageRedirect(
        action.data.history.location.pathname, bagPath
      ) ) );

    } );

  } );


  describe( 'checkForRedirect method', () => {

    const replace = ( path ) => {};

    const action1 = {
      data: {
        history: {
          location: {
            pathname: '/bag'
          },
          replace: replace
        }
      }
    };


    describe( 'if the service does return cart data redirect', () => {

      const checkForRedirectWithoutCartData = checkForRedirect( action1, null );


      it( 'should put redirect action', () => {

        checkForRedirectWithoutCartData.next();

        const userData = {
          isSignedIn: true,
          shoppingCartCount: 4
        };
        const homePage = '/';
        const putDescriptor = checkForRedirectWithoutCartData.next( userData ).value;

        expect( putDescriptor ).toEqual( put( pageRedirect(
          action1.data.history.location.pathname, homePage
        ) ) );

      } );


      it( 'should yield cancel', () => {

        const cancelDescriptor = checkForRedirectWithoutCartData.next().value;

        expect( cancelDescriptor ).toEqual( cancel() );

      } );

    } );



    const action = {
      data: {
        history: {
          location: {
            pathname: '/emptyBag'
          },
          replace: replace
        }
      }
    };



    describe( 'if the user has items in their cart and they are on an empty bag page send them to the bag', () => {

      const checkForRedirectWithItems = checkForRedirect( action );

      it( 'should select getUserState', () => {

        const selectDescriptor = checkForRedirectWithItems.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'should put redirect action', () => {

        const userData = {
          isSignedIn: true,
          shoppingCartCount: 4
        };
        const bagPath = '/bag';
        const selectDescriptor = checkForRedirectWithItems.next( userData ).value;

        expect( selectDescriptor ).toEqual( put( pageRedirect(
          action.data.history.location.pathname, bagPath
        ) ) );

      } );

      it( 'should put setDataLayer action', () => {

        const evt = {
          name: 'pageNavigation'
        };
        const selectDescriptor = checkForRedirectWithItems.next().value;

        expect( selectDescriptor ).toEqual( put( triggerAnalyticsEvent( {}, evt ) ) );

      } );

      it( 'should yield cancel', () => {

        const cancelDescriptor = checkForRedirectWithItems.next().value;

        expect( cancelDescriptor ).toEqual( cancel() );

      } );

    } );

    describe( 'if the user is signed in, have no cart items, and not on the signed emptyBagPage, redirect him to the signedin emptyBagpage', () => {

      const checkForRedirectNoItems = checkForRedirect( action );

      it( 'should select getUserState', () => {

        const selectDescriptor = checkForRedirectNoItems.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'should put redirect action', () => {

        const userData = {
          isSignedIn: true,
          shoppingCartCount: 0
        };
        const bagPath = '/bag/empty';
        const selectDescriptor = checkForRedirectNoItems.next( userData ).value;

        expect( selectDescriptor ).toEqual( put( pageRedirect(
          action.data.history.location.pathname, bagPath
        ) ) );

      } );

      it( 'should put setDataLayer action', () => {

        const evt = {
          name: 'pageNavigation'
        };
        const selectDescriptor = checkForRedirectNoItems.next().value;

        expect( selectDescriptor ).toEqual( put( triggerAnalyticsEvent( {}, evt ) ) );

      } );

      it( 'should yield cancel', () => {

        const cancelDescriptor = checkForRedirectNoItems.next().value;

        expect( cancelDescriptor ).toEqual( cancel() );

      } );

    } );

    describe( 'if the user is not signed in, have no cart items, and not on the signed out emptyBagPage redirct him to the signed out emptyBagpage', () => {

      const redirectNoItemsNotSigned = checkForRedirect( action );

      it( 'should select getUserState', () => {

        const selectDescriptor = redirectNoItemsNotSigned.next().value;

        expect( selectDescriptor ).toEqual( select( getUserState ) );

      } );

      it( 'should put redirect action', () => {

        const userData = {
          isSignedIn: false,
          shoppingCartCount: 0
        };
        const bagPath = '/bag/login';
        const selectDescriptor = redirectNoItemsNotSigned.next( userData ).value;

        expect( selectDescriptor ).toEqual( put( pageRedirect(
          action.data.history.location.pathname, bagPath
        ) ) );

      } );

      it( 'should yield cancel', () => {

        const cancelDescriptor = redirectNoItemsNotSigned.next().value;

        expect( cancelDescriptor ).toEqual( cancel() );

      } );

    } );

  } );

  describe( 'loadCart method success/failure path', () => {
    const res = {
      body: {
        data:{
          cartSummary: {
            shippingCost: 'FREE',
            subTotal: 286,
            itemCount: 5,
            orderGiftWrapAmt: 0,
            additionalDiscount: null,
            couponDiscount: 0,
            estimatedTax: 'TBD',
            estimatedTotal: 286,
            currencyCode: 'USD',
            couponCode: null
          },
          freeSamplesInfo: {
            items: [
              {
                catalogRefId: '2252998',
                sampleDesc: 'Fragrance',
                selected: false
              },
              {
                catalogRefId: '2252999',
                sampleDesc: 'Skincare',
                selected: false
              },
              {
                catalogRefId: '2253000',
                sampleDesc: 'Variety',
                selected: false
              }
            ]
          },
          messages: {
            items: [
              {
                type: 'Info',
                message: 'Looks like you have items in your bag from before. They\'ve been added below.'
              }
            ]
          },
          giftItems: {
            items: [{
              freeGifts: [{
                giftVariant: 'Signature Black',
                giftPDPUrl: '/go-curl-pocket-curler-pink?productId=xlsImpprod641081&sku=2161712',
                giftCatalogRefId: '2161712',
                giftDisplayName: 'Go Curl Pocket Curler - Pink',
                giftImageURL: 'http://images.ulta.com/is/image/Ulta/2161712?$sm$',
                selected: 'false',
                giftBrandName: 'Japonesque'
              },
              {
                giftVariant: 'Signature Red',
                giftPDPUrl: '/slant-tweezer?productId=prod2041233&sku=2145941',
                giftCatalogRefId: '2145941',
                giftDisplayName: 'Slant Tweezer',
                giftImageURL: 'http://images.ulta.com/is/image/Ulta/2145941?$sm$',
                selected: 'false',
                giftBrandName: 'Tweezerman'
              },
              {
                giftVariant: '1.7 oz',
                giftPDPUrl: '/eternity-men-eau-de-toilette?productId=2232&sku=2023775',
                giftCatalogRefId: '2023775',
                giftDisplayName: 'Eternity for Men Eau de Toilette',
                giftImageURL: 'http://images.ulta.com/is/image/Ulta/2023775?$sm$',
                selected: 'default',
                giftBrandName: 'Calvin Klein'
              }],
              promoValidity: 'offer valid 03/11/2015-12/30/2018 or while supplies last',
              bfxPriceMap: null,
              promoId: '0000071454',
              induldge: true
            },
            {
              freeGifts: [{
                giftPDPUrl: '/brazilliance-maracuja-self-tanner-mitt?productId=xlsImpprod5250035&sku=2258052',
                giftCatalogRefId: '2258052',
                giftDisplayName: 'Brazilliance Maracuja Self-Tanner & Mitt',
                giftImageURL: 'http://images.ulta.com/is/image/Ulta/2258052?$sm$',
                selected: 'true',
                giftBrandName: 'Tarte'
              },
              {
                giftPDPUrl: '/brazilliance-maracuja-self-tanner-mitt?productId=xlsImpprod5250035&sku=2258052',
                giftCatalogRefId: '2258052',
                giftDisplayName: 'Brazilliance Maracuja Self-Tanner & Mitt',
                giftImageURL: 'http://images.ulta.com/is/image/Ulta/2258052?$sm$',
                selected: 'default',
                giftBrandName: 'Tarte'
              }],
              promoValidity: 'offer valid 04/24/2017-07/31/2017 or while supplies last',
              bfxPriceMap: [
                {
                  bfxQty: '1',
                  bfxPrice: '$0.00'
                }
              ],
              promoId: '1000014332',
              induldge: true
            }]
          },
          cartItems: {
            items: [
              {
                displayType: 'removed',
                messages:{
                  items:[
                    {
                      type:'Info',
                      message:'Out of Stock'
                    }
                  ]
                },
                couponApplied: false,
                brandName: 'OPI',
                quantity: 2,
                productId: 'xlsImpprod13631063',
                excludedFromCoupon: false,
                adbugMessageMap: {
                  adbugMessage: null,
                  promoUrl: 'https://qa3.ulta.com/ulta/promotion/buy-more-save-more/detail/0000153130'
                },
                catalogRefId: '2299339',
                categoryName: 'Nail Polish',
                discountMessage: '',
                errorMsg: '',
                commerceItemid: 'ci14980000220',
                priceInfo: {
                  salePrice: '$10.00',
                  regularPrice: '$20.00',
                  bfxPriceMap: [
                    {
                      bfxQty: '2.0',
                      bfxPrice: '$5.00'
                    }
                  ],
                  unitPriceMessage: '2 @ $5.00'
                },
                productDisplayName: 'New Orleans Nail Lacquer Collection',
                imageURL: 'https://images.ulta.com/is/image/Ulta/2299339?$md$',
                variantInfo: {
                  Color: 'Spare Me A French Quarter? (mellowed raspberry crÃ¨me)'
                },
                skuDisplayName: 'New Orleans Nail Lacquer Collection',
                shippingRestriction: 'Cannot ship to your selected address',
                maxQty: 10,
                productURL: '/new-orleans-nail-lacquer-collection?productId=xlsImpprod13631063&sku=2299339'
              },
              {
                displayType: 'default',
                couponApplied: false,
                brandName: 'Dior',
                quantity: 3,
                productId: 'xlsImpprod13231211',
                excludedFromCoupon: false,
                adbugMessageMap: {
                  adbugMessage: null,
                  promoUrl: 'https://qa3.ulta.com/ulta/promotion/buy-more-save-more/detail/0000153130'
                },
                catalogRefId: '2291498',
                categoryName: 'Cologne',
                discountMessage: '',
                errorMsg: '',
                commerceItemid: 'ci14980000221',
                priceInfo: {
                  salePrice: null,
                  regularPrice: '$276.00',
                  bfxPriceMap: [
                    {
                      bfxQty: '3',
                      bfxPrice: '$92.00'
                    }
                  ],
                  unitPriceMessage: '3 @ $92.00'
                },
                productDisplayName: 'Dior Homme Eau for Men Eau de Toilette',
                imageURL: 'https://images.ulta.com/is/image/Ulta/2291498?$md$',
                variantInfo: {
                  Size: '3.4 oz'
                },
                skuDisplayName: 'Dior Homme Eau for Men Eau de Toilette',
                shippingRestriction: 'Cannot ship to your selected address',
                maxQty: 3,
                productURL: '/dior-homme-eau-men-eau-de-toilette?productId=xlsImpprod13231211&sku=2291498'
              }
            ]
          }
        }
      }
    };

    const action = {
      data: {
        history: {
          location: {
            pathname: '/bag'
          }
        }
      }
    };
    const listenerSaga = cloneableGenerator( loadCart )( type, CONFIG, action );
    const itemRestorePathSaga = loadCart( type, CONFIG, {
      data: { ...action.data, itemsToRestore: true }
    } );

    it( 'should until the loading event has been put', () => {

      const putDescriptor  = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( action.data ) ) );

    } );

    it( 'call checkItemsToAdd', () => {
      const callDescriptor  = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( checkItemsToAdd, action ) );
    } );

    it( 'call checkForRedirect', () => {
      const callDescriptor  = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( checkForRedirect, action ) );
    } );

    it( 'should call the ajax method', () => {
      const callDescriptor  = listenerSaga.next().value;
      const query = {};
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    let listenerSagaCloneRes01;
    let listenerSagaCloneRes02;
    let listenerSagaCloneRes03;
    let listenerSagaCloneRes04;

    it( 'should put success event', () => {
      listenerSagaCloneRes01 = listenerSaga.clone();
      listenerSagaCloneRes02 = listenerSaga.clone();
      listenerSagaCloneRes03 = listenerSaga.clone();

      const putDescriptor  = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    const switchData = {
      switches:{
        recTestEnabled:false
      }
    }
    let listenerSagaCloneRecs;
    it( 'should check global config switches Data', () => {

      const selectDescriptor  = listenerSaga.next( ).value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put updatedCartResponse event to return the loadcart response', () => {
      listenerSagaCloneRecs = listenerSaga.clone();
      const putDescriptor  = listenerSaga.next( switchData ).value;
      expect( putDescriptor ).toEqual( put( updatedCartResponse( res.body.data ) ) );
    } );

    it( 'should put productRecs requested event when recTestEnabled is false', () => {

      const putDescriptor  = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'productRecs', 'requested' )( res.body.data ) ) );
    } );

    it( 'should not put productRecs requested event when recTestEnabled is true', () => {
      switchData.switches.recTestEnabled = true;
      const putDescriptor  = listenerSagaCloneRecs.next( switchData ).value;
      expect( putDescriptor ).toEqual( put( updatedCartResponse( res.body.data ) ) );
      const cancelDescriptor  = listenerSagaCloneRecs.next( ).value;
      expect( cancelDescriptor ).toEqual( cancelled() );
    } );

    it( 'should cancel the event if an error occured in the service', () => {

      const cancelDescriptor  = listenerSaga.next( ).value;
      expect( cancelDescriptor ).toEqual( cancelled() );
    } );

    it( 'should put a cancel action', () => {

      const putDescriptor = listenerSaga.next( true, global ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'canceled' )() ) );

    } );

    it( 'should call checkForRedirect when there is no cart data sent from the service', () => {
      const res = {
        body: {
          data:{
            cartSummary: undefined
          }
        }
      };

      listenerSagaCloneRes01.next( res ).value;
      const callDescriptor = listenerSagaCloneRes01.next( ).value;

      expect( callDescriptor ).toEqual( call( checkForRedirect, action, null ) );
    } );

    describe( 'failure path', () => {
      it( 'should put a failure event if an error occurred', () => {
        const err = {
          statusText:'some failure message'
        };
        const putDescriptor = listenerSagaCloneRes01.throw( err ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );
    } );

    it( 'should call checkForRedirect when cart had only one item, and it was removed as part of the load cart call', () => {
      const res = {
        body: {
          data:{
            cartSummary: {
              itemCount: 0
            },
            cartItems: {}
          }
        }
      };

      listenerSagaCloneRes02.next( res ).value;
      const callDescriptor = listenerSagaCloneRes02.next( ).value;

      expect( callDescriptor ).toEqual( call( checkForRedirect, action, 0 ) );
    } );

    it( 'should put cartPickupInfoUpdate request if storePickupEnabled and itemCount > 0', () => {
      const res = {
        body: {
          data:{
            cartSummary: {
              itemCount: 2
            },
            cartItems: {}
          }
        }
      };
      const switchData = {
        switches:{
          storePickupEnabled: true
        }
      };
      const history = action.data.history;
      const responseData = res.body.data;

      listenerSagaCloneRes03.next( res );
      listenerSagaCloneRes03.next( );
      const putDescriptor = listenerSagaCloneRes03.next( switchData ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( 'cartPickupInfoUpdate', 'requested' )( {
        responseData,
        history
      } ) ) );
    } );

    it( 'should dispatch isCartPickupInfoUpdateAction with response from cartPickup info update service if storePickupEnabled is true', () => {
      const takeDescriptor = listenerSagaCloneRes03.next( ).value;
      listenerSagaCloneRes04 = listenerSagaCloneRes03.clone();
      expect( takeDescriptor ).toEqual( take( isCartPickupInfoUpdateAction ) );
    } );
    let cartPickupInfoUpdateResponse = {
      data:{
        cartSummary:{
          itemCount:1
        },
        pickupStoreInfo:{
          available:true
        }
      }
    }
    it( 'should put updatedCartResponse event to return the cartPickupInfoUpdate response after dispatching isCartPickupInfoUpdateAction if cartPickupInfoUpdateResponse.data is not empty', () => {
      const putDescriptor  = listenerSagaCloneRes03.next( cartPickupInfoUpdateResponse ).value;
      expect( putDescriptor ).toEqual( put( updatedCartResponse( cartPickupInfoUpdateResponse.data ) ) );
    } );

    it( 'should put updatedCartResponse event to return the loadcart ajax call response after dispatching isCartPickupInfoUpdateAction, if cartPickupInfoUpdateResponse.data is undefined', () => {
      const cartPickupInfoUpdateResponse = {
        data: undefined
      }
      const putDescriptor  = listenerSagaCloneRes04.next( cartPickupInfoUpdateResponse ).value;

      const loadCartCallResponse = {
        cartSummary: {
          itemCount: 2
        },
        cartItems: {}
      }
      expect( putDescriptor ).toEqual( put( updatedCartResponse( loadCartCallResponse ) ) );
    } );

    it( 'should put productRecs requested event', () => {

      const putDescriptor  = listenerSagaCloneRes03.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'productRecs', 'requested' )( cartPickupInfoUpdateResponse.data ) ) );
    } );

  } );

  describe( 'isCartPickupInfoUpdateAction test cases', () => {
    it( 'should return true for cartPickupInfoUpdate success', () => {
      const action = { type: getServiceType( 'cartPickupInfoUpdate', 'success' ) };
      expect( isCartPickupInfoUpdateAction( action ) ).toEqual( true );
    } );

    it( 'should return true for cartPickupInfoUpdate failure', () => {
      const action = { type: getServiceType( 'cartPickupInfoUpdate', 'failure' ) };
      expect( isCartPickupInfoUpdateAction( action ) ).toEqual( true );
    } );

    it( 'should return true for cartPickupInfoUpdate canceled', () => {
      const action = { type: getServiceType( 'cartPickupInfoUpdate', 'canceled' ) };
      expect( isCartPickupInfoUpdateAction( action ) ).toEqual( true );
    } );

    it( 'should return false for non cartPickupInfoUpdate actions', () => {
      const action = { type: getServiceType( 'productRecs', 'success' ) };
      expect( isCartPickupInfoUpdateAction( action ) ).toEqual( false );
    } );

  } );

} );
