import {
  takeEvery, take, call, put, select, cancel
} from 'redux-saga/effects';
import isUndefined from 'lodash/isUndefined';
import { delay } from 'redux-saga';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';



import {
  host,
  fullyQualifyLink
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';


import { getRoute } from 'ulta-fed-core/dist/js/utils/omniture/omniture';
import get from 'lodash/get';
import { getGTI, getUserState } from '../../models/view/user/user.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  triggerReflektionEvents
} from '../../events/reflektion/reflektion.events';

import {
  MOVE_TO_SFL,
  ADD_TO_SFL,
  SFL_ITEM_ADDED
} from '../../events/save_for_later/save_for_later.events';

import {
  retrieveAuthSuccessUrlDetails, removeAuthSuccessUrlDetails
} from '../../utils/local_storage/local_storage';
import appConstants from '../../shared/appConstants';
import { getExpirationInMilliseconds } from '../../utils/formatters/formatters';
import { saveUserData, removeUserData } from '../../utils/user_storage/user_storage';

// Individual exports for testing
export const listener = function*( type, action ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );

    let values = {
      login: action.data.values.username,
      password: action.data.values.password,
      autoLogin:action.data.values.staySignedIn,
      sourcePage: action.data.values.sourcePage
    };

    if( process.env.NODE_ENV === 'development' ){
      // debug cases
      // signedin
      // invalidData - returns login failure Messages object.
      values.__FORCE_RES = 'signedin';
    }

    const res = yield call(
      ajax, {
        type,
        method:'post',
        values
      }
    );

    let shoppingCartCount;

    if( res.body.data ){

      // Analytics tracking code begin
      const data = {
        'globalPageData': {
          'action': {
            'login': res.body.data.success ? 'true' : 'false'
          },
          'navigation': {
            'location': action.data.analyticsSourcePage
          },
          ...( res.body.data.messages && { 'messages': res.body.data.messages.items } )
        }
      }


      let evt = {
        'name': res.body.data.success ? 'trackAccountSignInSuccess' : 'serviceMessagesUpdated',
        ...( !res.body.data.messages && {
          data: {
            'signInLocation' : action.data.analyticsSourcePage,
            'signInPersist' : `${ !!action.data.values.staySignedIn }`
          }
        } )
      }

      if( res.body.data.success ){
        // get the profile data
        yield put( getActionDefinition( 'user', 'requested' )( { invokedFromLogin: true } ) );
        const userData = yield take( getServiceType( 'user', 'success' ) );

        // for handleLoginSuccess > fetch the shopping cart count for logged in user
        shoppingCartCount = userData.data.cart.itemCount;

        const switchData = yield select( makeGetSwitchesData() );

        const isStaySignedIn = !!action.data.values.staySignedIn || !action.data.values.username;
        // In the saveStaySigned in flag we are storing the value in milliseconds until which the user will be remembered
        // rememberMeMaxAge returned from config servie will be in seconds and hence multiplying with 1000 to convert it into milliseconds
        // this flag is being used by analytics code in signal
        const staySignedInFlagData = isStaySignedIn ? getExpirationInMilliseconds( switchData.switches.rememberMeMaxAge ) : 0;

        saveUserData( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, staySignedInFlagData );

        // triggerUserLoginReflektionEvent is called only when enableRfkEvents is true
        if( switchData.switches.enableRfkEvents ){
          // trigger reflektion event
          yield call( triggerUserLoginReflektionEvent );
        }

        data.globalPageData.profile = {
          ...( globalPageData.profile && globalPageData.profile ),
          'signInPersist':`${ !!action.data.values.staySignedIn }`
        }

        if( action.data.reauth ){

          yield put( setDataLayer( data, evt ) );
          // a delay of 200 ms is provided after the analytics event is triggered,
          // so as to provide enough time for the signal code to process it before the page is redirected
          yield call( delay, 200 );

          const search = action.data.history.location.search;
          const params = new URLSearchParams( search );

          let redirectUrl;

          const originalURL = params.get( 'originalURL' );

          if( originalURL ){
            const url = new URL( originalURL );
            redirectUrl = `${ url.pathname + ( url.search || '' )}`;
          }
          else if( params.get( 'source' ) === 'account' ){
            redirectUrl = appConstants.ROUTES.ACCOUNT_PAGE;
          }

          if( !redirectUrl ){
            const redirectDetails = retrieveAuthSuccessUrlDetails();
            removeAuthSuccessUrlDetails();

            if( action.data.reauthRetry && redirectDetails.url === appConstants.ROUTES.CHECKOUT_PAGE ){
              redirectUrl = appConstants.ROUTES.BAG_PAGE;
            }
            else {
              redirectUrl = redirectDetails.url || appConstants.ROUTES.ACCOUNT_PAGE;
            }
          }

          global.location.replace( fullyQualifyLink( host, redirectUrl ) );
          yield cancel();

        }
        else if( action.data.history.location.pathname === appConstants.ROUTES.FORGOT_PASSWORD_SENT ||
        action.data.history.location.pathname === appConstants.ROUTES.FORGOT_USERNAME_SENT ){
          global.location.assign( fullyQualifyLink( host, appConstants.ROUTES.ACCOUNT_PAGE ) );
        }

        // redirect page is false for login from checkout and cart pages
        // login is handled if redirectPage is false
        else if( action.data.redirectPage ){
          if( action.data.useRouter ){
            yield put( setDataLayer( data ) );
            action.data.history.push( action.data.paths.successPath, {
              formType: 'loggedIn',
              isSignedIn: true
            } );
          }
          else {
            yield put( setDataLayer( data, evt ) );
            global.location.href = fullyQualifyLink( host, action.data.paths.successPath );
          }
        }
        else {

          // this block will trigger any actions which needs to be initiated based on login success
          // when the user is on bag page or empty bag login page and only if redirect page is false, loadcart and saveforlater needs to be re-requested on login success
          // redirectPage will be false for login from bag and checkout and true for login from other places
          const pathname = action.data.history.location.pathname;

          const signedInBag = appConstants.ROUTES.BAG_PAGE;
          const signedInEmptyBag = appConstants.ROUTES.BAG_EMPTY_PAGE;
          let isRequestCartData = false; // used to determine is a cart data request needs to be triggered
          let hasPageNavigated = false; // used to determine if the pagenavigation event needs to be triggered
          let isRouteChange = false; // used to determine if there is a route change
          let newUrl;
          let reloadPage = false;

          // user logs in from /bag/login (empty bag login)
          if( pathname === appConstants.ROUTES.BAG_LOGIN_PAGE ){
            // if user doesn't have any item in cart, set newUrl as /bag/login
            if( shoppingCartCount === 0 ){
              isRouteChange = true;
              isRequestCartData = true;
              newUrl = signedInEmptyBag;
              hasPageNavigated = true;
            }
            // if user have any item in cart, set newUrl as /bag
            else {
              isRouteChange = true;
              newUrl = signedInBag;
            }
          }
          // user logs in from /bag (bag page login)
          else if( pathname === appConstants.ROUTES.BAG_PAGE ){
            isRequestCartData = true;
          }
          // user logs in from /checkout (checkout page login) and user have already item in cart, set newUrl as /bag
          else if( pathname === '/checkout' ){
            if( res.body.data.cartMerged ){
              isRouteChange = true;
              newUrl = signedInBag;
            }
          }
          else {
            reloadPage = true;
          }

          if( isRouteChange ){
            yield put( setDataLayer( data ) );
            action.data.history.replace( newUrl );
          }
          else {
            yield put( setDataLayer( data, evt ) );
          }

          if( get( action.data, 'loginSuccessHandler.action' ) === ADD_TO_SFL ){
            // trigger action to add clicked item to SFL section
            yield put( getActionDefinition( 'addToSaveForLater', 'requested' )( { ...action.data.loginSuccessHandler, history: action.data.history, isSignedIn:res.body.data.success } ) );
            yield take( SFL_ITEM_ADDED );
          }

          if( isRequestCartData ){
            yield put( getActionDefinition( 'cart', 'requested' )( { ...action.data, hasPageNavigated } ) );
          }

          // to avoid calling cart success for non bag and checkout page from common header signin modal
          if( pathname === appConstants.ROUTES.BAG_PAGE || pathname === appConstants.ROUTES.BAG_LOGIN_PAGE ){
            // we are waiting for cart response to trigger MOVE_TO_SFL or ADD_TO_SFL event
            yield take( getServiceType( 'cart', 'success' ) );
          }

          // if login is triggered on click of move to SFL action in item level, Item needs to be moved to SFL section on successful login
          if( get( action.data, 'loginSuccessHandler.action' ) === MOVE_TO_SFL ){
            // trigger action to move clicked item to SFL section
            yield put( getActionDefinition( 'moveToSaveForLater', 'requested' )( { ...action.data.loginSuccessHandler, history: action.data.history, isSignedIn:res.body.data.success } ) );
          }

          if( reloadPage ){

            const search = action.data.history.location.search;
            const params = new URLSearchParams( search );
            // if an anoynymous user is trying to access any myaccount pages, the user will be redirected to the home page with forceLogin as true
            // the actual url which the user was trying to access will be present in the URL as the value of the param called 'originalURL'
            // once the login is successful, if the originalURL is present in the url, the user will be redirected to the originalURL
            const originalURL = params.get( 'originalURL' );

            if( originalURL ){
              const url = new URL( originalURL );
              const redirectUrl = `${ url.pathname + ( url.search || '' )}`;
              global.location.replace( fullyQualifyLink( host, redirectUrl ) );
            }
            else if( params.get( 'source' ) === 'account' ){
              global.location.assign( fullyQualifyLink( host, appConstants.ROUTES.ACCOUNT_PAGE ) );
            }
            else {
              global.location.reload();
            }
          }
        }
      }
      else {
        // removeUserData() will clear stay signed in flag value ( Analytics ) from local storage
        removeUserData( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG );
        yield put( setDataLayer( data, evt ) );
      }

      yield put( getActionDefinition( type, 'success' )( {
        res: res.body.data, history: action.data.history, redirectPage:action.data.redirectPage, loginSuccessHandler:action.data.loginSuccessHandler, analyticsSourcePage:action.data.analyticsSourcePage, staySignedIn: action.data.values.staySignedIn
      } ) ) ;
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( err.status === appConstants.RESPONSE_CODE.SESSION_EXPIRED || err.status === appConstants.RESPONSE_CODE.TOKEN_MISMATCH ){
      // if a SESSION_EXPIRED or TOKEN_MISMATCH  was received when invoking the login service,
      // the token service will get invoked followed by the user lite
      // will wait to received user success, and then execute the login flow again
      yield take( getServiceType( 'user', 'success' ) );
      yield listener( type, action );
    }

  }
}

// this function will trigger reflektion event
export const triggerUserLoginReflektionEvent = function* (){
  const GTI = yield select( getGTI );
  const reflektionData = {
    type: 'user',
    name: 'login',
    value: {
      user: {
        id: GTI
      }
    }
  }
  yield put( triggerReflektionEvents( reflektionData ) );
}

export default function( CONFIG ){
  return function* (){
    let serviceType = 'login';

    // register events for the request
    registerServiceName( serviceType );
    registerServiceName( 'reflektionLoginEvent' );

    yield takeEvery( getServiceType( 'login', 'requested' ), listener, serviceType );
    yield takeEvery( getServiceType( 'reflektionLoginEvent', 'requested' ), triggerUserLoginReflektionEvent );
  }
}
