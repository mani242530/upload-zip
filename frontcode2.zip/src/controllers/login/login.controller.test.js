/**
 * Login  sagas
 */

import {
  takeEvery, call, put, take, select, cancel
} from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/utils';
import { delay } from 'redux-saga';


import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';




import { host, fullyQualifyLink } from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getGTI } from '../../models/view/user/user.model';
import CONFIG from '../../config';
import {
  ajax
} from '../../utils/ajax/ajax';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import saga, { listener, triggerUserLoginReflektionEvent } from './login.controller';
import {
  triggerReflektionEvents
} from '../../events/reflektion/reflektion.events';
import {
  MOVE_TO_SFL,
  ADD_TO_SFL,
  SFL_ITEM_ADDED
} from '../../events/save_for_later/save_for_later.events';
import {
  retrieveAuthSuccessUrlDetails
} from '../../utils/local_storage/local_storage';
import appConstants from '../../shared/appConstants';

jest.mock( '../../utils/local_storage/local_storage', () => {
  return {
    removeAuthSuccessUrlDetails: jest.fn(),
    retrieveAuthSuccessUrlDetails:jest.fn( () => {
      return {
        url : '/checkout'
      };
    } )
  }
} );

jest.mock( 'ulta-fed-core/dist/js/utils/formatters/formatters', () => {
  return {
    fullyQualifyLink:jest.fn( ( host, url ) => {
      return host + url;
    } ),
    host: undefined
  }
} );
import { getExpirationInMilliseconds } from '../../utils/formatters/formatters';
jest.mock( '../../utils/formatters/formatters', () => {
  return {
    getExpirationInMilliseconds:jest.fn( () => {
      return 1557505722757;
    } )
  }
} );
import { saveUserData, removeUserData } from '../../utils/user_storage/user_storage';
jest.mock( '../../utils/user_storage/user_storage', () => {
  return {
    saveUserData:jest.fn(),
    removeUserData:jest.fn()
  }
} );

const type = 'login';
const sessionID = 44432;
const username = 'testuser';
const password = 'ulta1234';
const sourcePage = 'ultapage';
const getRoute = jest.fn();
const redirectPage = true;
const useRouter = true;
const push = jest.fn();
const replace = jest.fn();
let newUrl;

global.globalPageData = {
  profile:{
    email:'test@ulta.com'
  }
}


describe( 'Login Saga', () => {

  registerServiceName( type );
  registerServiceName( 'user' );
  registerServiceName( 'reflektionLoginEvent' );
  registerServiceName( 'cart' );
  registerServiceName( 'moveToSaveForLater' );
  registerServiceName( 'addToSaveForLater' );

  const loginSaga = saga( CONFIG )();

  it( 'should listen for the login requested method', () => {
    const takeEveryDescriptor = loginSaga.next().value;
    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );
  } );

  it( 'should listen for the reflektionLoginEvent requested method', () => {
    const takeEveryDescriptor = loginSaga.next().value;
    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( 'reflektionLoginEvent', 'requested' ), triggerUserLoginReflektionEvent )
    );
  } );

  describe( 'listener saga success path with res.body and redirectPage are true', () => {

    const action = {
      data: {
        values:{
          sessionID,
          username,
          password,
          sourcePage,
          staySignedIn:true
        },
        paths:{
          successPath: '/bag',
          failurePath: '/'
        },
        redirectPage,
        useRouter,
        history: {
          push: push,
          location: {
            pathname: '/'
          }
        },
        analyticsSourcePage:'/bag'

      }
    };

    const listenerSaga = cloneableGenerator( listener )( type, action );


    it( 'should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      let values = {
        login: username, password, sourcePage, autoLogin: true
      };

      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values } ) );

    } );



    let evt = {
      data: {
        signInLocation:'/bag',
        signInPersist:true
      },
      name: 'trackAccountSignInSuccess'
    };
    let data = {
      globalPageData: {
        action: {
          login: 'true'
        },
        navigation: {
          location: '/bag'
        }
      }
    };
    data.globalPageData.profile = {
      ...globalPageData.profile,
      'signInPersist':'true'
    }

    let res = {
      data: {
        success: true,
        cartMerged: false,
        messages:null
      },
      meta: {
        lastFetchedTime: '2018-04-02 15:04:26.139-05:00'
      }
    };
    const switchData = {
      switches:{
        enableRfkEvents:true
      }
    }


    it( 'should set the data layer in case of login and res.body.data.success is true', () => {

      const putDescriptor = listenerSaga.next( { body: res, invokedFromLogin: true } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( 'user', 'requested' )( { invokedFromLogin: true } ) ) );

      const takeDescriptor = listenerSaga.next().value;

      expect( takeDescriptor ).toEqual( take( getServiceType( 'user', 'success' ) ) );


    } );

    it( 'should select swithces data', () => {
      const userData = {
        data:{
          cart:{
            itemCount :0
          }
        }
      }
      expect( JSON.stringify( listenerSaga.next( userData ).value ) ).toBe( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should call reflektion analytic event for login', () => {
      const callDescriptor = listenerSaga.next( switchData ).value;
      expect( callDescriptor ).toEqual( call( triggerUserLoginReflektionEvent ) );
    } );


    it( 'should set the data layer in case of getRoute is true', () => {
      getRoute.mockReturnValue( false );

      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( setDataLayer( data ) ) );

    } );

    it( 'should set the data layer in case of getRoute is false', () => {
      getRoute.mockReturnValue( true );
      const switchData = {
        switches:{
          enableRfkEvents:false
        }
      }
      const action = {
        data: {
          values:{
            sessionID,
            username,
            password,
            sourcePage,
            staySignedIn:false
          },
          paths:{
            successPath: '/bag',
            failurePath: '/'
          },
          cart:{
            itemCount: 0
          },
          redirectPage: true,
          useRouter: false,
          history: {
            push: push,
            location: {
              pathname: '/'
            }
          },
          analyticsSourcePage:'/bag'
        }
      };
      const userData = {
        data: {
          cart: {
            itemCount: 0
          }
        }
      }

      const data = {
        globalPageData: {
          action: {
            login: 'true'
          },
          navigation: {
            location: '/bag'
          }
        }
      }

      data.globalPageData.profile = {
        ...globalPageData.profile,
        'signInPersist':'false'
      }

      const evt = {
        name: 'trackAccountSignInSuccess',
        data:  {
          signInLocation:'/bag',
          signInPersist:'false'
        }
      }
      let res1 = { ...res };
      res1.data.messages = undefined;
      const listenerSaga = listener( type, action );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: res1 } ).value; // this is user requested event
      listenerSaga.next().value; // this is user success event
      listenerSaga.next( userData ).value; // this is switch select call
      const putDescriptor = listenerSaga.next( switchData ).value; // call for triggering reflektion event

      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );

    } );

    it( 'Should call action.data.history.push method if redirectPage is true and useRouter is true', () => {
      listenerSaga.next().value;
      const data = {
        formType: 'loggedIn',
        isSignedIn: true
      }

      expect( action.data.history.push ).toHaveBeenCalledWith( action.data.paths.successPath, data );
    } );

    it( 'Should put login success event with redirectPage as false without calling action.data.history.push method when redirectPage is false even if useRouter is true', () => {
      const push = jest.fn();
      const action = {
        data: {
          values:{
            sessionID,
            username,
            password,
            sourcePage
          },
          paths:{
            successPath: '/creditcards',
            failurePath: '/'
          },
          redirectPage: false,
          useRouter: true,
          history: {
            push: push,
            location: {
              pathname: '/creditcards'
            }
          }
        }
      };
      const userData = {
        data: {
          cart: {
            itemCount: 0
          }
        }
      }

      const expectedData = {
        res: res.data,
        analyticsSourcePage: undefined,
        staySignedIn: undefined,
        loginSuccessHandler: undefined,
        history: {
          location:{
            pathname: '/creditcards'
          },
          push: push
        },
        redirectPage:false
      }

      const listenerSaga = listener( type, action );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: res } ); // this is user requested event
      listenerSaga.next().value; // this is user success event
      listenerSaga.next( userData ).value; // this is switch select call
      listenerSaga.next( switchData ); // call for triggering reflektion event
      listenerSaga.next().value; // analytics set data layer for isRouteChange
      const putDescriptor = listenerSaga.next().value; // this is login success event
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( expectedData ) ) );

    } );

    it( 'Should put login success event with redirectPage as false without calling fullyQualifyLink when redirectPage is false and useRouter is false', () => {

      const push = jest.fn();
      const action = {
        data: {
          values:{
            sessionID,
            username,
            password,
            sourcePage
          },
          paths:{
            successPath: '/creditcards',
            failurePath: '/'
          },
          redirectPage: false,
          useRouter: true,
          history: {
            push: push,
            location: {
              pathname: '/creditcards'
            }
          }
        }
      };
      const userData = {
        data: {
          cart: {
            itemCount: 0
          }
        }
      }

      const expectedData = {
        res: res.data,
        analyticsSourcePage: undefined,
        staySignedIn: undefined,
        loginSuccessHandler: undefined,
        history: {
          location:{
            pathname: '/creditcards'
          },
          push: push
        },
        redirectPage:false
      }

      const listenerSaga = listener( type, action );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: res } ); // this is user requested event
      listenerSaga.next().value; // this is user success event
      listenerSaga.next( userData ).value; // this is switch select call
      listenerSaga.next( switchData ); // call for triggering reflektion event
      listenerSaga.next().value; // analytics set data layer for isRouteChange
      const putDescriptor = listenerSaga.next().value; // this is login success event


      expect( fullyQualifyLink ).not.toBeCalled();
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( expectedData ) ) );
    } );

    it( 'Should call fullyQualifyLink method when redirectPage is true and useRouter is false', () => {
      const action = {
        data: {
          values:{
            sessionID,
            username,
            password,
            sourcePage
          },
          paths:{
            successPath: '/bag',
            failurePath: '/'
          },
          redirectPage: true,
          useRouter: false,
          history: {
            push: push,
            location:{
              pathname: '/'
            }
          }
        }
      };

      const userData = {
        data: {
          cart: {
            itemCount: 0
          }
        }
      }

      const listenerSaga1 = listener( type, action );
      listenerSaga1.next(); // this is login loading event
      listenerSaga1.next(); // this is login ajax call
      listenerSaga1.next( { body: res } ).value; // this is user requested event
      listenerSaga1.next().value; // this is user success event
      listenerSaga1.next( userData ).value; // this is switch select call
      listenerSaga1.next( switchData ).value;// call for triggering reflektion event
      listenerSaga1.next().value; // this is dataLayerActions action
      listenerSaga1.next().value; // this is login success event

      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, action.data.paths.successPath );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

  describe( 'listener saga success path with res.body as true, redirectPage is false and pathname is /bag', () => {
    const replace = jest.fn();
    const action = {
      data: {
        values:{
          sessionID,
          username,
          password,
          sourcePage,
          staySignedIn:true
        },
        paths:{
          successPath: '/bag',
          failurePath: '/'
        },
        redirectPage :false,
        useRouter,
        history: {
          push: push,
          location:{
            pathname :'/bag'
          },
          replace:replace
        },
        analyticsSourcePage:'/bag'
      }
    };
    const listenerSaga = listener( type, action );

    let data = {
      globalPageData: {
        action: {
          login: 'true'
        },
        navigation: {
          location: '/bag'
        },
        messages : undefined
      }
    };
    data.globalPageData.profile = {
      ...globalPageData.profile,
      'signInPersist':'true'
    }
    let res = {
      data: {
        success: true,
        cartMerged: false,
        messages: {}
      },
      meta: {
        lastFetchedTime: '2018-04-02 15:04:26.139-05:00'
      }
    };
    let evt = {
      data: {
        signInLocation:'/bag',
        signInPersist:'true'
      },
      name: 'trackAccountSignInSuccess'
    };
    const switchData = {
      switches:{
        enableRfkEvents:true
      }
    }
    const userData = {
      data: {
        cart: {
          itemCount: 0
        }
      }
    }

    it( 'should set the data layer with data and evt and set isRouteChange to false', () => {
      getRoute.mockReturnValue( false );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      let res1 = { ...res }
      res1.data.messages = undefined;
      listenerSaga.next( { body: res1 } ); // this is user requested event
      listenerSaga.next().value; // this is user success event
      listenerSaga.next( userData ).value; // this is switch select call
      listenerSaga.next( switchData ); // call for triggering reflektion event
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put cart requested if isRequestCartData is true', () => {
      const expectedData = {
        ...action.data,
        hasPageNavigated : false
      }
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'cart', 'requested' )( expectedData ) ) );
    } );

    it( 'should wait for cart success since pathname is /bag', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( take( getServiceType( 'cart', 'success' ) ) );
    } );

    it( 'Should put login success event  ', () => {
      const putDescriptor = listenerSaga.next().value; // this is login loading event
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( {
        res:res.data, history: action.data.history, redirectPage:false, loginSuccessHandler:undefined, analyticsSourcePage:'/bag', staySignedIn: true
      } ) ) );
    } );

    describe( 'handle login Success when path is /bag, redirectPage is false and loginSuccessHandler.action is moveToSFL - login triggered when user moves an item from cart to bag', () => {
      const replace = jest.fn();
      const action = {
        data: {
          values:{
            sessionID,
            username,
            password,
            sourcePage,
            staySignedIn:true
          },
          paths:{
            successPath: '/bag',
            failurePath: '/'
          },
          redirectPage :false,
          loginSuccessHandler:{
            action:MOVE_TO_SFL,
            skuID:'1234'
          },
          useRouter,
          history: {
            push: push,
            location:{
              pathname :'/bag'
            },
            replace:replace
          },
          analyticsSourcePage:'/bag',
          action: 'SAVE_FOR_LATER::MOVE_TO_SFL'
        }
      };
      const listenerSaga = listener( type, action );
      let res = {
        data: {
          success: true,
          cartMerged: false,
          messages: {}
        },
        meta: {
          lastFetchedTime: '2018-04-02 15:04:26.139-05:00'
        }
      };
      const switchData = {
        switches:{
          enableRfkEvents:true
        }
      }
      const userData = {
        data: {
          cart: {
            itemCount: 0
          }
        }
      }


      getRoute.mockReturnValue( false );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      let res1 = { ...res }
      res1.data.messages = undefined;
      listenerSaga.next( { body: res1 } ); // this is user requested event
      listenerSaga.next().value; // this is user success event
      listenerSaga.next( userData ).value; // this is switch select call
      listenerSaga.next( switchData ); // call for triggering reflektion event
      listenerSaga.next().value; // setDataLayer
      listenerSaga.next().value; // 'cart', 'requested'
      listenerSaga.next().value; // 'cart', 'success'

      it( ' should put the action to move item to SaveForLater section if value loginSuccessHandler.action is moveToSFL ( login triggered on click of login button from save for later section ) ', () => {

        let data = {
          isSignedIn:true,
          action:MOVE_TO_SFL,
          skuID:'1234',
          history: {
            push: push,
            location: {
              pathname: '/bag'
            },
            replace: replace
          }
        }
        const putDescriptor = listenerSaga.next().value; // this is login loading event

        expect( putDescriptor ).toEqual( put( getActionDefinition( 'moveToSaveForLater', 'requested' )( data ) ) );
      } );

    } );

    describe( 'handleLogin on login Success when when path is /bag and redirectPage is false and loginSuccessHandler.action is add to SFL', () => {
      const replace = jest.fn();
      const action = {
        data: {
          values:{
            sessionID,
            username,
            password,
            sourcePage,
            staySignedIn:true
          },
          paths:{
            successPath: '/bag',
            failurePath: '/'
          },
          redirectPage :false,
          loginSuccessHandler:{
            action:ADD_TO_SFL,
            skuID:'1234'
          },
          useRouter,
          history: {
            push: push,
            location:{
              pathname :'/bag'
            },
            replace:replace
          },
          analyticsSourcePage:'/bag'
        }
      };
      const listenerSaga = listener( type, action );
      let res = {
        data: {
          success: true,
          cartMerged: false,
          messages: {}
        },
        meta: {
          lastFetchedTime: '2018-04-02 15:04:26.139-05:00'
        }
      };
      const switchData = {
        switches:{
          enableRfkEvents:true
        }
      }
      const userData = {
        data: {
          cart: {
            itemCount: 0
          }
        }
      }


      getRoute.mockReturnValue( false );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      let res1 = { ...res }
      res1.data.messages = undefined;
      listenerSaga.next( { body: res1 } ); // this is user requested event
      listenerSaga.next().value; // this is user success event
      listenerSaga.next( userData ).value; // this is switch select call
      listenerSaga.next( switchData ); // call for triggering reflektion event
      listenerSaga.next().value; // setDataLayer

      it( ' should put the action to move item to SaveForLater section if value loginSuccessHandler.action is addToSaveForLater ( login triggered on click of login button from save for later section ) ', () => {

        let data = {
          isSignedIn:true,
          action:ADD_TO_SFL,
          skuID:'1234',
          history: {
            push: push,
            location: {
              pathname: '/bag'
            },
            replace: replace
          }
        }
        const putDescriptor = listenerSaga.next().value; // this is addToSaveForLater requested event

        expect( putDescriptor ).toEqual( put( getActionDefinition( 'addToSaveForLater', 'requested' )( data ) ) );
      } );

      it( 'should put the action to request for cart data after the addToSaveForLater is completed ', () => {
        listenerSaga.next(); // addToSaveForLater success
        const expectedData = {
          ...action.data,
          hasPageNavigated : false
        }
        expect( listenerSaga.next().value ).toEqual( put( getActionDefinition( 'cart', 'requested' )( expectedData ) ) );
      } );

      it( 'should wait for cart success event ', () => {
        expect( listenerSaga.next().value ).toEqual( take( getServiceType( 'cart', 'success' ) ) );
      } );

    } );

  } );

  describe( 'listener saga success path with res.body as true, redirectPage is false and pathname is /bag/login', () => {
    const replace = jest.fn();
    const action = {
      data: {
        values:{
          sessionID,
          username,
          password,
          sourcePage,
          staySignedIn:true
        },
        paths:{
          successPath: '/bag/login',
          failurePath: '/'
        },
        redirectPage :false,
        useRouter,
        history: {
          push: push,
          location:{
            pathname :'/bag/login'
          },
          replace:replace
        },
        analyticsSourcePage:'/bag/login'
      }
    };
    const listenerSaga = cloneableGenerator( listener )( type, action );
    let listenerSagaClone;

    let evt = {
      data: {
        signInLocation:'/bag',
        signInPersist:'true'
      },
      name: 'trackAccountSignInSuccess'
    };
    let data = {
      globalPageData: {
        action: {
          login: 'true'
        },
        navigation: {
          location: '/bag/login'
        }
      }
    };

    data.globalPageData.profile = {
      ...globalPageData.profile,
      'signInPersist':'true'
    }

    let res = {
      data: {
        success: true,
        cartMerged: false,
        messages: null
      },
      meta: {
        lastFetchedTime: '2018-04-02 15:04:26.139-05:00'
      }
    };
    const switchData = {
      switches:{
        enableRfkEvents:true
      }
    }

    it( 'should set the data layer in case of pathname is /bag/login and shoppingCartCount is 0', () => {
      getRoute.mockReturnValue( false );
      const userData = {
        data:{
          cart:{
            itemCount:0
          }
        }
      }
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: res } ); // this is user requested event
      listenerSaga.next().value; // this is user success event
      listenerSagaClone = listenerSaga.clone();
      listenerSaga.next( userData ).value; // this is switch select call
      listenerSaga.next( switchData ); // call for triggering reflektion event
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data ) ) );
    } );

    it( 'should  replace the url as /bag/empty and put cart requested', () => {
      const expectedData = {
        ...action.data,
        hasPageNavigated : true
      }
      const putDescriptor = listenerSaga.next().value;
      expect( action.data.history.replace ).toHaveBeenCalledWith( '/bag/empty' );
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'cart', 'requested' )( expectedData ) ) );
    } );

    it( 'should wait for cart success', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( take( getServiceType( 'cart', 'success' ) ) );
    } );

    it( 'Should put login success event, ', () => {
      const putDescriptor = listenerSaga.next().value; // this is login loading event
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( {
        res:res.data, history: action.data.history, redirectPage:false, loginSuccessHandler:undefined, analyticsSourcePage:'/bag/login', staySignedIn: true
      } ) ) );
    } );

    describe( 'handle login Success when path is /bag, redirectPage is false and loginSuccessHandler.action is moveToSFL - login triggered when user moves an item from cart to bag', () => {
      const replace = jest.fn();
      const action = {
        data: {
          values:{
            sessionID,
            username,
            password,
            sourcePage,
            staySignedIn:true
          },
          paths:{
            successPath: '/bag',
            failurePath: '/'
          },
          redirectPage :false,
          loginSuccessHandler:{
            action:ADD_TO_SFL,
            skuID:'1234'
          },
          useRouter,
          history: {
            push: push,
            location:{
              pathname :'/bag/login'
            },
            replace:replace
          },
          analyticsSourcePage:'/bag'
        }
      };
      const listenerSaga = listener( type, action );
      let res = {
        data: {
          success: true,
          cartMerged: false,
          messages:null
        },
        meta: {
          lastFetchedTime: '2018-04-02 15:04:26.139-05:00'
        }
      };
      const switchData = {
        switches:{
          enableRfkEvents:true
        }
      }
      const userData = {
        data: {
          cart: {
            itemCount: 0
          }
        }
      }


      getRoute.mockReturnValue( false );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      let res1 = { ...res }
      res1.data.messages = undefined;
      listenerSaga.next( { body: res1 } ); // this is user requested event
      listenerSaga.next().value; // this is user success event
      listenerSaga.next( userData ).value; // this is switch select call
      listenerSaga.next( switchData ); // call for triggering reflektion event
      listenerSaga.next().value; // setDataLayer



      it( ' should put addToSaveForLater requested action to add item to SaveForLater section if action.data.loginSuccessHandler.action is ADD_TO_SFL ', () => {

        const putDescriptor = listenerSaga.next().value; // this is login loading event
        const data = {
          isSignedIn:true,
          action:ADD_TO_SFL,
          skuID:'1234',
          history: {
            location: {
              pathname: '/bag/login'
            },
            replace: replace,
            push: push
          }
        }

        expect( putDescriptor ).toEqual( put( getActionDefinition( 'addToSaveForLater', 'requested' )( data ) ) );
      } );

      it( 'should wait for cancel of addToSaveForLater', () => {
        expect( listenerSaga.next().value ).toEqual( take( SFL_ITEM_ADDED ) );
      } );

      it( 'should put the action for requesting cart data after the addToSaveForLater is completed ', () => {
        const expectedData = {
          ...action.data,
          hasPageNavigated : true
        }
        expect( listenerSaga.next().value ).toEqual( put( getActionDefinition( 'cart', 'requested' )( expectedData ) ) );
      } );

      it( 'should wait for load cart success event', () => {
        expect( listenerSaga.next().value ).toEqual( take( getServiceType( 'cart', 'success' ) ) );
      } );

    } );

    it( 'should set the data layer in case of if pathname is /bag/login and shoppingCartCount is not 0', () => {
      const userData1 = {
        data:{
          cart:{
            itemCount:3
          }
        }
      }
      listenerSagaClone.next( userData1 ).value; // this is switch select call
      listenerSagaClone.next( switchData ); // call for triggering reflektion event
      const putDescriptor = listenerSagaClone.next().value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data ) ) );
      listenerSagaClone.next().value;
      expect( action.data.history.replace ).toHaveBeenCalledWith( '/bag' );
    } );

  } );

  describe( 'listener saga success path with res.body as true, redirectPage is false and pathname is /checkout', () => {
    const replace = jest.fn();
    const action = {
      data: {
        values:{
          sessionID,
          username,
          password,
          sourcePage,
          staySignedIn:true
        },
        redirectPage :false,
        useRouter,
        history: {
          push: push,
          location:{
            pathname :'/checkout'
          },
          replace:replace
        },
        res:{
          success: true,
          cartMerged: true,
          messages: null
        },
        analyticsSourcePage:'/checkout'
      }
    };
    const listenerSaga = cloneableGenerator( listener )( type, action );
    let listenerSagaClone;

    let evt = {
      data: {
        signInLocation:'/checkout',
        signInPersist:'true'
      },
      name: 'trackAccountSignInSuccess'
    };
    let data = {
      globalPageData: {
        action: {
          login: 'true'
        },
        navigation: {
          location: '/checkout'
        }
      }
    };

    data.globalPageData.profile = {
      ...globalPageData.profile,
      'signInPersist':'true'
    }

    let res = {
      data: {
        success: true,
        cartMerged: true,
        messages: {}
      },
      meta: {
        lastFetchedTime: '2018-04-02 15:04:26.139-05:00'
      }
    };
    const switchData = {
      switches:{
        enableRfkEvents:true
      }
    }

    it( 'should set the data layer in case of pathname is /checkout', () => {
      getRoute.mockReturnValue( false );
      const userData = {
        data:{
          cart:{
            itemCount:0
          }
        }
      }
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: res } ); // this is user requested event
      listenerSaga.next().value; // this is user success event
      listenerSagaClone = listenerSaga.clone();
      listenerSaga.next( userData ).value; // this is switch select call
      listenerSaga.next( switchData ); // call for triggering reflektion event
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data ) ) );
    } );

    it( 'Should put login success event, ', () => {
      const putDescriptor = listenerSaga.next().value; // this is login loading event
      expect( action.data.history.replace ).toHaveBeenCalledWith( '/bag' );
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( {
        res:res.data, history: action.data.history, redirectPage:false, loginSuccessHandler:undefined, analyticsSourcePage:'/checkout', staySignedIn: true
      } ) ) );
    } );

    it( 'should set the data layer in case of if pathname is /bag/login and shoppingCartCount is not 0', () => {
      const userData1 = {
        data:{
          cart:{
            itemCount:3
          }
        }
      }
      listenerSagaClone.next( userData1 ).value; // this is switch select call
      listenerSagaClone.next( switchData ); // call for triggering reflektion event
      const putDescriptor = listenerSagaClone.next().value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data ) ) );
      listenerSagaClone.next().value;
      expect( action.data.history.replace ).toHaveBeenCalledWith( '/bag' );
    } );

  } );

  describe( 'listener saga success path with res.body as true, redirectPage is false and pathname is NOT bag, bag/login, checkout', () => {
    const replace = jest.fn();
    const action = {
      data: {
        values:{
          sessionID,
          username,
          password,
          sourcePage,
          staySignedIn:true
        },
        redirectPage :false,
        useRouter,
        history: {
          push: push,
          location:{
            pathname :'/creditcards'
          },
          replace:replace
        },
        res:{
          success: true,
          cartMerged: true,
          messages: {}
        },
        analyticsSourcePage:'/creditcards'
      }
    };
    const listenerSaga =  listener( type, action );

    let evt = {
      data: {
        signInLocation:'/creditcards',
        signInPersist:'true'
      },
      name: 'trackAccountSignInSuccess'
    };
    let data = {
      globalPageData: {
        action: {
          login: 'true'
        },
        navigation: {
          location: '/creditcards'
        },
        messages :undefined
      }
    };

    data.globalPageData.profile = {
      ...globalPageData.profile,
      'signInPersist':'true'
    }

    let res = {
      data: {
        success: true,
        cartMerged: true,
        messages: undefined
      },
      meta: {
        lastFetchedTime: '2018-04-02 15:04:26.139-05:00'
      }
    };
    const switchData = {
      switches:{
        enableRfkEvents:true
      }
    }

    it( 'should set the data layer in case of pathname is /creditcards', () => {
      getRoute.mockReturnValue( false );
      const userData = {
        data:{
          cart:{
            itemCount:0
          }
        }
      }
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: res } ); // this is user requested event
      listenerSaga.next().value; // this is user success event
      listenerSaga.next( userData ).value; // this is switch select call
      listenerSaga.next( switchData ); // call for triggering reflektion event
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'Should put login success event, ', () => {
      const putDescriptor = listenerSaga.next().value; // this is login loading event
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( {
        res:res.data, history: action.data.history, redirectPage:false, loginSuccessHandler:undefined, analyticsSourcePage:'/creditcards', staySignedIn: true
      } ) ) );
    } );

    it( 'should call page reload', () => {
      Object.defineProperty( global.location, 'reload', {
        configurable: true
      } );
      global.location.reload = jest.fn();
      global.location.reload();
      expect( global.location.reload ).toHaveBeenCalled();
    } );

  } );

  describe( 'listener saga success path with res.body as false', () => {

    const action = {
      data: {
        values:{
          sessionID,
          username,
          password,
          sourcePage
        }
      }
    }

    const listenerSaga = listener( type, action );

    it( 'should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      let values = { login: username, password, sourcePage };

      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values } ) );

    } );

    it( 'should call removeUserData with input as staySignedInFlag and set the data layer in case of login and res.body.success is false', () => {
      let evt = {
        name: 'serviceMessagesUpdated'
      };
      let data = {
        globalPageData: {
          action: {
            login: 'false'
          },
          navigation: {
            location: undefined
          },
          messages: [
            {
              type:'Error',
              message:'The email address/username or password you entered is invalid. Please try again.'
            }
          ]
        }
      };

      let res = {
        data: {
          success: false,
          messages: {
            items:[
              {
                type:'Error',
                message:'The email address/username or password you entered is invalid. Please try again.'
              }
            ]
          }
        },
        meta: {
          lastFetchedTime: '2018-04-02 15:04:26.139-05:00'
        }
      };
      const putDescriptor = listenerSaga.next( { body: res } ).value;

      expect( removeUserData ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG );
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );

    } );

    describe( 'cases for SESSION_EXPIRED and token_mismatch', () => {

      describe( 'cases for SESSION_EXPIRED', () => {

        const listenerSagaExpired = listener( type, action );
        it( 'should put a failure event if no data is returned from the service', () => {
          listenerSagaExpired.next();
          let err = {
            statusText:'expired',
            status:appConstants.RESPONSE_CODE.SESSION_EXPIRED
          }
          const putDescriptor = listenerSagaExpired.throw( err ).value;
          expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
        } );

        it( 'should wait for the user success response  if err status is SESSION_EXPIRED', () => {
          const putDescriptor = listenerSagaExpired.next().value;
          expect( putDescriptor ).toEqual( take( getServiceType( 'user', 'success' ) ) );
        } );

        it( 'should invoke the listner method again with the action data originally received', () => {
          const putDescriptor = listenerSagaExpired.next().value;
          expect( putDescriptor ).toEqual( listener( type, action ) );
        } );
      } );
    } );

    describe( 'cases for TOKEN_MISMATCH', () => {

      const listenerSagaMismatch = listener( type, action );
      it( 'should put a failure event if no data is returned from the service', () => {
        listenerSagaMismatch.next();
        let err = {
          statusText:'conflict',
          status:appConstants.RESPONSE_CODE.TOKEN_MISMATCH
        }
        const putDescriptor = listenerSagaMismatch.throw( err ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );

      it( 'should wait for the user success response  if err status is TOKEN_MISMATCH', () => {
        const putDescriptor = listenerSagaMismatch.next().value;
        expect( putDescriptor ).toEqual( take( getServiceType( 'user', 'success' ) ) );
      } );

      it( 'should invoke the listner method again with the action data originally received', () => {
        const putDescriptor = listenerSagaMismatch.next().value;
        expect( putDescriptor ).toEqual( listener( type, action ) );
      } );
    } );
  } );

  describe( 'listener saga failure path', () => {

    const listenerSaga1 = listener( type, {
      data: {
        values:{
          sessionID,
          username,
          password,
          sourcePage
        },
        redirectPage:true
      }
    } );

    it( 'should put a success event even if the res.body.success is false', () => {
      const res = {
        data: {
          success: false,
          messages: {
            items:[
              {
                type:'Error',
                message:'The email address/username or password you entered is invalid. Please try again.'
              }
            ]
          }
        }
      }

      const putDescriptor = listenerSaga1.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

      const callDescriptor = listenerSaga1.next().value;

      const values = { login: username, password, sourcePage };

      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values } ) );
      listenerSaga1.next( { body: res } ).value;
      const putDescriptor2 = listenerSaga1.next( { body: res } ).value;
      // this expectation proves that the if block is not executed, and even with sucess false value the login sucess action is fired
      // had it been executed then the putDescriptor will be 'put( getActionDefinition( 'user', 'requested' )( { invokedFromLogin: true} )
      const expectedData = {
        res: res.data,
        history: undefined,
        redirectPage:true
      }
      expect( putDescriptor2 ).toEqual( put( getActionDefinition( type, 'success' )( expectedData ) ) );
    } );
  } );

  describe( 'triggerUserLoginReflektionEvent test cases', () => {
    const userLoginReflektionEventSaga = triggerUserLoginReflektionEvent();
    it( 'should select getGTI', () => {

      const selectDescriptor = userLoginReflektionEventSaga.next( ).value;

      expect( selectDescriptor ).toEqual( select( getGTI ) );

    } );
    it( 'should call reflektion.triggerEvent with reflektionData', () => {
      const reflektionData = {
        type: 'user',
        name: 'login',
        value: {
          user: {
            id: '12345'
          }
        }
      }
      const GTI = '12345';
      const callDescriptor = userLoginReflektionEventSaga.next( GTI ).value;
      expect( callDescriptor ).toEqual( put( triggerReflektionEvents( reflektionData ) ) );
    } );

  } );

  describe( 'Login success event - redirectPage is true', () =>{

    const res = {
      data: {
        success: true
      }
    }

    const switchData = {
      switches:{
        enableRfkEvents:true
      }
    }
    const push = jest.fn();
    const action = {
      data: {
        values:{
          sessionID,
          username,
          password,
          sourcePage,
          staySignedIn:true
        },
        paths:{
          successPath: '/bag',
          failurePath: '/'
        },
        redirectPage: true,
        analyticsSourcePage:'/bag',
        useRouter: false,
        history: {
          push: push,
          location: {
            pathname: '/'
          }
        },
        loginSuccessHandler:{
          action:'MOVE_TO_SFL'
        }
      }
    };
    const listenerSaga = listener( type, action );
    it( 'Should update setDataLayer if redirectPage is true', () => {

      const userData = {
        data:{
          cart:{
            itemCount :0
          }
        }
      }

      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: res } ); // this is user requested event
      listenerSaga.next(); // this is user success event
      listenerSaga.next( userData ); // this is switch select call
      listenerSaga.next( switchData ); // call for triggering reflektion event
      const putDescriptor = listenerSaga.next().value; // this is updates globalPageData by invoking setDataLayer
      const data = {
        'globalPageData': {
          'action':  {
            'login': 'true'
          },
          'navigation': {
            'location': '/bag'
          }
        }
      }

      data.globalPageData.profile = {
        ...globalPageData.profile,
        'signInPersist':'true'
      }

      const evt = {
        'name': 'trackAccountSignInSuccess',
        'data':  {
          signInLocation:'/bag',
          signInPersist:'true'
        }
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'Should put login success event, ', () => {
      const putDescriptor = listenerSaga.next().value; // this is login loading event
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( {
        res:res.data, history: action.data.history, redirectPage:true, loginSuccessHandler:{ action:'MOVE_TO_SFL' }, analyticsSourcePage:'/bag', staySignedIn: true
      } ) ) );
    } );
  } )

  describe( 'cases for reauth flow', () => {

    let listenerSagaReauth;
    let listenerSagaReauthClone1;
    let listenerSagaReauthClone2;
    let listenerSagaReauthClone3;
    let listenerSagaReauthClone4;


    const userAction = {
      data: {
        cart: {
          itemCount: 0
        },
        values:{
          username:'testuser',
          staySignedIn:false
        },
        history:{
          location:{
            pathname:'/myaccount/reauthorize'
          }
        },
        reauth:true,
        analyticsSourcePage:'testSource',
        reauthRetry:true
      }
    }


    it( 'should call setdatalayer with appropriate data and evt objects following a delay 0f 200ms', () => {

      const switchData = {
        switches:{
          enableRfkEvents:false
        }
      }
      const evt = {
        name:'trackAccountSignInSuccess',
        data:{
          signInLocation:'testSource',
          signInPersist:'false'
        }
      }
      const userData = {
        data:{
          cart:{
            itemCount:1
          }
        }
      }

      const loginResponse = {
        data:{
          success:true
        }
      }

      const pageData = {
        globalPageData: {
          action:{
            login:'true'
          },
          navigation:{
            location:'testSource'
          },
          profile:{
            email:'test@ulta.com',
            signInPersist:'false'
          }
        }
      }
      listenerSagaReauth = cloneableGenerator( listener )( type, userAction );
      listenerSagaReauth.next(); // this is login loading event
      listenerSagaReauth.next(); // this is login ajax call
      listenerSagaReauth.next( { body: loginResponse } ); // this is user requested event
      listenerSagaReauth.next().value; // this is user success event
      listenerSagaReauth.next( userData ).value; // this is switch select call
      expect( listenerSagaReauth.next( switchData ).value ).toEqual( put( setDataLayer( pageData, evt ) ) ); // put setDataLayer with data and evt
      expect( listenerSagaReauth.next().value ).toEqual( call( delay, 200 ) ); // call delay of 200ms

    } );


    it( 'should set signInPersist to true in datalayer if it is reauth flow and action.data.values.staySignedIn is true', () => {

      const reauthAction = {
        data: {
          cart: {
            itemCount: 0
          },
          values:{
            password:'abc@123',
            staySignedIn: true
          },
          history:{
            location:{
              pathname:'/myaccount/reauthorize'
            }
          },
          reauth:true,
          analyticsSourcePage:'testSource',
          reauthRetry:false
        }
      }

      const switchData = {
        switches:{
          enableRfkEvents:false
        }
      }
      const evt = {
        name:'trackAccountSignInSuccess',
        data:{
          signInLocation:'testSource',
          signInPersist:'true'
        }
      }
      const userData = {
        data:{
          cart:{
            itemCount:1
          }
        }
      }

      const loginResponse = {
        data:{
          success:true
        }
      }

      const pageData = {
        globalPageData: {
          action:{
            login:'true'
          },
          navigation:{
            location:'testSource'
          },
          profile:{
            email:'test@ulta.com',
            signInPersist:'true'
          }
        }
      }
      const reauthSaga = cloneableGenerator( listener )( type, reauthAction );
      reauthSaga.next(); // this is login loading event
      reauthSaga.next(); // this is login ajax call
      reauthSaga.next( { body: loginResponse } ); // this is user requested event
      reauthSaga.next().value; // this is user success event
      reauthSaga.next( userData ).value; // this is switch select call
      expect( reauthSaga.next( switchData ).value ).toEqual( put( setDataLayer( pageData, evt ) ) ); // put setDataLayer with data and evt

    } );

    it( 'should replace url with myaccount url if source param with value account is part of url', () => {
      global.location.replace = jest.fn();
      fullyQualifyLink.mockClear();
      listenerSagaReauthClone1 = listenerSagaReauth.clone();
      listenerSagaReauthClone2 = listenerSagaReauth.clone();
      listenerSagaReauthClone3 = listenerSagaReauth.clone();
      listenerSagaReauthClone4 = listenerSagaReauth.clone();
      userAction.data.history.location.search = 'source=account';

      retrieveAuthSuccessUrlDetails.mockImplementation( () => {
        return {
          url : '/checkoutNew'
        };
      } );

      const descriptor = listenerSagaReauth.next().value; // put login success
      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, appConstants.ROUTES.ACCOUNT_PAGE );
      expect( global.location.replace ).toHaveBeenCalledWith( fullyQualifyLink( host, appConstants.ROUTES.ACCOUNT_PAGE ) );
      expect( descriptor ).toEqual( cancel() );
    } )

    it( 'should replace the url with url set in localstorage if source is not account and reauthRetry is false and location is not checkout', () => {
      global.location.replace = jest.fn();
      fullyQualifyLink.mockClear();
      userAction.data.history.location.search = '';

      retrieveAuthSuccessUrlDetails.mockImplementation( () => {
        return {
          url : '/testUrl'
        };
      } );

      const descriptor = listenerSagaReauthClone1.next().value; // put login success
      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, '/testUrl' );
      expect( global.location.replace ).toHaveBeenCalledWith( fullyQualifyLink( host, '/testUrl' ) );
      expect( descriptor ).toEqual( cancel() );
    } )

    it( 'should replace the url with /bag if source is not account and reauthRetry is true and local storage url location is /checkout', () => {
      global.location.replace = jest.fn();
      fullyQualifyLink.mockClear();
      userAction.data.history.location.search = '';
      userAction.data.reauthRetry = true;

      const checkoutPage = appConstants.ROUTES.CHECKOUT_PAGE;
      retrieveAuthSuccessUrlDetails.mockImplementation( () => {
        return {
          url : checkoutPage
        };
      } );

      const descriptor = listenerSagaReauthClone3.next().value; // put login success
      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, appConstants.ROUTES.BAG_PAGE );
      expect( global.location.replace ).toHaveBeenCalledWith( fullyQualifyLink( host, appConstants.ROUTES.BAG_PAGE ) );
      expect( descriptor ).toEqual( cancel() );
    } )

    it( 'should replace the url with myaccount url if source param is not present in url and no ', () => {
      global.location.replace = jest.fn();
      fullyQualifyLink.mockClear();
      userAction.data.history.location.search = '';

      retrieveAuthSuccessUrlDetails.mockImplementation( () => {
        return {};
      } );

      const descriptor = listenerSagaReauthClone2.next().value; // put login success
      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, appConstants.ROUTES.ACCOUNT_PAGE );
      expect( global.location.replace ).toHaveBeenCalledWith( fullyQualifyLink( host, appConstants.ROUTES.ACCOUNT_PAGE ) );
      expect( descriptor ).toEqual( cancel() );
    } )

    it( 'should replace url with original url if source param value contains original url', () => {
      global.location.replace = jest.fn();
      fullyQualifyLink.mockClear();
      userAction.data.history.location.search = 'originalURL=https%3A//www.ulta.com%3A80/ulta/myaccount/';

      retrieveAuthSuccessUrlDetails.mockImplementation( () => {
        return {
          url : '/testUrl'
        };
      } );

      const descriptor = listenerSagaReauthClone4.next().value; // put login success
      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, '/ulta/myaccount/' );
      expect( global.location.replace ).toHaveBeenCalledWith( fullyQualifyLink( host, '/ulta/myaccount/' ) );
      expect( descriptor ).toEqual( cancel() );
    } )

  } )

  describe( 'cases for reload flow', () => {

    let listnerSagaReload;
    let listnerSagaReloadClone1;
    let listnerSagaReloadClone2;
    let listnerSagaReloadClone3;
    let listnerSagaReloadClone4;

    const userAction = {
      data: {
        cart: {
          itemCount: 0
        },
        values:{
          username:'testuser',
          staySignedIn:'true'
        },
        history:{
          location:{
            pathname:'/home'
          }
        },
        redirectPage:false,
        analyticsSourcePage:'testSource',
        reauth:false
      }
    }


    it( 'should call setdatalayer with appropriate data and evt objects', () => {

      const switchData = {
        switches:{
          enableRfkEvents:false
        }
      }
      const evt = {
        name:'trackAccountSignInSuccess',
        data:{
          signInLocation:'testSource',
          signInPersist:'true'
        }
      }
      const userData = {
        data:{
          cart:{
            itemCount:1
          }
        }
      }

      const loginResponse = {
        data:{
          success:true
        }
      }

      const pageData = {
        globalPageData: {
          action:{
            login:'true'
          },
          navigation:{
            location:'testSource'
          },
          profile:{
            email:'test@ulta.com',
            signInPersist:'true'
          }
        }
      }
      listnerSagaReload = cloneableGenerator( listener )( type, userAction );
      listnerSagaReload.next(); // this is login loading event
      listnerSagaReload.next(); // this is login ajax call
      listnerSagaReload.next( { body: loginResponse } ); // this is user requested event
      listnerSagaReload.next().value; // this is user success event
      listnerSagaReload.next( userData ).value; // this is switch select call
      listnerSagaReloadClone3 = listnerSagaReload.clone();
      listnerSagaReloadClone4 = listnerSagaReload.clone();
      expect( listnerSagaReload.next( switchData ).value ).toEqual( put( setDataLayer( pageData, evt ) ) ); // put setDataLayer with data and evt
    } );

    it( 'should reload the page if source is not account', () => {
      listnerSagaReloadClone1 = listnerSagaReload.clone();
      listnerSagaReloadClone2 = listnerSagaReload.clone();
      global.location.reload = jest.fn();
      listnerSagaReload.next();
      expect( global.location.reload ).toHaveBeenCalled()
    } );


    it( 'should load myaccount page if the source account is part of url', () => {
      global.location.reload = jest.fn();
      global.location.assign = jest.fn();
      userAction.data.history.location.search = 'source=account';
      listnerSagaReloadClone1.next();
      expect( global.location.reload ).not.toHaveBeenCalled()
      expect( global.location.assign ).toHaveBeenCalledWith( fullyQualifyLink( host, appConstants.ROUTES.ACCOUNT_PAGE ) );
    } );

    it( 'should load originalURL pathname if params contains originalURL', () => {
      global.location.reload = jest.fn();
      global.location.replace = jest.fn();
      userAction.data.history.location.search = 'originalURL=https%3A//www.ulta.com%3A80/ulta/myaccount/';
      listnerSagaReloadClone2.next();
      expect( global.location.reload ).not.toHaveBeenCalled()
      expect( global.location.replace ).toHaveBeenCalledWith( fullyQualifyLink( host, '/ulta/myaccount/' ) );
    } );

    it( 'should load my account page if user logged in from /forgot-password-sent', () => {
      const switchData = {
        switches:{
          enableRfkEvents:false
        }
      }
      userAction.data.history.location.pathname = appConstants.ROUTES.FORGOT_PASSWORD_SENT;
      global.location.assign = jest.fn();

      listnerSagaReloadClone3.next( switchData ).value;
      expect( global.location.assign ).toHaveBeenCalledWith( fullyQualifyLink( host, appConstants.ROUTES.ACCOUNT_PAGE ) );
    } );

    it( 'should load my account page if user logged in from /forgot-username-sent', () => {
      const switchData = {
        switches:{
          enableRfkEvents:false
        }
      }
      userAction.data.history.location.pathname = appConstants.ROUTES.FORGOT_USERNAME_SENT;
      global.location.assign = jest.fn();

      listnerSagaReloadClone4.next( switchData ).value;
      expect( global.location.assign ).toHaveBeenCalledWith( fullyQualifyLink( host, appConstants.ROUTES.ACCOUNT_PAGE ) );
    } );

  } )

  describe( 'saveUserData function for saving staySignedInFlag for Analytics - listener saga success path with loginResponse success as true', () => {
    const loginResponse = {
      data:{
        success:true
      }
    }
    const userData = {
      data : {
        cart: {
          itemCount : 5
        }
      }
    }
    const switchData = {
      switches : {
        enableRfkEvents: true,
        rememberMeMaxAge : 6000 // rememberMeMaxAge sample data
      }
    }

    it( 'should call saveUserData with key as staySignedInFlag and value as 0 if staySignedIn is false and username is defined', () => {
      const action = {
        data: {
          cart: {},
          values:{
            username: 'test user',
            password:'abc@123',
            staySignedIn: false
          }
        }
      }
      const listenerSaga = listener( type, action );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: loginResponse } ); // this is user requested event
      listenerSaga.next(); // this is user success event
      listenerSaga.next( userData ); // this is makeGetSwitchesData select event
      const callDescriptor = listenerSaga.next( switchData ).value; // this is call triggerUserLoginReflektionEvent event

      expect( saveUserData ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, 0 );
      expect( callDescriptor ).toEqual( call( triggerUserLoginReflektionEvent ) );
    } );
    it( 'should call saveUserData with key as staySignedInFlag and value as rememberMeMaxAge if staySignedIn is true and username is defined', () => {
      const action = {
        data: {
          cart: {},
          values:{
            username: 'test user',
            password:'abc@123',
            staySignedIn: true
          }
        }
      }
      const listenerSaga = listener( type, action );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: loginResponse } ); // this is user requested event
      listenerSaga.next(); // this is user success event
      listenerSaga.next( userData ); // this is makeGetSwitchesData select event
      const callDescriptor = listenerSaga.next( switchData ).value; // this is call triggerUserLoginReflektionEvent event

      const expectedData = getExpirationInMilliseconds( switchData.switches.rememberMeMaxAge );
      expect( saveUserData ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, expectedData );
      expect( callDescriptor ).toEqual( call( triggerUserLoginReflektionEvent ) );
    } );
    it( 'should call saveUserData with key as staySignedInFlag and value as rememberMeMaxAge if staySignedIn is true and username is undefined', () => {
      const action = {
        data: {
          cart: {},
          values:{
            username: undefined,
            password:'abc@123',
            staySignedIn: true
          }
        }
      }
      const listenerSaga = listener( type, action );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: loginResponse } ); // this is user requested event
      listenerSaga.next(); // this is user success event
      listenerSaga.next( userData ); // this is makeGetSwitchesData select event
      const callDescriptor = listenerSaga.next( switchData ).value; // this is call triggerUserLoginReflektionEvent event

      const expectedData = getExpirationInMilliseconds( switchData.switches.rememberMeMaxAge );
      expect( saveUserData ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, expectedData );
      expect( callDescriptor ).toEqual( call( triggerUserLoginReflektionEvent ) );
    } );
    it( 'should call saveUserData with key as staySignedInFlag and value as rememberMeMaxAge if staySignedIn is false and username is undefined', () => {
      const action = {
        data: {
          cart: {},
          values:{
            username: undefined,
            password:'abc@123',
            staySignedIn: false
          }
        }
      }
      const listenerSaga = listener( type, action );
      listenerSaga.next(); // this is login loading event
      listenerSaga.next(); // this is login ajax call
      listenerSaga.next( { body: loginResponse } ); // this is user requested event
      listenerSaga.next(); // this is user success event
      listenerSaga.next( userData ); // this is makeGetSwitchesData select event
      const callDescriptor = listenerSaga.next( switchData ).value; // this is call triggerUserLoginReflektionEvent event

      const expectedData = getExpirationInMilliseconds( switchData.switches.rememberMeMaxAge );
      expect( saveUserData ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, expectedData );
      expect( callDescriptor ).toEqual( call( triggerUserLoginReflektionEvent ) );
    } );
  } );
} );
