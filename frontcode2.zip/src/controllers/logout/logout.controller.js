import {
  takeEvery, take, call, put, select
} from 'redux-saga/effects';

import isUndefined from 'lodash/isUndefined';
import has from 'lodash/has';


import {
  sessionTokenRequested,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  USER_LOGOUT
} from 'ulta-fed-core/dist/js/events/profile/profile.events';
import {
  host,
  fullyQualifyLink
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import {
  ajax
} from '../../utils/ajax/ajax';

import appConstants from '../../shared/appConstants';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import { removeStaySignedInFlagForAnalytics, removePickupSmsInfo } from '../../utils/local_storage/local_storage';


// Individual exports for testing
export const listener = function*( type, action ){


  try {
    yield put( getActionDefinition( type, 'loading' )() );


    const res = yield call( ajax, { type, method:'post' } );

    yield put( getActionDefinition( type, 'success' )( res.body ) );



    if( !isUndefined( res.body ) ){
      // removing pickup smsInfo from local storage once user logouts successfully
      yield call( removePickupSmsInfo );
      // Analytics tracking code begin
      const dataLayer = {
        'globalPageData': {
          'navigation': {
            'pageName': 'empty bag'
          },
          'profile': {
            'email': '',
            'firstName':'',
            'lastName':''
          },
          'rewards': {
            'loyaltyId':'',
            'programId':'',
            'memberSince':'',
            'platinumMember':'',
            'platinumMemberType':'',
            'userType': 'Guest'
          },
          'order': {
            'currency': '',
            'total': '',
            'subtotal': '',
            'shipping': '',
            'itemCount': '',
            'voucher_discount': '',
            'orderItems': {}
          },
          'cart': {
            'autoRemovedItems':''
          },
          'messages': ''
        }
      };


      yield put( setDataLayer( dataLayer ) );
      // once logout is successful request will be initiated to get new token
      yield put( sessionTokenRequested() );
      removeStaySignedInFlagForAnalytics();
      yield take( getServiceType( 'user', 'success' ) );
      // user should be redirected to home page after logout with login param which
      // help us to trigger sign in model open action in this case
      global.location.href = fullyQualifyLink( global.location.host, '?forceLogin=true' );
    }
    // Analtyics tracking code end

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( err.status === appConstants.RESPONSE_CODE.SESSION_EXPIRED || err.status === appConstants.RESPONSE_CODE.TOKEN_MISMATCH ){
      // SESSION_EXPIRED conflict will be received when invoking the logout service after session timeout
      // TOKEN_MISMATCH will be received if the jsession id and token does not match
      // the token service will get invoked followed by the user lite
      // will wait to receive the user success
      const userData = yield take( getServiceType( 'user', 'success' ) );
      // for a softlogin user, execute force logout and redirect to home page with sign in modal open
      if( userData.data.user.isSoftLoginUser ){
        yield call( listener, type );
      }
      // for a hardlogin user, as the user would have already logged out, redirect to home page with sign in modal open
      else {
        global.location.href = fullyQualifyLink( global.location.host, '?forceLogin=true' );
      }
    }

  }
}

export default function*(){
  let serviceType = 'logout';

  // register events for the request
  registerServiceName( serviceType );

  yield takeEvery( USER_LOGOUT, listener, serviceType )
}
