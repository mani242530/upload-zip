/**
 * Logout  sagas
 */

import {
  takeLatest,
  takeEvery,
  put,
  call,
  take
} from 'redux-saga/effects';

import {
  sessionTokenRequested,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';


import {
  USER_LOGOUT
} from 'ulta-fed-core/dist/js/events/profile/profile.events';

import {
  host,
  fullyQualifyLink
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
jest.mock( 'ulta-fed-core/dist/js//utils/formatters/formatters', () => {
  return { fullyQualifyLink:jest.fn() }
} );
import { cloneableGenerator } from 'redux-saga/lib/utils';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import saga, { listener } from './logout.controller';
import { ajax } from '../../utils/ajax/ajax';
import { removeStaySignedInFlagForAnalytics, removePickupSmsInfo } from '../../utils/local_storage/local_storage';
import appConstants from '../../shared/appConstants';

jest.mock( '../../utils/local_storage/local_storage', () => {
  return {
    removeStaySignedInFlagForAnalytics:jest.fn(),
    removePickupSmsInfo:jest.fn()
  }
} );

jest.mock( './../../utils/ajax/ajax', ()=>{
  return { ajax:jest.fn() }
} );

describe( 'Logout Saga', () => {

  const type = 'USER_LOGOUT';


  const serviceType = 'logout';

  registerServiceName( type );
  registerServiceName( 'session' );
  registerServiceName( 'user' );
  const coreSaga = saga();
  it( 'should listen for the logout requested method', () =>{

    const takeLatestDescriptor = coreSaga.next().value;

    expect( takeLatestDescriptor ).toEqual( takeEvery( USER_LOGOUT, listener, serviceType ) );
  } );

  describe( 'listener saga success/failure path', () => {

    const listenerSaga = cloneableGenerator( listener )( type );
    let listenerSagaclone1;
    let listenerSagaclone2;
    let listenerSagaclone3;
    let listenerSagaclone4;
    let listenerSagaclone5;
    it( 'should wait until the loading event has been put', () => {

      const putDescriptor  = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;
      listenerSagaclone1 = listenerSaga.clone();
      listenerSagaclone2 = listenerSaga.clone();
      listenerSagaclone3 = listenerSaga.clone();
      listenerSagaclone4 = listenerSaga.clone();
      listenerSagaclone5 = listenerSaga.clone();

      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post' } ) );
    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        title: 'test',
        status: 'ok'
      }
      const putDescriptor = listenerSaga.next( { body: res } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
    } );
    let clonedListenerSaga;

    it( 'should invoke removePickupSmsInfo after logout success', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( call( removePickupSmsInfo ) );
    } );

    it( 'should put a analytical event after removePickupSmsInfo event', () => {

      const dataLayer = {
        'globalPageData': {
          'navigation': {
            'pageName': 'empty bag'
          },
          'profile': {
            'email': '',
            'firstName':'',
            'lastName':''
          },
          'rewards': {
            'loyaltyId':'',
            'programId':'',
            'memberSince':'',
            'platinumMember':'',
            'platinumMemberType':'',
            'userType': 'Guest'
          },
          'order': {
            'currency': '',
            'total': '',
            'subtotal': '',
            'shipping': '',
            'itemCount': '',
            'voucher_discount': '',
            'orderItems': {}
          },
          'cart': {
            'autoRemovedItems':''
          },
          'messages': ''
        }
      };
      const putDescriptor = listenerSaga.next( ).value;
      clonedListenerSaga = listenerSaga.clone();
      expect( putDescriptor ).toEqual( put( setDataLayer( dataLayer ) ) );
    } );

    it( 'should not call removePickupSmsInfo method if res.body is undefined', () => {
      jest.resetAllMocks();
      const res = {
        body: undefined
      }
      listenerSagaclone5.next( res ); // this is logout success event
      const putDescriptor = listenerSagaclone5.next();

      expect( putDescriptor.value ).not.toEqual( call( removePickupSmsInfo ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should call put effect with sessionTokenRequested', () => {
      const putDescriptor = clonedListenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( sessionTokenRequested() ) );
    } );

    it( 'should call removeStaySignedInFlagForAnalytics function and take effect with user success after put sessionTokenRequested event', () => {
      expect( removeStaySignedInFlagForAnalytics ).not.toBeCalled( );

      const takeDescriptor = clonedListenerSaga.next().value;
      expect( removeStaySignedInFlagForAnalytics ).toBeCalled( );
      expect( takeDescriptor ).toEqual( take( getServiceType( 'user', 'success' ) ) );
    } );

    it( 'should set global.location.href', () => {
      const callDescriptor = clonedListenerSaga.next().done;
      expect( callDescriptor ).toEqual( true );
      expect( fullyQualifyLink ).toBeCalledWith( 'www.ulta.com', '?forceLogin=true' );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      const err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      expect( listenerSaga.next().done ).toBe( true );
    } );

    it( 'should call fullyQualifyLink method if isSoftLoginUser is false after user success event when a SESSION_EXPIRED is received', () => {
      const userData = {
        data: {
          user: {
            isSoftLoginUser : false
          }
        }
      }
      const err = {
        statusText: 'some failure message',
        status:appConstants.RESPONSE_CODE.SESSION_EXPIRED
      }
      listenerSagaclone2.throw( err ); // logout failure event
      const takeDescriptor = listenerSagaclone2.next().value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'user', 'success' ) ) );
      const nextStep = listenerSagaclone2.next( userData );

      expect( fullyQualifyLink ).toBeCalledWith( 'www.ulta.com', '?forceLogin=true' );
      expect( nextStep.done ).toEqual( true );
    } );

    it( 'should invoke the listener method again if isSoftLoginUser is true after user success event when a SESSION_EXPIRED is received', () => {
      const userData = {
        data: {
          user: {
            isSoftLoginUser : true
          }
        }
      }
      const err = {
        statusText: 'some failure message',
        status:appConstants.RESPONSE_CODE.SESSION_EXPIRED
      }
      listenerSagaclone1.throw( err ); // logout failure event
      const takeDescriptor = listenerSagaclone1.next().value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'user', 'success' ) ) );
      const putDescriptor = listenerSagaclone1.next( userData ).value;
      expect( putDescriptor ).toEqual( call( listener, type ) );
    } );

    it( 'should call fullyQualifyLink method if isSoftLoginUser is false after user success event when a TOKEN_MISMATCH is received', () => {
      const userData = {
        data: {
          user: {
            isSoftLoginUser : false
          }
        }
      }
      const err = {
        statusText: 'some failure message',
        status:appConstants.RESPONSE_CODE.TOKEN_MISMATCH
      }
      listenerSagaclone3.throw( err ); // logout failure event
      const takeDescriptor = listenerSagaclone3.next().value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'user', 'success' ) ) );
      const nextStep = listenerSagaclone3.next( userData );

      expect( fullyQualifyLink ).toBeCalledWith( 'www.ulta.com', '?forceLogin=true' );
      expect( nextStep.done ).toEqual( true );
    } );

    it( 'should invoke the listener method again if isSoftLoginUser is true after user success event when a TOKEN_MISMATCH is received', () => {
      const userData = {
        data: {
          user: {
            isSoftLoginUser : true
          }
        }
      }
      const err = {
        statusText: 'some failure message',
        status:appConstants.RESPONSE_CODE.TOKEN_MISMATCH
      }
      listenerSagaclone4.throw( err ); // logout failure event
      const takeDescriptor = listenerSagaclone4.next().value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'user', 'success' ) ) );
      const putDescriptor = listenerSagaclone4.next( userData ).value;
      expect( putDescriptor ).toEqual( call( listener, type ) );
    } );

  } );
} );
