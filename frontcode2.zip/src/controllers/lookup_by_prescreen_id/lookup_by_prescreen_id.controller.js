import { takeEvery, call, put } from 'redux-saga/effects';
import {
  types,
  actions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import { triggerAnalyticsEvent } from 'ulta-fed-core/dist/js/events/analytics/analytics.events';

import has from 'lodash/has';
import isUndefined from 'lodash/isUndefined';
import {
  fullyQualifyLink,
  host
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import {
  ajax
} from '../../utils/ajax/ajax';

// Individual exports for testing
export const listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    let _action = action;
    if( process.env.NODE_ENV === 'development' ){
      _action.data.values.__FORCE_RES = true;
    }

    const res = yield call(
      ajax, {
        type,
        method:'post',
        values: _action.data.values
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body.lpsPreScreenResponse ) );
    if( !isUndefined( res.body.lpsPreScreenResponse ) && has( res.body.lpsPreScreenResponse, 'firstName' ) ){
      if( !isUndefined( res.body.lpsPreScreenResponse.returnCode ) ){

        switch ( res.body.lpsPreScreenResponse.returnCode ){
          case '01':
            const omnitureData = {
              'globalPageData': {
                'action': {
                  'creditCardPrescreenApproval': 'true'
                }
              }
            }
            const omnitureEvt = {
              'name': 'pageNavigation'
            }
            yield put( triggerAnalyticsEvent( omnitureData, omnitureEvt ) );
            action.data.history.push( action.data.paths.successPath, { lpsData:res.body.lpsPreScreenResponse, flow: action.data.flow } );
            break;

          case '03':
            action.data.history.push( action.data.paths.failurePath );
            break;

          case '04':
            global.location.href = fullyQualifyLink( host, '/ulta/myaccount/index.jsp?member=true' );
            break;
        }
      }
      else {
        action.data.history.push( action.data.paths.failurePath );
      }
    }
    else {
      action.data.history.push( action.data.paths.failurePath );
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'lpsLookupByPrescreenId';

  registerServiceName( serviceType );

  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
