/**
 * Created by rush on 5/21/17.
 */
import { takeEvery, call, put } from 'redux-saga/effects';
import {
  types,
  actions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';


import {
  ajax
} from '../../utils/ajax/ajax';


export const listener = function*( type, action ){
  try {

    yield put( getActionDefinition( type, 'loading' )() );
    let values = {
      emailAddress: action.data.login,
      firstName: action.data.firstName,
      lastName: action.data.lastName,
      phoneNumber:action.data.phoneNumber
    }

    if( process.env.NODE_ENV === 'development' ){
      values.__FORCE_CODE = action.data.__FORCE_CODE
    }


    const res = yield call(
      ajax, {
        type,
        method: 'post',
        values
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body ) ) ;

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'lpsLookUp';
  // register events for the request
  registerServiceName( serviceType );

  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
