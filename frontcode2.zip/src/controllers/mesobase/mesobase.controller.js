import {
  takeEvery,
  call
} from 'redux-saga/effects';
import qProtocol from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';

import {
  TRIGGER_MESOBASE_EVENTS
} from '../../events/mesobase/mesobase.events';

export const triggerMesobaseEvents = function* ( CONFIG ){

  // this will check if mesobase script has been successfully loaded every 100 ms
  // if CNVR is available, it indicates that the mesobase script is loaded successfully
  let initalizeMesobase = setInterval( () => {
    if( global.CNVR ){
      clearInterval( initalizeMesobase );
      // Makes the request to the personalization service and passes the response object to the callback.
      global.CNVR.fetchUserDecision( CONFIG.MESOBASE_CONFIG, mesobaseCallback );
    }
  }, 100 ); // check every 100ms if mesobase and qubit is initialized
}

export const mesobaseCallback = ( response )=>{

  if( global.enableMesobaseLogs ){
    console.log("mesobase response ", response); //eslint-disable-line
  }
  var responseType = response.ResponseType;

  if( responseType === 'Decision' ){
    let mesobaseUserData = {
      user: {
        id: '',
        ...( response.member_tier && {
          loyalty: {
            tier: response.member_tier
          }
        } ),
        ...( response.last_transaction_date && { lastTransactionTs: parseInt( response.last_transaction_date, 10 ) } ),
        emailOptIn: response.has_email === 'Y'
      },
      ...( response.category_1 && { preferredCategoryOne: response.category_1 } ),
      ...( response.category_2 && { preferredCategoryTwo: response.category_2 } ),
      ...( response.category_3 && { preferredCategoryThree: response.category_3 } ),
      ...( response.category_4 && { preferredCategoryFour: response.category_4 } ),
      ...( response.category_5 && { preferredCategoryFive: response.category_5 } )
    }
    if( global.enableMesobaseLogs ){
      console.log("response---->", mesobaseUserData); //eslint-disable-line
    }

    qProtocol.triggerChildEvent( 'ulta.mesobaseUser', mesobaseUserData );
  }
}

export default function( CONFIG ){
  return function*(){
    yield takeEvery( TRIGGER_MESOBASE_EVENTS, triggerMesobaseEvents, CONFIG );
  }
}
