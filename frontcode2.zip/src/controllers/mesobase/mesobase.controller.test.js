
import {
  takeEvery,
  call
} from 'redux-saga/effects';
import qProtocol from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';

import CONFIG from '../../config';
import {
  TRIGGER_MESOBASE_EVENTS
} from '../../events/mesobase/mesobase.events';
import sagas, {
  triggerMesobaseEvents,
  mesobaseCallback
} from './mesobase.controller';




const listenerSaga = sagas( CONFIG )();

describe( 'mesobaseEventsSaga ', () =>{

  it( 'should listen to TRIGGER_MESOBASE_EVENTS', () =>{

    const takeEveryDescriptor = listenerSaga.next( ).value;

    expect( takeEveryDescriptor ).toEqual(
      takeEvery( TRIGGER_MESOBASE_EVENTS, triggerMesobaseEvents, CONFIG )
    );
  } );
} )

describe( 'triggerMesobaseEvents', () =>{

  const triggerMesobaseEventsListener = triggerMesobaseEvents( CONFIG );

  it( 'should invoke fetchUserDecision on successful load of mesobase script', () =>{
    window.CNVR = {
      fetchUserDecision:jest.fn()
    };
    window.clearInterval = jest.fn();

    jest.useFakeTimers();
    const takeEveryDescriptor = triggerMesobaseEventsListener.next();

    // At this point in time, the callback should not have been called yet
    expect( window.clearInterval ).not.toBeCalled();

    // Fast-forward until all timers have been executed
    jest.runTimersToTime( 100 );

    // Now our callback should have been called!
    expect( window.clearInterval ).toBeCalled();
    expect( window.CNVR.fetchUserDecision ).toBeCalledWith( CONFIG.MESOBASE_CONFIG, mesobaseCallback );
  } );
} )

describe( 'mesobaseCallback', () =>{
  it( 'should trigger callback function and trigger qprotocol', () => {
    window.CNVR = {
      fetchUserDecision:jest.fn()
    };

    let response = {
      'ResponseType': 'Decision',
      'member_tier': 'UR BRONZE TIER',
      'last_transaction_date': '1476994595732',
      'has_email': 'Y',
      'category_1': 'hair|shampoo',
      'category_2': 'fragrance',
      'category_3': 'salon',
      'category_4': 'hair|hair color',
      'category_5': 'skincare'
    };

    let mesobaseUserData = {
      'preferredCategoryFive': 'skincare',
      'preferredCategoryFour': 'hair|hair color',
      'preferredCategoryOne': 'hair|shampoo',
      'preferredCategoryThree': 'salon',
      'preferredCategoryTwo': 'fragrance',
      'user': {
        'id': '',
        'emailOptIn': true,
        'lastTransactionTs': 1476994595732,
        'loyalty': {
          'tier': 'UR BRONZE TIER'
        }
      }
    };

    qProtocol.triggerChildEvent = jest.fn();
    mesobaseCallback( response );
    expect( qProtocol.triggerChildEvent ).toBeCalledWith( 'ulta.mesobaseUser', mesobaseUserData );
  } );
} )
