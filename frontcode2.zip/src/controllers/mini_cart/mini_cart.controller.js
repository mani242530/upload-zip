import {
  takeEvery,
  takeLatest,
  call,
  put,
  take,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { ajax } from '../../utils/ajax/ajax';

import { getMiniBagCartServiceData } from '../../models/view/mini_cart/mini_cart.model';
import { triggerBasketEvents } from '../../events/qprotocol/qprotocol.events';


export const miniCart = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const res = yield call(
      ajax, {
        type,
        method:'get',
        values:action.data
      }
    );
    // fetch prev state at this point using a selector to get MiniBag data before modification
    const prevCartData = yield select( getMiniBagCartServiceData );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );

    const switchData = yield select( makeGetSwitchesData() );

    const isQubitEnabled = switchData.switches.enableQubitTag;

    // qprotocol basket events needs to be triggered if following conditions are met
    // 1. qubit is enabled
    // 2. there was no previous cart data or if there is a change in quanity compared to previous quanity
    // quanity comparison will ensure that we are not firing the events even if the user view minicart again and again
    if( isQubitEnabled && ( !prevCartData || prevCartData.cartSummary.itemCount !== res.body.data.cartSummary.itemCount ) ){
      yield put( triggerBasketEvents( 'minicart', res.body.data ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}

export const removeItemFromMiniCart = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const res = yield call(
      ajax, {
        type:'removeItemFromCart',
        method:'post',
        values: action.data
      }
    );

    yield put( getActionDefinition( 'user', 'requested' )() );
    yield take( getServiceType( 'user', 'success' ) );
    yield put( getActionDefinition( 'miniCart', 'requested' )() );
    yield put( getActionDefinition( type, 'success' )() );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}

export default function(){
  return function*( ){
    const serviceType = 'miniCart';
    const removeServiceType = 'removeItemFromMiniCart';
    registerServiceName( serviceType );
    registerServiceName( removeServiceType );
    yield takeEvery( getServiceType( serviceType, 'requested' ), miniCart, serviceType );
    yield takeLatest( getServiceType( removeServiceType, 'requested' ), removeItemFromMiniCart, removeServiceType );
  }
}
