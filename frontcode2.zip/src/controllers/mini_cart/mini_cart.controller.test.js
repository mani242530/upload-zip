import {
  takeEvery,
  takeLatest,
  call,
  put,
  cancelled,
  take,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { cloneableGenerator } from 'redux-saga/utils';
import { ajax } from '../../utils/ajax/ajax';
import { getMiniBagCartServiceData } from '../../models/view/mini_cart/mini_cart.model';
import CONFIG from '../../modules/pdp/pdp.config';
import saga, {
  miniCart,
  removeItemFromMiniCart
} from './mini_cart.controller';

const type = 'miniCart';
const removeType = 'removeItemFromMiniCart';
let action = {
  data:{
    sessionID : 44432,
    skuId: 2241934,
    productId : 123567,
    quantity: 1
  }
}
const listenerSaga = miniCart( type, action );
describe( 'MiniCart sagas', () => {
  const coreSaga = saga( CONFIG )();
  registerServiceName( type );
  registerServiceName( removeType );
  registerServiceName( 'user' );

  it( 'should take every miniCart request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), miniCart, type ) );
  } );

  it( 'should take every miniCart request', () => {
    const takeLatestDescriptor = coreSaga.next().value;
    expect( takeLatestDescriptor ).toEqual( takeLatest( getServiceType( removeType, 'requested' ), removeItemFromMiniCart, removeType ) );
  } );


  describe( 'miniCart saga success path', () => {

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      let values = action.data;

      expect( callDescriptor ).toEqual( call( ajax, { type, method:'get', values } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const selectDescriptor = listenerSaga.next( res ).value;
      const putDescriptor = listenerSaga.next( res ).value;
      expect( selectDescriptor ).toEqual( select( getMiniBagCartServiceData ) );
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );
  } );

  describe( 'MiniCart saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

  describe( 'MiniCart sagas remove flow', () => {

    const removeAction = {
      data:{
        removalCommerceId : 44432
      }
    }
    const listenerSaga = removeItemFromMiniCart( 'removeItemFromMiniCart', removeAction );

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( removeType, 'loading' )() ) );
    } );

    it( 'should invoke the ajax call to remove the item from cart', () => {
      const callDescriptor = listenerSaga.next().value;
      let values = action.data;

      expect( callDescriptor ).toEqual( call( ajax, { type:'removeItemFromCart', method:'post', values:removeAction.data } ) );
    } );

    it( 'should put a user requested event on the success of removal call', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'user', 'requested' )() ) );
    } );

    it( 'should wait to take a user success response', () => {
      const takeDescriptor = listenerSaga.next().value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'user', 'success' ) ) );
    } );

    it( 'should put a minicart requested event', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'minicart', 'requested' )() ) );
    } );

    it( 'should put a removeItemFromMiniCart success', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( removeType, 'success' )() ) );
    } );

  } );
} );
