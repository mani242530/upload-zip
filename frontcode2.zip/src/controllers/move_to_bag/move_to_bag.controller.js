import {
  takeEvery, call, put, select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType,
  checkoutRedirectListener
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { ajax } from '../../utils/ajax/ajax';
import {
  showMovedToBagSuccessMessage
} from '../../events/save_for_later/save_for_later.events';

import SaveForLaterItemsMessages from '../../views/SaveForLaterItems/SaveForLaterItems.messages';

import {
  getSaveForLaterState
} from '../../models/view/save_for_later/save_for_later.model'

export const listener = function*( type, action ){
  try {
    const { sflItemId, history, resetDeliveryOption } = action.data;
    const saveforLaterData = yield select( getSaveForLaterState );

    yield put( getActionDefinition( type, 'loading' )( sflItemId ) );
    // we are broadCasting an empty message because the screen reader will not read the same message which is populated in the globalAssertiveRegion div( which is in index.html).
    yield put( setBroadcastMessage( '' ) );

    let query = { sflItemId, resetDeliveryOption };

    const res = yield call(
      ajax, {
        type,
        method: 'post',
        query
      }
    );

    // if res has no error, showMovedToBagSuccessMessage action will be triggered,
    // showMovedToBagSuccessMessage action is to hide spinner and display transition message
    if( res.body.data ){
      const success = !!res.body.data.cart;
      yield put( showMovedToBagSuccessMessage( { sflItemId: action.data.sflItemId, success } ) );
      if( success ){
        yield put( setBroadcastMessage( formatMessage( SaveForLaterItemsMessages.moveToBagFromSaveForLaterLabel ) ) );
      }
      yield put( getActionDefinition( type, 'success' )( res.body.data ) );

      if( success ){
        /* Trigger Analytics event on moveToBagFromSaveForLater success */
        const evt = {
          'name': 'bagMoveToBag',
          'data': {
            'productSku' : action.data.skuId
          }
        }
        yield put( triggerAnalyticsEvent( evt ) );

        // numberOfSFLItems is the total number of items in the state after moving the  SFL item to bag
        const numberOfSFLItems = saveforLaterData.saveForLaterItems.length - 1;
        // should trigger saveForLaterAPI to fetch the next item in save for later setion if totalNumRecs in response is greater than the items present in state
        if( res.body.data.saveForLater.totalNumRecs > numberOfSFLItems ){
          yield put( getActionDefinition( 'saveForLater', 'requested' )( { start: numberOfSFLItems, limit: 1 } ) );
        }

        const cartItemQuantity = parseInt( res.body.data?.cart?.cartSummary?.itemCount, 10 );

        // this will handle the redirection to the bag page if the item moves to bag section from empty bag page
        yield put( checkoutRedirectListener( history, cartItemQuantity ) );
      }

    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    console.log( err );// eslint-disable-line
  }

}

export default function*(){
  let serviceType = 'moveToBagFromSaveForLater';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
