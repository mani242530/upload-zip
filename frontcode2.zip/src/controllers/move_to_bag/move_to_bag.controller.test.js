import {
  takeEvery, call, put, select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType,
  checkoutRedirectListener
} from 'ulta-fed-core/dist/js/events/services/services.events';



import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';


import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { initializeIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';

import React from 'react';
import { cloneableGenerator } from 'redux-saga/utils';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  initialState as initialStateGlobal
} from '../../models/view/global/global.model';
import { ajax } from '../../utils/ajax/ajax';

import CONFIG from '../../modules/ccr/ccr.config';
import configureStore from '../../modules/ccr/ccr.store';
import SaveForLaterItemsMessages from '../../views/SaveForLaterItems/SaveForLaterItems.messages';
import {
  showMovedToBagSuccessMessage
} from '../../events/save_for_later/save_for_later.events';
import saga, { listener } from './move_to_bag.controller';

import { getSaveForLaterState } from '../../models/view/save_for_later/save_for_later.model';

describe( 'MoveToBagFromSaveForLater saga', () => {
  const type = 'moveToBagFromSaveForLater';
  registerServiceName( type );
  registerServiceName( 'saveForLater' );
  const moveToBagFromSaveForLaterSaga = saga();

  initializeIntl();

  describe( 'default saga', () => {
    it( 'should listen for the moveToBagFromSaveForLater request method', () => {
      const takeEveryDescriptor = moveToBagFromSaveForLaterSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), listener, type )
      );
    } );
  } );

  describe( 'listener saga success path', () => {
    let action = {
      data: {
        sflItemId: 'gi101920006',
        history: '/bag',
        resetDeliveryOption:false,
        skuId: '2286651'
      }
    };
    const res = {
      body: {
        data: {
          saveForLater: {
            totalNumRecs:10,
            items: [
              {
                product: {
                  id: 'xlsImpprod12251073'
                },
                messages: null,
                sflItemId: 'gi101920006'
              }
            ]
          },
          cart: {
            cartSummary:{
              itemCount: 1,
              messages: null
            }
          }
        }
      }
    };
    const listenerSaga = cloneableGenerator( listener )( type, action );
    let listenerSagaClone;
    it( 'Should select getSaveForLaterState event to fetch saveForLater state', () => {
      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( select( getSaveForLaterState ) );
    } );
    it( 'should wait until the loading event has been put', () => {
      const saveforLaterData = {
        saveForLaterItems:[
          { sflItemId:1 },
          { sflItemId:1 },
          { sflItemId:1 }
        ]
      }
      const putDescriptor = listenerSaga.next( saveforLaterData ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( action.data.sflItemId ) ) );
    } );

    it( 'should put setBroadcastMessage action with empty message', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( '' ) ) );
    } );

    it( 'should call moveToBagFromSaveForLater API', () => {
      let query = {
        sflItemId: action.data.sflItemId,
        resetDeliveryOption:action.data.resetDeliveryOption
      }
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', query } ) );
    } );

    it( 'should put a success event to show SFL item moved to bag  transition message if item is moved to bag successfully', () => {
      listenerSagaClone = listenerSaga.clone();
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( showMovedToBagSuccessMessage( { sflItemId: action.data.sflItemId, success:true } ) ) );
    } );

    it( 'should put setBroadcastMessage action with moveToBagFromSaveForLater transition message', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( formatMessage( SaveForLaterItemsMessages.moveToBagFromSaveForLaterLabel ) ) ) );
    } );

    it( 'should put a moveToBagFromSaveForLater success event', () => {
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should trigger analytics event named bagMoveToBag after success', () => {
      const evt = {
        'name': 'bagMoveToBag',
        'data': {
          'productSku' : action.data.skuId
        }
      }
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );

    it( 'should put a saveForLater requested event when totalNumRecs in res is greater than numberOfSFLItems', () => {

      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'saveForLater', 'requested' )( { start: 2, limit: 1 } ) ) );
    } );

    it( 'should put checkoutRedirectListener event', () => {
      const putDescriptor = listenerSaga.next( ).value;
      const cartItemQuantity = res.body.data.cart.cartSummary.itemCount;
      expect( putDescriptor ).toEqual( put( checkoutRedirectListener( action.data.history, cartItemQuantity ) ) );
    } );


    describe( 'moveToBag scenarios when cart is returned as null', () => {

      it( 'should put an event with success as false', () => {
        res.body.data.cart = null;
        const putDescriptor = listenerSagaClone.next( res ).value;
        expect( putDescriptor ).toEqual( put( showMovedToBagSuccessMessage( { sflItemId: action.data.sflItemId, success:false } ) ) );
      } );

      it( 'should put a moveToBagFromSaveForLater success event', () => {
        const putDescriptor = listenerSagaClone.next().value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
      } );

      it( 'should not put handleRestoreItem ', () => {
        const putDescriptor = listenerSagaClone.next( );
        expect( putDescriptor.done ).toEqual( true );
      } );

    } )
  } );

  describe( 'listener saga success path if resetDeliveryOption in action.data is true', () => {
    let action = {
      data: {
        sflItemId: 'gi101920006',
        history: '/bag',
        resetDeliveryOption: true,
        skuId: '2286651'
      }
    };
    const res = {
      body: {
        data: {
          saveForLater: {
            items: [
              {
                product: {
                  id: 'xlsImpprod12251073'
                },
                messages: null,
                sflItemId: 'gi101920006'
              }
            ]
          },
          cart: {
            cartSummary:{
              itemCount: 1,
              messages: null
            }
          }
        }
      }
    };
    const listenerSaga1 = listener( type, action );

    it( 'should call moveToBagFromSaveForLater API with resetDeliveryOption as true in query if resetDeliveryOption is true in action.data', () => {
      listenerSaga1.next( ); // this is to get saveforLater state using select
      const saveforLaterData = {
        saveForLaterItems:[
          { sflItemId:1 },
          { sflItemId:1 },
          { sflItemId:1 }
        ]
      }
      listenerSaga1.next( saveforLaterData ); // this is moveToBagFromSaveForLater loading
      listenerSaga1.next( ); // this is empty setBroadcastMessage action

      let query = {
        sflItemId: action.data.sflItemId,
        resetDeliveryOption: true
      }
      const callDescriptor = listenerSaga1.next( ).value;
      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', query } ) );
    } );


  } );

  describe( 'listener saga failure path', () => {
    let action = {
      data:'gi101920006'
    };
    const failureSaga = listener( type, action );
    failureSaga.next();

    window.console = {
      log:jest.fn()
    }

    const err = {
      statusText:'some failure message'
    };

    it( 'should put a failure event if any error occurs during the sagas execution', () => {
      const putDescriptor = failureSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

    it( 'should log the error to the console', () => {
      failureSaga.next();
      expect( window.console.log ).toHaveBeenCalledWith( err );
    } );
  } );

} );
