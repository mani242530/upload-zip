/*
* moveToSaveForLater saga: calls the api to move items from bag to SaveForLater section
* */

import {
  takeEvery,
  call,
  put
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType,
  checkoutRedirectListener
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { ajax } from '../../utils/ajax/ajax';
import {
  MOVE_TO_SFL,
  moveItemToSaveForLater
} from '../../events/save_for_later/save_for_later.events';

import {
  openSignInModal
} from '../../events/sign_in_modal/sign_in_modal.events';


import ProductCellItemMessages from '../../views/ProductCellItem/ProductCellItem.messages';



import appConstants from '../../shared/appConstants';
export const listener = function* ( type, CONFIG, action ){
  try {
    const {
      skuId, history, isSignedIn, saveForLaterLocation
    } = action.data;

    // move to save for later call need to be triggered only for registered user
    if( isSignedIn ){

      yield put( getActionDefinition( type, 'loading' )( { skuId } ) );
      // we are broadCasting an empty message because the screen reader will not read the same message which is populated in the globalAssertiveRegion div( which is in index.html).
      yield put( setBroadcastMessage( '' ) );

      const res = yield call(
        ajax, {
          type,
          method:'post',
          query: {
            skuIds: [skuId]
          }
        }
      );
      // if res has no error, moveItemToSaveForLater action will be triggered
      // moveItemToSaveForLater action is to hide the spinner and display the transition
      if( res.body.data ){
        yield put( moveItemToSaveForLater( { skuId, movedItems: res.body.data } ) );
        yield put( setBroadcastMessage( formatMessage( ProductCellItemMessages.movedToSaveForLaterLabel ) ) );
        yield put( getActionDefinition( type, 'success' )( res.body.data ) );

        // this will handle the redirection to the empty bag page if all the items got moved to save for later section
        // as part of the moveToSaveForLater call
        if( res.body.data.cart.cartSummary.itemCount === 0 ){
          yield put( checkoutRedirectListener( history, 0 ) );
        }
        /* Trigger Analytics event on moveToSaveForLater success */
        const evt = {
          'name': 'bagSaveForLater',
          'data': {
            'productSku' : skuId,
            saveForLaterLocation
          }
        }
        yield put( triggerAnalyticsEvent( evt ) );
      }
    }
    else {
      // if user is not logged in trigger action to open SignIn Modal
      // passing loginSuccessHandler as parameter to trigger move to SFL action after successful login
      const loginSuccessHandler = {
        action:MOVE_TO_SFL,
        skuId,
        saveForLaterLocation
      }
      yield put( openSignInModal( { loginSuccessHandler, sourcePage: appConstants.ANALYTICS.BAG_LOGIN_SOURCE } ) )
    }
  }

  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    console.log( err ); // eslint-disable-line
  }
};


export default function( CONFIG ){
  return function* (){
    let serviceType = 'moveToSaveForLater';
    // register events for the request
    registerServiceName( serviceType );
    yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType, CONFIG );
  }
}
