import { takeEvery, call, put } from 'redux-saga/effects';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition,
  checkoutRedirectListener
} from 'ulta-fed-core/dist/js/events/services/services.events';

import { cloneableGenerator } from 'redux-saga/utils';

import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { initializeIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import React from 'react';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  initialState as initialStateGlobal
} from '../../models/view/global/global.model';
import {
  ajax
} from '../../utils/ajax/ajax';
import configureStore from '../../modules/ccr/ccr.store';
import CONFIG from '../../modules/ccr/ccr.config';
import {
  openSignInModal
} from '../../events/sign_in_modal/sign_in_modal.events';
import ProductCellItemMessages from '../../views/ProductCellItem/ProductCellItem.messages';
import {
  MOVE_TO_SFL,
  moveItemToSaveForLater
} from '../../events/save_for_later/save_for_later.events';
import saga, { listener } from './move_to_save_for_later.controller';

import appConstants from '../../shared/appConstants';

describe( 'MoveToSaveForLater Saga', () => {
  const type = 'moveToSaveForLater';
  registerServiceName( type );
  const moveToSaveForLaterSaga = saga( CONFIG )();

  initializeIntl();

  describe( 'default saga', () => {
    it( 'should listen for the MoveToSaveForLater request method', () => {
      const takeEveryDescriptor = moveToSaveForLaterSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), listener, type, CONFIG )
      );
    } );
  } );

  describe( 'listener saga - For Signed in user', () => {
    let action = {
      data: {
        skuId: 'testId', history: '/bag', isSignedIn:true, saveForLaterLocation:'/bag'
      }
    };
    const hasCartItemsResponse = {
      body:{
        data: {
          title: 'test',
          status: 'ok',
          cart: {
            cartSummary: {
              itemCount: 1
            }
          }
        }
      }
    };

    const listenerSaga = cloneableGenerator( listener )( type, CONFIG, action );
    let listenerSagaClone;

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { skuId: action.data.skuId } ) ) );
    } );

    it( 'should put setBroadcastMessage action with empty message', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( '' ) ) );
    } );

    it( 'should call moveToSaveForLater API', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( ajax, {
        type,
        method: 'post',
        query: {
          skuIds: [action.data.skuId]
        }
      } ) );
    } );

    it( 'should put moveItemToSaveForLater action', () => {
      listenerSagaClone = listenerSaga.clone();
      const expectedData = {
        skuId:action.data.skuId,
        movedItems: hasCartItemsResponse.body.data
      }
      const putDescriptor = listenerSaga.next( hasCartItemsResponse ).value;
      expect( putDescriptor ).toEqual( put( moveItemToSaveForLater( expectedData ) ) );
    } );

    it( 'should put setBroadcastMessage action with movedToSaveForLater transition message', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( formatMessage( ProductCellItemMessages.movedToSaveForLaterLabel ) ) ) );
    } );

    it( 'should put a moveToSaveForLater success event', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( hasCartItemsResponse.body.data ) ) );
    } );

    it( 'should put an analytic event on moveToSaveForLater success passing skuId and saveForLaterLocation (bag or bag update) passed in the action as parameter', () => {
      const putDescriptor = listenerSaga.next().value;
      const evt = {
        'name': 'bagSaveForLater',
        'data': {
          'productSku' : action.data.skuId,
          saveForLaterLocation:action.data.saveForLaterLocation
        }
      }
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );

    it( 'should not put the action to redirect to a different page, as the cart item count is not 0 in the service response', () => {
      const putDescriptor = listenerSaga.next();
      expect( putDescriptor.done ).toEqual( true );
    } );

    it( 'should put the action to redirect the user to empty bag page, when the itemCount is 0 in the service response ', () => {
      const noCartItemsResponse = {
        body:{
          data: {
            cart: {
              cartSummary: {
                itemCount: 0
              }
            }
          }
        }
      };
      listenerSagaClone.next( noCartItemsResponse ); // this is moveItemToSaveForLater action
      listenerSagaClone.next(); // this is setBroadcastMessage action
      listenerSagaClone.next(); // this is success action
      const putDescriptor = listenerSagaClone.next( ).value;
      expect( putDescriptor ).toEqual( put( checkoutRedirectListener( action.data.history, 0 ) ) );
    } );

    describe( 'failure path', () => {
      const failureSaga = listener( type, CONFIG, action );
      failureSaga.next();
      window.console = {
        log:jest.fn()
      }
      const err = {
        statusText:'some failure message'
      };

      it( 'should put a failure event if any error occurs during the sagas execution', () => {
        const putDescriptor = failureSaga.throw( err ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );

      it( 'should log the error to the console', () => {
        const putDescriptor = failureSaga.next();
        expect( window.console.log ).toHaveBeenCalledWith( err );
      } );

    } );
  } );
  describe( 'listener saga - For Guest user', () => {
    let action = {
      data: {
        skuId: 'testId', history: '/bag', isSignedIn:false, saveForLaterLocation: 'bag', sourcePage: 'bag'
      }
    };

    const listenerSaga = listener( type, CONFIG, action );

    it( 'should put action to open SignIn Modal', () => {
      const putDescriptor = listenerSaga.next( ).value;
      const data = {
        loginSuccessHandler: {
          action:MOVE_TO_SFL,
          saveForLaterLocation: 'bag',
          skuId:action.data.skuId
        },
        sourcePage: appConstants.ANALYTICS.BAG_LOGIN_SOURCE
      }
      expect( putDescriptor ).toEqual( put( openSignInModal( data ) ) );
    } );

  } );
} );
