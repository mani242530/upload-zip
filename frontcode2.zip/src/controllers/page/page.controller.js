
import { takeEvery, call, put } from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ajax
} from '../../utils/ajax/ajax';


// Individual exports for testing
export const listener = function*( type ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );

    const res = yield call( ajax,
      {
        type,
        page:{
          type: 'home'
        }
      } );


    yield put( getActionDefinition( type, 'success' )( res.body.pageContent ) ) ;

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'page';
  // register events for the request
  registerServiceName( serviceType );

  yield takeEvery( getServiceType( 'page', 'requested' ), listener, serviceType );
}
