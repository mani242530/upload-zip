
/**
 * Page  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import saga, { listener } from './page.controller';


import {
  ajax
} from '../../utils/ajax/ajax';

// jest.mock('superagent');

const type = 'page';

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );

  describe( 'default saga', () => {

    const navigationSaga = saga();

    it( 'should listen for the navigation requested method', () => {

      const takeEveryDescriptor = navigationSaga.next().value;
      expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( 'page', 'requested' ), listener, type ) );
    } );

  } );

  describe( 'listener saga success path', () => {

    const listenerSaga = listener( type );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor  = listenerSaga.next().value;


      expect( callDescriptor ).toEqual( call( ajax, { type, page:{ type:'home' } } ) );

    } );

    it( 'should put a success event after data is called', () => {

      let res = {
        title: 'test',
        status: 200
      }

      const putDescriptor = listenerSaga.next( { body:{ pageContent: res } } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );


} );
