import {
  takeEvery,
  takeLatest,
  call,
  put,
  cancelled,
  cancel
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  pageRedirect,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { ajax } from '../../utils/ajax/ajax';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

export const updateDataLayer = function*( res ){
  const data = {
    'globalPageData': {
      'messages': {
        message: res.body.data.messages.items,
        type:'error'
      }
    }
  }
  const evt = {
    'name': 'serviceMessagesUpdated'
  }
  yield put( setDataLayer( data, evt ) );
}

export const resetPasswordRequest = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() )
    const res = yield call(
      ajax, {
        type:'resetPasswordReqest',
        method:'post',
        values:{ userEmailId :action.data.values.emailAddress }
      }

    )
    const {
      pathname
    } = action.data.history.location;

    yield put( getActionDefinition( type, 'success' )( { ...res.body.data, userEmailId :action.data.values.emailAddress, pageType: 'password' } ) )
    if( res.body.data.success ){
      let confirmPath = `${action.data.passwordResetRoute}forgot-password-sent`;
      action.data.history.push( confirmPath );
      yield put( pageRedirect( pathname, confirmPath ) );
      yield cancel();
    }
    else {
      yield call( updateDataLayer, res );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) )
    if( window.TRACK_SAGA_FAILURES ){
      console.error( err.message ); //eslint-disable-line
    }
  }

}

export const resetUsernameRequest = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() )
    const res = yield call(
      ajax, {
        type:'forgotUserName',
        method:'post',
        values:{ userEmailId :action.data.values.emailAddress }
      }

    )
    const {
      pathname
    } = action.data.history.location;

    yield put( getActionDefinition( type, 'success' )( { ...res.body.data, userEmailId :action.data.values.emailAddress, pageType: 'username' } ) )
    if( res.body.data.success ){
      let confirmPath = `${action.data.passwordResetRoute}forgot-username-sent`;
      action.data.history.push( confirmPath );
      yield put( pageRedirect( pathname, confirmPath ) );
      yield cancel();
    }


  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) )
    if( window.TRACK_SAGA_FAILURES ){
      console.error( err.message ); //eslint-disable-line
    }
  }

}

export default function*(){
  let serviceType = 'passwordResetRequest';
  registerServiceName( serviceType );
  yield takeLatest( getServiceType( serviceType, 'requested' ), resetPasswordRequest, serviceType );

  serviceType = 'forgotUserName';
  registerServiceName( serviceType );
  yield takeLatest( getServiceType( serviceType, 'requested' ), resetUsernameRequest, serviceType );
}
