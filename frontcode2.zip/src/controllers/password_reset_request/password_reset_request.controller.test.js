import {
  takeEvery,
  call,
  put,
  cancelled,
  take,
  takeLatest
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType,
  pageRedirect
} from 'ulta-fed-core/dist/js/events/services/services.events';


import { cloneableGenerator } from 'redux-saga/utils';
import { ajax } from '../../utils/ajax/ajax';

import saga, {
  resetPasswordRequest,
  resetUsernameRequest,
  updateDataLayer
} from './password_reset_request.controller'

describe( 'password reset request saga', () => {
  let serviceType = 'passwordResetRequest';
  var action = {
    data:{
      values:{ userEmailId : 'ans@ulta.com' },
      history: {
        location: {
          pathname: '/forgot-password'
        },
        push: jest.fn()
      },
      passwordResetRoute: '/'
    }
  }

  const listenerSaga = cloneableGenerator( resetPasswordRequest )( serviceType, action );
  let listenerSagaClone;

  describe( 'password reset request saga', () => {
    const coreSaga = saga();
    registerServiceName( serviceType )

    it( 'should take latest password reset request', () => {
      const takeLatestDescriptor = coreSaga.next().value;
      expect( takeLatestDescriptor ).toEqual( takeLatest( getServiceType( serviceType, 'requested' ), resetPasswordRequest, serviceType ) )
    } )

    describe( 'password reset request saga success path', () => {
      it( 'should  until the loading event has been put', () => {
        const putDescriptor = listenerSaga.next().value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'loading' )() ) );
      } );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      let values = { emailAddress:action.data.values.emailAddress };

      expect( callDescriptor ).toEqual( call( ajax, { type:'resetPasswordReqest', method:'post', values } ) );
    } );

    it( 'should put a success event after data is called', () => {
      listenerSagaClone = listenerSaga.clone();
      const res = {
        body: {
          data:{
            success:true,
            messages : null
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'success' )( { ...res.body.data, userEmailId :action.data.values.emailAddress, pageType: 'password' } ) ) );
    } );

    it( 'should redirect to confirmation page on success', () => {
      const res = {
        body: {
          data:{
            success:true,
            messages : null
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      let confirmPath = `${action.data.passwordResetRoute}forgot-password-sent`;
      expect( putDescriptor ).toEqual( put( pageRedirect(
        action.data.history.location.pathname, confirmPath
      ) ) );
    } );

    it( 'should put a setDataLayer action', () => {
      const res = {
        body: {
          data:{
            success:false,
            messages: {
              items:[
                {
                  type:'error',
                  message:'Failed to raise reset password request.'
                }
              ]
            }
          }
        }
      };
      const data = {
        'globalPageData': {
          'messages': {
            message: res.body.data.messages.items,
            type:'error'
          }
        }
      }
      const evt = {
        'name': 'serviceMessagesUpdated'
      }
      listenerSagaClone.next( res ).value;
      const putDescriptor = listenerSagaClone.next( ).value;
      expect( putDescriptor ).toEqual( call( updateDataLayer, res ) );
    } );

    describe( 'password reset request saga failure path', () => {

      it( 'should put a failure event if no data is returned from the service', () => {
        window.TRACK_SAGA_FAILURES = true;
        const err = {
          statusText:'some failure message'
        }
        const putDescriptor = listenerSaga.throw( err, window ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'failure' )( err ) ) );
      } );

    } );
  } )
} )


describe( 'Forgot username request saga', () => {
  let serviceType = 'forgotUserName';
  let action = {
    data:{
      values:{ userEmailId : 'ans@ulta.com' },
      history: {
        location: {
          pathname: '/forgot-username'
        },
        push: jest.fn()
      },
      passwordResetRoute: '/'
    }
  }

  let listenerSaga = resetUsernameRequest( serviceType, action );
  let coreSaga = saga();
  registerServiceName( serviceType )

  it( 'should take latest username reset request', () => {
    let takeLatestDescriptor = coreSaga.next();
    takeLatestDescriptor = coreSaga.next().value;
    expect( takeLatestDescriptor ).toEqual( takeLatest( getServiceType( serviceType, 'requested' ), resetUsernameRequest, serviceType ) )
  } )

  describe( 'password reset request saga success path', () => {
    it( 'should  until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'loading' )() ) );
    } );
  } );
  it( 'should yield on requesting data and return that data with a sucess method', () => {
    const callDescriptor = listenerSaga.next().value;
    let values = { emailAddress:action.data.values.emailAddress };

    expect( callDescriptor ).toEqual( call( ajax, { type:'forgotUserName', method:'post', values } ) );
  } );
  it( 'should put a success event after data is called', () => {
    const res = {
      body: {
        data:{
          success:true,
          messages : null
        }
      }
    };
    const putDescriptor = listenerSaga.next( res ).value;
    expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'success' )( { ...res.body.data, userEmailId :action.data.values.emailAddress, pageType: 'username' } ) ) );
  } );
  it( 'should redirect to confirmation page on success', () => {
    const res = {
      body: {
        data:{
          success:true,
          messages : null
        }
      }
    };
    const putDescriptor = listenerSaga.next( res ).value;
    let confirmPath = `${action.data.passwordResetRoute}forgot-username-sent`;
    expect( putDescriptor ).toEqual( put( pageRedirect(
      action.data.history.location.pathname, confirmPath
    ) ) );
  } );
  describe( 'password reset request saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'failure' )( err ) ) );
    } );
  } );
} );
