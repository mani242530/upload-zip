
import {
  takeEvery, call, put, select, cancel, cancelled, take
} from 'redux-saga/effects';
import { delay } from 'redux-saga';

import isUndefined from 'lodash/isUndefined';
import has from 'lodash/has';
import isEmpty from 'lodash/isEmpty';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  ajax
} from '../../utils/ajax/ajax';
import { getTokenization } from '../../utils/tokenization/tokenization';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

let isPaymentRequested = {
  type: ''
}

export const listener = function*( type, data ){
  try {
    let res;

    if( isPaymentRequested.type === '' ){

      isPaymentRequested = yield put( getActionDefinition( type, 'loading' )( data.data.values ) );

      let values = data.data.values;
      // get global switch data to get token related config data.
      const switchData = yield select( makeGetSwitchesData() );
      // Need to genetate token only for creditCard payment type and when user enter full creditCard and cart type should be other than PLCC card
      if( switchData.switches.tokenizationEnabled && values.paymentType && values.paymentType === 'creditCard' && values.creditCardNumber.length > 4 && values.creditCardType !== 'Ultamate Rewards Credit Card' ){
        values = yield call( handleTokenization, values, switchData );
      }

      res = yield call( ajax,
        {
          type,
          method:'post',
          values
        } );
      yield put( getActionDefinition( type, 'success' )( { result:res.body.data, paymentType:data.data.values.paymentType } ) );
      isPaymentRequested.type = '';
      if( res.body.data ){
        yield call( handleAnalytics, res );
      }
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    isPaymentRequested.type = '';
    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
  finally {
    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'success' )( { istokenizationFailure: true } ) );
      isPaymentRequested.type = '';
    }
  }
}

export const handleTokenization = function*( values, switchData ){

  yield put( getActionDefinition( 'paymentsCCKey', 'requested' )() );
  const paymentsCCKeyData = yield take( getServiceType( 'paymentsCCKey', 'success' ) );

  // cancel paymemnt update service call, if payments CC Key not generated
  if( !has( paymentsCCKeyData, 'data.jwk' ) ){
    yield cancel();
  }
  const paymentsCCToken = paymentsCCKeyData.data.jwk;
  const creditCardTokenForProduction = switchData.switches.creditCardTokenForProduction;
  const creditCardTypeMapping = switchData.switches.creditCardTypeMapping;
  const cardInfoData = {
    cardNumber: values.creditCardNumber,
    cardType: creditCardTypeMapping[values.creditCardType],
    expiryMonth: values.expirationMonth,
    expiryYear: values.expirationYear
  }

  // getTokenization call to generate token call
  const cyberCCToken = yield call( getTokenization, {
    paymentsCCToken,
    cardInfoData,
    creditCardTokenForProduction
  } );

  // cancel paymemnt update service call, if any issues with cybersource token call
  if( isUndefined( cyberCCToken ) ){
    yield cancel();
  }

  let newValues = values;
  // After successfull token generated, delete the creditCardNumber key from the POST object
  // Add maskedPan and creditCardToken to the POST object that given by cybersource
  delete newValues.creditCardNumber;
  newValues.maskedPan = cyberCCToken.maskedPan;
  newValues.creditCardToken = cyberCCToken.token;

  return newValues;

}

export const handleAnalytics = function*( res ){


  const {
    cartSummary,
    paymentInfo
  } = res.body.data;

  let messages = [];
  paymentInfo && paymentInfo.items.forEach( function( payment ){
    if( !isEmpty( payment.messages && payment.messages.items ) ){
      messages.push( ...payment.messages.items );
    }
  } );

  const data = {
    'globalPageData': {
      'order': {
        'total': ( cartSummary.estimatedTotal ).toFixed( 2 ),
        'subtotal': ( cartSummary.subTotal ).toFixed( 2 ),
        // shippingCost will be null if fulfillment type is delivery
        ...( cartSummary.shippingCost && { 'shipping': ( cartSummary.shippingCost === 'FREE' ? cartSummary.shippingCost : ( cartSummary.shippingCost ).toFixed( 2 ) ) } ),
        'voucher_discount': cartSummary.couponDiscount
      },
      'messages': messages
    }

  }


  let evt = undefined;

  paymentInfo && paymentInfo.items.forEach( function( payment ){
    if( payment.paymentType === 'giftCard' && payment.messages && payment.messages.items[0].type === 'Error' ){
      evt = {
        'name': 'trackErrorDisplayed',
        'data': {
          'errorType':'form',
          'errorLabel':'apply gift cart',
          'errorDescription': payment.messages.items[0].message
        }
      }
    }
    else if( payment.paymentType === 'giftCard' ){
      evt = {
        'name': 'trackApplyGiftCard'
      }
    }
  } );


  yield put( setDataLayer( data, evt ) );

  if( !isEmpty( messages ) ){
    const messageEvent = {
      'name': 'serviceMessagesUpdated'
    }
    yield put( setDataLayer( data, messageEvent ) );
  }

}

export default function*(){
  let serviceType = 'paymentServiceResponse';
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );

  serviceType = 'removePaymentService';
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );

}
