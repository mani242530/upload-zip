/**
 * PaymentService sagas test
 */

import {
  takeEvery,
  call,
  put,
  select,
  cancel,
  cancelled,
  take
} from 'redux-saga/effects';
import { delay } from 'redux-saga';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { cloneableGenerator } from 'redux-saga/utils';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import { getTokenization } from '../../utils/tokenization/tokenization';

import {
  ajax
} from '../../utils/ajax/ajax';
import saga, {
  listener, handleTokenization, handleAnalytics
} from './payment_service.controller';

const res = {
  body:{
    data: {
      cartSummary: {
        estimatedTotal: 422.57,
        subTotal: 394,
        shippingCost: 'FREE',
        couponDiscount: 0,
        itemCount: 12
      },
      paymentInfo: {
        items: [{
          mount: 41.49,
          paymentType: 'giftCard',
          messages: {
            items: [{
              type: 'Info'
            }]
          }
        }]
      }
    }
  }
};
const paymentType = 'creditCard';
let isPaymentRequested = {
  type: ''
};
const data = {
  data:{
    values:{
      paymentType,
      creditCardNumber: '411111111111'
    }
  }
};
const evt = 'test';

describe( 'paymentService Saga', () => {

  const paymentServiceSaga = saga();
  const type = 'paymentServiceResponse';

  registerServiceName( type );

  describe( 'paymentServiceResponse saga', () =>{

    it( 'should listen for the paymentServiceResponse requested method', () =>{

      const takeEveryDescriptor = paymentServiceSaga.next().value;

      expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), listener, type ) );

    } );

  } );

  describe( 'listener saga success/failure path', () => {

    const listenerSaga = cloneableGenerator( listener )( type, data );
    let listenerSagaClone;
    let sagaCancelClone;
    it( 'should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;

      isPaymentRequested.type = 'loading';

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( data.data.values ) ) );
      expect( isPaymentRequested ).toEqual( { type:'loading' } );

    } );
    it( 'should select swithces data', () => {
      const isPaymentRequested = {
        type:'PAYMENTSERVICERESPONSE_DATA_LOADING'
      }
      expect( JSON.stringify( listenerSaga.next( isPaymentRequested ).value ) ).toBe( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should invoke handleTokenization if tokenizationEnabled is enabled ', () => {
      listenerSagaClone = listenerSaga.clone();
      const switchData = {
        switches:{
          tokenizationEnabled:true
        }
      }
      const callDescriptor = listenerSaga.next( switchData ).value;
      expect( callDescriptor ).toEqual( call( handleTokenization, { 'creditCardNumber': '411111111111', 'paymentType': 'creditCard' }, switchData ) );

    } );

    it( 'should yield the ajax POST call', () => {
      const maskedValues = { 'creditCardNumber': '4111XXXXX1111', 'paymentType': 'creditCard' };
      const callDescriptor  = listenerSaga.next( maskedValues ).value;

      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', values:maskedValues } ) );

    } );

    it( 'should put a success call', () => {

      isPaymentRequested.type = '';
      const putDescriptor  = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual(
        put( getActionDefinition( type, 'success' )( { result:res.body.data, paymentType:data.data.values.paymentType } ) )
      );
      expect( isPaymentRequested ).toEqual( { type:'' } );

    } );

    it( 'should call handleAnalytics method', () => {
      const callDesriptor  = listenerSaga.next().value;
      expect( callDesriptor ).toEqual( call( handleAnalytics, res ) );

    } );

    describe( 'listener saga failure path', () => {
      const err = {
        statusText:'some failure message'
      };

      it( 'should put a failure event if no data is returned from the service', () => {
        global.TRACK_SAGA_FAILURES = true;
        const putDescriptor = listenerSaga.throw( err, global ).value;
        isPaymentRequested.type = '';
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );
    } );

    describe( 'listener saga finally block', () => {

      it( 'should cancel the event if an error occured in the service', () => {
        const cancelDescriptor = listenerSaga.next().value;
        expect( cancelDescriptor ).toEqual( cancelled() );
      } );
      it( 'should put a cancel action', () => {
        const putDescriptor = listenerSaga.next( true, window ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { istokenizationFailure: true } ) ) );
      } );
    } );

  } );

} );

describe( 'PaymentService Saga', () => {

  describe( 'removePaymentService saga', () => {

    it( 'should listen for the removePaymentService requested method', () => {

      const removePaymentServiceSaga = saga();
      const removeType = 'removePaymentService';

      registerServiceName( removeType );

      removePaymentServiceSaga.next();
      const takeEveryDescriptor = removePaymentServiceSaga.next().value;

      expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( removeType, 'requested' ), listener, removeType ) );

    } );

  } );

} );

describe( 'handleAnalytics test cases', () => {

  const res = {
    body:{
      data: {
        cartSummary: {
          estimatedTotal: 422.57,
          subTotal: 394,
          shippingCost: 'FREE',
          couponDiscount: 0,
          itemCount: 12
        },
        paymentInfo: {
          items: [{
            mount: 41.49,
            paymentType: 'giftCard',
            messages: {
              items: [{
                type: 'Info',
                message:'card applied successfully'
              }]
            }
          }]
        }
      }
    }
  };

  const analyticsListener = handleAnalytics( res );
  let data;
  it( 'should call dataLayerActions setDataLayer method', () => {
    data = {
      globalPageData: {
        messages: [res.body.data.paymentInfo.items[0].messages.items[0]],
        order: {
          total: ( res.body.data.cartSummary.estimatedTotal ).toFixed( 2 ),
          subtotal: ( res.body.data.cartSummary.subTotal ).toFixed( 2 ),
          shipping: ( res.body.data.cartSummary.shippingCost === 'FREE' ? res.body.data.cartSummary.shippingCost : ( res.body.data.cartSummary.shippingCost ).toFixed( 2 ) ),
          voucher_discount: res.body.data.cartSummary.couponDiscount
        }
      }
    };
    const evt = {
      name: 'trackApplyGiftCard'
    };
    const putDescriptor  = analyticsListener.next( res ).value;
    expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );

  } );

  it( 'should call dataLayerActions setDataLayer method with event serviceMessagesUpdated', () => {
    const evt = {
      name: 'serviceMessagesUpdated'
    };
    const putDescriptor  = analyticsListener.next( res ).value;
    expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );

  } );

  const res1 = {
    body:{
      data: {
        cartSummary: {
          estimatedTotal: 422.57,
          subTotal: 394,
          shippingCost: null,
          couponDiscount: 0,
          itemCount: 12
        },
        paymentInfo: {
          items: [{
            mount: 41.49,
            paymentType: 'giftCard',
            messages: {
              items: [{
                type: 'Info',
                message:'card applied successfully'
              }]
            }
          }]
        }
      }
    }
  };

  const analyticsListener1 = handleAnalytics( res1 );
  it( 'should call dataLayerActions setDataLayer method - order node in globalPageData will not have shipping parameter if order fulfillment type is pickup ( Shipping Cost null )', () => {
    data = {
      globalPageData: {
        messages: [res.body.data.paymentInfo.items[0].messages.items[0]],
        order: {
          total: ( res.body.data.cartSummary.estimatedTotal ).toFixed( 2 ),
          subtotal: ( res.body.data.cartSummary.subTotal ).toFixed( 2 ),
          voucher_discount: res.body.data.cartSummary.couponDiscount
        }
      }
    };
    const evt = {
      name: 'trackApplyGiftCard'
    };
    const putDescriptor  = analyticsListener1.next( ).value;
    expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );

  } );

  it( 'should call dataLayerActions setDataLayer method - payment Type is giftcard with success', () => {
    const res = {
      body:{
        data: {
          cartSummary: {
            estimatedTotal: 422.57,
            subTotal: 394,
            shippingCost: 'FREE',
            couponDiscount: 0,
            itemCount: 12
          },
          paymentInfo: {
            items: [{
              mount: 41.49,
              paymentType: 'giftCard',
              messages: null
            }]
          }
        }
      }
    };
    const data = {
      globalPageData: {
        messages: [],
        order: {
          total: ( res.body.data.cartSummary.estimatedTotal ).toFixed( 2 ),
          subtotal: ( res.body.data.cartSummary.subTotal ).toFixed( 2 ),
          shipping: ( res.body.data.cartSummary.shippingCost === 'FREE' ? res.body.data.cartSummary.shippingCost : ( res.body.data.cartSummary.shippingCost ).toFixed( 2 ) ),
          voucher_discount: res.body.data.cartSummary.couponDiscount
        }
      }
    };
    const evt = {
      name: 'trackApplyGiftCard'
    };
    const analyticsListener = handleAnalytics( res );
    const putDescriptor  = analyticsListener.next( ).value;
    expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
  } );
  it( 'should call dataLayerActions setDataLayer method - payment Type is giftcard with error', () => {
    const res = {
      body:{
        data: {
          cartSummary: {
            estimatedTotal: 422.57,
            subTotal: 394,
            shippingCost: 'FREE',
            couponDiscount: 0,
            itemCount: 12
          },
          paymentInfo: {
            items: [{
              mount: 41.49,
              paymentType: 'giftCard',
              messages: {
                items:[{
                  type: 'Error',
                  message:'card invalid'
                }]
              }
            }]
          }
        }
      }
    };
    const data = {
      globalPageData: {
        messages: [...res.body.data.paymentInfo.items[0].messages.items],
        order: {
          total: ( res.body.data.cartSummary.estimatedTotal ).toFixed( 2 ),
          subtotal: ( res.body.data.cartSummary.subTotal ).toFixed( 2 ),
          shipping: ( res.body.data.cartSummary.shippingCost === 'FREE' ? res.body.data.cartSummary.shippingCost : ( res.body.data.cartSummary.shippingCost ).toFixed( 2 ) ),
          voucher_discount: res.body.data.cartSummary.couponDiscount
        }
      }
    };
    const evt = {
      name: 'trackErrorDisplayed',
      data:{
        'errorType':'form',
        'errorLabel':'apply gift cart',
        'errorDescription': res.body.data.paymentInfo.items[0].messages.items[0].message
      }
    };
    const analyticsListener = handleAnalytics( res );
    const putDescriptor  = analyticsListener.next( ).value;
    expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
  } );

} );

describe( 'handleTokenization test cases', () => {
  registerServiceName( 'paymentsCCKey' );

  const values = {
    'creditCardNumber': '411111111111',
    'paymentType': 'creditCard',
    'creditCardType':'visa',
    'expirationMonth':'12',
    'expirationYear':'2018'
  };
  const switchData = {
    switches:{
      creditCardTokenForProduction:'1231231',
      creditCardTypeMapping:{
        visa:'CreditCard'
      }

    }
  }
  const tokenizationListener = cloneableGenerator( handleTokenization )( values, switchData );
  let tokenizationListenerClone1;
  let tokenizationListenerClone2;
  it( 'should put paymentsCCKey requested method', () => {
    expect( tokenizationListener.next().value ).toEqual( put( getActionDefinition( 'paymentsCCKey', 'requested' )() ) );
  } );

  it( 'should wait for paymentsCCKey success', () => {
    expect( tokenizationListener.next().value ).toEqual( take( getServiceType( 'paymentsCCKey', 'success' ) ) );
  } );

  it( 'should cancel saga execution if jwk not obtained', () => {
    tokenizationListenerClone1 = tokenizationListener.clone();
    expect( tokenizationListenerClone1.next( {} ).value ).toEqual( cancel() );
  } );

  it( 'should make a call to getTokenization', () => {
    const switchData = {
      switches:{
        creditCardTokenForProduction:'1231231',
        creditCardTypeMapping:{
          visa:'CreditCard'
        }

      }
    }

    const tokenizationParams = {
      paymentsCCToken:'123',
      cardInfoData : {
        cardNumber: '411111111111',
        cardType: 'CreditCard',
        expiryMonth: '12',
        expiryYear: '2018'
      },
      creditCardTokenForProduction: '1231231'

    }
    expect( tokenizationListener.next( { data : { jwk:'123' } } ).value ).toEqual( call( getTokenization, tokenizationParams ) );
  } );

  it( 'should cancel saga execution if cybertoken is not obtained', () => {
    tokenizationListenerClone2 = tokenizationListener.clone();
    const cyberCCToken = undefined;
    expect( tokenizationListenerClone2.next( cyberCCToken ).value ).toEqual( cancel() );
  } );

  it( 'should return the new values if  cyberCCToken is obtained', () => {
    const cyberCCToken = {
      maskedPan:'41111XXXXX1111',
      token:'1234'
    }

    const newValues = {
      'maskedPan': '41111XXXXX1111',
      'paymentType': 'creditCard',
      'creditCardType':'visa',
      'expirationMonth':'12',
      'expirationYear':'2018',
      'creditCardToken':'1234'
    };

    expect( tokenizationListener.next( cyberCCToken ).value ).toEqual( newValues );
  } );

} );
