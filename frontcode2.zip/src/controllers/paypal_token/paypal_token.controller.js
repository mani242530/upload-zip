/**
 * PaypalToken sagas
 */
import {
  takeEvery, call, put, select
} from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ajax
} from '../../utils/ajax/ajax';


// Individual exports for testing
export const listener = function*( type, data ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const res = yield call( ajax, { type } );


    yield put( getActionDefinition( type, 'success' )( res.body.data ) );

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }
}

export default function*(){
  let serviceType = 'paypalToken';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( 'paypalToken', 'requested' ), listener, serviceType );
}
