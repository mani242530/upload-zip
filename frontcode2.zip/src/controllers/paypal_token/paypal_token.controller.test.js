/**
 * PaypalToken  sagas
 */

import {
  takeEvery, call, put, select
} from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import Cookies from 'js-cookie';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  ajax
} from '../../utils/ajax/ajax';
import saga, { listener } from './paypal_token.controller';

const _dynSessConf = '12345';

describe( 'PaypalToken Saga', () => {
  const type = 'paypalToken';
  const res = {
    body: {
      data:'eyJ2ZXJzaW9uIjoyLCJhdXRob3J'
    }
  }

  let data = {
    '_dynSessConf': _dynSessConf
  }
  registerServiceName( type );

  describe( 'listener PaypalToken saga success path', () => {

    Cookies.set( 'ultaSession', _dynSessConf );
    const listenerSaga = listener( type, data );

    it( 'should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( ajax, { type } ) );

    } );

    it( 'should until the success event has been put', () => {

      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );
} );
