import {
  takeEvery, call, put, select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import isEqual from 'lodash/isEqual';
import has from 'lodash/has';
import get from 'lodash/get';
import { getUserState } from '../../models/view/user/user.model';
import {
  ajax
} from '../../utils/ajax/ajax';
import { getPickupInformation } from '../../models/view/bopis/bopis.model';
import { getCheckoutPageState } from '../../models/view/checkout_page/checkout_page.model';
let isPickupContactRequested = {
  type: ''
}

export const listener = function*( type, action ){

  try {
    // ensures that 2 PickupContactUpdate Request call is addressed simultaneously
    if( isPickupContactRequested.type === '' ){

      const pickupInformation = yield select( getPickupInformation );



      // Update contact Info (primary,alternate) update call should be triggered
      // if alternate contact form is edited compared to previous updated value or
      // for registered user, on click of save option, primaryContactInfo update service should be invoked irrespective of the value changes
      if( ( action.data.contactInfo.data.alternateContactInfo && action.data.isAlternatePickupPersonEnable && !isEqual( action.data.contactInfo.data.alternateContactInfo, pickupInformation.tempAlternatePickupPersonData ) ) ||
        action.data.contactInfo.data.primaryContactInfo ){


        isPickupContactRequested = yield put( getActionDefinition( type, 'loading' )( action.data.contactInfo ) );
        const res = yield call(
          ajax, {
            type,
            method:'post',
            values: action.data.contactInfo
          }
        );
        const UserData = yield select( getUserState );

        const {
          isSignedIn
        } = UserData;

        // isPrimaryContactInfoUpdated flag is used to differentiate between the alternate and primary contact info update call
        yield put( getActionDefinition( type, 'success' )( { result: res.body.data, isSignedIn: isSignedIn, isPrimaryContactInfoUpdated:!!get( action.data, 'contactInfo.data.primaryContactInfo' ) } ) );
        isPickupContactRequested.type = '';

        const checkoutData = yield select( getCheckoutPageState );

        // trigger afterpayToken service call only if result is Success, afterpayEligible and isTokenRequired are true
        // and isProfileCreditCardListView should be true (signed in user ) or paymentType should be afterpay( guest user )
        if( res.body.data.result === 'Success' && res.body.data?.afterpay?.afterpayEligible && res.body.data?.afterpay?.isTokenRequired &&
         ( checkoutData.isProfileCreditCardListView || checkoutData.paymentType === 'afterpay' ) ){
          yield put( getActionDefinition( 'afterpayToken', 'requested' )() );
        }
      }
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export const removeAlternateContactInfoListner = function*( type, action ){

  try {

    const pickupInformation = yield select( getPickupInformation );

    // alternate pickup person update call should be triggered
    // if request is triggered to delete it isAlternatePickupPersonEnable:false
    // and also if the alternate pickup person have been updated (tempAlternatePickupPersonData have firstname)
    if( !action.data.isAlternatePickupPersonEnable && get( pickupInformation, 'tempAlternatePickupPersonData.firstName' ) ){

      let contactInfo = {
        data:{
          alternateContactInfo:null
        }
      }
      yield put( getActionDefinition( type, 'loading' )( ) );
      const res = yield call(
        ajax, {
          type:'pickupContactInfoUpdate',
          method:'post',
          values: contactInfo
        }
      );
      const UserData = yield select( getUserState );

      const {
        isSignedIn
      } = UserData;

      // isPrimaryContactInfoUpdated flag is used to differentiate between the alternate and primary contact info update call
      yield put( getActionDefinition( 'pickupContactInfoUpdate', 'success' )( { result: res.body.data, isSignedIn: isSignedIn, isPrimaryContactInfoUpdated:false } ) );
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    console.error( err.message )// eslint-disable-line

  }
}

export default function*(){
  let serviceType = 'pickupContactInfoUpdate';
  let removeAlternateContactInfo = 'removeAlternateContactInfo';
  registerServiceName( serviceType );
  registerServiceName( removeAlternateContactInfo );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
  yield takeEvery( getServiceType( removeAlternateContactInfo, 'requested' ), removeAlternateContactInfoListner, removeAlternateContactInfo );
}
