
import {
  takeEvery, call, put, select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { cloneableGenerator } from 'redux-saga/lib/utils';
import { getUserState } from '../../models/view/user/user.model';
import {
  ajax
} from '../../utils/ajax/ajax';
import saga, { listener, removeAlternateContactInfoListner } from './pickup_contact_info.controller';
import { getPickupInformation } from '../../models/view/bopis/bopis.model';
import { getCheckoutPageState } from '../../models/view/checkout_page/checkout_page.model';

const type = 'pickupContactInfoUpdate';

describe( 'pickupContactInfoUpdate Saga', () => {
  const pickupContactInfoUpdateSaga = saga();
  registerServiceName( type );
  registerServiceName( 'afterpayToken' );

  it( 'should listen for the pickupContactInfoUpdate requested method', () =>{
    const takeEveryDescriptor = pickupContactInfoUpdateSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), listener, type ) );
  } );

  describe( 'listener saga success/failure path if action data has primaryContactInfo', () => {
    let action = {
      data: {
        contactInfo:{
          data:{
            'primaryContactInfo': {
              'firstName': 'Teenu',
              'lastName': 'Jacob',
              'phoneNumber': '1234567876',
              'email': 'teenu.jacob@ulta.com'
            }
          }
        }
      }
    }
    const listenerSaga = cloneableGenerator( listener )( type, action );
    let listenerSaga1;
    let listenerSaga2;
    let listenerSaga3;
    let listenerSaga4;
    let listenerSaga5;

    it( 'should call select getPickupInformation', () => {
      const pickupInformation = {
        isDisplayPickupContactForm: true,
        isDisplayAlternatePickupPersonForm: false,
        tempPickupContactInfoData: {},
        tempAlternatePickupPersonData: {}
      };
      const selectDescriptor  = listenerSaga.next( pickupInformation ).value;
      expect( selectDescriptor ).toEqual( select( getPickupInformation ) );
    } );

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( action.data.contactInfo ) ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {
      let isPickupContactRequested = {
        type: ''
      }
      const callDescriptor  = listenerSaga.next( isPickupContactRequested ).value;
      listenerSaga3 = listenerSaga.clone();
      listenerSaga4 = listenerSaga.clone();
      listenerSaga5 = listenerSaga.clone();
      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values: action.data.contactInfo } ) );
    } );

    it( 'should call select getUserState', () => {
      const res = {
        body:{
          data: {
            result: 'Success',
            afterpay: {
              afterpayEligible: true,
              isTokenRequired: true
            }
          }
        }
      };
      const selectDescriptor  = listenerSaga.next( res ).value;
      expect( selectDescriptor ).toEqual( select( getUserState ) );
    } );

    it( 'should put a success event after data is called with primaryContactInfo as true ', () => {
      const UserData = {
        isSignedIn: true
      };
      const data = {
        'isSignedIn': true,
        'isPrimaryContactInfoUpdated': true,
        result: {
          result: 'Success',
          afterpay: {
            afterpayEligible: true,
            isTokenRequired: true
          }
        }
      }

      const putDescriptor = listenerSaga.next( UserData ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( data ) ) );
    } );

    it( 'should select getCheckoutPageState method', () => {
      const selectDescriptor = listenerSaga.next().value;
      listenerSaga1 = listenerSaga.clone();
      listenerSaga2 = listenerSaga.clone();
      expect( selectDescriptor ).toEqual( select( getCheckoutPageState ) );
    } );

    it( 'should put afterpayToken requested if the paymentType is afterpay and isTokenRequired is true and  if the view is not tab view for payment types', () => {
      const checkoutData = {
        isProfileCreditCardListView: true,
        paymentType: 'afterpay'
      }
      const putDescriptor = listenerSaga.next( checkoutData ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
    } );

    it( 'should not put afterpayToken requested if isProfileCreditCardListView is false', () => {
      const checkoutData = {
        isProfileCreditCardListView: false
      }
      const putDescriptor = listenerSaga1.next( checkoutData );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should not put afterpayToken requested if paymentType is not afterpay', () => {
      const checkoutData = {
        paymentType: 'creditCard'
      }
      const putDescriptor = listenerSaga2.next( checkoutData );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should not put afterpayToken requested if res.body.data.result is not success', () => {
      const res = {
        body:{
          data: {
            result: 'Failure',
            afterpay: {
              afterpayEligible: true,
              isTokenRequired: true
            }
          }
        }
      };
      const checkoutData = {
        isProfileCreditCardListView: true,
        paymentType: 'afterpay'
      }
      const UserData = {
        isSignedIn: true
      };
      listenerSaga3.next( res ); // this is select getUserState
      listenerSaga3.next( UserData ); // this is success event
      listenerSaga3.next( ); // this is getCheckoutPageState method
      const putDescriptor = listenerSaga3.next( checkoutData );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should not put afterpayToken requested if afterpayEligible is false', () => {
      const res = {
        body:{
          data: {
            result: 'Success',
            afterpay: {
              afterpayEligible: false,
              isTokenRequired: true
            }
          }
        }
      };
      const checkoutData = {
        isProfileCreditCardListView: true,
        paymentType: 'afterpay'
      }
      const UserData = {
        isSignedIn: true
      };
      listenerSaga4.next( res ); // this is select getUserState
      listenerSaga4.next( UserData ); // this is success event
      listenerSaga4.next( ); // this is getCheckoutPageState method
      const putDescriptor = listenerSaga4.next( checkoutData );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should not put afterpayToken requested if isTokenRequired is false', () => {
      const res = {
        body:{
          data: {
            result: 'Success',
            afterpay: {
              afterpayEligible: true,
              isTokenRequired: false
            }
          }
        }
      };
      const checkoutData = {
        isProfileCreditCardListView: true,
        paymentType: 'afterpay'
      }
      const UserData = {
        isSignedIn: true
      };
      listenerSaga5.next( res ); // this is select getUserState
      listenerSaga5.next( UserData ); // this is success event
      listenerSaga5.next( ); // this is getCheckoutPageState method
      const putDescriptor = listenerSaga5.next( checkoutData );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );
  } );

  describe( 'listener saga success/failure path if action data has alternateContactInfo', () => {
    let action = {
      data: {
        contactInfo:{
          data:{
            'alternateContactInfo': {
              'firstName': 'Jane',
              'lastName': 'Doe',
              'email': 'test@ulta.com'
            }
          }
        },
        isAlternatePickupPersonEnable:true
      }
    }
    const listenerSaga = listener( type, action );

    it( 'should call select getPickupInformation', () => {
      const selectDescriptor  = listenerSaga.next( ).value;
      expect( selectDescriptor ).toEqual( select( getPickupInformation ) );
    } );

    it( 'should should until the loading event has been put if tempAlternatePickupPersonData not equals to alternateContactInfo', () => {
      const pickupInformation = {
        isDisplayPickupContactForm: true,
        isDisplayAlternatePickupPersonForm: false,
        tempPickupContactInfoData: {},
        tempAlternatePickupPersonData: {}
      };
      const putDescriptor = listenerSaga.next( pickupInformation ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( action.data.contactInfo ) ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {
      let isPickupContactRequested = {
        type: ''
      }
      const callDescriptor  = listenerSaga.next( isPickupContactRequested ).value;
      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post', values: action.data.contactInfo } ) );
    } );

    const listenerSaga1 = listener( type, action );
    it( 'should not trigger loading event unless success event happens', () => {
      const putDescriptor1 = listenerSaga1.next().value;
      expect( putDescriptor1 ).not.toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should call select getUserState', () => {
      const res = {
        body:{
          data: {
            title: 'test',
            status: 'ok'
          }
        }
      };
      const selectDescriptor  = listenerSaga.next( res ).value;
      expect( selectDescriptor ).toEqual( select( getUserState ) );
    } );

    it( 'should put a success event after data is called', () => {
      const UserData = {
        isSignedIn: true
      };
      const data = {
        'isSignedIn': true,
        'result': {
          'status': 'ok',
          'title': 'test'
        },
        'isPrimaryContactInfoUpdated': false
      }

      const putDescriptor = listenerSaga.next( UserData ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( data ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );
  } );

  describe( 'removeAlternateContactInfoListner saga success/failure path if action data has alternateContactInfo as null', () => {
    let action = {
      data: {
        isAlternatePickupPersonEnable:false
      }
    }
    let type = 'removeAlternateContactInfo';
    const listenerSaga = removeAlternateContactInfoListner( type, action );

    it( 'should call select getPickupInformation', () => {
      const selectDescriptor  = listenerSaga.next( ).value;
      expect( selectDescriptor ).toEqual( select( getPickupInformation ) );
    } );

    it( 'should should until the loading event has been put if tempAlternatePickupPersonData not equals to alternateContactInfo', () => {
      const pickupInformation = {
        isDisplayPickupContactForm: true,
        isDisplayAlternatePickupPersonForm: false,
        tempPickupContactInfoData: {},
        tempAlternatePickupPersonData: {
          'firstName':test
        }
      };
      const putDescriptor = listenerSaga.next( pickupInformation ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( action.data.contactInfo ) ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {
      const callDescriptor  = listenerSaga.next().value;
      let contactInfo = {
        data:{
          alternateContactInfo:null
        }
      }
      expect( callDescriptor ).toEqual( call( ajax, { type:'pickupContactInfoUpdate', method: 'post', values: contactInfo } ) );
    } );

    const listenerSaga1 = listener( type, action );
    it( 'should not trigger loading event unless success event happens', () => {
      const putDescriptor1 = listenerSaga1.next().value;
      expect( putDescriptor1 ).not.toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should call select getUserState', () => {
      const res = {
        body:{
          data: {
            title: 'test',
            status: 'ok'
          }
        }
      };
      const selectDescriptor  = listenerSaga.next( res ).value;
      expect( selectDescriptor ).toEqual( select( getUserState ) );
    } );

    it( 'should put a success event after data is called', () => {
      const UserData = {
        isSignedIn: false
      };
      const data = {
        'isSignedIn': false,
        'result': {
          'status': 'ok',
          'title': 'test'
        },
        'isPrimaryContactInfoUpdated': false
      }

      const putDescriptor = listenerSaga.next( UserData ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( 'pickupContactInfoUpdate', 'success' )( data ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );
  } );
} );
