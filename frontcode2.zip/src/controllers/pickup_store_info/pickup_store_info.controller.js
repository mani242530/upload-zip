import { takeEvery, call, put } from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType,
  checkoutRedirectListener
} from 'ulta-fed-core/dist/js/events/services/services.events';

import get from 'lodash/get';
import reduxFormActions from 'redux-form/lib/actions';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  ajax
} from '../../utils/ajax/ajax';
import { setDeliveryOptions } from '../../events/bopis/bopis.events';
import appConstants from '../../shared/appConstants';


export const listener = function*( type, action ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const { storeId } = action.data;

    const res = yield call(
      ajax, {
        type,
        method:'post',
        query: { storeId }
      }
    );

    // Check if store is available for pickup by looking for Errors in messages.items
    const storeAvailable = !get( res.body.data, 'messages.items', [] )
      .some( ( item ) => ( item.type === 'Error' ) );

    // deselect RadioButton active on changeStoreModal form if store is not available
    // and it should select the radio button which was previously selected
    if( !storeAvailable ){
      yield put( reduxFormActions.change( 'changeStoreModalForm', 'selectStore', action.data.prevSelectedStore ) );
    }
    if( res.body.data ){
      yield put( getActionDefinition( type, 'success' )( {
        cartResponse: res.body.data,
        storeAvailable,
        storeId
      } ) );

      // moving the analytics code below for better readability
      if( analyticsEvt( storeAvailable, action, storeId ) ){
        yield put( triggerAnalyticsEvent( analyticsEvt( storeAvailable, action, storeId ) ) );
      }

      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( checkoutRedirectListener( action.data.history, qty, loadCartMessages ) );

      // select the 'Pickup in Store' radio button when a store is chosen
      yield put( setDeliveryOptions( 'pickup' ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
};

export default function*(){
  let serviceType = 'pickupStoreInfoUpdate';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( 'pickupStoreInfoUpdate', 'requested' ), listener, serviceType );
}

function analyticsEvt( storeAvailable, action, storeId ){
  if( !storeAvailable ){
    /* Trigger Analytics event when user selects a different store in the Change Store modal and is presented with a Not Available for Pickup message */
    return {
      'name': appConstants.ANALYTICS.BOPIS_CHANGE_STORE_NOT_AVAILABLE,
      'data': {
        storeId
      }
    }
  }
}
