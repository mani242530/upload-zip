import { takeEvery, call, put } from 'redux-saga/effects';
import { change } from 'redux-form';


import {
  registerServiceName,
  getServiceType,
  getActionDefinition,
  checkoutRedirectListener
} from 'ulta-fed-core/dist/js/events/services/services.events';


import { cloneableGenerator } from 'redux-saga/utils';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  ajax
} from '../../utils/ajax/ajax';
import saga, { listener } from './pickup_store_info.controller';

import { setDeliveryOptions } from '../../events/bopis/bopis.events'

const type = 'pickupStoreInfoUpdate';
const resetLatLongType = 'resetLatLong';

describe( 'PickupStoresInfoUpdate Saga', () => {
  registerServiceName( type );

  describe( 'default saga', () => {
    const pickupStoreInfoUpdateSaga = saga();

    it( 'should listen for the pickup store info request method', () => {
      const takeEveryDescriptor = pickupStoreInfoUpdateSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), listener, type )
      );
    } );
  } );

  describe( 'listener saga', () => {
    registerServiceName( resetLatLongType );

    const action = {
      data: { storeId: '68', prevSelectedStore:'289' }
    };

    const storeAvailableListenerSaga = cloneableGenerator( listener )( type, action );
    const storeUnavailableListenerSaga = cloneableGenerator( listener )( type, action );
    let storeAvailableListenerSagaClone;
    let storeUnavailableListenerSagaClone;

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = storeAvailableListenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should call pickupStoreInfoUpdate API', () => {
      const res = {
        type,
        method: 'post',
        query: {
          storeId: action.data.storeId
        }
      };
      const callDescriptor = storeAvailableListenerSaga.next( ).value;

      expect( callDescriptor ).toEqual( call( ajax, res ) );
    } );

    describe( 'pickup store available path', () => {

      it( 'should put a success event after pickupStoreInfoUpdate request data is called ', () => {
        const ajaxResponse = {
          body: {
            data: {
              test: 'test',
              cartSummary: {
                itemCount: 0
              },
              messages: { test: 'test' }
            }
          }
        };
        const dispatchValue = {
          cartResponse: {
            test: 'test',
            cartSummary: {
              itemCount: 0
            },
            messages: { test: 'test' }
          },
          storeAvailable: true,
          storeId: action.data.storeId
        };
        const putDescriptor = storeAvailableListenerSaga.next( ajaxResponse ).value;
        storeAvailableListenerSagaClone = storeAvailableListenerSaga.clone();

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( dispatchValue ) ) );
      } );

      it( 'should not trigger analytics event bopisChangeStoreNotAvailable after pickupStoreInfoUpdate success when store is available', () => {
        const evt = {
          'name': 'bopisChangeStoreNotAvailable',
          'data': {
            'storeId' : action.data.storeId
          }
        }
        const putDescriptor = storeAvailableListenerSagaClone.next( ).value;
        expect( putDescriptor ).not.toEqual( put( triggerAnalyticsEvent( evt ) ) );
      } );


      it( 'should put a checkoutRedirectListener event if item count is 0 ', () => {

        const putDescriptor = storeAvailableListenerSaga.next( ).value;

        expect( putDescriptor ).toEqual( put( checkoutRedirectListener( action.data.history, 0, { test: 'test' } ) ) );
      } );
    } );

    describe( 'pickup store unavailable path', () => {
      it( 'should deselect the selected radio button if store is unavailable and select the previously selected option', () => {
        const ajaxResponse = {
          body: {
            data: {
              messages: {
                items: [{ type: 'Error', message: 'error message 1' }]
              },
              cartSummary: {
                itemCount: 0
              }
            }
          }
        };

        storeUnavailableListenerSaga.next( );
        storeUnavailableListenerSaga.next( );

        const putDescriptor = storeUnavailableListenerSaga.next( ajaxResponse ).value;

        expect( putDescriptor ).toEqual( put( change( 'changeStoreModalForm', 'selectStore', action.data.prevSelectedStore ) ) );
      } );

      it( 'should put a success event after pickupStoreInfoUpdate request data is called ', () => {
        const dispatchValue = {
          cartResponse: {
            messages: {
              items: [{ type: 'Error', message: 'error message 1' }]
            },
            cartSummary: {
              itemCount: 0
            }
          },
          storeAvailable: false,
          storeId: action.data.storeId
        };
        const putDescriptor = storeUnavailableListenerSaga.next( ).value;
        storeUnavailableListenerSagaClone = storeUnavailableListenerSaga.clone();

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( dispatchValue ) ) );
      } );

      it( 'should trigger analytics event bopisChangeStoreNotAvailable after pickupStoreInfoUpdate success when store is unavailable', () => {
        const evt = {
          'name': 'bopisChangeStoreNotAvailable',
          'data': {
            'storeId' : action.data.storeId
          }
        }
        const putDescriptor = storeUnavailableListenerSaga.next( ).value;

        expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
      } );

      it( 'should put a checkoutRedirectListener event after analytics event bopisChangeStoreNotAvailable when store is unavailable', () => {
        const loadCartMessages = {
          items: [{ type: 'Error', message: 'error message 1' }]
        }
        const putDescriptor = storeUnavailableListenerSaga.next( ).value;
        expect( putDescriptor ).toEqual( put( checkoutRedirectListener( action.data.history, 0, loadCartMessages ) ) );
      } );
    } );
    describe( 'pickup store available path with selected store same as previously selected store', () => {

      const action = {
        data: { storeId: '68', prevSelectedStore:'68', history: '/bag' }
      };

      const ajaxResponse = {
        body: {
          data: {
            test: 'test',
            cartSummary: {
              itemCount: 0
            },
            messages: { test: 'test' }
          }
        }
      };

      const listenerSaga = listener( type, action );
      listenerSaga.next(); // pickupStoreInfoUpdate loading event
      listenerSaga.next(); // pickupStoreInfoUpdate ajax call
      listenerSaga.next( ajaxResponse ); // pickupStoreInfoUpdate success event

    } );

    describe( 'failure path', () => {
      const err = {
        statusText:'some failure message'
      };

      it( 'should put a failure event if no data is returned from the service', () => {
        const putDescriptor = storeAvailableListenerSaga.throw( err ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );
    } );
  } );
  describe( 'listener saga - success path, prevSelectedStore selected store is not passed in action', () => {
    registerServiceName( resetLatLongType );

    const action = {
      data: { storeId: '68', prevSelectedStore:'' }
    };

    const storeAvailableListenerSaga = listener( type, action );


    it( 'should trigger setDeliveryOptions, to set delivery option as pickup', () => {
      storeAvailableListenerSaga.next( ); // loading event
      storeAvailableListenerSaga.next( ); // call pickupStoreInfoUpdate API
      const ajaxResponse = {
        body: {
          data: {
            test: 'test',
            cartSummary: {
              itemCount: 0
            },
            messages: { test: 'test' }
          }
        }
      };
      storeAvailableListenerSaga.next( ajaxResponse ) // success event after pickupStoreInfoUpdate
      storeAvailableListenerSaga.next( ) // trigger analytics event bopisChangeStoreNotAvailable
      const putDescriptor = storeAvailableListenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( setDeliveryOptions( 'pickup' ) ) );
    } );

  } );

} );
