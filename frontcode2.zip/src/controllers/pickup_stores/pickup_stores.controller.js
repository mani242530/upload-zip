/**
 * PickupStores saga : Uses mapbox api OR navigator location to detect
 * LatLong and serves stores with pickup available based on distance
 */
import {
  takeEvery, take, call, put
} from 'redux-saga/effects';
import isEmpty from 'lodash/isEmpty';
import {
  types,
  actions,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';

import reduxFormActions from 'redux-form/lib/actions';
import {
  ajax
} from '../../utils/ajax/ajax';
import { getGeoLocation } from '../../utils/geo_location/geo_location';
import appConstants from '../../shared/appConstants';

export const pickupStoresListener = function*( type, action ){
  try {
    const { searchValue, store, disableTimeout } = action.data;
    yield put( getActionDefinition( type, 'loading' )( { searchValue } ) );
    let pickupStoresData;
    let isStoresDataEmpty = false;
    let realTimeDataAvailable = false;
    let locationData = null;

    if( !action.data.searchValue ){
      yield put( getActionDefinition( 'latLong', 'requested' )( { searchValue, disableTimeout } ) );
      // Resolving co-ordinates
      locationData = yield take( getServiceType( 'latLong', 'success' ) );
    }

    if( locationData?.data || action.data.searchValue ){
      /* Retrieving stores based on co-ordinates from LatLong*/
      const res = yield call(
        ajax, {
          type,
          method:'get',
          query: {
            ...( locationData?.data &&
             {
               latitude : locationData.data.latitude,
               longitude : locationData.data.longitude
             } ),
            geoLocationOverride: !!action.data.searchValue,
            ...( action.data.searchValue && { searchString:action.data.searchValue } )
          }
        }
      );

      isStoresDataEmpty = isEmpty( res.body.data.pickupEnabledStores );
      realTimeDataAvailable = res.body.data.realTimeDataAvailable;
      // return only the first 20 results
      pickupStoresData = res.body.data.pickupEnabledStores?.items?.slice( 0, 20 );

      // setting disableStore to true if the store is selected and not available
      pickupStoresData = pickupStoresData?.map( ( store ) => {
        return {
          ...store,
          disableStore: store.selected && !store.available
        }
      } )
    }

    yield put( getActionDefinition( type, 'success' )( { pickupStoresData, isStoresDataEmpty, realTimeDataAvailable } ) );

    if( pickupStoresData ){
      // filtering pickupStoresData based on availabilityStatus
      const allItemsAvailable = pickupStoresData.filter( store => store.itemAvailability.status === 'completelyAvailable' );
      const noItemsAvailable = pickupStoresData.filter( store => store.itemAvailability.status === 'notAvailable' );
      const limitedItemsAvailable = pickupStoresData.filter( store => store.itemAvailability.status === 'partiallyAvailable' );
      let evt = {
        'name': appConstants.ANALYTICS.BOPIS_SELECT_STORE_PICKUP_AVAILABILITY,
        'data': {
          'allItemsAvailable': allItemsAvailable.length,
          'limitedItemsAvailable': limitedItemsAvailable.length,
          'noItemsAvailable': noItemsAvailable.length
        }
      }
      // fire analytic event with data corresponding to number of store with availability status of items.
      yield put( triggerAnalyticsEvent( evt ) );
    }

    // set the selected store RadioButton active on changeStoreModal form to mark auto selected store
    if( store ){
      yield put( reduxFormActions.change( 'changeStoreModalForm', 'selectStore', store.storeId ) );
    }
    // set the search field to empty if the user uses geo-locate option
    if( !searchValue ){
      yield put( reduxFormActions.change( 'changeStoreModalForm', 'searchField', '' ) );
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
};

export default function*(){
  let serviceType = 'pickupStores';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( 'pickupStores', 'requested' ), pickupStoresListener, serviceType );
}
