import {
  takeEvery, take, call, put
} from 'redux-saga/effects';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { change } from 'redux-form';
import {
  ajax
} from '../../utils/ajax/ajax';
import appConstants from '../../shared/appConstants';
import saga, { pickupStoresListener } from './pickup_stores.controller';

const type = 'pickupStores';

describe( 'PickupStores Saga', () => {
  const pickupStoresSaga = saga();
  const latLong = {
    data: {
      latitude:  121,
      longitude: 123,
      geoLocationOverride: false
    }
  };
  const res = {
    body: {
      data: {
        pickupEnabledStores: {
          items: Array.from( { length: 50 }, ( val, idx ) => ( {
            item: idx,
            selected: idx === 0,
            available: idx !== 0,
            itemAvailability:{
              status:'completelyAvailable'
            }
          } ) )
        },
        realTimeDataAvailable:true
      }
    }
  };
  registerServiceName( type );

  describe( 'default saga', () => {

    it( 'should take every pickupStores request', () => {
      const takeEveryDescriptor = pickupStoresSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), pickupStoresListener, type )
      );
    } );
  } );

  describe( 'pickupStoresListener saga success/failure path, searchValue is null', () => {
    registerServiceName( 'latLong' );

    const action = {
      data: {
        searchValue:null,
        store: { storeId: 'testId' },
        disableTimeout:true,
        itemAvailability: {
          status: 'notAvailable'
        }
      }
    };
    const listenerSaga = pickupStoresListener( type, action );
    const invalidPathListenerSaga = pickupStoresListener( type, action );
    const geoLocatePathListenerSaga = pickupStoresListener( type, { data: { store: { storeId: 'testId' } } } );

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { searchValue: null } ) ) );
    } );

    it( 'should put a latLong request event', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'latLong', 'requested' )( {
        searchValue: action.data.searchValue,
        disableTimeout: action.data.disableTimeout
      } ) ) );
    } );

    it( 'should take a latLong success event after latLong request data is called ', () => {
      const serviceType = listenerSaga.next( ).value;
      expect( serviceType ).toEqual( take( getServiceType( 'latLong', 'success' ) ) );
    } );

    it( 'should call pickupStores', () => {
      const callDescriptor = listenerSaga.next( latLong ).value;

      expect( callDescriptor ).toEqual( call( ajax, { type, method:'get', query: latLong.data } ) );
    } );

    it( 'should put a success event after pickupStores request data is called ', () => {
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )(
        {
          'isStoresDataEmpty':false,
          'realTimeDataAvailable':res.body.data.realTimeDataAvailable,
          'pickupStoresData':
        Array.from( { length: 20 }, ( val, idx ) => ( {
          item: idx,
          selected: idx === 0,
          available: idx !== 0,
          disableStore: idx === 0,
          itemAvailability:{
            status:'completelyAvailable'
          }
        } ) )
        }
      ) ) );
    } );

    it( 'should trigger triggerAnalyticsEvent if pickupStoresData is not null', () => {

      const putDescriptor = listenerSaga.next( ).value;
      const evt = {
        'name': appConstants.ANALYTICS.BOPIS_SELECT_STORE_PICKUP_AVAILABILITY,
        'data': {
          'allItemsAvailable': 20,
          'limitedItemsAvailable': 0,
          'noItemsAvailable': 0
        }
      };
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );

    it( 'should put a redux-form change on ( form: changeStoreModalForm, field: selectStore )', () => {

      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( change( 'changeStoreModalForm', 'selectStore', action.data.store.storeId ) ) );
    } );

    describe( 'geo locate path', () => {
      it( 'should wait until the loading event has been put', () => {
        const putDescriptor = geoLocatePathListenerSaga.next().value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { searchValue: undefined } ) ) );
      } );

      it( 'should reset changeStoreModalForm searchField if geo locate is used', () => {
        geoLocatePathListenerSaga.next( );
        geoLocatePathListenerSaga.next( );
        geoLocatePathListenerSaga.next( res );
        geoLocatePathListenerSaga.next( );
        const putDescriptor = geoLocatePathListenerSaga.next( ).value;

        expect( putDescriptor ).toEqual( put( change( 'changeStoreModalForm', 'searchField', '' ) ) );
      } );
    } );

    describe( 'invalid search path', () => {
      it( 'should put undefined if searchValue is not a valid city/state or zipcode', () => {
        invalidPathListenerSaga.next( );
        invalidPathListenerSaga.next( );
        invalidPathListenerSaga.next( );
        const putDescriptor = invalidPathListenerSaga.next( { locationData: { data: undefined } } ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { isStoresDataEmpty:false, realTimeDataAvailable:false, pickupStoresData:undefined } ) ) );
      } );
    } );

    describe( 'No stores are present for a valid city/state or zipcode', () => {
      const invalidPathListenerSaga1 = pickupStoresListener( type, action );
      it( 'should put pickupStoresData as undefined and isStoresDataEmpty as true if no stores retuned for a valid city/state or zipcode', () => {
        invalidPathListenerSaga1.next( ); // loading
        invalidPathListenerSaga1.next( ); // latLong requested
        invalidPathListenerSaga1.next( ); // latLong success event triggered
        invalidPathListenerSaga1.next( latLong ); // call pickupStores
        const res = {
          body:{
            data:{
              pickupEnabledStores:{}
            }
          }
        }
        const putDescriptor = invalidPathListenerSaga1.next( res ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { isStoresDataEmpty:true, pickupStoresData:undefined } ) ) );
      } );
      it( 'should put a redux-form change on ( form: changeStoreModalForm, field: selectStore ) and  not trigger triggerAnalyticsEvent event if pickupStoresData is undefined', () => {

        const putDescriptor = invalidPathListenerSaga1.next( ).value;
        expect( putDescriptor ).toEqual( put( change( 'changeStoreModalForm', 'selectStore', 'testId' ) ) );
      } );
    } );

    describe( 'failure path', () => {
      it( 'should put a failure event if an error occurred', () => {
        const err = {
          statusText:'some failure message'
        };
        const putDescriptor = listenerSaga.throw( err ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );
    } );
  } );

  describe( 'pickupStoresListener saga success path, searchValue is not null', () => {

    const action = {
      data: {
        searchValue:'newyork',
        store: { storeId: 'testId' },
        disableTimeout:true
      }
    };
    const listenerSaga = pickupStoresListener( type, action );

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { searchValue: 'newyork' } ) ) );
    } );

    it( 'should call pickupStores passing searchString and geoLocationOverride as parameter', () => {
      const callDescriptor = listenerSaga.next( ).value;

      expect( callDescriptor ).toEqual( call( ajax, {
        type,
        method:'get',
        query:{
          geoLocationOverride:true,
          searchString:'newyork'
        }
      } ) );
    } );


  } );

} );
