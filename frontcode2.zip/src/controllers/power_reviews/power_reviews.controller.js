import {
  takeEvery, select, call, put
} from 'redux-saga/effects';
import { eventChannel, END } from 'redux-saga';


import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  EMITTING_FEEDLESS_PRODUCT
} from '../../events/power_reviews/power_reviews.events';
import {
  enablePowerReviewReadyFlag
} from '../../events/product_detail/product_detail.events';

export const checkForPowerReviewScript = function* ( action ){
  const switchData  = yield select( makeGetSwitchesData() );
  const switches = switchData.switches;
  const productDetails = action.productDetails;
  //
  const powerReviewLoadingStatusChannel = yield call( watchPowerReviewLoading );
  // It subscribe the emitter channel , so when flag is received as true ,
  // then it continue tit operation
  yield takeEvery( powerReviewLoadingStatusChannel, emittingFeedlessProductScript, switches, productDetails );
}

export const emittingFeedlessProductScript =  function* ( switches, productDetails ){
  // it updates displayReviews state of the product_page.model.js to indicates the successfull loading of power review.
  yield put( enablePowerReviewReadyFlag() );

  // if there is product data call powerreviews with that data
  if( productDetails ){
    // emitt power review feedless product
    yield call( global.POWERREVIEWS.display.render, {
      api_key: `${ switches.powerReviewsAPIKey }`,
      locale: 'en_US',
      merchant_group_id: `${ switches.powerReviewsMerchantGroupId }`,
      merchant_id: `${ switches.powerReviewsMerchantId }`,
      page_id: `${ productDetails.product.id }`,
      review_wrapper_url: `//${ switches.siteHttpServerName }/ui/pdp/review/?pr_page_id=${ productDetails.product.id }&pr_source=web`,
      product:{
        name:`${ productDetails.product.displayName }`,
        url:`${ productDetails.product.actionUrl }`,
        image_url:`${ productDetails.sku.images.largeImage }`,
        description:`${ productDetails.sku.description }`,
        category_name:`${ productDetails.breadCrumbNames }`,
        manufacturer_id:`${ productDetails.sku.manufacturerId }`,
        upc:`${ productDetails.sku.UPC }`,
        brand_name:`${ productDetails.brand.brandName }`,
        price:`${ productDetails.sku.price?.listPrice?.amount.toFixed( 2 ) || '' }`,
        in_stock:''
      }
    } );
  }

}
// This channel emit flag as true only when power review script is loaded completely.
export const watchPowerReviewLoading = () => {
  return eventChannel( emitter => {
    const iv = setInterval( () => {
      // power script is loaded , it emit flag to the event channel .
      if( global.POWERREVIEWS ){
        // emit flag to the subscribing channel .
        emitter( true )
        // Stop the emiiter channel
        emitter( END )
      }
    }, 100 );
    // The subscriber must return an unsubscribe function
    return () => {
      clearInterval( iv )
    }
  } )
}

export default function*(){
  yield takeEvery( EMITTING_FEEDLESS_PRODUCT, checkForPowerReviewScript );
}
