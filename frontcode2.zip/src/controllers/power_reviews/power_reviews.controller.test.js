import {
  takeEvery, select, call, put
} from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/lib/utils';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  EMITTING_FEEDLESS_PRODUCT
} from '../../events/power_reviews/power_reviews.events';
import saga, { checkForPowerReviewScript, watchPowerReviewLoading, emittingFeedlessProductScript } from './power_reviews.controller';

import {
  enablePowerReviewReadyFlag
} from '../../events/product_detail/product_detail.events';
describe( 'Power Review Saga', () => {
  const powerReviewSaga = saga();

  it( 'should listen for EMITTING_FEEDLESS_PRODUCT action', () => {

    const takeEveryDescriptor = powerReviewSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( EMITTING_FEEDLESS_PRODUCT, checkForPowerReviewScript ) );
  } );

} )
describe( 'Check for power review script load', () => {
  var action = {
    productDetails : {
      product:{
        id:'xlsImp20900008',
        displayName:'All Bright Cleansing Foam Wash',
        actionUrl:'https://qa1.ulta.com/all-bright-cleansing-foam-wash?productId=xlsImpprod15381019'
      },
      sku:{
        id:'1234',
        images:{
          largeImage:'https://images.ulta.com/is/image/Ulta/2502161?$lg$'
        },
        price:{
          listPrice:{
            amount:24
          }
        },
        manufacturerId:'xlsImp20900008',
        UPC:'5000167227673',
        description:'Botanics All Bright Cleansing Foam Wash is a foaming, soap-free face wash'
      },
      brand:{
        brandName:'Botanics'
      },
      breadCrumbNames:'Home >Skin Care >Cleansers >All Bright Cleansing Foam Wash'
    }
  }
  const switchData = {
    switches : {
      powerReviewsAPIKey:'daa0f241-c242-4483-afb7-4449942d1a2b',
      powerReviewsMerchantGroupId:'11984',
      powerReviewsMerchantId:'6406',
      siteHttpServerName:'da3.ulta.com'
    }
  }
  const listenerSaga = cloneableGenerator( checkForPowerReviewScript )( action );

  it( 'should do a select on makeGetSwitchesData', () => {
    const selectDescriptor = listenerSaga.next().value;
    expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
  } );
  it( 'should call powerReviewLoadingStatusChannel', () => {
    const callDescriptor = listenerSaga.next( switchData ).value;
    expect( callDescriptor ).toEqual( call( watchPowerReviewLoading ) ) ;
  } );
  it( 'should subscribe for POWER REVIEW EVENT CHANNEL ', () => {
    const takeEveryDescriptor = listenerSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( undefined, emittingFeedlessProductScript, switchData.switches, action.productDetails ) );
  } );
} )

describe( 'emit feedless product ', () => {
  var
      productDetails = {
        product:{
          id:'xlsImp20900008',
          displayName:'All Bright Cleansing Foam Wash',
          actionUrl:'https://qa1.ulta.com/all-bright-cleansing-foam-wash?productId=xlsImpprod15381019'
        },
        sku:{
          id:'1234',
          images:{
            largeImage:'https://images.ulta.com/is/image/Ulta/2502161?$lg$'
          },
          price:{
            listPrice:{
              amount:24
            }
          },
          manufacturerId:'xlsImp20900008',
          UPC:'5000167227673',
          description:'Botanics All Bright Cleansing Foam Wash is a foaming, soap-free face wash'
        },
        brand:{
          brandName:'Botanics'
        },
        breadCrumbNames:'Home >Skin Care >Cleansers >All Bright Cleansing Foam Wash'
      };
  const switches = {
    powerReviewsAPIKey:'daa0f241-c242-4483-afb7-4449942d1a2b',
    powerReviewsMerchantGroupId:'11984',
    powerReviewsMerchantId:'6406',
    siteHttpServerName:'da3.ulta.com'
  }
  const listenerSagaForScript = cloneableGenerator( emittingFeedlessProductScript )( switches, productDetails );

  it( 'should do a put against product page data layer', () => {
    const putDescriptor = listenerSagaForScript.next( ).value;
    expect( putDescriptor ).toEqual( put( enablePowerReviewReadyFlag() ) );
  } );
  it( 'should invoke POWERREVIEWS render method for emitting a feedless product if the productDetails object is passed', () => {
    window.POWERREVIEWS = {
      display : {
        render : jest.fn()
      }
    };
    let powerReviewRequestParam = {
      api_key: `${ switches.powerReviewsAPIKey }`,
      locale: `en_US`,
      merchant_group_id: `${ switches.powerReviewsMerchantGroupId }`,
      merchant_id: `${ switches.powerReviewsMerchantId }`,
      page_id: `${ productDetails.product.id }`,
      review_wrapper_url: `//${ switches.siteHttpServerName }/ui/pdp/review/?pr_page_id=${ productDetails.product.id }&pr_source=web`,
      product:{
        name:`${ productDetails.product.displayName }`,
        url:`${ productDetails.product.actionUrl }`,
        image_url:`${ productDetails.sku.images.largeImage }`,
        description:`${ productDetails.sku.description }`,
        category_name:`${ productDetails.breadCrumbNames }`,
        manufacturer_id:`${ productDetails.sku.manufacturerId }`,
        upc:`${ productDetails.sku.UPC }`,
        brand_name:`${ productDetails.brand.brandName }`,
        price:`${ productDetails.sku.price?.listPrice?.amount.toFixed( 2 ) || '' }`,
        in_stock:''
      }
    };
    const callDescriptor = listenerSagaForScript.next( ).value;
    expect( callDescriptor ).toEqual( call( global.POWERREVIEWS.display.render, powerReviewRequestParam ) );
  } );
} )

describe( 'emit feedless product no list price ', () => {
  var
      productDetails = {
        product:{
          id:'xlsImp20900008',
          displayName:'All Bright Cleansing Foam Wash',
          actionUrl:'https://qa1.ulta.com/all-bright-cleansing-foam-wash?productId=xlsImpprod15381019'
        },
        sku:{
          id:'1234',
          images:{
            largeImage:'https://images.ulta.com/is/image/Ulta/2502161?$lg$'
          },
          price:{
            listPrice:null
          },
          manufacturerId:'xlsImp20900008',
          UPC:'5000167227673',
          description:'Botanics All Bright Cleansing Foam Wash is a foaming, soap-free face wash'
        },
        brand:{
          brandName:'Botanics'
        },
        breadCrumbNames:'Home >Skin Care >Cleansers >All Bright Cleansing Foam Wash'
      };
  const switches = {
    powerReviewsAPIKey:'daa0f241-c242-4483-afb7-4449942d1a2b',
    powerReviewsMerchantGroupId:'11984',
    powerReviewsMerchantId:'6406',
    siteHttpServerName:'da3.ulta.com'
  }
  const listenerSagaForScript = cloneableGenerator( emittingFeedlessProductScript )( switches, productDetails );

  it( 'should do a put against product page data layer', () => {
    const putDescriptor = listenerSagaForScript.next( ).value;
    expect( putDescriptor ).toEqual( put( enablePowerReviewReadyFlag() ) );
  } );
  it( 'should invoke POWERREVIEWS render method with empty price when listPrice is null', () => {
    window.POWERREVIEWS = {
      display : {
        render : jest.fn()
      }
    };
    let powerReviewRequestParam = {
      api_key: `${ switches.powerReviewsAPIKey }`,
      locale: `en_US`,
      merchant_group_id: `${ switches.powerReviewsMerchantGroupId }`,
      merchant_id: `${ switches.powerReviewsMerchantId }`,
      page_id: `${ productDetails.product.id }`,
      review_wrapper_url: `//${ switches.siteHttpServerName }/ui/pdp/review/?pr_page_id=${ productDetails.product.id }&pr_source=web`,
      product:{
        name:`${ productDetails.product.displayName }`,
        url:`${ productDetails.product.actionUrl }`,
        image_url:`${ productDetails.sku.images.largeImage }`,
        description:`${ productDetails.sku.description }`,
        category_name:`${ productDetails.breadCrumbNames }`,
        manufacturer_id:`${ productDetails.sku.manufacturerId }`,
        upc:`${ productDetails.sku.UPC }`,
        brand_name:`${ productDetails.brand.brandName }`,
        price:'',
        in_stock:''
      }
    };
    const callDescriptor = listenerSagaForScript.next( ).value;
    expect( callDescriptor ).toEqual( call( global.POWERREVIEWS.display.render, powerReviewRequestParam ) );
  } );
} )

describe( 'emit feedless product --> no product details object ', () => {
  const switches = {
    powerReviewsAPIKey:'daa0f241-c242-4483-afb7-4449942d1a2b',
    powerReviewsMerchantGroupId:'11984',
    powerReviewsMerchantId:'6406',
    siteHttpServerName:'da3.ulta.com'
  }
  const listenerSagaForScript = cloneableGenerator( emittingFeedlessProductScript )( switches, undefined );

  it( 'should do a put against product page data layer', () => {
    const putDescriptor = listenerSagaForScript.next( ).value;
    expect( putDescriptor ).toEqual( put( enablePowerReviewReadyFlag() ) );
  } );
  it( 'should not invoke POWERREVIEWS if no productDetails data is set ', () => {
    expect( listenerSagaForScript.next().done ).toEqual( true );
  } );
} )

describe( 'PowerReview Script Ready', () => {
  it( 'should emit flag as true when POWERREVIEWS is available', () => {
    window.POWERREVIEWS = {
    };
    window.clearInterval = jest.fn();
    jest.useFakeTimers();
    const eventChannel = watchPowerReviewLoading( )
    const spy = isLoaded => {
      expect( isLoaded ).toEqual( true )
    }
    eventChannel.take( spy )
    jest.runTimersToTime( 3000 );
    expect( window.clearInterval ).toBeCalled();
  } );
} );