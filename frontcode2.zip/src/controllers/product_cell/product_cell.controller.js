import { takeLatest, call, put } from 'redux-saga/effects';

import {
  checkoutRedirectListener,
  registerServiceName,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import {
  ajax
} from '../../utils/ajax/ajax';

import {
  REMOVE_FROM_CART,
  UPDATE_CART,
  showRemovedFromBagSuccessMessage
} from '../../events/mini_cart/mini_cart.events';



import ProductCellItemMessages from '../../views/ProductCellItem/ProductCellItem.messages';


// Individual exports for testing
export const listener = function*( type, action ){

  try {

    yield put( getActionDefinition( type, 'loading' )( action.item ) );
    // we are broadCasting an empty message because the screen reader will not read the same message which is populated in the globalAssertiveRegion div( which is in index.html).
    yield put( setBroadcastMessage( '' ) );

    let query = {
      removalCommerceId: action.item.commerceItemid
    }

    const res =  yield call(
      ajax, {
        type,
        method:'post',
        query
      }
    );

    if( res.body.data ){

      // if res has no error, showRemovedFromBagSuccessMessage action will be triggered,
      // showRemovedFromBagSuccessMessage action is to hide spinner and display transition message
      yield put( showRemovedFromBagSuccessMessage( action.item ) );
      yield put( setBroadcastMessage( formatMessage( ProductCellItemMessages.removeItemFromBagLabel ) ) );
      yield put( getActionDefinition( type, 'success' )( { type:res.body.data, item:action.item } ) ) ;

      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( checkoutRedirectListener( action.item.history, qty, loadCartMessages ) );

      // Analytics tracking code begin

      const {
        cartSummary
      } = res.body.data;


      // remove the item from the orderItems object data layer
      if( cartSummary.itemCount === 0 ){
        global.globalPageData.order.orderItems = {};
      }
      else {
        global.globalPageData.order.orderItems.splice( global.globalPageData.order.orderItems.map( function( item ){
          return item.skuId;
        } ).indexOf( action.item.catalogRefId ), 1 )
      }


      // update data layer and fire remove from cart event
      const evt = {
        'name': 'cartRemoveFromCart',
        'data': {
          'sku': action.item.catalogRefId
        }
      }
      const data = {
        'globalPageData': {
          'order': {
            'removedFromCart': action.item.catalogRefId
          }
        }
      }

      yield put( setDataLayer( data, evt ) );

    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    console.error( err ); //eslint-disable-line

  }
}

export const updateListner = function*( type, action ){
  try {

    let values = {
      updateCommerceId: action.item,
      updateQuantity: action.quantity
    }
    const res =  yield call(
      ajax, {
        type,
        method:'post',
        values
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) ) ;
    if( res.body.data ){
      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( checkoutRedirectListener( action.history, qty, loadCartMessages ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let removeServiceType = 'removeItemFromCart';
  let updateServiceType = 'updateCartItems'
  // register events for the request
  registerServiceName( removeServiceType );
  registerServiceName( updateServiceType );


  yield takeLatest( REMOVE_FROM_CART, listener, removeServiceType );
  yield takeLatest( UPDATE_CART, updateListner, updateServiceType );

}
