/**
 * Created by Siyad on 7/2/18.
 **/
import {
  takeEvery,
  call,
  put,
  take,
  select,
  cancel
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import get from 'lodash/get';
import isEmpty from 'lodash/isEmpty';
import qProtocol from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';
import { getUserState } from '../../models/view/user/user.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import { ajax } from '../../utils/ajax/ajax';
import {
  retrieveProductIndex, retrieveVisualTerm,
  retrieveSearchTerm,
  retrieveSelectedTerm,
  retrieveViewAllResultFlag,
  removeSearchData
} from '../../utils/local_storage/local_storage';
import { getCartState } from '../../models/view/cart/cart.model';
import { getProductDetailsState } from '../../models/view/product_page/product_page.model';
const {
  triggerChildEvent
} = qProtocol;
import {
  emittingFeedlessProduct
} from '../../events/power_reviews/power_reviews.events';
import getHistory from '../../utils/history/history';
import appConstants from '../../shared/appConstants';

export function getProductQueryParams(){
  const history = getHistory();
  const {
    search
  } = history.location;

  const params = new URLSearchParams( search );
  const fav =  params.get( 'fav' );
  let page = 'detail';
  let productId = params.get( 'productId' );

  if( !productId ){
    productId = params.get( 'pr_page_id' );
    if( params.get( 'appName' ) === 'askQuestion' ){
      page = 'question';
    }
    else {
      page = 'review';
    }
  }
  const skuId = params.get( 'sku' );
  if( productId ){
    return {
      productId, skuId, fav, page
    };
  }
}

// this method is used to retreive the product and its related details
// In cases when the page is rendered via SSR, productDetails will already by available in the store and this method will be retrieve only the related details
// For client side rendering it will retrieve all the details including the product and sku details
export const getProductDetails = function* ( type, CONFIG, action ){
  const history = getHistory();
  const {
    pathname
  } = history.location;
  if( pathname === appConstants.URLS.VIRTUAL_TRYON_PAGE ){
    const switchData  = yield select( makeGetSwitchesData() );
    const switches = switchData.switches;
    if( ! switches.virtualTryOnEnabled ){
      history.replace( appConstants.URLS.ERROR_404_PAGE );
      yield cancel();
    }
  }
  const queryData = yield call( getProductQueryParams );
  try {
    if( queryData.productId ){
      yield put( getActionDefinition( type, 'loading' )() );

      let productDetails = yield select( getProductDetailsState );

      // this will check if productDetails is already available in the store, in case of which it will not be again fetched from here
      // logic to fetch productDetail will executed only in the case of client side rendering
      if( !productDetails ){

        const URIParams = { productid: queryData.productId };
        const query = {};

        if( process.env.NODE_ENV === 'development' ){
          query.__onSale = CONFIG.DEBUGGING.PRODUCT.onSale;
        }
        const res = yield call( ajax,
          {
            type:'productDetails',
            query,
            URIParams
          } );
        productDetails = res.body.data;

        if( productDetails.product && queryData.skuId ){
          // if sku was part of the request, then we need to make the follow up call to retrieve sku details
          const skuResponseData = yield call( invokeSkuService, queryData.skuId );
          if( skuResponseData ){
            // skudetails are populated in the product data, before sending a sucess response
            productDetails.sku = skuResponseData.sku;
          }
        }
      }
      yield put( getActionDefinition( type, 'success' )( productDetails ) );


      // the below logic will initiate the service calls to retrieve the other sku related data like eligibility, dynamicData etc
      // this will be invoked for both client side and server side rendering
      const skuRequestData = Object.assign( {}, queryData );
      if( queryData.page === 'detail' && productDetails.product ){
        skuRequestData.skuId = productDetails.sku.id;
        yield call( getSkuAdditionalDetails, skuRequestData );
        const switchData  = yield select( makeGetSwitchesData() );

        // Recommended Products
        const recTestEnabled = switchData.switches.recTestEnabled;
        if( !recTestEnabled ){
          yield put( getActionDefinition( 'pdpProductRecs', 'requested' )( { skuId:productDetails.sku.id } ) );
        }
        // Power Review Feedless Product
        productDetails = yield select( getProductDetailsState );
      }

      // Placing it here so that the emit happens irrespective of the page type
      yield put( emittingFeedlessProduct() );

      // handleProductAnalytics method will trigger the page navigation event
      yield call( handleProductAnalytics, queryData.page );

      // for signedIn user if the fav parameter is present in the request, a request will be made to add the sku to the favorites
      if( skuRequestData.fav ){
        const UserData = yield select( getUserState );

        const {
          isSignedIn
        } = UserData;

        if( isSignedIn ){
          // Update datalayer values on load when a guest successfully signs in to their account via the anonymous Add to Favorites scenario
          const data = {
            'globalPageData': {
              'action':{
                'login':'true'
              },
              'navigation':{
                'location':'product:favorites'
              }
            }
          };
          yield put( setDataLayer( data ) );
          yield put( getActionDefinition( 'pdpAddFavorite', 'requested' )( { productId:skuRequestData.productId, skuId: skuRequestData.skuId } ) );
        }
      }

    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}


// this method will initate the requests to fetch the eligibility, dynamicdata and favorites
export const getSkuAdditionalDetails = function* ( data ){
  // As the page is going to display the details of default sku, we need to make the eligibility service and dynamic sku data call at this point
  // In other cases, where we have a follow up sku service call to be made, the eligibility service and dynamic sku data call will be triggered from the SkuDetail saga
  // after sku service is invoked
  yield put( getActionDefinition( 'pdpPurchaseEligibility', 'requested' )( data.skuId ) );
  // we are waiting for purchaseEligibility response as we need the same to handle analytics requirement
  yield take( getServiceType( 'pdpPurchaseEligibility', 'success' ) );
  yield put( getActionDefinition( 'pdpSkuDynamicData', 'requested' )( data.skuId ) );
  // we are waiting for skuDynamicData response as we need the same to handle analytics requirement
  yield take( getServiceType( 'pdpSkuDynamicData', 'success' ) );
}

// this method will fetch the skuDetails when a swatch is selected
export const getSkuDetails = function* ( type, CONFIG, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const skuData = yield call( invokeSkuService, action.data.skuId );
    yield put( getActionDefinition( type, 'success' )( skuData ) );
    yield call( getSkuAdditionalDetails, action.data );
    yield call( handleProductAnalytics, 'detail', true );

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}

// this method will invoke the sku service and return the sku details
export const invokeSkuService = function* ( skuid ){

  const URIParams = { skuid };
  const query = {};
  const res = yield call( ajax,
    {
      type:'skuDetails',
      query,
      URIParams
    } );
  return res.body.data;
}

// this method will populate the globalPageData object and trigger the pageNavigation event
export const handleProductAnalytics = function*( page, isOptionClick ){
  // retrieve product index from session storage
  const productIndex = yield call( retrieveProductIndex );
  // retrieve Search Term from session storage
  const searchTerm = yield call( retrieveSearchTerm );
  // retrieve Visual Term from session storage
  const visualTerm = yield call( retrieveVisualTerm );
  // retrieve View Results flag from session storage
  const viewAllResultFlag = yield call( retrieveViewAllResultFlag );
  // retrieve Selected Term from session storage
  const selectedTerm = yield call( retrieveSelectedTerm );
  const cartState = yield select( getCartState );
  const productDetails = yield select( getProductDetailsState );

  const {
    product,
    sku,
    brand,
    purchaseEligibility,
    reviewSummary
  } = productDetails;

  const evt = {
    'name': 'pageNavigation'
  }

  let pageType;
  let pageName;

  if( page === 'detail' ){
    pageType = 'product detail';
    if( product ){
      pageName = `product:${sku.id}:${brand.brandName}:${sku.displayName}`;
    }
    else {
      pageName = 'product:no results';
    }
  }
  else if( page === 'review' ){
    pageType = 'product review';
    pageName = 'product:review';
  }
  else if( page === 'question' ){
    pageType = 'product question';
    pageName = 'product:question';
  }

  // Removing all the search data from  global page data if swatch is selected so that it doesnt get reported to omniture again
  if( isOptionClick && global.globalPageData.search ){
    global.globalPageData.search = {};
  }

  const data = {
    'globalPageData': {
      'navigation': {
        'channel': 'product',
        'pageType':pageType,
        'pageName': pageName.toLowerCase(),
        ...( product && page === 'detail' && { 'hierarchy':product.categoryPath ? product.categoryPath.items.map( item => item.name ).toString().toLowerCase() : '' } )
      },
      'product':{
        'expired':product ? 'false' : 'true',
        ...( product && {
          'url':product.actionUrl,
          'excludedFromCoupons':!sku.couponEligible ? 'true' : 'false',
          ...( sku.variant && sku.variant.variantType === 'Color' && { 'color': sku.variant.variantDesc } ),
          ...( sku.price && sku.price.listPrice && { 'currency' : sku.price.listPrice.currencyCode } ),
          'description' : sku.description,
          'id' : product.id,
          'imgurl' :sku.images.largeImage,
          'listPrice' : sku && sku.price && sku.price.listPrice ? sku.price.listPrice.amount : '0.00',
          'name' :sku.displayName,
          'saleprice' :sku && sku.price && sku.price.salePrice ? sku.price.salePrice.amount : '0.00',
          'size' :sku.size,
          'sku' :sku.id,
          'qaCount' :reviewSummary && reviewSummary.questionCount ? `${reviewSummary.questionCount}` : '0',
          'reviewCount' :reviewSummary && reviewSummary.reviewCount ? `${reviewSummary.reviewCount}` : '0',
          'reviewAverage' :reviewSummary && reviewSummary.rating ? `${reviewSummary.rating}` : '0',
          'onlineOnly' :( sku.onlineOnlyStatus ?? false ).toString(),
          'optionClick':`${ !!isOptionClick }`
        } ),
        ...( purchaseEligibility && {
          'outOfStock': ( purchaseEligibility.isNotifyMeSignUp || purchaseEligibility.isNotifyMeEligible || purchaseEligibility.isOutOfStock ) ? 'true' : 'false',
          'comingSoon': purchaseEligibility.isComingSoonProduct ? 'true' : 'false',
          'inStoreOnly': purchaseEligibility.isInStoreOnlyProduct ? 'true' : 'false'
        } ),
        ...( brand && { 'brand':brand.brandName } )
      },
      'order':{
        'previousItemCount':cartState.quantity
      },
      ...( ( !isEmpty( productIndex ) || !isEmpty( searchTerm ) ) &&
      {
        'search': {
          'noOfResults':'1',
          ...( !isEmpty( searchTerm ) && { 'searchTerm':searchTerm } ),
          ...( !isEmpty( selectedTerm ) && { 'suggestedTerm':selectedTerm } ),
          ...( !isEmpty( productIndex ) && { 'visualProductSelected':`${productIndex }:${ brand.brandName.toLowerCase() }:${ product.displayName.toLowerCase() }` } ),
          // only if the view all results link is clicked or product link is clicked we will populate the visual term
          ...( ( !isEmpty( productIndex ) || !isEmpty( viewAllResultFlag ) ) && ( !isEmpty( visualTerm ) && { 'visualTerm':visualTerm.toLowerCase() } ) ),
          ...( !isEmpty( viewAllResultFlag ) && { 'visualViewAllResults':'true' } )
        }
      } )
    }
  }
  yield put( setDataLayer( data, evt ) );

  // Removing all the search data from session storage so that it doesnt get reported to omniture again
  yield call( removeSearchData );

  // Omniture changes for adding Error/Info Messages to globalPageData object and trigger the serviceMessagesUpdated event
  let serviceMessages = [];
  if( productDetails ){
    if( productDetails.messages ){
      serviceMessages.push( productDetails.messages );
    }
    if( productDetails.sku && productDetails.sku.messages ){
      serviceMessages.push( productDetails.sku.messages );
    }
  }
  if( purchaseEligibility ){

    if( purchaseEligibility.availabilityMessage1 ){
      serviceMessages.push( purchaseEligibility.availabilityMessage1 );
    }
    if( purchaseEligibility.availabilityMessage2 ){
      serviceMessages.push( purchaseEligibility.availabilityMessage2 );
    }
    if( purchaseEligibility.emailStockNotifyMessage ){
      serviceMessages.push( purchaseEligibility.emailStockNotifyMessage );
    }
  }
  if( !isEmpty( serviceMessages ) ){
    const meassageEvt = {
      'name': 'serviceMessagesUpdated'
    }
    const messageData = {
      'globalPageData': {
        'product':{
          ...data.globalPageData.product,
          'messages': serviceMessages
        }
      }
    }

    yield put( setDataLayer( messageData, meassageEvt ) );
  }
  yield call( triggerQProtocol, productDetails );
}

export const triggerQProtocol = function* ( data ){

  let qubitProductDetailEventData = getProductObject( data );
  triggerChildEvent( 'ecProduct', qubitProductDetailEventData );
}

const getProductObject = ( data )=>{
  const productDetails = data;
  let listPriceValue = get( productDetails, 'sku.price.listPrice.amount' );
  let salePriceValue = get( productDetails, 'sku.price.salePrice.amount' );
  let listPriceCurrency = get( productDetails, 'sku.price.listPrice.currency' ) || 'USD';
  let variantType = get( productDetails, 'sku.variant.variantType' ) || '' ;
  let variantDesc = get( productDetails, 'sku.variant.variantDesc' ) || '' ;

  let qubitProductDetailEventData = {
    eventType: 'detail',
    product: {
      sku: productDetails.sku.id,
      productId: productDetails.product.id,
      name: productDetails.product.displayName,
      stock: productDetails.purchaseEligibility.isAddToCartEligible ? null : 0,
      price: {
        currency: listPriceCurrency,
        value: salePriceValue || listPriceValue
      },
      originalPrice: {
        currency: listPriceCurrency,
        value: listPriceValue
      },
      manufacturer: productDetails.brand.brandName,
      url: productDetails.product.actionUrl,
      description: productDetails.sku.description,
      categories: [( ( ( productDetails.product.categoryPath.items.map( ( item ) => item.name ) ).toString() ).replace( /,/g, ' > ' ) )],
      images: [productDetails.sku.images.mainImage],
      ...( variantType && { [variantType.toLowerCase()]: variantDesc } )
    }
  };
  return qubitProductDetailEventData;
}

export default function( CONFIG ){
  return function*( ){
    const productDetailsServiceType = 'pdpProductDetails';
    const skuDetailsServiceType = 'pdpSkuDetails';
    const userServiceType = 'user';

    registerServiceName( productDetailsServiceType );
    registerServiceName( skuDetailsServiceType );

    yield takeEvery( getServiceType( productDetailsServiceType, 'requested' ), getProductDetails, productDetailsServiceType, CONFIG );
    yield takeEvery( getServiceType( skuDetailsServiceType, 'requested' ), getSkuDetails, skuDetailsServiceType, CONFIG );
    yield takeEvery( getServiceType( userServiceType, 'success' ), getProductDetails, productDetailsServiceType, CONFIG );
  }
}