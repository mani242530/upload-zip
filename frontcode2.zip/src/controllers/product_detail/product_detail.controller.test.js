/**
 * Created by Siyad on 7/2/18.
 */
import {
  takeEvery,
  call,
  put,
  cancelled,
  take,
  select,
  cancel
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { cloneableGenerator } from 'redux-saga/utils';
import { triggerChildEvent } from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getUserState } from '../../models/view/user/user.model';
import getHistory from '../../utils/history/history';
import {
  emittingFeedlessProduct
} from '../../events/power_reviews/power_reviews.events';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import { ajax } from '../../utils/ajax/ajax';
import {
  retrieveProductIndex, retrieveVisualTerm,
  retrieveSearchTerm,
  retrieveViewAllResultFlag,
  retrieveSelectedTerm,
  removeSearchData
} from '../../utils/local_storage/local_storage';
import { getCartState } from '../../models/view/cart/cart.model';
import { getProductDetailsState } from '../../models/view/product_page/product_page.model';
import CONFIG from '../../modules/pdp/pdp.config';
import saga, {
  getProductDetails, getSkuDetails,
  getProductQueryParams,
  getSkuAdditionalDetails,
  handleProductAnalytics,
  invokeSkuService,
  triggerQProtocol
} from './product_detail.controller';
import appConstants from '../../shared/appConstants';

jest.mock( 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol', () => {
  return { triggerChildEvent:jest.fn() }
} );
const history = getHistory();
const type = 'pdpProductDetails';
const promotionType = 'pdpSkuDynamicData';
const skuDetailsServiceType = 'pdpSkuDetails';
const productQueryParamsServiceType = 'pdpProductQuery'
var action = {
  data:{
    productId: '123567',
    skuId: '12312312',
    page:'detail',
    fav:true
  }
}
history.location.search = '?productId=123567&sku=12312312&fav=true';
history.location.pathname = appConstants.URLS.VIRTUAL_TRYON_PAGE;

global.globalPageData = {};

const listenerSaga = cloneableGenerator( getProductDetails )( type, CONFIG, action );
const listenerSaga1 = cloneableGenerator( getSkuDetails )( skuDetailsServiceType, CONFIG, action );
let listenerSagaClone1;
let listenerSagaClone2;
let listenerSagaClone;
let listenerSaga2Clone1;
let listenerSaga2Clone2;
describe( 'ProductDetail sagas', () => {
  const coreSaga = saga( CONFIG )();
  registerServiceName( type );
  registerServiceName( promotionType );
  registerServiceName( 'pdpSkuDetails' );
  registerServiceName( 'pdpPurchaseEligibility' );
  registerServiceName( 'pdpFindFavorite' );
  registerServiceName( 'pdpAddFavorite' );
  registerServiceName( 'pdpProductRecs' );
  registerServiceName( 'pdpProductQuery' );
  registerServiceName( 'user' );

  it( 'should take every pdpProductDetails request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), getProductDetails, type, CONFIG ) );
  } );

  it( 'should take every pdpSkuDetails request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( 'pdpSkuDetails', 'requested' ), getSkuDetails, 'pdpSkuDetails', CONFIG ) );
  } );

  it( 'should take every user success', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( 'user', 'success' ), getProductDetails, type, CONFIG ) );
  } );
  describe( 'ProductDetail saga success path', () => {

    it( 'should select the makeGetSwitchesData ', () => {
      const selectDescriptor = listenerSaga.next( ).value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should call the getProductQueryParams ', () => {
      const switchData = {
        switches:{
          virtualTryOnEnabled:true
        }
      }
      const callDescriptor = listenerSaga.next( switchData ).value;
      // const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( getProductQueryParams ) );
    } );

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( action.data ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method when the environemnt is developement', () => {
      listenerSaga.next();
      const callDescriptor = listenerSaga.next().value;
      const query = {};
      const URIParams = { productid:action.data.productId };
      // the NODE_ENV variable needs to be reset to it original value i.e.test or else it will affect other test cases.
      // resetting it before the 'expect' so that the value will be reset even in those case where expect fails
      process.env.NODE_ENV = 'test';
      expect( callDescriptor ).toEqual( call( ajax, { type:'productDetails', query, URIParams } ) );
    } );

    let productRes;
    it( 'should call invokeSkuService ', () => {
      productRes = {
        body: {
          data:{
            product:{},
            sku:{
              id:'123',
              images:{},
              price:{}
            },
            brand:{}
          }
        }
      };
      const callDescriptor = listenerSaga.next( productRes ).value;
      expect( callDescriptor ).toEqual( call( invokeSkuService, action.data.skuId ) );
    } );
    let listenerSagaCloneRecs;
    it( 'should put a success event after data is called', () => {
      const skuRes = {
        body:{
          data:{
            sku:{
              id:'12312312'
            }
          }
        }
      }
      listenerSagaClone1 = listenerSaga.clone();
      listenerSagaCloneRecs = listenerSaga.clone();
      const putDescriptor = listenerSaga.next( skuRes ).value;
      productRes.body.data.sku = skuRes.body.data.sku;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( productRes.body.data ) ) );
    } );

    it( 'should call getSkuAdditionalDetails ', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( getSkuAdditionalDetails, action.data ) );
    } );

    it( 'should call makeGetSwitchesData ', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put pdpProductRecs requested event if recTestEnabled is false', () => {
      const putDescriptor = listenerSaga.next( { switches:{ recTestEnabled : false } } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'pdpProductRecs', 'requested' )( { skuId:'12312312' } ) ) );
    } );

    it( 'should not put pdpProductRecs requested event if recTestEnabled is true', () => {
      const skuRes = {
        body:{
          data:{
            sku:{
              id:'12312312'
            }
          }
        }
      }
      const putDescriptor = listenerSagaCloneRecs.next( skuRes ).value;
      productRes.body.data.sku = skuRes.body.data.sku;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( productRes.body.data ) ) );
      const callDescriptor = listenerSagaCloneRecs.next().value;
      expect( callDescriptor ).toEqual( call( getSkuAdditionalDetails, action.data ) );
      const selectDescriptor = listenerSagaCloneRecs.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
      const selectDescriptor1 = listenerSagaCloneRecs.next( { switches:{ recTestEnabled : true } } ).value;
      expect( selectDescriptor1 ).toEqual( select( getProductDetailsState ) );
    } );

    it( 'should select getProductDetailsState', () => {
      const selectDescriptor = listenerSaga.next( ).value;
      expect( selectDescriptor ).toEqual( select( getProductDetailsState ) );

    } );

    it( 'should put emittingFeedlessProduct requested event', () => {
      const productDetails = {
        product:{},
        sku:{
          id:'123',
          displayName:'shiny lipstick',
          images:{},
          price:{},
          variant:{},
          couponEligible:false
        },
        brand:{},
        purchaseEligibility:{},
        reviewNum:1559,
        reviewSummary:{
          questionCount: 16,
          rating: 4.66,
          reviewCount: 1559
        }
      }
      const putDescriptor = listenerSaga.next( productDetails ).value;
      expect( putDescriptor ).toEqual( put( emittingFeedlessProduct() ) );
    } );

    it( 'should call handleProductAnalytics ', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( handleProductAnalytics, 'detail' ) );
    } );

    it( 'should call getUserState ', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( select( getUserState ) );
    } );

    it( 'Update datalayer values when a guest successfully signs in to their account via the anonymous Add to Favorites scenario ', () => {
      const data = {
        'globalPageData': {
          'action':{
            'login':'true'
          },
          'navigation':{
            'location':'product:favorites'
          }
        }
      };
      const putDescriptor = listenerSaga.next( { isSignedIn:true } ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data ) ) );
    } );

    it( 'should put pdpAddFavorite requested event ', () => {
      const putDescriptor = listenerSaga.next( { isSignedIn:true } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'pdpAddFavorite', 'requested' )( { productId:action.data.productId, skuId: action.data.skuId } ) ) );
    } );

  } );
  describe( 'ProductDetail saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

  describe( 'GetSkuAdditionalDetails', () => {

    var action1 = {
      data:{
        productId: 123567,
        skuId: 12312312
      }
    }

    const listenerSaga = getSkuAdditionalDetails( action1.data );
    it( 'should put pdpPurchaseEligibility requested event ', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'pdpPurchaseEligibility', 'requested' )( action1.data.skuId ) ) );
    } );

    it( 'should take pdpPurchaseEligibility success event ', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( take( getServiceType( 'pdpPurchaseEligibility', 'success' ) ) );
    } );

    it( 'should put pdpSkuDynamicData requested event ', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'pdpSkuDynamicData', 'requested' )( action1.data.skuId ) ) );
    } );

    it( 'should take pdpSkuDynamicData success event ', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( take( getServiceType( 'pdpSkuDynamicData', 'success' ) ) );
    } );

  } );

  let listenerSagaClone3;
  let listenerSagaClone4;
  let listenerSagaClone5;
  let listenerSagaClone6;
  let listenerSagaClone7;
  let listenerSagaClone8;

  describe( 'HandleProductAnalytics', () => {
    const listenerSaga = cloneableGenerator( handleProductAnalytics )( 'detail' );
    let listenerSagaClone9;
    it( 'should call the retrieveProductIndex ', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( retrieveProductIndex ) );
    } );

    it( 'should call the retrieveVisualTerm ', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( retrieveSearchTerm ) );
    } );

    it( 'should call the retrieveSearchTerm ', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( retrieveVisualTerm ) );
    } );

    it( 'should call the retrieveViewAllResultFlag ', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( retrieveViewAllResultFlag ) );
    } );

    it( 'should call the retrieveSelectedTerm ', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( retrieveSelectedTerm ) );
    } );

    it( 'should select getCartState', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( selectDescriptor ).toEqual( select( getCartState ) );

    } );

    const cartState = {
      quantity:5
    }
    it( 'should select getProductDetailsState', () => {
      const selectDescriptor = listenerSaga.next( cartState ).value;
      listenerSagaClone9 = listenerSaga.clone();
      expect( selectDescriptor ).toEqual( select( getProductDetailsState ) );

    } );

    it( 'should put a request event setDataLayer-response product is not null', () => {
      const productDetails = {
        product:{},
        sku:{
          id:'123',
          displayName:'shiny lipstick',
          images:{},
          price:{},
          variant:{},
          couponEligible:false
        },
        brand:{},
        purchaseEligibility:{},
        reviewSummary:{
          questionCount: 16,
          rating: 4.66,
          reviewCount: 1559
        }
      }
      listenerSagaClone = listenerSaga.clone();
      listenerSagaClone3 = listenerSaga.clone();
      listenerSagaClone4 = listenerSaga.clone();
      listenerSagaClone5 = listenerSaga.clone();
      listenerSagaClone6 = listenerSaga.clone();
      listenerSagaClone7 = listenerSaga.clone();
      listenerSagaClone8 = listenerSaga.clone();

      const putDescriptor = listenerSaga.next( productDetails ).value;
      const data = {
        'globalPageData': {
          'navigation': {
            'channel': 'product',
            'pageName': 'product:123:undefined:shiny lipstick',
            'pageType': 'product detail',
            'hierarchy':''
          },
          'product': {
            brand: undefined,
            'description': undefined,
            'excludedFromCoupons': 'true',
            'expired': 'false',
            id:undefined,
            'imgurl': undefined,
            'listPrice': '0.00',
            'name': 'shiny lipstick',
            'saleprice': '0.00',
            'size': undefined,
            'sku': '123',
            url : undefined,
            outOfStock:'false',
            inStoreOnly:'false',
            comingSoon:'false',
            qaCount: '16',
            reviewAverage: '4.66',
            reviewCount: '1559',
            'onlineOnly': 'false',
            'optionClick': 'false'
          },
          'order':{
            'previousItemCount':5
          }
        }
      }
      let evt = {
        'name': 'pageNavigation'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put a request event setDataLayer-response product is null', () => {
      const productDetails = {
        product:null
      }
      const putDescriptor = listenerSagaClone3.next( productDetails ).value;
      const data = {
        'globalPageData': {
          'navigation': {
            'channel': 'product',
            'pageName': 'product:no results',
            'pageType': 'product detail'
          },
          'product': {
            'expired':'true'
          },
          'order':{
            'previousItemCount':5
          }
        }
      }
      let evt = {
        'name': 'pageNavigation'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put a request event setDataLayer-response with hierarchy if there is categoryPath in product', () => {
      const productDetails = {
        product:{
          categoryPath: {
            items: [
              {
                name: 'Nails',
                actionUrl: 'https://qa1.ulta.com/nails?N=271o'
              },
              {
                name: 'Nail Polish',
                actionUrl: 'https://qa1.ulta.com/nail-polish?N=278s'
              }
            ]
          }
        },
        sku:{
          id:'123',
          displayName:'shiny lipstick',
          images:{},
          price:{},
          variant:{},
          couponEligible:false
        },
        brand:{},
        reviewSummary:{
          questionCount: 16,
          rating: 4.66,
          reviewCount: 1559
        }
      }
      const data = {
        'globalPageData': {
          'navigation': {
            'channel': 'product',
            'pageName': 'product:123:undefined:shiny lipstick',
            'pageType': 'product detail',
            'hierarchy':'Nails,Nail Polish'.toLowerCase()
          },
          'product': {
            brand: undefined,
            'description': undefined,
            'excludedFromCoupons': 'true',
            'expired': 'false',
            id:undefined,
            'imgurl': undefined,
            'listPrice': '0.00',
            'name': 'shiny lipstick',
            'saleprice': '0.00',
            'size': undefined,
            'sku': '123',
            'url':undefined,
            qaCount: '16',
            reviewAverage: '4.66',
            reviewCount: '1559',
            'onlineOnly': 'false',
            'optionClick': 'false'
          },
          'order':{
            'previousItemCount':5
          }
        }
      }
      let evt = {
        'name': 'pageNavigation'
      }
      const putDescriptor = listenerSagaClone.next( productDetails ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put a request event setDataLayer-response with onlineOnly as true', () => {
      const productDetails = {
        product:{
          categoryPath: {
            items: [
              {
                name: 'Nails',
                actionUrl: 'https://qa1.ulta.com/nails?N=271o'
              },
              {
                name: 'Nail Polish',
                actionUrl: 'https://qa1.ulta.com/nail-polish?N=278s'
              }
            ]
          }
        },
        sku:{
          id:'123',
          displayName:'shiny lipstick',
          images:{},
          onlineOnlyStatus: true,
          price:{},
          variant:{},
          couponEligible:false
        },
        brand:{},
        reviewSummary:{
          questionCount: 16,
          rating: 4.66,
          reviewCount: 1559
        }
      }
      const data = {
        'globalPageData': {
          'navigation': {
            'channel': 'product',
            'pageName': 'product:123:undefined:shiny lipstick',
            'pageType': 'product detail',
            'hierarchy':'Nails,Nail Polish'.toLowerCase()
          },
          'product': {
            brand: undefined,
            'description': undefined,
            'excludedFromCoupons': 'true',
            'expired': 'false',
            id:undefined,
            'imgurl': undefined,
            'listPrice': '0.00',
            'name': 'shiny lipstick',
            'saleprice': '0.00',
            'size': undefined,
            'sku': '123',
            'url':undefined,
            qaCount: '16',
            reviewAverage: '4.66',
            reviewCount: '1559',
            'onlineOnly': 'true',
            'optionClick': 'false'
          },
          'order':{
            'previousItemCount':5
          }
        }
      }
      let evt = {
        'name': 'pageNavigation'
      }
      const putDescriptor = listenerSagaClone9.next( productDetails ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );
    it( 'should call the removeSearchData method', () => {
      const callDescriptor = listenerSagaClone.next( ).value;
      expect( callDescriptor ).toEqual( call( removeSearchData ) );
    } );

    it( 'should put a request event setDataLayer-response if there is messages in productdetail', () => {
      const productDetails = {
        messages:'test'
      }
      listenerSagaClone4.next( productDetails );
      listenerSagaClone4.next(); // call for removeSearchData
      const putDescriptor = listenerSagaClone4.next( ).value;
      const data = {
        'globalPageData': {
          'product':{
            'expired': 'true',
            'messages': ['test']
          }
        }
      }
      let evt = {
        'name': 'serviceMessagesUpdated'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put a request event setDataLayer-response if there is availabilityMessage1 in productdetail purchaseEligibility', () => {
      const productDetails = {
        purchaseEligibility:{
          availabilityMessage1: 'test'
        }
      }
      listenerSagaClone5.next( productDetails );
      listenerSagaClone5.next();// call for removeSearchData
      const putDescriptor = listenerSagaClone5.next( productDetails ).value;
      const data = {
        'globalPageData': {
          'product':{
            'comingSoon': 'false',
            'expired': 'true',
            'inStoreOnly': 'false',
            'messages': ['test'],
            'outOfStock': 'false'
          }
        }
      }
      let evt = {
        'name': 'serviceMessagesUpdated'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put a request event setDataLayer-response if there is availabilityMessage2 in productdetail purchaseEligibility', () => {
      const productDetails = {
        purchaseEligibility:{
          availabilityMessage2: 'test'
        }
      }
      listenerSagaClone6.next( productDetails );
      listenerSagaClone6.next();// call for removeSearchData
      const putDescriptor = listenerSagaClone6.next( productDetails ).value;
      const data = {
        'globalPageData': {
          'product':{
            'comingSoon': 'false',
            'expired': 'true',
            'inStoreOnly': 'false',
            'messages': ['test'],
            'outOfStock': 'false'
          }
        }
      }
      let evt = {
        'name': 'serviceMessagesUpdated'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put a request event setDataLayer-response if there is emailStockNotifyMessage in productdetail purchaseEligibility', () => {
      const productDetails = {
        purchaseEligibility:{
          emailStockNotifyMessage: 'test'
        }
      }
      listenerSagaClone7.next( productDetails );
      listenerSagaClone7.next();// call for removeSearchData
      const putDescriptor = listenerSagaClone7.next( productDetails ).value;
      const data = {
        'globalPageData': {
          'product':{
            'comingSoon': 'false',
            'expired': 'true',
            'inStoreOnly': 'false',
            'outOfStock': 'false',
            'messages': ['test']
          }
        }
      }
      let evt = {
        'name': 'serviceMessagesUpdated'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );
    const productDetails = {
      sku:{
        messages: 'test'
      }
    }
    it( 'should put a request event setDataLayer-response if there is messages in productdetail sku', () => {
      listenerSagaClone8.next( productDetails );
      listenerSagaClone8.next();// call for removeSearchData
      const putDescriptor = listenerSagaClone8.next( productDetails ).value;
      const data = {
        'globalPageData': {
          'product':{
            'expired': 'true',
            'messages': ['test']
          }
        }
      }
      let evt = {
        'name': 'serviceMessagesUpdated'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should call the triggerQProtocol ', () => {
      const callDescriptor = listenerSagaClone8.next( ).value;
      expect( callDescriptor ).toEqual( call( triggerQProtocol, productDetails ) );
    } );
  } );


  describe( 'GetSkuDetails success path', () => {
    const res = {
      body: {
        data:{
          product:{},
          sku:{
            id:'123',
            images:{},
            price:{}
          },
          brand:{}
        }
      }
    };
    const type = 'pdpSkuDetails';
    it( 'should put loadSkuDetails loading  event ', () => {
      const putDescriptor = listenerSaga1.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( skuDetailsServiceType, 'loading' )() ) );
    } );

    it( 'should call invokeSkuService', () => {
      const callDescriptor = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( invokeSkuService, action.data.skuId ) );
    } );

    it( 'should put pdpSkuDetails success  event ', () => {
      const res = {
        sku:{
          id:'123',
          images:{},
          price:{}
        },
        brand:{}
      };
      listenerSagaClone1 = listenerSaga1.clone();
      const putDescriptor = listenerSaga1.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
    } );

    it( 'should call getSkuAdditionalDetails', () => {
      const callDescriptor = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( getSkuAdditionalDetails, action.data ) );
    } );
    it( 'should call handleProductAnalytics with option selected as true', () => {
      const callDescriptor = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( handleProductAnalytics, 'detail', true ) );
    } );

  } );

  describe( 'GetSkuDetails failure path', () => {
    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga1.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( skuDetailsServiceType, 'failure' )( err ) ) );
    } );

  } );

  describe( 'invokeSkuService test cases', () => {
    const testSkuId = '123323';
    const invokeSkuServiceListener = invokeSkuService( testSkuId );

    it( 'should invoke pdpSkuDetails call ', () => {
      const callDescriptor = invokeSkuServiceListener.next().value;
      expect( callDescriptor ).toEqual( call( ajax, { type:'skuDetails', query: {}, URIParams: { skuid:'123323' } } ) );
    } );

    it( 'should call invokeSkuService', () => {
      const skuRes = {
        body:{
          data:{
            sku:{
              id:'12312312'
            }
          }
        }
      }
      const skuReturnData = invokeSkuServiceListener.next( skuRes );
      expect( skuReturnData.value ).toBe( skuRes.body.data );
    } );

  } );

  describe( 'triggerQProtocol sagas', () => {
    it( ' triggerChildEvent should be triggered with ecProduct as object  ', () => {
      const data = {
        'product': {
          'displayName': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'categoryPath': {
            'items': [
              {
                'name': 'Makeup',
                'actionUrl': 'https://qa3.ulta.com/makeup?N=26y1'
              },
              {
                'name': 'Face',
                'actionUrl': 'https://qa3.ulta.com/makeup-face?N=26y3'
              },
              {
                'name': 'Color Correcting',
                'actionUrl': 'https://qa3.ulta.com/makeup-face-color-correcting?N=dapq1e'
              }
            ]
          },
          'actionUrl': 'https://qa3.ulta.com/talc-free-cushion-corrector-primer-duo-spf-20?productId=xlsImpprod15451011',
          'title': 'Physicians Formula Talc-Free Cushion Corrector + Primer Duo SPF 20 | Ulta Beauty',
          'defaultSku': '2502914',
          'id': 'xlsImpprod15451011'
        },
        'purchaseEligibility':{
          'isAddToCartEligible':true
        },
        'sku': {
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2502914?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2502914',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2502914?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2502914?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2502914?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2502914?$md$'
          },
          'displayName': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'description': 'Physician\'s Formula Talc-Free Cushion Corrector + Primer Duo has a weightless mineral formula that delivers the skin-transforming benefits of color-correction and the skin-perfecting effect of priming in one revolutionary cushion.',
          'price': {
            'salePrice': null,
            'listPrice': {
              'displayAmount': '$16.99',
              'amount': 16.99,
              'currencyCode': 'USD'
            }
          },
          'variant': {
            'variantType': 'Size',
            'variantDesc': '3.4 oz'
          },
          'id': '2502914',
          'maxQty': 10
        },
        'brand': {
          'brandName': 'Jimmy Choo'
        }
      }
      const triggerQProtocol1 = triggerQProtocol( data );
      let qubitProductDetailEventData = {
        'eventType': 'detail',
        'product': {
          'categories': [
            'Makeup > Face > Color Correcting'
          ],
          'description': 'Physician\'s Formula Talc-Free Cushion Corrector + Primer Duo has a weightless mineral formula that delivers the skin-transforming benefits of color-correction and the skin-perfecting effect of priming in one revolutionary cushion.',
          'images': [
            'https://images.ulta.com/is/image/Ulta/2502914'
          ],
          'manufacturer': 'Jimmy Choo',
          'name': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'originalPrice': {
            'currency': 'USD',
            'value': 16.99
          },
          'price': {
            'currency': 'USD',
            'value': 16.99
          },
          'productId': 'xlsImpprod15451011',
          'size': '3.4 oz',
          'sku': '2502914',
          'stock': null,
          'url': 'https://qa3.ulta.com/talc-free-cushion-corrector-primer-duo-spf-20?productId=xlsImpprod15451011'
        }
      }
      const callDescriptor = triggerQProtocol1.next( qubitProductDetailEventData ).value;
      expect( triggerChildEvent ).toHaveBeenCalledWith( 'ecProduct', qubitProductDetailEventData )

    } );
    it( ' triggerChildEvent should not be triggered with ecProduct as object  ', () => {
      const data1 = {
        'product': {
          'displayName': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'categoryPath': {
            'items': [
              {
                'name': 'Makeup',
                'actionUrl': 'https://qa3.ulta.com/makeup?N=26y1'
              },
              {
                'name': 'Face',
                'actionUrl': 'https://qa3.ulta.com/makeup-face?N=26y3'
              },
              {
                'name': 'Color Correcting',
                'actionUrl': 'https://qa3.ulta.com/makeup-face-color-correcting?N=dapq1e'
              }
            ]
          },
          'actionUrl': 'https://qa3.ulta.com/talc-free-cushion-corrector-primer-duo-spf-20?productId=xlsImpprod15451011',
          'title': 'Physicians Formula Talc-Free Cushion Corrector + Primer Duo SPF 20 | Ulta Beauty',
          'defaultSku': '2502914',
          'id': 'xlsImpprod15451011'
        },
        'purchaseEligibility':{
          'isAddToCartEligible':true
        },
        'sku': {
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2502914?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2502914',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2502914?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2502914?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2502914?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2502914?$md$'
          },
          'displayName': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'description': 'Physician\'s Formula Talc-Free Cushion Corrector + Primer Duo has a weightless mineral formula that delivers the skin-transforming benefits of color-correction and the skin-perfecting effect of priming in one revolutionary cushion.',
          'price': {
            'salePrice': null,
            'listPrice': {
              'displayAmount': '$16.99',
              'currencyCode': 'USD'
            }
          },
          'variant': {
            'variantType': 'Color',
            'variantDesc': 'Red'
          },
          'id': '2502914',
          'maxQty': 10
        },
        'brand': {
          'brandName': 'Jimmy Choo'
        }
      }

      const triggerQProtocol2 = triggerQProtocol( data1 );
      let qubitProductDetailEventData1 = {
        'eventType': 'detail',
        'product': {
          'categories': [
            'Makeup > Face > Color Correcting'
          ],
          'description': 'Physician\'s Formula Talc-Free Cushion Corrector + Primer Duo has a weightless mineral formula that delivers the skin-transforming benefits of color-correction and the skin-perfecting effect of priming in one revolutionary cushion.',
          'images': [
            'https://images.ulta.com/is/image/Ulta/2502914'
          ],
          'manufacturer': 'Jimmy Choo',
          'name': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'originalPrice': {
            'currency': 'USD',
            'value': undefined
          },
          'price': {
            'currency': 'USD',
            'value': undefined
          },
          'productId': 'xlsImpprod15451011',
          'color': 'Red',
          'sku': '2502914',
          'stock': null,
          'url': 'https://qa3.ulta.com/talc-free-cushion-corrector-primer-duo-spf-20?productId=xlsImpprod15451011'
        }
      }
      const callDescriptor = triggerQProtocol2.next( qubitProductDetailEventData1 ).value;
      expect( triggerChildEvent ).toHaveBeenCalledWith( 'ecProduct', qubitProductDetailEventData1 )

    } );
    it( ' triggerChildEvent should be triggered with VariantType/Scent for ecProduct as object  ', () => {
      const data2 = {
        'product': {
          'displayName': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'categoryPath': {
            'items': [
              {
                'name': 'Makeup',
                'actionUrl': 'https://qa3.ulta.com/makeup?N=26y1'
              },
              {
                'name': 'Face',
                'actionUrl': 'https://qa3.ulta.com/makeup-face?N=26y3'
              },
              {
                'name': 'Color Correcting',
                'actionUrl': 'https://qa3.ulta.com/makeup-face-color-correcting?N=dapq1e'
              }
            ]
          },
          'actionUrl': 'https://qa3.ulta.com/talc-free-cushion-corrector-primer-duo-spf-20?productId=xlsImpprod15451011',
          'title': 'Physicians Formula Talc-Free Cushion Corrector + Primer Duo SPF 20 | Ulta Beauty',
          'defaultSku': '2502914',
          'id': 'xlsImpprod15451011'
        },
        'purchaseEligibility':{
          'isAddToCartEligible':true
        },
        'sku': {
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2502914?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2502914',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2502914?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2502914?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2502914?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2502914?$md$'
          },
          'displayName': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'description': 'Physician\'s Formula Talc-Free Cushion Corrector + Primer Duo has a weightless mineral formula that delivers the skin-transforming benefits of color-correction and the skin-perfecting effect of priming in one revolutionary cushion.',
          'price': {
            'salePrice': null,
            'listPrice': {
              'displayAmount': '$16.99',
              'currencyCode': 'USD'
            }
          },
          'variant': {
            'variantType': 'Scent',
            'variantDesc': 'Vanilla Sugar'
          },
          'id': '2502914',
          'maxQty': 10
        },
        'brand': {
          'brandName': 'Jimmy Choo'
        }
      }

      const triggerQProtocol3 = triggerQProtocol( data2 );
      let qubitProductDetailEventData2 = {
        'eventType': 'detail',
        'product': {
          'categories': [
            'Makeup > Face > Color Correcting'
          ],
          'description': 'Physician\'s Formula Talc-Free Cushion Corrector + Primer Duo has a weightless mineral formula that delivers the skin-transforming benefits of color-correction and the skin-perfecting effect of priming in one revolutionary cushion.',
          'images': [
            'https://images.ulta.com/is/image/Ulta/2502914'
          ],
          'manufacturer': 'Jimmy Choo',
          'name': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'originalPrice': {
            'currency': 'USD',
            'value': undefined
          },
          'price': {
            'currency': 'USD',
            'value': undefined
          },
          'productId': 'xlsImpprod15451011',
          'scent': 'Vanilla Sugar',
          'sku': '2502914',
          'stock': null,
          'url': 'https://qa3.ulta.com/talc-free-cushion-corrector-primer-duo-spf-20?productId=xlsImpprod15451011'
        }
      }
      const callDescriptor = triggerQProtocol3.next( qubitProductDetailEventData2 ).value;
      expect( triggerChildEvent ).toHaveBeenCalledWith( 'ecProduct', qubitProductDetailEventData2 )

    } );
    it( ' triggerChildEvent should be triggered with VariantType/Other for ecProduct as object  ', () => {
      const data3 = {
        'product': {
          'displayName': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'categoryPath': {
            'items': [
              {
                'name': 'Makeup',
                'actionUrl': 'https://qa3.ulta.com/makeup?N=26y1'
              },
              {
                'name': 'Face',
                'actionUrl': 'https://qa3.ulta.com/makeup-face?N=26y3'
              },
              {
                'name': 'Color Correcting',
                'actionUrl': 'https://qa3.ulta.com/makeup-face-color-correcting?N=dapq1e'
              }
            ]
          },
          'actionUrl': 'https://qa3.ulta.com/talc-free-cushion-corrector-primer-duo-spf-20?productId=xlsImpprod15451011',
          'title': 'Physicians Formula Talc-Free Cushion Corrector + Primer Duo SPF 20 | Ulta Beauty',
          'defaultSku': '2502914',
          'id': 'xlsImpprod15451011'
        },
        'purchaseEligibility':{
          'isAddToCartEligible':true
        },
        'sku': {
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2502914?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2502914',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2502914?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2502914?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2502914?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2502914?$md$'
          },
          'displayName': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'description': 'Physician\'s Formula Talc-Free Cushion Corrector + Primer Duo has a weightless mineral formula that delivers the skin-transforming benefits of color-correction and the skin-perfecting effect of priming in one revolutionary cushion.',
          'price': {
            'salePrice': null,
            'listPrice': {
              'displayAmount': '$16.99',
              'currencyCode': 'USD'
            }
          },
          'variant': {
            'variantType': 'Other',
            'variantDesc': '$1'
          },
          'id': '2502914',
          'maxQty': 10
        },
        'brand': {
          'brandName': 'Jimmy Choo'
        }
      }

      const triggerQProtocol4 = triggerQProtocol( data3 );
      let qubitProductDetailEventData3 = {
        'eventType': 'detail',
        'product': {
          'categories': [
            'Makeup > Face > Color Correcting'
          ],
          'description': 'Physician\'s Formula Talc-Free Cushion Corrector + Primer Duo has a weightless mineral formula that delivers the skin-transforming benefits of color-correction and the skin-perfecting effect of priming in one revolutionary cushion.',
          'images': [
            'https://images.ulta.com/is/image/Ulta/2502914'
          ],
          'manufacturer': 'Jimmy Choo',
          'name': 'Talc-Free Cushion Corrector + Primer Duo SPF 20',
          'originalPrice': {
            'currency': 'USD',
            'value': undefined
          },
          'price': {
            'currency': 'USD',
            'value': undefined
          },
          'productId': 'xlsImpprod15451011',
          'other': '$1',
          'sku': '2502914',
          'stock': null,
          'url': 'https://qa3.ulta.com/talc-free-cushion-corrector-primer-duo-spf-20?productId=xlsImpprod15451011'
        }
      }
      const callDescriptor = triggerQProtocol4.next( qubitProductDetailEventData3 ).value;
      expect( triggerChildEvent ).toHaveBeenCalledWith( 'ecProduct', qubitProductDetailEventData3 )

    } );
  } )
  describe( 'HandleProductAnalytics -search', () => {
    const listenerSaga = cloneableGenerator( handleProductAnalytics )( 'detail' );
    let listenerSagaClone11;
    let listenerSagaClone12;
    let listenerSagaClone13;
    let listenerSagaClone14;
    const searchTerm = 'Nai'
    const productIndex = '1';
    const visualTerm = 'Nai';
    const selectedTerm = 'lip';
    const visualViewAllResults = 'true';
    const productDetails = {
      product:{
        categoryPath: {
          items: [
            {
              name: 'Nails',
              actionUrl: 'https://qa1.ulta.com/nails?N=271o'
            },
            {
              name: 'Nail Polish',
              actionUrl: 'https://qa1.ulta.com/nail-polish?N=278s'
            }
          ]
        },
        displayName:'Nail Polish'
      },
      sku:{
        id:'123',
        displayName:'shiny lipstick',
        images:{},
        price:{},
        variant:{},
        couponEligible:false
      },
      brand:{
        brandName:'OPI'
      },
      reviewSummary:{
        questionCount: 16,
        rating: 4.66,
        reviewCount: 1559
      }
    }
    const cartState = {
      quantity:5
    }
    const data = {
      'globalPageData': {
        'navigation': {
          'channel': 'product',
          'pageName': 'product:123:opi:shiny lipstick',
          'pageType': 'product detail',
          'hierarchy':'nails,nail polish'
        },
        'product': {
          brand: 'OPI',
          'description': undefined,
          'excludedFromCoupons': 'true',
          'expired': 'false',
          id:undefined,
          'imgurl': undefined,
          'listPrice': '0.00',
          'name': 'shiny lipstick',
          'saleprice': '0.00',
          'size': undefined,
          'sku': '123',
          url : undefined,
          qaCount: '16',
          reviewAverage: '4.66',
          reviewCount: '1559',
          'onlineOnly': 'false',
          'optionClick':'false'
        },
        'order':{
          'previousItemCount':5
        },
        search:{
          searchTerm:'Nai',
          noOfResults:'1',
          ...( { 'visualProductSelected':`${productIndex }:${ productDetails.brand.brandName.toLowerCase() }:${ productDetails.product.displayName.toLowerCase() }` } ),
          visualViewAllResults:'true',
          visualTerm:visualTerm.toLowerCase(),
          suggestedTerm:'lip'
        }
      }
    }
    const evt = {
      'name': 'pageNavigation'
    }
    listenerSaga.next( ).value; // call for productIndex
    listenerSagaClone14 = listenerSaga.clone();
    listenerSaga.next( productIndex ).value; // call for retrieve serach term
    listenerSaga.next( searchTerm ).value; // call for retrieveVisualTerm
    listenerSagaClone12 = listenerSaga.clone();
    listenerSaga.next( visualTerm ).value; // call for retrieveViewAllResultFlag
    listenerSagaClone13 = listenerSaga.clone();
    listenerSaga.next( visualViewAllResults ).value; // call for retrieveSelectedTerm
    listenerSagaClone11 = listenerSaga.clone();

    listenerSaga.next( selectedTerm ).value; // call for getCartState
    listenerSaga.next( cartState ).value; // call for getProductDetailsState

    it( 'should set setDataLayer with search node with proper data if product index is not empty ', () => {
      const putDescriptor = listenerSaga.next( productDetails ).value; // call for getProductDetailsState
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should not set setDataLayer with selectedTerm if selectedTerm is empty ', () => {
      const selectedTerm = '';
      const data1 = {
        'globalPageData': {
          'navigation': {
            'channel': 'product',
            'pageName': 'product:123:opi:shiny lipstick',
            'pageType': 'product detail',
            'hierarchy':'nails,nail polish'
          },
          'product': {
            brand: 'OPI',
            'description': undefined,
            'excludedFromCoupons': 'true',
            'expired': 'false',
            id:undefined,
            'imgurl': undefined,
            'listPrice': '0.00',
            'name': 'shiny lipstick',
            'saleprice': '0.00',
            'size': undefined,
            'sku': '123',
            url : undefined,
            qaCount: '16',
            reviewAverage: '4.66',
            reviewCount: '1559',
            'onlineOnly': 'false',
            'optionClick': 'false'
          },
          'order':{
            'previousItemCount':5
          },
          search:{
            searchTerm:'Nai',
            noOfResults:'1',
            visualProductSelected:'1:opi:nail polish',
            visualViewAllResults:'true',
            visualTerm:'nai'
          }
        }
      }
      listenerSagaClone11.next( );
      listenerSagaClone11.next( cartState );
      const putDescriptor = listenerSagaClone11.next( productDetails ).value;

      expect( putDescriptor ).toEqual( put( setDataLayer( data1, evt ) ) );
    } );

    it( 'should not set setDataLayer with visualTerm if visualTerm and viewAllResultFlag is empty ', () => {
      const data1 = {
        'globalPageData': {
          'navigation': {
            'channel': 'product',
            'pageName': 'product:123:opi:shiny lipstick',
            'pageType': 'product detail',
            'hierarchy':'nails,nail polish'
          },
          'product': {
            brand: 'OPI',
            'description': undefined,
            'excludedFromCoupons': 'true',
            'expired': 'false',
            id:undefined,
            'imgurl': undefined,
            'listPrice': '0.00',
            'name': 'shiny lipstick',
            'saleprice': '0.00',
            'size': undefined,
            'sku': '123',
            url : undefined,
            qaCount: '16',
            reviewAverage: '4.66',
            reviewCount: '1559',
            'onlineOnly': 'false',
            'optionClick': 'false'
          },
          'order':{
            'previousItemCount':5
          },
          search:{
            searchTerm:'Nai',
            noOfResults:'1',
            visualProductSelected:'1:opi:nail polish',
            suggestedTerm:'lip'
          }
        }
      }
      listenerSagaClone12.next( ); // call for retrieveViewAllResultFlag
      listenerSagaClone12.next( ); // call for retrieveSelectedTerm
      listenerSagaClone12.next( selectedTerm ); // call for retrieveSelectedTerm
      listenerSagaClone12.next( cartState );
      const putDescriptor = listenerSagaClone12.next( productDetails ).value;

      expect( putDescriptor ).toEqual( put( setDataLayer( data1, evt ) ) );
    } );

    it( 'should not set setDataLayer with visualViewAllResult if viewAllResultFlag is false ', () => {
      const data1 = {
        'globalPageData': {
          'navigation': {
            'channel': 'product',
            'pageName': 'product:123:opi:shiny lipstick',
            'pageType': 'product detail',
            'hierarchy':'nails,nail polish'
          },
          'product': {
            brand: 'OPI',
            'description': undefined,
            'excludedFromCoupons': 'true',
            'expired': 'false',
            id:undefined,
            'imgurl': undefined,
            'listPrice': '0.00',
            'name': 'shiny lipstick',
            'saleprice': '0.00',
            'size': undefined,
            'sku': '123',
            url : undefined,
            qaCount: '16',
            reviewAverage: '4.66',
            reviewCount: '1559',
            'onlineOnly': 'false',
            'optionClick': 'false'
          },
          'order':{
            'previousItemCount':5
          },
          search:{
            searchTerm:'Nai',
            noOfResults:'1',
            visualProductSelected:'1:opi:nail polish',
            suggestedTerm:'lip',
            visualTerm: 'nai'
          }
        }
      }
      listenerSagaClone13.next( ); // call for retrieveSelectedTerm
      listenerSagaClone13.next( selectedTerm ); // call for retrieveSelectedTerm
      listenerSagaClone13.next( cartState );
      const putDescriptor = listenerSagaClone13.next( productDetails ).value;

      expect( putDescriptor ).toEqual( put( setDataLayer( data1, evt ) ) );
    } );

    it( 'should not contain visualProductSelected in setDataLayer if productIndex is empty ', () => {
      const data1 = {
        'globalPageData': {
          'navigation': {
            'channel': 'product',
            'pageName': 'product:123:opi:shiny lipstick',
            'pageType': 'product detail',
            'hierarchy':'nails,nail polish'
          },
          'product': {
            brand: 'OPI',
            'description': undefined,
            'excludedFromCoupons': 'true',
            'expired': 'false',
            id:undefined,
            'imgurl': undefined,
            'listPrice': '0.00',
            'name': 'shiny lipstick',
            'saleprice': '0.00',
            'size': undefined,
            'sku': '123',
            url : undefined,
            qaCount: '16',
            reviewAverage: '4.66',
            reviewCount: '1559',
            'onlineOnly': 'false',
            'optionClick': 'false'
          },
          'order':{
            'previousItemCount':5
          },
          search:{
            searchTerm:'Nai',
            noOfResults:'1',
            suggestedTerm:'lip'
          }
        }
      }
      listenerSagaClone14.next( ); // call for retrieveSearchTerm
      listenerSagaClone14.next( searchTerm ); // call for retrieveVisualTerm
      listenerSagaClone14.next( ); // call for retrieveViewAllResultFlag
      listenerSagaClone14.next( ); // call for retrieveSelectedTerm
      listenerSagaClone14.next( selectedTerm );// call for select getCartState
      listenerSagaClone14.next( cartState );
      const putDescriptor = listenerSagaClone14.next( productDetails ).value;

      expect( putDescriptor ).toEqual( put( setDataLayer( data1, evt ) ) );
    } );
  } );

  describe( 'HandleProductAnalytics -should set isOptionClick as true when swatch is selected', () => {
    const listenerSaga =  handleProductAnalytics( 'detail', true );
    const searchTerm = 'Nai'
    const productIndex = '1';
    const visualTerm = 'Nai';
    const selectedTerm = 'lip';
    const visualViewAllResults = 'true';
    const productDetails = {
      product:{
        categoryPath: {
          items: [
            {
              name: 'Nails',
              actionUrl: 'https://qa1.ulta.com/nails?N=271o'
            },
            {
              name: 'Nail Polish',
              actionUrl: 'https://qa1.ulta.com/nail-polish?N=278s'
            }
          ]
        },
        displayName:'Nail Polish'
      },
      sku:{
        id:'123',
        displayName:'shiny lipstick',
        images:{},
        price:{},
        variant:{},
        couponEligible:false
      },
      brand:{
        brandName:'OPI'
      },
      reviewSummary:{
        questionCount: 16,
        rating: 4.66,
        reviewCount: 1559
      }
    }
    const cartState = {
      quantity:5
    }
    const data = {
      'globalPageData': {
        'navigation': {
          'channel': 'product',
          'pageName': 'product:123:opi:shiny lipstick',
          'pageType': 'product detail',
          'hierarchy':'nails,nail polish'
        },
        'product': {
          brand: 'OPI',
          'description': undefined,
          'excludedFromCoupons': 'true',
          'expired': 'false',
          id:undefined,
          'imgurl': undefined,
          'listPrice': '0.00',
          'name': 'shiny lipstick',
          'saleprice': '0.00',
          'size': undefined,
          'sku': '123',
          url : undefined,
          qaCount: '16',
          reviewAverage: '4.66',
          reviewCount: '1559',
          'onlineOnly': 'false',
          'optionClick':'true'
        },
        'order':{
          'previousItemCount':5
        },
        search:{
          searchTerm:'Nai',
          noOfResults:'1',
          ...( { 'visualProductSelected':`${productIndex }:${ productDetails.brand.brandName.toLowerCase() }:${ productDetails.product.displayName.toLowerCase() }` } ),
          visualViewAllResults:'true',
          visualTerm:visualTerm.toLowerCase(),
          suggestedTerm:'lip'
        }
      }
    }
    const evt = {
      'name': 'pageNavigation'
    }
    listenerSaga.next( ).value; // call for productIndex
    listenerSaga.next( productIndex ).value; // call for retrieve serach term
    listenerSaga.next( searchTerm ).value; // call for retrieveVisualTerm
    listenerSaga.next( visualTerm ).value; // call for retrieveViewAllResultFlag
    listenerSaga.next( visualViewAllResults ).value; // call for retrieveSelectedTerm

    listenerSaga.next( selectedTerm ).value; // call for getCartState
    listenerSaga.next( cartState ).value; // call for getProductDetailsState

    it( 'should set setDataLayer with isOptionClick as true when swatch is selected from product detail page and search object should be empty if search object is already present in global page data ', () => {
      const globalPageData = {
        navigation: {
          channel: 'product',
          pageName: 'product:123:opi:shiny lipstick',
          pageType: 'product detail',
          hierarchy: 'nails,nail polish'
        },
        search: {
          searchTerm: 'Nail',
          noOfResults: '1',
          ...( { 'visualProductSelected': `${productIndex}:${productDetails.brand.brandName.toLowerCase()}:${productDetails.product.displayName.toLowerCase()}` } ),
          visualViewAllResults: 'true',
          visualTerm: visualTerm.toLowerCase(),
          suggestedTerm: 'lip'
        }
      };
      global.globalPageData = globalPageData;
      const putDescriptor = listenerSaga.next( productDetails ).value; // call for getProductDetailsState
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
      expect( global.globalPageData.search ).toEqual( {} );
    } );

  } );

  describe( 'ProductDetail Virtual Try On', () => {
    history.location.search = '?productId=123567&sku=12312312&fav=true';
    history.location.pathname = appConstants.URLS.VIRTUAL_TRYON_PAGE;
    history.replace = jest.fn();
    const listenerSaga2 = cloneableGenerator( getProductDetails )( type, CONFIG, action );
    it( 'should select the makeGetSwitchesData ', () => {
      const selectDescriptor = listenerSaga2.next( ).value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should redirect to the Error 404 page if virtualTryOnEnabled is false ', () => {
      const switchData = {
        switches:{
          virtualTryOnEnabled:false
        }
      }
      const cancelDescriptor = listenerSaga2.next( switchData ).value;
      expect( history.replace ).toHaveBeenCalledWith( appConstants.URLS.ERROR_404_PAGE );
      expect( cancelDescriptor ).toEqual( cancel() );
    } );

  } );

  describe( 'ProductDetail PDP page', () => {
    history.location.search = '?productId=123567&sku=12312312&fav=true';
    const listenerSaga3 = cloneableGenerator( getProductDetails )( type, CONFIG, action );
    it( 'should call the getProductQueryParams directly for the PDP page', () => {
      history.location.pathname = '/pdp';
      const callDescriptor = listenerSaga3.next().value;
      expect( callDescriptor ).toEqual( call( getProductQueryParams ) );
    } );

  } );

} );