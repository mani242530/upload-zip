/**
 * Created by Sreekala on 8/3/18.
 */
import {
  takeEvery,
  call,
  put,
  cancelled,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { ajax } from '../../utils/ajax/ajax';
import appConstants from '../../shared/appConstants';

export const purchaseEligibility = function* ( type, CONFIG, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const query = {};
    if( process.env.NODE_ENV === 'development' ){
      query.eligibilityState = CONFIG.DEBUGGING?.PRODUCT?.eligibilityState;
    }
    query.skuId = action.data;
    const res = yield call( ajax,
      {
        type:'purchaseEligibility',
        query
      } );
    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    // get global switch data
    const switchData = yield select( makeGetSwitchesData() );
    if( switchData.switches.enableRfkEvents ){
      yield call( triggerAddToCartReflektionEvent, type, action.data );
    }

    if( switchData.switches.enableQuaziEvents ){
      const quaziData = {
        event: appConstants.EVENT_NAMES.PRODUCT_VIEWED,
        sku:[action.data]
      }
      yield put( getActionDefinition( 'quaziEvent', 'requested' )( quaziData ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
  finally {
    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'canceled' )() );
    }
  }
}
export const triggerAddToCartReflektionEvent = function* ( type, data ){
  let sourcePage;
  if( type === 'pdpPurchaseEligibility' ){
    sourcePage = 'pdp';
  }
  else if( type === 'qsPurchaseEligibility' ){
    sourcePage = 'qview';
  }
  // Trigger Reflektion analytic Event
  const reflektionData = {
    'type': 'view',
    'name': sourcePage, // value can be home|pdp|cart|category|qview
    'value': {
      'products': [
        {
          'sku': data
        }
      ]
    }
  }
  yield put( triggerReflektionEvents( reflektionData ) );
}
export default function( CONFIG ){
  return function*( ){
    const pdpServiceType = 'pdpPurchaseEligibility';
    registerServiceName( pdpServiceType );
    yield takeEvery( getServiceType( pdpServiceType, 'requested' ), purchaseEligibility, pdpServiceType, CONFIG )

    const qsServiceType = 'qsPurchaseEligibility';
    registerServiceName( qsServiceType );
    yield takeEvery( getServiceType( qsServiceType, 'requested' ), purchaseEligibility, qsServiceType, CONFIG )
  }
}
