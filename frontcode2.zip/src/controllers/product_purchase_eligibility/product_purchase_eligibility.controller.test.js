import {
  takeEvery,
  call,
  put,
  cancelled,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import { cloneableGenerator } from 'redux-saga/utils';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { ajax } from '../../utils/ajax/ajax';
import CONFIG from '../../modules/pdp/pdp.config';
import saga, {
  purchaseEligibility,
  triggerAddToCartReflektionEvent
} from './product_purchase_eligibility.controller';

import appConstants from '../../shared/appConstants';

const type = 'pdpPurchaseEligibility';
const serviceType = 'qsPurchaseEligibility';
var action = {
  data: {
    productId: 123,
    skuId: 1234
  }
}

const listenerSaga = cloneableGenerator( purchaseEligibility )( type, CONFIG, action );
let listenerSagaClone;
let listenerSagaClone1;
let listenerSagaClone2;

describe( 'purchaseEligibility sagas', () => {
  const coreSaga = saga( CONFIG )();
  registerServiceName( type );
  registerServiceName( serviceType );
  registerServiceName( 'quaziEvent' );

  it( 'should take every purchaseEligibility request from pdp', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), purchaseEligibility, type, CONFIG ) );
  } );

  it( 'should take every purchaseEligibility request from quick shop', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( serviceType, 'requested' ), purchaseEligibility, serviceType, CONFIG ) );
  } );

  describe( 'purchaseEligibility saga success path', () => {

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      let query = {};
      query.skuId = action.data;

      expect( callDescriptor ).toEqual( call( ajax, { type:'purchaseEligibility', query } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should call triggerAddToCartReflektionEvent when enableRfkEvents is true', () => {
      listenerSagaClone = listenerSaga.clone();
      listenerSagaClone1 = listenerSaga.clone();
      listenerSagaClone2 = listenerSaga.clone();
      const switchData = {
        switches:{
          enableRfkEvents:true
        }
      };
      const callDescriptor = listenerSaga.next( switchData ).value; // triggerAddToCartReflektionEvent call
      expect( callDescriptor ).toEqual( call( triggerAddToCartReflektionEvent, type, action.data ) );
    } );

    it( 'should not call triggerAddToCartReflektionEvent when enableRfkEvents is false', () => {
      // Pass modified switch data with enableRfkEvents false
      const switchData1 = {
        switches:{
          enableRfkEvents:false
        }
      };
      // when enableRfkEvents is false, triggerAddToCartReflektionEvent won't be called and execution will got to cancelled yield on purchase eligibility saga finally block
      const cancelDescriptor = listenerSagaClone.next( switchData1 ).value; // purchase eligibility saga cancelled
      expect( cancelDescriptor ).toEqual( cancelled() );
    } );

    it( 'should call triggerQuaziEvents when enableQuaziEvents is true', () => {
      const switchData = {
        switches:{
          enableQuaziEvents:true
        }
      };
      const quaziData = {
        event: appConstants.EVENT_NAMES.PRODUCT_VIEWED,
        'sku':[
          {
            'productId': 123,
            'skuId': 1234
          }
        ]
      }
      const callDescriptor = listenerSagaClone1.next( switchData ).value; // triggerQuaziEvents call
      expect( callDescriptor ).toEqual( put( getActionDefinition( 'quaziEvent', 'requested' )( quaziData ) ) );
    } );
    it( 'should not call triggerQuaziEvents when enableQuaziEvents is false', () => {
      const switchData = {
        switches:{
          enableQuaziEvents:false
        }
      };
      const cancelDescriptor = listenerSagaClone2.next( switchData ).value; // triggerQuaziEvents call
      expect( cancelDescriptor ).toEqual( cancelled() );
    } );

  } );

  describe( 'purchaseEligibility saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

  describe( 'SkuDetail saga finally block', () => {

    it( 'should cancel the event if an error occured in the service', () => {
      const cancelDescriptor = listenerSaga.next().value;
      expect( cancelDescriptor ).toEqual( cancelled() );
    } );

    it( 'should put a cancel action', () => {
      const putDescriptor = listenerSaga.next( true, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'canceled' )() ) );
    } );

  } );
  describe( 'triggerAddToCartReflektionEvent function', () => {
    it( 'should invoke triggerAddToCartReflektionEvent with proper object for product detail page(PDP)', () => {
      const listenerSagaReflektion = triggerAddToCartReflektionEvent( type, action.data.skuId );
      const reflektionData = {
        'type': 'view',
        'name': 'pdp',
        'value': {
          'products': [
            {
              'sku': action.data.skuId
            }
          ]
        }
      }
      const callDescriptor = listenerSagaReflektion.next( ).value;
      expect( callDescriptor ).toEqual( put( triggerReflektionEvents( reflektionData ) ) );
    } );
    it( 'should invoke triggerAddToCartReflektionEvent with proper object for Quick shop(qview)', () => {
      const listenerSagaReflektion = triggerAddToCartReflektionEvent( serviceType, action.data.skuId );
      const reflektionData = {
        'type': 'view',
        'name': 'qview',
        'value': {
          'products': [
            {
              'sku': action.data.skuId
            }
          ]
        }
      }
      const callDescriptor = listenerSagaReflektion.next( ).value;
      expect( callDescriptor ).toEqual( put( triggerReflektionEvents( reflektionData ) ) );
    } );
  } );

} );
