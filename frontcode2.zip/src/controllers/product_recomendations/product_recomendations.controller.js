import {
  takeEvery, call, put, select
} from 'redux-saga/effects';

import last from 'lodash/last';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import has from 'lodash/has';
import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import get from 'lodash/get';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getGTI } from '../../models/view/user/user.model';
import reflektion from '../../utils/reflektion/reflektion';
// import { get } from 'http';
import {
  ajax
} from '../../utils/ajax/ajax';
import { getProductDetailsState } from '../../models/view/product_page/product_page.model';
import { getAddToBagState } from '../../models/view/add_to_bag/add_to_bag.model';
import { getCartState } from '../../models/view/cart/cart.model';
import appConstants from '../../shared/appConstants';
import { getUserData, getUserSessionData } from '../../utils/user_storage/user_storage';

// Individual exports for testing
export const listener = function* ( type, action ){
  try {

    // Get ULTA switch data from store
    const switchData = yield select( makeGetSwitchesData() );
    // If product recs enabled make the API call to retrieve them.
    if( switchData.switches.enableRfkRecommendation ){
      // putting a latLong requested for Quazi recommendations
      if( switchData.switches.enableGeoLocationForRecs ){
        yield put( getActionDefinition( 'latLong', 'requested' )( { disableTimeout: false } ) );
      }

      yield put( getActionDefinition( type, 'loading' )() );
      let recType = '';
      let skuId;
      let pageTitle;
      const pageUrl = encodeURIComponent( global.location.pathname );
      const fingerPrintId = reflektion.retrieveReflektionTrackingId();
      const GTI = yield select( getGTI );
      const pageToRfkWidgetIdMapping = switchData.switches.pageToRfkWidgetIdMapping ;
      const storedLatLongData = yield call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA );
      let latitude = storedLatLongData?.latitude;
      let longitude = storedLatLongData?.longitude;
      let recSource = type;

      let deviceID = yield call( getUserData, 'deviceID' );

      // when a/b test is enabled for the recommendations, qubit will fire an event with the recType values
      // We will in turn fire an action with type productRecsTest and data as recType
      // based on the recType we will identify the page on which the recommendation needs to be displayed, and accordingly
      // retrieve the data which needs to be sent to the recommendation service
      if( type === 'productRecsTest' ){
        recType = action.data.recType;

        if( recType.indexOf( appConstants.REC_TYPE.PDP ) !== -1 ){
          const productDetails = yield select( getProductDetailsState );
          skuId = productDetails.sku.id;
          recSource = 'pdpProductRecs';
          pageTitle = 'PDP';
        }
        else if( recType.indexOf( appConstants.REC_TYPE.ATC ) !== -1 ){
          const addToBagDetails = yield select( getAddToBagState );
          skuId = addToBagDetails.skuId;
          recSource = 'addToBagModalProductRecs';
          pageTitle = 'Add to Cart Modal';
        }
        else if( recType.indexOf( appConstants.REC_TYPE.CART ) !== -1 ){
          const cartState = yield select( getCartState );
          skuId = last( cartState.cartPageData.cartItems.items.filter( cartItem => cartItem.displayType !== 'removed' ) ).catalogRefId.toString();
          recSource = 'productRecs';
          pageTitle = 'Cart Page';
        }
        else if( recType.indexOf( appConstants.REC_TYPE.EMPTYCART ) !== -1 ){
          recSource = 'productRecs';
          pageTitle = 'Empty Cart Page';
        }

      }

      else if( type === 'pdpProductRecs' ){
        // product recommendation PDP widget id's
        recType = pageToRfkWidgetIdMapping.productDetailsPage;
        skuId = action.data.skuId;
        pageTitle = 'PDP';
      }
      else if( type === 'addToBagModalProductRecs' ){
        // product recommendation Add to Bag Model widget id's
        recType = pageToRfkWidgetIdMapping.addToCartPage;
        skuId = action.data.skuId;
        pageTitle = 'Add to Cart Modal'
      }
      else if( type === 'productRecs' ){
        if( action.data.cartSummary.itemCount > 0 ){
          skuId = last( action.data.cartItems.items.filter( cartItem => cartItem.displayType !== 'removed' ) ).catalogRefId.toString();
          // product recommendation Cart page widget id's
          recType = pageToRfkWidgetIdMapping.cartPage;
          pageTitle = 'Cart Page';
        }
        else {
          // product recommendation Default widget id's
          recType = pageToRfkWidgetIdMapping.emptyCartPage;
          pageTitle = 'Empty Cart Page'
        }
      }
      let query = {
        recType,
        pageUrl,
        pageTitle : encodeURIComponent( pageTitle ),
        fingerPrintId,
        GTI,
        cookie_id: deviceID,
        ...( skuId && { skuId } ),
        ...( latitude && { latitude } ),
        ...( longitude && { longitude } )
      }
      const res = yield call( ajax,
        {
          type:'productRecs',
          query
        } );
      yield put( getActionDefinition( recSource, 'success' )( res.body ) );
      // trigger reflektion event when a user views product recommendation panel
      if( switchData.switches.enableRfkEvents ){
        if( has( res.body, 'data.recommendations.items' ) ){
          yield call( triggerWidgetAppearReflektionEvent, res.body.data.recommendations.items );
        }
      }
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export const triggerWidgetAppearReflektionEvent = function* ( productItems ){
  for ( let carousel of productItems ){
    // Fire the widget appear event only if it has atleast one product
    if( get( carousel, 'products.items' ) ){
      const reflektionData = {
        'type': 'widget',
        'name': 'appear',
        'value': {
          'rfkid': carousel.placementName,
          'f': 'rw'
        }
      }
      yield put( triggerReflektionEvents( reflektionData ) );
    }
  }

}
export default function* (){
  let serviceType = 'productRecs';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );

  // PDP Recommended Products
  const pdpServiceType = 'pdpProductRecs';
  registerServiceName( pdpServiceType );
  yield takeEvery( getServiceType( pdpServiceType, 'requested' ), listener, pdpServiceType );

  // Addtobagmodal Recommended Products
  const abmServiceType = 'addToBagModalProductRecs';
  registerServiceName( abmServiceType );
  yield takeEvery( getServiceType( abmServiceType, 'requested' ), listener, abmServiceType );


  // Addtobagmodal Recommended Products
  const productRecsTest = 'productRecsTest';
  registerServiceName( productRecsTest );
  yield takeEvery( getServiceType( productRecsTest, 'requested' ), listener, productRecsTest );

}