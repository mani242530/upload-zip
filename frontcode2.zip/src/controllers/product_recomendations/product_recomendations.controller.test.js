/**
 * Created by rush on 5/3/17.
 */

/**
 * LoadCart  sagas
 */

import {
  takeEvery, call, put, select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import { cloneableGenerator } from 'redux-saga/utils';
import { getGTI } from '../../models/view/user/user.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  ajax
} from '../../utils/ajax/ajax';
import reflektion from '../../utils/reflektion/reflektion';
import saga, {
  listener,
  triggerWidgetAppearReflektionEvent
} from './product_recomendations.controller';
import { getProductDetailsState } from '../../models/view/product_page/product_page.model';
import { getAddToBagState } from '../../models/view/add_to_bag/add_to_bag.model';
import { getCartState } from '../../models/view/cart/cart.model';
import { getUserData, getUserSessionData } from '../../utils/user_storage/user_storage';
import appConstants from '../../shared/appConstants';

const type = 'productRecs';
const sessionID = 12345;
let data =  {
  'cartItems': {
    'items': [{
      'catalogRefId': 'ceerf344r431'
    },
    {
      'catalogRefId': 'ceerf344r42'
    },
    {
      'catalogRefId': 'ceerf344r43'
    },
    {
      'catalogRefId': 'ceerf344r44',
      'displayType':'removed'
    }
    ]
  }

  ,
  'cartSummary': {
    'itemCount': 1

  }
};

const pdpServiceType = 'pdpProductRecs';
registerServiceName( pdpServiceType );

const addToBagServiceType = 'addToBagModalProductRecs';
registerServiceName( addToBagServiceType );


const productRecsTestServiceType = 'productRecsTest';
registerServiceName( productRecsTestServiceType );

registerServiceName( type );

const latLongServiceType = 'latLong';
registerServiceName( latLongServiceType );


const switchData = {
  switches: {
    enableRfkEvents:true,
    enableRfkRecommendation:true,
    enableGeoLocationForRecs:true,
    pageToRfkWidgetIdMapping : {
      emptyCartPage: 'RFK_RECS_EMPTYCART',
      productDetailsPage: 'RFK_RECS_PDP1',
      addToCartPage: 'RFK_RECS_A2CMODAL',
      cartPage: 'RFK_RECS_CART1,RFK_RECS_CART2'
    }
  }
};

reflektion.retrieveReflektionTrackingId = jest.fn( () => {
  return '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986'
} );



describe( 'defaultSaga Saga', () => {


  const productRecsSaga = saga();

  describe( 'listener saga success path', () => {
    const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
    const listenerSaga = listener( type, { data } );
    const listenerSaga1 = listener( type, { data } );
    it( 'should listen for the navigation requested method', () => {

      const takeEveryDescriptor = productRecsSaga.next().value;
      expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( 'productRecs', 'requested' ), listener, type ) );
    } );

    it( 'should listen for the PDP Recommended Products requested method', () =>{

      const takeEveryDescriptor = productRecsSaga.next().value;

      expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( pdpServiceType, 'requested' ), listener, pdpServiceType ) );
    } );

    it( 'should listen for the addToBagModalProductRecs requested method', () => {
      const takeEveryDescriptor1 = productRecsSaga.next().value;
      expect( takeEveryDescriptor1 ).toEqual( takeEvery( getServiceType( addToBagServiceType, 'requested' ), listener, addToBagServiceType ) );
    } );

    it( 'should listen for the productRecsTest requested method', () => {
      const takeEveryDescriptor2 = productRecsSaga.next().value;
      expect( takeEveryDescriptor2 ).toEqual( takeEvery( getServiceType( 'productRecsTest', 'requested' ), listener, productRecsTestServiceType ) );
    } );

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put latLong requested when enableGeoLocationForRecs is true', () => {
      const putDescriptor1 = listenerSaga.next( switchData ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( latLongServiceType, 'requested' )( { disableTimeout: false } ) ) );
    } );

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should select getGTI', () => {
      const selectDescriptor = listenerSaga.next( ).value;
      expect( selectDescriptor ).toEqual( select( getGTI ) );

    } );

    it( 'should call getUserSessionData', () => {
      const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
      const callDescriptor = listenerSaga.next( GTI ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should call getUserData to get deviceID ', () => {
      const latLongData = {
        latitude: 80,
        longitude: 80,
        geoLocationOverride: false,
        currentLocationRequested: true,
        isLocationBlocked: false
      }
      const callDescriptor = listenerSaga.next( latLongData ).value;
      expect( callDescriptor ).toEqual( call( getUserData, 'deviceID' ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const cookie_id = 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      let callDescriptor = listenerSaga.next( cookie_id ).value;
      let query = {
        recType: switchData.switches.pageToRfkWidgetIdMapping.cartPage, cookie_id, pageTitle: encodeURIComponent( 'Cart Page' ), fingerPrintId: '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986', GTI: '8d1da48b-b79d-412c-b3cc-20b149e5df05', latitude: 80, longitude: 80, pageUrl: encodeURIComponent( '/' ), skuId:'ceerf344r43'
      };
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should not put latlong requested when enableGeoLocationForRecs is false but put productRecs loading event', () => {
      const switchData1 = {
        switches: {
          enableRfkRecommendation:true,
          enableGeoLocationForRecs:false
        }
      };
      listenerSaga1.next( )
      const putDescriptor1 = listenerSaga1.next( switchData1 ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

  } );
  describe( 'listener saga on empty page success path', () => {
    const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
    data = {
      'cartSummary': {
        'itemCount': 0
      }
    };
    const listenSaga = listener( type, { data } );

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenSaga.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put latLong requested when enableGeoLocationForRecs is true', () => {
      const putDescriptor1 = listenSaga.next( switchData ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( latLongServiceType, 'requested' )( { disableTimeout: false } ) ) );
    } );

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should select getGTI', () => {
      const selectDescriptor = listenSaga.next().value;
      expect( selectDescriptor ).toEqual( select( getGTI ) );

    } );

    it( 'should call getUserSessionData', () => {
      const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
      const callDescriptor = listenSaga.next( GTI ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should call getUserData to get deviceID ', () => {
      const callDescriptor = listenSaga.next().value;
      expect( callDescriptor ).toEqual( call( getUserData, 'deviceID' ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const cookie_id = 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      let callDescriptor = listenSaga.next( cookie_id ).value;
      let query = {
        recType: switchData.switches.pageToRfkWidgetIdMapping.emptyCartPage, cookie_id, pageTitle: encodeURIComponent( 'Empty Cart Page' ), GTI: '8d1da48b-b79d-412c-b3cc-20b149e5df05', fingerPrintId: '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986', pageUrl: encodeURIComponent( '/' )
      };
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const putDescriptor = listenSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body ) ) );
    } );

  } );


} );

describe( 'PDP productRecommendations sagas', () => {

  let action = {
    data:{
      skuId: '2232635',
      pageTitle: 'PDP',
      GTI: '8d1da48b-b79d-412c-b3cc-20b149e5df05',
      ç: '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986',
      pageUrl: 'porefection-baked-perfecting-powder'
    }
  };
  const listenerSaga = cloneableGenerator( listener )( pdpServiceType, action );
  describe( 'productRecommendations saga success path', () => {
    const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
    let listenerSagaCloneReflektion1;

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put latLong requested when enableGeoLocationForRecs is true', () => {
      const putDescriptor1 = listenerSaga.next( switchData ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( latLongServiceType, 'requested' )( { disableTimeout: false } ) ) );
    } );

    it( 'should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( pdpServiceType, 'loading' )() ) );
    } );

    it( 'should select getGTI', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( selectDescriptor ).toEqual( select( getGTI ) );

    } );

    it( 'should call getUserSessionData', () => {
      const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
      const callDescriptor = listenerSaga.next( GTI ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should call getUserData to get deviceID ', () => {
      const callDescriptor = listenerSaga.next().value;
      listenerSagaCloneReflektion1 = listenerSaga.clone();
      expect( callDescriptor ).toEqual( call( getUserData, 'deviceID' ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const cookie_id = 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      let callDescriptor = listenerSaga.next( cookie_id ).value;
      let query = {
        recType: switchData.switches.pageToRfkWidgetIdMapping.productDetailsPage, cookie_id, pageTitle: encodeURIComponent( 'PDP' ), GTI: '8d1da48b-b79d-412c-b3cc-20b149e5df05', fingerPrintId: '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986', pageUrl: encodeURIComponent( '/' ), skuId: '2232635'
      };
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true,
            recommendations:{
              items:[
                {
                  placementName:'cart_page.rvi'
                }
              ]
            }
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( pdpServiceType, 'success' )( res.body ) ) );
    } );
    it( 'should invoke triggerWidgetAppearReflektionEvent if enableRfkEvents is enabled ', () => {
      const res = {
        body: {
          data:{
            recommendations:{
              items:[
                {
                  placementName:'cart_page.rvi'
                }
              ]
            }
          }
        }
      };
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( triggerWidgetAppearReflektionEvent, res.body.data.recommendations.items ) );

    } );
    it( 'should not invoke triggerWidgetAppearReflektionEvent if enableRfkEvents is disabled ', () => {
      const switchDataLoc = {
        switches:{
          enableRfkEvents:false,
          enableRfkRecommendation:true
        }
      };
      const res = {
        body: {
          recommendedProducts:{
            productItems:[
              {
                placmentName:'cart_page.rvi'
              }
            ]
          },
          data:{ success:true }
        }
      };
      listenerSagaCloneReflektion1.next( switchDataLoc ); // put productRecs loading
      listenerSagaCloneReflektion1.next(); // call productRecs
      listenerSagaCloneReflektion1.next( res ); // put productRecs success
      listenerSagaCloneReflektion1.next();// put productRecs failure
      const callDescriptor = listenerSagaCloneReflektion1.next()
      expect( callDescriptor.done ).toEqual( true );

    } );

  } );
  describe( 'triggerWidgetAppearReflektionEvent test cases', () => {
    const res = {
      body: {
        data:{
          success:true,
          recommendations:{
            items:[
              {
                placementName:'rfkid_31',
                products:{
                  items:[
                    {
                      adbugMessage:null,
                      product:{}
                    }
                  ]
                }
              },
              {
                placementName:'rfkid_32',
                products:null
              }
            ]
          }
        }
      }
    };
    const triggerWidgetAppearReflektionEventSaga = triggerWidgetAppearReflektionEvent( res.body.data.recommendations.items );

    it( 'should call reflektion.triggerEvent with reflektionData only if each section contain atlease one product', () => {
      const reflektionData = {
        'type': 'widget',
        'name': 'appear',
        'value': {
          'f':'rw',
          'rfkid':'rfkid_31'
        }
      }
      const callDescriptor = triggerWidgetAppearReflektionEventSaga.next( reflektionData ).value;
      expect( callDescriptor ).toEqual( put( triggerReflektionEvents( reflektionData ) ) );
    } );

    const res2 = {
      body: {
        data:{
          success:true,
          recommendations:{
            items:[
              {
                placementName:'rfkid_31',
                products:null
              }
            ]
          }
        }
      }
    };
    const triggerWidgetAppearReflektionEventSaga2 = triggerWidgetAppearReflektionEvent( res2.body.data.recommendations.items );

    it( 'should not call reflektion.triggerEvent with reflektionData if product is null', () => {
      const reflektionData2 = {
        'type': 'widget',
        'name': 'appear',
        'value': {
          'f':'rw',
          'rfkid':'rfkid_31'
        }
      }
      const callDescriptor2 = triggerWidgetAppearReflektionEventSaga2.next( reflektionData2 ).value;
      expect( callDescriptor2 ).not.toEqual( put( triggerReflektionEvents( reflektionData2 ) ) );
    } );
  } );

  describe( 'productRecommendations saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( pdpServiceType, 'failure' )( err ) ) );
    } );

  } );

} );


describe( 'Addtobagmodal productRecommendations sagas', () => {

  let action = {
    data:{
      pId: 'ceerf344r43'
    }
  };
  const listenerSaga1 = listener( addToBagServiceType, action );

  describe( 'productRecommendations saga success path', () => {
    const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga1.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put latLong requested when enableGeoLocationForRecs is true', () => {
      const putDescriptor1 = listenerSaga1.next( switchData ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( latLongServiceType, 'requested' )( { disableTimeout: false } ) ) );
    } );

    it( 'should should until the loading event has been put', () => {
      const putDescriptor1 = listenerSaga1.next().value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( addToBagServiceType, 'loading' )() ) );
    } );

    it( 'should select getGTI', () => {
      const selectDescriptor = listenerSaga1.next().value;
      expect( selectDescriptor ).toEqual( select( getGTI ) );

    } );

    it( 'should call getUserSessionData', () => {
      const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
      const callDescriptor = listenerSaga1.next( GTI ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should call getUserData to get deviceID ', () => {
      const callDescriptor = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( getUserData, 'deviceID' ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const cookie_id = 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      let callDescriptor = listenerSaga1.next( cookie_id ).value;
      let query = {
        recType: switchData.switches.pageToRfkWidgetIdMapping.addToCartPage, cookie_id, pageTitle: encodeURIComponent( 'Add to Cart Modal' ), GTI: '8d1da48b-b79d-412c-b3cc-20b149e5df05', fingerPrintId: '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986', pageUrl: encodeURIComponent( '/' )
      };
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const putDescriptor1 = listenerSaga1.next( res ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( addToBagServiceType, 'success' )( res.body ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor1 = listenerSaga1.throw( err, window ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( addToBagServiceType, 'failure' )( err ) ) );
    } );
  } );
} );



describe( 'productRecsTest sagas', () => {

  describe( 'PDP', () => {

    let action = {
      data:{
        recType: 'RFK_RECS_PDP'

      }
    };
    const listenerSaga1 = listener( productRecsTestServiceType, action );
    const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga1.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put latLong requested when enableGeoLocationForRecs is true', () => {
      const putDescriptor1 = listenerSaga1.next( switchData ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( latLongServiceType, 'requested' )( { disableTimeout: false } ) ) );
    } );

    it( 'should should until the loading event has been put', () => {
      const putDescriptor1 = listenerSaga1.next().value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( productRecsTestServiceType, 'loading' )() ) );
    } );

    it( 'should select getGTI', () => {
      const selectDescriptor = listenerSaga1.next( ).value;
      expect( selectDescriptor ).toEqual( select( getGTI ) );

    } );

    it( 'should call getUserSessionData', () => {
      const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
      const callDescriptor = listenerSaga1.next( GTI ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should call getUserData to get deviceID ', () => {
      const callDescriptor = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( getUserData, 'deviceID' ) );
    } );

    it( 'should select getProductDetailsState', () => {
      const cookie_id = 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      const selectDescriptor = listenerSaga1.next( cookie_id ).value;
      expect( selectDescriptor ).toEqual( select( getProductDetailsState ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      let callDescriptor = listenerSaga1.next( { sku: { id:'123' } } ).value;
      let query = {
        recType: action.data.recType,
        pageTitle: 'PDP',
        GTI: '8d1da48b-b79d-412c-b3cc-20b149e5df05',
        fingerPrintId: '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986',
        pageUrl: encodeURIComponent( '/' ),
        skuId:'123',
        cookie_id: 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      };
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const putDescriptor1 = listenerSaga1.next( res ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( 'pdpProductRecs', 'success' )( res.body ) ) );
    } );
  } );


  describe( 'ATC MODAL', () => {

    let action = {
      data:{
        recType: 'RFK_RECS_A2CMODAL'

      }
    };
    const listenerSaga1 = listener( productRecsTestServiceType, action );
    const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga1.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put latLong requested when enableGeoLocationForRecs is true', () => {
      const putDescriptor1 = listenerSaga1.next( switchData ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( latLongServiceType, 'requested' )( { disableTimeout: false } ) ) );
    } );

    it( 'should should until the loading event has been put', () => {
      const putDescriptor1 = listenerSaga1.next().value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( productRecsTestServiceType, 'loading' )() ) );
    } );

    it( 'should select getGTI', () => {
      const selectDescriptor = listenerSaga1.next().value;
      expect( selectDescriptor ).toEqual( select( getGTI ) );

    } );

    it( 'should call getUserSessionData', () => {
      const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
      const callDescriptor = listenerSaga1.next( GTI ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should call getUserData to get deviceID ', () => {
      const callDescriptor = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( getUserData, 'deviceID' ) );
    } );

    it( 'should select getAddToBagState', () => {
      const cookie_id = 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      const selectDescriptor = listenerSaga1.next( cookie_id ).value;
      expect( selectDescriptor ).toEqual( select( getAddToBagState ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      let callDescriptor = listenerSaga1.next( { skuId:'123' } ).value;
      let query = {
        recType: action.data.recType,
        pageTitle: encodeURIComponent( 'Add to Cart Modal' ),
        GTI: '8d1da48b-b79d-412c-b3cc-20b149e5df05',
        fingerPrintId: '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986',
        pageUrl: encodeURIComponent( '/' ),
        skuId:'123',
        cookie_id: 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      };
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const putDescriptor1 = listenerSaga1.next( res ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( 'addToBagModalProductRecs', 'success' )( res.body ) ) );
    } );
  } );


  describe( 'Cart Page', () => {

    let action = {
      data:{
        recType: 'RFK_RECS_CART'

      }
    };
    const listenerSaga1 = listener( productRecsTestServiceType, action );
    const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga1.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put latLong requested when enableGeoLocationForRecs is true', () => {
      const putDescriptor1 = listenerSaga1.next( switchData ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( latLongServiceType, 'requested' )( { disableTimeout: false } ) ) );
    } );

    it( 'should should until the loading event has been put', () => {
      const putDescriptor1 = listenerSaga1.next().value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( productRecsTestServiceType, 'loading' )() ) );
    } );

    it( 'should select getGTI', () => {
      const selectDescriptor = listenerSaga1.next().value;
      expect( selectDescriptor ).toEqual( select( getGTI ) );

    } );

    it( 'should call getUserSessionData', () => {
      const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
      const callDescriptor = listenerSaga1.next( GTI ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should call getUserData to get deviceID ', () => {
      const callDescriptor = listenerSaga1.next( GTI ).value;
      expect( callDescriptor ).toEqual( call( getUserData, 'deviceID' ) );
    } );

    it( 'should select getCartState', () => {
      const cookie_id = 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      const selectDescriptor = listenerSaga1.next( cookie_id ).value;
      expect( selectDescriptor ).toEqual( select( getCartState ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const cartState = {
        cartPageData:{
          cartItems:{
            items:[
              {
                catalogRefId:'123'
              }
            ]
          }
        }
      }
      let callDescriptor = listenerSaga1.next( cartState ).value;
      let query = {
        recType: action.data.recType,
        pageTitle: encodeURIComponent( 'Cart Page' ),
        GTI: '8d1da48b-b79d-412c-b3cc-20b149e5df05',
        fingerPrintId: '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986',
        pageUrl: encodeURIComponent( '/' ),
        skuId:'123',
        cookie_id: 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      };
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const putDescriptor1 = listenerSaga1.next( res ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( 'productRecs', 'success' )( res.body ) ) );
    } );
  } );


  describe( 'EMPTY Cart Page', () => {

    let action = {
      data:{
        recType: 'RFK_RECS_EMPTYCART'

      }
    };
    const listenerSaga1 = listener( productRecsTestServiceType, action );
    const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga1.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put latLong requested when enableGeoLocationForRecs is true', () => {
      const putDescriptor1 = listenerSaga1.next( switchData ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( latLongServiceType, 'requested' )( { disableTimeout: false } ) ) );
    } );

    it( 'should should until the loading event has been put', () => {
      const putDescriptor1 = listenerSaga1.next().value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( productRecsTestServiceType, 'loading' )() ) );
    } );

    it( 'should select getGTI', () => {
      const selectDescriptor = listenerSaga1.next( ).value;
      expect( selectDescriptor ).toEqual( select( getGTI ) );

    } );

    it( 'should call getUserSessionData', () => {
      const GTI = '8d1da48b-b79d-412c-b3cc-20b149e5df05';
      const callDescriptor = listenerSaga1.next( GTI ).value;
      expect( callDescriptor ).toEqual( call( getUserSessionData, appConstants.SESSION_STORAGE.CURRENT_LOCATION_DATA ) );
    } );

    it( 'should call getUserData to get deviceID ', () => {
      const callDescriptor = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( getUserData, 'deviceID' ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const cookie_id = 'ad211b40a3cc194b86c24792a4ae3b1fa18cb2e352c432011c98268de6018d9e'
      let callDescriptor = listenerSaga1.next( cookie_id ).value;
      let query = {
        recType: action.data.recType,
        pageTitle: encodeURIComponent( 'Empty Cart Page' ),
        GTI: '8d1da48b-b79d-412c-b3cc-20b149e5df05',
        fingerPrintId: '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986',
        pageUrl: encodeURIComponent( '/' ),
        cookie_id
      };
      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const putDescriptor1 = listenerSaga1.next( res ).value;
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( 'productRecs', 'success' )( res.body ) ) );
    } );
  } );


} );