import { takeLatest, call, put } from 'redux-saga/effects';

import {
  checkoutRedirectListener,
  types as serviceActionTypes,
  registerServiceName,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  SELECT_PRODUCT_SAMPLE_SERVICE,
  REMOVE_PRODUCT_SAMPLE_SERVICE
} from '../../events/mini_cart/mini_cart.events';


// Individual exports for testing
export const listener = function*( type, action ){

  try {
    let methodType = '';
    yield put( getActionDefinition( type, 'loading' )() );
    let query;
    if( type === 'addProductSamples' ){
      let qty = action.quantity;
      let catalogRefId = action.catalogID;
      methodType = 'post';
      query = {
        catalogRefIds: catalogRefId,
        quantity: qty
      }
    }
    else {
      methodType = 'get';
      query = {}
    }


    const res =      yield call( ajax,
      {
        type,
        method:methodType,
        query
      } );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data ){
      const qty = parseInt( res.body.data.cartSummary.itemCount, 10 );
      const loadCartMessages = res.body.data.messages;
      yield put( checkoutRedirectListener( action.history, qty, loadCartMessages ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'addProductSamples';
  // register events for the request
  registerServiceName( serviceType );
  yield takeLatest( SELECT_PRODUCT_SAMPLE_SERVICE, listener, serviceType );

  serviceType = 'removeProductSamples';
  // register events for the request
  registerServiceName( serviceType );
  yield takeLatest( REMOVE_PRODUCT_SAMPLE_SERVICE, listener, serviceType );

}
