/**
 * Page  sagas
 */

import { takeLatest, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  SELECT_PRODUCT_SAMPLE_SERVICE,
  REMOVE_PRODUCT_SAMPLE_SERVICE
} from '../../events/mini_cart/mini_cart.events';


import {
  ajax
} from '../../utils/ajax/ajax';
import saga, { listener } from './product_samples.controller';




describe( 'defaultSaga Saga of addProductSamples', () => {
  const type2 = 'addProductSamples';
  registerServiceName( type2 );

  describe( 'default saga', () => {

    const coreSaga = saga();

    it( 'should listen for the addProductSamples requested method', () => {

      const takeLatestDescriptor = coreSaga.next().value;
      expect( takeLatestDescriptor ).toEqual( takeLatest( SELECT_PRODUCT_SAMPLE_SERVICE, listener, type2 ) );
    } );

  } );

  describe( 'listener saga success path of addProductSamples', () => {
    let action = {
      query: {
        catalogRefIds: '12345',
        quantity: '1',
        _dynSessConf: '654321'
      }
    }

    const listenerSaga = listener( type2, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;
      const type = 'addProductSamples';
      registerServiceName( type );
      let query = {
        catalogRefIds: '12345',
        quantity: '1',
        _dynSessConf: '654321'
      };
      callDescriptor.CALL.args[ 0 ].query = query;
      let method = 'post';
      expect( callDescriptor ).toEqual( call( ajax, { type, method, query } ) );

    } );

    it( 'should put a success event after data is called', () => {

      let body = {
        data: {
          freeSampleInfo: {
            freeSamples: {}
          }
        }

      }

      const putDescriptor = listenerSaga.next( { body } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'success' )( body.data ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'failure' )( err ) ) );

    } );

  } );


} );

describe( 'defaultSaga Saga of removeProductSamples', () => {

  const type = 'removeProductSamples';
  registerServiceName( type );

  describe( 'default saga', () => {
    const type1 = 'removeProductSamples';
    const coreSaga1 = saga();

    it( 'should listen for the removeProductSamples requested method', () => {
      coreSaga1.next().value;
      const takeLatestDescriptor1 = coreSaga1.next().value;
      expect( takeLatestDescriptor1 ).toEqual( takeLatest( REMOVE_PRODUCT_SAMPLE_SERVICE, listener, type ) );
    } );

  } );

  describe( 'listener saga success path of addProductSamples', () => {
    let action = {
      query: {
        _dynSessConf: '654321'
      }
    }

    const listenerSaga = listener( type, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next().value;

      let query = {
        _dynSessConf: '654321'
      };
      let method = 'get';
      callDescriptor.CALL.args[ 0 ].query = query;
      expect( callDescriptor ).toEqual( call( ajax, { type, method, query } ) );

    } );

    it( 'should put a success event after data is called', () => {

      let body = {
        data:{
          freeSampleInfo: {
            freeSamples: {}
          }
        }
      }

      const putDescriptor = listenerSaga.next( { body } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( body.data ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      let err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );

  } );


} );
