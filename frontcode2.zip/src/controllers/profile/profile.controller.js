import { takeEvery, call, put } from 'redux-saga/effects';

import isUndefined from 'lodash/isUndefined';
import has from 'lodash/has';


import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

// Individual exports for testing
export const listener = function*( type, data ){

  try {


    yield put( getActionDefinition( type, 'loading' )() );

    let query = {};

    if( process.env.NODE_ENV === 'development' ){
      query.__FORCE_RES = 'signedin';
    }

    const res = yield call( ajax, { type, query } );

    yield put( getActionDefinition( type, 'success' )( res.body ) ) ;

    // Analytics tracking code begin
    if( !isUndefined( res.body ) && has( res.body, 'profileInfo.firstName' ) ){

      const {
        profileInfo,
        rewardsInfo
      } = res.body;

      const data = {
        'globalPageData': {
          'profile': {
            'email': profileInfo.email,
            'hashedEmail': profileInfo.hashedEmail,
            'firstName':profileInfo.firstName,
            'lastName':profileInfo.lastName
          },
          'rewards': {
            'isCardHolder': rewardsInfo.isCardHolder,
            'loyaltyId':rewardsInfo.memberNumber,
            'programId':rewardsInfo.planId,
            'memberSince':rewardsInfo.memberSince,
            'platinumMember':rewardsInfo.platinum,
            'platinumMemberType': ( has( profileInfo, 'beautyClubPlanType.planDesc' ) ? profileInfo.beautyClubPlanType.planDesc.toLowerCase() : '' ),
            'userType': ( has( profileInfo, 'beautyClubPlanType.planDesc' ) ? 'reg - loyalty member' : 'reg - non-loyalty member' )
          }
        }
      }

      yield put( setDataLayer( data ) );

    }
    // Analtyics tracking code end

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'profile';

  // register events for the request
  registerServiceName( serviceType );

  yield takeEvery( getServiceType( 'profile', 'requested' ), listener, serviceType );


}
