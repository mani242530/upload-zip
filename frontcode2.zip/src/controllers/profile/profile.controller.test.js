/**
* Profile  sagas
*/

import { takeEvery, call, put } from 'redux-saga/effects';
import { has } from 'lodash';
import { cloneableGenerator } from 'redux-saga/lib/utils';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import saga, { listener } from './profile.controller';


import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import {
  ajax
} from '../../utils/ajax/ajax';


const type = 'profile';

describe( 'ProfileSaga', () => {

  registerServiceName( type );

  describe( 'profile saga', () => {

    const userSaga = saga();
    const profileSaga  = saga();

    it( 'should listen for the navigation requested method', () => {

      const takeEveryDescriptor = profileSaga .next().value;

      takeEvery( getServiceType( 'profile', 'requested' ), listener, type );

    } );

  } );

  describe( 'listener saga success/failure path', () => {

    const res = {
      body: {
        profileInfo: {
          email: 'test.function@ulta.com',
          hashedEmail: 'test.hashed@ulta.com',
          firstName: 'Test',
          lastName: 'Function',
          beautyClubPlanType: {
            planDesc: 'Diamond'
          }
        },
        rewardsInfo: {
          isCardHolder: false,
          memberNumber: '2919123456789',
          planId: '2',
          memberSince: '11/6/2017',
          platinum: 'true'
        }
      }
    };
    const listenerSaga = cloneableGenerator( listener )( type, {} ) ;

    it( 'should put the loading event', () => {

      const putDescriptor = listenerSaga.next( process ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;
      const data = {
        type,
        query: { }
      };

      expect( callDescriptor ).toEqual( call( ajax, data ) );

    } );
    let listenerSagaClone;
    it( 'should put a success event after data is called', () => {
      listenerSagaClone = listenerSaga.clone();
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body ) ) );

    } );

    it( 'should put a setDataLayer action with proper values set for platinumMemberType and usertype when there is value for beautyClubPlanType in the response', () => {

      const data = {
        globalPageData: {
          profile: {
            email: res.body.profileInfo.email,
            hashedEmail: res.body.profileInfo.hashedEmail,
            firstName: res.body.profileInfo.firstName,
            lastName: res.body.profileInfo.lastName
          },
          rewards: {
            isCardHolder: res.body.rewardsInfo.isCardHolder,
            loyaltyId: res.body.rewardsInfo.memberNumber,
            programId: res.body.rewardsInfo.planId,
            memberSince: res.body.rewardsInfo.memberSince,
            platinumMember: res.body.rewardsInfo.platinum,
            platinumMemberType: 'diamond',
            userType: 'reg - loyalty member'
          }
        }
      };
      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( setDataLayer( data ) ) );

    } );

    it( 'should put a setDataLayer action with empty string value set for platinumMemberType and usertype when there is no value  for beautyClubPlanType in the service response', () => {
      const res1 = {
        body: {
          profileInfo: {
            email: 'test.function@ulta.com',
            hashedEmail: 'test.hashed@ulta.com',
            firstName: 'Test',
            lastName: 'Function'
          },
          rewardsInfo: {
            isCardHolder: false,
            memberNumber: '2919123456789',
            planId: '2',
            memberSince: '11/6/2017',
            platinum: 'true'
          }
        }
      };

      const data = {
        globalPageData: {
          profile: {
            email: res.body.profileInfo.email,
            hashedEmail: res.body.profileInfo.hashedEmail,
            firstName: res.body.profileInfo.firstName,
            lastName: res.body.profileInfo.lastName
          },
          rewards: {
            isCardHolder: res.body.rewardsInfo.isCardHolder,
            loyaltyId: res.body.rewardsInfo.memberNumber,
            programId: res.body.rewardsInfo.planId,
            memberSince: res.body.rewardsInfo.memberSince,
            platinumMember: res.body.rewardsInfo.platinum,
            platinumMemberType: '',
            userType: 'reg - non-loyalty member'
          }
        }
      };
      listenerSagaClone.next( res1 );
      const putDescriptor = listenerSagaClone.next().value;

      expect( putDescriptor ).toEqual( put( setDataLayer( data ) ) );

    } );

    describe( 'listener saga failure path', () => {

      it( 'should put a failure event if no data is returned from the service', () => {

        global.TRACK_SAGA_FAILURES = true;
        const err = {
          statusText:'some failure message'
        }
        const putDescriptor = listenerSaga.throw( err ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

      } );

      it( 'should throw the error', () => {

        expect( () => {
          listenerSaga.next().throw( err )
        } ).toThrow();

      } );

    } );

  } );

} );
