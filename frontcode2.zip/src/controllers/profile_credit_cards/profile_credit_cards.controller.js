/**
 * ProfileCreditCards sagas
 */
import { takeEvery, call, put } from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ajax
} from '../../utils/ajax/ajax';


// Individual exports for testing
export const listener = function*( type, action ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const res = yield call( ajax, { type } );

    yield put( getActionDefinition( type, 'success' )( { data:res.body.data, view:action.data.view } ) );

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'profileCreditCards';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( 'profileCreditCards', 'requested' ), listener, serviceType );
}
