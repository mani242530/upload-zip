/**
 * ProfileCreditCards  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';
import { createMockTask } from 'redux-saga/lib/utils';
import Cookies from 'js-cookie';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  ajax
} from '../../utils/ajax/ajax';
import saga, { listener } from './profile_credit_cards.controller';



const type = 'profileCreditCards';
const action = {
  data: {
    view:'list'
  }
}

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );

  describe( 'listener saga success path', () => {

    const listenerSaga = listener( type, action );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor  = listenerSaga.next().value;


      expect( callDescriptor ).toEqual( call( ajax, { type } ) );

    } );

    it( 'should put a success event after data is called', () => {

      const res = {
        body: {
          data:{
            title: 'test',
            status: 'ok'
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { data:res.body.data, view:action.data.view } ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should throw the error', () => {

      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }

      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );

  } );


} );
