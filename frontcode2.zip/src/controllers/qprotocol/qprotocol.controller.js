import {
  takeEvery,
  call
} from 'redux-saga/effects';


import get from 'lodash/get';
import has from 'lodash/has';
import isEmpty from 'lodash/isEmpty';
import qProtocol from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';
import { TRIGGER_BASKET_EVENTS } from '../../events/qprotocol/qprotocol.events'
import { getMiniBagCartServiceData } from '../../models/view/mini_cart/mini_cart.model';


const {
  triggerChildEvent
} = qProtocol;

export const triggerQProtocolEvent = function* ( action ){
  if( action.data.cartSummary.itemCount > 0 ){
    yield call( triggerBasketEvents, action.data );
  }
}

export const triggerBasketEvents = function( data ){

  let ecBasket = getBasketObject( data );

  // should fire ecbasket event only if non-removed items are available
  if( ecBasket.items.length ){
    triggerChildEvent( 'ecBasketSummary', ecBasket.summary );

    // ecBasketItem start
    ecBasket.items.forEach( function( item ){
      triggerChildEvent( 'ecBasketItem', item );
    } );
  }
}


// this method will return object with Basket Item and Summary properties
const getBasketObject = ( data )=>{
  let cartSummary = data.cartSummary;
  let currencyCode = get( cartSummary, 'currencyCode' ) || 'USD';

  // default estimated tax value = 0.00 and if estimatedTax is a valid number add it to subtotal
  let basketSubtotalVal = cartSummary.subTotal + ( get( cartSummary, 'estimatedTax' ) || 0 );

  let basketSubTotalObj = { currency: currencyCode, value: parseFloat( basketSubtotalVal.toFixed( 2 ) ) };
  let hasEstimatedTax = !!cartSummary.estimatedTax;

  let basketSubtotal = hasEstimatedTax ?
    { subtotalIncludingTax: basketSubTotalObj } : { subtotal: basketSubTotalObj };

  let ecBasketSummaryObj = {
    basket: {
      ...( basketSubtotal ),
      total: {
        currency: currencyCode,
        value: cartSummary.estimatedTotal
      },
      quantity: parseInt( cartSummary.itemCount, 10 )// parse string itemCount to integer for matching qubit data type
    }
  };

  const basketSummary = {
    total:{
      value: cartSummary.estimatedTotal,
      currency: currencyCode
    },
    quantity: parseInt( cartSummary.itemCount, 10 )
  };
  const cartSubtotal = {
    value: cartSummary.subTotal,
    currency: currencyCode
  };
  let ecBasketItemsObj = [];
  // ecBasketItem start
  // should filter removed items
  data.cartItems && data.cartItems.items.filter( item => item.displayType !== 'removed' ).forEach( function( cartItem ){
    let regularPrice = get( cartItem, 'priceInfo.regularPrice' );
    let price = get( cartItem, 'priceInfo.salePrice' ) || regularPrice;
    // default product.images value
    let cartItemImages = null;

    // if cartItem.images array exist and not empty
    if( cartItem.images ){
      cartItemImages = [cartItem.images.blowupImage]
    }

    let ecBasketItemData = {
      basket:basketSummary,
      product : {
        sku : cartItem.catalogRefId,
        productId: cartItem.productId,
        name : cartItem.productDisplayName,
        stock :null,
        ...( price && {
          price: {
            currency: currencyCode,
            // getting price as string,prefix with $.so to trim $ we are using Slice here
            value: parseFloat( price.slice( 1 ) )
          }
        } ),
        ...( regularPrice && {
          originalPrice: {
            currency: currencyCode,
            // getting regularPrice as string,prefix with $.so to trim $ we are using Slice here
            value: parseFloat( regularPrice.slice( 1 ) )
          }
        } ),
        url : cartItem.productURL,
        description :cartItem.skuDisplayName,
        categories : [cartItem.categoryName],
        images : cartItemImages
      },
      // bag page backend response has quantity as object and checkout page response has quantity as number
      quantity: has( cartItem, 'quantity.value' ) ? cartItem.quantity.value : cartItem.quantity,
      subtotalIncludingTax: basketSubTotalObj,
      subtotal: {
        value: parseFloat( cartSummary.subTotal.toFixed( 2 ) ),
        currency: currencyCode
      }
    }
    ecBasketItemsObj.push( ecBasketItemData );
  } );
  return { summary: ecBasketSummaryObj, items: ecBasketItemsObj }
}

export default function*(){
  yield takeEvery( TRIGGER_BASKET_EVENTS, triggerQProtocolEvent );
}
