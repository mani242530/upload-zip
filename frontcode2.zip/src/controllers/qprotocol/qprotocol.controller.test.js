
import {
  takeEvery,
  call
} from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/lib/utils';

import qProtocol from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';
import {
  TRIGGER_BASKET_EVENTS
} from '../../events/qprotocol/qprotocol.events'
import saga, {
  triggerBasketEvents,
  triggerQProtocolEvent
} from './qprotocol.controller';


jest.mock( 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol', () => {
  return { triggerChildEvent:jest.fn() }
} );


let action = {
  data:{
    'cartSummary': {
      'shippingCost': 5.95,
      'subTotal': 160,
      'itemCount': '9',
      'orderGiftWrapAmt': 3.99,
      'additionalDiscount': null,
      'couponDiscount': 0,
      'estimatedTax': '0',
      'estimatedTotal': 170,
      'currencyCode': 'USD',
      'rewardPointsDiscount': -3.00
    },
    'id': 'US463704869',
    'cartItems': {
      'items': [
        {
          'couponApplied': false,
          'brandName': 'Laura Geller Beauty',
          'quantity': {
            'value' : 2
          },
          'productId': 'xlsImpprod3570045',
          'excludedFromCoupon': false,
          'adbugMessageMap': null,
          'catalogRefId': '2230775',
          'hazmatCode': 'Ships within Continental US only',
          'discountMessage': '',
          'commerceItemid': 'ci270000001',
          'priceInfo': {
            'salePrice': null,
            'regularPrice': '$12.00',
            'unitPriceMessage': '2 @ $6.00'
          },
          'productDisplayName': 'Salon Nail Clear Topcoat',
          'images': {
            'blowupImage': 'test'
          },
          'variantInfo': {

          },
          'skuDisplayName': 'Salon Topcoat',
          'productURL': '/test',
          'itemType': 'cartItem'
        }
      ]
    }
  }
};
let checkoutServiceResponse = {
  'cartSummary': {
    'shippingCost': 5.95,
    'subTotal': 160.98999999999998,
    'itemCount': '9',
    'orderGiftWrapAmt': 3.99,
    'additionalDiscount': null,
    'couponDiscount': 0,
    'estimatedTax': 1,
    'estimatedTotal': 170.93,
    'currencyCode': 'USD',
    'rewardPointsDiscount': -3.00
  },
  'id': 'US463704869',
  'cartItems': {
    'items': [
      {
        'couponApplied': false,
        'brandName': 'Laura Geller Beauty',
        'quantity':2,
        'productId': 'xlsImpprod3570045',
        'excludedFromCoupon': false,
        'adbugMessageMap': null,
        'catalogRefId': '2230775',
        'hazmatCode': 'Ships within Continental US only',
        'discountMessage': '',
        'commerceItemid': 'ci270000001',
        'priceInfo': {
          'salePrice': null,
          'regularPrice': '$12.00',
          'unitPriceMessage': '2 @ $6.00'
        },
        'productDisplayName': 'Salon Nail Clear Topcoat',
        'images': {
          'blowupImage':'test'
        },
        'variantInfo': {

        },
        'skuDisplayName': 'Salon Topcoat',
        'productURL': 'test',
        'itemType': 'cartItem',
        'maxQty': 2,
        'categoryName': 'Nail Polish'
      }
    ]
  }
}

const listenerSaga = triggerQProtocolEvent( action );

describe( 'triggerQProtocolEvent sagas', () => {

  it( 'should call the triggerBasketEvents if the itemCount is greater than 0', () => {
    const callDescriptor = listenerSaga.next( action ).value;
    expect( callDescriptor ).toEqual( call( triggerBasketEvents, action.data ) );
  } );

  let action1 = { data: { cartSummary: { itemCount: 0 } } }

  it( 'should not call the triggerBasketEvents, if the itemCount is 0', () => {
    const callDescriptor = triggerQProtocolEvent( action1 ).next().done;
    expect( callDescriptor ).toEqual( true );
  } );
} )

let cartServiceResponse = {
  'cartSummary': {
    'shippingCost': 5.95,
    'subTotal': 160.98999999999998,
    'itemCount': '9',
    'orderGiftWrapAmt': 3.99,
    'additionalDiscount': null,
    'couponDiscount': 0,
    'estimatedTax': 1,
    'estimatedTotal': 170.93,
    'currencyCode': 'USD',
    'rewardPointsDiscount': -3.00
  },
  'id': 'US463704869',
  'cartItems': {
    'items': [
      {
        'couponApplied': false,
        'brandName': 'Laura Geller Beauty',
        'quantity': {
          'value':2
        },
        'productId': 'xlsImpprod3570045',
        'excludedFromCoupon': false,
        'adbugMessageMap': null,
        'catalogRefId': '2230775',
        'hazmatCode': 'Ships within Continental US only',
        'discountMessage': '',
        'commerceItemid': 'ci270000001',
        'priceInfo': {
          'salePrice': null,
          'regularPrice': '$12.00',
          'unitPriceMessage': '2 @ $6.00'
        },
        'productDisplayName': 'Salon Nail Clear Topcoat',
        'images': {
          'blowupImage':'test'
        },
        'variantInfo': {

        },
        'skuDisplayName': 'Salon Topcoat',
        'productURL': 'test',
        'itemType': 'cartItem',
        'maxQty': 2,
        'categoryName': 'Nail Polish'
      }
    ]
  }
}


describe( 'triggerBasketEvents sagas', () => {
  it( ' triggerChildEvent should be triggered from cart page with ecBasketItem/Summary as object  ', () => {
    triggerBasketEvents( cartServiceResponse );
    let ecBasket = {
      'summary': {
        'basket': {
          'subtotalIncludingTax': {
            'currency': 'USD',
            'value': 161.99
          },
          'total': {
            'currency': 'USD',
            'value': 170.93
          },
          'quantity': 9
        }
      },
      'items': [
        {
          'basket': {
            'total': {
              'value': 170.93,
              'currency': 'USD'
            },
            'quantity': 9
          },
          'product': {
            'sku': '2230775',
            'productId': 'xlsImpprod3570045',
            'name': 'Salon Nail Clear Topcoat',
            'stock': null,
            'price': {
              'currency': 'USD',
              'value': 12
            },
            'originalPrice': {
              'currency': 'USD',
              'value': 12
            },
            'url': 'test',
            'description': 'Salon Topcoat',
            'categories': ['Nail Polish'],
            'images': ['test']
          },
          'quantity': 2,
          'subtotalIncludingTax': {
            'currency': 'USD',
            'value': 161.99
          },
          'subtotal': {
            'value': 160.99,
            'currency': 'USD'
          }
        }
      ]
    }
    expect( qProtocol.triggerChildEvent ).toHaveBeenCalledWith( 'ecBasketSummary', ecBasket.summary )
    expect( qProtocol.triggerChildEvent ).toHaveBeenCalledWith( 'ecBasketItem', ecBasket.items[0] )

  } );

  it( 'triggerChildEvent should be triggered from checkout page with ecBasketItem/Summary as object  ', () => {
    triggerBasketEvents( checkoutServiceResponse );
    let ecBasket = {
      'summary': {
        'basket': {
          'subtotalIncludingTax': {
            'currency': 'USD',
            'value': 161.99
          },
          'total': {
            'currency': 'USD',
            'value': 170.93
          },
          'quantity': 9
        }
      },
      'items': [
        {
          'basket': {
            'total': {
              'value': 170.93,
              'currency': 'USD'
            },
            'quantity': 9
          },
          'product': {
            'sku': '2230775',
            'productId': 'xlsImpprod3570045',
            'name': 'Salon Nail Clear Topcoat',
            'stock': null,
            'price': {
              'currency': 'USD',
              'value': 12
            },
            'originalPrice': {
              'currency': 'USD',
              'value': 12
            },
            'url': 'test',
            'description': 'Salon Topcoat',
            'categories': ['Nail Polish'],
            'images': ['test']
          },
          'quantity': 2,
          'subtotalIncludingTax': {
            'currency': 'USD',
            'value': 161.99
          },
          'subtotal': {
            'value': 160.99,
            'currency': 'USD'
          }
        }
      ]
    }
    expect( qProtocol.triggerChildEvent ).toHaveBeenCalledWith( 'ecBasketSummary', ecBasket.summary )
    expect( qProtocol.triggerChildEvent ).toHaveBeenCalledWith( 'ecBasketItem', ecBasket.items[0] )

  } );

  it( ' shoule not invoke triggerChildEvent when cartItems is null ', () => {
    qProtocol.triggerChildEvent.mockReset();
    checkoutServiceResponse.cartItems = null;
    const listenerSaga2 = triggerBasketEvents( checkoutServiceResponse );
    expect( qProtocol.triggerChildEvent ).not.toBeCalled();

  } );
} )


describe( 'triggerBasketEvents sagas', () => {
  it( ' triggerChildEvent should be triggered with ecBasketItem/Summary object without price', () => {

    let data7 = {
      'cartSummary': {
        'shippingCost': 5.95,
        'subTotal': 160.98999999999998,
        'itemCount': '9',
        'orderGiftWrapAmt': 3.99,
        'additionalDiscount': null,
        'couponDiscount': 0,
        'estimatedTax': 1,
        'estimatedTotal': 170.93,
        'currencyCode': 'USD',
        'rewardPointsDiscount': -3.00
      },
      'id': 'US463704869',
      'cartItems': {
        'items': [
          {
            'couponApplied': false,
            'brandName': 'Laura Geller Beauty',
            'quantity': {
              'value' : 2
            },
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': false,
            'adbugMessageMap': null,
            'catalogRefId': '2230775',
            'hazmatCode': 'Ships within Continental US only',
            'discountMessage': '',
            'commerceItemid': 'ci270000001',
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'images': {
              'blowupImage': 'test'
            },
            'variantInfo': {
            },
            'skuDisplayName': 'Salon Topcoat',
            'productURL': 'test',
            'itemType': 'cartItem',
            'maxQty': 2,
            'categoryName': 'Nail Polish'
          }
        ]
      },
      source:'minicart'
    }
    const listenerSaga7 = triggerBasketEvents( data7 );

    let ecBasket7 = {
      'summary': {
        'basket': {
          'subtotalIncludingTax': {
            'currency': 'USD',
            'value': 161.99
          },
          'total': {
            'currency': 'USD',
            'value': 170.93
          },
          'quantity':9
        }
      },
      'items': [
        {
          'basket': {
            'total': {
              'value': 170.93,
              'currency': 'USD'
            },
            'quantity': 9
          },
          'product': {
            'sku': '2230775',
            'productId': 'xlsImpprod3570045',
            'name': 'Salon Nail Clear Topcoat',
            'stock': null,
            'url': 'test',
            'description': 'Salon Topcoat',
            'categories': ['Nail Polish'],
            'images': ['test']
          },
          'quantity': 2,
          'subtotal': {
            'value': 160.99,
            'currency': 'USD'
          },
          'subtotalIncludingTax': {
            'currency': 'USD',
            'value': 161.99
          }
        }
      ]
    }
    expect( qProtocol.triggerChildEvent ).toHaveBeenCalledWith( 'ecBasketSummary', ecBasket7.summary )
    expect( qProtocol.triggerChildEvent ).toHaveBeenCalledWith( 'ecBasketItem', ecBasket7.items[0] )

  } );
} )


describe( 'triggerBasketEvents sagas', () => {
  it( ' triggerChildEvent should be triggered with ecBasketItem/Summary object without price', () => {
    let data7 = {
      'cartSummary': {
        'shippingCost': 5.95,
        'subTotal': 160.98999999999998,
        'itemCount': '9',
        'orderGiftWrapAmt': 3.99,
        'additionalDiscount': null,
        'couponDiscount': 0,
        'estimatedTax': null,
        'estimatedTotal': 170.93,
        'currencyCode': 'USD',
        'rewardPointsDiscount': -3.00
      },
      'id': 'US463704869',
      'cartItems': {
        'items': [
          {
            'couponApplied': false,
            'brandName': 'Laura Geller Beauty',
            'quantity': {
              'value':2
            },
            'productId': 'xlsImpprod3570045',
            'excludedFromCoupon': false,
            'adbugMessageMap': null,
            'catalogRefId': '2230775',
            'hazmatCode': 'Ships within Continental US only',
            'discountMessage': '',
            'commerceItemid': 'ci270000001',
            'productDisplayName': 'Salon Nail Clear Topcoat',
            'priceInfo': {
              'salePrice': null,
              'regularPrice': '$12.00',
              'unitPriceMessage': '2 @ $6.00'
            },
            'images': {
              'blowupImage': 'test'
            },
            'variantInfo': {
            },
            'skuDisplayName': 'Salon Topcoat',
            'productURL': 'test',
            'itemType': 'cartItem',
            'maxQty': 2,
            'categoryName': 'Nail Polish'
          }
        ]
      }
    }

    triggerBasketEvents( data7 );
    let ecBasket7 = {
      'summary': {
        'basket': {
          'subtotal': {
            'currency': 'USD',
            'value': 160.99
          },
          'total': {
            'currency': 'USD',
            'value': 170.93
          },
          'quantity': 9
        }
      },
      'items': [
        {
          'basket': {
            'total': {
              'value': 170.93,
              'currency': 'USD'
            },
            'quantity': 9
          },
          'product': {
            'sku': '2230775',
            'productId': 'xlsImpprod3570045',
            'name': 'Salon Nail Clear Topcoat',
            'stock': null,
            'url': 'test',
            'description': 'Salon Topcoat',
            'categories': ['Nail Polish'],
            'images': ['test'],
            'originalPrice': {
              'currency': 'USD',
              'value': 12
            },
            'price': {
              'currency'
              : 'USD',
              'value': 12
            }
          },
          'quantity': 2,
          'subtotal': {
            'value': 160.99,
            'currency': 'USD'
          },
          'subtotalIncludingTax': {
            'currency': 'USD',
            'value': 160.99
          }

        }
      ]
    }
    expect( qProtocol.triggerChildEvent ).toHaveBeenCalledWith( 'ecBasketSummary', ecBasket7.summary )
    expect( qProtocol.triggerChildEvent ).toHaveBeenCalledWith( 'ecBasketItem', ecBasket7.items[0] )

  } );
} )


describe( 'triggerQProtocolEvent saga ', () =>{
  it( 'should listen to the triggerQProtocolEvent method', () =>{
    const listenerSaga6 = saga( );
    const takeLatestDescriptor = listenerSaga6.next( ).value;

    expect( takeLatestDescriptor ).toEqual(
      takeEvery( TRIGGER_BASKET_EVENTS, triggerQProtocolEvent )
    );
  } );
} );


describe( 'triggerBasketEvents sagas - test for images ', () => {
  it( ' ecBasketItem should be triggered if product images array exist', () => {
    triggerBasketEvents( cartServiceResponse );
    let ecBasket8 = {
      'summary': {
        'basket': {
          'subtotalIncludingTax': {
            'currency': 'USD',
            'value': 160.98
          },
          'total': {
            'currency': 'USD',
            'value': 170.93
          }
        }
      },
      'items': [
        {
          'basket': {
            'total': {
              'value': 170.93,
              'currency': 'USD'
            },
            'quantity': 9
          },
          'product': {
            'sku': '2230775',
            'productId': 'xlsImpprod3570045',
            'name': 'Salon Nail Clear Topcoat',
            'originalPrice': {
              'currency': 'USD',
              'value': 12
            },
            'price': {
              'currency'
              : 'USD',
              'value': 12
            },
            'stock': null,
            'url': 'test',
            'description': 'Salon Topcoat',
            'categories': ['Nail Polish'],
            'images': ['test']
          },
          'quantity': 2,
          'subtotal': {
            'value': 160.99,
            'currency': 'USD'
          },
          'subtotalIncludingTax':
           {
             'currency': 'USD',
             'value': 161.99
           }
        }
      ]
    }
    expect( qProtocol.triggerChildEvent ).toHaveBeenCalledWith( 'ecBasketItem', ecBasket8.items[0] );

  } );
} )
