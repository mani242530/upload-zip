import {
  takeEvery,
  call,
  select,
  put,
  take
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ajax
} from '../../utils/ajax/ajax';
import { getGTI } from '../../models/view/user/user.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { getUserData } from '../../utils/user_storage/user_storage';


export const triggerQuaziEvent = function* ( type, CONFIG, action ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const GTI = yield select( getGTI );


    yield put( getActionDefinition( 'deviceID', 'requested' )() );
    const deviceID = yield take( getServiceType( 'deviceID', 'success' ) );

    const values = {
      timestamp: new Date().toISOString(),
      meta:{ GTI },
      cookie_id: deviceID.data
    }
    const customHeaders = { apiKey:CONFIG.QUAZI_API_KEY };

    const switchData = yield select( makeGetSwitchesData() );
    yield call(
      ajax, {
        type:'quaziEventAPI',
        method:'post',
        dynamicURL:switchData.switches.quaziEventURL,
        values:{
          ...action.data,
          ...values
        },
        customHeaders
      }
    );
    yield put( getActionDefinition( type, 'success' )() );
  }
  catch ( err ){
    console.error( err ); //eslint-disable-line
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }

}

export default function( CONFIG ){
  return function* (){
    const quaziEventType = 'quaziEvent';
    registerServiceName( quaziEventType );
    yield takeEvery( getServiceType( quaziEventType, 'requested' ), triggerQuaziEvent, quaziEventType, CONFIG );
  }
}