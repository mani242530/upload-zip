import {
  takeEvery,
  call,
  select,
  put,
  take
} from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/utils';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  ajax
} from '../../utils/ajax/ajax';
import { getGTI } from '../../models/view/user/user.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import saga, { triggerQuaziEvent } from './quazi_event.controller';
import CONFIG from '../../config';
import appConstants from '../../shared/appConstants';

describe( 'triggerQuaziEvent test cases', () => {

  const constantDate = new Date( '2017-06-13T04:41:20' );
  const deviceID = 'deviceID';
  registerServiceName( deviceID );


  // the below helps to mock the date so that it returns the same date while running the tests
  /* eslint no-global-assign:off*/
  Date = class extends Date{
    constructor(){
      return constantDate
    }
  }

  let action =
  {
    data:{
      event: appConstants.EVENT_NAMES.PRODUCT_VIEWED,
      'sku':[
        {
          'productId': 123,
          'skuId': 1234
        }
      ]
    }
  }

  const type = 'quaziEvent';

  describe( 'triggerQuaziEvent saga ', () =>{
    const coreSaga = saga( CONFIG )();
    it( 'should take every quaziEvent request', () => {
      const takeEveryDescriptor = coreSaga.next().value;
      expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), triggerQuaziEvent, type, CONFIG ) );
    } );
  } );


  const listenerSaga = cloneableGenerator( triggerQuaziEvent )( type, CONFIG, action );
  let listenerSagaClone;

  it( 'should put loading event', () => {

    const putDescriptor = listenerSaga.next( ).value;

    expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

  } );

  it( 'should select getGTI', () => {

    listenerSagaClone = listenerSaga.clone();
    const selectDescriptor = listenerSaga.next( ).value;

    expect( selectDescriptor ).toEqual( select( getGTI ) );

  } );

  it( 'should put an event to trigger the deviceID', () => {
    let GTI = 'UID12344';
    const putDescriptor = listenerSaga.next( GTI ).value;
    expect( putDescriptor ).toEqual( put( getActionDefinition( deviceID, 'requested' )() ) );
  } );

  it( 'should put success event', () => {
    const putDescriptor = listenerSaga.next( ).value;

    expect( putDescriptor ).toEqual( take( getServiceType( deviceID, 'success' ) ) );

  } );

  it( 'should do a select on makeGetSwitchesData', () => {
    let cookie_id = {
      data: '215b64b9-a57d-4539-bb83-62e372c0b894'
    }
    const selectDescriptor = listenerSaga.next( cookie_id ).value;
    expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
  } );

  it( 'should yield on requesting data and return that data with a sucess method', () => {
    let GTI = 'UID12344';
    let values = {
      cookie_id:'215b64b9-a57d-4539-bb83-62e372c0b894',
      event: appConstants.EVENT_NAMES.PRODUCT_VIEWED,
      meta:{ GTI },
      'sku':[
        {
          'productId': 123,
          'skuId': 1234
        }
      ],
      timestamp:new Date().toISOString()
    }
    let switchData = {
      switches:{
        quaziEventURL:'https://qzai.qmscientific.com/v1/events/new'
      }
    }
    let customHeaders = { apiKey:'XyyS9ghuVrNjZWoU5lBw6RI4elrSHth7Kg0TmQ42' };
    const callDescriptor = listenerSaga.next( switchData ).value;
    expect( callDescriptor ).toEqual( call( ajax, {
      type:'quaziEventAPI', method:'post', dynamicURL:switchData.switches.quaziEventURL, values, customHeaders
    } ) );
  } );


  describe( 'quaziEvent saga failure path', () => {

    it( 'should put a failure event if there is an exception', () => {
      const err = {
        statusText:'some failure message'
      }
      global.console = {
        error:jest.fn()
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( global.console.error ).toHaveBeenCalledWith( err );
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );


} );