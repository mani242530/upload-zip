import {
  takeEvery,
  call,
  put,
  cancelled,
  take,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { getUserState } from '../../models/view/user/user.model';
import { ajax } from '../../utils/ajax/ajax';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import { getQuickShopProductDetailsState } from '../../models/view/quick_shop/quick_shop.model';
import {
  emittingFeedlessProduct
} from '../../events/power_reviews/power_reviews.events';
import appConstants from '../../shared/appConstants';
export const getProductDetails = function* ( type, CONFIG, action ){
  try {

    yield put( getActionDefinition( type, 'loading' )() );
    const URIParams = { productid: action.data.productId };
    const query = {};
    const res = yield call( ajax,
      {
        type:'productDetails',
        query,
        URIParams
      } );
    let productDetails = res.body.data;

    yield put( getActionDefinition( type, 'success' )( productDetails ) );

    // the below logic will initiate the service calls to retrieve the other sku related data like eligibility, dynamicData etc
    const skuRequestData = Object.assign( {}, action.data );
    if( productDetails.product ){
      skuRequestData.skuId = productDetails.sku.id;
      yield call( getSkuAdditionalDetails, skuRequestData );
    }

    // handleProductAnalytics method will trigger the quickShopProductLoaded event
    yield call( handleProductAnalytics, action.data.section );
    // Power Review Feedless Product
    productDetails = yield select( getQuickShopProductDetailsState );
    yield put( emittingFeedlessProduct( productDetails ) );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}

// this method will initate the requests to fetch the eligibility, dynamicdata and favorites
export const getSkuAdditionalDetails = function* ( data ){
  // As the page is going to display the details of default sku, we need to make the eligibility service and dynamic sku data call at this point
  // In other cases, where we have a follow up sku service call to be made, the eligibility service and dynamic sku data call will be triggered from the SkuDetail saga
  // after sku service is invoked
  yield put( getActionDefinition( 'qsPurchaseEligibility', 'requested' )( data.skuId ) );
  // we are waiting for purchaseEligibility response as we need the same to handle analytics requirement
  yield take( getServiceType( 'qsPurchaseEligibility', 'success' ) );
  yield put( getActionDefinition( 'qsSkuDynamicData', 'requested' )( data.skuId ) );
  // we are waiting for skuDynamicData response as we need the same to handle analytics requirement
  yield take( getServiceType( 'qsSkuDynamicData', 'success' ) );

  // for signedIn user if a request will be made to check if the sku is already part of the favorites
  const UserData = yield select( getUserState );

  const {
    isSignedIn
  } = UserData;

  if( isSignedIn ){
    yield put( getActionDefinition( 'qsFindFavorite', 'requested' )( data.skuId ) );
  }
}

// this method will fetch the skuDetails when a swatch is selected
export const getSkuDetails = function* ( type, CONFIG, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const skuData = yield call( invokeSkuService, action.data.skuId );
    yield put( getActionDefinition( type, 'success' )( skuData ) );
    yield call( getSkuAdditionalDetails, action.data );
    yield call( handleProductAnalytics, action.data.section, true );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}

// this method will invoke the sku service and return the sku details
export const invokeSkuService = function* ( skuid ){

  const URIParams = { skuid };
  const query = {};
  const res = yield call( ajax,
    {
      type:'skuDetails',
      query,
      URIParams
    } );
  return res.body.data;
}

// this method will populate the globalPageData object and trigger the quickShopProductLoaded event
export const handleProductAnalytics = function*( section, isOptionClick ){
  const productDetails = yield select( getQuickShopProductDetailsState );

  const {
    product,
    sku,
    brand,
    purchaseEligibility
  } = productDetails;

  const evt = {
    'name': 'quickShopProductLoaded'
  }
  let pageName;
  if( product ){
    pageName = appConstants.ANALYTICS.PRODUCT_PAGE_NAME( sku.id, brand.brandName, sku.displayName );
  }
  else {
    pageName = appConstants.ANALYTICS.PRODUCT_NO_RESULTS_PAGE_NAME;
  }

  const data = {
    'globalPageData': {
      'quickShopProduct':{
        'pageName': pageName,
        'expired':product ? 'false' : 'true',
        ...( product && {
          'url':product.actionUrl,
          'excludedFromCoupons':!sku.couponEligible ? 'true' : 'false',
          ...( sku.variant && sku.variant.variantType === 'Color' && { 'color': sku.variant.variantDesc } ),
          ...( sku.price && sku.price.listPrice && { 'currency' : sku.price.listPrice.currencyCode } ),
          'description' : sku.description,
          'id' : product.id,
          'imgurl' :sku.images.largeImage,
          'listPrice' : sku && sku.price && sku.price.listPrice ? sku.price.listPrice.amount : '0.00',
          'name' :sku.displayName,
          'saleprice' :sku && sku.price && sku.price.salePrice ? sku.price.salePrice.amount : '0.00',
          'size' :sku.size,
          'sku' :sku.id,
          'onlineOnly' :( sku.onlineOnlyStatus ?? false ).toString(),
          'optionClick':`${ !!isOptionClick }`
        } ),
        ...( purchaseEligibility && {
          'outOfStock': purchaseEligibility.isNotAvailable ? 'true' : 'false',
          'comingSoon': purchaseEligibility.isComingSoonProduct ? 'true' : 'false',
          'inStoreOnly': purchaseEligibility.isInStoreOnlyProduct ? 'true' : 'false'
        } ),
        ...( brand && { 'brand':brand.brandName } ),
        'crossSellLocation':'product',
        'crossSellType': section
      }
    }
  }

  yield put( setDataLayer( data, evt ) );

}

export default function( CONFIG ){
  return function*( ){
    const productDetailsServiceType = 'qsProductDetails';
    const skuDetailsServiceType = 'qsSkuDetails';

    registerServiceName( productDetailsServiceType );
    registerServiceName( skuDetailsServiceType );

    yield takeEvery( getServiceType( productDetailsServiceType, 'requested' ), getProductDetails, productDetailsServiceType, CONFIG );
    yield takeEvery( getServiceType( skuDetailsServiceType, 'requested' ), getSkuDetails, skuDetailsServiceType, CONFIG );
  }
}
