
import {
  takeEvery,
  call,
  put,
  take,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { cloneableGenerator } from 'redux-saga/utils';
import { getUserState } from '../../models/view/user/user.model';
import { ajax } from '../../utils/ajax/ajax';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import { getQuickShopProductDetailsState } from '../../models/view/quick_shop/quick_shop.model';
import CONFIG from '../../modules/pdp/pdp.config';
import saga, {
  getProductDetails, getSkuDetails,
  getSkuAdditionalDetails,
  invokeSkuService,
  handleProductAnalytics
} from './quick_shop.controller';
import {
  emittingFeedlessProduct
} from '../../events/power_reviews/power_reviews.events';

const type = 'qsProductDetails';
const promotionType = 'qsSkuDynamicData';
const skuDetailsServiceType = 'qsSkuDetails';
var action = {
  data:{
    productId: '123567',
    skuId: '12312312',
    page:'detail',
    section:'Previously Viewed',
    fav:true
  }
}
const listenerSaga = cloneableGenerator( getProductDetails )( type, CONFIG, action );
const listenerSaga1 = cloneableGenerator( getSkuDetails )( skuDetailsServiceType, CONFIG, action );
let listenerSagaClone1;
let listenerSagaClone2;
let listenerSagaClone;
describe( 'Quick shop productDetail sagas', () => {
  const coreSaga = saga( CONFIG )();
  registerServiceName( type );
  registerServiceName( promotionType );
  registerServiceName( 'qsSkuDetails' );
  registerServiceName( 'qsPurchaseEligibility' );
  registerServiceName( 'qsFindFavorite' );
  registerServiceName( 'qsAddFavorite' );
  registerServiceName( 'qsProductRecs' );

  it( 'should take every qsProductDetails request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), getProductDetails, type, CONFIG ) );
  } );
  it( 'should take every qsSkuDetails request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( 'qsSkuDetails', 'requested' ), getSkuDetails, 'qsSkuDetails', CONFIG ) );
  } );

  describe( 'ProductDetail saga success path', () => {

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method when the environemnt is development', () => {
      const callDescriptor = listenerSaga.next().value;
      const query = {};
      const URIParams = { productid:action.data.productId };
      expect( callDescriptor ).toEqual( call( ajax, { type:'productDetails', query, URIParams } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true,
            product:{},
            sku:{
              id:'12312312',
              images:{},
              price:{}
            }
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    let productRes;
    it( 'should call getSkuAdditionalDetails ', () => {
      productRes = {
        body: {
          data:{
            product:{},
            sku:{
              id:'123',
              images:{},
              price:{}
            },
            brand:{}
          }
        }
      };
      const callDescriptor = listenerSaga.next( productRes ).value;
      expect( callDescriptor ).toEqual( call( getSkuAdditionalDetails, action.data ) );
    } );

    it( 'should call handleProductAnalytics ', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( handleProductAnalytics, action.data.section ) );
    } );

    it( 'should select getProductDetailsState', () => {
      const selectDescriptor = listenerSaga.next( ).value;
      expect( selectDescriptor ).toEqual( select( getQuickShopProductDetailsState ) );

    } );

    it( 'should put emittingFeedlessProduct requested event', () => {
      const productDetails = {
        product:{},
        sku:{
          id:'123',
          displayName:'shiny lipstick',
          images:{},
          price:{},
          variant:{},
          couponEligible:false
        },
        brand:{},
        purchaseEligibility:{},
        reviewNum:1559,
        reviewSummary:{
          questionCount: 16,
          rating: 4.66,
          reviewCount: 1559
        }
      }
      const putDescriptor = listenerSaga.next( productDetails ).value;
      expect( putDescriptor ).toEqual( put( emittingFeedlessProduct( productDetails ) ) );
    } );

  } );

  describe( 'ProductDetail saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

  describe( 'GetSkuAdditionalDetails', () => {

    var action1 = {
      data:{
        productId: 123567,
        skuId: 12312312
      }
    }

    const listenerSaga = getSkuAdditionalDetails( action1.data );
    it( 'should put qsPurchaseEligibility requested event ', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'qsPurchaseEligibility', 'requested' )( action1.data.skuId ) ) );
    } );

    it( 'should take qsPurchaseEligibility success event ', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( take( getServiceType( 'qsPurchaseEligibility', 'success' ) ) );
    } );

    it( 'should put qsSkuDynamicData requested event ', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'qsSkuDynamicData', 'requested' )( action1.data.skuId ) ) );
    } );

    it( 'should take qsSkuDynamicData success event ', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( take( getServiceType( 'qsSkuDynamicData', 'success' ) ) );
    } );

    it( 'should do a select on getUserState ', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( select( getUserState ) );
    } );

    it( 'should put qsFindFavorite requested event ', () => {
      const listenerSaga = getSkuAdditionalDetails( action1.data );
      listenerSaga.next();
      listenerSaga.next();
      listenerSaga.next();
      listenerSaga.next();
      listenerSaga.next();
      const putDescriptor = listenerSaga.next( { isSignedIn : true } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'qsFindFavorite', 'requested' )( action1.data.skuId ) ) );
    } );
  } );

  describe( 'HandleProductAnalytics', () => {
    const listenerSaga = cloneableGenerator( handleProductAnalytics )( action.data.section );
    let listenerSagaClone3;
    it( 'should select getProductDetailsState', () => {
      const selectDescriptor = listenerSaga.next().value;
      listenerSagaClone3 = listenerSaga.clone();
      expect( selectDescriptor ).toEqual( select( getQuickShopProductDetailsState ) );
    } );

    it( 'should put a request event setDataLayer-response when quickShopModal is loaded', () => {
      const productDetails = {
        'product': {
          'gwp': false,
          'displayName': 'Classic Nail Lacquer',
          'actionUrl': 'https://qa3.ulta.com/classic-nail-lacquer?productId=xlsImpprod5180201',
          'defaultSku': '2204232',
          'parentCategory': {
            'name': 'Nail Polish',
            'actionUrl': 'https://qa3.ulta.com/nail-polish?N=278s',
            'parentCategory': {
              'name': 'Nails',
              'actionUrl': 'https://qa3.ulta.com/nails?N=271o',
              'parentCategory': null
            }
          },
          'id': 'xlsImpprod5180201',
          'altImages': null
        },
        'swatches': {
          'items': [
            {
              'checkProfile': false,
              'variantDesc': 'Dulce de Leche',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2070018?$sm$',
              'altImageText': 'OPI Classic Nail Lacquer Dulce de Leche',
              'inStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2070018?$md$',
              'skuId': '2070018'
            },
            {
              'checkProfile': false,
              'variantDesc': 'Color So Hot It Berns',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2222139?$sm$',
              'altImageText': 'OPI Classic Nail Lacquer Color So Hot It Berns',
              'inStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2222139?$md$',
              'skuId': '2222139'
            }
          ]
        },
        'sku': {
          'longDescription': 'The most-asked-for brand in the industry! With a superior range of shades and the hottest special effects and textures, OPI is the go-to brand for nail fashion. From elegant classics to eye-popping brights, OPI has your color! Formaldehyde-free.',
          'enableFindStore': false,
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2204232?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2204232',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2204232?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2204232?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2204232?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2204232?$md$'
          },
          'displayName': 'Classic Nail Lacquer',
          'description': 'The most-asked-for brand in the industry! Classic Nail Lacquer with a superior range of shades and the hottest special effects and textures, OPI is the go-to brand for nail fashion. From elegant classics to eye-popping brights, OPI has your color!',
          'onlineOnlyStatus': true,
          'shippingRestricted': true,
          'UOM': 'oz',
          'couponEligible': true,
          'directions': 'Follow these steps for a mani that lasts:<ul><li>Start by applying OPI Base Coat or Treatment on clean, dry nails with cuticles pushed back.<li>For a perfect polish, apply one stroke of nail lacquer down the center of the nail, followed by one stroke along each side of the nail.<li>Smooth the surface of the nail with a final stroke of the brush. Then, apply a second coat of nail lacquer, pulling color over the tips of the nails.<li>Shine, seal, and protect with one coat of OPI Top Coat, pulling it over the tips of the nails to seal in color.<li>For a mani that\'s dry to the touch in minutes, apply 2 drops of OPI DripDry Lacquer Drying Drops to each nail.</li></ul>',
          'size': '0.5',
          'comingSoon': false,
          'price': {
            'salePrice': null,
            'listPrice': {
              'amount': 8.99,
              'currencyCode': 'USD'
            }
          },
          'enableAskaQuestion': false,
          'variant': {
            'variantType': 'Color',
            'variantDesc': `Feelin' Hot-Hot-Hot!`
          },
          'ingredients': 'Ethyl Acetate, Butyl Acetate, Nitrocellulose, Propyl Acetate, Tosylamide Formaldehyde Resin, Isopropyl Alcohol, Trimethyl Pentanyl Diisobutyrate, Triphenyl Phosphate, Ethyl Tosylamide, Camphor, Stearalkonium Bentonite, Diacetone Alcohol, Stearalkonium Hectorite, Benzophenone 1, Citric Acid, Dimethicone, CI 77120, Titanium Dioxide (CI 77891), CI 77499, FD&C Yellow 5 Aluminum Lake, FD&C Red 6.',
          'storeOnly': false,
          'id': '2204232',
          'maxQty': 10,
          'promotionData': {
            'isGiftItem': false,
            'gwpPresent': false,
            'actionUrl': null,
            'promotions': [
              {
                'id': '0000143902',
                'displayName': 'FREE Anastasia Beverly Hills Eye Shadow Palette with any 4 Single Eye Shadow purchase (offer valid 3/2/16-12/31/17 or while supplies last. Limit 1 per order)',
                'description': 'Special Free Gift with Purchase',
                'type': 'G',
                'qualifyingSKU': {
                  'id': '2050103',
                  'displayName': 'Total Effects Daily Moisturizer',
                  'imageUrl': 'http://s7d5.scene7.com/is/image/Ulta/2050103?$sm$'
                }
              },
              {
                'id': '0000012666',
                'displayName': 'QA-Buy one and get one 50 %-PROMO',
                'description': 'Buy 1, get 1 at 50% off! Add 2 items to qualify',
                'type': 'B'
              }
            ]
          }
        },
        'brand': {
          'brandName': 'OPI',
          'actionUrl': 'https://qa3.ulta.com/brand/opi',
          'brandId': 'xlsImp19400002'
        },
        'selectedThumbnailIndex': 1,
        'reviewNum': 0,
        'ratingNum': 0,
        'displayReviews': false,
        'displayQaSection': false,
        'displayQAs': false,
        'displayAskLink': false,
        'purchaseEligibility': {
          'isAddToCartEligible': true,
          'isComingSoonProduct': false,
          'isOutOfStock': false,
          'isNotifyMeSignUp': false,
          'isNotifyMeEligible': false,
          'isInStoreOnlyProduct': false,
          'isPlatinumAndUserAnonymous': false,
          'isPlatinumAndUserIneligible': false,
          'availabilityMessage1': null,
          'availabilityMessage2': null,
          'emailStockNotifyMessage': null,
          'platinumEligibilityMessage': null,
          'isNotAvailable' : true
        }
      };
      const putDescriptor = listenerSaga.next( productDetails ).value;

      const {
        product,
        sku,
        brand,
        purchaseEligibility
      } = productDetails;

      const data = {
        'globalPageData': {
          'quickShopProduct':{
            'expired':product ? 'false' : 'true',
            'pageName': 'product:2204232:OPI:Classic Nail Lacquer',
            ...( product && {
              'url':product.actionUrl,
              'excludedFromCoupons':!sku.couponEligible ? 'true' : 'false',
              ...( sku.variant && sku.variant.variantType === 'Color' && { 'color': sku.variant.variantDesc } ),
              ...( sku.price && sku.price.listPrice && { 'currency' : sku.price.listPrice.currencyCode } ),
              'description' : sku.description,
              'id' : product.id,
              'imgurl' :sku.images.largeImage,
              'listPrice' : sku && sku.price && sku.price.listPrice ? sku.price.listPrice.amount : '0.00',
              'name' :sku.displayName,
              'saleprice' :sku && sku.price && sku.price.salePrice ? sku.price.salePrice.amount : '0.00',
              'size' :sku.size,
              'sku' :sku.id,
              'onlineOnly': 'true',
              'optionClick':'false'
            } ),
            ...( purchaseEligibility && {
              'outOfStock': purchaseEligibility.isNotAvailable ? 'true' : 'false',
              'comingSoon': purchaseEligibility.isComingSoonProduct ? 'true' : 'false',
              'inStoreOnly': purchaseEligibility.isInStoreOnlyProduct ? 'true' : 'false'
            } ),
            ...( brand && { 'brand':brand.brandName } ),
            'crossSellLocation': 'product',
            'crossSellType': 'Previously Viewed'
          }
        }
      }
      const evt = {
        'name': 'quickShopProductLoaded'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put a request event setDataLayer-response when quickShopModal is loaded with onlineOnly as false', () => {
      const productDetails = {
        'product': {
          'gwp': false,
          'displayName': 'Classic Nail Lacquer',
          'actionUrl': 'https://qa3.ulta.com/classic-nail-lacquer?productId=xlsImpprod5180201',
          'defaultSku': '2204232',
          'parentCategory': {
            'name': 'Nail Polish',
            'actionUrl': 'https://qa3.ulta.com/nail-polish?N=278s',
            'parentCategory': {
              'name': 'Nails',
              'actionUrl': 'https://qa3.ulta.com/nails?N=271o',
              'parentCategory': null
            }
          },
          'id': 'xlsImpprod5180201',
          'altImages': null
        },
        'swatches': {
          'items': [
            {
              'checkProfile': false,
              'variantDesc': 'Dulce de Leche',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2070018?$sm$',
              'altImageText': 'OPI Classic Nail Lacquer Dulce de Leche',
              'inStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2070018?$md$',
              'skuId': '2070018'
            },
            {
              'checkProfile': false,
              'variantDesc': 'Color So Hot It Berns',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2222139?$sm$',
              'altImageText': 'OPI Classic Nail Lacquer Color So Hot It Berns',
              'inStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2222139?$md$',
              'skuId': '2222139'
            }
          ]
        },
        'sku': {
          'longDescription': 'The most-asked-for brand in the industry! With a superior range of shades and the hottest special effects and textures, OPI is the go-to brand for nail fashion. From elegant classics to eye-popping brights, OPI has your color! Formaldehyde-free.',
          'enableFindStore': false,
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2204232?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2204232',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2204232?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2204232?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2204232?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2204232?$md$'
          },
          'displayName': 'Classic Nail Lacquer',
          'description': 'The most-asked-for brand in the industry! Classic Nail Lacquer with a superior range of shades and the hottest special effects and textures, OPI is the go-to brand for nail fashion. From elegant classics to eye-popping brights, OPI has your color!',
          onlineOnlyStatus: false,
          'shippingRestricted': true,
          'UOM': 'oz',
          'couponEligible': true,
          'directions': 'Follow these steps for a mani that lasts:<ul><li>Start by applying OPI Base Coat or Treatment on clean, dry nails with cuticles pushed back.<li>For a perfect polish, apply one stroke of nail lacquer down the center of the nail, followed by one stroke along each side of the nail.<li>Smooth the surface of the nail with a final stroke of the brush. Then, apply a second coat of nail lacquer, pulling color over the tips of the nails.<li>Shine, seal, and protect with one coat of OPI Top Coat, pulling it over the tips of the nails to seal in color.<li>For a mani that\'s dry to the touch in minutes, apply 2 drops of OPI DripDry Lacquer Drying Drops to each nail.</li></ul>',
          'size': '0.5',
          'comingSoon': false,
          'price': {
            'salePrice': null,
            'listPrice': {
              'amount': 8.99,
              'currencyCode': 'USD'
            }
          },
          'enableAskaQuestion': false,
          'variant': {
            'variantType': 'Color',
            'variantDesc': `Feelin' Hot-Hot-Hot!`
          },
          'ingredients': 'Ethyl Acetate, Butyl Acetate, Nitrocellulose, Propyl Acetate, Tosylamide Formaldehyde Resin, Isopropyl Alcohol, Trimethyl Pentanyl Diisobutyrate, Triphenyl Phosphate, Ethyl Tosylamide, Camphor, Stearalkonium Bentonite, Diacetone Alcohol, Stearalkonium Hectorite, Benzophenone 1, Citric Acid, Dimethicone, CI 77120, Titanium Dioxide (CI 77891), CI 77499, FD&C Yellow 5 Aluminum Lake, FD&C Red 6.',
          'storeOnly': false,
          'id': '2204232',
          'maxQty': 10,
          'promotionData': {
            'isGiftItem': false,
            'gwpPresent': false,
            'actionUrl': null,
            'promotions': [
              {
                'id': '0000143902',
                'displayName': 'FREE Anastasia Beverly Hills Eye Shadow Palette with any 4 Single Eye Shadow purchase (offer valid 3/2/16-12/31/17 or while supplies last. Limit 1 per order)',
                'description': 'Special Free Gift with Purchase',
                'type': 'G',
                'qualifyingSKU': {
                  'id': '2050103',
                  'displayName': 'Total Effects Daily Moisturizer',
                  'imageUrl': 'http://s7d5.scene7.com/is/image/Ulta/2050103?$sm$'
                }
              },
              {
                'id': '0000012666',
                'displayName': 'QA-Buy one and get one 50 %-PROMO',
                'description': 'Buy 1, get 1 at 50% off! Add 2 items to qualify',
                'type': 'B'
              }
            ]
          }
        },
        'brand': {
          'brandName': 'OPI',
          'actionUrl': 'https://qa3.ulta.com/brand/opi',
          'brandId': 'xlsImp19400002'
        },
        'selectedThumbnailIndex': 1,
        'reviewNum': 0,
        'ratingNum': 0,
        'displayReviews': false,
        'displayQaSection': false,
        'displayQAs': false,
        'displayAskLink': false,
        'purchaseEligibility': {
          'isAddToCartEligible': true,
          'isComingSoonProduct': false,
          'isOutOfStock': false,
          'isNotifyMeSignUp': false,
          'isNotifyMeEligible': false,
          'isInStoreOnlyProduct': false,
          'isPlatinumAndUserAnonymous': false,
          'isPlatinumAndUserIneligible': false,
          'availabilityMessage1': null,
          'availabilityMessage2': null,
          'emailStockNotifyMessage': null,
          'platinumEligibilityMessage': null,
          'isNotAvailable' : false
        }
      };
      const putDescriptor = listenerSagaClone3.next( productDetails ).value;

      const {
        product,
        sku,
        brand,
        purchaseEligibility
      } = productDetails;

      const data = {
        'globalPageData': {
          'quickShopProduct':{
            'pageName': 'product:2204232:OPI:Classic Nail Lacquer',
            'expired':product ? 'false' : 'true',
            ...( product && {
              'url':product.actionUrl,
              'excludedFromCoupons':!sku.couponEligible ? 'true' : 'false',
              ...( sku.variant && sku.variant.variantType === 'Color' && { 'color': sku.variant.variantDesc } ),
              ...( sku.price && sku.price.listPrice && { 'currency' : sku.price.listPrice.currencyCode } ),
              'description' : sku.description,
              'id' : product.id,
              'imgurl' :sku.images.largeImage,
              'listPrice' : sku && sku.price && sku.price.listPrice ? sku.price.listPrice.amount : '0.00',
              'name' :sku.displayName,
              'saleprice' :sku && sku.price && sku.price.salePrice ? sku.price.salePrice.amount : '0.00',
              'size' :sku.size,
              'sku' :sku.id,
              'onlineOnly': 'false',
              'optionClick':'false'
            } ),
            ...( purchaseEligibility && {
              'outOfStock': purchaseEligibility.isNotAvailable ? 'true' : 'false',
              'comingSoon': purchaseEligibility.isComingSoonProduct ? 'true' : 'false',
              'inStoreOnly': purchaseEligibility.isInStoreOnlyProduct ? 'true' : 'false'
            } ),
            ...( brand && { 'brand':brand.brandName } ),
            'crossSellLocation': 'product',
            'crossSellType': 'Previously Viewed'
          }
        }
      }
      const evt = {
        'name': 'quickShopProductLoaded'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

  } );
  describe( 'HandleProductAnalytics -should set isOptionClick as true in globalPageData when swatch is selected', () => {
    const listenerSaga = handleProductAnalytics( action.data.section, true );
    it( 'should put a request event setDataLayer-response with isOptionClick as true when swatch is selected from quick shop page', () => {
      const productDetails = {
        'product': {
          'gwp': false,
          'displayName': 'Classic Nail Lacquer',
          'actionUrl': 'https://qa3.ulta.com/classic-nail-lacquer?productId=xlsImpprod5180201',
          'defaultSku': '2204232',
          'parentCategory': {
            'name': 'Nail Polish',
            'actionUrl': 'https://qa3.ulta.com/nail-polish?N=278s',
            'parentCategory': {
              'name': 'Nails',
              'actionUrl': 'https://qa3.ulta.com/nails?N=271o',
              'parentCategory': null
            }
          },
          'id': 'xlsImpprod5180201',
          'altImages': null
        },
        'swatches': {
          'items': [
            {
              'checkProfile': false,
              'variantDesc': 'Dulce de Leche',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2070018?$sm$',
              'altImageText': 'OPI Classic Nail Lacquer Dulce de Leche',
              'inStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2070018?$md$',
              'skuId': '2070018'
            },
            {
              'checkProfile': false,
              'variantDesc': 'Color So Hot It Berns',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2222139?$sm$',
              'altImageText': 'OPI Classic Nail Lacquer Color So Hot It Berns',
              'inStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2222139?$md$',
              'skuId': '2222139'
            }
          ]
        },
        'sku': {
          'longDescription': 'The most-asked-for brand in the industry! With a superior range of shades and the hottest special effects and textures, OPI is the go-to brand for nail fashion. From elegant classics to eye-popping brights, OPI has your color! Formaldehyde-free.',
          'enableFindStore': false,
          'images': {
            'blowupImage': 'https://images.ulta.com/is/image/Ulta/2204232?$detail$',
            'mainImage': 'https://images.ulta.com/is/image/Ulta/2204232',
            'largeImage': 'https://images.ulta.com/is/image/Ulta/2204232?$lg$',
            'smallImage': 'https://images.ulta.com/is/image/Ulta/2204232?$sm$',
            'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2204232?$tn$',
            'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2204232?$md$'
          },
          'displayName': 'Classic Nail Lacquer',
          'description': 'The most-asked-for brand in the industry! Classic Nail Lacquer with a superior range of shades and the hottest special effects and textures, OPI is the go-to brand for nail fashion. From elegant classics to eye-popping brights, OPI has your color!',
          'onlineOnlyStatus': true,
          'shippingRestricted': true,
          'UOM': 'oz',
          'couponEligible': true,
          'directions': 'Follow these steps for a mani that lasts:<ul><li>Start by applying OPI Base Coat or Treatment on clean, dry nails with cuticles pushed back.<li>For a perfect polish, apply one stroke of nail lacquer down the center of the nail, followed by one stroke along each side of the nail.<li>Smooth the surface of the nail with a final stroke of the brush. Then, apply a second coat of nail lacquer, pulling color over the tips of the nails.<li>Shine, seal, and protect with one coat of OPI Top Coat, pulling it over the tips of the nails to seal in color.<li>For a mani that\'s dry to the touch in minutes, apply 2 drops of OPI DripDry Lacquer Drying Drops to each nail.</li></ul>',
          'size': '0.5',
          'comingSoon': false,
          'price': {
            'salePrice': null,
            'listPrice': {
              'amount': 8.99,
              'currencyCode': 'USD'
            }
          },
          'enableAskaQuestion': false,
          'variant': {
            'variantType': 'Color',
            'variantDesc': `Feelin' Hot-Hot-Hot!`
          },
          'ingredients': 'Ethyl Acetate, Butyl Acetate, Nitrocellulose, Propyl Acetate, Tosylamide Formaldehyde Resin, Isopropyl Alcohol, Trimethyl Pentanyl Diisobutyrate, Triphenyl Phosphate, Ethyl Tosylamide, Camphor, Stearalkonium Bentonite, Diacetone Alcohol, Stearalkonium Hectorite, Benzophenone 1, Citric Acid, Dimethicone, CI 77120, Titanium Dioxide (CI 77891), CI 77499, FD&C Yellow 5 Aluminum Lake, FD&C Red 6.',
          'storeOnly': false,
          'id': '2204232',
          'maxQty': 10,
          'promotionData': {
            'isGiftItem': false,
            'gwpPresent': false,
            'actionUrl': null,
            'promotions': [
              {
                'id': '0000143902',
                'displayName': 'FREE Anastasia Beverly Hills Eye Shadow Palette with any 4 Single Eye Shadow purchase (offer valid 3/2/16-12/31/17 or while supplies last. Limit 1 per order)',
                'description': 'Special Free Gift with Purchase',
                'type': 'G',
                'qualifyingSKU': {
                  'id': '2050103',
                  'displayName': 'Total Effects Daily Moisturizer',
                  'imageUrl': 'http://s7d5.scene7.com/is/image/Ulta/2050103?$sm$'
                }
              },
              {
                'id': '0000012666',
                'displayName': 'QA-Buy one and get one 50 %-PROMO',
                'description': 'Buy 1, get 1 at 50% off! Add 2 items to qualify',
                'type': 'B'
              }
            ]
          }
        },
        'brand': {
          'brandName': 'OPI',
          'actionUrl': 'https://qa3.ulta.com/brand/opi',
          'brandId': 'xlsImp19400002'
        },
        'selectedThumbnailIndex': 1,
        'reviewNum': 0,
        'ratingNum': 0,
        'displayReviews': false,
        'displayQaSection': false,
        'displayQAs': false,
        'displayAskLink': false,
        'purchaseEligibility': {
          'isAddToCartEligible': true,
          'isComingSoonProduct': false,
          'isOutOfStock': false,
          'isNotifyMeSignUp': false,
          'isNotifyMeEligible': false,
          'isInStoreOnlyProduct': false,
          'isPlatinumAndUserAnonymous': false,
          'isPlatinumAndUserIneligible': false,
          'availabilityMessage1': null,
          'availabilityMessage2': null,
          'emailStockNotifyMessage': null,
          'platinumEligibilityMessage': null
        }
      };
      listenerSaga.next(); // getproductdetailstate
      const putDescriptor = listenerSaga.next( productDetails ).value;

      const {
        product,
        sku,
        brand,
        purchaseEligibility
      } = productDetails;

      const data = {
        'globalPageData': {
          'quickShopProduct':{
            'expired':product ? 'false' : 'true',
            'pageName':'product:2204232:OPI:Classic Nail Lacquer',
            ...( product && {
              'url':product.actionUrl,
              'excludedFromCoupons':!sku.couponEligible ? 'true' : 'false',
              ...( sku.variant && sku.variant.variantType === 'Color' && { 'color': sku.variant.variantDesc } ),
              ...( sku.price && sku.price.listPrice && { 'currency' : sku.price.listPrice.currencyCode } ),
              'description' : sku.description,
              'id' : product.id,
              'imgurl' :sku.images.largeImage,
              'listPrice' : sku && sku.price && sku.price.listPrice ? sku.price.listPrice.amount : '0.00',
              'name' :sku.displayName,
              'saleprice' :sku && sku.price && sku.price.salePrice ? sku.price.salePrice.amount : '0.00',
              'size' :sku.size,
              'sku' :sku.id,
              'onlineOnly': 'true',
              'optionClick':'true'
            } ),
            ...( purchaseEligibility && {
              'outOfStock': ( purchaseEligibility.isNotifyMeSignUp || purchaseEligibility.isNotifyMeEligible || purchaseEligibility.isOutOfStock ) ? 'true' : 'false',
              'comingSoon': purchaseEligibility.isComingSoonProduct ? 'true' : 'false',
              'inStoreOnly': purchaseEligibility.isInStoreOnlyProduct ? 'true' : 'false'
            } ),
            ...( brand && { 'brand':brand.brandName } ),
            'crossSellLocation': 'product',
            'crossSellType': 'Previously Viewed'
          }
        }
      }
      const evt = {
        'name': 'quickShopProductLoaded'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

  } );
  describe( 'HandleProductAnalytics -should set pageName as product:no results  in globalPageData when no product is found', () => {
    const listenerSaga = handleProductAnalytics( action.data.section, true );
    it( 'should put a request event setDataLayer-response with pageName as product:no results when no product is found', () => {
      const productDetails = {
        'product': null
      };
      listenerSaga.next(); // getproductdetailstate
      const putDescriptor = listenerSaga.next( productDetails ).value;

      const {
        product,
        sku,
        brand,
        purchaseEligibility
      } = productDetails;

      const data = {
        'globalPageData': {
          'quickShopProduct':{
            'expired':product ? 'false' : 'true',
            'pageName':'product:no results',
            'crossSellLocation': 'product',
            'crossSellType': 'Previously Viewed'
          }
        }
      }
      const evt = {
        'name': 'quickShopProductLoaded'
      }
      expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

  } );
  describe( 'GetSkuDetails success path', () => {
    const res = {
      body: {
        data:{
          product:{},
          sku:{
            id:'123',
            images:{},
            price:{}
          },
          brand:{}
        }
      }
    };
    const type = 'qsSkuDetails';
    it( 'should put loadSkuDetails loading  event ', () => {
      const putDescriptor = listenerSaga1.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( skuDetailsServiceType, 'loading' )() ) );
    } );

    it( 'should call invokeSkuService', () => {
      const callDescriptor = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( invokeSkuService, action.data.skuId ) );
    } );

    it( 'should put qsSkuDetails success  event ', () => {
      const res = {
        sku:{
          id:'123',
          images:{},
          price:{}
        },
        brand:{}
      };
      listenerSagaClone1 = listenerSaga1.clone();
      const putDescriptor = listenerSaga1.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );
    } );

    it( 'should call getSkuAdditionalDetails', () => {
      const callDescriptor = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( getSkuAdditionalDetails, action.data ) );
    } );


    it( 'should call handleProductAnalytics ', () => {
      const callDescriptor = listenerSaga1.next().value;
      expect( callDescriptor ).toEqual( call( handleProductAnalytics, action.data.section, true ) );
    } );
  } );

  describe( 'GetSkuDetails failure path', () => {
    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga1.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( skuDetailsServiceType, 'failure' )( err ) ) );
    } );

  } );

  describe( 'invokeSkuService test cases', () => {
    const testSkuId = '123323';
    const invokeSkuServiceListener = invokeSkuService( testSkuId );

    it( 'should invoke qsSkuDetails call ', () => {
      const callDescriptor = invokeSkuServiceListener.next().value;
      expect( callDescriptor ).toEqual( call( ajax, { type:'skuDetails', query: {}, URIParams: { skuid:'123323' } } ) );
    } );

    it( 'should call invokeSkuService', () => {
      const skuRes = {
        body:{
          data:{
            sku:{
              id:'12312312'
            }
          }
        }
      }
      const skuReturnData = invokeSkuServiceListener.next( skuRes );
      expect( skuReturnData.value ).toBe( skuRes.body.data );
    } );

  } );

} );
