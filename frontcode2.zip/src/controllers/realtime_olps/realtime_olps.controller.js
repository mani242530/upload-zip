import {
  takeEvery, take, call, put
} from 'redux-saga/effects';
import has from 'lodash/has';

import {
  types,
  actions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import { getRoute } from 'ulta-fed-core/dist/js/utils/omniture/omniture';
import {
  host,
  fullyQualifyLink
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';



let _PRESCREEN_ID, _FIRST_NAME, _CARD_TYPE;
let _ACCEPTED = 'Accepted';
let _NO_RESPONSE = 'NoResponse';

// listener for the action on the model window
export const clearHeadResponse = function*( type, action ){

  let eventType;
  let evt = {
    'name': 'creditCardPrescreenOfferInteraction',
    'data':{

    }
  };
  if( action.data.type === 'QUBIT::PREAPPROVED_FLOW_ACCEPT' ){
    eventType = _ACCEPTED;
    evt.data.typeOfInteraction = 'interested';
  }
  else {
    eventType = 'NotAtThisTime';
    evt.data.typeOfInteraction = 'not interested';
  }

  // fire prescreenlps event service depending on user interaction with the modal popup.
  yield put( getActionDefinition( 'preScreenLPSEvent', 'requested' )( { eventType, preScreenId: _PRESCREEN_ID } ) );
  yield put( setDataLayer( {}, evt ) );
}

// listener for lpsEvent to notify if the modal is shown, if user accepted and if user declined offer.
export const listenerForLPSEvent = function*( type, action ){

  try {
    const response = yield call(
      ajax, {
        type,
        method:'post',
        values: { eventType: action.data.eventType }
      }
    );

    yield put( getActionDefinition( type, 'success' )( response.body ) );

    // check if the event fired is NoResponse Event and on success of it fire the custom event to open the modal.
    if( action.data.eventType === _NO_RESPONSE && ( has( response.body, 'success' ) && response.body.success === true ) ){

      // trigger the custom event to show the modal window from clearhead.
      let triggerForShowingModel = new CustomEvent( 'DISPLAY_REALTIME_UI', {
        detail:{
          name: _FIRST_NAME,
          cardType: _CARD_TYPE
        }
      } );

      // dispatch the custom event to open the modal
      document.dispatchEvent( triggerForShowingModel );
    }


    if( action.data.eventType === _ACCEPTED && has( response.body, 'success' ) ){

      global.location.href = `${fullyQualifyLink( host, '/creditcards/c/offer' )}?id=${action.data.preScreenId}`;
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }
}

// listener to realtimeOLPS to get the info about if the user is a preScreened user.
export const listener = function*( type, action ){

  try {
    let query = {};
    if( process.env.NODE_ENV === 'development' ){
      query.__FORCE_RES = '01';
    }

    const res = yield call(
      ajax, {
        type,
        query
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body ) ) ;

    if( has( res.body, 'olpsResponse.responseType' ) && res.body.olpsResponse.responseType === '01' ){

      // updating the constants so that we can pass this to the custom event.
      _PRESCREEN_ID = res.body.olpsResponse.preScreenId;
      _FIRST_NAME = res.body.olpsResponse.firstName;
      _CARD_TYPE = res.body.olpsResponse.cardType;
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }
}

export default function*(){
  let serviceType = 'RealtimeOLPS';
  let serviceTypeForLPSEvent = 'preScreenLPSEvent';
  // register events for the request
  registerServiceName( serviceType );
  registerServiceName( serviceTypeForLPSEvent );
  registerServiceName( 'QubitRealtimeEvent' );

  yield [
    takeEvery( getServiceType( 'RealtimeOLPS', 'requested' ), listener, serviceType ),
    takeEvery( getServiceType( 'QubitRealtimeEvent', 'requested' ), clearHeadResponse, 'QubitRealtimeEvent' )
  ];

  yield takeEvery( getServiceType( 'preScreenLPSEvent', 'requested' ), listenerForLPSEvent, serviceTypeForLPSEvent );
}
