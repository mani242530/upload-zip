import { takeEvery, call, put } from 'redux-saga/effects';
import { delay } from 'redux-saga';
import { createMockTask } from 'redux-saga/lib/utils';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import saga, { listener, listenerForLPSEvent, clearHeadResponse } from './realtime_olps.controller';

const type = 'RealtimeOLPS';
const sessionID = '44432';
const __FORCE_RES = '02'

const type2 = 'preScreenLPSEvent';

describe( 'defaultSaga Saga', () => {
  registerServiceName( type );
  describe( 'default saga', () => {
    const RealtimeOLPS = saga();
    it( 'should listen for the navigation request method', () => {
      const takeEveryDescriptor = RealtimeOLPS.next().value;
      expect( takeEveryDescriptor ).toEqual( [
        takeEvery( getServiceType( type, 'requested' ), listener, type ),
        takeEvery( getServiceType( 'QubitRealtimeEvent', 'requested' ), clearHeadResponse, 'QubitRealtimeEvent' )] );
    } );
  } );

  describe( 'listener saga success path', () => {

    const listenerSaga2 = listener( type, { __FORCE_RES } );


    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga2.next().value;

      let query = {};

      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    it( 'should put a success event after data is called', () => {

      let res = {
        'eventType': 'NoResponse'
      }

      const putDescriptor = listenerSaga2.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga2.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );


} );

describe( 'CUSTOM_MODAL_EVENT', () => {
  registerServiceName( 'QubitRealtimeEvent' );
  describe( 'default saga', () => {
    const QubitRealtimeEvent = saga();
    it( 'should listen for the navigation request method', () => {
      const takeEveryDescriptor3 = QubitRealtimeEvent.next().value;
      expect( takeEveryDescriptor3 ).toEqual(
        [takeEvery( getServiceType( type, 'requested' ), listener, type ), takeEvery( getServiceType( 'QubitRealtimeEvent', 'requested' ), clearHeadResponse, 'QubitRealtimeEvent' )]
      );
    } );
  } );
  describe( 'listener saga success path', () => {

    const listenerSaga3 = clearHeadResponse( 'QubitRealtimeEvent', { data: { eventType: 'NotAtThisTime' } } );


    it( 'should put a success event after data is called', () => {

      let res = {
        eventType: 'NotAtThisTime'
      }

      const putDescriptor = listenerSaga3.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'requested' )( res ) ) );

    } );

  } );
} );

describe( 'defaultSaga Saga', () => {
  registerServiceName( type2 );
  describe( 'default saga', () => {
    const preScreenLPSEvent = saga();
    it( 'should listen for the navigation request method', () => {
      const takeEveryDescriptor2 = preScreenLPSEvent.next().value;
      expect( takeEveryDescriptor2 ).toEqual(
        [takeEvery( getServiceType( type, 'requested' ), listener, type ), takeEvery( getServiceType( 'QubitRealtimeEvent', 'requested' ), clearHeadResponse, 'QubitRealtimeEvent' )]
      );
    } );
  } );
  describe( 'listener saga success path', () => {

    const listenerSaga = listenerForLPSEvent( type2, { data: { _dynSessConf: sessionID } } );

    it( 'should yield on requesting data and return that data with a sucess method222', () => {

      const callDescriptor = listenerSaga.next().value;

      let method = 'post';
      let values = { eventType: undefined };
      expect( callDescriptor ).toEqual( call( ajax, { type: 'preScreenLPSEvent', method, values } ) );

    } );

    it( 'should put a success event after data is called', () => {

      let res = {
        title: 'test',
        status: 'ok'
      }

      const putDescriptor = listenerSaga.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'success' )( res ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type2, 'failure' )( err ) ) );

    } );

  } );

  describe( 'listener', () => {

    const listenerSaga = listener( type, { data: { _dynSessConf: sessionID } } );

    it( 'should yield on requesting data and return that data with a sucess method222', () => {

      const callDescriptor = listenerSaga.next().value;

      let query = {};

      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    let res = {
      title: 'test',
      status: 'ok',
      olpsResponse: {
        responseType: '01',
        preScreenId:'4534',
        firstName: 'john',
        cardType: 'VISA'
      }
    }

    it( 'should put a success event after data is called', () => {

      const putDescriptor = listenerSaga.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res ) ) );

    } );

    it( 'should update the constants to pass to custom event', () => {
      listenerSaga.next().value;
      expect( res.olpsResponse.preScreenId ).toBe( '4534' );
      expect( res.olpsResponse.firstName ).toBe( 'john' );
      expect( res.olpsResponse.cardType ).toBe( 'VISA' );
    } );

  } );

} );
