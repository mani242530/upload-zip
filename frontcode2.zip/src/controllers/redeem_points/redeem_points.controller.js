import { takeEvery, call, put } from 'redux-saga/effects';
import isUndefined from 'lodash/isUndefined';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

// Individual exports for testing
export const listener = function*( type, data ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );



    let query = {};

    if( process.env.NODE_ENV === 'development' ){
      // Possible responses
      // noPoints - returns response for user with not enough loyalty points
      // serviceDown - returns reseponse if loyalty service is failing
      // query.__FORCE_RES = 'noPoints';
    }


    const res = yield call( ajax, { type, query } );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );


    // The following is to track omniture analytics errors when the service
    // returns messages back
    if( !isUndefined( res.body.data.messages ) ){

      const {
        messages
      } = res.body.data;


      const evt = {
        'name': 'trackErrorDisplayed',
        'data': messages.items.map( item => {
          return {
            'errorType': item.type,
            'errorLable': 'redeemPoints',
            'errorDescription': item.message
          }
        } )
      }

      yield put( triggerAnalyticsEvent( {}, evt ) );



    }





  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'redeemPoints';

  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
