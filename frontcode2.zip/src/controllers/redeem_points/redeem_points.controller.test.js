import { takeEvery, call, put } from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/utils';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';

import {
  ajax
} from '../../utils/ajax/ajax';


import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import saga, { listener } from './redeem_points.controller';


const type  = 'redeemPoints';

describe( 'redeemPoints Saga', () => {

  registerServiceName( type );

  const redeemPointssaga = saga();

  it( 'should listen for the navigation request method', () => {

    const takeEveryDescriptor = redeemPointssaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), listener, type ) );
  } );

  describe( 'listener saga success path', () => {

    const listenerSaga = cloneableGenerator( listener )( type );



    it( 'should wait until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );


    it( 'should yield on requesting data and return that data with a sucess method', () => {

      //      process.env.NODE_ENV = 'development';
      const callDescriptor = listenerSaga.next().value;
      const data = {
        type,
        query: {}
      }

      expect( callDescriptor ).toEqual( call( ajax, data ) );

    } );

    it( 'should put a success event after data is called', () => {

      let res = {
        data: {
          messages:{
            items: [{
              type: 'Error',
              message: 'Sorry we\'re experiencing an issue right now.'
            }]
          }
        }
      }

      const putDescriptor = listenerSaga.next( { body: res } ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.data ) ) );

    } );

    it( 'should put a success event after data is called and have pointsBalance in dataLayer', () => {

      const evt = {
        'name': 'trackErrorDisplayed',
        'data': [{
          'errorType': 'Error',
          'errorLable': 'redeemPoints',
          'errorDescription': 'Sorry we\'re experiencing an issue right now.'
        }]
      }

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( {}, evt ) ) );

    } );



    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

} )
