import {
  takeEvery,
  call,
  select
} from 'redux-saga/effects';
import { getGTI } from '../../models/view/user/user.model';
import reflektion from '../../utils/reflektion/reflektion';
import {
  TRIGGER_REFLEKTION_EVENTS
} from '../../events/reflektion/reflektion.events';

export const triggerReflektionEvent = function* ( action ){
  // the reflektion event should not be fired, if the type is 'widget' and the source of the widget is not reflektion
  if( !( action.data.type === 'widget' && action.data.value.rfkid?.toUpperCase().indexOf( 'RFK' ) === -1 ) ){
    /** *
   * GTI is the unique ID reflektion will use to track the ULTA
   * user across sessions in reflektion end. This will need to be passed for all events
   */
    const GTI = yield select( getGTI );
    const reflektionData =  { ...action.data, user_id: GTI }
    yield call( reflektion.triggerEvent, reflektionData );
  }

}

export default function*(){
  yield takeEvery( TRIGGER_REFLEKTION_EVENTS, triggerReflektionEvent );
}
