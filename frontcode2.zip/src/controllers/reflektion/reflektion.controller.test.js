
import {
  takeEvery,
  call,
  select
} from 'redux-saga/effects';
import { getGTI } from '../../models/view/user/user.model';
import { TRIGGER_REFLEKTION_EVENTS } from '../../events/reflektion/reflektion.events'
import saga, {
  triggerReflektionEvent
} from './reflektion.controller';
import reflektion from '../../utils/reflektion/reflektion';
jest.mock( './../../utils/reflektion/reflektion', () => {
  return { triggerEvent:jest.fn() }
} );


describe( 'triggerReflektionEvent sagas', () => {

  let action = {
    data:{
      'type': 'a2w',
      'name': 'pdp',
      'value': {
        'products': [
          {
            'sku': '1012219'
          }
        ]
      }
    }
  }
  const listenerSaga = triggerReflektionEvent( action );

  it( 'should select getGTI', () => {

    const selectDescriptor = listenerSaga.next( ).value;

    expect( selectDescriptor ).toEqual( select( getGTI ) );

  } );
  it( ' triggerEvent should be triggered from add favourite saga with reflektion object as data', () => {
    const callDescriptor = listenerSaga.next( ).value;
    expect( callDescriptor ).toEqual( call( reflektion.triggerEvent, action.data ) );
  } );
} );
describe( 'Reflektion saga ', () =>{
  it( 'should listen to the triggerReflektionEvent method', () =>{
    const listenerSaga1 = saga( );
    const takeLatestDescriptor = listenerSaga1.next( ).value;

    expect( takeLatestDescriptor ).toEqual(
      takeEvery( TRIGGER_REFLEKTION_EVENTS, triggerReflektionEvent )
    );
  } );
} );

describe( 'test cases for widget events', () => {

  describe( 'should fire the widget appear event for RFK events', () => {

    let action = {
      data:{
        'type': 'widget',
        'name': 'appear',
        'value': {
          'rfkid': 'RFK_RECS_CART',
          'f': 'rw'
        }
      }
    }
    const listenerSaga = triggerReflektionEvent( action );

    it( 'should select getGTI', () => {

      const selectDescriptor = listenerSaga.next( ).value;

      expect( selectDescriptor ).toEqual( select( getGTI ) );

    } );
    it( ' triggerEvent should be triggered from add favourite saga with reflektion object as data', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( reflektion.triggerEvent, action.data ) );
    } );
  } );

  describe( 'should not fire the widget appear event for non RFK events', () => {

    let action = {
      data:{
        'type': 'widget',
        'name': 'appear',
        'value': {
          'rfkid': 'QZI_RECS_CART',
          'f': 'rw'
        }
      }
    }
    const listenerSaga = triggerReflektionEvent( action );

    it( 'should not fire the reflektion events', () => {

      const selectDescriptor = listenerSaga.next( );
      expect( selectDescriptor.done ).toEqual( true );

    } );

  } );

} );
