
import {
  call,
  put,
  takeLatest,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerReflektionEvents
} from 'ulta-fed-core/dist/js/events/reflektion/reflektion.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import reflektion from '../../utils/reflektion/reflektion';
import { ajax } from '../../utils/ajax/ajax';

const reflektionSearchTypes = {
  TYPE_AHEAD_SERVICE_CALL : 'reflektionSearch',
  TOP_RESULT_SERVICE_CALL : 'fetchTopResults'
}
export const reflektionSearch = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    // searchTerm is query value for reflektionSearch API
    let enteredSearchTerm = action.data?.search_term;
    // searchInput is input value of seachbar input
    let searchInput = action.data?.search_input;
    let isWiderDevice = ( type === reflektionSearchTypes.TYPE_AHEAD_SERVICE_CALL ) && action.data?.isWiderDevice;
    const fingerPrintId = reflektion.retrieveReflektionTrackingId();
    const pageUrl = encodeURIComponent( global.location.pathname );
    const query = {
      searchTerm: encodeURIComponent( enteredSearchTerm ),
      fingerPrintId,
      pageUrl,
      ...( document.title && { pageTitle : encodeURIComponent( document.title ) } ),
      ...( type === reflektionSearchTypes.TOP_RESULT_SERVICE_CALL && searchInput !== '' && { maxKeyPhrase :1 } ),
      ...( type === reflektionSearchTypes.TOP_RESULT_SERVICE_CALL && searchInput === '' && { maxTrendingCategory :1 } )
    }
    const res = yield call( ajax,
      {
        type:'reflektionSearch',
        method:'get',
        query
      } );
    const respForReflektionSearchModel =  {
      searchTerm: enteredSearchTerm,
      skus:res.body.data.suggestion?.skus,
      ...( type === reflektionSearchTypes.TYPE_AHEAD_SERVICE_CALL && isWiderDevice && enteredSearchTerm !== '' && { categories: res.body.data.suggestion?.keyphraseCategories } ),
      ...( type === reflektionSearchTypes.TYPE_AHEAD_SERVICE_CALL && isWiderDevice && enteredSearchTerm === '' && { categories: res.body.data.suggestion?.trendingCategories } ),
      ...( type === reflektionSearchTypes.TYPE_AHEAD_SERVICE_CALL && !isWiderDevice && { categories: res.body.data.suggestion?.mobileSuggestionCategories } )
    }
    yield put( getActionDefinition( type, 'success' )( respForReflektionSearchModel ) );

    // fire the reflektion event if service type is reflektionSearch
    if( type === reflektionSearchTypes.TYPE_AHEAD_SERVICE_CALL && respForReflektionSearchModel?.categories?.items ){
      // Get ULTA switch data from store
      const switchData = yield select( makeGetSwitchesData() );
      // trigger reflektion event when a user views the preview search panel
      if( switchData.switches.enableRfkEvents ){
        yield call( triggerWidgetAppearReflektionEvent, switchData.switches.pageToRfkWidgetIdMapping.visualSearch );
      }
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}


export const triggerWidgetAppearReflektionEvent = function* ( searchWidgetId ){
  const reflektionData = {
    'type': 'widget',
    'name': 'appear',
    'value': {
      'rfkid': searchWidgetId,
      'f': 'sb'
    }
  }
  yield put( triggerReflektionEvents( reflektionData ) );
}

export default function*(){

  registerServiceName( reflektionSearchTypes.TYPE_AHEAD_SERVICE_CALL );
  registerServiceName( reflektionSearchTypes.TOP_RESULT_SERVICE_CALL );
  yield takeLatest( getServiceType( reflektionSearchTypes.TYPE_AHEAD_SERVICE_CALL, 'requested' ), reflektionSearch, reflektionSearchTypes.TYPE_AHEAD_SERVICE_CALL );
  yield takeLatest( getServiceType( reflektionSearchTypes.TOP_RESULT_SERVICE_CALL, 'requested' ), reflektionSearch, reflektionSearchTypes.TOP_RESULT_SERVICE_CALL );
}
