import {
  takeLatest,
  call,
  put,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { cloneableGenerator } from 'redux-saga/utils';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { ajax } from '../../utils/ajax/ajax';
import reflektion from '../../utils/reflektion/reflektion';
import saga, {
  reflektionSearch,
  triggerWidgetAppearReflektionEvent
} from './reflektion_search.controller';

const serviceType = 'reflektionSearch';
const fetchTopResultType = 'fetchTopResults';
reflektion.retrieveReflektionTrackingId = jest.fn( () => {
  return '123'
} );

const switchData = {
  switches: {
    enableRfkEvents:true,
    pageToRfkWidgetIdMapping : {
      visualSearch: 'RFK_RECS_TYPEAHEAD'
    }
  }
};

document.title = 'pageTitle' ;


// const listenerSagaForTrending = reflektionSearch( trendingCategoryServiceType, action );
describe( 'reflektionSearch sagas', () => {
  describe( 'reflektionSearch listener call ', () => {
    const coreSaga = saga();

    it( 'should take latest reflektion search request ', () => {
      const takeLatestDescriptor = coreSaga.next().value;
      expect( takeLatestDescriptor ).toEqual( takeLatest( getServiceType( serviceType, 'requested' ), reflektionSearch, serviceType ) );
    } );
    it( 'should take latest fetch top result request', () => {
      const takeLatestDescriptor = coreSaga.next().value;
      expect( takeLatestDescriptor ).toEqual( takeLatest( getServiceType( fetchTopResultType, 'requested' ), reflektionSearch, fetchTopResultType ) );
    } );
  } );
  describe( 'reflektion key phrase category search saga success path', () => {
    var action = {
      data:{
        search_term:encodeURIComponent( 'nail' ),
        isWiderDevice:true
      }
    };
    const listenerSagaForKeyPhrase = cloneableGenerator( reflektionSearch )( serviceType, action ) ;
    const res = {
      body: {
        data:{
          success:true,
          searchTerm:'nail',
          suggestion:{
            skus:{
              items:[{}]
            },
            keyphraseCategories:{
              items:[{}]
            }
          }
        }
      }
    };
    let listenerSagaAlternative1;
    let listenerSagaAlternative2;
    it( 'should until the loading event has been put', () => {
      const putDescriptor = listenerSagaForKeyPhrase.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'loading' )() ) );
    } );

    it( 'should yield a call with correct query value if service type is reflektionSearch', () => {
      const callDescriptor = listenerSagaForKeyPhrase.next( ).value;
      let query = {
        searchTerm :encodeURIComponent( 'nail' ),
        fingerPrintId:'123',
        pageUrl:encodeURIComponent( '/' ),
        pageTitle:encodeURIComponent( 'pageTitle' )
      }
      listenerSagaAlternative1 = listenerSagaForKeyPhrase.clone();
      listenerSagaAlternative2 = listenerSagaForKeyPhrase.clone();
      expect( callDescriptor ).toEqual( call( ajax, { type:'reflektionSearch', method:'get', query } ) );
    } );
    it( 'should put a success event with proper data after response is received', () => {
      const putDescriptor = listenerSagaForKeyPhrase.next( res ).value;
      let respForReflektionSearchModel = {
        searchTerm: encodeURIComponent( 'nail' ),
        skus:{
          items:[{}]
        },
        categories:{
          items:[{}]
        }
      };
      expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'success' )( respForReflektionSearchModel ) ) );
    } );

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSagaForKeyPhrase.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should trigger reflektion event when there is data and enableReflektionEvents flag is true', () => {
      const callDescriptor = listenerSagaForKeyPhrase.next( switchData ).value;
      expect( callDescriptor ).toEqual( call( triggerWidgetAppearReflektionEvent, switchData.switches.pageToRfkWidgetIdMapping.visualSearch ) );

    } );
    describe( 'alternative scenario shouldnt call reflektion event when enableRfkEvents is false ', () => {
      const switchData2 = {
        switches: {
          enableRfkEvents:false,
          pageToRfkWidgetIdMapping : {
            visualSearch: 'RFK_RECS_TYPEAHEAD'
          }
        }
      };
      let respForReflektionSearchModel = {
        searchTerm: encodeURIComponent( 'nail' ),
        skus:{
          items:[{}]
        },
        categories:{
          items:[{}]
        }
      };
      it( 'should put a success event after data is called', () => {
        const putDescriptor = listenerSagaAlternative1.next( res ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'success' )( respForReflektionSearchModel ) ) );
      } );

      it( 'should do a select on makeGetSwitchesData', () => {
        const selectDescriptor = listenerSagaAlternative1.next().value;
        expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
      } );

      it( 'should be done', () => {
        const callDescriptor = listenerSagaAlternative1.next( switchData2 );
        expect( callDescriptor.done ).toEqual( true );
      } );
    } );

    describe( 'alternative scenario shouldnt call reflektion event if result is empty', () => {
      it( 'should put a success event after data is called', () => {
        const res = {
          body: {
            data:{
              success:true,
              searchTerm:'nail',
              suggestion:{
                skus:null,
                keyphraseCategories:null
              }
            }
          }
        };
        let respForReflektionSearchModel = {
          searchTerm: encodeURIComponent( 'nail' ),
          skus:null,
          categories:null
        };
        const putDescriptor = listenerSagaAlternative2.next( res ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'success' )( respForReflektionSearchModel ) ) );
      } );

      it( 'should be done', () => {
        const callDescriptor = listenerSagaAlternative2.next()
        expect( callDescriptor.done ).toEqual( true );
      } );
    } );
    describe( 'reflektionSearch saga failure path', () => {

      it( 'should put a failure event if no data is returned from the service', () => {
        window.TRACK_SAGA_FAILURES = true;
        const err = {
          statusText:'some failure message'
        }
        const putDescriptor = listenerSagaForKeyPhrase.throw( err, window ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'failure' )( err ) ) );
      } );

    } );
  } );
  describe( 'reflektion fetch top results saga success path', () => {

    describe( 'fetch top result when user hover on trending categories ', () => {
      var action = {
        data:{
          search_term:encodeURIComponent( 'nail' ),
          search_input:''
        }
      };
      const res = {
        body: {
          data:{
            success:true,
            searchTerm:'nail',
            suggestion:{
              skus:{
                items:[{}]
              },
              trendingCategories:{
                items:[{}]
              }
            }
          }
        }
      };
      const listenerSagaForTopResultFromTrendingCategory = reflektionSearch( fetchTopResultType, action );
      it( 'should yield a call with correct query value if service type is fetch top results', () => {
        document.title = '' ;
        listenerSagaForTopResultFromTrendingCategory.next();
        const callDescriptor = listenerSagaForTopResultFromTrendingCategory.next().value;
        let query = {
          searchTerm :encodeURIComponent( 'nail' ),
          fingerPrintId:'123',
          pageUrl:encodeURIComponent( '/' ),
          maxTrendingCategory:1
        };expect( callDescriptor ).toEqual( call( ajax, { type:'reflektionSearch', method:'get', query } ) );
      } );
      it( 'shouldnt call reflektion event if service type is fetch top results', () => {
        listenerSagaForTopResultFromTrendingCategory.next( res );// success event
        const callDescriptor = listenerSagaForTopResultFromTrendingCategory.next()
        expect( callDescriptor.done ).toEqual( true );
      } );

    } );
    describe( 'fetch top result when user hover on keyphrase categories ', () => {
      var action = {
        data:{
          search_term:encodeURIComponent( 'nail' ),
          search_input:'nai',
          isWiderDevice:true
        }
      };
      const listenerSagaForTopResultFromKeyphraseCategory = reflektionSearch( fetchTopResultType, action );
      it( 'should yield a call with correct query value if service type is fetch top results', () => {
        document.title = '' ;
        listenerSagaForTopResultFromKeyphraseCategory.next();
        const callDescriptor = listenerSagaForTopResultFromKeyphraseCategory.next().value;
        let query = {
          searchTerm :encodeURIComponent( 'nail' ),
          fingerPrintId:'123',
          pageUrl: encodeURIComponent( '/' ),
          maxKeyPhrase:1
        };expect( callDescriptor ).toEqual( call( ajax, { type:'reflektionSearch', method:'get', query } ) );
      } );
    } );
  } );
  describe( 'reflektion trending category search saga success path', () => {
    var action = {
      data:{
        search_term:'',
        isWiderDevice:true
      }
    };
    const listenerSagaForTrendingCat = cloneableGenerator( reflektionSearch )( serviceType, action ) ;
    const res = {
      body: {
        data:{
          success:true,
          searchTerm:'',
          suggestion:{
            skus:{
              items:[{}]
            },
            trendingCategories:{
              items:[{}]
            }
          }
        }
      }
    };
    it( 'should yield a call with correct query value if service type is trendingCategories', () => {
      listenerSagaForTrendingCat.next(); // loading
      document.title = 'pageTitle' ;
      const callDescriptor = listenerSagaForTrendingCat.next( ).value;
      let query = {
        searchTerm :'',
        fingerPrintId:'123',
        pageUrl:encodeURIComponent( '/' ),
        pageTitle:encodeURIComponent( 'pageTitle' )
      };
      expect( callDescriptor ).toEqual( call( ajax, { type:'reflektionSearch', method:'get', query } ) );
    } );
    it( 'should put a success event after data is called', () => {
      const putDescriptor = listenerSagaForTrendingCat.next( res ).value;
      let respForReflektionSearchModel = {
        searchTerm: '',
        skus:{
          items:[{}]
        },
        categories:{
          items:[{}]
        }
      };
      expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'success' )( respForReflektionSearchModel ) ) );
    } );
    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSagaForTrendingCat.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should trigger reflektion event when there is data and enableReflektionEvents flag is true', () => {
      const callDescriptor = listenerSagaForTrendingCat.next( switchData ).value;
      expect( callDescriptor ).toEqual( call( triggerWidgetAppearReflektionEvent, switchData.switches.pageToRfkWidgetIdMapping.visualSearch ) );

    } );
  } );
  describe( 'reflektion trending category search for mobile', () => {
    var action = {
      data:{
        search_term:'',
        isWiderDevice:false
      }
    };
    const listenerSagaForTrendingCat = cloneableGenerator( reflektionSearch )( serviceType, action ) ;
    const res = {
      body: {
        data:{
          success:true,
          searchTerm:'',
          suggestion:{
            skus:{
              items:[{}]
            },
            mobileSuggestionCategories:{
              items:[{}]
            }
          }
        }
      }
    };
    it( 'should fetch the mobileSuggestionCategories when isWiderDevice as false', () => {
      listenerSagaForTrendingCat.next(); // loading
      listenerSagaForTrendingCat.next( ).value;
      const putDescriptor = listenerSagaForTrendingCat.next( res ).value;
      let respForReflektionSearchModel = {
        searchTerm: '',
        skus:{
          items:[{}]
        },
        categories:{
          items:[{}]
        }
      };
      expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'success' )( respForReflektionSearchModel ) ) );
    } );

  } );
} );


