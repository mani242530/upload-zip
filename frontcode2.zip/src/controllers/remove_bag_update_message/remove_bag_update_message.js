import { takeEvery, call, put } from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  ajax
} from '../../utils/ajax/ajax';

export const listener = function*( type ){

  try {
    yield put( getActionDefinition( type, 'loading' )( ) );

    const res = yield call(
      ajax, {
        type,
        method:'post'
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body.success ) );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    console.error( err.message ); //eslint-disable-line
  }
};

export default function*(){
  let serviceType = 'removeBagUpdateMessage';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
