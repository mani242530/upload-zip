import {
  takeEvery,
  call,
  put
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { ajax } from '../../utils/ajax/ajax';
import saga, {
  listener
} from './remove_bag_update_message';

const type = 'removeBagUpdateMessage';
const listenerSaga = listener( type );
describe( 'remove bag update messages sagas', () => {
  const coreSaga = saga( );
  registerServiceName( type );

  it( 'should take every removeBagUpdateMessage request on click of the close button in bag update', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), listener, type ) );
  } );


  describe( 'removeBagUpdateMessage saga success path', () => {

    it( 'should put loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should put an actition to request data clear message and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( ajax, { type:'removeBagUpdateMessage', method:'post' } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          success:true
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.success ) ) );
    } );

  } );

  describe( 'removeBagUpdateMessage saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

} );