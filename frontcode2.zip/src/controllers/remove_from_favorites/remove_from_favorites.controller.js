import {
  takeEvery,
  call,
  put,
  cancelled,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { ajax } from '../../utils/ajax/ajax';
import { getProductDetailsState } from '../../models/view/product_page/product_page.model';

export const removeFromFavorites = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const res = yield call(
      ajax, {
        type:'removeFavorite',
        method:'post',
        values:action.data
      }
    );
    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data.success ){
      const evt = {
        name: 'removeFromFavoritesClick',
        data:{
          productSku :action.data.skuId
        }
      }
      yield put( triggerAnalyticsEvent( evt ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}
export default function(){
  return function*( ){
    const pdpServiceType = 'pdpRemoveFavorite';
    registerServiceName( pdpServiceType );
    yield takeEvery( getServiceType( pdpServiceType, 'requested' ), removeFromFavorites, pdpServiceType );

    const qsServiceType = 'qsRemoveFavorite';
    registerServiceName( qsServiceType );
    yield takeEvery( getServiceType( qsServiceType, 'requested' ), removeFromFavorites, qsServiceType );
  }
}
