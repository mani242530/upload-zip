import {
  takeEvery,
  call,
  put,
  cancelled,
  take,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { cloneableGenerator } from 'redux-saga/utils';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { ajax } from '../../utils/ajax/ajax';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import { getProductDetailsState } from '../../models/view/product_page/product_page.model';
import CONFIG from '../../modules/pdp/pdp.config';
import saga, {
  removeFromFavorites
} from './remove_from_favorites.controller';

const type = 'pdpRemoveFavorite';
const serviceType = 'qsRemoveFavorite';
const action = {
  data:{
    skuId: 2241934,
    favoriteId : 123567
  }
}
const listenerSaga = removeFromFavorites( type, action );
describe( 'removeFromFavorites sagas', () => {
  const coreSaga = saga( CONFIG )();
  registerServiceName( type );

  it( 'should take every removeFromFavorites request from pdp', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), removeFromFavorites, type ) );
  } );

  it( 'should take every removeFromFavorites request from quick shop', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( serviceType, 'requested' ), removeFromFavorites, serviceType ) );
  } );

  describe( 'removeFromFavorites saga success path', () => {

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      let values = action.data;

      expect( callDescriptor ).toEqual( call( ajax, { type:'removeFavorite', method:'post', values } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            success:true
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should fire a trigger removeFromFavoritesClick', () => {
      const evt = {
        'name': 'removeFromFavoritesClick',
        'data':{
          'productSku':action.data.skuId
        }
      }
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );

  } );

  describe( 'removeFromFavorites saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

} );
