import { takeEvery, call, put } from 'redux-saga/effects';
import { delay } from 'redux-saga';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  ajax
} from '../../utils/ajax/ajax';
import SaveForLaterItemsMessages from '../../views/SaveForLaterItems/SaveForLaterItems.messages';
import {
  showSaveForLaterRemovedSuccessMessage
} from '../../events/save_for_later/save_for_later.events';

export const listener = function*( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )( action.data.sflItemId ) );
    // we are broadCasting an empty message because the screen reader will not read the same message which is populated in the globalAssertiveRegion div( which is in index.html).
    yield put( setBroadcastMessage( '' ) );

    let query = { sflItemId:action.data.sflItemId }
    // delay to show spinner
    yield call( delay, 2000 );

    const res = yield call(
      ajax, {
        type,
        method:'post',
        query
      }
    );

    if( res.body.data ){
      // to set falg to show the removed message in the product level
      yield put( showSaveForLaterRemovedSuccessMessage( action.data.sflItemId ) );
      yield put( setBroadcastMessage( formatMessage( SaveForLaterItemsMessages.removeSaveForLaterLabel ) ) );

      yield put( getActionDefinition( type, 'success' )( res.body.data ) );

      /* Trigger Analytics event on bagSaveForLaterRemove success */
      const evt = {
        'name': 'bagSaveForLaterRemove',
        'data': {
          'productSku' : action.data.skuId
        }
      }
      yield put( triggerAnalyticsEvent( evt ) );
    }

    const numberOfSFLItems = action.data.numberOfSFLItems - 1;

    if( res.body.data.totalNumRecs > numberOfSFLItems ){
      yield put( getActionDefinition( 'saveForLater', 'requested' )( { start: numberOfSFLItems, limit: 1 } ) );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    console.error( err.message ); //eslint-disable-line
  }
};

export default function*(){
  let serviceType = 'saveForLaterItemRemove';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
