import { takeEvery, call, put } from 'redux-saga/effects';
import { delay } from 'redux-saga';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';


import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { initializeIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import React from 'react';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  initialState as initialStateGlobal
} from '../../models/view/global/global.model';
import {
  ajax
} from '../../utils/ajax/ajax';
import CONFIG from '../../modules/ccr/ccr.config';
import configureStore from '../../modules/ccr/ccr.store';
import SaveForLaterItemsMessages from '../../views/SaveForLaterItems/SaveForLaterItems.messages';
import {
  showSaveForLaterRemovedSuccessMessage
} from '../../events/save_for_later/save_for_later.events';
import saga, { listener } from './remove_from_save_for_later.controller';

const type = 'saveForLaterItemRemove';

describe( 'saveForLaterItemRemove Saga', () => {

  registerServiceName( type );
  registerServiceName( 'saveForLater' );
  const saveForLaterItemRemoveSaga = saga();

  initializeIntl();

  describe( 'default saga', () => {
    it( 'should listen for the saveForLaterItemRemove request method', () => {
      const takeEveryDescriptor = saveForLaterItemRemoveSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), listener, type )
      );
    } );
  } );

  describe( 'listener saga', () => {
    let action = {
      data: {
        sflItemId :'gi1234',
        numberOfSFLItems: 19,
        skuId: '2286651'
      }
    };
    const res = {
      body: {
        data: {
          saveForLaterItems: {
            items: [
              {
                product: {
                  id: 'xlsImpprod12251073'
                },
                messages: null,
                sflItemId: 'gi115200003'
              }
            ]
          },
          numberOfPages: 1,
          totalNumRecs: 25,
          messages: null
        }
      }
    };
    const listenerSaga = listener( type, action );

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( action.data.sflItemId ) ) );
    } );

    it( 'should put setBroadcastMessage action with empty message', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( '' ) ) );
    } );

    it( 'should call delay API - to show spinner', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( delay, 2000 ) );
    } );

    it( 'should call saveForLater remove API', () => {
      let query = { sflItemId:action.data.sflItemId }
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( ajax, { type, method:'post', query } ) );
    } );

    it( 'should put a success event to show removed message if items got removed successfully', () => {
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( showSaveForLaterRemovedSuccessMessage( action.data.sflItemId ) ) );
    } );

    it( 'should put setBroadcastMessage action with removeSaveForLater transition message', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( formatMessage( SaveForLaterItemsMessages.removeSaveForLaterLabel ) ) ) );
    } );

    it( 'should put a success event after data is called', () => {
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should trigger analytics event named bagSaveForLaterRemove after success', () => {
      const evt = {
        'name': 'bagSaveForLaterRemove',
        'data': {
          'productSku' : action.data.skuId
        }
      }
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );

    it( 'should put a saveForLater requested event when totalNumRecs in res is greater than numberOfSFLItems in action', () => {
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'saveForLater', 'requested' )( { start: action.data.numberOfSFLItems - 1, limit: 1 } ) ) );
    } );

    it( 'should not put a saveForLater requested after saveForLaterItemRemove success when totalNumRecs in res is lesser than numberOfSFLItems in action', () => {
      let action = {
        data: {
          sflItemId :'gi1234',
          numberOfSFLItems: 19
        }
      };
      const res = {
        body: {
          data: {
            saveForLaterItems: {
              items: [
                {
                  product: {
                    id: 'xlsImpprod12251073'
                  },
                  messages: null,
                  sflItemId: 'gi115200003'
                }
              ]
            },
            numberOfPages: 1,
            totalNumRecs: 18,
            messages: null
          }
        }
      };

      const listenerSaga = listener( type, action );

      listenerSaga.next( ); // this is saveForLaterItemRemove loading event
      listenerSaga.next( ); // this is setBroadcastMessage action with empty message
      listenerSaga.next( ); // this is spinner delay call
      listenerSaga.next( ); // this is saveForLaterItemRemove ajax call
      listenerSaga.next( res ); // this is showSaveForLaterRemovedSuccessMessage action
      listenerSaga.next( ); // this is setBroadcastMessage action with removeSaveForLater transition message
      listenerSaga.next( res ); // this is saveForLaterItemRemove success event
      listenerSaga.next( ); // this is this is triggerAnalyticsEvent action
      const putDescriptor = listenerSaga.next( res ); // this is saveForLater requested event
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'saveForLater', 'requested' )( ) ) );
      expect( putDescriptor.done ).toEqual( true );
    } );


    describe( 'failure path', () => {
      const err = {
        statusText:'some failure message'
      };

      it( 'should put a failure event if no data is returned from the service', () => {
        const putDescriptor = listenerSaga.throw( err ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );
    } );
  } );
} );
