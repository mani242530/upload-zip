import {
  takeEvery,
  call,
  put,
  cancelled,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { ajax } from '../../utils/ajax/ajax';

export const resetCredential = function* ( type, action ){
  try {
    // fetches token and email from passwordreset link that had sent to user's email
    // This validates whether the link is expired or not and redirect the page to either /reset-password-error or /reset-password respectively.
    const query = new URLSearchParams( action.data.location.search );
    const token = query.get( 't' );
    const emailId = query.get( 'e' );
    yield put( getActionDefinition( type, 'loading' )() );
    const postData =  { e: emailId, t: token };
    const res = yield call(
      ajax, {
        type:'resetCredential',
        method:'post',
        values: postData
      }
    );
    // we are passing the request params instead of response data because in the response we will have 'success' as true or false,
    // depending upon that we will route the user to homepage and we are not storing 'success' variable in the reducer. So we are not capturing the response data.
    yield put( getActionDefinition( type, 'success' )( postData ) );

    if( res.body.data.success !== true ){
      let expiredPath = `${action.data.passwordResetRoute}reset-password-error`;
      action.data.history.push( expiredPath );
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}
export default function(){
  return function*( ){
    const serviceType = 'resetCredential';
    registerServiceName( serviceType );
    yield takeEvery( getServiceType( serviceType, 'requested' ), resetCredential, serviceType );
  }
}
