import {
  takeEvery, call, put, select
} from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import get from 'lodash/get';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  ajax
} from '../../utils/ajax/ajax';


export const listener = function*( type, CONFIG, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    let query = {};
    // get global switch data to check the saveForLaterItem limit
    const switchData = yield select( makeGetSwitchesData() );
    // limit of number of SFL items returned in response.
    // By default, limit will be set as saveForLaterItemLimit in CONFIG, when action.data.limit or sflPageSize ( saveForLaterItemLimit obtained from config service ) is undefined
    query.limit = get( action, 'data.limit' ) || get( switchData, 'switches.sflPageSize' ) || CONFIG.SAVEFORLATER.saveForLaterItemLimit
    query.start = get( action, 'data.start' ) || 0 ; // By default start will be 0

    const res = yield call(
      ajax, {
        type,
        query,
        method:'get'
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    console.error( err.message ); //eslint-disable-line
  }
};


export default function( CONFIG ){
  return function*(){
    let serviceType = 'saveForLater';
    // register events for the request
    registerServiceName( serviceType );
    yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType, CONFIG );
  }
}
