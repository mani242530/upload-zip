import {
  takeEvery, call, put, select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  ajax
} from '../../utils/ajax/ajax';
import CONFIG from '../../modules/ccr/ccr.config';
import saga, { listener } from './save_for_later.controller';

const type = 'saveForLater';

describe( 'SaveForLater Saga', () => {

  registerServiceName( type );
  const saveForLaterSaga = saga( CONFIG )();

  describe( 'default saga', () => {
    it( 'should listen for the saveForLater request method', () => {
      const takeEveryDescriptor = saveForLaterSaga.next().value;

      expect( takeEveryDescriptor ).toEqual(
        takeEvery( getServiceType( type, 'requested' ), listener, type, CONFIG )
      );
    } );
  } );

  describe( 'listener saga', () => {
    let action = {};
    const res = {
      body: {
        data: {
          saveForLaterItems: {
            items: [
              {
                product: {
                  id: 'xlsImpprod12251073'
                },
                messages: null,
                sflItemId: 'gi115200003'
              }
            ]
          },
          numberOfPages: 1,
          totalNumRecs: 1,
          messages: null
        }
      }
    };
    const listenerSaga = listener( type, CONFIG, action );

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should select Switch Data to get the sflPageSize,saveForLaterItemLimit obtained from config service', () => {
      const selectDescriptor = listenerSaga.next( ).value;

      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should call saveForLater API - start query paramter will be set to 0 since no value is passed in the action', () => {
      let query = {};
      query.limit = CONFIG.SAVEFORLATER.saveForLaterItemLimit
      query.start = 0
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( ajax, { type, query, method: 'get' } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should call saveForLater API - start query paramter will be set to start, limit number when start, limit are passed in the action', () => {
      let action = {
        data: {
          start: 20,
          limit: 1
        }
      };

      let query = {};
      query.limit = 1
      query.start = 20

      const listenerSaga = listener( type, CONFIG, action );
      listenerSaga.next( ); // this is saveForLater loading event
      listenerSaga.next( ); // this is fetch the sflPageSize from config (switchData)
      const callDescriptor = listenerSaga.next( ).value; // this is saveForLater ajax call

      expect( callDescriptor ).toEqual( call( ajax, { type, query, method: 'get' } ) );
    } );

    describe( 'failure path', () => {
      const err = {
        statusText:'some failure message'
      };

      it( 'should put a failure event if no data is returned from the service', () => {
        const putDescriptor = listenerSaga.throw( err ).value;

        expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      } );
    } );

    describe( 'listener saga - Success with start parameter value passed in action ', () => {
      let action = {
        data: {
          start: 5
        }
      }
      const listenerSaga = listener( type, CONFIG, action );
      it( 'should call saveForLater API with start query parameter as the value passed in action', () => {
        let query = {};
        query.limit = CONFIG.SAVEFORLATER.saveForLaterItemLimit
        query.start = 5
        listenerSaga.next( ); // this is trigger saveForLater loading action
        listenerSaga.next( ); // this is fetch the sflPageSize from config (switchData)
        const callDescriptor = listenerSaga.next( ).value;
        expect( callDescriptor ).toEqual( call( ajax, { type, query, method: 'get' } ) );
      } );

    } );

    describe( 'listener saga - Success with limit parameter value not passed in action, the value is passed from BE config service.', () => {
      let action = { }
      const listenerSaga = listener( type, CONFIG, action );
      it( 'should call saveForLater API with start query parameter as the value passed in action', () => {
        let query = {};

        listenerSaga.next( ); // this is trigger saveForLater loading action
        listenerSaga.next( ); // this is fetch the sflPageSize from config (switchData)
        const switchData = {
          switches:{
            sflPageSize:10
          }
        }
        query.limit = switchData.switches.sflPageSize;
        query.start = 0
        const callDescriptor = listenerSaga.next( switchData ).value;
        expect( callDescriptor ).toEqual( call( ajax, { type, query, method: 'get' } ) );
      } );

    } );

  } );
} );
