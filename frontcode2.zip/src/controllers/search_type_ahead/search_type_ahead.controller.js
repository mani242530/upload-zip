import { takeLatest, call, put } from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  REQUEST_SEARCH_RESULTS
} from '../../events/type_ahead_search/type_ahead_search.events';


// Individual exports for testing
export const listener = function*( type, action ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );

    let date = new Date();
    let timeStamp = date.setHours( date.getHours(), 0, 0, 0 );
    let val = action.query.value.trim();

    val = val
      .replace( /\\/g, '' )
      .replace( /\//g, '' )
      .replace( /\%/g, '' );

    const res =      yield call( ajax,
      {
        type,
        query: {
          format: 'json',
          Dy: 1,
          Ntt:`${action.query.value.trim()}*`,
          Nr: 'OR(AND(product.isLive:1,sku.isLive:1,NOT(product.category:Gifts:Gifts with Purchase)),keywords:1)',
          Nf: `product.startDate|LTEQ+${ timeStamp }`

        }
      } );

    yield put( getActionDefinition( type, 'success' )( res.body.contents[0].autoSuggest[0].dimensionSearchGroups ) ) ;

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function*(){
  let serviceType = 'searchTypeAhead';
  // register events for the request
  registerServiceName( serviceType );

  yield takeLatest( REQUEST_SEARCH_RESULTS, listener, serviceType );

}
