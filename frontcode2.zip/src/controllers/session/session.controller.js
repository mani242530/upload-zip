import {
  takeEvery, take, call, put, select, cancel
} from 'redux-saga/effects';
import isUndefined from 'lodash/isUndefined';
import has from 'lodash/has';
import {
  SESSION_TOKEN_REQUESTED,
  sessionTimeout,
  sessionTokenRequested,
  persistSessionData,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { makeGetSessionInfo } from '../../models/view/session/session.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';

import { saveUserData, getUserData } from '../../utils/user_storage/user_storage';
import { authorizeLoad } from '../../events/authorize/authorize.events';
import {
  loadState, removePickupSmsInfo
} from '../../utils/local_storage/local_storage';

import appConstants from '../../shared/appConstants';


import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import {
  ajax
} from '../../utils/ajax/ajax';



export const listener = function*( type, CONFIG ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );

    let res, token;

    // get the stored token (secure and unsecure ) information from the reduxstore
    const sessionData = yield select( makeGetSessionInfo() );

    // check to see if the cookie is an object, if not we need to clear it out and allw the code to recreate it

    const {
      secureToken,
      unsecureToken
    } = sessionData;

    // get the previous session values in the store
    const isSecureProtocol = global.location.protocol === 'https:';

    // handle session requests for non secure protocols
    // and if there isn't a usecureToken store we can request
    if( !isSecureProtocol && isUndefined( unsecureToken ) || isSecureProtocol && isUndefined( secureToken ) ){
      res = yield call( ajax, { type } );
      token = res.body.sessionConfirmationNumber;

      // if token retuned is -1, it indicates that the application has already received a valid token as part of another token call
      // in this case the valid token call previously received will be available in the cookie, and can be retrieved invoking the loadstate method
      if( token === '-1' ){
        let persistedState = loadState();
        token = persistedState.session.secureToken || '-1';
      }
      // we need to save the data to the store immeditely to prevent the scenariod
      // where the requested session is being lost due to an action being performed
      // before the config saga resolves due to something like a slow connection
      yield put( persistSessionData( isSecureProtocol, token ) );

      localStorage.setItem( appConstants.SESSION_DATA, JSON.stringify( {} ) );
    }

    // when navgating back to the secure page the response from
    // the token service would be a -1, which would then cause the services
    // to use 0 as the session toekn for requests, which would throw false positives
    // against the 409 session management

    // reset the timeout in flight var
    TIMEOUTINFLIGHT = false;

    let switchData  = yield select( makeGetSwitchesData() );

    // if there is no switchData request it
    if( isUndefined( switchData ) ){
      // get the switches data
      yield put( getActionDefinition( 'switches', 'requested' )() );
      // wait for the switches data before continue
      const switchResponse = yield take( getServiceType( 'switches', 'success' ) );
      switchData = switchResponse.data;
    }

    yield put( getActionDefinition( type, 'success' )( {
      activeSession: true
    } ) ) ;
    yield put( getActionDefinition( 'deviceID', 'requested' )() );
  }
  catch ( err ){
    TIMEOUTINFLIGHT = false;
    yield put( getActionDefinition( type, 'failure' )( err ) );

    console.error( err ); //eslint-disable-line

  }
}

export const getDeviceID = function* ( type ){

  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let res;
    let deviceID = yield call( getUserData, 'deviceID' );
    if( ! deviceID ){
      res = yield call(
        ajax, {
          type:'deviceID',
          method:'get'
        }
      );
    }
    if( res ){
      deviceID = res.body.data?.clientId
      yield call( saveUserData, 'deviceID', deviceID );
    }
    yield put( getActionDefinition( type, 'success' )( deviceID ) );
  }
  catch ( err ){
    console.error( err ); //eslint-disable-line
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }

}

export default function( CONFIG ){
  return function*(){
    let serviceType = 'session';
    // register events for the request
    registerServiceName( serviceType );

    yield takeEvery( SESSION_TOKEN_REQUESTED, listener, serviceType, CONFIG );

    const deviceIdServiceType = 'deviceID';
    registerServiceName( deviceIdServiceType );
    yield takeEvery( getServiceType( deviceIdServiceType, 'requested' ), getDeviceID, deviceIdServiceType );
  }

}

export var TIMEOUTINFLIGHT = false;

export const setInFlight = ( isInFlight ) => {
  TIMEOUTINFLIGHT = isInFlight;
}

export const getInFlight = () => {
  return TIMEOUTINFLIGHT;
}

export const sessionManager = function*(){

  yield takeEvery( '*', watchSession )
}

export const watchSession = function*( action ){

  try {

    const isSessionExpired = action.data?.status === appConstants.RESPONSE_CODE.SESSION_EXPIRED;
    const isTokenMismatch = action.data?.status === appConstants.RESPONSE_CODE.TOKEN_MISMATCH;

    if( ( isSessionExpired || isTokenMismatch ) && !TIMEOUTINFLIGHT ){

      TIMEOUTINFLIGHT = true;

      if( process.env.NODE_ENV === 'development' ){
        global._DEBUG_TIMEOUT = true;
      }
      // inform the application that a timeout has happened so it can respond
      // this also clears out all of the previous stored token data
      // ( undecureToken, secureToken, and active session )
      yield put( sessionTimeout() );

      // once the session timesout, clear the sms pickup info from local storage
      yield call( removePickupSmsInfo );

      // if it is a token mismatch, make a call to invalidate the current jsession
      if( isTokenMismatch ){
        yield call( ajax, { type:'invalidate', method:'post' } );
      }

      // once we have remove the old session data we are clear to go aehad and
      // get a new token
      yield put( sessionTokenRequested() );

    }

    else if( action.data?.status === appConstants.RESPONSE_CODE.UNAUTHORIZED ){
      yield put( authorizeLoad( { url:global.location.pathname, search:global.location.search, forceAuthorize:true } ) );
    }
  }
  catch ( err ){
    TIMEOUTINFLIGHT = false;

    console.error( err ); //eslint-disable-line

  }
}
