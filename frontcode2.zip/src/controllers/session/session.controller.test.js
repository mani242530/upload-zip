/**
 * Session  sagas
 */

import {
  takeEvery, call, put, select, take
} from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/utils';
import {
  SESSION_TOKEN_REQUESTED,
  sessionTimeout,
  sessionTokenRequested,
  persistSessionData,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { saveUserData, getUserData } from '../../utils/user_storage/user_storage';
import { makeGetSessionInfo } from '../../models/view/session/session.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import CONFIG from '../../config';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import { authorizeLoad } from '../../events/authorize/authorize.events';
import appConstants from '../../shared/appConstants';

import {
  ajax
} from '../../utils/ajax/ajax';

import saga, {
  listener, watchSession, setInFlight, getInFlight, getDeviceID
} from './session.controller';
import { removePickupSmsInfo } from '../../utils/local_storage/local_storage';


jest.mock( './../../utils/local_storage/local_storage', ()=>{
  return {
    loadState:()=> {
      return {
        session:{
          secureToken:'-123456789'
        }
      }
    },
    removePickupSmsInfo:jest.fn()
  }
} );
jest.mock( '../../utils/user_storage/user_storage', ()=>{
  return {
    getUserData:jest.fn(),
    saveUserData:jest.fn()
  }
} );

const type = 'session';
const deviceID = 'deviceID';
const setItemSpy = jest.spyOn( Storage.prototype, 'setItem' );

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );
  registerServiceName( 'switches' );
  registerServiceName( deviceID );

  describe( 'default saga', () => {

    const navigationSaga = saga( CONFIG )();

    it( 'should listen for the navigation requested method', () => {

      const takeEveryDescriptor = navigationSaga.next( type, CONFIG ).value;
      expect( takeEveryDescriptor ).toEqual( takeEvery( SESSION_TOKEN_REQUESTED, listener, type, CONFIG ) );
    } );

    it( 'should listen for the deviceID requested method', () => {
      const takeEveryDescriptor1 = navigationSaga.next().value;
      expect( takeEveryDescriptor1 ).toEqual( takeEvery( getServiceType( deviceID, 'requested' ), getDeviceID, deviceID ) );
    } );

  } );
  describe( 'WatchSession Saga', () => {
    const action = {
      data:{
        status: 409
      }
    }
    const watchSessionSaga = watchSession( action );

    it( 'should inform of SessionTimeout', () => {

      process.env.NODE_ENV = 'development';
      window._DEBUG_TIMEOUT = true;
      const putDescriptor = watchSessionSaga.next().value;
      // the NODE_ENV variable needs to be reset to it original value i.e.test or else it will affect other test cases.
      // resetting it before the 'expect' so that the value will be reset even in those case where expect fails
      process.env.NODE_ENV = 'test';
      expect( putDescriptor ).toEqual( put( sessionTimeout() ) );

    } );

    it( 'should invoke removePickupSmsInfo', () => {
      const putDescriptor = watchSessionSaga.next().value;
      expect( putDescriptor ).toEqual( call( removePickupSmsInfo ) );

    } );

    it( 'should invoke request for Session Token', () => {
      const putDescriptor = watchSessionSaga.next().value;
      expect( putDescriptor ).toEqual( put( sessionTokenRequested() ) );

    } );


  } );

  describe( 'tests for TIMEOUTINFLIGHT getter and setter', () => {
    it( 'should get the same value for TIMEOUTINFLIGHT from getInFlight which was set using setInFlight', () => {
      setInFlight( true );
      expect( getInFlight() ).toBe( true );
      setInFlight( false );
      expect( getInFlight() ).toBe( false );
    } )
  } )

  describe( 'listener saga success path', () => {

    let listenerSagaNoSwitches;
    let listenerSagaSwitches;

    const listenerSaga = cloneableGenerator( listener )( type, CONFIG );
    let listnerSagaClone;
    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on selecting the latest request timestamp from the store', () => {

      let selectDescriptor = listenerSaga.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( ( select( makeGetSessionInfo() ) ) ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next( { lastFetchedData:{} } ).value;

      expect( callDescriptor ).toEqual( call( ajax, { type } ) );

    } );

    it( 'should put presistsessiondata event with token data', () => {
      listnerSagaClone = listenerSaga.clone();
      let res = {
        sessionConfirmationNumber: 8000
      }
      const putDescriptor = listenerSaga.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( persistSessionData( false, res.sessionConfirmationNumber ) ) );
    } );

    it( 'should put presistsessiondata with the existing token value in the cookie if new token returned is -1', () => {
      let res = {
        sessionConfirmationNumber: '-1'
      }
      const putDescriptor = listnerSagaClone.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( persistSessionData( false, '-123456789' ) ) );
    } );


    it( 'should get the switchData using a selector', () => {

      listenerSagaSwitches = listenerSaga.clone();
      const selectDescriptor = listenerSagaSwitches.next().value;
      listenerSagaNoSwitches = listenerSagaSwitches.clone();
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );

    } );

    it( 'should set session data to local storage with empty object', () => {
      expect( setItemSpy ).toHaveBeenCalledWith( appConstants.SESSION_DATA, JSON.stringify( {} ) );
    } );


    it( 'should put an event to trigger the switches data, in case the switchdata is not already available in the state', () => {

      const putDescriptor = listenerSagaNoSwitches.next().value;
      // console.log( putDescriptor );
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'switches', 'requested' )() ) );
    } );

    it( 'should take the value from the swtiches data', () => {
      const takeDescriptor = listenerSagaNoSwitches.next( ).value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'switches', 'success' ) ) );

    } );

    it( 'should put a success event after data is called', () => {
      const putDescriptor = listenerSagaNoSwitches
        .next( { activeSession : true } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { activeSession: true } ) ) );


    } );

    it( 'should put a request to get deviceID', () => {
      const putDescriptor = listenerSagaNoSwitches.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( deviceID, 'requested' )() ) );


    } );

    it( 'should put a failure event if the service returns any error and reset the TIMEOUTINFLIGHT to false', () => {
      window.console = {
        error:jest.fn()
      }
      setInFlight( true );
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      expect( getInFlight() ).toBe( false );
      listenerSaga.next();
      expect( window.console.error ).toHaveBeenCalledWith( err );
    } );

  } );


  describe( 'getDeviceID saga', () => {
    const res = {
      body: {
        data:{
          clientId:'75810370b0de2742159a8b5ba234f679415d648a235adc2bb2195a54de823238'
        }
      }
    };
    const listenerSaga = cloneableGenerator( getDeviceID )( deviceID );
    let listenerSagaClone;

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( deviceID, 'loading' )() ) );
    } );

    it( 'should call getUserData to get deviceID ', () => {

      const callDescriptor = listenerSaga.next( ).value;
      listenerSagaClone = listenerSaga.clone( );

      expect( callDescriptor ).toEqual( call( getUserData, 'deviceID' ) );
    } );

    it( 'should put a success event after data is called', () => {
      const deviceId = '75810370b0de2742159a8b5ba234f679415d648a235adc2bb2195a54de823238'
      const putDescriptor = listenerSaga.next( deviceId ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( deviceID, 'success' )( deviceId ) ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method, if deviceID is not present in localstorage', () => {
      const callDescriptor = listenerSagaClone.next( ).value;

      expect( callDescriptor ).toEqual( call( ajax, { type:deviceID, method:'get' } ) );
    } );

    it( 'should call saveUserData to set deviceID', () => {
      const deviceID = '75810370b0de2742159a8b5ba234f679415d648a235adc2bb2195a54de823238'

      const callDescriptor = listenerSagaClone.next( res ).value;

      expect( callDescriptor ).toEqual( call( saveUserData, 'deviceID', deviceID ) );
    } );

    it( 'should put a success event after data is called', () => {
      const deviceId = '75810370b0de2742159a8b5ba234f679415d648a235adc2bb2195a54de823238'
      const putDescriptor = listenerSagaClone.next( deviceId ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( deviceID, 'success' )( deviceId ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( deviceID, 'failure' )( err ) ) );
    } );

  } );

  describe( 'WatchSession Saga', () => {
    const action = {
      data:{
        status: 409
      }
    }
    const watchSessionSaga = watchSession( action );

    it( 'should inform of SessionTimeout', () => {

      process.env.NODE_ENV = 'development';
      window._DEBUG_TIMEOUT = true;
      const putDescriptor = watchSessionSaga.next().value;
      // the NODE_ENV variable needs to be reset to it original value i.e.test or else it will affect other test cases.
      // resetting it before the 'expect' so that the value will be reset even in those case where expect fails
      process.env.NODE_ENV = 'test';
      expect( putDescriptor ).toEqual( put( sessionTimeout() ) );

    } );

    it( 'should remove removePickupSmsInfo before requesting token', () => {

      const putDescriptor = watchSessionSaga.next().value;
      expect( putDescriptor ).toEqual( call( removePickupSmsInfo ) );

    } );

    it( 'should request for Session Token after the removePickupSmsInfo is called', () => {

      const putDescriptor = watchSessionSaga.next().value;
      expect( putDescriptor ).toEqual( put( sessionTokenRequested() ) );

    } );


  } );

  describe( 'WatchSession Saga - action.data.status is TOKEN_MISMATCH', () => {
    const action = {
      data:{
        status: appConstants.RESPONSE_CODE.TOKEN_MISMATCH
      }
    }
    const watchSessionSaga1 = watchSession( action );

    it( 'should inform of SessionTimeout', () => {
      setInFlight( false );
      const putDescriptor = watchSessionSaga1.next().value;
      expect( putDescriptor ).toEqual( put( sessionTimeout() ) );

    } );

    it( 'should remove removePickupSmsInfo before invalidating the token', () => {
      setInFlight( false );
      const putDescriptor = watchSessionSaga1.next().value;
      expect( putDescriptor ).toEqual( call( removePickupSmsInfo ) );

    } );

    it( 'should invoke invalidate service', () => {
      setInFlight( false );

      const putDescriptor = watchSessionSaga1.next().value;
      expect( putDescriptor ).toEqual( call( ajax, { type:'invalidate', method:'post' } ) );

    } );

    it( 'should request for Session Token', () => {

      const putDescriptor = watchSessionSaga1.next().value;
      expect( putDescriptor ).toEqual( put( sessionTokenRequested() ) );

    } );
  } );

  describe( 'WatchSession Saga - action.data.status is 401', () => {
    const action = {
      data:{
        status: 401
      }
    }
    const watchSessionSaga = watchSession( action );

    it( 'should put authorizeLoad with expected data if action.data.status is 401', () => {
      const expectedData = {
        url: global.location.pathname,
        search: global.location.search,
        forceAuthorize: true
      }

      const putDescriptor = watchSessionSaga.next().value;
      expect( putDescriptor ).toEqual( put( authorizeLoad( expectedData ) ) );
      expect( watchSessionSaga.next().done ).toEqual( true );
    } );


    it( 'should not put authorizeLoad if action.data.status is not 401', () => {
      const action = {
        data: {
          status: 400
        }
      }
      const watchSessionSaga = watchSession( action );
      const data = {
        url: global.location.pathname,
        search: global.location.search,
        forceAuthorize: true
      }

      const putDescriptor = watchSessionSaga.next().value;
      expect( putDescriptor ).not.toEqual( put( authorizeLoad( data ) ) );
      expect( watchSessionSaga.next().done ).toEqual( true );
    } );
  } );

} );
