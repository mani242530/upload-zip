/**
 * shippingupdate sagas
 */

import {
  takeEvery, call, put, delay, take, select
} from 'redux-saga/effects';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';


import get from 'lodash/get';
import { getCheckoutPageState } from '../../models/view/checkout_page/checkout_page.model';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import {
  ajax
} from '../../utils/ajax/ajax';
// Individual exports for testing
let isShippingRequested = {
  type: ''
}
export const listener = function*( type, action ){

  try {
    let res;
    if( isShippingRequested.type === '' ){
      isShippingRequested = yield put( getActionDefinition( type, 'loading' )( action.data ) );

      if( action.data.values ){
        res = yield call(
          ajax, {
            type,
            method:'post',
            values:action.data.values
          }
        );
      }
      // isShippingMethodUpdated flag is used to differentiate between the Shipping address and Shipping method update call
      const isShippingMethodUpdated = !!get( action.data, 'values.shipMethodName' );
      yield put( getActionDefinition( type, 'success' )( { response: res.body.data, isShippingMethodUpdated } ) );
      isShippingRequested.type = '';
      let shippingInfo = res.body.data.shippingInfo;
      if( shippingInfo.messages ){
        yield call( handleAnalytics, shippingInfo );
      }

      // if there is selected shipmode, and if the corresponding delivery date is not present,
      // a request needs to be initiated for estimatedDeliveryDate
      const shipMethodInfo = shippingInfo.shipMethodInfo &&
           shippingInfo.shipMethodInfo.items.find( shipMethodInfo => shipMethodInfo.isSelected && !shipMethodInfo.estimatedDelivery )
      if( shipMethodInfo ){
        yield put( getActionDefinition( 'estimatedDeliveryDate', 'requested' )() );
      }

      const checkoutData = yield select( getCheckoutPageState );

      // trigger afterpayToken service call only if result is Success, afterpayEligible and isTokenRequired are true
      // and isProfileCreditCardListView should be true (signed in user ) or paymentType should be afterpay( guest user )
      if( res.body.data.result === 'Success' && res.body.data?.afterpay?.afterpayEligible && res.body.data?.afterpay?.isTokenRequired &&
       ( checkoutData.isProfileCreditCardListView || checkoutData.paymentType === 'afterpay' ) ){
        yield put( getActionDefinition( 'afterpayToken', 'requested' )() );
      }
    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    isShippingRequested.type = '';
    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
}

export const handleAnalytics = function*( shippingInfo ){

  const data = {
    'globalPageData': {
      'messages' : shippingInfo.messages
    }
  }

  const evt = {
    'name' : 'serviceMessagesUpdated'
  }

  yield put( setDataLayer( data, evt ) );

  if( shippingInfo.shippingStatus === 'IncompatibleShipping' ){
    let analyticsEvent =    {
      name: 'trackErrorDisplayed',
      data: {
        'errorType': 'form',
        'errorLabel': 'shipping',
        'errorDescription': shippingInfo.messages.items
      }
    };
    yield put( triggerAnalyticsEvent( analyticsEvent ) );
  }
}


export default function*(){
  let serviceType = 'shippingUpdate';
  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );


}
