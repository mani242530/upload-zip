/**
 * InitCart sagas test
 */

import {
  takeEvery, call, put, take, select
} from 'redux-saga/effects';
import { createMockTask, cloneableGenerator } from 'redux-saga/lib/utils';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import saga, { listener, handleAnalytics } from './shipping_update.controller';
import { getCheckoutPageState } from '../../models/view/checkout_page/checkout_page.model';


const type = 'shippingUpdate';
const sessionID = undefined;
const shipMethodName = 'ups_next_day';
const shipAddrNickName = 'secondaryShippingAddress';
const confirmAddress = true;

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );
  registerServiceName( 'estimatedDeliveryDate' );
  registerServiceName( 'afterpayToken' );

  const shippingUpdateSaga = saga();

  it( 'should listen for the shippingUpdate requested method', () =>{

    const takeEveryDescriptor = shippingUpdateSaga.next().value;

    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );

  } );

  describe( 'listener saga success path', () => {

    const data = {
      sessionID,
      shipMethodName,
      shipAddrNickName,
      confirmAddress
    };
    const listenerSaga = cloneableGenerator( listener )( type, { data:{ values:data } } );
    let listenerSaga1;
    let listenerSaga2;
    let listenerSaga3;
    let listenerSaga4;
    let listenerSaga5;

    it( 'should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      listenerSaga3 = listenerSaga.clone();
      listenerSaga4 = listenerSaga.clone();
      listenerSaga5 = listenerSaga.clone();
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { values: data } ) ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next( { type:'SHIPPINGUPDATE_DATA_LOADING' } ).value;
      let values = data;
      expect( callDescriptor ).toEqual( call( ajax, {
        type,
        method: 'post',
        values
      } ) );

    } );

    let res;
    it( 'should put a success event after data is called', () => {
      res = {
        body:{
          data:{
            title: 'test',
            status: 'ok',
            shippingInfo : {
              shippingStatus:'IncompatibleShipping',
              messages :{
                items :[
                  {
                    key : 'address error',
                    desc : 'error occurred'
                  }
                ]
              },
              shipMethodInfo : {
                items:[
                  {
                    'cost': 'FREE',
                    'displayName': 'Standard Shipping',
                    'shipMethod': 'free_shipping',
                    'isSelected': true,
                    'estimatedDelivery': null
                  }
                ]
              }
            },
            result: 'Success',
            afterpay: {
              afterpayEligible: true,
              isTokenRequired: true
            }
          }
        }
      }
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { response:res.body.data, isShippingMethodUpdated :true } ) ) );

    } );

    it( 'should call handleAnalytics', () => {
      const callDescriptor = listenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( handleAnalytics, res.body.data.shippingInfo ) );

    } );

    it( 'should put a estimatedDeliveryDate sucess', () => {

      const putDescriptor = listenerSaga.next().value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( 'estimatedDeliveryDate', 'requested' )() ) );

    } );

    it( 'should select getCheckoutPageState method', () => {
      const selectDescriptor = listenerSaga.next().value;
      listenerSaga1 = listenerSaga.clone();
      listenerSaga2 = listenerSaga.clone();
      expect( selectDescriptor ).toEqual( select( getCheckoutPageState ) );
    } );

    it( 'should put afterpayToken requested', () => {
      const checkoutData = {
        isProfileCreditCardListView: true,
        paymentType: 'afterpay'
      }
      const putDescriptor = listenerSaga.next( checkoutData ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
    } );

    it( 'should not put afterpayToken requested if isProfileCreditCardListView is false', () => {
      const checkoutData = {
        isProfileCreditCardListView: false
      }
      const putDescriptor = listenerSaga1.next( checkoutData );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should not put afterpayToken requested if paymentType is not afterpay', () => {
      const checkoutData = {
        paymentType: 'creditCard'
      }
      const putDescriptor = listenerSaga2.next( checkoutData );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should not put afterpayToken requested if res.body.data.result is not success', () => {
      res.body.data.result = 'Failure';
      res.body.data.shippingInfo = {};
      const checkoutData = {
        isProfileCreditCardListView: true,
        paymentType: 'afterpay'
      }
      listenerSaga3.next( { type:'SHIPPINGUPDATE_DATA_LOADING' } ); // this is ajax call
      listenerSaga3.next( res ); // this is shipping update success
      listenerSaga3.next(); // this is select getCheckoutPageState method
      const putDescriptor = listenerSaga3.next( checkoutData );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should not put afterpayToken requested if afterpayEligible is false', () => {
      res.body.data.afterpay = {
        afterpayEligible: false,
        isTokenRequired: true
      }
      res.body.data.result = 'Success';
      res.body.data.shippingInfo = {};
      const checkoutData = {
        isProfileCreditCardListView: true,
        paymentType: 'afterpay'
      }
      listenerSaga4.next( { type:'SHIPPINGUPDATE_DATA_LOADING' } ); // this is ajax call
      listenerSaga4.next( res ); // this is shipping update success
      listenerSaga4.next(); // this is select getCheckoutPageState method
      const putDescriptor = listenerSaga4.next( checkoutData );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should not put afterpayToken requested if isTokenRequired is false', () => {
      res.body.data.afterpay = {
        afterpayEligible: true,
        isTokenRequired: false
      }
      res.body.data.result = 'Success';
      res.body.data.shippingInfo = {};
      const checkoutData = {
        isProfileCreditCardListView: true,
        paymentType: 'afterpay'
      }
      listenerSaga5.next( { type:'SHIPPINGUPDATE_DATA_LOADING' } ); // this is ajax call
      listenerSaga5.next( res ); // this is shipping update success
      listenerSaga5.next(); // this is select getCheckoutPageState method
      const putDescriptor = listenerSaga5.next( checkoutData );
      expect( putDescriptor.value ).not.toEqual( put( getActionDefinition( 'afterpayToken', 'requested' )() ) );
      expect( putDescriptor.done ).toBe( true );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      window.TRACK_SAGA_FAILURES = true;
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should throw the error', () => {

      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }

      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );

  } );

  describe( 'handleAnalytics test cases', () => {
    const shippingInfo = {
      messages :{
        items: [
          {
            key : 'address error',
            desc : 'error occurred'
          }
        ]
      },
      shippingStatus:'IncompatibleShipping'
    }
    const analyticListener = handleAnalytics( shippingInfo );
    it( 'should put an event for data layer updates', () => {
      const data = {
        'globalPageData': {
          'messages' : shippingInfo.messages
        }
      }

      const evt = {
        'name' : 'serviceMessagesUpdated'
      }
      expect( analyticListener.next().value ).toEqual( put( setDataLayer( data, evt ) ) );
    } );

    it( 'should put a analyticActions if the shipping status is IncompatibleShipping in the resposne', () => {

      let analyticsEvent =      {
        name: 'trackErrorDisplayed',
        data: {
          'errorType': 'form',
          'errorLabel': 'shipping',
          'errorDescription': [
            {
              key : 'address error',
              desc : 'error occurred'
            }
          ]
        }
      };

      const putDescriptor = analyticListener.next().value;

      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( analyticsEvent ) ) );

    } );

  } );

} );
