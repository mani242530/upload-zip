/**
 * Created by Sreekala on 12/3/18.
 */
import {
  takeEvery,
  call,
  put,
  cancelled,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { ajax } from '../../utils/ajax/ajax';

export const getSkuDynamicData = function* ( type, CONFIG, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    const query = {
      skuId: action.data
    };
    if( process.env.NODE_ENV === 'development' ){
      // query.__onSale = CONFIG.DEBUGGING.PRODUCT.onSale;
    }
    // get global switch data
    const switchData = yield select( makeGetSwitchesData() );
    const res = yield call( ajax,
      {
        type:'skuDynamicData',
        query
      } );
    yield put( getActionDefinition( type, 'success' )( { dynamicData: res.body.data, skuId:action.data, displayGWPEligibleLink: switchData.switches.displayGWPEligibleLink } ) );
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }
  finally {
    if( yield cancelled() ){
      yield put( getActionDefinition( type, 'canceled' )() );
    }
  }
}
export default function( CONFIG ){
  return function*( ){
    const pdpServiceType = 'pdpSkuDynamicData';
    registerServiceName( pdpServiceType );
    yield takeEvery( getServiceType( pdpServiceType, 'requested' ), getSkuDynamicData, pdpServiceType, CONFIG )

    const qsServiceType = 'qsSkuDynamicData';
    registerServiceName( qsServiceType );
    yield takeEvery( getServiceType( qsServiceType, 'requested' ), getSkuDynamicData, qsServiceType, CONFIG )
  }
}
