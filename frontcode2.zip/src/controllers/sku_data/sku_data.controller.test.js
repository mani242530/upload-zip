/**
 * Created by Sreekala on 7/2/18.
 */
import {
  takeEvery,
  call,
  put,
  cancelled,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import { ajax } from '../../utils/ajax/ajax';
import saga, {
  getSkuDynamicData
} from './sku_data.controller';
import CONFIG from '../../modules/pdp/pdp.config';

const type = 'pdpSkuDynamicData';
const serviceType = 'qsSkuDynamicData';

var action = {
  data:123
}
const listenerSaga = getSkuDynamicData( type, CONFIG, action );

describe( 'SkuDynamicData sagas', () => {
  const coreSaga = saga( CONFIG )();
  registerServiceName( type );
  registerServiceName( serviceType );

  it( 'should take every skuDynamicData request from pdp', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), getSkuDynamicData, type, CONFIG ) );
  } );
  it( 'should take every skuDynamicData request from quick shop', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( serviceType, 'requested' ), getSkuDynamicData, serviceType, CONFIG ) );
  } );

  describe( 'SkuDynamicData saga success path', () => {

    const switchData = {
      switches:{
        displayGWPEligibleLink:true
      }
    };

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next( switchData ).value;
      const query = { skuId:123 };
      expect( callDescriptor ).toEqual( call( ajax, { type:'skuDynamicData', query } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            sku:{
              id:'123'
            }
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( { 'dynamicData':res.body.data, skuId:123, displayGWPEligibleLink: switchData.switches.displayGWPEligibleLink } ) ) );
    } );

  } );

  describe( 'PromotionDetails saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
    } );

  } );

  describe( 'PromotionDetails saga finally block', () => {

    it( 'should cancel the event if an error occured in the service', () => {
      const cancelDescriptor = listenerSaga.next().value;
      expect( cancelDescriptor ).toEqual( cancelled() );
    } );

    it( 'should put a cancel action', () => {
      const putDescriptor = listenerSaga.next( true, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'canceled' )() ) );
    } );

  } );

} );
