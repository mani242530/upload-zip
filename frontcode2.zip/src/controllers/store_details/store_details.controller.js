import {
  take,
  takeLatest,
  call,
  put,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import reduxFormActions from 'redux-form/lib/actions';
import { delay } from 'redux-saga';
import { ajax } from '../../utils/ajax/ajax';
import { persistFindInStoreData, retrieveFindInStoreData, removeFindInStoreData } from '../../utils/local_storage/local_storage';
import { getCurrentLocationBlockedState } from '../../models/view/find_in_store/find_in_store.model';

export const storeDetail = function* ( type, action ){
  try {

    let searchValue = action.data.searchValue;
    let useCachedValue = action.data.useCachedValue;
    let skuIds = action.data.skuId;
    let storeServiceData;
    let latitude ;
    let longitude ;
    let isLocationBlocked;
    let cachedSearchData;

    /** *
     * If the user already typed a city/state/zip and searched it will be stored in the localStorage
     * when the useCachedValue is true the value will be retrieved from localStorage and used
     */
    if( useCachedValue ){
      cachedSearchData = retrieveFindInStoreData();
    }
    // set the values from cache
    if( cachedSearchData ){
      searchValue = cachedSearchData.searchValue;
      isLocationBlocked = cachedSearchData.isLocationBlocked;
    }
    else if( !searchValue ){
      yield put( getActionDefinition( 'latLong', 'requested' )( { disableTimeout: false } ) );
      // Resolving co-ordinates
      const locationData = yield take( getServiceType( 'latLong', 'success' ) );

      if( locationData.data ){
        latitude = locationData.data.latitude;
        longitude = locationData.data.longitude;
      }
    }

    if( ( latitude && longitude ) || searchValue ){
      /* Retrieving stores based on co-ordinates from LatLong*/
      yield put( getActionDefinition( type, 'loading' )() );
      const res = yield call(
        ajax, {
          type,
          method:'get',
          query: {
            ...( searchValue && { searchString:searchValue } ),
            ...( !searchValue && { latitude, longitude } ),
            skuIds
          }
        }
      );
      storeServiceData = res.body.data;
    }

    if( useCachedValue && searchValue && storeServiceData ){
      // setting the cached locationBlocked status
      storeServiceData.isLocationBlocked = isLocationBlocked;
      storeServiceData.useCachedValue = useCachedValue;
    }

    // set the search field with either the cachedData or currentLocation usage
    yield put( reduxFormActions.change( 'FindInStore', 'searchField', searchValue || '' ) );
    yield put( getActionDefinition( type, 'success' )( storeServiceData ) );

    if( storeServiceData ){
      if( !useCachedValue && searchValue ){
        let isLocationBlocked = yield select( getCurrentLocationBlockedState );
        let cachedStoreData = {
          searchValue, isLocationBlocked
        };
        // saving the user searched data only when there are results and only if it is not an already cached value
        yield call( persistFindInStoreData, cachedStoreData );
      }
      else if( !searchValue ){ // removing the persisted data if the current location is used
        // remove any already persisted data
        yield call( removeFindInStoreData );
      }

      const evt = {
        'name': 'pdpFindInStore',
        'data': {
          'productSku': action.data.skuId,
          'storeSearchZipCode': searchValue
        }
      };
      yield put( triggerAnalyticsEvent( evt ) );
    }
  }

  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }

};

export const loadMoreResults = function* ( type ){
  yield put( getActionDefinition( type, 'loading' )() );
  yield call( delay, 2000 );
  yield put( getActionDefinition( type, 'success' )( ) );
}
export default function*(){
  const serviceType = 'storeDetail';
  const loadMoreResultsServiceType =  'loadMoreResults';
  registerServiceName( serviceType );
  registerServiceName( loadMoreResultsServiceType );
  yield takeLatest( getServiceType( serviceType, 'requested' ), storeDetail, serviceType )
  yield takeLatest( getServiceType( loadMoreResultsServiceType, 'requested' ), loadMoreResults, loadMoreResultsServiceType )
}


