import {
  takeLatest,
  call,
  put,
  select
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { change } from 'redux-form';
import { delay } from 'redux-saga';
import { ajax } from '../../utils/ajax/ajax';
import saga, {
  storeDetail,
  loadMoreResults
} from './store_details.controller';
import { persistFindInStoreData, removeFindInStoreData } from '../../utils/local_storage/local_storage';
import { getCurrentLocationBlockedState } from '../../models/view/find_in_store/find_in_store.model';

let mockCachedData = {
  isLocationBlocked: false,
  searchValue: 60603
}

jest.mock( '../../utils/local_storage/local_storage', () => {
  return {
    retrieveFindInStoreData:()=> mockCachedData,
    persistFindInStoreData:jest.fn(),
    removeFindInStoreData: jest.fn()
  }
} );


const storeDetailServicetype = 'storeDetail';
const loadMoreResultsServiceType = 'loadMoreResults';
describe( 'storeDetail sagas', () => {
  const coreSaga = saga();
  registerServiceName( storeDetailServicetype );
  registerServiceName( loadMoreResultsServiceType );
  registerServiceName( 'latLong' );

  it( 'should take every storeDetail request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeLatest( getServiceType( storeDetailServicetype, 'requested' ), storeDetail, storeDetailServicetype ) );
  } );
  it( 'should take every loadMoreResults request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeLatest( getServiceType( loadMoreResultsServiceType, 'requested' ), loadMoreResults, loadMoreResultsServiceType ) );
  } );
} );

describe( 'StoreDetail sagas useCachedValue false', () => {

  describe( 'storeProductAvailability saga success path when searchValue is empty ', () => {
    let latLong = {
      data: {
        latitude:  121,
        longitude: 123
      }
    };
    const action = {
      data:{
        skuId:2241934,
        useCachedValue: false
      }
    };
    const listenerSaga = storeDetail( storeDetailServicetype, action );

    it( 'should put a latLong request', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'latLong', 'requested' )( { disableTimeout:false } ) ) );
      listenerSaga.next( ); // take LatLong value
    } );



    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( latLong ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( storeDetailServicetype, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a success method', () => {

      const callDescriptor = listenerSaga.next( latLong ).value;
      expect( callDescriptor ).toEqual( call( ajax, { type:storeDetailServicetype, method:'get', query: { ...latLong.data, skuIds:action.data.skuId } } ) );
    } );

    it( 'should reset FindInStore form\'\s searchField with cached search value', () => {
      let res = {
        body: {
          data:121
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;// form change
      expect( putDescriptor ).toEqual( put( change( 'FindInStore', 'searchField', '' ) ) );
    } );

    it( 'should put a success event after data is called', () => {
      let res = {
        body: {
          data:121
        }
      };
      let storeServiceData = res.body.data;
      const putDescriptor = listenerSaga.next( storeServiceData ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( storeDetailServicetype, 'success' )( res.body.data ) ) );
    } );
    it( 'should call removeFindInStoreData', () => {
      let res = {
        body: {
          data:121
        }
      };
      let storeServiceData = res.body.data;
      const callDescriptor = listenerSaga.next( storeServiceData ).value;
      expect( callDescriptor ).toEqual( call( removeFindInStoreData ) );
    } );
    it( 'should trigger analytics event named pdpFindInStore after success', () => {
      const res = {
        body: {
          data:{}
        }
      };
      const evt = {
        'name': 'pdpFindInStore',
        'data': {
          'productSku': action.data.skuId,
          'storeSearchZipCode': action.data.searchValue
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );
    describe( 'storeDetail saga failure path', () => {

      it( 'should put a failure event if no data is returned from the service', () => {
        window.TRACK_SAGA_FAILURES = true;
        const err = {
          statusText:'some failure message'
        };
        const putDescriptor = listenerSaga.throw( err, window ).value;
        expect( putDescriptor ).toEqual( put( getActionDefinition( storeDetailServicetype, 'failure' )( err ) ) );
        expect( () => {
          listenerSaga.next();
        } ).toThrow();
      } );
    } );

  } );

  describe( 'storeProductAvailability saga success path when searchValue is not empty ', () => {
    let latLong = {
      data: {
        latitude:  121,
        longitude: 123
      }
    };
    const action = {
      data:{
        skuId:2241934,
        useCachedValue: false,
        searchValue:60603
      }
    };
    const listenerSaga = storeDetail( storeDetailServicetype, action );


    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( latLong ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( storeDetailServicetype, 'loading' )() ) );
    } );
    it( 'should call store service with search term ', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( ajax, { type:storeDetailServicetype, method:'get', query: { searchString: action.data.searchValue, skuIds:action.data.skuId } } ) );
    } );

    it( 'should reset FindInStore form\'\s searchField with cached search value', () => {
      let res = {
        body: {
          data:121
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;// form change
      expect( putDescriptor ).toEqual( put( change( 'FindInStore', 'searchField', action.data.searchValue ) ) );
    } );

    it( 'should put a success event after data is called', () => {
      let res = {
        body: {
          data:121
        }
      };
      let storeServiceData = res.body.data;
      const putDescriptor = listenerSaga.next( storeServiceData ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( storeDetailServicetype, 'success' )( res.body.data ) ) );
    } );

    it( 'should select getCurrentLocationBlockedState', () => {
      let res = {
        body: {
          data:121
        }
      };
      const selectDescriptor = listenerSaga.next( res ).value;
      expect( selectDescriptor ).toEqual( select( getCurrentLocationBlockedState ) );
    } );

    it( 'should call persistFindInStoreData', () => {
      let storeData = {
        searchValue: 60603
      }
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( persistFindInStoreData, storeData ) );
    } );
    it( 'should trigger analytics event named pdpFindInStore after success', () => {
      const res = {
        body: {
          data:{}
        }
      };
      const evt = {
        'name': 'pdpFindInStore',
        'data': {
          'productSku': action.data.skuId,
          'storeSearchZipCode': action.data.searchValue
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );
  } );
} );
describe( 'StoreDetail sagas useCachedValue true', () => {
  const cachedAction = {
    data:{
      skuId:2241934,
      useCachedValue: true
    }
  };
  const listenerSaga = storeDetail( storeDetailServicetype, cachedAction );

  let res = {
    body: {
      'data': {
        'stores': {
          'items': [
            {
              'storeTimings': '10:00 am - 9:00 pm',
              'storeDistanceMiles': 4.3,
              'storeId': '269',
              'storeContactInfo': {
                'phoneNumber': '630-783-0018',
                'address': {
                  'country': 'US',
                  'zipCode': '60440-3143',
                  'city': 'Bolingbrook',
                  'address1': '641 East Boughton Road, Suite 100',
                  'latitude': '41.7195855',
                  'state': 'IL',
                  'longitude': '-88.04249949999999'
                },
                'displayName': 'The Promenade at Bolingbrook'
              },
              'nearByStore': false
            }
          ]
        }
      },
      'meta': {
        'lastFetchedTime': '2019-03-15 15:10:51.941-05:00'
      }
    }
  };
  let storeServiceData = res.body.data;

  describe( 'storeProductAvailability saga success path', () => {

    it( 'should wait until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( storeDetailServicetype, 'loading' )() ) );
    } );

    it( 'should call store service with the cached data', () => {
      const callDescriptor = listenerSaga.next( ).value;
      expect( callDescriptor ).toEqual( call( ajax, { type:storeDetailServicetype, method:'get', query: { searchString: mockCachedData.searchValue, skuIds:cachedAction.data.skuId } } ) );
    } );

    it( 'should reset FindInStore form\'\s searchField with cached search value', () => {
      const putDescriptor = listenerSaga.next( res ).value;// form change
      expect( putDescriptor ).toEqual( put( change( 'FindInStore', 'searchField', mockCachedData.searchValue ) ) );
    } );

    it( 'should put a success event after data is called', () => {
      storeServiceData.isLocationBlocked = mockCachedData.isLocationBlocked;
      storeServiceData.useCachedValue = cachedAction.data.useCachedValue;
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( storeDetailServicetype, 'success' )( storeServiceData ) ) );
    } );

    it( 'should trigger analytics event named pdpFindInStore after success', () => {
      const res = {
        body: {
          data:{}
        }
      };
      const evt = {
        'name': 'pdpFindInStore',
        'data': {
          'productSku': cachedAction.data.skuId,
          'storeSearchZipCode': mockCachedData.searchValue
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );

  } );
  describe( 'storeDetail saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      };
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( storeDetailServicetype, 'failure' )( err ) ) );
      expect( () => {
        listenerSaga.next();
      } ).toThrow();
    } );

  } );

} );

describe( 'loadMoreResults sagas', () => {
  const listenerSaga = loadMoreResults( loadMoreResultsServiceType );
  it( 'should wait until the loading event has been put', () => {
    const putDescriptor = listenerSaga.next().value;
    expect( putDescriptor ).toEqual( put( getActionDefinition( loadMoreResultsServiceType, 'loading' )() ) );
  } );
  it( 'should add a delay so that the spinner is visible before displaying more results', () => {
    const callDescriptor = listenerSaga.next( ).value;
    expect( callDescriptor ).toEqual( call( delay, 2000 ) );
  } );
  it( 'should put a success event ', () => {
    const putDescriptor = listenerSaga.next( ).value;
    expect( putDescriptor ).toEqual( put( getActionDefinition( loadMoreResultsServiceType, 'success' )( ) ) );
  } );
} );

describe( 'geo locate path', () => {
  const geoLocation = {
    data:{
      skuId:2241934,
      useCachedValue: false
    }
  };
  const geoLocatePathListenerSaga = storeDetail( storeDetailServicetype, geoLocation );
  let res = {
    body: {
      data:121
    }
  };

  let latLongData = {
    data: {
      latitude:  121,
      longitude: 123
    }
  };

  it( 'should reset FindInStore form\'\s searchField if geo locate is used', () => {

    geoLocatePathListenerSaga.next( ); // lat long requested
    geoLocatePathListenerSaga.next( ); // lat long success
    geoLocatePathListenerSaga.next( latLongData ); // store data loading
    geoLocatePathListenerSaga.next( ); // ajax call for store details
    const putDescriptor = geoLocatePathListenerSaga.next( res ).value;// form change
    expect( putDescriptor ).toEqual( put( change( 'FindInStore', 'searchField', '' ) ) );
  } );

  it( 'should call removeFindInStoreData with empty object', () => {
    let cachedStoreData;
    geoLocatePathListenerSaga.next( res ); // store detail success
    const callDescriptor = geoLocatePathListenerSaga.next().value;
    expect( callDescriptor ).toEqual( call( removeFindInStoreData ) );
  } );

} );