import {
  takeEvery,
  call,
  put
} from 'redux-saga/effects';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { ajax } from '../../utils/ajax/ajax';

export const storeProductAvailability = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const URIParams = {
      storeId: action.data.storeId,
      skuId: action.data.skuId
    };

    const res = yield call(
      ajax, {
        type,
        method:'get',
        URIParams
      }
    );
    // Add store Id with response
    res.body.data.storeId = action.data.storeId;
    // Below logic is for screen reader to read out the status of store product availability  message when ever the user clicks the Check In Store Availability
    if( res.body.data.inventoryStatus !== 'NO DATA' ){
      yield put( setBroadcastMessage( res.body.data.inventoryStatus ) );
    }
    yield put( getActionDefinition( type, 'success' )( res.body.data ) );


    if( res.body.data ){
      const evt = {
        'name': 'pdpFindInStoreAvailabilityCheck',
        'data': {
          'productSku': action.data.skuId,
          'storeSearchZipCode': action.data.searchValue,
          'storeId': action.data.storeId,
          'storeAvailabilityResponse': res.body.data.inventoryStatus
        }
      }
      yield put( triggerAnalyticsEvent( evt ) );
    }

  }

  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    if( window.TRACK_SAGA_FAILURES ){
      throw err;
    }
  }

}


export default function*(){
  const serviceType = 'storeProductAvailability';
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), storeProductAvailability, serviceType )
}
