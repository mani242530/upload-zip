import {
  takeEvery,
  call,
  put,
  cancelled
} from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/utils';
import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import {
  setBroadcastMessage
} from 'ulta-fed-core/dist/js/events/global/global.events';
import { ajax } from '../../utils/ajax/ajax';
import saga, {
  storeProductAvailability
} from './store_product_availability.controller';
import CONFIG from '../../modules/pdp/pdp.config';


const type = 'storeProductAvailability';
var action = {
  data: {
    skuId: 1234,
    storeId: 123,
    searchValue:60603

  }
}
const listenerSaga = cloneableGenerator( storeProductAvailability )( type, action );
let listenerSagaClone;

describe( 'storeProductAvailability sagas', () => {
  const coreSaga = saga();
  registerServiceName( type );

  it( 'should take every storeProductAvailability request', () => {
    const takeEveryDescriptor = coreSaga.next().value;
    expect( takeEveryDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), storeProductAvailability, type ) );
  } );


  describe( 'storeProductAvailability saga success path', () => {

    it( 'should should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      const callDescriptor = listenerSaga.next().value;
      listenerSagaClone = listenerSaga.clone();
      const URIParams = {
        storeId: action.data.storeId,
        skuId: action.data.skuId
      };

      expect( callDescriptor ).toEqual( call( ajax, { type:'storeProductAvailability', method:'get', URIParams } ) );
    } );
    it( 'should put setBroadcastMessage action with inventoryStatus message', () => {
      const res = {
        body: {
          data:{
            inventoryStatus:'IN STOCK'
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( setBroadcastMessage( res.body.data.inventoryStatus ) ) );
    } );
    it( 'shouldn\'t put setBroadcastMessage action when inventoryStatus NO DATA', () => {
      const res = {
        body: {
          data:{
            inventoryStatus:'NO DATA'
          }
        }
      };
      const putDescriptor = listenerSagaClone.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should put a success event after data is called', () => {
      const res = {
        body: {
          data:{
            inventoryStatus:'IN STOCK',
            storeId: 123
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should trigger analytics event named pdpFindInStoreAvailabilityCheck after success', () => {
      const res = {
        body: {
          data:{
            inventoryStatus:'IN STOCK'
          }
        }
      };
      const evt = {
        'name': 'pdpFindInStoreAvailabilityCheck',
        'data': {
          'productSku': action.data.skuId,
          'storeSearchZipCode': action.data.searchValue,
          'storeId': action.data.storeId,
          'storeAvailabilityResponse': res.body.data.inventoryStatus
        }
      }
      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( triggerAnalyticsEvent( evt ) ) );
    } );

  } );

  describe( 'storeProductAvailability saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      expect( () => {
        listenerSaga.next();
      } ).toThrow();
    } );

  } );

} );
