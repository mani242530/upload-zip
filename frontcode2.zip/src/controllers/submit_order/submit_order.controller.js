import {
  takeEvery, takeLatest, call, put, take, select
} from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';
import { delay } from 'redux-saga';
import has from 'lodash/has';
import isEmpty from 'lodash/isEmpty';
import find from 'lodash/find';
import isUndefined from 'lodash/isUndefined';
import get from 'lodash/get';

import VMasker from 'vanilla-masker';
import { getUserState } from '../../models/view/user/user.model';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';
import {
  ajax
} from '../../utils/ajax/ajax';
import {
  setTempPaymentCCVNumber
} from '../../events/checkout_page/checkout_page.events';
import { removePickupSmsInfo } from '../../utils/local_storage/local_storage';

// this method will check if the address form is dirty
export const isAddressFormDirty = ( shippingAddress, formValues ) => {
  let phNumber =  !isUndefined( formValues.phoneNumbershippingAddressForm ) ? VMasker.toPattern( formValues.phoneNumbershippingAddressForm, '999-999-9999' ) : '';
  let postalCode = shippingAddress && shippingAddress.postalCode.value.split( '-' )
  if( ( formValues.firstNameshippingAddressForm && formValues.firstNameshippingAddressForm !== shippingAddress.firstName.value ) ||
      ( formValues.lastNameshippingAddressForm && formValues.lastNameshippingAddressForm !== shippingAddress.lastName.value ) ||
      ( formValues.address1shippingAddressForm && formValues.address1shippingAddressForm !== shippingAddress.address1.value ) ||
      ( formValues.address2shippingAddressForm && formValues.address2shippingAddressForm !== shippingAddress.address2.value ) ||
      ( formValues.cityshippingAddressForm && formValues.cityshippingAddressForm !== shippingAddress.city.value ) ||
      ( formValues.stateshippingAddressForm && formValues.stateshippingAddressForm !== shippingAddress.state.value ) ||
      ( formValues.countryshippingAddressForm && formValues.countryshippingAddressForm !== shippingAddress.country.value ) ||
      ( formValues.emailaddressshippingAddressForm && formValues.emailaddressshippingAddressForm !== shippingAddress.email.value ) ||
      ( formValues.phoneNumbershippingAddressForm && phNumber !== shippingAddress.phoneNumber.value ) ||
      ( formValues.postalCodeshippingAddressForm && formValues.postalCodeshippingAddressForm !== postalCode[0] ) ){
    return true;
  }
  else {
    return false;
  }
}

export const isPickupContactInfoFormDirty = ( primaryContactInfo, formValues )=>{
  let phNumber =  !isUndefined( formValues.phoneNumber ) ? VMasker.toPattern( formValues.phoneNumber, '999-999-9999' ) : '';
  if( ( formValues.firstName && formValues.firstName !== primaryContactInfo.firstName.value ) ||
    ( formValues.lastName && formValues.lastName !== primaryContactInfo.lastName.value ) ||
    ( formValues.emailaddress && formValues.emailaddress !== primaryContactInfo.emailAddress.value ) ||
    ( formValues.phoneNumber && phNumber !== primaryContactInfo.phoneNumber.value ) ){
    return true
  }
  return false
}

export const isAlternateContactInfoFormDirty = ( alternateConatctInfo, formValues )=>{

  if( ( formValues.alternateFirstName && formValues.alternateFirstName !== alternateConatctInfo.firstName.value ) ||
    ( formValues.alternateLastName && formValues.alternateLastName !== alternateConatctInfo.lastName.value ) ||
    ( formValues.alternateEmailaddress && formValues.alternateEmailaddress !== alternateConatctInfo.emailAddress.value ) ){
    return true
  }
  return false
}

export const updateShippingFormValues = ( data )=>{

  let shippingFormValues = {};
  const {
    isDeliveryOptionPickup,
    checkoutServicesData,
    incompatibleShippingMessges,
    shippingErrorMessages,
    addEditShippingForm,
    shippingForm
  } = data.data;
  // setting shippingSuccess to true because shipping details need not be considered if delivery option is pickUp
  let shippingSuccess = isDeliveryOptionPickup || ( ( has( checkoutServicesData, 'shippingInfo.shippingAddress' ) ) &&
                              checkoutServicesData.shippingInfo.shippingStatus === 'Complete' &&
                              !incompatibleShippingMessges && !shippingErrorMessages &&
                              !( has( addEditShippingForm, 'values' ) ) );
  if( !isDeliveryOptionPickup && has( shippingForm, 'values' ) || ( has( addEditShippingForm, 'values' ) ) ){
    let formValues = has( addEditShippingForm, 'values' ) ? addEditShippingForm.values : shippingForm.values;

    if( !shippingSuccess || isAddressFormDirty( checkoutServicesData.shippingInfo.shippingAddress, formValues ) ){
      let phNumber =  VMasker.toPattern( formValues.phoneNumbershippingAddressForm, '999-999-9999' );
      shippingFormValues = {
        firstName: formValues.firstNameshippingAddressForm,
        lastName: formValues.lastNameshippingAddressForm,
        address1:  formValues.address1shippingAddressForm,
        city: formValues.cityshippingAddressForm,
        phoneNumber: phNumber,
        email:formValues.emailaddressshippingAddressForm,
        postalCode : formValues.postalCodeshippingAddressForm,
        state: formValues.state,
        primary:!!formValues.isPrimary,
        ...( formValues.address2shippingAddressForm && { address2: formValues.address2shippingAddressForm } )
      }
      // if adddress is edited then shippingSuccess will be set to false
      shippingSuccess = false;
    }
  }

  return {
    shippingFormValues,
    shippingSuccess
  }

}

export const updatePickupContactFormValues = ( data )=> {

  const {
    isDeliveryOptionPickup,
    checkoutServicesData,
    pickupContactInfoForm
  } = data.data;

  let pickupContactFormValues = {};
  let contactInfoSuccess = !isDeliveryOptionPickup || !!get( checkoutServicesData, 'pickupInfo.primaryContactInfo' );

  if( has( pickupContactInfoForm, 'values' ) ){

    let formValues = pickupContactInfoForm.values;

    if( !contactInfoSuccess || isPickupContactInfoFormDirty( checkoutServicesData.pickupInfo.primaryContactInfo, formValues ) ){
      let phNumber =  VMasker.toPattern( formValues.phoneNumber, '999-999-9999' );
      pickupContactFormValues = {
        data:{
          primaryContactInfo: {
            firstName: formValues.firstName,
            lastName: formValues.lastName,
            email:formValues.emailaddress,
            phoneNumber: phNumber
          }
        }
      }
      contactInfoSuccess = false;
    }
  }

  return {
    pickupContactFormValues,
    contactInfoSuccess
  }

}

export const updateAlternateContactFormValues = ( pickupContactForm, data )=> {

  const {
    isDeliveryOptionPickup,
    checkoutServicesData,
    alternatePickupPersonForm
  } = data.data;

  let pickupContactFormValues = pickupContactForm;
  let contactInfoSuccess = !isDeliveryOptionPickup || !!get( checkoutServicesData, 'pickupInfo.primaryContactInfo' );
  let alternateContactInfoSuccess  = !isDeliveryOptionPickup || !!get( checkoutServicesData, 'pickupInfo.alternateContactInfo' );

  if( get( alternatePickupPersonForm, 'values.isAlternatePickupPersonEnable' ) ){

    let formValues = alternatePickupPersonForm.values;
    if( !alternateContactInfoSuccess || isAlternateContactInfoFormDirty( checkoutServicesData.pickupInfo.alternateContactInfo, formValues ) ){
      pickupContactFormValues = {
        data:{
          ...pickupContactFormValues.data,
          alternateContactInfo:{
            firstName: formValues.alternateFirstName,
            lastName: formValues.alternateLastName,
            email:formValues.alternateEmailaddress
          }
        }
      }
      contactInfoSuccess = false;
    }
  }

  return {
    pickupContactFormValues,
    contactInfoSuccess
  }

}

export const validatePaymentForm = ( paymentSuccess, data )=>{

  const {
    isDeliveryOptionPickup,
    paymentType,
    paymentForm,
    isBillingAddressSameAsShipping,
    creditCardType,
    editCreditCardData,
    pickupContactInfoForm,
    creditCardDetails,
    PaymentCCSecurityCode,
    tempPaymentCCVNumber
  } = data.data;

  let paymentFormValues = {};
  if( !paymentSuccess && paymentType === 'creditCard' ){
    if( has( paymentForm, 'values' ) ){
      let formValues = paymentForm.values;
      if( isBillingAddressSameAsShipping ){
        paymentFormValues = {
          creditCardNumber: ( formValues.creditCardNumber ) ? formValues.creditCardNumber.replace( / /g, '' ).replace( /\*/g, '' ).trim() : formValues.creditCardNumber,
          creditCardType: creditCardType,
          nickName:  editCreditCardData.nickName || '',
          sameAsShipping: true,
          paymentType: 'creditCard'
        };
      }
      else {
        let phNumber =  VMasker.toPattern( formValues.phoneNumberpaymentAddressForm, '999-999-9999' );
        const isBillingAddressSameAsContactInfo = data.data.isBillingAddressSameAsContactInfo && isDeliveryOptionPickup;
        paymentFormValues = {
          // if the BillingAddressSameAsContactInfo populate firstname lastname and phone number from pickupContactInfoForm
          firstName: isBillingAddressSameAsContactInfo ? pickupContactInfoForm.values.firstName : formValues.firstNamepaymentAddressForm.trim(),
          lastName: isBillingAddressSameAsContactInfo ? pickupContactInfoForm.values.lastName : formValues.lastNamepaymentAddressForm.trim(),
          address2: ( formValues.address2paymentAddressForm ) ? formValues.address2paymentAddressForm.trim() : '',
          address1: formValues.address1paymentAddressForm.trim(),
          postalCode: formValues.postalCodepaymentAddressForm.trim(),
          city: formValues.citypaymentAddressForm.trim(),
          state: formValues.state,
          phoneNumber: isBillingAddressSameAsContactInfo ? pickupContactInfoForm.values.phoneNumber : phNumber.trim(),
          creditCardNumber: ( formValues.creditCardNumber ) ? formValues.creditCardNumber.replace( / /g, '' ).replace( /\*/g, '' ).trim() : formValues.creditCardNumber,
          creditCardType,
          nickName: editCreditCardData.nickName || '',
          sameAsShipping: false,
          paymentType: 'creditCard'
        };
      }
      if( creditCardType !== 'Ultamate Rewards Credit Card' ){
        paymentFormValues.expirationMonth = ( formValues.expirationDate ) ? formValues.expirationDate.substring( 0, 2 ).trim() : formValues.expirationDate;
        paymentFormValues.expirationYear = ( formValues.expirationDate ) ? formValues.expirationDate.substring( 3, 7 ).trim() : formValues.expirationDate;
        paymentFormValues.cardVerificationNumber = ( formValues.securityCode ) ? formValues.securityCode.trim() : formValues.securityCode;
      }
    }
    else if( has( creditCardDetails, 'paymentDetails' ) && creditCardDetails.paymentType === 'creditCard' ){
      paymentFormValues = {
        paymentType:creditCardDetails.paymentType,
        creditCardType:creditCardDetails.paymentDetails.creditCardType.value,
        creditCardNumber:creditCardDetails.paymentDetails.creditCardNumber.value,
        expirationMonth:creditCardDetails.paymentDetails.expirationMonth.value,
        expirationYear:creditCardDetails.paymentDetails.expirationYear.value,
        nickName:creditCardDetails.nickName,
        firstName:creditCardDetails.contactInfo.firstName.value,
        lastName:creditCardDetails.contactInfo.lastName.value,
        phoneNumber:creditCardDetails.contactInfo.phoneNumber.value,
        address1:creditCardDetails.contactInfo.address1.value,
        address2:creditCardDetails.contactInfo.address2.value ? creditCardDetails.contactInfo.address2.value : '',
        city:creditCardDetails.contactInfo.city.value,
        state:creditCardDetails.contactInfo.state.value,
        postalCode:creditCardDetails.contactInfo.postalCode.value,
        country:creditCardDetails.contactInfo.country.value

      }
      if( creditCardDetails.paymentDetails.creditCardType !== 'Ultamate Rewards Credit Card' ){
        paymentFormValues.cardVerificationNumber = has( PaymentCCSecurityCode, 'values' ) ? PaymentCCSecurityCode.values.ccSecurityCode : tempPaymentCCVNumber
      }
    }
  }

  return paymentFormValues;

}


export const submitForms = ( data ) => {

  let paymentSuccess = false;

  let paymentFormValues = {};
  let updateShippingForm = {};
  let shippingResponse = {};
  let paymentResponse = {};
  let updatePickupContactForm = {};

  const {
    paymentType,
    creditCardDetails,
    paymentForm,
    payPalDetails,
    checkoutServicesData,
    newsLetterSignupFormValues,
    afterpayDetails
  } = data.data;

  if( paymentType === 'creditCard' && has( creditCardDetails, 'paymentDetails' ) ){
    paymentSuccess = data.data.paymentSuccess && creditCardDetails.paymentDetails && !creditCardDetails.messages && !has( paymentForm, 'values' );
    paymentResponse = creditCardDetails;
  }
  else if( paymentType === 'paypal' && payPalDetails ){
    paymentSuccess = data.data.paymentSuccess && !payPalDetails.messages;
    paymentResponse = payPalDetails;
  }
  else if( paymentType === 'afterpay' && afterpayDetails ){
    paymentSuccess = !afterpayDetails.messages;
    paymentResponse = afterpayDetails;
  }

  if( has( checkoutServicesData, 'shippingInfo.shippingAddress' ) ){
    shippingResponse = checkoutServicesData.shippingInfo;
  }

  // if the delivery option is ship, and if there is a shippin form open on the page,
  // the form details are compared with the saved details, to determing if a shipping update call needs to be made
  updateShippingForm = updateShippingFormValues( data );

  // Populate pickupContactFormValues to trigger pickupContactInfoUpdate service call if
  // pickupContactInfoUpdate service call have not triggered yet or
  // if pickupContactInfoForm values have been modified after last update.
  updatePickupContactForm = updatePickupContactFormValues( data )

  // Populate alternateContactFormValues to trigger pickupContactInfoUpdate service call if
  // alternateContactFormValues service call have not triggered yet or
  // if alternateContactFormValues values have been modified after last update.
  updatePickupContactForm = updateAlternateContactFormValues( updatePickupContactForm.pickupContactFormValues, data );

  paymentFormValues = validatePaymentForm( paymentSuccess, data );

  return {
    shippingData: updateShippingForm.shippingFormValues,
    paymentData: paymentFormValues,
    pickupContactInfoData: updatePickupContactForm.pickupContactFormValues,
    contactInfoSuccess: updatePickupContactForm.contactInfoSuccess,
    paymentSuccess: paymentSuccess,
    amountDue: checkoutServicesData.cartSummary.estimatedTotal,
    shippingSuccess: updateShippingForm.shippingSuccess,
    shippingResponse: shippingResponse,
    paymentResponse: paymentResponse,
    guestUserEmailOptIn:newsLetterSignupFormValues && newsLetterSignupFormValues.newsLetter

  };

}

export const listener = function* ( type, data ){

  try {
    yield put( getActionDefinition( type, 'loading' )( { paymentType: data?.data?.paymentType } ) ); // passing the paymenttype to set it in afterpay modal to set updateAfterpayWidget and errorMessege if submitOrderService is failed.

    let submitFormValues = submitForms( data );

    let estimatedTotal = submitFormValues.amountDue; // this is the value from checkoutServicesData.cartSummary.estimatedTotal
    let shippingSuccess = submitFormValues.shippingSuccess;
    let paymentSuccess = submitFormValues.paymentSuccess;
    let contactInfoSuccess = submitFormValues.contactInfoSuccess;

    if( !paymentSuccess ){
      yield put( setTempPaymentCCVNumber( submitFormValues.paymentData.cardVerificationNumber ) );
    }

    // if shipping is already not succes by the time submit order is invoked, the shipping service call
    // will be invoked from here
    if( !shippingSuccess ){

      yield put( getActionDefinition( 'shippingUpdate', 'requested' )( { values: submitFormValues.shippingData } ) );
      let response = yield take( getServiceType( 'shippingUpdate', 'success' ) );
      let shippingResponse = response.data.response.shippingInfo;


      let shippingErrorMessage =  shippingResponse.shippingAddress.messages && find( shippingResponse.shippingAddress.messages.items, { 'type': 'Error' } );
      if( shippingErrorMessage || ( shippingResponse.shippingStatus !== 'Complete' && shippingResponse.shippingStatus !== 'CorrectedAddress' ) ){
        yield put( getActionDefinition( type, 'failure' )( { setFocusTo: 'shipping' } ) );
      }
      // if there is a message ( not necessarily error ) for shipmethodinfo, we need to block submit order
      else if( ( shippingResponse.shipMethodInfo && shippingResponse.shipMethodInfo.messages ) || shippingResponse.shippingStatus === 'CorrectedAddress' ){
        yield put( getActionDefinition( type, 'failure' )( { displayCheckoutLevelErrorMessage:'false' } ) );
      }
      else {
        shippingSuccess = true;

        // if there is change in estimated total when shipping call is made,
        // payment service will be forced
        if( estimatedTotal !== response.data.response.cartSummary.estimatedTotal ){
          estimatedTotal = response.data.response.cartSummary.estimatedTotal;
          paymentSuccess = false;
        }
      }
    }
    // if pickup contactInfo is not updated the pickupContactInfoUpdate service call will be invoked from here
    if( !contactInfoSuccess ){
      yield put( getActionDefinition( 'pickupContactInfoUpdate', 'requested' )( { contactInfo:submitFormValues.pickupContactInfoData } ) );
      let response = yield take( getServiceType( 'pickupContactInfoUpdate', 'success' ) );
      contactInfoSuccess = true;
    }
    // if shipping is success, and if payment is not success and estimatedTotal > 0, payment service call
    // will be invoked from here
    if( shippingSuccess && estimatedTotal > 0 && !paymentSuccess ){

      yield put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: submitFormValues.paymentData } ) );
      let paymentResponse =  yield take( getServiceType( 'paymentServiceResponse', 'success' ) );
      let crediCardObject;
      let payPalObject;
      // we are checking if there is any error from cybersource before we check errors from creditcard and paypal from payment Service response
      if( !has( paymentResponse.data, 'istokenizationFailure' ) ){
        crediCardObject = find( paymentResponse.data.result.paymentDetails, ['paymentInfo.paymentType', 'creditCard'] );
        payPalObject = find( paymentResponse.data.result.paymentDetails, ['paymentInfo.paymentType', 'paypal'] );
      }
      // checking if there is any error from cybersource, so that we will make the submit order saga to put failure response.
      if( ( has( crediCardObject, 'messages' ) && !isEmpty( crediCardObject.messages ) ) ||
        ( ( has( payPalObject, 'messages' ) && !isEmpty( payPalObject.messages ) ) ) || has( paymentResponse.data, 'istokenizationFailure' ) ){
        yield put( getActionDefinition( type, 'failure' )( { setFocusTo: 'payment', displayCheckoutLevelErrorMessage:'false' } ) );
      }
      else {
        paymentSuccess = true;
      }
    }

    // place order will be invoked if shipping is success
    let placeOrder = contactInfoSuccess && shippingSuccess && ( estimatedTotal <= 0 || ( estimatedTotal > 0 && paymentSuccess ) );

    if( placeOrder ){

      const UserData = yield select( getUserState );

      const {
        isSignedIn
      } = UserData;

      let values = !isSignedIn ? { guestUserEmailOptIn: submitFormValues.guestUserEmailOptIn } : {};
      const switchData  = yield select( makeGetSwitchesData() );
      if( data.data.isDeliveryOptionPickup && switchData.switches.enablePickupText ){
        values.smsCommunicationInfo = {
          transactionalContactInfo: {
            optInStatus: data.data.pickupSmsOptInStatus,
            phoneNumber: VMasker.toPattern( data.data.pickupMobileNumber, '999-999-9999' )
          }
        }
      }
      const res = yield call( ajax,
        {
          type,
          method: 'post',
          values
        } );

      yield put( getActionDefinition( type, 'success' )( res.body.data ) );

      if( res.body.data.success ){
        removePickupSmsInfo();
      }

      // update the JSON data layer for analtyics purposes.
      yield call( updateDataLayer, res );


    }
  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
    console.log( err ); // eslint-disable-line

  }
}

// for analtyics tracking we must pass all messages (info/error)
// then let them know there are messages.
export const updateDataLayer = function* ( res ){
  if( !res.body.data.success ){
    let messages = {
      items:[]
    };
    if( has( res.body.data, 'paymentInfo.messages.items' ) ){
      messages.items.push( ...res.body.data.paymentInfo.messages.items );
    }
    if( has( res.body.data, 'shippingInfo.messages.items' ) ){
      messages.items.push( ...res.body.data.shippingInfo.messages.items );
    }
    if( has( res.body.data, 'cartItems.messages.items' ) ){
      messages.items.push( ...res.body.data.cartItems.messages.items )
    }
    if( res.body.data.messages ){
      messages.items.push( ...res.body.data.messages.items );
    }
    // analtyics tracking code
    const data = {
      'globalPageData': {
        'messages': messages
      }
    };
    const evt = {
      'name': 'serviceMessagesUpdated'
    };

    yield put( setDataLayer( data, evt ) );

  }


}

export default function* (){
  let serviceType = 'submitOrderService';

  // register events for the request
  registerServiceName( serviceType );
  yield takeEvery( getServiceType( serviceType, 'requested' ), listener, serviceType );
}
