import {
  takeEvery, take, call, put, select
} from 'redux-saga/effects';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import VMasker from 'vanilla-masker';
import { cloneableGenerator } from 'redux-saga/lib/utils';

import {
  ajax
} from '../../utils/ajax/ajax';
const type  = 'submitOrderService';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import saga, {
  listener,
  updateDataLayer,
  submitForms,
  isAddressFormDirty,
  isPickupContactInfoFormDirty,
  isAlternateContactInfoFormDirty,
  updateShippingFormValues,
  updatePickupContactFormValues,
  updateAlternateContactFormValues,
  validatePaymentForm
} from './submit_order.controller';
import {
  setTempPaymentCCVNumber
} from '../../events/checkout_page/checkout_page.events';
import { removePickupSmsInfo } from '../../utils/local_storage/local_storage';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
jest.mock( '../../utils/local_storage/local_storage', () => {
  return {
    removePickupSmsInfo:jest.fn()
  }
} );

describe( 'submitOrderService Saga', () => {
  registerServiceName( type );

  const submitOrdersaga = saga();

  it( 'should listen for the navigation request method', () => {

    const takeEveryDescriptor = submitOrdersaga.next().value;
    expect( takeEveryDescriptor ).toEqual(
      takeEvery( getServiceType( type, 'requested' ), listener, type )
    );
  } );

  describe( 'check shipping and billing object success', () => {

    const data = {
      data:{
        shippingAddressList:{
          shippingAddress: {
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '1000 Remington Boulevard',
            address2: 'Suite # 120',
            city: 'Bolingbrook',
            state: 'IL',
            postalCode:{ value: '60564' },
            phoneNumber: '510-213-8347'
          }
        },
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              firstName: 'Jane',
              lastName: 'Doe',
              address1: '1000 Remington Boulevard',
              address2: 'Suite # 120',
              city: 'Bolingbrook',
              state: 'IL',
              postalCode:{ value: '60564' },
              phoneNumber: '(510)-213-8347'
            },
            shippingStatus: 'Complete'
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: true,
        paymentType: 'creditCard',
        isDeliveryOptionPickup: false,
        creditCardDetails: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {},
          messages: null
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        shippingForm:{
          firstNameshippingAddressForm: 'Jane',
          lastNameshippingAddressForm: 'Doe',
          address1shippingAddressForm: '1000 Remington Boulevard',
          address2shippingAddressForm: 'Ste 200',
          cityshippingAddressForm: 'Bolingbrook',
          stateshippingAddressForm: 'IL',
          countryshippingAddressForm:'Chicago',
          emailaddressshippingAddressForm: 'test@test.com',
          phoneNumbershippingAddressForm: '510-213-8347',
          postalCodeshippingAddressForm: '60564'
        },
        pickupSmsOptInStatus : true,
        pickupMobileNumber : '(999) 999-9999'
      }
    };
    const dataForPickupOrder = {
      data:{
        checkoutServicesData:{
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: true,
        paymentType: 'creditCard',
        isDeliveryOptionPickup: true,
        creditCardDetails: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {},
          messages: null
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        pickupSmsOptInStatus : true,
        pickupMobileNumber : '(999) 999-9999'
      }
    };

    const values = { guestUserEmailOptIn: true };
    const listenerSaga = listener( type, data );
    const listenerSagaForPickup = listener( type, dataForPickupOrder );
    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { paymentType: 'creditCard' } ) ) );

    } );

    it( 'should yield on requesting data and return that data with a success method', () => {
      let values = {
        guestUserEmailOptIn: false
      }
      let UserData = listenerSaga.next().value;
      UserData = {
        isSignedIn: false
      }
      const switchData = {
        switches:{
          enablePickupText: true
        }
      }
      listenerSaga.next( switchData ).value; // selecting switchdata

      let callDescriptor = listenerSaga.next( { select } ).value;
      const method = 'post';
      expect( callDescriptor ).toEqual( call( ajax, { type, method, values } ) );

    } );

    const res = {
      body:{
        data: {
          success: true,
          status: 'ok'
        }
      }
    }
    let listenerSagaClone;

    it( 'should put a success event after data is called', () => {
      const listenerSaga = cloneableGenerator( listener )( type, data );
      let callDescriptor = listenerSaga.next().value;
      let UserData = listenerSaga.next().value;
      UserData = {
        isSignedIn: false
      }
      const switchData = {
        switches:{
          enablePickupText: true
        }
      }
      listenerSaga.next( switchData ).value; // selecting switchdata
      let putDescriptor = listenerSaga.next( { select } ).value;
      listenerSagaClone = listenerSaga.clone();
      putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body.data ) ) );
    } );

    it( 'should not trigger removePickupSmsInfo method and call updateDataLayer method if res.body.data.success is false', () => {
      const res = {
        body:{
          data: {
            success: false,
            status: 'ok'
          }
        }
      }
      listenerSagaClone.next( res ); // this is submitOrderService success event
      const callDescriptor = listenerSagaClone.next().value;

      expect( removePickupSmsInfo ).not.toBeCalled( );
      expect( callDescriptor ).toEqual( call( updateDataLayer, res ) );
      expect( listenerSagaClone.next().done ).toBe( true );
    } );

    it( 'should trigger removePickupSmsInfo method and call updateDataLayer method if res.body.data.success is true', () => {
      const putDescriptor = listenerSaga.next( res ).value;
      const callDescriptor = listenerSaga.next().value;

      expect( removePickupSmsInfo ).toBeCalled( );
      expect( callDescriptor ).toEqual( call( updateDataLayer, res ) );
    } );
  } );

  describe( 'updateDataLayer for analytics test', () => {
    const res = {
      body:{
        data: {
          'success': false,
          'shippingInfo': null,
          'paymentInfo': {
            'messages': {
              'items': [{
                'type': 'error',
                'message': 'Please enter a valid Security Code.'
              }]
            }
          },
          'cartItems': {
            'messages': {
              'items': [{
                'type': 'error',
                'message': 'SKU 12345 is Out of Stock'
              }]
            }
          },
          'messages': {
            'items': [{
              'type': 'error',
              'message': 'Error commitiing error'
            }]
          }
        }
      }
    }
    const dataLayerRes = {
      'messages': {
        'items':[
          {
            'type': 'error',
            'message': 'Please enter a valid Security Code.'
          },
          {
            'type': 'error',
            'message': 'SKU 12345 is Out of Stock'
          },
          {
            'type': 'error',
            'message': 'Error commitiing error'
          }
        ]
      }
    }

    const dataLayer = updateDataLayer( res );

    const putDescriptor = dataLayer.next( { body: dataLayerRes } ).value;

    const data = {
      'globalPageData': {
        'messages': dataLayerRes.messages
      }
    };

    const evt = {
      'name': 'serviceMessagesUpdated'
    };

    expect( putDescriptor ).toEqual( put( setDataLayer( data, evt ) ) );


  } );

  describe( 'check shiping and billing object failure', () => {

    const data = {
      data: {
        paymentType: 'creditCard',
        paymentForm: { },
        paymentSuccess: true,
        paymentResponse: { },
        shippingSuccess: true,
        shippingResponse: {
          'messages': [
            {
              'messageKey': 'INFO_SHIPPING_CORRECTED_ADDRESS',
              'messageType': 'Info',
              'messageRef': 'shippingAddress',
              'messageDesc': 'USPS recommends the following address to ensure your package is delivered without issues.'
            }
          ],
          'shippingStatus': 'Complete'
        }
      }
    }

    const values = { guestUserEmailOptIn: true };

    const listenerSaga = listener( type, data );

    it( 'should wait until the loading event has been put', () =>{

      const putDescriptor  = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { paymentType: 'creditCard' } ) ) );

    } );

    it( 'should put a failure event if wrong data is returned from the service', () => {

      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );
  describe( 'check failure due to shippingMethod Info message', () => {
    registerServiceName( 'shippingUpdate' );
    const data = {
      data:{
        shippingAddressList:{
          shippingAddress: {
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '1000 Remington Boulevard',
            address2: 'Suite # 120',
            city: 'Bolingbrook',
            state: 'IL',
            postalCode:{ value: '60564' },
            phoneNumber: '510-213-8347'
          }
        },
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              firstName: 'Jane',
              lastName: 'Doe',
              address1: '1000 Remington Boulevard',
              address2: 'Suite # 120',
              city: 'Bolingbrook',
              state: 'IL',
              postalCode:{ value: '60564' },
              phoneNumber: '(510)-213-8347'
            }
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: true,
        paymentType: 'creditCard',
        isDeliveryOptionPickup: false,
        creditCardDetails: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {},
          messages: null
        },
        addEditShippingForm:{
          values: {
            firstNameshippingAddressForm:'test address',
            lastNameshippingAddressForm:'test address',
            address1shippingAddressForm:'test address',
            cityshippingAddressForm:'test address',
            emailaddressshippingAddressForm:'test address',
            postalCodeshippingAddressForm:'test address',
            phoneNumbershippingAddressForm: '510-213-8347'
          }
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        }
      }
    };

    const shippingResponse = {
      data:{
        response:{
          shippingInfo:  {
            shippingStatus: 'Complete',
            shippingAddress: {
              lastName: 'last',
              country: 'US',
              address2: null,
              city: 'APO',
              address1: 'PSC3 box 7263',
              postalCode: '96266',
              firstName: 'test',
              phoneNumber: '469-901-4395',
              state: 'AP',
              email: 'tst@ulta.com',
              messages: {
                items: [
                  {
                    type: 'Info'
                  }
                ]
              }
            },
            shipMethodInfo: {
              messages: {
                items: [
                  {
                    messageKey: 'ERR_SHIP_PRICE_CHANGED',
                    messageType: 'Info',
                    messageRef: 'shipMethodInfo',
                    messageDesc: 'Free or discounted shipping is available in the Continental U.S. only and excludes PO Boxes, APO/FPO addresses.'
                  }
                ]
              },
              cost: '$5.95',
              displayName: 'Standard Shipping',
              shipMethod: 'ups_ground',
              estimatedDelivery: null
            }
          }
        }
      }
    };
    const listenerSaga1 = listener( type, data );
    listenerSaga1.next().value;// loading
    listenerSaga1.next().value;// shippingUpdate requested
    listenerSaga1.next( shippingResponse ).value;// shippingUpdate success
    it( 'should put a failure event if shipMethodInfo is returned from the service', () => {
      const msg = { displayCheckoutLevelErrorMessage:'false' };
      const putDescriptor = listenerSaga1.next( shippingResponse ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( msg ) ) );
    } );

  } );

  describe( 'listener saga success path', () => {

    const listenerSaga = listener( type );

    it( 'should  until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )( { paymentType : undefined } ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {

      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );

  describe( 'payment service call check', () => {

    registerServiceName( 'paymentServiceResponse' );
    const data = {
      data:{
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              firstName: 'Jane',
              lastName: 'Doe',
              address1: '1000 Remington Boulevard',
              address2: 'Suite # 120',
              city: 'Bolingbrook',
              state: 'IL',
              postalCode:{ value: '60564' },
              phoneNumber: '(510)-213-8347'
            },
            shippingStatus: 'Complete'
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentForm:{
          values:{
            creditCardType: 'Visa',
            creditCardNumber: '4111111111111111',
            expirationDate: '12/2020',
            securityCode: '123',
            firstNamepaymentAddressForm: 'test1',
            lastNamepaymentAddressForm: 'test',
            address1paymentAddressForm: '1000 Remington Boulevard',
            address2paymentAddressForm: 'Suite # 120',
            citypaymentAddressForm: 'Boolingbrook',
            state: 'IL',
            postalCodepaymentAddressForm: '60564',
            phoneNumberpaymentAddressForm: '999-999-9999',
            nickName:''
          }
        },
        editCreditCardData: {},
        paymentType: 'creditCard',
        paymentSuccess:false,
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        isDeliveryOptionPickup: false,
        shippingSuccess: true,
        creditCardType: 'VISA'
      }
    };

    const paymentData = {
      'address1':'1000 Remington Boulevard',
      'address2':'Suite # 120',
      'cardVerificationNumber':'123',
      'city':'Boolingbrook',
      'creditCardNumber':'4111111111111111',
      'creditCardType':'VISA',
      'expirationMonth':'12',
      'expirationYear':'2020',
      'firstName':'test1',
      'lastName':'test',
      'nickName':'',
      'paymentType':'creditCard',
      'phoneNumber':'999-999-9999',
      'postalCode':'60564',
      'sameAsShipping':false,
      'state':'IL'
    }
    const listenerSaga = listener( type, data );

    it( 'should call setTempPaymentCCVNumber method', () => {
      listenerSaga.next();
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( setTempPaymentCCVNumber( paymentData.cardVerificationNumber ) ) );
    } );

    it( 'should  until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: paymentData } ) ) );
    } );

    it( 'should take paymentServiceResponse success', () => {
      const takeDescriptor = listenerSaga.next().value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'paymentServiceResponse', 'success' ) ) );
    } );

  } );
  describe( 'pickupContactInfoUpdate service call when contactInfoSuccess is false', () => {
    registerServiceName( 'pickupContactInfoUpdate' );
    const data = {
      data : {
        shippingSuccess:true,
        paymentSuccess:false,
        isDeliveryOptionPickup: true,
        pickupContactInfoForm :{
          values:{
            'lastName': 'Test',
            'firstName': 'Test',
            'phoneNumber': '754-647-8754',
            'emailaddress': 'test@ulta.com'
          }
        },
        contactInfoSuccess: false,
        checkoutServicesData:{
          cartSummary:{
            estimatedTotal: 46.18
          }
        }
      }
    }
    const pickupContactInfoData = {
      data:{
        'primaryContactInfo': {
          'lastName': 'Test',
          'firstName': 'Test',
          'phoneNumber': '754-647-8754',
          'email': 'test@ulta.com'
        }
      }
    }
    const listenerSaga = listener( type, data );
    it( 'should wait until the loading event has been put', () => {
      listenerSaga.next();
      listenerSaga.next();
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'pickupContactInfoUpdate', 'requested' )( { contactInfo: pickupContactInfoData } ) ) );
    } );

  } );
  describe( 'pickupContactInfoUpdate service call when contactInfoSuccess is false with alternate contactInfo details', () => {
    registerServiceName( 'pickupContactInfoUpdate' );
    const data = {
      data : {
        shippingSuccess:true,
        paymentSuccess:false,
        isDeliveryOptionPickup: true,
        pickupContactInfoForm :{
          values:{
            'lastName': 'Test',
            'firstName': 'Test',
            'phoneNumber': '754-647-8754',
            'emailaddress': 'test@ulta.com'
          }
        },
        alternatePickupPersonForm :{
          values:{
            isAlternatePickupPersonEnable: true,
            alternateFirstName : 'hello',
            alternateLastName : 'world',
            alternateEmailaddress : 'abc@efhg.com'
          }
        },
        contactInfoSuccess: false,
        checkoutServicesData:{
          cartSummary:{
            estimatedTotal: 46.18
          }
        }
      }
    }
    const pickupContactInfoData = {
      data:{
        'primaryContactInfo': {
          'lastName': 'Test',
          'firstName': 'Test',
          'phoneNumber': '754-647-8754',
          'email': 'test@ulta.com'
        },
        alternateContactInfo: {
          'lastName': 'world',
          'firstName': 'hello',
          'email': 'abc@efhg.com'
        }
      }
    }
    const listenerSaga = listener( type, data );
    it( 'should wait until the loading event has been put', () => {
      listenerSaga.next();
      listenerSaga.next();
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'pickupContactInfoUpdate', 'requested' )( { contactInfo: pickupContactInfoData } ) ) );
    } );

    it( 'should take pickupContactInfoUpdate success', () => {
      const takeDescriptor = listenerSaga.next().value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'pickupContactInfoUpdate', 'success' ) ) );
    } );
  } );
  describe( 'payment service call check when estimated total changes', () => {
    const data = {
      data:{
        checkoutServicesData:{
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentForm:{
          values:{
            creditCardType: 'Visa',
            creditCardNumber: '4111111111111111',
            expirationDate: '12/2020',
            securityCode: '123',
            firstNamepaymentAddressForm: 'test1',
            lastNamepaymentAddressForm: 'test',
            address1paymentAddressForm: '1000 Remington Boulevard',
            address2paymentAddressForm: 'Suite # 120',
            citypaymentAddressForm: 'Boolingbrook',
            state: 'IL',
            postalCodepaymentAddressForm: '60564',
            phoneNumberpaymentAddressForm: '999-999-9999',
            nickName:''
          }
        },
        editCreditCardData: {},
        paymentType: 'creditCard',
        paymentSuccess:false,
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        isDeliveryOptionPickup: false,
        shippingSuccess: true,
        creditCardType: 'VISA',
        shippingForm : {
          values:{
            firstNameshippingAddressForm: 'test',
            lastNameshippingAddressForm: 'test',
            address1shippingAddressForm: '1000 remngton blvd',
            address2shippingAddressForm: 'Ste 200',
            cityshippingAddressForm: 'Boolingbrook',
            emailaddressshippingAddressForm: 'test@test.com',
            state: 'IL',
            postalCodeshippingAddressForm: '07105',
            phoneNumbershippingAddressForm: '(510)-213-8347'
          }
        }
      }
    };
    const expectedShippingOutput = {
      firstName: 'test',
      lastName: 'test',
      address1: '1000 remngton blvd',
      address2: 'Ste 200',
      city: 'Boolingbrook',
      email: 'test@test.com',
      state: 'IL',
      postalCode: '07105',
      primary: false,
      phoneNumber: '510-213-8347'
    }
    const listenerSaga = cloneableGenerator( listener )( type, data );
    listenerSaga.next();
    listenerSaga.next();
    it( 'should make the shipping update call', () => {
      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'shippingUpdate', 'requested' )( { values: expectedShippingOutput } ) ) );
    } );

    let listenerSagaClone;
    it( 'should make the payment call if the estimated total is different', () => {
      listenerSagaClone = listenerSaga.clone();
      listenerSaga.next();
      const paymentData = {
        'address1':'1000 Remington Boulevard',
        'address2':'Suite # 120',
        'cardVerificationNumber':'123',
        'city':'Boolingbrook',
        'creditCardNumber':'4111111111111111',
        'creditCardType':'VISA',
        'expirationMonth':'12',
        'expirationYear':'2020',
        'firstName':'test1',
        'lastName':'test',
        'nickName':'',
        'paymentType':'creditCard',
        'phoneNumber':'999-999-9999',
        'postalCode':'60564',
        'sameAsShipping':false,
        'state':'IL'
      }
      const response = {
        data : {
          response:{
            shippingInfo : {
              shippingStatus : 'Complete',
              shippingAddress : {
                messages: null
              }
            },
            cartSummary:{
              estimatedTotal : 150
            }
          }
        }
      }
      const putDescriptor = listenerSaga.next( response ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: paymentData } ) ) );
    } );


    it( 'should put a payment failure event when istokenizationFailure ', () => {
      listenerSaga.next();
      const putDescriptor = listenerSaga.next( { data:{ istokenizationFailure:true } } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( { setFocusTo: 'payment', displayCheckoutLevelErrorMessage:'false' } ) ) );
    } );

    it( 'should make the payment call if the estimated total is different', () => {
      listenerSagaClone.next();
      const expectedPaymentOutput = {
        creditCardNumber: '4111111111111111',
        expirationDate: '12/2020',
        securityCode: '123',
        firstNamepaymentAddressForm: 'test',
        lastNamepaymentAddressForm: 'test',
        address1paymentAddressForm: '1000 remngton blvd',
        address2paymentAddressForm: 'Ste 200',
        citypaymentAddressForm: 'Boolingbrook',
        state: 'IL',
        postalCodepaymentAddressForm: '07105',
        phoneNumberpaymentAddressForm: '(510)-213-8347'
      }
      const response = {
        data : {
          response:{
            shippingInfo : {
              shippingStatus : 'Complete'
            },
            cartSummary:{
              estimatedTotal : 100
            }
          }
        }
      }
      const putDescriptor = listenerSagaClone.next( response ).value;
      expect( putDescriptor ).not.toEqual( put( getActionDefinition( 'paymentServiceResponse', 'requested' )( { values: expectedPaymentOutput } ) ) );
    } );

  } );

  describe( 'submitOrderService failure path', () => {
    const data = {
      data: {
        checkoutServicesData:{
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentForm: { },
        paymentSuccess: true,
        shippingSuccess: false,
        shippingForm: { }
      }
    };

    const shippingResponse = {
      data:{
        response:{
          shippingInfo:  {
            shippingStatus: 'Complete',
            shippingAddress: {
              messages: {
                items: [
                  {
                    type: 'Error'
                  }
                ]
              }
            }
          }
        }
      }
    };
    const listenerSaga1 = listener( type, data );
    listenerSaga1.next().value;// loading
    listenerSaga1.next().value;
    listenerSaga1.next( ).value;// shippingUpdate requested
    listenerSaga1.next( shippingResponse ).value;// shippingUpdate success

    it( 'should put a failure event with setFocusTo as shipping if shippingResponse has type as error', () => {
      const msg = { displayCheckoutLevelErrorMessage:'false' };
      const putDescriptor = listenerSaga1.next( shippingResponse ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( { setFocusTo: 'shipping' } ) ) );
    } );
  } );

  describe( 'submitOrderService failure path with empty shippingAddress messages', () => {
    const data = {
      data: {
        checkoutServicesData:{
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentForm: { },
        paymentSuccess: true,
        shippingSuccess: false,
        shippingForm: { }
      }
    };

    const shippingResponse = {
      data:{
        response:{
          shippingInfo:  {
            shippingStatus: 'CorrectedAddress',
            shippingAddress: {
              messages: {
                items:{
                  type:'Info'
                }
              }
            }
          }
        }
      }
    };
    const listenerSaga = listener( type, data );
    listenerSaga.next().value;// loading
    listenerSaga.next().value;
    listenerSaga.next().value;// shippingUpdate requested
    listenerSaga.next( shippingResponse ).value;// shippingUpdate success

    it( 'should put a failure event with displayCheckoutLevelErrorMessage as false if shippingStatus is CorrectedAddress', () => {
      const putDescriptor = listenerSaga.next( shippingResponse ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( { displayCheckoutLevelErrorMessage: 'false' } ) ) );
    } );
  } );

  it( 'isAddressFormDirty should return false when the data is matching', () => {

    const formValues = {
      firstNameshippingAddressForm: 'Jane',
      lastNameshippingAddressForm: 'Doe',
      address1shippingAddressForm: '1000 Remington Boulevard',
      address2shippingAddressForm: 'Ste 200',
      cityshippingAddressForm: 'Bolingbrook',
      stateshippingAddressForm: 'IL',
      countryshippingAddressForm:'Chicago',
      emailaddressshippingAddressForm: 'test@test.com',
      phoneNumbershippingAddressForm: '510-213-8347',
      postalCodeshippingAddressForm: '60564'
    }

    const shippingAddress = {
      firstName: { messages: null, value: 'Jane' },
      lastName: { messages: null, value: 'Doe' },
      address1: { messages: null, value: '1000 Remington Boulevard' },
      address2: { messages: null, value: 'Ste 200' },
      city: { messages: null, value: 'Bolingbrook' },
      state: { messages: null, value: 'IL' },
      country: { messages: null, value: 'Chicago' },
      email: { messages: null, value: 'test@test.com' },
      phoneNumber: { messages: null, value: '510-213-8347' },
      postalCode: { messages: null, value: '60564' }
    }
    expect( isAddressFormDirty( shippingAddress, formValues ) ).toBe( false );
  } );

  it( 'isAddressFormDirty should return true when the data is not matching', () => {
    const formValues = {
      firstNameshippingAddressForm: 'Jane',
      lastNameshippingAddressForm: 'Doe',
      address1shippingAddressForm: '1000 Remington Boulevard',
      cityshippingAddressForm: 'Bolingbrook',
      emailaddressshippingAddressForm: 'test@test.com',
      state: 'IL',
      postalCodeshippingAddressForm: '60564',
      phoneNumbershippingAddressForm: '(510)-213-8346'
    }

    const shippingAddress = {
      firstName: { messages: null, value: 'Pushpendra' },
      lastName: { messages: null, value: 'Kabdaula' },
      phoneNumber: { messages: null, value: '123-456-7890' },
      email: { messages: null, value: 'pkabdaula@ulta.com' },
      address1: { messages: null, value: '1000 remngton blvd' },
      address2: { messages: null, value: 'Ste 200' },
      city: { messages: null, value: 'ffff' },
      state: { messages: null, value: 'Iy' },
      postalCode: { messages: null, value: '07105' },
      country: { messages: null, value: 'US' }
    }
    expect( isAddressFormDirty( shippingAddress, formValues ) ).toBe( true );
  } );

  it( 'isPickupContactInfoFormDirty should return true when the data is not matching', () => {
    const formValues = {
      firstName: 'Jane',
      lastName: 'Doe',
      emailaddress: '1000 Remington Boulevard',
      phoneNumber: 'Bolingbrook'
    }
    const primaryContactInfo = {
      firstName: { messages: null, value: 'Jane' },
      lastName: { messages: null, value: 'Kabdaula' },
      phoneNumber: { messages: null, value: '123-456-7890' },
      email: { messages: null, value: 'pkabdaula@ulta.com' }
    }
    expect( isPickupContactInfoFormDirty( primaryContactInfo, formValues ) ).toBe( true );
  } );

  it( 'isPickupContactInfoFormDirty should return false when the data is matching', () => {
    const formValues = {
      firstName: 'Jane',
      lastName: 'Doe',
      emailaddress: 'pkabdaula@ulta.com',
      phoneNumber: '123-456-7890'
    }
    const primaryContactInfo = {
      firstName: { messages: null, value: 'Jane' },
      lastName: { messages: null, value: 'Doe' },
      phoneNumber: { messages: null, value: '123-456-7890' },
      emailAddress: { messages: null, value: 'pkabdaula@ulta.com' }
    }
    expect( isPickupContactInfoFormDirty( primaryContactInfo, formValues ) ).toBe( false );
  } );

  it( 'isAlternateContactInfoFormDirty should return true when the data is not matching', () => {
    const formValues = {
      alternateFirstName: 'Jane',
      alternateLastName: 'Doe',
      alternateEmailaddress: '1000 Remington Boulevard'
    }
    const alternateConatctInfo = {
      firstName: { messages: null, value: 'Jane' },
      lastName: { messages: null, value: 'Kabdaula' },
      emailAddress: { messages: null, value: 'pkabdaula@ulta.com' }
    }
    expect( isAlternateContactInfoFormDirty( alternateConatctInfo, formValues ) ).toBe( true );
  } )

  it( 'isAlternateContactInfoFormDirty should return false when the data is matching', () => {
    const formValues = {
      alternateFirstName: 'Jane',
      alternateLastName: 'Doe',
      alternateEmailaddress: 'pkabdaula@ulta.com'
    }
    const alternateConatctInfo = {
      firstName: { messages: null, value: 'Jane' },
      lastName: { messages: null, value: 'Doe' },
      emailAddress: { messages: null, value: 'pkabdaula@ulta.com' }
    }
    expect( isAlternateContactInfoFormDirty( alternateConatctInfo, formValues ) ).toBe( false );
  } );

  it( 'updateShippingFormValues should return shippingFormValues and shippingSuccess as false if shipping adddress is edited and isPrimary as true', () => {
    const data = {
      data:{
        shippingAddressList:{
          shippingAddress: {
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '1000 Remington Boulevard',
            address2: 'Suite # 120',
            city: 'Bolingbrook',
            state: 'IL',
            postalCode:{ value: '60564' },
            phoneNumber: '510-213-8347'
          }
        },
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              firstName: 'Jane',
              lastName: 'Doe',
              address1: '1000 Remington Boulevard',
              address2: 'Suite # 120',
              city: 'Bolingbrook',
              state: 'IL',
              postalCode:{ value: '60564' },
              phoneNumber: '(510)-213-8347'
            },
            shippingStatus: 'Complete'
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: true,
        paymentType: 'creditCard',
        isDeliveryOptionPickup: false,
        creditCardDetails: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {},
          messages: null
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        shippingForm:{
          values:{
            firstNameshippingAddressForm: 'Jane',
            lastNameshippingAddressForm: 'Doe',
            address1shippingAddressForm: '1000 Remington Boulevard',
            address2shippingAddressForm: 'Ste 200',
            cityshippingAddressForm: 'Bolingbrook',
            state: 'IL',
            countryshippingAddressForm:'Chicago',
            emailaddressshippingAddressForm: 'test@test.com',
            phoneNumbershippingAddressForm: '510-213-8347',
            postalCodeshippingAddressForm: '60564',
            isPrimary: true
          }
        }
      }
    };

    const shippingFormValues = {
      firstName: 'Jane',
      lastName: 'Doe',
      phoneNumber: '510-213-8347',
      email: 'test@test.com',
      address1: '1000 Remington Boulevard',
      address2: 'Ste 200',
      city: 'Bolingbrook',
      state: 'IL',
      postalCode: '60564',
      primary: true
    }
    expect( updateShippingFormValues( data ) ).toEqual( { shippingFormValues: shippingFormValues, shippingSuccess: false } );
  } );

  it( 'updateShippingFormValues should return shippingFormValues and shippingSuccess as false if shipping adddress is edited and isPrimary as false', () => {
    const data = {
      data:{
        shippingAddressList:{
          shippingAddress: {
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '1000 Remington Boulevard',
            address2: 'Suite # 120',
            city: 'Bolingbrook',
            state: 'IL',
            postalCode:{ value: '60564' },
            phoneNumber: '510-213-8347'
          }
        },
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              firstName: 'Jane',
              lastName: 'Doe',
              address1: '1000 Remington Boulevard',
              address2: 'Suite # 120',
              city: 'Bolingbrook',
              state: 'IL',
              postalCode:{ value: '60564' },
              phoneNumber: '(510)-213-8347'
            },
            shippingStatus: 'Complete'
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: true,
        paymentType: 'creditCard',
        isDeliveryOptionPickup: false,
        creditCardDetails: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {},
          messages: null
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        shippingForm:{
          values:{
            firstNameshippingAddressForm: 'Jane',
            lastNameshippingAddressForm: 'Doe',
            address1shippingAddressForm: '1000 Remington Boulevard',
            address2shippingAddressForm: 'Ste 200',
            cityshippingAddressForm: 'Bolingbrook',
            state: 'IL',
            countryshippingAddressForm:'Chicago',
            emailaddressshippingAddressForm: 'test@test.com',
            phoneNumbershippingAddressForm: '510-213-8347',
            postalCodeshippingAddressForm: '60564',
            isPrimary: false
          }
        }
      }
    };

    const shippingFormValues = {
      firstName: 'Jane',
      lastName: 'Doe',
      phoneNumber: '510-213-8347',
      email: 'test@test.com',
      address1: '1000 Remington Boulevard',
      address2: 'Ste 200',
      city: 'Bolingbrook',
      state: 'IL',
      postalCode: '60564',
      primary: false
    }
    expect( updateShippingFormValues( data ) ).toEqual( { shippingFormValues: shippingFormValues, shippingSuccess: false } );
  } );
  it( 'updateShippingFormValues should return shippingFormValues and shippingSuccess as false if shipping adddress is edited and isPrimary as undefined', () => {
    const data = {
      data:{
        shippingAddressList:{
          shippingAddress: {
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '1000 Remington Boulevard',
            address2: 'Suite # 120',
            city: 'Bolingbrook',
            state: 'IL',
            postalCode:{ value: '60564' },
            phoneNumber: '510-213-8347'
          }
        },
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              firstName: 'Jane',
              lastName: 'Doe',
              address1: '1000 Remington Boulevard',
              address2: 'Suite # 120',
              city: 'Bolingbrook',
              state: 'IL',
              postalCode:{ value: '60564' },
              phoneNumber: '(510)-213-8347'
            },
            shippingStatus: 'Complete'
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: true,
        paymentType: 'creditCard',
        isDeliveryOptionPickup: false,
        creditCardDetails: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {},
          messages: null
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        shippingForm:{
          values:{
            firstNameshippingAddressForm: 'Jane',
            lastNameshippingAddressForm: 'Doe',
            address1shippingAddressForm: '1000 Remington Boulevard',
            address2shippingAddressForm: 'Ste 200',
            cityshippingAddressForm: 'Bolingbrook',
            state: 'IL',
            countryshippingAddressForm:'Chicago',
            emailaddressshippingAddressForm: 'test@test.com',
            phoneNumbershippingAddressForm: '510-213-8347',
            postalCodeshippingAddressForm: '60564',
            isPrimary: undefined
          }
        }
      }
    };

    const shippingFormValues = {
      firstName: 'Jane',
      lastName: 'Doe',
      phoneNumber: '510-213-8347',
      email: 'test@test.com',
      address1: '1000 Remington Boulevard',
      address2: 'Ste 200',
      city: 'Bolingbrook',
      state: 'IL',
      postalCode: '60564',
      primary: false
    }
    expect( updateShippingFormValues( data ) ).toEqual( { shippingFormValues: shippingFormValues, shippingSuccess: false } );
  } );

  it( 'updatePickupContactFormValues should return pickupContactFormValues and contactInfoSuccess as false if primaryContactInfo is edited', () => {
    const data = {
      data:{
        checkoutServicesData:{
          pickupInfo:{
            primaryContactInfo:{
              firstName: 'Jane',
              lastName: 'Doe',
              emailaddress: '1000 Remington Boulevard',
              phoneNumber: '111-111-1111'
            }
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: true,
        paymentType: 'creditCard',
        isDeliveryOptionPickup: true,
        creditCardDetails: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {},
          messages: null
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        pickupContactInfoForm:{
          values:{
            firstName: 'Jane',
            lastName: 'Doe',
            emailaddress: 'test@test.com',
            phoneNumber: '510-213-8347'
          }
        }
      }
    };

    const pickupContactFormValues = {
      data:{
        primaryContactInfo: {
          firstName: 'Jane',
          lastName: 'Doe',
          phoneNumber: '510-213-8347',
          email: 'test@test.com'
        }
      }
    }
    expect( updatePickupContactFormValues( data ) ).toEqual( { pickupContactFormValues: pickupContactFormValues, contactInfoSuccess: false } );
  } );

  it( 'updateAlternateContactFormValues should return pickupContactFormValues and contactInfoSuccess as false if alternateContactInfo is edited', () => {
    const data = {
      data:{
        checkoutServicesData:{
          pickupInfo:{
            primaryContactInfo:{
              firstName: 'Jane',
              lastName: 'Doe',
              emailaddress: '1000 Remington Boulevard',
              phoneNumber: '111-111-1111'
            }
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: true,
        paymentType: 'creditCard',
        isDeliveryOptionPickup: true,
        creditCardDetails: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {},
          messages: null
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        pickupContactInfoForm:{
          values:{
            firstName: 'Jane',
            lastName: 'Doe',
            emailaddress: 'test@test.com',
            phoneNumber: '510-213-8347'
          }
        },
        alternatePickupPersonForm:{
          values:{
            alternateFirstName: 'John',
            alternateLastName: 'Doe',
            alternateEmailaddress: 'johndoe@test.com',
            isAlternatePickupPersonEnable: true
          }
        }
      }
    };

    const pickupContactForm = {
      data:{
        primaryContactInfo: {
          firstName: 'Jane',
          lastName: 'Doe',
          phoneNumber: '510-213-8347',
          email: 'test@test.com'
        }
      }
    }
    const pickupContactFormValues = {
      data:{
        primaryContactInfo: {
          firstName: 'Jane',
          lastName: 'Doe',
          phoneNumber: '510-213-8347',
          email: 'test@test.com'
        },
        alternateContactInfo: {
          firstName: 'John',
          lastName: 'Doe',
          email: 'johndoe@test.com'
        }
      }
    }
    expect( updateAlternateContactFormValues( pickupContactForm, data ) ).toEqual( { pickupContactFormValues: pickupContactFormValues, contactInfoSuccess: false } );
  } );

  it( 'validatePaymentForm should return paymentFormValues if paymentSuccess is false and billing address is same as contactInfo', () => {
    const paymentSuccess = false;
    const data = {
      data:{
        checkoutServicesData:{
          pickupInfo:{
            primaryContactInfo:{
              firstName: 'Jane',
              lastName: 'Doe',
              emailaddress: '1000 Remington Boulevard',
              phoneNumber: '111-111-1111'
            }
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: false,
        paymentType: 'creditCard',
        creditCardType: 'Visa',
        isDeliveryOptionPickup: true,
        isBillingAddressSameAsContactInfo: true,
        editCreditCardData:{},
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        pickupContactInfoForm:{
          values:{
            firstName: 'Jane',
            lastName: 'Doe',
            emailaddress: 'test@test.com',
            phoneNumber: '510-213-8347'
          }
        },
        alternatePickupPersonForm:{
          values:{
            alternateFirstName: 'John',
            alternateLastName: 'Doe',
            alternateEmailaddress: 'johndoe@test.com',
            isAlternatePickupPersonEnable: true
          }
        },
        paymentForm:{
          values:{
            creditCardType: 'Visa',
            creditCardNumber: '4111111111111111',
            expirationDate: '12/2020',
            securityCode: '123',
            firstNamepaymentAddressForm: 'test1',
            lastNamepaymentAddressForm: 'test',
            address1paymentAddressForm: '1000 Remington Boulevard',
            address2paymentAddressForm: 'Suite # 120',
            citypaymentAddressForm: 'Boolingbrook',
            state: 'IL',
            postalCodepaymentAddressForm: '60564',
            phoneNumberpaymentAddressForm: '999-999-9999',
            nickName:''
          }
        }
      }
    };

    const paymentFormValues = {
      firstName: 'Jane',
      lastName: 'Doe',
      address1: '1000 Remington Boulevard',
      address2: 'Suite # 120',
      postalCode: '60564',
      city: 'Boolingbrook',
      state: 'IL',
      phoneNumber: '510-213-8347',
      creditCardNumber: '4111111111111111',
      creditCardType: 'Visa',
      nickName: '',
      sameAsShipping: false,
      paymentType: 'creditCard',
      expirationMonth: '12',
      expirationYear: '2020',
      cardVerificationNumber: '123'
    }
    expect( validatePaymentForm( paymentSuccess, data ) ).toEqual( paymentFormValues );
  } );

  it( 'validatePaymentForm should return paymentFormValues if paymentSuccess is false and billing address is same as shipping', () => {
    const paymentSuccess = false;
    const data = {
      data:{
        shippingAddressList:{
          shippingAddress: {
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '1000 Remington Boulevard',
            address2: 'Suite # 120',
            city: 'Bolingbrook',
            state: 'IL',
            postalCode:{ value: '60564' },
            phoneNumber: '510-213-8347'
          }
        },
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              firstName: 'Jane',
              lastName: 'Doe',
              address1: '1000 Remington Boulevard',
              address2: 'Suite # 120',
              city: 'Bolingbrook',
              state: 'IL',
              postalCode:{ value: '60564' },
              phoneNumber: '(510)-213-8347'
            },
            shippingStatus: 'Complete'
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: false,
        paymentType: 'creditCard',
        creditCardType: 'Visa',
        isDeliveryOptionPickup: true,
        isBillingAddressSameAsShipping: true,
        editCreditCardData:{},
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        shippingForm:{
          values:{
            firstNameshippingAddressForm: 'Jane',
            lastNameshippingAddressForm: 'Doe',
            address1shippingAddressForm: '1000 Remington Boulevard',
            address2shippingAddressForm: 'Ste 200',
            cityshippingAddressForm: 'Bolingbrook',
            state: 'IL',
            countryshippingAddressForm:'Chicago',
            emailaddressshippingAddressForm: 'test@test.com',
            phoneNumbershippingAddressForm: '510-213-8347',
            postalCodeshippingAddressForm: '60564'
          }
        },
        paymentForm:{
          values:{
            creditCardType: 'Visa',
            creditCardNumber: '4111111111111111',
            expirationDate: '12/2020',
            securityCode: '123',
            firstNamepaymentAddressForm: 'test1',
            lastNamepaymentAddressForm: 'test',
            address1paymentAddressForm: '1000 Remington Boulevard',
            address2paymentAddressForm: 'Suite # 120',
            citypaymentAddressForm: 'Boolingbrook',
            state: 'IL',
            postalCodepaymentAddressForm: '60564',
            phoneNumberpaymentAddressForm: '999-999-9999',
            nickName:''
          }
        }
      }
    };

    const paymentFormValues = {
      creditCardNumber: '4111111111111111',
      creditCardType: 'Visa',
      nickName: '',
      sameAsShipping: true,
      paymentType: 'creditCard',
      expirationMonth: '12',
      expirationYear: '2020',
      cardVerificationNumber: '123'
    }
    expect( validatePaymentForm( paymentSuccess, data ) ).toEqual( paymentFormValues );
  } );

  it( 'validatePaymentForm should return paymentFormValues if paymentSuccess is false and creditCardDetails.paymentDetails is available', () => {
    const paymentSuccess = false;
    const data = {
      data:{
        shippingAddressList:{
          shippingAddress: {
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '1000 Remington Boulevard',
            address2: 'Suite # 120',
            city: 'Bolingbrook',
            state: 'IL',
            postalCode:{ value: '60564' },
            phoneNumber: '510-213-8347'
          }
        },
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              firstName: 'Jane',
              lastName: 'Doe',
              address1: '1000 Remington Boulevard',
              address2: 'Suite # 120',
              city: 'Bolingbrook',
              state: 'IL',
              postalCode:{ value: '60564' },
              phoneNumber: '(510)-213-8347'
            },
            shippingStatus: 'Complete'
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: false,
        paymentType: 'creditCard',
        creditCardType: 'Visa',
        isDeliveryOptionPickup: true,
        isBillingAddressSameAsShipping: true,
        editCreditCardData:{},
        creditCardDetails: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth:  { messages: null, value: '09' },
            expirationYear:  { messages: null, value: '2021' },
            creditCardNumber:  { messages: null, value: '4111111111111111' },
            creditCardType:  { messages: null, value: 'Visa' }
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: { messages: null, value: 'John' },
            lastName: { messages: null, value: 'Doe' },
            phoneNumber: { messages: null, value: '123-456-7890' },
            email: { messages: null, value: 'johndoe@ulta.com' },
            address1: { messages: null, value: '1000 remngton blvd' },
            address2: { messages: null, value: '' },
            city: { messages: null, value: 'Boolingbrook' },
            state: { messages: null, value: 'IL' },
            postalCode: { messages: null, value: '07105' },
            country: { messages: null, value: 'US' }
          },
          nickName:'',
          messages: null
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        shippingForm:{
          values:{
            firstNameshippingAddressForm: 'Jane',
            lastNameshippingAddressForm: 'Doe',
            address1shippingAddressForm: '1000 Remington Boulevard',
            address2shippingAddressForm: 'Ste 200',
            cityshippingAddressForm: 'Bolingbrook',
            state: 'IL',
            countryshippingAddressForm:'Chicago',
            emailaddressshippingAddressForm: 'test@test.com',
            phoneNumbershippingAddressForm: '510-213-8347',
            postalCodeshippingAddressForm: '60564'
          }
        }
      }
    };

    const paymentFormValues = {
      paymentType: 'creditCard',
      creditCardType:'Visa',
      creditCardNumber:'4111111111111111',
      expirationMonth:'09',
      expirationYear:'2021',
      nickName:'',
      firstName:'John',
      lastName:'Doe',
      phoneNumber:'123-456-7890',
      address1:'1000 remngton blvd',
      address2:'',
      city:'Boolingbrook',
      state:'IL',
      postalCode:'07105',
      country:'US'
    }
    expect( validatePaymentForm( paymentSuccess, data ) ).toEqual( paymentFormValues );
  } );

  it( 'submitForms should return values when creditCard is used as the payment type', () => {
    const data = {
      data:{
        shippingAddressList:{
          shippingAddress: {
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '1000 Remington Boulevard',
            address2: 'Suite # 120',
            city: 'Bolingbrook',
            state: 'IL',
            postalCode:{ value: '60564' },
            phoneNumber: '510-213-8347'
          }
        },
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              firstName: 'Jane',
              lastName: 'Doe',
              address1: '1000 Remington Boulevard',
              address2: 'Suite # 120',
              city: 'Bolingbrook',
              state: 'IL',
              postalCode:{ value: '60564' },
              phoneNumber: '(510)-213-8347'
            },
            shippingStatus: 'Complete'
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: true,
        paymentType: 'creditCard',
        isDeliveryOptionPickup: false,
        creditCardDetails: {
          paymentType: 'creditCard',
          paymentDetails: {
            expirationMonth: '09',
            expirationYear: '2021',
            creditCardNumber: '',
            creditCardType: 'Visa'
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {},
          messages: null
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        shippingForm:{
          firstNameshippingAddressForm: 'Jane',
          lastNameshippingAddressForm: 'Doe',
          address1shippingAddressForm: '1000 Remington Boulevard',
          address2shippingAddressForm: 'Ste 200',
          cityshippingAddressForm: 'Bolingbrook',
          stateshippingAddressForm: 'IL',
          countryshippingAddressForm:'Chicago',
          emailaddressshippingAddressForm: 'test@test.com',
          phoneNumbershippingAddressForm: '510-213-8347',
          postalCodeshippingAddressForm: '60564'
        }
      }
    };

    const submitFormValues = {
      'amountDue':46.18,
      'contactInfoSuccess':true,
      'guestUserEmailOptIn':false,
      'paymentData':{

      },
      'paymentResponse':{
        'amount':46.18,
        'contactInfo':{

        },
        'currencyCode':'USD',
        'messages':null,
        'paymentDetails':{
          'creditCardNumber':'',
          'creditCardType':'Visa',
          'expirationMonth':'09',
          'expirationYear':'2021'
        },
        'paymentType':'creditCard'
      },
      'paymentSuccess':true,
      'pickupContactInfoData':{

      },
      'shippingData':{

      },
      'shippingResponse':{
        'shippingAddress':{
          'address1':'1000 Remington Boulevard',
          'address2':'Suite # 120',
          'city':'Bolingbrook',
          'firstName':'Jane',
          'lastName':'Doe',
          'phoneNumber':'(510)-213-8347',
          'postalCode':{
            'value':'60564'
          },
          'state':'IL'
        },
        'shippingStatus':'Complete'
      },
      'shippingSuccess':true
    }
    expect( submitForms( data ) ).toEqual( submitFormValues );
  } );

  it( 'submitForms should return values when paypal is used as the payment type', () => {
    const data = {
      data:{
        shippingAddressList:{
          shippingAddress: {
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '1000 Remington Boulevard',
            address2: 'Suite # 120',
            city: 'Bolingbrook',
            state: 'IL',
            postalCode:{ value: '60564' },
            phoneNumber: '510-213-8347'
          }
        },
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              firstName: 'Jane',
              lastName: 'Doe',
              address1: '1000 Remington Boulevard',
              address2: 'Suite # 120',
              city: 'Bolingbrook',
              state: 'IL',
              postalCode:{ value: '60564' },
              phoneNumber: '(510)-213-8347'
            },
            shippingStatus: 'Complete'
          },
          cartSummary:{
            estimatedTotal: 46.18
          }
        },
        paymentSuccess: true,
        paymentType: 'paypal',
        isDeliveryOptionPickup: false,
        payPalDetails : {
          emailAddress: 'ecomqaoffshore@ulta.com'
        },
        newsLetterSignupFormValues: {
          newsLetter: false
        },
        shippingForm:{
          firstNameshippingAddressForm: 'Jane',
          lastNameshippingAddressForm: 'Doe',
          address1shippingAddressForm: '1000 Remington Boulevard',
          address2shippingAddressForm: 'Ste 200',
          cityshippingAddressForm: 'Bolingbrook',
          stateshippingAddressForm: 'IL',
          countryshippingAddressForm:'Chicago',
          emailaddressshippingAddressForm: 'test@test.com',
          phoneNumbershippingAddressForm: '510-213-8347',
          postalCodeshippingAddressForm: '60564'
        }
      }
    };

    const submitFormValues = {
      'amountDue':46.18,
      'contactInfoSuccess':true,
      'guestUserEmailOptIn':false,
      'paymentData':{

      },
      'paymentResponse':{
        emailAddress: 'ecomqaoffshore@ulta.com'
      },
      'paymentSuccess':true,
      'pickupContactInfoData':{

      },
      'shippingData':{

      },
      'shippingResponse':{
        'shippingAddress':{
          'address1':'1000 Remington Boulevard',
          'address2':'Suite # 120',
          'city':'Bolingbrook',
          'firstName':'Jane',
          'lastName':'Doe',
          'phoneNumber':'(510)-213-8347',
          'postalCode':{
            'value':'60564'
          },
          'state':'IL'
        },
        'shippingStatus':'Complete'
      },
      'shippingSuccess':true
    }
    expect( submitForms( data ) ).toEqual( submitFormValues );
  } );

  it( 'submitForms should return values when payment type is afterpay', () => {
    const data = {
      data:{
        paymentType: 'afterpay',
        afterpayDetails : {
          paymentType: 'afterpay',
          messages: null
        },
        checkoutServicesData:{
          cartSummary:{
            estimatedTotal: 46.18
          }
        }
      }
    };

    const submitFormValues = {
      'amountDue':46.18,
      'contactInfoSuccess':true,
      'guestUserEmailOptIn':undefined,
      'paymentData':{},
      'paymentResponse':{
        paymentType: 'afterpay',
        messages: null
      },
      'paymentSuccess':true,
      'pickupContactInfoData':{},
      'shippingData':{},
      'shippingResponse':{},
      'shippingSuccess':false
    }
    expect( submitForms( data ) ).toEqual( submitFormValues );
  } );

  it( 'submitForms should return paymentSuccess as false if paymentType is afterpay and afterpayDetails has error messages', () => {
    const data = {
      data:{
        paymentType: 'afterpay',
        afterpayDetails : {
          paymentType: 'afterpay',
          messages: {
            items: [
              {
                type: 'Error',
                message: 'Oh no! Were experiencing difficulty processing your payment. Try again later or use another payment method.'
              }
            ]
          }
        },
        checkoutServicesData:{
          cartSummary:{
            estimatedTotal: 46.18
          }
        }
      }
    };
    expect( submitForms( data ).paymentSuccess ).toEqual( false );
  } );

} );
