
import { takeEvery, call, put } from 'redux-saga/effects';



import {
  fullyQualifyLink,
  host
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';

import {
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ajax
} from '../../utils/ajax/ajax';

// Individual exports for testing
export const listener = function*( type, CONFIG, action ){

  try {

    yield put( getActionDefinition( type, 'loading' )() );

    let query = {};
    if( process.env.NODE_ENV === 'development' ){
      query.__ENABLE_QUBIT = true;
      query.__ENABLE_REFLEKTION = false;
      query.__ENABLE_SESSIONCAM = true;
      query.__ENABLE_MOOVWEB = false;
    }

    const res = yield call( ajax,
      {
        type,
        query
      } );

    yield put( getActionDefinition( type, 'success' )( res.body ) ) ;

  }
  catch ( err ){

    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}

export default function( CONFIG ){
  return function*(){
    let serviceType = 'switches';
    // register events for the request
    registerServiceName( serviceType );

    yield takeEvery( getServiceType( 'switches', 'requested' ), listener, serviceType, CONFIG );
  }
}
