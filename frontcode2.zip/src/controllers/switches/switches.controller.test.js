
/**
 * switches  sagas
 */

import { call, put } from 'redux-saga/effects';

import {
  registerServiceName,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';


import CONFIG from '../../config';

import {
  ajax
} from '../../utils/ajax/ajax';
import { listener } from './switches.controller';


const type = 'switches';

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );

  describe( 'listener saga success path', () => {

    const data = {};
    const CONFIG = {
      ENABLE_QUBIT :true,
      ENABLE_SESSIONCAM:true,
      ENABLE_POWER_REVIEWS:true
    }
    const listenerSaga = listener( type, CONFIG, { data } );

    it( 'should should until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor  = listenerSaga.next().value;
      const query = {};

      expect( callDescriptor ).toEqual( call( ajax, { type, query } ) );

    } );

    const res = {
      body:{
        switches:{
          brightTagSiteID:'1',
          enableQubitTag:true,
          enableSessionCamTag:true
        }
      }
    }

    it( 'should yield sucess', () => {

      const callDescriptor  = listenerSaga.next( res ).value;

      expect( callDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );

  } );

  describe( 'conditionally load scripts', () => {
    let res = {
      body: {
        switches: {
          enableRfkRecommendation: true
        }
      }
    }

    it( 'should load the Reflektion script', () => {
      expect( res.body.switches.enableRfkRecommendation ).toEqual( CONFIG.ENABLE_REFLEKTION );
    } );

  } );

} );
