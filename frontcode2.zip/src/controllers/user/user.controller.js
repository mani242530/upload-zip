import {
  takeEvery, take, call, put, select
} from 'redux-saga/effects';
import has from 'lodash/has';
import get from 'lodash/get';


import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import qProtocol from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';
import { fullyQualifyLink, host } from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import {
  retrieveReflektionLoginEvent,
  removeReflektionLoginEvent
} from '../../utils/local_storage/local_storage';
import getHistory from '../../utils/history/history';
import { openSignInModal } from '../../events/sign_in_modal/sign_in_modal.events';
import { authorizeLoad } from '../../events/authorize/authorize.events';
import appConstants from '../../shared/appConstants';
import { getExpirationInMilliseconds } from '../../utils/formatters/formatters';
import { saveUserData } from '../../utils/user_storage/user_storage';

// Individual exports for testing
export const listener = function*( type, CONFIG, data ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    let query = {}

    if( process.env.NODE_ENV === 'development' ){
      const invokedFromLogin = !!has( data.data, 'invokedFromLogin' );

      query.__IS_SIGNED_IN = invokedFromLogin ? true : CONFIG.DEBUGGING.USER.isSignedIn;
      query.__IS_REWARDS_MEMBER = CONFIG.DEBUGGING.USER.isRewardsMember;
      query.__IS_REWARD_STATUS = CONFIG.DEBUGGING.USER.rewardStatus;
      query.__IS_EMAIL_OPT_IN = CONFIG.DEBUGGING.USER.isEmailOptIn;
      query.__CART_COUNT = CONFIG.DEBUGGING.CART.cartQty;
      query.__IS_SOFT_LOGIN_USER = CONFIG.DEBUGGING.USER.isSoftLoginUser;
      query.__IS_STAGING_ENV = CONFIG.DEBUGGING.isStagingEnvironment;
    }

    const res = yield call( ajax, { type, query } );


    if( process.env.NODE_ENV === 'development' ){

      // check the timeout flag and reset the user data based on that
      if( global._DEBUG_TIMEOUT ){

        res.body = {
          data: {
            cart: {
              itemCount: 0
            },
            user: {
              rewardsInfo: {
                pointRedeemValue: 111,
                pointsBalance: 4411,
                pointRedeem: 3330,
                status: null
              },
              accountInfo: {
                lastName: 'Test Last',
                firstName: 'Test First',
                email: 'testuser@ulta.com',
                rewardsMember: false,
                emailOptIn: false,
                dateOfBirth: '04/30'
              }
            }
          },
          meta: {
            lastFetchedTime: '2017-11-08 14:52:33.608-06:00'
          }
        };

        // reset the debugTimeout flag
        global._DEBUG_TIMEOUT = false;
      }

    }

    let profileData;
    // Updated the below condition based on v2 user lite services
    if( has( res.body.data, 'user.accountInfo.firstName' ) ){
      yield put( getActionDefinition( 'profile', 'requested' )() );
      profileData = yield take( getServiceType( 'profile', 'success' ) );
    }
    yield put( getActionDefinition( type, 'success' )( {
      ...res.body.data,
      meta:res.body.meta
    } ) );

    // authorizeLoad will put an action to check if the user is allowed to load the page
    // a success will indicate that the user has access, and will be able to continue viewing the page
    yield put( authorizeLoad( { url:global.location.pathname, search: global.location.search } ) );
    yield take( getServiceType( 'authorize', 'success' ) );

    const history = getHistory();
    const {
      pathname,
      search
    } = history.location;

    const params = new URLSearchParams( search );
    if( params.get( 'forceLogin' ) ){
      // for anonymous user if forceLogin param is part of the url, launch the signin modal
      if( !res.body.data?.user?.accountInfo?.firstName ){
        yield put( openSignInModal( { sourcePage:'logout' } ) )
        params.delete( 'forceLogin' );
        let newUrl = pathname;
        if( params.toString() !== '' ){
          newUrl = `${ newUrl }?${ params.toString() }`;
        }
        history.replace( newUrl );
      }
      // if the user is already logged in, and if forceLogin=true and source=account is part of the url, then redirect the user to myaccount page
      else if( params.get( 'source' ) === 'account' ){
        global.location.href = fullyQualifyLink( host, appConstants.ROUTES.ACCOUNT_PAGE );
      }
    }

    // Analytics tracking code begin
    // In the updated V2 service user object will be empty for guest user or LPS down
    if( has( res.body.data, 'user.rewardsInfo.pointsBalance' ) ){

      const {
        rewardsInfo
      } = res.body.data.user;

      const profileRewardsInfo = profileData.data.rewardsInfo;

      const profileInfo = profileData.data.profileInfo;

      const dataLayer = {
        'globalPageData': {
          'rewards': {
            ...( global.globalPageData?.rewards && global.globalPageData.rewards ),
            'loyaltyId': profileRewardsInfo?.memberNumber,
            'programId': profileRewardsInfo?.planId,
            'memberSince': profileRewardsInfo?.memberSince,
            'platinumMember': `${ profileRewardsInfo?.platinum }`,
            'platinumMemberType':( profileInfo?.beautyClubPlanType?.planDesc || '' ) .toLowerCase(),
            'userType' : profileInfo?.beautyClubPlanType?.planDesc ? 'reg - loyalty member' : 'reg - non-loyalty member',
            'clubPoints': rewardsInfo.pointsBalance
          }
        }
      }

      let evt = {
        'name': appConstants.ANALYTICS.REWARDS_DATA_READY
      }

      yield put( setDataLayer( dataLayer, evt ) );

    }
    // Analtyics tracking code end
    // Member number will have value only for reward member
    // ECUser Event should triggered only for reward member
    if( get( profileData, 'data.rewardsInfo.memberNumber' ) && res.body.data.user ){
    // memberNumber is available in profile success response's rewardInfo
    // member loyalty info- status and pointBalance available in user success response's rewardInfo
      triggerQProtocol( profileData.data.rewardsInfo.memberNumber, res.body.data.user.rewardsInfo );
    }

    /**
     * The following logic is implemented to trigger the login event when the user is in the salon flow in the mobile Inflection.
     * This flow is bit complicated as the login happens in the JSP but the header is REACT hence we need to handle the logic in bit of both.
     * The 'fireReflektionLoginEvent' variable is set in the sessionStorage before login, once the user is logged in the below peice of code
     * checks if the retrieveReflektionLoginEvent() returns a value and if enableRfkEvents flag is true if yes then triggers the event and
     * removes the 'fireReflektionLoginEvent' value from session by calling the removeReflektionLoginEvent()
     */
    if( has( res.body.data, 'user.accountInfo.firstName' ) ){
      const switchData = yield select( makeGetSwitchesData() );

      // if the user is softlogin user,  in the flag in local storage we are storing the value in milliseconds until which the user will be remembered
      // rememberMeMaxAge returned from config servie will be in seconds and hence multiplying with 1000 to convert it into milliseconds
      // this flag is being used by analytics code in signal
      if( res.body.data.user.isSoftLoginUser ){
        saveUserData( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, getExpirationInMilliseconds( switchData.switches.rememberMeMaxAge ) );
      }

      // triggerUserLoginReflektionEvent is called only when enableRfkEvents is true
      if( retrieveReflektionLoginEvent() && switchData.switches.enableRfkEvents ){
      // trigger reflektion event
        yield put( getActionDefinition( 'reflektionLoginEvent', 'requested' )() );
        removeReflektionLoginEvent();
      }
    }

  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );

    if( global.TRACK_SAGA_FAILURES ){
      throw err;
    }

  }
}
export const triggerQProtocol = ( memberId, rewardsInfo ) => {
  let qubitUserData = {
    user: {
      id:memberId,
      loyalty:{
        tier:rewardsInfo.status,
        tierPoints:rewardsInfo.pointsBalance
      }
    }
  }
  qProtocol.triggerChildEvent( 'ecUser', qubitUserData );
}

export default function( CONFIG ){
  return function*( ){
    let serviceType = 'user';


    // register events for the request
    registerServiceName( serviceType );

    yield [
      takeEvery( getServiceType( 'session', 'success' ), listener, serviceType, CONFIG ),
      takeEvery( getServiceType( 'user', 'requested' ), listener, serviceType, CONFIG )
    ];
  }
}
