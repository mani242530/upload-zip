/**
* Session  sagas
*/

import {
  takeEvery, call, put, ChannelTakeEffect, take, select
} from 'redux-saga/effects';
import { cloneableGenerator } from 'redux-saga/utils';
import Cookies from 'js-cookie';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import qprotocol from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';
import { fullyQualifyLink, host } from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import { makeGetSwitchesData } from '../../models/view/global/global.model';
import CONFIG from '../../config';
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import getHistory from '../../utils/history/history';

import {
  openSignInModal
} from '../../events/sign_in_modal/sign_in_modal.events';

jest.mock( 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol', () => {
  return { triggerChildEvent:jest.fn() }
} );

import saga, {
  listener,
  triggerQProtocol
} from './user.controller';

const type = 'user';
const sessionID = '44432';
import {
  retrieveReflektionLoginEvent,
  removeReflektionLoginEvent,
  saveStaySignedInFlagForAnalytics
} from '../../utils/local_storage/local_storage';
import { authorizeLoad } from '../../events/authorize/authorize.events';
import appConstants from '../../shared/appConstants';

jest.mock( './../../utils/local_storage/local_storage', ()=>{
  return {
    retrieveReflektionLoginEvent:()=> 'fireReflektionLoginEvent',
    removeReflektionLoginEvent:()=>{},
    saveStaySignedInFlagForAnalytics:jest.fn()
  }
} );
jest.mock( 'ulta-fed-core/dist/js//utils/formatters/formatters', () => {
  return { fullyQualifyLink:jest.fn() }
} );
import { getExpirationInMilliseconds } from '../../utils/formatters/formatters';
jest.mock( '../../utils/formatters/formatters', () => {
  return {
    getExpirationInMilliseconds:jest.fn( () => {
      return 1557505722757;
    } )
  }
} );
import { saveUserData } from '../../utils/user_storage/user_storage';
jest.mock( '../../utils/user_storage/user_storage', () => {
  return {
    saveUserData:jest.fn()
  }
} );


const history = getHistory();

describe( 'defaultSaga Saga', () => {

  registerServiceName( type );
  registerServiceName( 'profile' );
  registerServiceName( 'reflektionLoginEvent' );
  registerServiceName( 'authorize' );

  describe( 'default saga', () => {

    const userSaga = saga( CONFIG )();

    it( 'should listen for the navigation requested method', () => {

      const takeEveryDescriptor = userSaga.next().value;
      expect( takeEveryDescriptor ).toEqual(
        [
          takeEvery( getServiceType( 'session', 'success' ), listener, type, CONFIG ),
          takeEvery( getServiceType( 'user', 'requested' ), listener, type, CONFIG )
        ]
      );
    } );

  } );

  describe( 'listener saga success path', () => {

    Cookies.set( 'ultaSession', sessionID );
    const listenerSaga = cloneableGenerator( listener )( type, CONFIG, { data: sessionID, invokedFromLogin: false } );

    it( 'should load until the loading event has been put', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );
    } );

    it( 'should yield on requesting data and return that data with a sucess method one', () => {

      const callDescriptor = listenerSaga.next().value;

      const data = {
        type,
        query: {}
      };
      expect( callDescriptor ).toEqual( call( ajax, data ) );

    } );
    const listenerSaga2 = cloneableGenerator( listener )( type, CONFIG, { data: sessionID, invokedFromLogin: true } );
    it( 'should load until the loading event has been put when the environemnt is developement', () => {
      const putDescriptor = listenerSaga2.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method one when the environemnt is developement', () => {
      process.env.NODE_ENV = 'development';
      const callDescriptor = listenerSaga2.next().value;
      const data = {
        type,
        query: {
          __IS_SIGNED_IN : true,
          __IS_EMAIL_OPT_IN : false,
          __IS_REWARDS_MEMBER: true,
          __IS_REWARD_STATUS: 'Member',
          __CART_COUNT : '4',
          __IS_SOFT_LOGIN_USER: CONFIG.DEBUGGING.USER.isSoftLoginUser,
          __IS_STAGING_ENV: CONFIG.DEBUGGING.isStagingEnvironment
        }
      };

      expect( callDescriptor ).toEqual( call( ajax, data ) );

    } );

    let res = {
      meta: {
        previewDate: '2019-05-24'
      },
      data: {
        user: {
          rewardsInfo: {
            pointsBalance: 4411,
            status: 'Member'
          },
          accountInfo: {
            firstName: 'Test First'
          }
        }
      }
    }
    let listenerSagaDevelop;
    let listenerSaga3;
    let listenerSaga4;
    let listenerSaga6;
    let listenerSaga7;
    let listenerSaga8;
    let listenerSagaClone5;
    let listenerSagaClone6;
    let listenerSagaClone7;
    let listenerSagaClone8;
    let listenerSagaClone9;
    let listenerSagaClone10;
    it( 'should put and call for profile on success', () => {
      listenerSagaDevelop = listenerSaga.clone();
      listenerSaga3 = listenerSaga.clone();
      listenerSaga4 = listenerSaga.clone();
      listenerSagaClone6 = listenerSaga.clone();
      listenerSagaClone7 = listenerSaga.clone();
      listenerSagaClone8 = listenerSaga.clone();
      listenerSagaClone9 = listenerSaga.clone();
      listenerSagaClone10 = listenerSaga.clone();
      const putDescriptor = listenerSaga.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'profile', 'requested' )() ) );
      const takeDescriptor = listenerSaga.next().value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'profile', 'success' ) ) );
    } );

    it( 'should put when the environemnt is developement', () => {
      process.env.NODE_ENV = 'development';
      const putDescriptor = listenerSagaDevelop.next( { body: res } ).value;
      // the NODE_ENV variable needs to be reset to it original value i.e.test or else it will affect other test cases.
      // resetting it before the 'expect' so that the value will be reset even in those case where expect fails
      process.env.NODE_ENV = 'test';
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'profile', 'requested' )() ) );
    } );

    it( 'should put a success event after data is called', () => {
      listenerSaga6 = listenerSaga.clone();
      listenerSaga7 = listenerSaga.clone();
      listenerSaga8 = listenerSaga.clone();
      listenerSagaClone5 = listenerSaga.clone();
      const putDescriptor = listenerSaga.next( { body: res } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( {
        ...res.data,
        meta:res.meta
      } ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );
      expect( () => {
        listenerSaga.next();
      } ).toThrow();

    } );

    const listenerSaga1 = listener( type, CONFIG, {
      data: {
        sessionID,
        invokedFromLogin: true
      }
    } );

    it( 'should should until the loading event has been put', () => {
      const CONFIG = {
        DEBUGGING: {
          CART: {
            cartQty: 5,
            isRewardsMember: true
          },
          USER: {
            isSignedIn: true
          }
        }
      };

      const putDescriptor = listenerSaga1.next( process, CONFIG ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {
      global._DEBUG_TIMEOUT = true;
      const callDescriptor = listenerSaga1.next( global ).value;
      const data = {
        type,
        query: {}
      };
      expect( callDescriptor ).toEqual( call( ajax, data ) );

    } );

    let res1 = {
      data: {
        cart: {
          itemCount: 0
        },
        user: {
          rewardsInfo: {
            pointRedeemValue: 111,
            pointsBalance: 4411,
            pointRedeem: 3330,
            status: 'Member'
          },
          accountInfo: {
            lastName: 'Test Last',
            firstName: 'Test First',
            email: 'testuser@ulta.com',
            rewardsMember: false,
            emailOptIn: false,
            dateOfBirth: '04/30'
          }
        }
      }
    };
    it( 'should put a profile request event', () => {
      const putDescriptor = listenerSaga1.next( { body: res1 } ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'profile', 'requested' )() ) );
    } );

    it( 'should take a profile success event', () => {
      const putDescriptor = listenerSaga1.next().value;
      expect( putDescriptor ).toEqual( take( getServiceType( 'profile', 'success' ) ) );
    } );

    it( 'should put a user success event', () => {
      let profileData = {
        data: {
          rewardsInfo:{
            memberNumber:'12346',
            planId: 'profileDataPlanId',
            memberSince: '04/06/2014',
            platinum: false
          },
          profileInfo: {
            beautyClubPlanType:{ planDesc: 'test platinumMemberType' }
          },
          pointsBalance: 4411
        }
      };
      const putDescriptor = listenerSaga1.next( profileData ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( {
        ...res1.data,
        meta:res1.meta
      } ) ) );
    } );

    it( 'should put authorizeLoad action to check user is allowed to load the page', () => {
      const putDescriptor = listenerSaga1.next().value;
      expect( putDescriptor ).toEqual( put( authorizeLoad( { url:global.location.pathname, search: global.location.search } ) ) );
    } );

    it( 'should wait for authorize success to continue loading the page', () => {
      const takeDescriptor = listenerSaga1.next().value;
      expect( takeDescriptor ).toEqual( take( getServiceType( 'authorize', 'success' ) ) );
    } );

    it( 'should put a success event after data is called and set proper values for rewards in dataLayer', () => {
      const globalPageData = {
        'rewards': {
          'pointsToRedeem': 3330,
          'loyaltyId': '789101'
        }
      };
      global.globalPageData = globalPageData;

      const dataLayer = {
        'globalPageData': {
          'rewards': {
            'clubPoints': 4411,
            'loyaltyId': '12346',
            'memberSince': '04/06/2014',
            'platinumMember': 'false',
            'platinumMemberType': 'test platinummembertype',
            'programId': 'profileDataPlanId',
            'userType': 'reg - loyalty member',
            'pointsToRedeem': 3330
          }
        }
      }
      let evt = {
        'name': appConstants.ANALYTICS.REWARDS_DATA_READY
      }
      const putDescriptor = listenerSaga1.next( ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( dataLayer, evt ) ) );

    } );

    it( 'Should call triggerQprotocol, if memberNumber is present in profile API response', () => {

      let profileData = {
        data:{
          rewardsInfo:{
            memberNumber:'D123'
          }
        }
      };

      let response = {
        data: {
          user: {
            rewardsInfo: {
              pointsBalance: 4411,
              status: 'Member'
            },
            accountInfo: {
              firstName: 'Test First'
            }
          }
        }
      };
      // Response data from User service call
      listenerSaga3.next( { body: response } );
      listenerSaga3.next();
      // Profile data from Profile service call
      listenerSaga3.next( profileData );
      listenerSaga3.next();
      listenerSaga3.next();
      listenerSaga3.next(); // put( getActionDefinition( type, 'success' )( res.body.data ) )
      listenerSaga3.next(); // put( authorizeLoad( global.location.pathname ) )
      let qubitUserData = {
        user:{
          id:'D123',
          loyalty: {
            tier : 'Member',
            tierPoints: 4411
          }
        }
      }
      expect( qprotocol.triggerChildEvent ).toHaveBeenCalledWith( 'ecUser', qubitUserData );
    } );

    it( 'Should Not call triggerQProtocol, if memberNumber is not present in profile API response ', () => {
      // Should reset mock function as it was previously called
      qprotocol.triggerChildEvent.mockClear();
      let profileData = {
        data:{
          rewardsInfo:{
            memberNumber:null
          }
        }
      };
      let response = {
        data: {
          user: {
            rewardsInfo: {
              pointsBalance: 4411,
              status: 'Member'
            },
            accountInfo: {
              firstName: 'Test Last'
            }
          }
        }
      };
      // Response data from User service call
      listenerSaga4.next( { body: response } ).value;
      listenerSaga4.next();
      // Profile data with rewardsInfo.memberNumber as null from Profile service call
      listenerSaga4.next( profileData );
      expect( qprotocol.triggerChildEvent ).not.toBeCalled();
    } );

    it( 'should do a select on makeGetSwitchesData', () => {
      const selectDescriptor = listenerSaga1.next().value;
      expect( JSON.stringify( selectDescriptor ) ).toEqual( JSON.stringify( select( makeGetSwitchesData() ) ) );
    } );

    it( 'should put a reflektionLoginEvent requested event', () => {
      const switchData = {
        switches:{
          enableRfkEvents:true
        }
      }
      const putDescriptor = listenerSaga1.next( switchData ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'reflektionLoginEvent', 'requested' )() ) );
    } );
    it( 'should not call reflektionLoginEvent requested event when enableRfkEvents is false', () => {
      const switchData = {
        switches:{
          enableRfkEvents:false
        }
      }
      const profileData = {
        data: {
          rewardsInfo:{
            memberNumber:'12346',
            planId: 'profileDataPlanId',
            memberSince: '04/06/2014',
            platinum: false
          },
          profileInfo: {
            beautyClubPlanType:{ planDesc: 'test platinumMemberType' }
          },
          pointsBalance: 4411
        }
      };

      listenerSagaClone5.next( profileData ); // user success yeild
      listenerSagaClone5.next();// put( getActionDefinition( type, 'success' )( res.body.data ) )
      listenerSagaClone5.next(); // put( authorizeLoad( global.location.pathname ) )
      listenerSagaClone5.next(); // setDataLayer yield for analytics
      listenerSagaClone5.next(); // makeGetSwitchesData select yield
      expect( listenerSagaClone5.next( switchData ).done ).toEqual( true );
    } );
    it( 'Should set platinumMemberType as empty in the datalayer if planDesc element is not present in the response', () => {
      const profileData = {
        data: {
          rewardsInfo:{
            memberNumber:'12346',
            planId: 'profileDataPlanId',
            memberSince: '04/06/2014',
            platinum: false
          },
          profileInfo: {
            beautyClubPlanType:{ }
          },
          pointsBalance: 4411
        }
      };
      listenerSaga6.next( profileData ); // user success yeild
      const dataLayer = {
        'globalPageData': {
          'rewards': {
            'clubPoints': 4411,
            'loyaltyId': '12346',
            'memberSince': '04/06/2014',
            'platinumMember': 'false',
            'platinumMemberType': '',
            'programId': 'profileDataPlanId',
            'userType': 'reg - non-loyalty member',
            'pointsToRedeem': 3330
          }
        }
      }
      let evt = {
        'name': appConstants.ANALYTICS.REWARDS_DATA_READY
      }
      listenerSaga6.next();
      listenerSaga6.next();
      const putDescriptor = listenerSaga6.next( ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( dataLayer, evt ) ) );
    } );
    it( 'Should set platinumMemberType as empty in the datalayer if planDesc element value as undefined in the profile response', () => {
      const profileData = {
        data: {
          rewardsInfo:{
            memberNumber:'12346',
            planId: 'profileDataPlanId',
            memberSince: '04/06/2014',
            platinum: false
          },
          profileInfo: {
            beautyClubPlanType:{ planDesc: undefined }
          },
          pointsBalance: 4411
        }
      };
      listenerSaga7.next( profileData ); // user success yeild
      const dataLayer = {
        'globalPageData': {
          'rewards': {
            'clubPoints': 4411,
            'loyaltyId': '12346',
            'memberSince': '04/06/2014',
            'platinumMember': 'false',
            'platinumMemberType': '',
            'programId': 'profileDataPlanId',
            'userType': 'reg - non-loyalty member',
            'pointsToRedeem': 3330
          }
        }
      }
      let evt = {
        'name': appConstants.ANALYTICS.REWARDS_DATA_READY
      }
      listenerSaga7.next();
      listenerSaga7.next();
      const putDescriptor = listenerSaga7.next( ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( dataLayer, evt ) ) );
    } );
    it( 'Should set platinumMemberType as empty in the datalayer if planDesc element value as empty in the profile response', () => {
      const profileData = {
        data: {
          rewardsInfo:{
            memberNumber:'12346',
            planId: 'profileDataPlanId',
            memberSince: '04/06/2014',
            platinum: false
          },
          profileInfo: {
            beautyClubPlanType:{ planDesc: '' }
          },
          pointsBalance: 4411
        }
      };
      listenerSaga8.next( profileData ); // user success yeild
      const dataLayer = {
        'globalPageData': {
          'rewards': {
            'clubPoints': 4411,
            'loyaltyId': '12346',
            'memberSince': '04/06/2014',
            'platinumMember': 'false',
            'platinumMemberType': '',
            'programId': 'profileDataPlanId',
            'userType': 'reg - non-loyalty member',
            'pointsToRedeem': 3330
          }
        }
      }
      let evt = {
        'name': appConstants.ANALYTICS.REWARDS_DATA_READY
      }
      listenerSaga8.next();
      listenerSaga8.next();
      const putDescriptor = listenerSaga8.next( ).value;
      expect( putDescriptor ).toEqual( put( setDataLayer( dataLayer, evt ) ) );
    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      let err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga1.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

    it( 'should NOT call openSignInModal if user accountInfo has firstName and any search param if present should not be deleted', () => {

      let response = {
        data: {
          user: {
            rewardsInfo: {
              pointsBalance: 4411,
              status: 'Member'
            },
            accountInfo: {
              firstName: 'Test First'
            }
          }
        }
      };

      const profileData = {
        data: {
          rewardsInfo:{
            memberNumber:'12346',
            planId: 'profileDataPlanId',
            memberSince: '04/06/2014',
            platinum: true
          },
          profileInfo: {
            beautyClubPlanType:{ planDesc: undefined }
          },
          pointsBalance: 4411
        }
      };

      const dataLayer = {
        'globalPageData': {
          'rewards': {
            'clubPoints': 4411,
            'platinumMemberType':'',
            'userType': 'reg - non-loyalty member',
            'loyaltyId': '12346',
            'memberSince': '04/06/2014',
            'platinumMember': 'true',
            'programId': 'profileDataPlanId',
            'pointsToRedeem': 3330
          }
        }
      }

      const evt = {
        'name': appConstants.ANALYTICS.REWARDS_DATA_READY
      }
      history.location.search = '?forceLogin=true&sample=true&test=1';
      listenerSagaClone7.next( { body: response } ); // calls yield take( getServiceType( 'user', 'success' ) );
      listenerSagaClone7.next();

      const putDescriptor1 = listenerSagaClone7.next( profileData ).value; // calls yield take( getServiceType( 'profile', 'success' ) );
      expect( putDescriptor1 ).toEqual( put( getActionDefinition( type, 'success' )( {
        ...response.data,
        meta:response.meta
      } ) ) );

      listenerSagaClone7.next(); // put( getActionDefinition( type, 'success' )( res.body.data ) )
      listenerSagaClone7.next(); // put( authorizeLoad( global.location.pathname ) )
      const putDescriptor2 = listenerSagaClone7.next().value; // calls yield put( setDataLayer( dataLayer ) );
      expect( putDescriptor2 ).toEqual( put( setDataLayer( dataLayer, evt ) ) );

      expect( history.location.search ).toBe( '?forceLogin=true&sample=true&test=1' );
    } );

    it( 'should call openSignInModal if user accountInfo does not have firstName and url param forceLogin is true and also remove url param forceLogin from url for anonymous user after calling openSignInModal', () => {
      history.replace = jest.fn();
      let response = {
        data: {
          user: {
            rewardsInfo: {
              pointsBalance: 4411,
              status: 'Member'
            },
            accountInfo: {
            }
          }
        }
      };
      history.location.search = '?forceLogin=true';
      listenerSagaClone8.next( { body: response } ); // calls yield take( getServiceType( 'user', 'success' ) );
      listenerSagaClone8.next(); // authorize_url
      listenerSagaClone8.next(); // take( authorizesuccess )
      const putDescriptor = listenerSagaClone8.next().value;
      expect( putDescriptor ).toEqual( put( openSignInModal( { sourcePage: 'logout' } ) ) );
      listenerSagaClone8.next(); // history.replace
      expect( history.replace ).toHaveBeenCalledWith( '/' );
    } );

    it( 'should call openSignInModal if user accountInfo does not have firstName and url param forceLogin is true and also remove url param forceLogin and keep other search params if any in url for anonymous user after calling openSignInModal', () => {

      history.replace = jest.fn();
      let response = {
        data: {
          user: {
            rewardsInfo: {
              pointsBalance: 4411,
              status: 'Member'
            },
            accountInfo: {
            }
          }
        }
      };
      history.location.search = '?forceLogin=true&test=1';
      listenerSagaClone6.next( { body: response } ); // calls yield take( getServiceType( 'profile', 'success' ) );
      listenerSagaClone6.next(); // put( getActionDefinition( type, 'success' )( res.body.data ) )
      listenerSagaClone6.next(); // put( authorizeLoad( global.location.pathname ) )
      const putDescriptor = listenerSagaClone6.next().value;
      expect( putDescriptor ).toEqual( put( openSignInModal( { sourcePage: 'logout' } ) ) );
      listenerSagaClone6.next(); // calls yield put( setDataLayer( dataLayer ) );
      expect( history.replace ).toHaveBeenCalledWith( '/?test=1' );
    } );

    it( 'should redirect to account page if a logged in user search url contains forceLogin and source=account params', () => {

      let response = {
        data: {
          user: {
            rewardsInfo: {
              pointsBalance: 4411,
              status: 'Member'
            },
            accountInfo: {
              firstName: 'Test First Name'
            }
          }
        }
      };

      history.location.search = '?forceLogin=true&source=account';
      listenerSagaClone9.next( { body: response } ); // take( getServiceType( 'user', 'success' ) );
      listenerSagaClone9.next(); // put( getActionDefinition( 'profile', 'requested' )() )
      listenerSagaClone9.next(); // take( getServiceType( 'profile', 'success' ) );
      listenerSagaClone9.next(); // put( getActionDefinition( type, 'success' )( res.body.data ) )
      listenerSagaClone9.next(); // put( authorizeLoad( global.location.pathname ) )
      listenerSagaClone9.next(); // calls yield put( setDataLayer( dataLayer ) );

      expect( fullyQualifyLink ).toHaveBeenCalledWith( host, appConstants.ROUTES.ACCOUNT_PAGE );

    } );

    it( 'should call saveUserData with key as staySignedIn and value as value as rememberMeMaxAge in milliseconds, if response has first name and user is a SoftLoginUser', () => {

      let response = {
        data: {
          user: {
            rewardsInfo: {
              pointsBalance: 4411,
              status: 'Member'
            },
            accountInfo: {
              firstName: 'Test First Name'
            },
            isSoftLoginUser: true
          }
        }
      };
      let profileData = {
        data:{
          rewardsInfo:{
            memberNumber:null
          }
        }
      };
      const switchData = {
        switches:{
          enableRfkEvents:true,
          rememberMeMaxAge: 30000
        }
      }


      listenerSagaClone10.next( { body: response } ); // take( getServiceType( 'user', 'success' ) );
      listenerSagaClone10.next(); // put( getActionDefinition( 'profile', 'requested' )() )
      listenerSagaClone10.next( profileData ); // take( getServiceType( 'profile', 'success' ) );
      listenerSagaClone10.next(); // put( getActionDefinition( type, 'success' )( res.body.data ) )
      listenerSagaClone10.next(); // put( authorizeLoad( global.location.pathname ) )
      listenerSagaClone10.next(); // calls yield put( setDataLayer( dataLayer ) );
      listenerSagaClone10.next(); // makeGetSwitchesData select yield

      const putDescriptor = listenerSagaClone10.next( switchData ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( 'reflektionLoginEvent', 'requested' )() ) );

      const expectedData = getExpirationInMilliseconds( switchData.switches.rememberMeMaxAge );
      expect( saveUserData ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, expectedData );

    } );


  } );
} );
