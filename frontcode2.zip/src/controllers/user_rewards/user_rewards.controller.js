
import {
  takeEvery, take, call, put
} from 'redux-saga/effects';
import isUndefined from 'lodash/isUndefined';
import has from 'lodash/has';


import {
  types,
  actions,
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';


import { getRoute } from 'ulta-fed-core/dist/js/utils/omniture/omniture'
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import ProfileSaga from '../profile/profile.controller';

// Individual exports for testing
export const listener = function*( type, data ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );

    const res = yield call( ajax,
      {
        type,
        method:'post'
      } );

    // Analytics tracking
    // Check if a rewards account was created and if so then update the data layer
    // and dispatch and event to show the account was created.
    if( !isUndefined( res.body ) && has( res.body, 'isRewardsMember' ) ){

      // Only dispatch an event if the account was created.
      if( res.body.isRewardsMember ){
        const data = {
          'globalPageData': {
            'action': {
              'loyaltyCreated': ( res.body.isRewardsMember === true ? 'true' : 'false' )
            },
            'navigation': {
              'location': ( getRoute( 'checkout' ) ? 'checkout' : global.location.pathname.replace( /\.[^\.\/]+$/, '' ).substr( 1 ) )
            }
          }
        };

        const evt = {
          'name': 'loyaltyCreated'
        };

        yield put( setDataLayer( data, evt ) );
      }
    }
    // End analytics

    yield put( getActionDefinition( type, 'success' )( res.body ) );


  }
  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) );
  }
}

export default function*(){
  let serviceType = 'userRewards';


  // register events for the request
  registerServiceName( serviceType );

  yield takeEvery( getServiceType( 'userRewards', 'requested' ), listener, serviceType );
}
