
/**
 * UserRewards  sagas
 */

import { takeEvery, call, put } from 'redux-saga/effects';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  triggerAnalyticsEvent
} from 'ulta-fed-core/dist/js/events/analytics/analytics.events';

import { getRoute } from 'ulta-fed-core/dist/js/utils/omniture/omniture'
import {
  ajax
} from '../../utils/ajax/ajax';

import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

import saga, { listener } from './user_rewards.controller';

const type = 'userRewards';

registerServiceName( type );

describe( 'UserRewards Saga', () => {
  describe( 'UserRewards saga', () =>{

    const UserRewardsSaga = saga();

    it( 'should listen for the userRewards requested method', () =>{

      const takeLatestDescriptor = UserRewardsSaga.next().value;

      expect( takeLatestDescriptor ).toEqual( takeEvery( getServiceType( type, 'requested' ), listener, type ) );
    } );

  } );
  describe( 'listener saga success/failure path', () => {

    const res = {
      body: {
        isRewardsMember : true
      }
    };

    const listenerSaga = listener( type );

    it( 'should put the loading event', () => {

      const putDescriptor = listenerSaga.next().value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'loading' )() ) );

    } );

    it( 'should yield on requesting data and return that data with a sucess method', () => {

      const callDescriptor = listenerSaga.next().value;

      expect( callDescriptor ).toEqual( call( ajax, { type, method: 'post' } ) );

    } );

    it( 'should put setDataLayer action', () => {

      const evt = {
        name: 'loyaltyCreated'
      };
      const data = {
        globalPageData: {
          action: {
            loyaltyCreated: ( res.body.isRewardsMember === true ? 'true' : 'false' )
          },
          'navigation': {
            'location': ( getRoute( 'checkout' ) ? 'checkout' : global.location.pathname.replace( /\.[^\.\/]+$/, '' ).substr( 1 ) )
          }
        }
      };
      const putDescriptor = listenerSaga.next( res ).value;

      expect( putDescriptor ).toEqual(
        put( setDataLayer( data, evt ) )
      );

    } );

    it( 'should put a success event after data is called', () => {

      const putDescriptor = listenerSaga.next( res ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'success' )( res.body ) ) );

    } );

    it( 'should put a failure event if no data is returned from the service', () => {
      const err = {
        statusText: 'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err ).value;

      expect( putDescriptor ).toEqual( put( getActionDefinition( type, 'failure' )( err ) ) );

    } );

  } );
} );
