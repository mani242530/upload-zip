import {
  takeLatest,
  call,
  put,
  cancel
} from 'redux-saga/effects';
import {
  pageRedirect,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { ajax } from '../../utils/ajax/ajax';
import {
  setDataLayer
} from '../../events/data_layer/data_layer.events';

export const updateDataLayer = function*( res ){
  const data = {
    'globalPageData': {
      'messages': {
        message: res.body.data.messages.items,
        type:'error'
      }
    }
  }
  const evt = {
    'name': 'serviceMessagesUpdated'
  }
  yield put( setDataLayer( data, evt ) );
}


export const validateAndResetPassword = function* ( type, action ){
  try {
    yield put( getActionDefinition( type, 'loading' )() );
    // Values to Post
    const postValues = {
      t: action.data.t,
      e: action.data.e,
      password: action.data.password
    }
    const res = yield call(
      ajax, {
        type:'validateAndResetPasswordRequest',
        method:'post',
        values: postValues
      }
    );

    yield put( getActionDefinition( type, 'success' )( res.body.data ) );
    if( res.body.data.success ){
      let homepage = '/';
      let loginPage = '/ulta/myaccount/login.jsp';
      const {
        pathname
      } = action.data.history.location;
      // Redirect to home page after successful password reset and login success
      if( res.body.data.loginSuccess ){
        yield put( pageRedirect( pathname, homepage ) );
        global.location.href = homepage;
        yield cancel();
      }
      // Redirect to login page if login fails after successfull password reset
      else {
        yield put( pageRedirect( pathname, loginPage ) );
        global.location.href = loginPage;
        yield cancel();

      }
    }
    else {
      yield call( updateDataLayer, res );
    }
  }

  catch ( err ){
    yield put( getActionDefinition( type, 'failure' )( err ) )
    if( window.TRACK_SAGA_FAILURES ){
      console.error( err.message ); //eslint-disable-line
    }
  }

}


export default function*(){
  const serviceType = 'validateAndResetPassword';
  registerServiceName( serviceType );
  yield takeLatest( getServiceType( serviceType, 'requested' ), validateAndResetPassword, serviceType )
}
