import {
  call,
  put,
  take,
  takeLatest
} from 'redux-saga/effects';
import {
  pageRedirect,
  registerServiceName,
  getActionDefinition,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { cloneableGenerator } from 'redux-saga/utils';
import { ajax } from '../../utils/ajax/ajax';

import saga, {
  validateAndResetPassword,
  updateDataLayer
} from './validate_and_reset_password.controller'

const serviceType = 'validateAndResetPassword';
const action = {
  data:{
    t: 'Dummy_Token',
    e: 'Dummy_Email',
    password: 'Dummy_Password',
    history: {
      location: {
        pathname: '/forgot-password'
      }
    }
  }
}
const listenerSaga = cloneableGenerator( validateAndResetPassword )( serviceType, action );
let listenerSagaResponseSuccess;
let listenerSagaResponseFailure;

describe( 'validateAndResetPassword saga', () => {
  const coreSaga = saga();
  registerServiceName( serviceType )

  it( 'should take latest validateAndResetPassword reset request', () => {
    const takeLatestDescriptor = coreSaga.next().value;
    expect( takeLatestDescriptor ).toEqual( takeLatest( getServiceType( serviceType, 'requested' ), validateAndResetPassword, serviceType ) )
  } )

  describe( 'ValidateAndResetPassword saga success path', () => {

    const values = {
      t: 'Dummy_Token',
      e: 'Dummy_Email',
      password: 'Dummy_Password'
    }

    it( 'should until the loading event has been put', () => {
      const putDescriptor = listenerSaga.next( values ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'loading' )() ) );
    } );


    it( 'should yield on requesting data and return that data with a success method', () => {
      const callDescriptor = listenerSaga.next().value;
      expect( callDescriptor ).toEqual( call( ajax, { type:'validateAndResetPasswordRequest', method:'post', values } ) );
    } );

    it( 'should put a success event after data is called', () => {
      const resFailure = {
        body: {
          data:{
            success:false,
            loginSuccess:false,
            messages: {
              items:[
                {
                  type:'error',
                  message:'Failed to raise reset password request.'
                }
              ]
            }
          }
        }
      };
      listenerSagaResponseSuccess = listenerSaga.clone();
      listenerSagaResponseFailure = listenerSaga.clone();
      const putDescriptor = listenerSagaResponseFailure.next( resFailure ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'success' )( resFailure.body.data ) ) );
    } );

    it( 'should redirect to homepage on passsword reset success', () => {
      let resSuccess = {
        body: {
          data:{
            success:true,
            loginSuccess:true,
            messages: null
          }
        }
      };
      let putDescriptor = listenerSagaResponseSuccess.next( resSuccess ).value;
      putDescriptor = listenerSagaResponseSuccess.next( resSuccess ).value;
      expect( putDescriptor ).toEqual( put( pageRedirect(
        action.data.history.location.pathname, '/'
      ) ) );
    } );

    it( 'should redirect to homepage on passsword reset success and loginSuccess failure', () => {
      let resSuccess = {
        body: {
          data:{
            success:true,
            loginSuccess:false,
            messages: null
          }
        }
      };
      listenerSagaResponseSuccess = listenerSaga.clone();
      let putDescriptor = listenerSagaResponseSuccess.next( resSuccess ).value;
      putDescriptor = listenerSagaResponseSuccess.next( resSuccess ).value;
      expect( putDescriptor ).toEqual( put( pageRedirect(
        action.data.history.location.pathname, '/ulta/myaccount/login.jsp'
      ) ) );
    } );

    it( 'should put a setDataLayer action', () => {
      const res = {
        body: {
          data:{
            success:false,
            loginSuccess:false,
            messages: {
              items:[
                {
                  type:'error',
                  message:'Failed to raise reset password request.'
                }
              ]
            }
          }
        }
      };
      const data = {
        'globalPageData': {
          'messages': {
            message: res.body.data.messages.items,
            type:'error'
          }
        }
      }
      const evt = {
        'name': 'serviceMessagesUpdated'
      }
      const putDescriptor = listenerSagaResponseFailure.next( ).value;
      expect( putDescriptor ).toEqual( call( updateDataLayer, res ) );
    } );

  } );

  describe( 'ValidateAndResetPassword saga failure path', () => {

    it( 'should put a failure event if no data is returned from the service', () => {
      window.TRACK_SAGA_FAILURES = true;
      const err = {
        statusText:'some failure message'
      }
      const putDescriptor = listenerSaga.throw( err, window ).value;
      expect( putDescriptor ).toEqual( put( getActionDefinition( serviceType, 'failure' )( err ) ) );
    } );

  } );
} )
