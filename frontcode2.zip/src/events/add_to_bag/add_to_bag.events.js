
/**
 * Footer Actions
 *
 * This file defines the action types and action creators for add to bag modal
 **/


/**
 * ACTION TYPES
 */
export const CLOSE_ADD_BAG_MODAL = 'ADD_BAG::CLOSE_MODAL';


/**
 * ACTIONS
 */
export const closeAddToBagModal = () => ( { type: CLOSE_ADD_BAG_MODAL } );
