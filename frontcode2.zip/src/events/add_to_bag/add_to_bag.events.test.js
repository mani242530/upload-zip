
import _ from 'lodash';
import * as events from './add_to_bag.events';


describe( 'AddToBag action types', () => {
  it( 'expect all types to be defined', () => {
    expect( events.CLOSE_ADD_BAG_MODAL ).toBe( 'ADD_BAG::CLOSE_MODAL' );
  } );
} );

describe( 'AddToBag actions', () => {

  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.closeAddToBagModal ) ).toBe( true );
  } );

  it( 'should create the proper action for closeAddToBagModal', () => {
    let creator = events.closeAddToBagModal();
    expect( creator ).toEqual( {
      type: events.CLOSE_ADD_BAG_MODAL
    } )
  } );

} );
