/**
 * Afterpay Actions
 *
 * This file defines the action types and action creators for 'Afterpay'
 **/


/**
 * ACTION TYPES
 */

export const RESET_UPDATE_AFTER_PAY_WIDGET_FLAG = 'AFTER_PAY::RESET_UPDATE_AFTER_PAY_WIDGET_FLAG';

/**
   * ACTIONS
   */

export const resetUpdateAfterpayWidgetFlag = () => ( { type: RESET_UPDATE_AFTER_PAY_WIDGET_FLAG } );
