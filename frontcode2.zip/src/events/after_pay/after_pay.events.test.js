/**
 * Test for After Pay actions
 */

import isFunction from 'lodash/isFunction';
import * as events from './after_pay.events';


describe( 'AfterPay actions/types', () => {

  describe( 'resetUpdateAfterPayWidgetFlagy', () => {

    it( 'The action type should exist', () => {
      expect( events.RESET_UPDATE_AFTER_PAY_WIDGET_FLAG ).toBe( 'AFTER_PAY::RESET_UPDATE_AFTER_PAY_WIDGET_FLAG' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.resetUpdateAfterpayWidgetFlag ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.resetUpdateAfterpayWidgetFlag();
      expect( creator ).toEqual( { type: events.RESET_UPDATE_AFTER_PAY_WIDGET_FLAG } )
    } );
  } );
} );
