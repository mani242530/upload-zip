

/**
 * ACTION TYPES
 */
export const AUTHORIZE_URL = 'AUTHORIZE_URL';
/**
 * ACTIONS
 */
export const authorizeReplace = ( url, route, state ) => ( {
  type:'AUTHORIZE_URL',
  data:{
    action:'replace',
    url,
    route,
    state
  }
} );

export const authorizePush = ( url, route, state ) => ( {
  type:'AUTHORIZE_URL',
  data:{
    action:'push',
    url,
    route,
    state
  }
} );

export const authorizeLoad = ( data ) => ( {
  type:'AUTHORIZE_URL',
  data:{
    action:'load',
    url:data.url,
    search:data.search,
    forceAuthorize:data.forceAuthorize
  }
} );

export const authorizePageLoad = ( data ) => ( {
  type:'AUTHORIZE_URL',
  data:{
    action:'pageLoad',
    url:data.url,
    search:data.search
  }
} );
