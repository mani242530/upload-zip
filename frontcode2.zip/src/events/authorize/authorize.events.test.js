import isFunction from 'lodash/isFunction';
import * as events from './authorize.events';

describe( 'Authorize action types', () => {
  it( 'should define all actions types', () => {
    expect( events.AUTHORIZE_URL ).toBe( 'AUTHORIZE_URL' );
  } );
} );

describe( 'Authorize Actions', () => {
  const url = 'testUrl';
  const route = 'testRoute';
  const state = { key:'value' };

  it( 'should have authorizeReplace action creaters to be defined', () => {
    expect( isFunction( events.authorizeReplace ) ).toBe( true );
  } );

  it( 'should return proper action creator object from authorizeReplace', () => {
    const actionCreator = events.authorizeReplace( url, route, state );
    expect( actionCreator ).toEqual( {
      type: events.AUTHORIZE_URL,
      data:{
        action:'replace',
        url,
        route,
        state
      }
    } );
  } );

  it( 'should have authorizePush action creaters to be defined', () => {
    expect( isFunction( events.authorizePush ) ).toBe( true );
  } );

  it( 'should return proper action creator object from authorizePush', () => {
    const actionCreator = events.authorizePush( url, route, state );
    expect( actionCreator ).toEqual( {
      type: events.AUTHORIZE_URL,
      data:{
        action:'push',
        url,
        route,
        state
      }
    } );
  } );

  it( 'should have authorizePageLoad action creaters to be defined', () => {
    expect( isFunction( events.authorizePageLoad ) ).toBe( true );
  } );

  it( 'should return proper action creator object from authorizePageLoad', () => {
    const data = {
      url: 'test URL',
      search: 'testSearchTerm'
    }
    const actionCreator = events.authorizePageLoad( data );
    expect( actionCreator ).toEqual( {
      type: events.AUTHORIZE_URL,
      data:{
        action:'pageLoad',
        url:data.url,
        search:data.search
      }
    } );
  } );

  it( 'should have authorizeReplace action creaters to be defined', () => {
    expect( isFunction( events.authorizeLoad ) ).toBe( true );
  } );

  it( 'should return proper action creator object from authorizeReplace', () => {
    const data = {
      url: 'test URL',
      search: '/bag',
      forceAuthorize: true
    }
    const actionCreator = events.authorizeLoad( data );
    expect( actionCreator ).toEqual( {
      type: events.AUTHORIZE_URL,
      data:{
        action:'load',
        url:data.url,
        search:data.search,
        forceAuthorize:data.forceAuthorize
      }
    } );
  } );
} );
