/**
 * BOPIS Actions
 *
 * This file defines the action types and action creators for 'BOPIS'
 **/


/**
 * ACTION TYPES
 */
export const TOGGLE_BOPIS_CONTACT_FORM_DISPLAY = 'BOPIS::TOGGLE_BOPIS_CONTACT_FORM_DISPLAY';
export const SET_DELIVERY_OPTIONS = 'BOPIS::SET_DELIVERY_OPTIONS';


/**
 * ACTIONS
 */
export const toggleBopisContactFormDisplay = ( data ) => ( { type: TOGGLE_BOPIS_CONTACT_FORM_DISPLAY, data } );
export const setDeliveryOptions = ( data, history ) => ( { type: SET_DELIVERY_OPTIONS, data, history } );
