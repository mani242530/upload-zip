/**
 * Test for Bopis actions
 */

import isFunction from 'lodash/isFunction';
import * as events from './bopis.events';


describe( 'Bopis actions/types', () => {

  describe( 'toggle Bopis Contact Form Display', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_BOPIS_CONTACT_FORM_DISPLAY ).toBe( 'BOPIS::TOGGLE_BOPIS_CONTACT_FORM_DISPLAY' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.toggleBopisContactFormDisplay ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = true;
      const creator = events.toggleBopisContactFormDisplay( data );
      expect( creator ).toEqual( {
        type: events.TOGGLE_BOPIS_CONTACT_FORM_DISPLAY,
        data
      } )
    } );
  } );

  describe( 'set delivery options', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_DELIVERY_OPTIONS ).toBe( 'BOPIS::SET_DELIVERY_OPTIONS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.setDeliveryOptions ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = 'ship';
      const history = {};
      const creator = events.setDeliveryOptions( data, history );
      expect( creator ).toEqual( {
        type: events.SET_DELIVERY_OPTIONS,
        data,
        history
      } )
    } );

  } );

} );
