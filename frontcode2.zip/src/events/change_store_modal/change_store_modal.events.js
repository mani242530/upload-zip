/**
 * ChangeStoreModal Actions
 *
 * This file defines the action types and action creators for 'ChangeStoreModal'
 **/


/**
 * ACTION TYPES
 */
export const SEARCH_FOCUSED = 'CHANGE_STORE_MODAL::SEARCH_FOCUSED';
export const SEARCH_BUTTON_FOCUSED = 'CHANGE_STORE_MODAL::SEARCH_BUTTON_FOCUSED';
export const SEARCH_UNFOCUSED = 'CHANGE_STORE_MODAL::SEARCH_UNFOCUSED';
export const SEARCH_BUTTON_UNFOCUSED = 'CHANGE_STORE_MODAL::SEARCH_BUTTON_UNFOCUSED';
export const DISPLAY_CHANGE_STORE = 'CHANGE_STORE_MODAL::DISPLAY_CHANGE_STORE';
export const CLOSE_CHANGE_STORE_MODAL = 'CHANGE_STORE_MODAL::CLOSE_CHANGE_STORE_MODAL';
export const TOGGLE_FILTER_STORE = 'CHANGE_STORE_MODAL::TOGGLE_FILTER_STORE';



/**
 * ACTIONS
 */
export const searchFocused = ( ) => ( { type: SEARCH_FOCUSED } );
export const searchButtonFocused = ( ) => ( { type: SEARCH_BUTTON_FOCUSED } );
export const searchUnfocused = ( data ) => ( { type: SEARCH_UNFOCUSED, data } );
export const searchButtonUnfocused = ( ) => ( { type: SEARCH_BUTTON_UNFOCUSED } );
export const displayChangeStore = () => ( { type: DISPLAY_CHANGE_STORE } );
export const closeChangeStoreModal = () => ( { type: CLOSE_CHANGE_STORE_MODAL } );
export const toggleFilterStore = ( data )=> ( { type: TOGGLE_FILTER_STORE, data } );
