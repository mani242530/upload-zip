/**
 * Test for ChangeStoreModal actions
 */

import isFunction from 'lodash/isFunction';
import * as events from './change_store_modal.events';


describe( 'ChangeStoreModal actions/types', () => {

  describe( 'searchFocused', () => {

    it( 'The action type should exist', () => {
      expect( events.SEARCH_FOCUSED ).toBe( 'CHANGE_STORE_MODAL::SEARCH_FOCUSED' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.searchFocused ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.searchFocused( );
      expect( creator ).toEqual( {
        type: events.SEARCH_FOCUSED
      } )
    } );

  } );

  describe( 'searchUnfocused', () => {

    it( 'The action type should exist', () => {
      expect( events.SEARCH_UNFOCUSED ).toBe( 'CHANGE_STORE_MODAL::SEARCH_UNFOCUSED' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.searchUnfocused ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.searchUnfocused( 'test' );
      expect( creator ).toEqual( {
        type: events.SEARCH_UNFOCUSED,
        data: 'test'
      } )
    } );

  } );

  describe( 'searchButtonFocused', () => {

    it( 'The action type should exist', () => {
      expect( events.SEARCH_BUTTON_FOCUSED ).toBe( 'CHANGE_STORE_MODAL::SEARCH_BUTTON_FOCUSED' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.searchButtonFocused ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.searchButtonFocused( );
      expect( creator ).toEqual( {
        type: events.SEARCH_BUTTON_FOCUSED
      } )
    } );

  } );

  describe( 'searchButtonUnfocused', () => {

    it( 'The action type should exist', () => {
      expect( events.SEARCH_BUTTON_UNFOCUSED ).toBe( 'CHANGE_STORE_MODAL::SEARCH_BUTTON_UNFOCUSED' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.searchButtonUnfocused ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.searchButtonUnfocused( 'test' );
      expect( creator ).toEqual( {
        type: events.SEARCH_BUTTON_UNFOCUSED
      } )
    } );

  } );

  describe( 'displayChangeStore', () => {

    it( 'The action type should exist', () => {
      expect( events.DISPLAY_CHANGE_STORE ).toBe( 'CHANGE_STORE_MODAL::DISPLAY_CHANGE_STORE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.displayChangeStore ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.displayChangeStore();
      expect( creator ).toEqual( {
        type: events.DISPLAY_CHANGE_STORE
      } )
    } );

  } );

  describe( 'closeChangeStoreModal', () => {

    it( 'The action type should exist', () => {
      expect( events.CLOSE_CHANGE_STORE_MODAL ).toBe( 'CHANGE_STORE_MODAL::CLOSE_CHANGE_STORE_MODAL' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.closeChangeStoreModal ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.closeChangeStoreModal();
      expect( creator ).toEqual( {
        type: events.CLOSE_CHANGE_STORE_MODAL
      } )
    } );

  } );

  describe( 'toggleFilterStore', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_FILTER_STORE ).toBe( 'CHANGE_STORE_MODAL::TOGGLE_FILTER_STORE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.toggleFilterStore ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.toggleFilterStore( true );
      expect( creator ).toEqual( {
        type: events.TOGGLE_FILTER_STORE,
        data: true
      } )
    } );

  } );

} );
