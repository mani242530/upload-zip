/**
 * CheckoutPage Actions
 *
 * This file defines the action types and action creators for 'CheckoutPage'
 **/


/**
 * ACTION TYPES
 */
export const SET_EDIT_ADDRESS_DATA = 'CHECKOUT_PAGE::SET_EDIT_ADDRESS_DATA';
export const SET_EDIT_CREDITCARD_DATA = 'CHECKOUT_PAGE::SET_EDIT_CREDITCARD_DATA';
export const UPDATE_STATE_DROPDOWN_VALUE = 'CART_AND_CHECKOUT_APP::UPDATE_STATE_DROPDOWN_VALUE';
export const PAYPAL_RESPONSE = 'CHECKOUT_PAGE::PAYPAL_RESPONSE';
export const UPDATE_PAYMENT_STATUS = 'CHECKOUT_PAGE::UPDATE_PAYMENT_STATUS';
export const SET_PAYMENT_FORM_TYPE = 'CHECKOUT_PAGE::SET_PAYMENT_FORM_TYPE';
export const SET_CREDITCARD_PAYMENT_TYPE = 'CHECKOUT_PAGE::SET_CREDITCARD_PAYMENT_TYPE';
export const SET_TEMP_PAYMENT_CCV_NUMBER = 'CHECKOUT_PAGE::SET_TEMP_PAYMENT_CCV_NUMBER';
export const RESET_CART_MERGED = 'CHECKOUT_PAGE::RESET_CART_MERGED';
export const RESET_CARTPAGE_NAVIGATION = 'CHECKOUT_PAGE::RESET_CARTPAGE_NAVIGATION';
export const RESET_ORDER_STATUS = 'CHECKOUT_PAGE::RESET_ORDER_STATUS';
export const TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY = 'CHECKOUT_PAGE::TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY';
export const SET_IS_COUPON_BUTTON_CLICKED = 'CHECKOUT_PAGE::SET_IS_COUPON_BUTTON_CLICKED';
export const SET_SHOW_DEFAULT_SHIPPING_METHOD = 'CHECKOUT_PAGE::SET_SHOW_DEFAULT_SHIPPING_METHOD';
export const SET_SHIPPING_ADDRESS_VIEW = 'CHECKOUT_PAGE::SET_SHIPPING_ADDRESS_VIEW';
export const SET_DISPLAY_DAV_POPUP = 'CHECKOUT_PAGE::SET_DISPLAY_DAV_POPUP';
export const SET_PAYMENT_INFORMATION_VIEW = 'CHECKOUT_PAGE::SET_PAYMENT_INFORMATION_VIEW';
export const ADD_EDIT_PAYMENT_METHOD = 'CHECKOUT_PAGE::ADD_EDIT_PAYMENT_METHOD';
export const BILLING_ADDRESS_SAME_AS_SHIPPING = 'CHECKOUT_PAGE::BILLING_ADDRESS_SAME_AS_SHIPPING';
export const CHECKOUT_PANEL_COLLAPSE = 'CHECKOUT_PAGE::CHECKOUT_PANEL_COLLAPSE';
export const SET_SHOW_PAYPAL_BUTTON = 'CHECKOUT_PAGE::SET_SHOW_PAYPAL_BUTTON';
export const BILLING_ADDRESS_SAME_AS_CONTACT_INFO = 'CHECKOUT_PAGE::BILLING_ADDRESS_SAME_AS_CONTACT_INFO';
export const RESET_CHECKOUT_DATA_AVAILABLE = 'CHECKOUT_PAGE::RESET_CHECKOUT_DATA_AVAILABLE';
export const TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY = 'CHECKOUT_PAGE::TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY';
export const TOGGLE_OPTIN_FOR_SMS = 'CHECKOUT_PAGE::TOGGLE_OPTIN_FOR_SMS';
export const UPDATE_MOBILE_NUMBER = 'CHECKOUT_PAGE::UPDATE_MOBILE_NUMBER';


/**
   * ACTIONS
   */
export const setEditAddressData = ( data ) => ( { type: SET_EDIT_ADDRESS_DATA, data } );
export const setEditCreditCardData = ( data ) => ( { type: SET_EDIT_CREDITCARD_DATA, data } );
export const updateStateDropdownValue = ( form, value ) => ( { type: UPDATE_STATE_DROPDOWN_VALUE, form, value } );
export const getPaypalResponse = ( info ) => ( { type: PAYPAL_RESPONSE, info } );
export const updatePaymentStatus = ( data ) => ( { type: UPDATE_PAYMENT_STATUS, data } );
export const setPaymentType = ( paymentType ) => ( { type: SET_PAYMENT_FORM_TYPE, paymentType } );
export const setCreditCardPaymentType = ( data ) => ( { type: SET_CREDITCARD_PAYMENT_TYPE, data } );
export const setTempPaymentCCVNumber = ( data ) => ( { type: SET_TEMP_PAYMENT_CCV_NUMBER, data } );
export const resetCartMerge = ( ) => ( { type: RESET_CART_MERGED } );
export const resetCartPageNavigation = ( ) => ( { type: RESET_CARTPAGE_NAVIGATION } );
export const resetOrderStatus = ( ) => ( { type: RESET_ORDER_STATUS } );
export const toggleInputFieldPaymentDisplay = ( ) => ( { type: TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY } );
export const isCouponBtnClicked = ( data ) => ( { type: SET_IS_COUPON_BUTTON_CLICKED, data } );
export const setShowDefaultShippingMethod = ( data ) => ( { type: SET_SHOW_DEFAULT_SHIPPING_METHOD, data } );
export const setShippingAddressView = ( data ) => ( { type: SET_SHIPPING_ADDRESS_VIEW, data } );
export const setDisplayDavPopUp = () =>( { type: SET_DISPLAY_DAV_POPUP } );
export const setPaymentInformationView = ( data ) => ( { type: SET_PAYMENT_INFORMATION_VIEW, data } );
export const addEditPaymentMethod = ( data )=>( { type: ADD_EDIT_PAYMENT_METHOD, data } );
export const setBillingAddressSameAsShipping = ( data )=>( { type: BILLING_ADDRESS_SAME_AS_SHIPPING, data } );
export const setCheckoutPanelCollapse = ( panelID ) => ( { type: CHECKOUT_PANEL_COLLAPSE, panelID } );
export const setShowPaypalButton = () =>( { type: SET_SHOW_PAYPAL_BUTTON } );
export const setBillingAddressSameAsContactInfo = ( data )=>( { type: BILLING_ADDRESS_SAME_AS_CONTACT_INFO, data } );
export const resetCheckoutDataAvailable = ( )=>( { type: RESET_CHECKOUT_DATA_AVAILABLE } );
export const toggleInputFieldShippingDisplay = ( ) => ( { type: TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY } );
export const toggleOptInForSms = ( data ) => ( { type: TOGGLE_OPTIN_FOR_SMS, data } );
export const updateMobileNumber = ( data ) => ( { type: UPDATE_MOBILE_NUMBER, data } );
