/**
 * Test for CheckoutPage actions
 */

import _ from 'lodash';
import * as events from './checkout_page.events';


describe( 'CheckoutPage actions/types', () => {

  describe( 'Edit address data', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_EDIT_ADDRESS_DATA ).toBe( 'CHECKOUT_PAGE::SET_EDIT_ADDRESS_DATA' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setEditAddressData ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = {
        refId : 'checkoutaddress',
        firstName : 'joe',
        lastName:'joe',
        phoneNumber: '1234567876',
        isPrimaryAddress: true,
        isPaypalFlag: true,
        addressData: {
          address1: 'address',
          address2: '',
          city: 'chicago',
          state: 'IL',
          postalCode: 12345
        }
      }

      const creator = events.setEditAddressData( data );
      expect( creator ).toEqual( {
        type: events.SET_EDIT_ADDRESS_DATA,
        data
      } )
    } );
  } );

  describe( 'Edit Creditcard data', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_EDIT_CREDITCARD_DATA ).toBe( 'CHECKOUT_PAGE::SET_EDIT_CREDITCARD_DATA' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setEditCreditCardData ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = {
        nickName: 'Mastercard - 4444',
        creditCardType: 'Mastercard',
        creditCardNumber: '4444',
        expirationMonth: '06',
        expirationYear: '2031',
        firstName: 'Jane',
        lastName: 'Doe',
        phoneNumber: '123-456-7890',
        addressData: {
          address1: '724 Greenwood Circle',
          address2: 'Apt#102',
          city: 'Naperville',
          state: 'IL',
          postalCode: '92476'
        }
      }

      const creator = events.setEditCreditCardData( data );
      expect( creator ).toEqual( {
        type: events.SET_EDIT_CREDITCARD_DATA,
        data
      } )
    } );
  } );

  describe( 'UPDATE_STATE_DROPDOWN_VALUE', () => {

    it( 'The action type should exist', () => {
      expect( events.UPDATE_STATE_DROPDOWN_VALUE ).toBe( 'CART_AND_CHECKOUT_APP::UPDATE_STATE_DROPDOWN_VALUE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.updateStateDropdownValue ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const form = jest.fn();
      const value = jest.fn();
      const creator = events.updateStateDropdownValue( form, value );
      expect( creator ).toEqual( {
        type: events.UPDATE_STATE_DROPDOWN_VALUE,
        form,
        value
      } )
    } );
  } );

  describe( 'get paypal response', () => {

    it( 'The action type should exist', () => {
      expect( events.PAYPAL_RESPONSE ).toBe( 'CHECKOUT_PAGE::PAYPAL_RESPONSE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.getPaypalResponse ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const info = jest.fn();
      const creator = events.getPaypalResponse( info );
      expect( creator ).toEqual( {
        type: events.PAYPAL_RESPONSE,
        info
      } )
    } );
  } );

  describe( 'Update Payment Status', () => {

    it( 'The action type should exist', () => {
      expect( events.UPDATE_PAYMENT_STATUS ).toBe( 'CHECKOUT_PAGE::UPDATE_PAYMENT_STATUS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.updatePaymentStatus ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = 'success';
      const creator = events.updatePaymentStatus( data );
      expect( creator ).toEqual( {
        type: events.UPDATE_PAYMENT_STATUS,
        data
      } )
    } );
  } );

  describe( 'Set Payment Type', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_PAYMENT_FORM_TYPE ).toBe( 'CHECKOUT_PAGE::SET_PAYMENT_FORM_TYPE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setPaymentType ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const paymentType = 'paypal';
      const creator = events.setPaymentType( paymentType );
      expect( creator ).toEqual( {
        type: events.SET_PAYMENT_FORM_TYPE,
        paymentType
      } )
    } );
  } );

  describe( 'Set CreditCard Payment Type', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_CREDITCARD_PAYMENT_TYPE ).toBe( 'CHECKOUT_PAGE::SET_CREDITCARD_PAYMENT_TYPE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setCreditCardPaymentType ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = 'Ultamate Rewards Credit Card';
      const creator = events.setCreditCardPaymentType( data );
      expect( creator ).toEqual( {
        type: events.SET_CREDITCARD_PAYMENT_TYPE,
        data
      } )
    } );
  } );

  describe( 'Set Payment CCV Number', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_TEMP_PAYMENT_CCV_NUMBER ).toBe( 'CHECKOUT_PAGE::SET_TEMP_PAYMENT_CCV_NUMBER' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setTempPaymentCCVNumber ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {

      const data = '111';

      const creator = events.setTempPaymentCCVNumber( data );
      expect( creator ).toEqual( {
        type: events.SET_TEMP_PAYMENT_CCV_NUMBER,
        data
      } )
    } );
  } );

  describe( 'Reset Cart Merge', () => {

    it( 'The action type should exist', () => {
      expect( events.RESET_CART_MERGED ).toBe( 'CHECKOUT_PAGE::RESET_CART_MERGED' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.resetCartMerge ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.resetCartMerge( );
      expect( creator ).toEqual( {
        type: events.RESET_CART_MERGED
      } )
    } );
  } );

  describe( 'Reset Cart Page Navigation', () => {

    it( 'The action type should exist', () => {
      expect( events.RESET_CARTPAGE_NAVIGATION ).toBe( 'CHECKOUT_PAGE::RESET_CARTPAGE_NAVIGATION' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.resetCartPageNavigation ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.resetCartPageNavigation( );
      expect( creator ).toEqual( {
        type: events.RESET_CARTPAGE_NAVIGATION
      } )
    } );
  } );

  describe( 'Reset Order Status', () => {

    it( 'The action type should exist', () => {
      expect( events.RESET_ORDER_STATUS ).toBe( 'CHECKOUT_PAGE::RESET_ORDER_STATUS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.resetOrderStatus ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.resetOrderStatus( );
      expect( creator ).toEqual( {
        type: events.RESET_ORDER_STATUS
      } )
    } );
  } );

  describe( 'Toggle InputField Payment Display', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY ).toBe( 'CHECKOUT_PAGE::TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.toggleInputFieldPaymentDisplay ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.toggleInputFieldPaymentDisplay( );
      expect( creator ).toEqual( {
        type: events.TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY
      } )
    } );
  } );

  describe( 'Is Coupon Button Clicked', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_IS_COUPON_BUTTON_CLICKED ).toBe( 'CHECKOUT_PAGE::SET_IS_COUPON_BUTTON_CLICKED' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.isCouponBtnClicked ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = 'true';
      const creator = events.isCouponBtnClicked( data );
      expect( creator ).toEqual( {
        type: events.SET_IS_COUPON_BUTTON_CLICKED,
        data
      } )
    } );
  } );

  describe( 'Set show default shipping method', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_SHOW_DEFAULT_SHIPPING_METHOD ).toBe( 'CHECKOUT_PAGE::SET_SHOW_DEFAULT_SHIPPING_METHOD' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setShowDefaultShippingMethod ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = jest.fn();
      const creator = events.setShowDefaultShippingMethod( data );
      expect( creator ).toEqual( {
        type: events.SET_SHOW_DEFAULT_SHIPPING_METHOD,
        data
      } )
    } );
  } );

  describe( 'Set shippping address view', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_SHIPPING_ADDRESS_VIEW ).toBe( 'CHECKOUT_PAGE::SET_SHIPPING_ADDRESS_VIEW' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setShippingAddressView ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = jest.fn();
      const creator = events.setShippingAddressView( data );
      expect( creator ).toEqual( {
        type: events.SET_SHIPPING_ADDRESS_VIEW,
        data
      } )
    } );
  } );

  describe( 'Set payment information view', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_PAYMENT_INFORMATION_VIEW ).toBe( 'CHECKOUT_PAGE::SET_PAYMENT_INFORMATION_VIEW' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setPaymentInformationView ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = jest.fn();
      const creator = events.setPaymentInformationView( data );
      expect( creator ).toEqual( {
        type: events.SET_PAYMENT_INFORMATION_VIEW,
        data
      } )
    } );
  } );

  describe( 'Add Edit Payment Method', () => {

    it( 'The action type should exist', () => {
      expect( events.ADD_EDIT_PAYMENT_METHOD ).toBe( 'CHECKOUT_PAGE::ADD_EDIT_PAYMENT_METHOD' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.addEditPaymentMethod ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = {
        nickName: 'Mastercard - 4444',
        creditCardType: 'Mastercard',
        creditCardNumber: '4444',
        expirationMonth: '06',
        expirationYear: '2031',
        firstName: 'Jane',
        lastName: 'Doe',
        phoneNumber: '123-456-7890',
        isPrimary: 'true',
        addressData: {
          address1: '724 Greenwood Circle',
          address2: 'Apt#102',
          city: 'Naperville',
          state: 'IL',
          postalCode: '92476'
        }
      }

      const creator = events.addEditPaymentMethod( data );
      expect( creator ).toEqual( {
        type: events.ADD_EDIT_PAYMENT_METHOD,
        data
      } )
    } );
  } );

  describe( 'Display Dav PopUp', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_DISPLAY_DAV_POPUP ).toBe( 'CHECKOUT_PAGE::SET_DISPLAY_DAV_POPUP' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setDisplayDavPopUp ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.setDisplayDavPopUp( );
      expect( creator ).toEqual( {
        type: events.SET_DISPLAY_DAV_POPUP
      } )
    } );
  } );

  describe( 'Billing  Address Same As Shipping', () => {

    it( 'The action type should exist', () => {
      expect( events.BILLING_ADDRESS_SAME_AS_SHIPPING ).toBe( 'CHECKOUT_PAGE::BILLING_ADDRESS_SAME_AS_SHIPPING' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setBillingAddressSameAsShipping ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = 'true';
      const creator = events.setBillingAddressSameAsShipping( data );
      expect( creator ).toEqual( {
        type: events.BILLING_ADDRESS_SAME_AS_SHIPPING,
        data
      } )
    } );
  } );

  describe( 'Set CheckOut Panel Collapse', () => {
    it( 'should have a defined action type', () => {
      expect( events.CHECKOUT_PANEL_COLLAPSE ).toBe( 'CHECKOUT_PAGE::CHECKOUT_PANEL_COLLAPSE' );
    } );
    it( 'should have an action creator function', () => {
      expect( _.isFunction( events.setCheckoutPanelCollapse ) ).toBe( true );
    } );
    it( 'should return the proper action object from the action creator function', () => {
      let panelID = 'redeemPanel';
      let creator = events.setCheckoutPanelCollapse( panelID );
      expect( creator ).toEqual( {
        type: events.CHECKOUT_PANEL_COLLAPSE,
        panelID
      } )
    } );



  } );

  describe( 'Show Paypal Button', () => {

    it( 'The action type should exist', () => {
      expect( events.SET_SHOW_PAYPAL_BUTTON ).toBe( 'CHECKOUT_PAGE::SET_SHOW_PAYPAL_BUTTON' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setShowPaypalButton ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.setShowPaypalButton( );
      expect( creator ).toEqual( {
        type: events.SET_SHOW_PAYPAL_BUTTON
      } )
    } );
  } );

  describe( 'Billing Address same as contact info', () => {
    it( 'The action type should exist', () => {
      expect( events.BILLING_ADDRESS_SAME_AS_CONTACT_INFO ).toBe( 'CHECKOUT_PAGE::BILLING_ADDRESS_SAME_AS_CONTACT_INFO' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setBillingAddressSameAsContactInfo ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.setBillingAddressSameAsContactInfo( );
      expect( creator ).toEqual( {
        type: events.BILLING_ADDRESS_SAME_AS_CONTACT_INFO
      } )
    } );
  } );

  describe( 'Reset CheckoutDataAvailable', () => {

    it( 'The action type should exist', () => {
      expect( events.RESET_CHECKOUT_DATA_AVAILABLE ).toBe( 'CHECKOUT_PAGE::RESET_CHECKOUT_DATA_AVAILABLE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.resetCheckoutDataAvailable ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.resetCheckoutDataAvailable( );
      expect( creator ).toEqual( {
        type: events.RESET_CHECKOUT_DATA_AVAILABLE
      } )
    } );
  } );

  describe( 'Toggle InputField shipping Display', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY ).toBe( 'CHECKOUT_PAGE::TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.toggleInputFieldShippingDisplay ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.toggleInputFieldShippingDisplay( );
      expect( creator ).toEqual( {
        type: events.TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY
      } )
    } );
  } );

  describe( 'Toggle OptIn to enable SMS', () => {

    it( 'The action type should exist', () => {
      expect( events.TOGGLE_OPTIN_FOR_SMS ).toBe( 'CHECKOUT_PAGE::TOGGLE_OPTIN_FOR_SMS' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.toggleOptInForSms ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.toggleOptInForSms( );
      expect( creator ).toEqual( {
        type: events.TOGGLE_OPTIN_FOR_SMS
      } )
    } );
  } );

  describe( 'UPDATE_MOBILE_NUMBER', () => {

    it( 'The action type should exist', () => {
      expect( events.UPDATE_MOBILE_NUMBER ).toBe( 'CHECKOUT_PAGE::UPDATE_MOBILE_NUMBER' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.updateMobileNumber ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.updateMobileNumber( );
      expect( creator ).toEqual( {
        type: events.UPDATE_MOBILE_NUMBER
      } )
    } );
  } );

} );
