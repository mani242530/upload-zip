/**
 *
 * Coupons Actions
 *
 * This file defines the action types and action creators for 'Coupons'
 **/


/**
 * ACTION TYPES
 */
export const COUPON_CODE = 'COUPONS::COUPON_CODE';
export const COUPON_CODE_REMOVED = 'COUPONS::COUPON_CODE_REMOVED';


/**
 * ACTIONS
 */
export const couponCodeUpdated = ( item, history, fromCheckout ) => ( {
  type: COUPON_CODE, item, history, fromCheckout
} );
export const couponCodeRemoved = ( history, fromCheckout ) => ( { type: COUPON_CODE_REMOVED, history, fromCheckout } );
