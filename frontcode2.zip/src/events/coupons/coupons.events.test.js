/**
 * Test for Coupons actions
 */
import _ from 'lodash';
import * as events from './coupons.events';
describe( 'Coupons action types', () => {



  describe( 'Coupon code applied', () => {
    it( 'The action type should exist', () => {
      expect( events.COUPON_CODE ).toBe( 'COUPONS::COUPON_CODE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.couponCodeUpdated ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let item = '43243534543';
      let creator = events.couponCodeUpdated( item );
      expect( creator ).toEqual( {
        type: events.COUPON_CODE,
        item
      } )
    } );
  } );

  describe( 'Coupon code removed', () => {
    it( 'The action type should exist', () => {
      expect( events.COUPON_CODE_REMOVED ).toBe( 'COUPONS::COUPON_CODE_REMOVED' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.couponCodeRemoved ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.couponCodeRemoved( );
      expect( creator ).toEqual( {
        type: events.COUPON_CODE_REMOVED
      } )
    } );
  } );


} );
