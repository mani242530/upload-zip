
/**
 * Services Actions
 *
 * This file defines the action types and action creators for 'Services'
 **/


/**
 * ACTION TYPES
 */
export const SET_DATA_LAYER = 'DATA_LAYER::SET_DATA_LAYER';
export const DATA_LAYER_UPDATED = 'DATA_LAYER::DATA_LAYER_UPDATED';
export const DATA_LAYER_UPDATE_FAILURE = 'DATA_LAYER::DATA_LAYER_UPDATE_FAILURE';


/**
 * ACTIONS
 */

export const setDataLayer = ( data, evt ) => ( { type: SET_DATA_LAYER, data, evt } );
export const dataLayerUpdated = ( data ) => ( { type: DATA_LAYER_UPDATED, data } );
export const dataLayerUpdateFailed = ( err ) => ( { type: DATA_LAYER_UPDATE_FAILURE, err } );
