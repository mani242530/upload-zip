/**
 * Test for DataLayer actions
 */

import _ from 'lodash';
import * as events from './data_layer.events';


describe( 'DataLayer action types', () => {
  it( 'expect all types to be defined', () => {
    expect( events.SET_DATA_LAYER ).toBe( 'DATA_LAYER::SET_DATA_LAYER' );
    expect( events.DATA_LAYER_UPDATED ).toBe( 'DATA_LAYER::DATA_LAYER_UPDATED' );
    expect( events.DATA_LAYER_UPDATE_FAILURE ).toBe( 'DATA_LAYER::DATA_LAYER_UPDATE_FAILURE' );
  } );
} );

describe( 'DataLayer actions', () => {

  it( 'sould have action creators defined', () => {
    expect( _.isFunction( events.setDataLayer ) ).toBe( true );
    expect( _.isFunction( events.dataLayerUpdated ) ).toBe( true );
    expect( _.isFunction( events.dataLayerUpdateFailed ) ).toBe( true );
  } );

  it( 'should create the proper action for setDataLayer', () => {
    const data =  {};
    const evt = {
      'name': 'pageNavigation'
    }
    const creator = events.setDataLayer( data, evt );
    expect( creator ).toEqual( {
      type: events.SET_DATA_LAYER,
      data:data,
      evt:evt
    } )
  } );

  it( 'should create the proper action for dataLayerUpdated', () => {
    const data =  {};
    const creator = events.dataLayerUpdated( data );
    expect( creator ).toEqual( {
      type: events.DATA_LAYER_UPDATED,
      data:data
    } )
  } );

  it( 'should create the proper action for dataLayerUpdateFailed', () => {
    const err = 'insufficient data to udpate data layer';
    const creator = events.dataLayerUpdateFailed( err );
    expect( creator ).toEqual( {
      type: events.DATA_LAYER_UPDATE_FAILURE,
      err:err
    } )
  } );
} );
