/**
 * Test for Footer actions
 */

import isFunction from 'lodash/isFunction';
import * as events from './email_sign_up.events';

describe( 'ESU action events', () => {

  it( 'The action type TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM should exist', () => {
    expect( events.TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM ).toBe( 'ESU::TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM' );
  } );

  it( 'The action type TOGGLE_SHOW_EMAIL_SIGN_UP_FORM should exist', () => {
    expect( events.TOGGLE_SHOW_EMAIL_SIGN_UP_FORM ).toBe( 'ESU::TOGGLE_SHOW_EMAIL_SIGN_UP_FORM' );
  } );

  it( 'The action type SET_BODY_STYLE_PADDING_BOTTOM should exist', () => {
    expect( events.SET_BODY_STYLE_PADDING_BOTTOM ).toBe( 'ESU::SET_BODY_STYLE_PADDING_BOTTOM' );
  } );

  it( 'The action type SET_STICKY_FOOTER_DISPLAY should exist', () => {
    expect( events.SET_STICKY_FOOTER_DISPLAY ).toBe( 'ESU::SET_STICKY_FOOTER_DISPLAY' );
  } );

  it( 'The action type SET_ESU_FORM_GT_SCREEN_HEIGHT should exist', () => {
    expect( events.SET_ESU_FORM_GT_SCREEN_HEIGHT ).toBe( 'ESU::SET_ESU_FORM_GT_SCREEN_HEIGHT' );
  } );

  it( 'The action type SET_ESU_CONTAINER_TRANSLATE_Y should exist', () => {
    expect( events.SET_ESU_CONTAINER_TRANSLATE_Y ).toBe( 'ESU::SET_ESU_CONTAINER_TRANSLATE_Y' );
  } );

  it( 'The action type SET_ESU_MODEL_OPENED_FLAG should exist', () => {
    expect( events.SET_ESU_MODEL_OPENED_FLAG ).toBe( 'ESU::SET_ESU_MODEL_OPENED_FLAG' );
  } );

  it( 'The action type SET_ESU_MODEL_CLOSED_FLAG should exist', () => {
    expect( events.SET_ESU_MODEL_CLOSED_FLAG ).toBe( 'ESU::SET_ESU_MODEL_CLOSED_FLAG' );
  } );

  it( 'The action type SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR should exist', () => {
    expect( events.SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR ).toBe( 'ESU::SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR' );
  } );

  it( 'The action creator toggleEligibleEmailSignUpForm function should exist', () => {
    expect( isFunction( events.toggleEligibleEmailSignUpForm ) ).toBe( true );
  } );

  it( 'The action creator toggleShowEmailSignUpForm function should exist', () => {
    expect( isFunction( events.toggleShowEmailSignUpForm ) ).toBe( true );
  } );

  it( 'The action creator setBodyStylePaddingBottom function should exist', () => {
    expect( isFunction( events.setBodyStylePaddingBottom ) ).toBe( true );
  } );

  it( 'The action creator setStickyFooterDisplay function should exist', () => {
    expect( isFunction( events.setStickyFooterDisplay ) ).toBe( true );
  } );

  it( 'The action creator setESUFormGTScreenHeight function should exist', () => {
    expect( isFunction( events.setESUFormGTScreenHeight ) ).toBe( true );
  } );

  it( 'The action creator setESUContainerTranslateY function should exist', () => {
    expect( isFunction( events.setESUContainerTranslateY ) ).toBe( true );
  } );

  it( 'The action creator setESUModelOpenedFlag function should exist', () => {
    expect( isFunction( events.setESUModelOpenedFlag ) ).toBe( true );
  } );

  it( 'The action creator setESUModelClosedFlag function should exist', () => {
    expect( isFunction( events.setESUModelClosedFlag ) ).toBe( true );
  } );

  it( 'The action creator setSubmittedEmailSignUpFormError function should exist', () => {
    expect( isFunction( events.setSubmittedEmailSignUpFormError ) ).toBe( true );
  } );

  it( 'The action creator toggleEligibleEmailSignUpForm function should return the proper action creator object', () => {
    var data = true;
    let creator = events.toggleEligibleEmailSignUpForm( data );
    expect( creator ).toEqual( {
      type: events.TOGGLE_ELIGIBLE_EMAIL_SIGN_UP_FORM,
      data
    } )
  } );

  it( 'The action creator toggleShowEmailSignUpForm function should return the proper action creator object', () => {
    var data = true;
    let creator = events.toggleShowEmailSignUpForm( data );
    expect( creator ).toEqual( {
      type: events.TOGGLE_SHOW_EMAIL_SIGN_UP_FORM,
      data
    } )
  } );

  it( 'The action creator setBodyStylePaddingBottom function should return the proper action creator object', () => {
    var data = 10;
    let creator = events.setBodyStylePaddingBottom( data );
    expect( creator ).toEqual( {
      type: events.SET_BODY_STYLE_PADDING_BOTTOM,
      data
    } )
  } );

  it( 'The action creator setStickyFooterDisplay function should return the proper action creator object', () => {
    var data = true;
    let creator = events.setStickyFooterDisplay( data );
    expect( creator ).toEqual( {
      type: events.SET_STICKY_FOOTER_DISPLAY,
      data
    } )
  } );

  it( 'The action creator setESUFormGTScreenHeight function should return the proper action creator object', () => {
    var data = true;
    let creator = events.setESUFormGTScreenHeight( data );
    expect( creator ).toEqual( {
      type: events.SET_ESU_FORM_GT_SCREEN_HEIGHT,
      data
    } )
  } );

  it( 'The action creator setESUContainerTranslateY function should return the proper action creator object', () => {
    var data = 150;
    let creator = events.setESUContainerTranslateY( data );
    expect( creator ).toEqual( {
      type: events.SET_ESU_CONTAINER_TRANSLATE_Y,
      data
    } )
  } );

  it( 'The action creator setESUModelOpenedFlag function should return the proper action creator object', () => {
    var data = 300;
    let creator = events.setESUModelOpenedFlag( data );
    expect( creator ).toEqual( {
      type: events.SET_ESU_MODEL_OPENED_FLAG
    } )
  } );

  it( 'The action creator setESUModelClosedFlag function should return the proper action creator object', () => {
    var data = 300;
    let creator = events.setESUModelClosedFlag( data );
    expect( creator ).toEqual( {
      type: events.SET_ESU_MODEL_CLOSED_FLAG
    } )
  } );

  it( 'The action creator setSubmittedEmailSignUpFormError function should return the proper action creator object', () => {
    var data = true;
    let creator = events.setSubmittedEmailSignUpFormError( data );
    expect( creator ).toEqual( {
      type: events.SET_SUBMITTED_EMAIL_SIGN_UP_FORM_ERROR,
      data
    } )
  } );

} );

