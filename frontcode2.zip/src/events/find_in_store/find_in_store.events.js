/**
 *
 * Find In Store Actions
 *
 * This file defines the action types and action creators for 'FindInStore'
 **/


/**
 * ACTION TYPES
 */
export const SEARCH_FOCUSED = 'FIND_IN_STORE::SEARCH_FOCUSED';
export const SEARCH_UNFOCUSED = 'FIND_IN_STORE::SEARCH_UNFOCUSED';
export const CLOSE_FIND_IN_STORE_MODAL = 'FIND_IN_STORE::CLOSE_FIND_IN_STORE_MODAL';
export const SEARCH_BUTTON_FOCUSED = 'FIND_IN_STORE::SEARCH_BUTTON_FOCUSED';
export const SEARCH_BUTTON_UNFOCUSED = 'FIND_IN_STORE::SEARCH_BUTTON_UNFOCUSED';



/**
   * ACTIONS
   */
export const searchFocused = ( ) => ( { type: SEARCH_FOCUSED } );
export const searchUnFocused = ( ) => ( { type: SEARCH_UNFOCUSED } );
export const closeFindInStoreModal = () => ( { type: CLOSE_FIND_IN_STORE_MODAL } );
export const searchButtonFocused = ( ) => ( { type: SEARCH_BUTTON_FOCUSED } );
export const searchButtonUnfocused = ( ) => ( { type: SEARCH_BUTTON_UNFOCUSED } );


