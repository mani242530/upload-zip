
import _ from 'lodash';
import * as events from './find_in_store.events';


describe( 'FindInStore action types', () => {
  it( 'expect all types to be defined', () => {
    expect( events.SEARCH_FOCUSED ).toBe( 'FIND_IN_STORE::SEARCH_FOCUSED' );
  } );

  it( 'expect all types to be defined', () => {
    expect( events.SEARCH_UNFOCUSED ).toBe( 'FIND_IN_STORE::SEARCH_UNFOCUSED' );
  } );

  it( 'expect all types to be defined', () => {
    expect( events.CLOSE_FIND_IN_STORE_MODAL ).toBe( 'FIND_IN_STORE::CLOSE_FIND_IN_STORE_MODAL' );
  } );


} );

describe( 'FindInStore actions', () => {

  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.searchFocused ) ).toBe( true );
  } );

  it( 'should create the proper action for searchFocused', () => {
    let creator = events.searchFocused();
    expect( creator ).toEqual( {
      type: events.SEARCH_FOCUSED
    } )
  } );

  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.searchUnFocused ) ).toBe( true );
  } );

  it( 'should create the proper action for searchUnFocused', () => {
    let creator = events.searchUnFocused();
    expect( creator ).toEqual( {
      type: events.SEARCH_UNFOCUSED
    } )
  } );

  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.closeFindInStoreModal ) ).toBe( true );
  } );

  it( 'The action creator function should return the proper action creator object', () => {
    let creator = events.closeFindInStoreModal();
    expect( creator ).toEqual( {
      type: events.CLOSE_FIND_IN_STORE_MODAL
    } )
  } );

  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.searchButtonFocused ) ).toBe( true );
  } );

  it( 'should create the proper action for searchButtonFocused', () => {
    let creator = events.searchButtonFocused();
    expect( creator ).toEqual( {
      type: events.SEARCH_BUTTON_FOCUSED
    } )
  } );

  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.searchButtonUnfocused ) ).toBe( true );
  } );

  it( 'should create the proper action for searchButtonUnfocused', () => {
    let creator = events.searchButtonUnfocused();
    expect( creator ).toEqual( {
      type: events.SEARCH_BUTTON_UNFOCUSED
    } )
  } );

} );
