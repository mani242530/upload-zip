/**
 * Footer Actions
 *
 * This file defines the action types and action creators for 'Footer'
 **/


/**
 * ACTION TYPES
 */
export const SET_ACTIVE_FOOTER_NAV_COLLAPSE = 'FOOTER::SET_ACTIVE_FOOTER_NAV_COLLAPSE';
export const SET_FOOTER_DISPLAY_MODE = 'FOOTER::SET_FOOTER_DISPLAY_MODE';


/**
 * ACTIONS
 */
export const setActiveFooterNavCollapse = ( panelID ) => ( { type: SET_ACTIVE_FOOTER_NAV_COLLAPSE, panelID } );
export const setFooterDisplayMode = ( deviceType, mode ) => ( { type: SET_FOOTER_DISPLAY_MODE, mode, deviceType } );
