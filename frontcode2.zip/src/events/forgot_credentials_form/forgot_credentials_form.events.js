export const REQUEST_PASSWORD_RESET_REQUEST = 'FORGOTCREDENTIALSFORM::REQUEST_PASSWORD_RESET_REQUEST';

export const requestPasswordResetRequest = ( emailId ) => (
  { type: REQUEST_PASSWORD_RESET_REQUEST, emailId } )
