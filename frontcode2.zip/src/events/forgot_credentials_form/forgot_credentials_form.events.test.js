import _ from 'lodash';
import * as events from './forgot_credentials_form.events';


describe( 'ForgotCredentialsForm action types', () => {
  it( 'expect all types to be defined', () => {
    expect( events.REQUEST_PASSWORD_RESET_REQUEST ).toBe( 'FORGOTCREDENTIALSFORM::REQUEST_PASSWORD_RESET_REQUEST' );
  } );
} );
describe( 'ForgotCredentialsForm actions', () => {

  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.requestPasswordResetRequest ) ).toBe( true );
  } );

  it( 'should create the proper action for requestPasswordResetRequest', () => {
    let creator = events.requestPasswordResetRequest();
    expect( creator ).toEqual( {
      type: events.REQUEST_PASSWORD_RESET_REQUEST
    } )
  } );

} );
