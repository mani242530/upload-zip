/**
 * LiveChat Actions
 *
 * This file defines the action types and action creators for 'LiveChat'
 **/


/**
 * ACTION TYPES
 */
export const LOAD_LIVE_CHAT = 'LIVE_CHAT::LOAD';

/**
 * ACTIONS
 */
export const loadLiveChat = () => ( { type: LOAD_LIVE_CHAT } );
