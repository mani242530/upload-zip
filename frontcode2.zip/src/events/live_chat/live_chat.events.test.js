
/**
 * Test for LiveChat actions
 */

import _ from 'lodash';
import * as events from './live_chat.events';


describe( 'LiveChat action types', () => {
  it( 'should have the right value for LOAD_LIVE_CHAT ', () => {
    expect( events.LOAD_LIVE_CHAT ).toBe( 'LIVE_CHAT::LOAD' );
  } );
} );

describe( 'LiveChat action creators', () => {
  it( 'loadLiveChat should exist', () => {
    expect( _.isFunction( events.loadLiveChat ) ).toBe( true );
  } );
} );

describe( 'Live actions', () => {
  it( 'should create the proper action for loadLiveChat', () => {
    const creator = events.loadLiveChat( );
    expect( creator ).toEqual( {
      type: events.LOAD_LIVE_CHAT
    } );
  } );
} );
