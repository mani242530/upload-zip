
/**
 * Services Actions
 *
 * This file defines the action types and action creators for Mesobase
 **/


/**
 * ACTION TYPES
 */
export const TRIGGER_MESOBASE_EVENTS = 'MESOBASE::TRIGGER_MESOBASE_EVENTS';

/**
 * ACTIONS
 */
export const triggerMesobaseEvents = () => ( { type: TRIGGER_MESOBASE_EVENTS } );
