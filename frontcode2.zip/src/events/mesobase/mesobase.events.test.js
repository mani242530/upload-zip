
/**
 * Test for Language actions
 */

import _ from 'lodash';
import * as events from './mesobase.events';


describe( 'Mesobase action types', () => {
  it( 'The TRIGGER_MESOBASE_EVENTS action  should be the right value', () => {
    expect( events.TRIGGER_MESOBASE_EVENTS ).toBe( 'MESOBASE::TRIGGER_MESOBASE_EVENTS' );
  } );
} );

describe( 'Mesobase action creators', () => {
  it( 'TRIGGER_MESOBASE_EVENTS should exist', () => {
    expect( _.isFunction( events.triggerMesobaseEvents ) ).toBe( true );
  } );
} );

describe( 'Mesobase actions', () => {
  it( 'should create the proper action for triggerMesobaseEvents', () => {
    const creator = events.triggerMesobaseEvents( );
    expect( creator ).toEqual( {
      type: events.TRIGGER_MESOBASE_EVENTS
    } );
  } );
} );
