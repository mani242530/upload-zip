/**
 *
 * Cart Actions
 *
 * This file defines the action types and action creators for 'Cart'
 **/


/**
 * ACTION TYPES
 */


export const REMOVE_FROM_CART = 'MINI_CART::REMOVE_FROM_CART';
export const REMOVE_GIFT_FROM_CART = 'MINI_CART::REMOVE_GIFT_FROM_CART';
export const SET_GIFT_MESSAGE = 'MINI_CART::SET_GIFT_MESSAGE';
export const SET_GIFT_BOX_TOGGLE_STATE = 'MINI_CART::SET_GIFT_BOX_TOGGLE_STATE';
export const SHOW_BAG_SUMMARY = 'MINI_CART::SHOW_BAG_SUMMARY';
export const SET_PRODUCT_SAMPLE = 'MINI_CART::SET_PRODUCT_SAMPLE';
export const CART_RIGHT_PANEL_COLLAPSE = 'MINI_CART::CART_RIGHT_PANEL_COLLAPSE';
export const SET_CHKOUT_BTN_STATE = 'MINI_CART::SET_CHKOUT_BTN_STATE';
export const SELECT_PRODUCT_SAMPLE_SERVICE = 'MINI_CART::SELECT_PRODUCT_SAMPLE_SERVICE';
export const REMOVE_PRODUCT_SAMPLE_SERVICE = 'MINI_CART::REMOVE_PRODUCT_SAMPLE_SERVICE';
export const SELECT_GIFT_VARIANT = 'MINI_CART::SELECT_GIFT_VARIANT';
export const SET_GIFT_WRAP_GIFT_NOTE_SERVICE = 'MINI_CART::SET_GIFT_WRAP_GIFT_NOTE_SERVICE';
export const SET_GIFT_WRAP_GIFT_BOX_SERVICE = 'MINI_CART::SET_GIFT_WRAP_GIFT_BOX_SERVICE';
export const OPEN_CART = 'MINI_CART::OPEN_CART';
export const ADD_TO_CART = 'MINI_CART::ADD_TO_CART';
export const UPDATE_CART = 'MINI_CART::UPDATE_CART';
export const INITIATE_CHECKOUT = 'MINI_CART::INITIATE_CHECKOUT';
export const RESET_CHECKOUT_ELIGIBILITY = 'MINI_CART::RESET_CHECKOUT_ELIGIBILITY';
export const GET_PAYPAL_RESPONSE = 'MINI_CART::GET_PAYPAL_RESPONSE';
export const CLEAR_COUPON_ERROR = 'FORMS::CLEAR_COUPON_ERROR';
export const FOCUS_GIFT_BOX = 'MINI_CART::FOCUS_GIFT_BOX';
export const BLUR_GIFT_BOX = 'MINI_CART::BLUR_GIFT_BOX';
export const DISPLAY_MINI_CART_FLYOUT = 'MINI_BAG::DISPLAY_MINI_CART_FLYOUT';
export const HIDE_MINI_CART_FLYOUT = 'MINI_BAG::HIDE_MINI_CART_FLYOUT';
export const REMOVE_FROM_MINI_CART = 'MINI_CART::REMOVE_FROM_MINI_CART';
export const SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE = 'MINI_CART::SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE';
export const UPDATED_CART_RESPONSE = 'MINI_CART::UPDATED_CART_RESPONSE';



/**
 * ACTIONS
 */
export const addToCart = ( item, history ) => ( { type: ADD_TO_CART, item, history } );
export const removeFromCart =  ( item ) => ( { type: REMOVE_FROM_CART, item } );
export const updateCart = ( item, quantity, history ) => ( {
  type: UPDATE_CART, item, quantity, history
} );
export const removeGiftFromCart = ( item, history ) => ( { type: REMOVE_GIFT_FROM_CART, item, history } );
export const openCart = () => ( { type: OPEN_CART } );
export const setGiftMessage = ( text ) => ( { type: SET_GIFT_MESSAGE, text } );
export const setGiftBoxToggleStatus = ( status ) => ( { type: SET_GIFT_BOX_TOGGLE_STATE, status } );
export const setShowBagSummaryStatus = ( status ) => ( { type: SHOW_BAG_SUMMARY, status } );
export const setCartRightPanelCollapse = ( panelID ) => ( { type: CART_RIGHT_PANEL_COLLAPSE, panelID } );
export const setChkoutBtnStatus = ( status ) => ( { type: SET_CHKOUT_BTN_STATE, status } );
export const selectProductSampleService = ( catalogID, quantity, history ) => ( {
  type: SELECT_PRODUCT_SAMPLE_SERVICE, catalogID, quantity, history
} );
export const removeProductSampleService = ( history ) => ( { type: REMOVE_PRODUCT_SAMPLE_SERVICE, history } );
export const selectGiftVariant = ( promotionid, skuid, history ) => ( {
  type: SELECT_GIFT_VARIANT, promotionid, skuid, history
} );
export const setGiftWrapGiftNoteService = ( giftNote, history ) => ( { type: SET_GIFT_WRAP_GIFT_NOTE_SERVICE, giftNote, history } );
export const setGiftWrapGiftBoxService = ( giftboxStatus, history ) => ( { type: SET_GIFT_WRAP_GIFT_BOX_SERVICE, giftboxStatus, history } );
export const initiateCheckout = ( data ) => ( { type: INITIATE_CHECKOUT, data } );
export const resetCheckoutEligibility = () => ( { type: RESET_CHECKOUT_ELIGIBILITY } );
export const getPaypalResponse = ( info ) => ( { type: GET_PAYPAL_RESPONSE, info } );
export const focusGiftBox = ( ) => ( { type: FOCUS_GIFT_BOX } );
export const blurGiftBox = ( ) => ( { type: BLUR_GIFT_BOX } );
export const displayMiniCartFlyout = () => ( { type: DISPLAY_MINI_CART_FLYOUT } );
export const hideMiniCartFlyout = () => ( { type: HIDE_MINI_CART_FLYOUT } );
export const removeFromMiniCart = ( item ) => ( { type: REMOVE_FROM_MINI_CART, item } );
export const showRemovedFromBagSuccessMessage = ( data ) => ( { type: SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE, data } );
export const updatedCartResponse = ( data ) => ( { type: UPDATED_CART_RESPONSE, data } );
