/**
 * Test for Cart actions
 */
import _ from 'lodash';
import * as events from './mini_cart.events';
describe( 'Cart action types', () => {

  describe( 'Open LoadCart', () => {

    it( 'The action type should exist', () => {
      expect( events.OPEN_CART ).toBe( 'MINI_CART::OPEN_CART' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.openCart ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.openCart();
      expect( creator ).toEqual( {
        type: events.OPEN_CART
      } )
    } );
  } );

  describe( 'addToCart', () => {

    it( 'The action type should exist', () => {
      expect( events.ADD_TO_CART ).toBe( 'MINI_CART::ADD_TO_CART' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.addToCart ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let item = '43243534543';
      let history = '123243535';
      let creator = events.addToCart( item, history );
      expect( creator ).toEqual( {
        type: events.ADD_TO_CART,
        history,
        item
      } )
    } );
  } );
  describe( 'Update LoadCart', () => {

    it( 'The action type should exist', () => {
      expect( events.UPDATE_CART ).toBe( 'MINI_CART::UPDATE_CART' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.updateCart ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let item = 'a1234567';
      let history = '1234'
      let quantity = '2';
      let creator = events.updateCart( item, quantity, history );
      expect( creator ).toEqual( {
        type: events.UPDATE_CART,
        item,
        quantity,
        history
      } )
    } );
  } );
  describe( 'Remove from cart', () => {

    it( 'The action type should exist', () => {
      expect( events.REMOVE_FROM_CART ).toBe( 'MINI_CART::REMOVE_FROM_CART' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.removeFromCart ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let item = { title: 'test', price: '$2231.22' };
      let creator = events.removeFromCart( item );
      expect( creator ).toEqual( {
        type: events.REMOVE_FROM_CART,
        item
      } )
    } );
  } );
  describe( 'Remove Gift from cart', () => {
    it( 'The action type should exist', () => {
      expect( events.REMOVE_GIFT_FROM_CART ).toBe( 'MINI_CART::REMOVE_GIFT_FROM_CART' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.removeGiftFromCart ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let item = '43243534543';
      let history = '123243535';
      let creator = events.removeGiftFromCart( item, history );
      expect( creator ).toEqual( {
        type: events.REMOVE_GIFT_FROM_CART,
        history,
        item
      } )
    } );
  } );


  describe( 'select Gift variant', () => {

    it( 'The action type should exist', () => {
      expect( events.SELECT_GIFT_VARIANT ).toBe( 'MINI_CART::SELECT_GIFT_VARIANT' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.selectGiftVariant ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let promotionid = '43243534543';
      let skuid = '43243534543';
      let history = '123243535';
      let creator = events.selectGiftVariant( promotionid, skuid, history );
      expect( creator ).toEqual( {
        type: events.SELECT_GIFT_VARIANT,
        history,
        promotionid,
        skuid
      } )
    } );
  } );
  describe( 'Set Gift Message', () => {
    it( 'The action type should exist', () => {
      expect( events.SET_GIFT_MESSAGE ).toBe( 'MINI_CART::SET_GIFT_MESSAGE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setGiftMessage ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let text = { giftText: 'GiftWrap Selected' };
      let creator = events.setGiftMessage( text );
      expect( creator ).toEqual( {
        type: events.SET_GIFT_MESSAGE,
        text
      } )
    } );
  } );
  describe( 'Set Gift Box Toggle Status', () => {
    it( 'The action type should exist', () => {
      expect( events.SET_GIFT_BOX_TOGGLE_STATE ).toBe( 'MINI_CART::SET_GIFT_BOX_TOGGLE_STATE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setGiftBoxToggleStatus ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let status = { giftBoxToggle: true };
      let creator = events.setGiftBoxToggleStatus( status );
      expect( creator ).toEqual( {
        type: events.SET_GIFT_BOX_TOGGLE_STATE,
        status
      } )
    } );
  } );
  describe( 'Set check out button Status', () => {
    it( 'The action type should exist', () => {
      expect( events.SET_CHKOUT_BTN_STATE ).toBe( 'MINI_CART::SET_CHKOUT_BTN_STATE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setChkoutBtnStatus ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let status = { chkoutbtnClk: true };
      let creator = events.setChkoutBtnStatus( status );
      expect( creator ).toEqual( {
        type: events.SET_CHKOUT_BTN_STATE,
        status
      } )
    } );
  } );
  describe( 'Set Header Bag Summary Status', () => {
    it( 'The action type should exist', () => {
      expect( events.SHOW_BAG_SUMMARY ).toBe( 'MINI_CART::SHOW_BAG_SUMMARY' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setShowBagSummaryStatus ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let status = { showBagSummary: true };
      let creator = events.setShowBagSummaryStatus( status );
      expect( creator ).toEqual( {
        type: events.SHOW_BAG_SUMMARY,
        status
      } )
    } );
  } );
  describe( 'Select Product Sample', () => {
    it( 'The action type should exist', () => {
      expect( events.SELECT_PRODUCT_SAMPLE_SERVICE ).toBe( 'MINI_CART::SELECT_PRODUCT_SAMPLE_SERVICE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.selectProductSampleService ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let catalogID = '12345';
      let quantity = '2';
      let history = '1234678' ;
      let creator = events.selectProductSampleService( catalogID, quantity, history );
      expect( creator ).toEqual( {
        type: events.SELECT_PRODUCT_SAMPLE_SERVICE,
        catalogID,
        quantity,
        history
      } )
    } );
  } );
  describe( 'Remove Product Sample', () => {
    it( 'The action type should exist', () => {
      expect( events.REMOVE_PRODUCT_SAMPLE_SERVICE ).toBe( 'MINI_CART::REMOVE_PRODUCT_SAMPLE_SERVICE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.removeProductSampleService ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let history = '1234678' ;
      let creator = events.removeProductSampleService( history );
      expect( creator ).toEqual( {
        type: events.REMOVE_PRODUCT_SAMPLE_SERVICE,
        history
      } )
    } );
  } );
  describe( 'Set Cart Page Right Panel Collapse', () => {
    it( 'The action type should exist', () => {
      expect( events.CART_RIGHT_PANEL_COLLAPSE ).toBe( 'MINI_CART::CART_RIGHT_PANEL_COLLAPSE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setCartRightPanelCollapse ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let panelID = 'gifts' ;
      let creator = events.setCartRightPanelCollapse( panelID );
      expect( creator ).toEqual( {
        type: events.CART_RIGHT_PANEL_COLLAPSE,
        panelID
      } )
    } );
  } );
  describe( 'setGiftWrapGiftNoteService', () => {
    it( 'The action type should exist', () => {
      expect( events.SET_GIFT_WRAP_GIFT_NOTE_SERVICE ).toBe( 'MINI_CART::SET_GIFT_WRAP_GIFT_NOTE_SERVICE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setGiftWrapGiftNoteService ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let giftNote = 'Happy Birthday Teja' ;
      let history = '12345';
      let creator = events.setGiftWrapGiftNoteService( giftNote, history );
      expect( creator ).toEqual( {
        type: events.SET_GIFT_WRAP_GIFT_NOTE_SERVICE,
        giftNote,
        history
      } )
    } );
  } );

  describe( 'focusGiftBox', () => {
    it( 'The action type should exist', () => {
      expect( events.FOCUS_GIFT_BOX ).toBe( 'MINI_CART::FOCUS_GIFT_BOX' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.focusGiftBox ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.focusGiftBox();
      expect( creator ).toEqual( {
        type: events.FOCUS_GIFT_BOX
      } )
    } );
  } );

  describe( 'blurGiftBox', () => {
    it( 'The action type should exist', () => {
      expect( events.BLUR_GIFT_BOX ).toBe( 'MINI_CART::BLUR_GIFT_BOX' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.blurGiftBox ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.blurGiftBox();
      expect( creator ).toEqual( {
        type: events.BLUR_GIFT_BOX
      } )
    } );
  } );

  describe( 'setGiftWrapGiftBoxService', () => {
    it( 'The action type should exist', () => {
      expect( events.SET_GIFT_WRAP_GIFT_BOX_SERVICE ).toBe( 'MINI_CART::SET_GIFT_WRAP_GIFT_BOX_SERVICE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setGiftWrapGiftBoxService ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const giftboxStatus = jest.fn();
      const hObj = '12321'
      const creator = events.setGiftWrapGiftBoxService( giftboxStatus, hObj );
      expect( creator ).toEqual( {
        type: events.SET_GIFT_WRAP_GIFT_BOX_SERVICE,
        giftboxStatus,
        history: hObj
      } )
    } );
  } );

  describe( 'initiateCheckout', () => {
    it( 'The action type should exist', () => {
      expect( events.INITIATE_CHECKOUT ).toBe( 'MINI_CART::INITIATE_CHECKOUT' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.initiateCheckout ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.initiateCheckout();
      expect( creator ).toEqual( {
        type: events.INITIATE_CHECKOUT
      } )
    } );
  } );

  describe( 'resetCheckoutEligibility', () => {
    it( 'The action type should exist', () => {
      expect( events.RESET_CHECKOUT_ELIGIBILITY ).toBe( 'MINI_CART::RESET_CHECKOUT_ELIGIBILITY' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.resetCheckoutEligibility ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.resetCheckoutEligibility();
      expect( creator ).toEqual( {
        type: events.RESET_CHECKOUT_ELIGIBILITY
      } )
    } );
  } );

  describe( 'getPaypalResponse', () => {
    it( 'The action type should exist', () => {
      expect( events.GET_PAYPAL_RESPONSE ).toBe( 'MINI_CART::GET_PAYPAL_RESPONSE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.getPaypalResponse ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.getPaypalResponse();
      expect( creator ).toEqual( {
        type: events.GET_PAYPAL_RESPONSE
      } )
    } );
  } );


  describe( 'displayMiniCartFlyout', () => {
    it( 'The action type should exist', () => {
      expect( events.DISPLAY_MINI_CART_FLYOUT ).toBe( 'MINI_BAG::DISPLAY_MINI_CART_FLYOUT' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.displayMiniCartFlyout ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.displayMiniCartFlyout();
      expect( creator ).toEqual( {
        type: events.DISPLAY_MINI_CART_FLYOUT
      } )
    } );
  } );

  describe( 'hideMiniCartFlyout', () => {
    it( 'The action type should exist', () => {
      expect( events.HIDE_MINI_CART_FLYOUT ).toBe( 'MINI_BAG::HIDE_MINI_CART_FLYOUT' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.hideMiniCartFlyout ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const creator = events.hideMiniCartFlyout();
      expect( creator ).toEqual( {
        type: events.HIDE_MINI_CART_FLYOUT
      } )
    } );

    describe( 'removeFromMiniCart', () => {
      it( 'The action type should exist', () => {
        expect( events.REMOVE_FROM_MINI_CART ).toBe( 'MINI_CART::REMOVE_FROM_MINI_CART' );
      } );
      it( 'The action creator function should exist', () => {
        expect( _.isFunction( events.removeFromMiniCart ) ).toBe( true );
      } );
      it( 'The action creator function should return the proper action creator object', () => {
        const creator = events.removeFromMiniCart();
        expect( creator ).toEqual( {
          type: events.REMOVE_FROM_MINI_CART
        } )
      } );
    } );
  } );

  describe( 'show item removed from bag success message ', () => {

    it( 'The action type should exist', () => {
      expect( events.SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE ).toBe( 'MINI_CART::SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.showRemovedFromBagSuccessMessage ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = '2210015';
      const creator = events.showRemovedFromBagSuccessMessage( data );
      expect( creator ).toEqual( {
        type: events.SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE,
        data
      } );
    } );

  } );

  describe( 'action to update the cart response ', () => {

    it( 'The action type should exist', () => {
      expect( events.UPDATED_CART_RESPONSE ).toBe( 'MINI_CART::UPDATED_CART_RESPONSE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.updatedCartResponse ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = {};
      const creator = events.updatedCartResponse( data );
      expect( creator ).toEqual( {
        type: events.UPDATED_CART_RESPONSE,
        data
      } );
    } );

  } );

} );
