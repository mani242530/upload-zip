/**
 * Power Reviews Actions
 *
 * This file defines the action types and action creators for 'PowerReviews'
 **/


/**
 * ACTION TYPES
 */
export const EMITTING_FEEDLESS_PRODUCT   = 'POWER_REVIEWS::EMITTING_FEEDLESS_PRODUCT';
/**
 * ACTIONS
 */
export const emittingFeedlessProduct = ( productDetails ) => ( { type: EMITTING_FEEDLESS_PRODUCT, productDetails } );
