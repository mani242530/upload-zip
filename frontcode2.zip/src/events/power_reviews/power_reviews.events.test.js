/**
 * Test for Power Reviews actions
 */

import _ from 'lodash';
import * as events from './power_reviews.events';


describe( 'Power Reviews action types', () => {
  it( 'should have the right value for EMITTING_FEEDLESS_PRODUCT ', () => {
    expect( events.EMITTING_FEEDLESS_PRODUCT ).toBe( 'POWER_REVIEWS::EMITTING_FEEDLESS_PRODUCT' );
  } );
} );

describe( 'Power Reviews action creators', () => {
  it( 'emittingFeedlessProduct should exist', () => {
    expect( _.isFunction( events.emittingFeedlessProduct ) ).toBe( true );
  } );
} );

describe( 'Power Reviews actions', () => {
  it( 'should create the proper action for emittingFeedlessProduct', () => {
    const creator = events.emittingFeedlessProduct( );
    expect( creator ).toEqual( {
      type: events.EMITTING_FEEDLESS_PRODUCT
    } );
  } );
} );