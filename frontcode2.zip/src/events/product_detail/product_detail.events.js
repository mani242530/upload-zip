/**
 *
 * Product Page Actions
 *
 * This file defines the action types and action creators for 'ProductDetail'
 **/


/**
 * ACTION TYPES
 */
export const PRODUCT_RIGHT_PANEL_COLLAPSE = 'PRODUCT_PAGE::PDP_RIGHT_PANEL_COLLAPSE';
export const PRODUCT_SWATCHES_VIEW_ALL_OPTIONS = 'PRODUCT_PAGE::PRODUCT_SWATCHES_VIEW_ALL_OPTIONS';
export const PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS = 'PRODUCT_PAGE::PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS';
export const PRODUCT_SWATCHES_MAX_HEIGHT = 'PRODUCT_PAGE::PRODUCT_SWATCHES_MAX_HEIGHT';
export const PRODUCT_SWATCHES_WIDTH_AND_MARGIN = 'PRODUCT_PAGE::PRODUCT_SWATCHES_WIDTH_AND_MARGIN';
export const PRODUCT_SWATCHES_COUNT_PER_ROW = 'PRODUCT_PAGE::PRODUCT_SWATCHES_COUNT_PER_ROW';
export const PRODUCT_PAGE_MODAL_OPEN = 'PRODUCT_PAGE::PRODUCT_PAGE_MODAL_OPEN';
export const PRODUCT_PAGE_MODAL_CLOSE = 'PRODUCT_PAGE::PRODUCT_PAGE_MODAL_CLOSE';
export const PRODUCT_THUMBNAILIMAGE_SELECT = 'PRODUCT_PAGE::PRODUCT_THUMBNAILIMAGE_SELECT';
export const PRODUCT_POWERREVIEW_READY_FLAG = 'PRODUCT_PAGE::POWERREVIEW_READY_FLAG';
export const PRODUCT_ADD_TO_FAV = 'PRODUCT_PAGE::ADD_TO_FAV';
export const PRODUCT_MAINIMAGE_LOADER = 'PRODUCT_PAGE::PRODUCT_MAINIMAGE_LOADER';
/**
 * ACTIONS
 */
export const setProductRightPanelCollapse = ( panelID ) => ( { type: PRODUCT_RIGHT_PANEL_COLLAPSE, panelID } );
export const toggleProductSwatchesViewAllOption = () => ( { type: PRODUCT_SWATCHES_VIEW_ALL_OPTIONS } );
export const setProductSwatchesDiplayMoreOptions = ( display ) => ( { type: PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS, display } );
export const setProductSwatchesMaxHeight = ( height ) => ( { type: PRODUCT_SWATCHES_MAX_HEIGHT, height } );
export const setSectionWidthAndCellMargin = ( data ) => ( { type: PRODUCT_SWATCHES_WIDTH_AND_MARGIN, data } );
export const setProductSwatchesCountPerRow = ( count ) => ( { type: PRODUCT_SWATCHES_COUNT_PER_ROW, count } );
export const openProductPageModal = ( modalID ) => ( { type: PRODUCT_PAGE_MODAL_OPEN, modalID } );
export const closeProductPageModal = ( modalID ) => ( { type: PRODUCT_PAGE_MODAL_CLOSE, modalID } );
export const selectThumbnailImage = ( thumbnailIndex )=>( { type: PRODUCT_THUMBNAILIMAGE_SELECT, thumbnailIndex } );
export const enablePowerReviewReadyFlag = () => ( { type: PRODUCT_POWERREVIEW_READY_FLAG } );
export const setMainImageLoader = ( ) => ( { type: PRODUCT_MAINIMAGE_LOADER } );