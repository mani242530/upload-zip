/**
 * Test for ProductDetails actions
 */
import _ from 'lodash';
import * as events from './product_detail.events';

describe( 'ProductDetails action types', () => {

  describe( 'Product Right panel Collapse', () => {
    it( 'The action type should exist', () => {
      expect( events.PRODUCT_RIGHT_PANEL_COLLAPSE ).toBe( 'PRODUCT_PAGE::PDP_RIGHT_PANEL_COLLAPSE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setProductRightPanelCollapse ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.setProductRightPanelCollapse();
      expect( creator ).toEqual( {
        type: events.PRODUCT_RIGHT_PANEL_COLLAPSE
      } )
    } );
  } );
  describe( 'toogle view more product swatches option', () => {
    it( 'The action type should exist', () => {
      expect( events.PRODUCT_SWATCHES_VIEW_ALL_OPTIONS ).toBe( 'PRODUCT_PAGE::PRODUCT_SWATCHES_VIEW_ALL_OPTIONS' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.toggleProductSwatchesViewAllOption ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object - toogle product swatch option', () => {
      let creator = events.toggleProductSwatchesViewAllOption();
      expect( creator ).toEqual( {
        type: events.PRODUCT_SWATCHES_VIEW_ALL_OPTIONS
      } )
    } );
  } );
  describe( 'set view more product swatches option', () => {
    it( 'The action type should exist', () => {
      expect( events.PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS ).toBe( 'PRODUCT_PAGE::PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setProductSwatchesDiplayMoreOptions ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object - action : setProductSwatchesDiplayMoreOptions', () => {
      let creator = events.setProductSwatchesDiplayMoreOptions();
      expect( creator ).toEqual( {
        type: events.PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS
      } )
    } );
  } );
  describe( 'set max height for the product swatches in mobile view', () => {
    it( 'The action type should exist', () => {
      expect( events.PRODUCT_SWATCHES_MAX_HEIGHT ).toBe( 'PRODUCT_PAGE::PRODUCT_SWATCHES_MAX_HEIGHT' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setProductSwatchesMaxHeight ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object - action : setProductSwatchesMaxHeight', () => {
      let creator = events.setProductSwatchesMaxHeight();
      expect( creator ).toEqual( {
        type: events.PRODUCT_SWATCHES_MAX_HEIGHT
      } )
    } );
  } );
  describe( 'set width and cell margin for the product swatches in mobile view', () => {
    it( 'The action type should exist', () => {
      expect( events.PRODUCT_SWATCHES_WIDTH_AND_MARGIN ).toBe( 'PRODUCT_PAGE::PRODUCT_SWATCHES_WIDTH_AND_MARGIN' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setSectionWidthAndCellMargin ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object - action : setSectionWidthAndCellMargin', () => {
      let creator = events.setSectionWidthAndCellMargin();
      expect( creator ).toEqual( {
        type: events.PRODUCT_SWATCHES_WIDTH_AND_MARGIN
      } )
    } );
  } );

  describe( 'test cases for swatches count per row', () => {
    it( 'The action type should exist', () => {
      expect( events.PRODUCT_SWATCHES_COUNT_PER_ROW ).toBe( 'PRODUCT_PAGE::PRODUCT_SWATCHES_COUNT_PER_ROW' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setProductSwatchesCountPerRow ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object - action : setProductSwatchesCountPerRow', () => {
      let creator = events.setProductSwatchesCountPerRow();
      expect( creator ).toEqual( {
        type: events.PRODUCT_SWATCHES_COUNT_PER_ROW
      } )
    } );
  } );

  describe( 'test cases for Modal open', () => {
    it( 'The action type should exist', () => {
      expect( events.PRODUCT_PAGE_MODAL_OPEN ).toBe( 'PRODUCT_PAGE::PRODUCT_PAGE_MODAL_OPEN' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.openProductPageModal ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object - action : openProductPageModal', () => {
      let creator = events.openProductPageModal();
      expect( creator ).toEqual( {
        type: events.PRODUCT_PAGE_MODAL_OPEN
      } )
    } );
  } );

  describe( 'test cases for Modal Close', () => {
    it( 'The action type should exist', () => {
      expect( events.PRODUCT_PAGE_MODAL_CLOSE ).toBe( 'PRODUCT_PAGE::PRODUCT_PAGE_MODAL_CLOSE' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.closeProductPageModal ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object - action : closeProductPageModal', () => {
      let creator = events.closeProductPageModal();
      expect( creator ).toEqual( {
        type: events.PRODUCT_PAGE_MODAL_CLOSE
      } )
    } );
  } );

  describe( 'enablePowerReviewReadyFlag', () => {
    it( 'The action type should exist', () => {
      expect( events.PRODUCT_POWERREVIEW_READY_FLAG ).toBe( 'PRODUCT_PAGE::POWERREVIEW_READY_FLAG' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.enablePowerReviewReadyFlag ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.enablePowerReviewReadyFlag();
      expect( creator ).toEqual( {
        type: events.PRODUCT_POWERREVIEW_READY_FLAG
      } )
    } );
  } );

  it( 'The action type for add to favourite should exist', () => {
    expect( events.PRODUCT_ADD_TO_FAV ).toBe( 'PRODUCT_PAGE::ADD_TO_FAV' );
  } );

  describe( 'setMainImageLoader', () => {
    it( 'The action type should exist', () => {
      expect( events.PRODUCT_MAINIMAGE_LOADER ).toBe( 'PRODUCT_PAGE::PRODUCT_MAINIMAGE_LOADER' );
    } );
    it( 'The action creator function should exist', () => {
      expect( _.isFunction( events.setMainImageLoader ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.setMainImageLoader();
      expect( creator ).toEqual( {
        type: events.PRODUCT_MAINIMAGE_LOADER
      } )
    } );
  } );

} )
