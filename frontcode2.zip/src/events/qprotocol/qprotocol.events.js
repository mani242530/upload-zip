
/**
 * Services Actions
 *
 * This file defines the action types and action creators for QProtocol
 **/


/**
 * ACTION TYPES
 */
export const TRIGGER_BASKET_EVENTS = 'QPROTOCOL::TRIGGER_BASKET_EVENTS'


/**
 * ACTIONS
 */
export const triggerBasketEvents = ( source, data ) => ( { type: TRIGGER_BASKET_EVENTS, source, data } )
