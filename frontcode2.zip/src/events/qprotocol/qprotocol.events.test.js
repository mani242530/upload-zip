
/**
 * Test for Language actions
 */

import _ from 'lodash';
import * as events from './qprotocol.events';


describe( 'QProtocol action types', () => {
  it( 'The TRIGGER_BASKET_EVENTS action  should be the right value', () => {
    expect( events.TRIGGER_BASKET_EVENTS ).toBe( 'QPROTOCOL::TRIGGER_BASKET_EVENTS' );
  } );
} );

describe( 'QProtocol action creators', () => {
  it( 'TRIGGER_BASKET_EVENTS should exist', () => {
    expect( _.isFunction( events.triggerBasketEvents ) ).toBe( true );
  } );
} );

describe( 'QProtocol actions', () => {
  it( 'should create the proper action for triggerBasketEvents', () => {
    const source = 'en';
    const data = 1;
    const creator = events.triggerBasketEvents( source, data );
    expect( creator ).toEqual( {
      type: events.TRIGGER_BASKET_EVENTS,
      source:source,
      data:data
    } );
  } );
} );
