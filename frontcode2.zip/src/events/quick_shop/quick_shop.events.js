
/**
 * Footer Actions
 *
 * This file defines the action types and action creators for add to bag modal
 **/


/**
 * ACTION TYPES
 */
export const CLOSE_QUICK_SHOP_MODAL = 'QUICK_SHOP::CLOSE_MODAL';
export const PRODUCT_SWATCHES_MAX_HEIGHT = 'QUICK_SHOP::PRODUCT_SWATCHES_MAX_HEIGHT';

/**
 * ACTIONS
 */
export const closeQuickShopModal = () => ( { type: CLOSE_QUICK_SHOP_MODAL } );
export const setProductSwatchesMaxHeight = ( height ) => ( { type: PRODUCT_SWATCHES_MAX_HEIGHT, height } );