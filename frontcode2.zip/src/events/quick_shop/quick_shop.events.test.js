
import _ from 'lodash';
import * as events from './quick_shop.events';


describe( 'QuickShop action types', () => {
  it( 'expect all types to be defined', () => {
    expect( events.CLOSE_QUICK_SHOP_MODAL ).toBe( 'QUICK_SHOP::CLOSE_MODAL' );
  } );
} );

describe( 'QuickShop actions', () => {

  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.closeQuickShopModal ) ).toBe( true );
  } );

  it( 'should create the proper action for closeQuickShopModal', () => {
    let creator = events.closeQuickShopModal();
    expect( creator ).toEqual( {
      type: events.CLOSE_QUICK_SHOP_MODAL
    } )
  } );

  it( 'should create the proper action for setProductSwatchesMaxHeight', () => {
    let creator = events.setProductSwatchesMaxHeight();
    expect( creator ).toEqual( {
      type: events.PRODUCT_SWATCHES_MAX_HEIGHT
    } )
  } );

} );
