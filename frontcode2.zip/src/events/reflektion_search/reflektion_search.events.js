/**
 * ReflektionSearch Actions
 *
 * This file defines the action and action creators for 'ReflektionSearch'
 **/


/**
 * ACTION TYPES
 */

export const CLOSE_REFLEKTION_SEARCH_MODEL = 'REFLEKTION_SEARCH::CLOSE_REFLEKTION_SEARCH_MODEL';
export const UPDATE_TOP_RESULT = 'REFLEKTION_SEARCH::UPDATE_TOP_RESULT';
/**
 * ACTIONS
 */
export const closeReflektionSearchModal = ( data ) => ( { type: CLOSE_REFLEKTION_SEARCH_MODEL, data } );
export const updateTopResult = ( suggestionName ) => ( { type: UPDATE_TOP_RESULT, suggestionName } );
