
import _ from 'lodash';
import * as events from './reflektion_search.events';

describe( 'Reflektion search action type', () => {

  describe( 'Close reflektion search modal', () => {
    it( 'The CLOSE_REFLEKTION_SEARCH_MODEL action  should be the right value', () => {
      expect( events.CLOSE_REFLEKTION_SEARCH_MODEL ).toBe( 'REFLEKTION_SEARCH::CLOSE_REFLEKTION_SEARCH_MODEL' );
    } );
    it( 'CLOSE_REFLEKTION_SEARCH_MODELS should exist', () => {
      expect( _.isFunction( events.closeReflektionSearchModal ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      const data = {
        'searchTerm':'lips'
      };
      let creator = events.closeReflektionSearchModal( data );
      expect( creator ).toEqual( {
        type: events.CLOSE_REFLEKTION_SEARCH_MODEL,
        data:data
      } )
    } );
  } );
  describe( 'Update top results', () => {
    it( 'The CLOSE_REFLEKTION_SEARCH_MODEL action  should be the right value', () => {
      expect( events.UPDATE_TOP_RESULT ).toBe( 'REFLEKTION_SEARCH::UPDATE_TOP_RESULT' );
    } );
    it( 'UPDATE_TOP_RESULT should exist', () => {
      expect( _.isFunction( events.updateTopResult ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.updateTopResult();
      expect( creator ).toEqual( {
        type: events.UPDATE_TOP_RESULT
      } )
    } );
  } );
} )
