import _ from 'lodash';
import * as events from './reset_credentials_form.events';

describe( 'ResetCredentialsForm action types', () => {
  it( 'expect all types to be defined', () => {
    expect( events.CLOSE_RESPONSE_MESSAGE_SECTION ).toBe( 'RESETCREDENTIALSFORM::CLOSE_RESPONSE_MESSAGE_SECTION' );
  } );
} );

describe( 'ResetCredentialsForm actions', () => {

  it( 'should have action creators defined', () => {
    expect( _.isFunction( events.closeResponseMessageSection ) ).toBe( true );
  } );

  it( 'should create the proper action for closeResponseMessageSection', () => {
    let creator = events.closeResponseMessageSection();
    expect( creator ).toEqual( {
      type: events.CLOSE_RESPONSE_MESSAGE_SECTION
    } )
  } );

} );
