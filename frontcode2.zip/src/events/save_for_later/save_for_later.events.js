/**
 * SaveForLater Actions
 *
 * This file defines the action types and action creators for 'SaveForLater'
 **/


/**
 * ACTION TYPES
 */
export const MOVE_ITEM_TO_SAVE_FOR_LATER = 'SAVE_FOR_LATER::MOVE_ITEM_TO_SAVE_FOR_LATER';
export const SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE = 'SAVE_FOR_LATER::SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE';
export const SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE = 'SAVE_FOR_LATER::SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE';
export const MOVE_TO_SFL = 'SAVE_FOR_LATER::MOVE_TO_SFL'; // constant to indicate item moved from cart to SFL section action
export const ADD_TO_SFL = 'SAVE_FOR_LATER::ADD_TO_SFL' ;// constant to indicate item added to SFL section action
export const SFL_ITEM_ADDED = 'SAVE_FOR_LATER::SFL_ITEM_ADDED'; // constant to indicate not to update save for later items

/**
 * ACTIONS
 */
export const moveItemToSaveForLater = ( data ) => ( { type: MOVE_ITEM_TO_SAVE_FOR_LATER, data } );
export const showSaveForLaterRemovedSuccessMessage = ( data ) => ( { type: SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE, data } );
export const showMovedToBagSuccessMessage = ( data ) => ( { type: SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE, data } );
export const sflItemAdded = () => ( { type: SFL_ITEM_ADDED } );
