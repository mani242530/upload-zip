/**
 * Test for SaveForLater actions
 */

import isFunction from 'lodash/isFunction';
import * as events from './save_for_later.events';


describe( 'SaveForLater actions/types', () => {

  describe( 'show Save For Later item removed success message', () => {

    it( 'The action type should exist', () => {
      expect( events.SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE ).toBe( 'SAVE_FOR_LATER::SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.showSaveForLaterRemovedSuccessMessage ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = '123';
      const creator = events.showSaveForLaterRemovedSuccessMessage( data );
      expect( creator ).toEqual( {
        type: events.SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE,
        data
      } )
    } );
  } );

  describe( 'move Item To Save For Later', () => {

    it( 'The action type should exist', () => {
      expect( events.MOVE_ITEM_TO_SAVE_FOR_LATER ).toBe( 'SAVE_FOR_LATER::MOVE_ITEM_TO_SAVE_FOR_LATER' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.moveItemToSaveForLater ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = {
        movedItems:{
          saveForLater: {
            saveForLaterItems: {
              items: [
                {
                  sflItemId: 'testSflItemId'
                }
              ]
            }
          }
        }
      };
      const creator = events.moveItemToSaveForLater( data );
      expect( creator ).toEqual( {
        type: events.MOVE_ITEM_TO_SAVE_FOR_LATER,
        data
      } )
    } );
  } );

  describe( 'show SFL item moved to bag success message ', () => {

    it( 'The action type should exist', () => {
      expect( events.SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE ).toBe( 'SAVE_FOR_LATER::SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE' );
    } );

    it( 'The action creator function should exist', () => {
      expect( isFunction( events.showMovedToBagSuccessMessage ) ).toBe( true );
    } );

    it( 'The action creator function should return the proper action creator object', () => {
      const data = 'gi135660020';
      const creator = events.showMovedToBagSuccessMessage( data );
      expect( creator ).toEqual( {
        type: events.SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE,
        data
      } );
    } );

  } );

  describe( 'MOVE_TO_SFL action', () => {

    it( 'The action type should exist', () => {
      expect( events.MOVE_TO_SFL ).toBe( 'SAVE_FOR_LATER::MOVE_TO_SFL' );
    } );

  } );

  describe( 'ADD_TO_SFL action', () => {

    it( 'The action type should exist', () => {
      expect( events.ADD_TO_SFL ).toBe( 'SAVE_FOR_LATER::ADD_TO_SFL' );
    } );

  } );

  describe( 'SFL_ITEM_ADDED action', () => {

    it( 'The action type should exist', () => {
      expect( events.SFL_ITEM_ADDED ).toBe( 'SAVE_FOR_LATER::SFL_ITEM_ADDED' );
    } );

  } );

  describe( 'The action creator function should exist', () => {
    it( 'sflItemAdded should exist', () => {
      expect( isFunction( events.sflItemAdded ) ).toBe( true );
    } );
  } );

  describe( 'Live actions', () => {
    it( 'should create the proper action for sflItemAdded', () => {
      const creator = events.sflItemAdded( );
      expect( creator ).toEqual( {
        type: events.SFL_ITEM_ADDED
      } );
    } );
  } );

} );
