/**
 * Search Menu Actions
 *
 * This file defines the action and action creators for 'Search Menu'
 **/


/**
 * ACTION TYPES
 */

export const TOGGLE_MOBILE_SEARCH =  'SEARCH_MENU::TOGGLE_MOBILE_SEARCH'

/**
 * ACTIONS
 */
export const toggleMobileSearch = () => ( { type: TOGGLE_MOBILE_SEARCH } );