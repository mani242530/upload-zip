
import _ from 'lodash';
import * as events from './search_menu.events';

describe( 'Search Menu action type', () => {

  describe( 'Toggle Mobile Search', () => {
    it( 'The TOGGLE_MOBILE_SEARCH action  should be the right value', () => {
      expect( events.TOGGLE_MOBILE_SEARCH ).toBe( 'SEARCH_MENU::TOGGLE_MOBILE_SEARCH' );
    } );
    it( 'TOGGLE_MOBILE_SEARCH should exist', () => {
      expect( _.isFunction( events.toggleMobileSearch ) ).toBe( true );
    } );
    it( 'The action creator function should return the proper action creator object', () => {
      let creator = events.toggleMobileSearch();
      expect( creator ).toEqual( {
        type: events.TOGGLE_MOBILE_SEARCH
      } )
    } );
  } );
} )
