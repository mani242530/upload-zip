/**
 * SignInModal Actions
 *
 * This file defines the action types and action creators for 'SignInModal'
 **/


/**
 * ACTION TYPES
 */
export const OPEN_SIGN_IN_MODAL = 'SAVE_FOR_LATER::OPEN_SIGN_IN_MODAL';
export const CLOSE_SIGN_IN_MODAL = 'SAVE_FOR_LATER::CLOSE_SIGN_IN_MODAL';
/**
 * ACTIONS
 */
export const openSignInModal = ( data ) => ( { type: OPEN_SIGN_IN_MODAL, data } );
export const closeSignInModal = ( ) => ( { type: CLOSE_SIGN_IN_MODAL } );
