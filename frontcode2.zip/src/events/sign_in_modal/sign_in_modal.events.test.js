/**
 * Test for SignInModal actions
 */

import isFunction from 'lodash/isFunction';
import * as events from './sign_in_modal.events';

describe( 'SignInModal actions/types', () => {

  describe( 'toggle Sign In Modal', () => {

    it( 'The action type OPEN_SIGN_IN_MODAL should exist', () => {
      expect( events.OPEN_SIGN_IN_MODAL ).toBe( 'SAVE_FOR_LATER::OPEN_SIGN_IN_MODAL' );
    } );
    it( 'The action type CLOSE_SIGN_IN_MODAL should exist', () => {
      expect( events.CLOSE_SIGN_IN_MODAL ).toBe( 'SAVE_FOR_LATER::CLOSE_SIGN_IN_MODAL' );
    } );

    it( 'The action creator openSignInModal function should exist', () => {
      expect( isFunction( events.openSignInModal ) ).toBe( true );
    } );
    it( 'The action creator closeSignInModal function should exist', () => {
      expect( isFunction( events.closeSignInModal ) ).toBe( true );
    } );

    it( 'The action creator openSignInModal function should return the proper action creator object', () => {
      const data = true;
      const creator = events.openSignInModal( data );
      expect( creator ).toEqual( {
        type: events.OPEN_SIGN_IN_MODAL,
        data
      } )
    } );

    it( 'The action creator closeSignInModal function should return the proper action creator object', () => {
      const creator = events.closeSignInModal();
      expect( creator ).toEqual( {
        type: events.CLOSE_SIGN_IN_MODAL
      } )
    } );

  } );

} )
