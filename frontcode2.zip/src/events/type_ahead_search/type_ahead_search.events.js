/**
 * TypeAheadSearch Actions
 *
 * This file defines the action types and action creators for 'TypeAheadSearch'
 **/


/**
 * ACTION TYPES
 */
export const RESET_INPUT_VALUE = 'TYPE_AHEAD_SEARCH::RESET_INPUT_VALUE';
export const SET_INPUT_WIDTH = 'TYPE_AHEAD_SEARCH::SET_INPUT_WIDTH';
export const UPDATE_INPUT_VALUE = 'TYPE_AHEAD_SEARCH::UPDATE_INPUT_VALUE';
export const CLEAR_SUGGESTIONS = 'TYPE_AHEAD_SEARCH::CLEAR_SUGGESTIONS';
export const SET_SEARCH_RESULTS_HEIGHT = 'TYPE_AHEAD_SEARCH::SET_SEARCH_RESULTS_HEIGHT';
export const LOAD_SUGGESTIONS_BEGIN = 'TYPE_AHEAD_SEARCH::LOAD_SUGGESTIONS_BEGIN';
export const MAYBE_UPDATE_SUGGESTIONS = 'TYPE_AHEAD_SEARCH::MAYBE_UPDATE_SUGGESTIONS';
export const REQUEST_SEARCH_RESULTS = 'TYPE_AHEAD_SEARCH::REQUEST_SEARCH_RESULTS';
export const UPDATE_NAVIGATION_STATE_URL = 'TYPE_AHEAD_SEARCH::UPDATE_NAVIGATION_STATE_URL';


/**
 * ACTIONS
 */
export const setSearchResultsHeight = ( offset, screenHeight ) => ( { type: SET_SEARCH_RESULTS_HEIGHT, offset, screenHeight } );
export const setInputWidth = ( cancelBtnWidth, containerWidth, deviceWidth ) => ( {
  type:SET_INPUT_WIDTH, cancelBtnWidth, containerWidth, deviceWidth
} );
export const updateInputValue = ( value ) => ( { type: UPDATE_INPUT_VALUE, value } );
export const requestSearchResults = ( query ) => ( { type: REQUEST_SEARCH_RESULTS, query } );
export const onSuggestionsClearRequested = () => ( { type: CLEAR_SUGGESTIONS } );
export const resetSearchInputValue = () => ( { type: RESET_INPUT_VALUE } );
export const navigationStateURL = ( data, label ) => ( { type: UPDATE_NAVIGATION_STATE_URL, data, label } );
