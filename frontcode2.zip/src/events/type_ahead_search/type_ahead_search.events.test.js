/**
 * Test for TypeAheadSearch actions
 */

import _ from 'lodash';
import * as events from './type_ahead_search.events';




describe( 'TypeAheadSearch action types', () => {
  it( 'expect all types to be defined', () => {
    expect( events.RESET_INPUT_VALUE ).toBe( 'TYPE_AHEAD_SEARCH::RESET_INPUT_VALUE' );
    expect( events.SET_INPUT_WIDTH ).toBe( 'TYPE_AHEAD_SEARCH::SET_INPUT_WIDTH' );
    expect( events.UPDATE_INPUT_VALUE ).toBe( 'TYPE_AHEAD_SEARCH::UPDATE_INPUT_VALUE' );
    expect( events.CLEAR_SUGGESTIONS ).toBe( 'TYPE_AHEAD_SEARCH::CLEAR_SUGGESTIONS' );
    expect( events.SET_SEARCH_RESULTS_HEIGHT ).toBe( 'TYPE_AHEAD_SEARCH::SET_SEARCH_RESULTS_HEIGHT' );
    expect( events.LOAD_SUGGESTIONS_BEGIN ).toBe( 'TYPE_AHEAD_SEARCH::LOAD_SUGGESTIONS_BEGIN' );
    expect( events.MAYBE_UPDATE_SUGGESTIONS ).toBe( 'TYPE_AHEAD_SEARCH::MAYBE_UPDATE_SUGGESTIONS' );
    expect( events.REQUEST_SEARCH_RESULTS ).toBe( 'TYPE_AHEAD_SEARCH::REQUEST_SEARCH_RESULTS' );
    expect( events.UPDATE_NAVIGATION_STATE_URL ).toBe( 'TYPE_AHEAD_SEARCH::UPDATE_NAVIGATION_STATE_URL' );
  } );
} );

describe( 'TypeAhead actions', () => {

  it( 'sould have action creators defined', () => {
    expect( _.isFunction( events.setSearchResultsHeight ) ).toBe( true );
    expect( _.isFunction( events.setInputWidth ) ).toBe( true );
    expect( _.isFunction( events.updateInputValue ) ).toBe( true );
    expect( _.isFunction( events.requestSearchResults ) ).toBe( true );
    expect( _.isFunction( events.onSuggestionsClearRequested ) ).toBe( true );
    expect( _.isFunction( events.resetSearchInputValue ) ).toBe( true );
    expect( _.isFunction( events.navigationStateURL ) ).toBe( true );
  } );

  it( 'should create the proper action for setSearchResultsHeight', () => {
    let creator = events.setSearchResultsHeight( 11, 0 );
    expect( creator ).toEqual( {
      type: events.SET_SEARCH_RESULTS_HEIGHT,
      offset: 11,
      screenHeight: 0
    } )
  } );

  it( 'should create the proper action for setInputWidth', () => {
    let creator = events.setInputWidth( 11, 0, 321 );
    expect( creator ).toEqual( {
      type: events.SET_INPUT_WIDTH,
      cancelBtnWidth: 11,
      containerWidth: 0,
      deviceWidth: 321
    } )
  } );

  it( 'should create the proper action for updateInputValue', () => {
    let creator = events.updateInputValue( 'newValue' );
    expect( creator ).toEqual( {
      type: events.UPDATE_INPUT_VALUE,
      value: 'newValue'
    } )
  } );

  it( 'should create the proper action for requestSearchResults', () => {
    let creator = events.requestSearchResults( 'abc' );
    expect( creator ).toEqual( {
      type: events.REQUEST_SEARCH_RESULTS,
      query: 'abc'
    } )
  } );

  it( 'should create the proper action for onSuggestionsClearRequested', () => {
    let creator = events.onSuggestionsClearRequested();
    expect( creator ).toEqual( {
      type: events.CLEAR_SUGGESTIONS
    } )
  } );

  it( 'should create the proper action for resetSearchInputValue', () => {
    let creator = events.resetSearchInputValue();
    expect( creator ).toEqual( {
      type: events.RESET_INPUT_VALUE
    } )
  } );

  it( 'should create the proper action for navigationStateURL', () => {
    let creator = events.navigationStateURL( '/nails?N=271o', 'MakeUp > lipstick' );
    expect( creator ).toEqual( {
      type: events.UPDATE_NAVIGATION_STATE_URL,
      data: '/nails?N=271o',
      label: 'MakeUp > lipstick'
    } )
  } );

} );
