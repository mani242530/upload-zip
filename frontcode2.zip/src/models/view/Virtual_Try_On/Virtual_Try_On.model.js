import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  getNextStateOnProductSuccess,
  setEligibilityDetails
} from '../product_page/product_page.model';
import {
  PRODUCT_SWATCHES_VIEW_ALL_OPTIONS,
  PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS,
  PRODUCT_SWATCHES_MAX_HEIGHT,
  PRODUCT_SWATCHES_COUNT_PER_ROW
} from '../../../events/product_detail/product_detail.events';
export const initialState = {
  virtualTryOnEnable:true,
  productDetails: null,
  isValidProduct:false,
  isEmailMeModalOpen:false,
  isProductUnavailable:undefined,
  addToBagErrorMessages:null,
  breadCrumbLinks:undefined,
  viewAllOption: false,
  displayMoreOptions:false,
  // swatchesCountPerRow will be the number of elements that can be accomodated in a row for mobile view
  // initializing to a hight count, and the actual value  will be set in the code based on the width
  swatchesCountPerRow:999,
  swatchesSectionMaxHeight:'none'
};
export default function reducer( state = initialState, action ){

  switch ( action.type ){

    case getServiceType( 'pdpProductDetails', 'success' ):
      return {
        ...state,
        virtualTryOnEnable:true,
        ...getNextStateOnProductSuccess( action.data, state )
      }
    case getServiceType( 'pdpPurchaseEligibility', 'success' ):
      return {
        ...state,
        productDetails: {
          ...state.productDetails,
          purchaseEligibility: setEligibilityDetails( action.data ),
          sku: {
            ...state.productDetails.sku,
            favoriteId: action.data.favoriteId
          }
        }
      }
    case getServiceType( 'pdpEmailNotification', 'success' ):
      return {
        ...state,
        productDetails: {
          ...state.productDetails,
          purchaseEligibility: {
            ...state.productDetails.purchaseEligibility,
            isNotifyMeEligible:false,
            availabilityMessage1:null,
            emailStockNotifyMessage: action.data.messages.items[0].message
          }
        }
      }
    case getServiceType( 'pdpAddFavorite', 'success' ):
      return {
        ...state,
        productDetails:{
          ...state.productDetails,
          sku: {
            ...state.productDetails.sku,
            favoriteId: action.data.favoriteId,
            addToFavoriteErrorMessages:action.data.messages
          }
        }
      }
    case getServiceType( 'pdpRemoveFavorite', 'success' ):
      return {
        ...state,
        productDetails:{
          ...state.productDetails,
          sku: {
            ...state.productDetails.sku,
            favoriteId: null
          }
        }
      }
    case getServiceType( 'pdpSkuDetails', 'requested' ):
    case getServiceType( 'pdpAddItem', 'requested' ):
      return {
        ...state,
        addToBagErrorMessages:null
      }
    case getServiceType( 'pdpAddItem', 'success' ):
      return {
        ...state,
        ...( action.data.responseData.messages && { addToBagErrorMessages:action.data.responseData.messages } )
      }
    case PRODUCT_SWATCHES_VIEW_ALL_OPTIONS:
      return {
        ...state,
        viewAllOption: !state.viewAllOption
      }
    case PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS:
      return {
        ...state,
        displayMoreOptions: action.display
      }
    case PRODUCT_SWATCHES_COUNT_PER_ROW:
      return {
        ...state,
        swatchesCountPerRow: action.count
      }
    case PRODUCT_SWATCHES_MAX_HEIGHT:
      return {
        ...state,
        swatchesSectionMaxHeight: action.height
      }

    default:
      return state;
  }
}
