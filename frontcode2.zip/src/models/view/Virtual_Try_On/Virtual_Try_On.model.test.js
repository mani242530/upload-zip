import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import _ from 'lodash';
import {
  PRODUCT_SWATCHES_VIEW_ALL_OPTIONS,
  PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS,
  PRODUCT_SWATCHES_COUNT_PER_ROW,
  PRODUCT_SWATCHES_MAX_HEIGHT
} from '../../../events/product_detail/product_detail.events';

import reducer, {
  initialState
} from './Virtual_Try_On.model';

describe( 'Product Page reducer', ( ) => {
  const serviceType = 'pdpProductDetails';
  registerServiceName( serviceType );
  registerServiceName( 'switches' );
  registerServiceName( 'pdpSkuDetails' );
  registerServiceName( 'pdpPurchaseEligibility' );
  registerServiceName( 'pdpSkuDynamicData' );
  registerServiceName( 'pdpAddItem' );
  registerServiceName( 'pdpRemoveFromFavorites' );
  registerServiceName( 'pdpFindFavorite' );
  registerServiceName( 'pdpAddFavorite' );
  registerServiceName( 'pdpRemoveFavorite' );
  registerServiceName( 'pdpEmailNotification' );
  registerServiceName( 'pdpProductRecs' );

  it( 'should have the proper default state', ( ) => {
    let expectedState = {
      virtualTryOnEnable:true,
      productDetails: null,
      isValidProduct:false,
      isEmailMeModalOpen:false,
      isProductUnavailable:undefined,
      addToBagErrorMessages:null,
      breadCrumbLinks:undefined,
      viewAllOption: false,
      displayMoreOptions:false,
      swatchesCountPerRow:999,
      swatchesSectionMaxHeight:'none'
    }
    expect( initialState ).toEqual( expectedState );
  } )

  it( 'should be a function', ( ) => {
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  it( 'should view all the swatch options on the event PRODUCT_SWATCHES_VIEW_ALL_OPTIONS', ( ) => {

    let state = {
      viewAllOption: false
    }

    let actionCreator = {
      type: PRODUCT_SWATCHES_VIEW_ALL_OPTIONS,
      viewAllOption: false
    }

    let expectedOutput = { viewAllOption: true };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Should display swatches section on the event PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS', () => {

    const actionCreator = {
      type: PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS,
      display:true
    }
    let state = {
      displayMoreOptions:false
    }
    let expectedOutput = { displayMoreOptions: true };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Should set swatches section max height on event PRODUCT_SWATCHES_MAX_HEIGHT', () => {

    const actionCreator = {
      type: PRODUCT_SWATCHES_MAX_HEIGHT,
      height : '30px'
    }

    let expectedOutput = { swatchesSectionMaxHeight: '30px' };
    let state = {
      swatchesSectionMaxHeight:'10px'
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Should set swatchesCountPerRow on the event PRODUCT_SWATCHES_COUNT_PER_ROW', () => {

    const actionCreator = {
      type: PRODUCT_SWATCHES_COUNT_PER_ROW,
      count:5
    }
    let state = {
      swatchesCountPerRow:999
    }
    let expectedOutput = { swatchesCountPerRow: 5 };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should execute case getServiceType( \'pdpEmailNotification\', \'success\' )', ( ) => {
    let state = {
      productDetails: {
        sku:{}
      }
    }
    let res = {
      success:true,
      messages:{
        items:[{
          message:'Okay! We\'ve got you down to be emailed when this item is back in stock.',
          type:'Info'
        }]
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpEmailNotification', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        purchaseEligibility:{
          isNotifyMeEligible:false,
          availabilityMessage1:null,
          emailStockNotifyMessage:'Okay! We\'ve got you down to be emailed when this item is back in stock.'
        },
        sku: {}
      }
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  describe( 'add Favorite Sku', ( ) => {
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }

    let expectedOutput = {
      productDetails: {
        id:1,
        sku : {
          id:12,
          favoriteId: 'gi60001',
          'addToFavoriteErrorMessages':{
            items:[{
              message:'test message',
              type:'Info'
            }]
          }
        }
      }
    };
    it( ' should execute case getServiceType( \'addFavorite\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'pdpAddFavorite', 'success' ),
        data: {
          favoriteId: 'gi60001',
          messages:{
            items:[{
              message:'test message',
              type:'Info'
            }]
          }
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'remove Favorite Sku', ( ) => {
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }

    let expectedOutput = {
      productDetails: {
        id:1,
        sku : {
          id:12,
          favoriteId: null
        }
      }
    };
    it( ' should execute case getServiceType( \'removeFavorite\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'pdpRemoveFavorite', 'success' ),
        data: {
          favoriteId: null
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );
  it( 'should execute case getServiceType( \'pdpAddItem\', \'requested\' )- and reset error message', ( ) => {

    let actionCreator = {
      type: getServiceType( 'pdpAddItem', 'requested' )
    }
    let state = {
      productDetails:{},
      isAddToBagModalOpen:false,
      addToBagErrorMessages:{
        items:[{
          message:'That quantity is currently unavailable. Please choose 5 or less.',
          type:'Error'
        }]
      }
    }
    let expectedOutput = {
      productDetails:{},
      isAddToBagModalOpen:false,
      addToBagErrorMessages:null
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpSkuDetails\', \'requested\' )- and reset error message', ( ) => {

    let actionCreator = {
      type: getServiceType( 'pdpSkuDetails', 'requested' )
    }
    let state = {
      productDetails:{},
      isAddToBagModalOpen:false,
      addToBagErrorMessages:{
        items:[{
          message:'That quantity is currently unavailable. Please choose 5 or less.',
          type:'Error'
        }]
      }
    }
    let expectedOutput = {
      productDetails:{},
      isAddToBagModalOpen:false,
      addToBagErrorMessages:null
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );
  it( 'should execute case getServiceType( \'pdpAddItem\', \'success\' )- return error message', ( ) => {
    let res = {
      success:false,
      responseData:{
        messages:{
          items:[{
            message:'That quantity is currently unavailable. Please choose 5 or less.',
            type:'Error'
          }]
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpAddItem', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails:{},
      isAddToBagModalOpen:false,
      addToBagErrorMessages:{
        items:[{
          message:'That quantity is currently unavailable. Please choose 5 or less.',
          type:'Error'
        }]
      }
    };
    let state = {
      productDetails:{},
      isAddToBagModalOpen:false
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );
  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' )', ( ) => {
    let res = {
      eligibilityState: 0,
      favoriteId: 'gi60001',
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:true,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: false,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null
        },
        sku : {
          id:12,
          favoriteId: 'gi60001'
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 1', ( ) => {
    let res = {
      eligibilityState: 1,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:true,
          isInStoreOnlyProduct:false,
          isNotAvailable: false,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null
        },
        sku : {
          id:12,
          favoriteId: undefined
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 2', ( ) => {
    let res = {
      eligibilityState: 2,
      messages: {
        items:[{
          message:'sign in to see if you are eligible',
          type:'Info'
        }]
      }
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: false,
          isPlatinumAndUserAnonymous: true,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:'sign in to see if you are eligible',
          comingSoonDate:null,
          inStoreDate:null
        },
        sku : {
          id:12,
          favoriteId: undefined

        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 3', ( ) => {
    let res = {
      eligibilityState: 3,
      messages: {
        items:[{
          message:'you are not eligible to buy the product',
          type:'Info'
        }]
      }
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: false,
          isPlatinumAndUserIneligible: true,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:'you are not eligible to buy the product',
          comingSoonDate:null,
          inStoreDate:null
        },
        sku : {
          id:12,
          favoriteId: undefined

        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 5', ( ) => {
    let res = {
      eligibilityState: 5,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: true,
          isOutOfStock:true,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null
        },
        sku : {
          id:12,
          favoriteId: undefined
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 6', ( ) => {
    let res = {
      eligibilityState: 6,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: true,
          isOutOfStock:false,
          isNotifyMeEligible:true,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null
        },
        sku : {
          id:12,
          favoriteId:undefined
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 7', ( ) => {
    let res = {
      eligibilityState: 7,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: true,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: true,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate: null,
          inStoreDate: null
        },
        sku : {
          id:12,
          favoriteId: undefined
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );
  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 8', ( ) => {
    let res = {
      eligibilityState: 8,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:true,
          isNotAvailable: false,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null
        },
        sku : {
          id:12,
          favoriteId: undefined
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );
  it( 'should execute case getServiceType( \'pdpProductDetails\', \'success\' )', ( ) => {
    let res = {
      product: {
        maxQty: 3,
        displayName:'Online Only TexasLash Mascara',
        live: true,
        categoryPath: {
          items:[
            {
              name : 'Nails'
            },
            {
              name : 'Nail Care'
            }
          ]
        },
        'altImages': {
          'items': []
        }
      },
      sku:{
        id:1,
        images:{
          mainImage:'//mainUrl',
          thumbnailImage:'//url'
        },
        enableAskaQuestion: true
      },
      reviewSummary: {
        rating: 5,
        reviewCount: 1,
        questionCount: 1
      },
      isProductUnavailable:true
    }
    let actionCreator = {
      type: getServiceType( 'pdpProductDetails', 'success' ),
      data: res
    }
    let expectedOutput = {
      showVarientDropDown:false,
      virtualTryOnEnable:true,
      isValidProduct: true,
      prAskUrl:'//www.ulta.com/ulta/review/?pr_page_id=undefined&pr_source=web&appName=askQuestion',
      prWriteUrl:'//www.ulta.com/ulta/review/?pr_page_id=undefined&pr_source=web',
      productDetails: {
        selectedThumbnailIndex: 0,
        product: {
          maxQty: 3,
          displayName:'Online Only TexasLash Mascara',
          live: true,
          categoryPath: {
            items:[
              {
                name : 'Nails'
              },
              {
                name : 'Nail Care'
              }
            ]
          },
          'altImages': {
            'items': []
          }
        },
        sku:{
          id:1,
          images:{
            mainImage:'//mainUrl',
            thumbnailImage:'//url'
          },
          enableAskaQuestion: true
        },
        reviewSummary: {
          rating: 5,
          reviewCount: 1,
          questionCount: 1
        },
        ratingNum: 5,
        reviewNum: 1,
        questionCount:1,
        displayQaSection: true,
        displayQAs: true,
        displayAskLink: false,
        displayFavoritesButton: true,
        isProductUnavailable: true,
        breadCrumbNames: 'Home>Nails>Nail Care>Online Only TexasLash Mascara',
        enablePrAskQuestion : true,
        variantInfo: {
          message: '',
          treatmentType: 'default'
        }
      },
      breadCrumbLinks: [
        {
          dataNavDescription: 'bc - home',
          format: true,
          name: 'home',
          url: '/'
        },
        {
          dataNavDescription: 'bc - nails',
          name: 'Nails',
          url: undefined
        },
        {
          dataNavDescription: 'bc - nails:nail care',
          name: 'Nail Care',
          url: undefined
        },
        {
          name : 'Online Only TexasLash Mascara'
        }
      ],
      isProductUnavailable: true,
      combinedAltImages:[{
        mainImage:'//mainUrl',
        thumbnailImage:'//url'
      }]
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );

} );