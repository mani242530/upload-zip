
/**
 * Account Redux reducer Module
 *
 */

import { getServiceType } from 'ulta-fed-core/dist/js/events/services/services.events';
import { CHANGE as REDUXFORM_CHANGE } from 'redux-form/lib/actionTypes';
import appConstants from '../../../shared/appConstants'

/**
 * default state for the Account reducer
 */

export const initialState = {
  orderNumber: '',
  userEmail: '',
  orderStatusMessages: null
}

/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now( ) or Math.random( ).
 */

export default function reducer( state = initialState, action ){

  switch ( action.type ){

    case REDUXFORM_CHANGE:
      // when the user enters invalid data in order number field or email address field in order status page,
      // orderStatusMessages will be displayed. Once the user start editing again in order number field or
      // email address field in order status page, orderStatusMessages will be cleared.
      if( action.meta.form === appConstants.ORDER_STATUS_FORM.FORM_NAME && ( !!state.orderStatusMessages ) &&
          ( ( action.meta.field === appConstants.ORDER_STATUS_FORM.ORDER_NUMBER && action.payload !== state.orderNumber ) ||
          ( action.meta.field === appConstants.ORDER_STATUS_FORM.EMAIL && action.payload !== state.userEmail ) ) ){
        return {
          ...state,
          orderStatusMessages : []
        };
      }
      else {
        return {
          ...state
        };
      }

    case getServiceType( 'fetchOrderDetails', 'requested' ):
      return {
        ...state,
        orderNumber: action.data.orderId,
        userEmail: action.data.email,
        orderStatusMessages: []
      }

    case getServiceType( 'fetchOrderDetails', 'success' ):
      return {
        ...state,
        ...( action.data.messages?.items && { orderStatusMessages: action.data.messages.items } )
      }

    default:
      return state;
  }
}