
/**
 * Test for Account Reducer
 */
import { CHANGE as REDUXFORM_CHANGE } from 'redux-form/lib/actionTypes'
import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import reducer, {
  initialState
} from './account.model';


describe( 'Account reducer', ( ) => {
  registerServiceName( 'fetchOrderDetails' );

  it( 'should have the proper default state', ( ) => {
    let expectedState = {
      orderNumber:'',
      userEmail:'',
      orderStatusMessages: null
    }
    expect( initialState ).toEqual( expectedState );
  } )

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  describe( 'fetchOrderDetails', () => {
    it( 'should set orderNumber, userEmail from action.data and orderStatusMessages as undefined on fetchOrderDetails requested', () => {
      const actionCreator = {
        type:getServiceType( 'fetchOrderDetails', 'requested' ),
        data: {
          orderId: 'D12345',
          email: 'test@ulta.com'
        }
      }
      const expectedOutput = {
        orderNumber: 'D12345',
        userEmail: 'test@ulta.com',
        orderStatusMessages: []
      };

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should set orderStatusMessages from action.data.messages.items on fetchOrderDetails success if action.data contains messages', () => {
      const actionCreator = {
        type:getServiceType( 'fetchOrderDetails', 'success' ),
        data: {
          messages: {
            items: [
              {
                message: 'test message'
              }
            ]
          }
        }
      }
      const expectedOutput = {
        orderNumber: '',
        userEmail: '',
        orderStatusMessages: [
          {
            message: 'test message'
          }
        ]
      };

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should not set orderStatusMessages on fetchOrderDetails success if action.data.messages is null', () => {
      const actionCreator = {
        type:getServiceType( 'fetchOrderDetails', 'success' ),
        data: {
          messages: null
        }
      }
      expect( reducer( initialState, actionCreator ).orderStatusMessages ).toBeFalsy();
    } );
  } );

  describe( 'REDUXFORM_CHANGE', ( ) => {
    it( 'should clear orderStatusMessages upon change in orderNumber field of OrderStatus form', ( ) => {
      let state = {
        orderNumber:'D12345',
        orderStatusMessages: [
          {
            message: 'test message'
          }
        ]
      }
      let action = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:'OrderStatus',
          field:'orderNumber'
        },
        payload: 'D1234'
      }
      let expectedOutput = {
        orderNumber:'D12345',
        orderStatusMessages: []
      };
      expect( reducer( state, action ) ).toEqual( expectedOutput );
    } );

    it( 'should clear orderStatusMessages upon change in email field of OrderStatus form', ( ) => {
      let state = {
        userEmail:'test@ulta.com',
        orderStatusMessages: [
          {
            message: 'test message'
          }
        ]
      }
      let action = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:'OrderStatus',
          field:'orderNumber'
        },
        payload: 'test@ulta.co'
      }
      let expectedOutput = {
        userEmail:'test@ulta.com',
        orderStatusMessages: []
      };
      expect( reducer( state, action ) ).toEqual( expectedOutput );
    } );

    it( 'should not clear orderStatusMessages if form is not OrderStatus', ( ) => {
      let state = {
        userEmail: 'test@ulta.com',
        orderStatusMessages: [
          {
            message: 'test message'
          }
        ]
      }
      let action = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:'Login',
          field:'email'
        },
        payload: 'test@ulta.co'
      }
      let expectedOutput = {
        userEmail: 'test@ulta.com',
        orderStatusMessages: [
          {
            message: 'test message'
          }
        ]
      };
      expect( reducer( state, action ) ).toEqual( expectedOutput );
    } );

    it( 'should not clear orderStatusMessages if no change in orderNumber field of OrderStatus form', ( ) => {
      let state = {
        orderNumber:'D12345',
        orderStatusMessages: [
          {
            message: 'test message'
          }
        ]
      }
      let action = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:'OrderStatus',
          field:'orderNumber'
        },
        payload: 'D12345'
      }
      let expectedOutput = {
        orderNumber:'D12345',
        orderStatusMessages: [
          {
            message: 'test message'
          }
        ]
      };
      expect( reducer( state, action ) ).toEqual( expectedOutput );
    } );

    it( 'should not clear orderStatusMessages if no change in email field of OrderStatus form', ( ) => {
      let state = {
        userEmail:'test@ulta.com',
        orderStatusMessages: [
          {
            message: 'test message'
          }
        ]
      }
      let action = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:'OrderStatus',
          field:'email'
        },
        payload: 'test@ulta.com'
      }
      let expectedOutput = {
        userEmail:'test@ulta.com',
        orderStatusMessages: [
          {
            message: 'test message'
          }
        ]
      };
      expect( reducer( state, action ) ).toEqual( expectedOutput );
    } );
  } );
} );
