/**
 * Add to Bag Modal Redux reducer Module
 *
 */
import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  CLOSE_ADD_BAG_MODAL
} from '../../../events/add_to_bag/add_to_bag.events';

/**
 * default state for the AddToBag reducer
 */

export const initialState = {
  isAddToBagModalOpen:false,
  selectedQuantity:undefined,
  productImage:undefined,
  brandName:undefined,
  displayName:undefined,
  variant:undefined,
  listPrice:undefined,
  salePrice:undefined
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){
  switch ( action.type ){

    case getServiceType( 'pdpAddItem', 'requested' ):
    case getServiceType( 'qsAddItem', 'requested' ):
      return {
        ...state,
        selectedQuantity:action.data.quantity
      }

    case getServiceType( 'qsAddItem', 'success' ):
    case getServiceType( 'pdpAddItem', 'success' ):
      return {
        ...state,
        isAddToBagModalOpen:action.data.responseData.enableAddToBagModal,
        productImage:action.data.responseData.productImage,
        brandName:action.data.responseData.brandName,
        displayName:action.data.responseData.displayName,
        variant:action.data.responseData.variant,
        listPrice:action.data.responseData.listPrice,
        salePrice:action.data.responseData.salePrice,
        skuId:action.data.responseData.skuId
      }

    case getServiceType( 'addToBagModalProductRecs', 'success' ):
      return {
        ...state,
        recommendedProducts: action.data.data.recommendations
      }

    case getServiceType( 'qsProductDetails', 'success' ):
    case CLOSE_ADD_BAG_MODAL:
      return {
        ...state,
        isAddToBagModalOpen:false
      }

    default:
      return state;
  }
}

export const getAddToBagState = state => state.addtobag;
