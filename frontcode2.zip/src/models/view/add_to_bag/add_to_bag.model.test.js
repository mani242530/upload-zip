

import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  actionTypes as ReduxActionType
} from 'redux-form';
import reducer, {
  initialState,
  getAddToBagState
} from './add_to_bag.model';
import {
  CLOSE_ADD_BAG_MODAL
} from '../../../events/add_to_bag/add_to_bag.events';


describe( 'AddToBag reducer', ( ) => {
  registerServiceName( 'pdpAddItem' );
  registerServiceName( 'qsAddItem' );
  registerServiceName( 'addToBagModalProductRecs' );

  it( 'should have the proper default state', ( ) => {
    const expectedState = {
      isAddToBagModalOpen:false,
      selectedQuantity:undefined,
      productImage:undefined,
      brandName:undefined,
      displayName:undefined,
      variant:undefined,
      listPrice:undefined,
      salePrice:undefined
    }
    expect( initialState ).toEqual( expectedState );
  } );

  it( 'AddToBag requested case', ( ) => {
    const res = {
      quantity: 2
    }
    let actionCreator = {
      type: getServiceType( 'pdpAddItem', 'requested' ),
      data: res
    }
    let expectedOutput = {
      selectedQuantity: 2
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Should set the selected quantity of the item in quick shop modal when user clicks the Add to Bag button from quickshop in bag or empty bag page', ( ) => {
    const res = {
      quantity: 2
    }
    let actionCreator = {
      type: getServiceType( 'qsAddItem', 'requested' ),
      data: res
    }
    let expectedOutput = {
      selectedQuantity: 2
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'AddToBag success case', ( ) => {
    let res = {
      action:{
        data:{
          quantity: 1,
          skuId: 12312312,
          showProdRecs:true
        }
      },
      responseData :{
        success:true,
        enableAddToBagModal:true,
        productImage:'https://images.ulta.com/is/image/Ulta/2236259?$sm$',
        brandName:'Red Carpet Manicure',
        displayName:'Purple LED Gel Nail Polish Collection',
        skuId:'12321',
        variant:{
          'variantType': 'Color',
          'variantDesc': 'Violetta Darling (light purple crème)'
        },
        listPrice:{
          'displayAmount': '$8.99',
          'amount': 8.99,
          'currencyCode': 'USD'
        },
        salePrice:{
          'displayAmount': '$8.99',
          'amount': 8.99,
          'currencyCode': 'USD'
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpAddItem', 'success' ),
      data: res
    }
    let expectedOutput = {
      isAddToBagModalOpen:true,
      productImage:'https://images.ulta.com/is/image/Ulta/2236259?$sm$',
      brandName:'Red Carpet Manicure',
      displayName:'Purple LED Gel Nail Polish Collection',
      variant:{
        'variantType': 'Color',
        'variantDesc': 'Violetta Darling (light purple crème)'
      },
      listPrice:{
        'displayAmount': '$8.99',
        'amount': 8.99,
        'currencyCode': 'USD'
      },
      salePrice:{
        'displayAmount': '$8.99',
        'amount': 8.99,
        'currencyCode': 'USD'
      },
      skuId:'12321'
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'AddToBag from quick shop success case', ( ) => {
    let res = {
      action:{
        data:{
          quantity: 1,
          skuId: 12312312,
          showProdRecs:true
        }
      },
      responseData :{
        success:true,
        enableAddToBagModal:true,
        productImage:'https://images.ulta.com/is/image/Ulta/2236259?$sm$',
        brandName:'Red Carpet Manicure',
        displayName:'Purple LED Gel Nail Polish Collection',
        variant:{
          'variantType': 'Color',
          'variantDesc': 'Violetta Darling (light purple crème)'
        },
        listPrice:{
          'displayAmount': '$8.99',
          'amount': 8.99,
          'currencyCode': 'USD'
        },
        salePrice:{
          'displayAmount': '$8.99',
          'amount': 8.99,
          'currencyCode': 'USD'
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsAddItem', 'success' ),
      data: res
    }
    let expectedOutput = {
      isAddToBagModalOpen:true,
      productImage:'https://images.ulta.com/is/image/Ulta/2236259?$sm$',
      brandName:'Red Carpet Manicure',
      displayName:'Purple LED Gel Nail Polish Collection',
      variant:{
        'variantType': 'Color',
        'variantDesc': 'Violetta Darling (light purple crème)'
      },
      listPrice:{
        'displayAmount': '$8.99',
        'amount': 8.99,
        'currencyCode': 'USD'
      },
      salePrice:{
        'displayAmount': '$8.99',
        'amount': 8.99,
        'currencyCode': 'USD'
      }
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'AddToBag enableAddToBagModal key toggle', ( ) => {
    // enableAddToBagModal is true
    let res = {
      action:{
        data:{
          quantity: 1,
          skuId: 12312312,
          showProdRecs:true
        }
      },
      responseData :{
        enableAddToBagModal:true
      }
    };
    let expectedOutput = {
      isAddToBagModalOpen:true
    }
    let actionCreator = {
      type: getServiceType( 'pdpAddItem', 'success' ),
      data: res
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    // enableAddToBagModal is false
    res = {
      action:{
        data:{
          quantity: 1,
          skuId: 12312312,
          showProdRecs:true
        }
      },
      responseData :{
        enableAddToBagModal:false
      }
    };
    expectedOutput = {
      isAddToBagModalOpen:false
    }
    actionCreator = {
      type: getServiceType( 'pdpAddItem', 'success' ),
      data: res
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'AddToBag from quick shop enableAddToBagModal key toggle', ( ) => {
    // enableAddToBagModal is true
    let res = {
      action:{
        data:{
          quantity: 1,
          skuId: 12312312,
          showProdRecs:true
        }
      },
      responseData :{
        enableAddToBagModal:true
      }
    };
    let expectedOutput = {
      isAddToBagModalOpen:true
    }
    let actionCreator = {
      type: getServiceType( 'qsAddItem', 'success' ),
      data: res
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    res = {
      action:{
        data:{
          quantity: 1,
          skuId: 12312312,
          showProdRecs:true
        }
      },
      responseData :{
        enableAddToBagModal:false
      }
    };
    expectedOutput = {
      isAddToBagModalOpen:false
    }
    actionCreator = {
      type: getServiceType( 'qsAddItem', 'success' ),
      data: res
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should handle the event CLOSE_ADD_BAG_MODAL and set the state', ( ) => {
    const state = {
      isAddToBagModalOpen:true
    }
    const actionCreator = {
      type: CLOSE_ADD_BAG_MODAL
    }
    const expectedOutput = {
      isAddToBagModalOpen:false
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'qsProductDetails success case', ( ) => {
    const state = {
      isAddToBagModalOpen:true
    }
    const actionCreator = {
      type: getServiceType( 'qsProductDetails', 'success' )
    }
    const expectedOutput = {
      isAddToBagModalOpen:false
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'addToBagModalProductRecs success case', ( ) => {
    let res = {
      data:{
        recommendations :{}
      }
    }
    let actionCreator = {
      type: getServiceType( 'addToBagModalProductRecs', 'success' ),
      data: res
    }
    let expectedOutput = {
      recommendedProducts :{}
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should return addtobag state when  getAddToBagState is invoked', ( ) => {
    let state = {
      addtobag:{
        isAddToBagModalOpen:true,
        productImage:'https://images.ulta.com/is/image/Ulta/2236259?$sm$',
        brandName:'Red Carpet Manicure',
        displayName:'Purple LED Gel Nail Polish Collection'
      },
      cart:{
        quantity:'1'
      }
    }
    expect( getAddToBagState( state ) ).toEqual( state.addtobag );
  } );

} );
