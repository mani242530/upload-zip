/**
 * After Pay Redux reducer Module
 *
 */
import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  RESET_UPDATE_AFTER_PAY_WIDGET_FLAG
} from '../../../events/after_pay/after_pay.events';

import {
  SET_PAYMENT_FORM_TYPE
} from '../../../events/checkout_page/checkout_page.events';

/**
   * default state for the After Pay reducer
   */


export const initialState = {
  updateAfterpayWidget: false,
  afterpayEligible: false,
  renderAfterpayButton: false,
  afterpayErrorMessage: undefined,
  isAfterpayTokenRequired: false,
  paymentType: 'creditCard',
  isSignedIn: false,
  estimatedTotalInCents: 0,
  profileCreditCards: null,
  afterpayClientToken: undefined,
  paymentInvokeFromInitCart: false
};

export default function reducer( state = initialState, action ){

  switch ( action.type ){

    case SET_PAYMENT_FORM_TYPE:
      return {
        ...state,
        paymentType: action.paymentType
      }

    case RESET_UPDATE_AFTER_PAY_WIDGET_FLAG:
      return {
        ...state,
        updateAfterpayWidget: false
      }

    case getServiceType( 'submitOrderService', 'loading' ):
      return {
        ...state,
        paymentType: action.data.paymentType // need this because we need the payment type on submitOrderService success to set error message and to update updateAfterpayWidget
      };

    case getServiceType( 'submitOrderService', 'success' ):
      return {
        ...state,
        // render afterpay error message only if payment success is false, paymentType is afterpay and had paymentInfo messages
        ...( !action.data.success && state.paymentType === 'afterpay' && action.data.paymentInfo?.messages?.items && {
          updateAfterpayWidget: updateAfterpayWidget( state ),
          afterpayErrorMessage: action.data.paymentInfo.messages.items
        } )
      };

    case getServiceType( 'initCart', 'success' ):
      return {
        ...state,
        ...( action.data.result.afterpay && populateAfterpayData( action.data.result.afterpay, state ) ),
        estimatedTotalInCents: calculateEstimatedTotalInCents( action.data.result, state ),
        isSignedIn: action.data.isSignedIn
      }

    case getServiceType( 'paymentServiceResponse', 'requested' ):
      return {
        ...state,
        paymentInvokeFromInitCart: !!action.data.paymentInvokeFromInitCart
      }

    case getServiceType( 'paymentServiceResponse', 'success' ):
    case getServiceType( 'removePaymentService', 'success' ):
    case getServiceType( 'pickupContactInfoUpdate', 'success' ):
      return {
        ...state,
        // should not update afterpay widget if payment is invoked from initcart controller
        ...( !state.paymentInvokeFromInitCart && { updateAfterpayWidget: updateAfterpayWidget( state ) } ),
        ...( action.data.result.afterpay && populateAfterpayData( action.data.result.afterpay, state ) ),
        estimatedTotalInCents: calculateEstimatedTotalInCents( action.data.result, state ),
        // resetting paymentInvokeFromInitCart flag
        ...( state.paymentInvokeFromInitCart && { paymentInvokeFromInitCart: false } )
      }

    case getServiceType( 'shippingUpdate', 'success' ):
      return {
        ...state,
        updateAfterpayWidget: updateAfterpayWidget( state ),
        ...( action.data.response.afterpay && populateAfterpayData( action.data.response.afterpay, state ) ),
        estimatedTotalInCents: calculateEstimatedTotalInCents( action.data.response, state )
      }

    case getServiceType( 'removecoupon', 'success' ):
    case getServiceType( 'applycoupon', 'success' ):
    case getServiceType( 'applyPayPalPayment', 'success' ):
      return {
        ...state,
        updateAfterpayWidget: updateAfterpayWidget( state ),
        ...( action.data.afterpay && populateAfterpayData( action.data.afterpay, state ) )
      }

    case getServiceType( 'afterpayToken', 'loading' ):
      return {
        ...state,
        afterpayClientToken: undefined
      }

    case getServiceType( 'afterpayToken', 'success' ):
      let error;
      if( !action.data.afterpayClientToken ){
        error = action.data.messages.items;
      }
      return {
        ...state,
        afterpayClientToken: action.data.afterpayClientToken,
        renderAfterpayButton: renderAfterpayButton( action.data, state ),
        afterpayErrorMessage: error
      }

    case getServiceType( 'profileCreditCards', 'success' ):
      return {
        ...state,
        updateAfterpayWidget: false,
        profileCreditCards: action.data.data.profileCreditCards,
        afterpayErrorMessage: undefined
      }

    default:
      return state;

  }
}

export const populateAfterpayData = ( data, state ) => {
  const afterpayData = {
    afterpayEligible: data.afterpayEligible,
    isAfterpayTokenRequired: data.isTokenRequired,
    afterpayErrorMessage: data?.messages?.items,
    renderAfterpayButton: renderAfterpayButton( data, state )
  };
  return afterpayData;
}


export const renderAfterpayButton = ( data, state ) => {
  const afterpayEligible = data.afterpayEligible ?? state.afterpayEligible;
  const isAfterpayTokenRequired = data.isTokenRequired ?? state.isAfterpayTokenRequired;
  const afterpayClientToken = data.afterpayClientToken ?? state.afterpayClientToken;

  // afterpay button should be render only if afterpayEligible and isAfterpayTokenRequired are true and has valid afterpayClientToken
  return afterpayEligible && isAfterpayTokenRequired && !!( afterpayClientToken );
}
export const calculateEstimatedTotalInCents = ( data, state ) => {
  // if cartSummary is not null, it will return estimatedTotal in cents
  // otherwise it will return existing estimatedTotalInCents from state, to display in afterpay widget
  return data.cartSummary ? ( data.cartSummary.estimatedTotal * 100 ) : state.estimatedTotalInCents;
}

export const updateAfterpayWidget = ( state ) => {
  let updateAfterpayWidget = false;
  // updateAfterpayWidget will be true, if registered user has saved credit cards
  // or if paymentType is afterpay
  if( state.isSignedIn && state.profileCreditCards ){
    updateAfterpayWidget = true;
  }
  else if( state.paymentType === 'afterpay' ){
    updateAfterpayWidget = true;
  }
  return updateAfterpayWidget;
}
