
/**
 * Test for After Pay Reducer
 */
import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import reducer, {
  initialState,
  populateAfterpayData,
  renderAfterpayButton,
  calculateEstimatedTotalInCents,
  updateAfterpayWidget
} from './after_pay.model';
import {
  RESET_UPDATE_AFTER_PAY_WIDGET_FLAG
} from '../../../events/after_pay/after_pay.events';
import {
  SET_PAYMENT_FORM_TYPE
} from '../../../events/checkout_page/checkout_page.events';

describe( 'AfterPay reducer', ( ) => {
  registerServiceName( 'initCart' );
  registerServiceName( 'shippingUpdate' );
  registerServiceName( 'paymentServiceResponse' );
  registerServiceName( 'removePaymentService' );
  registerServiceName( 'submitOrderService' );
  registerServiceName( 'pickupContactInfoUpdate' );
  registerServiceName( 'removecoupon' );
  registerServiceName( 'applycoupon' );
  registerServiceName( 'profileCreditCards' );
  registerServiceName( 'applyPayPalPayment' );
  registerServiceName( 'afterpayToken' );

  it( 'should have the proper default state', ( ) => {
    let expectedState = {
      updateAfterpayWidget: false,
      afterpayEligible: false,
      renderAfterpayButton: false,
      afterpayErrorMessage: undefined,
      isAfterpayTokenRequired: false,
      paymentType: 'creditCard',
      isSignedIn: false,
      estimatedTotalInCents: 0,
      profileCreditCards: null,
      paymentInvokeFromInitCart: false
    }
    expect( initialState ).toEqual( expectedState );
  } )

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  describe( 'RESET_UPDATE_AFTER_PAY_WIDGET_FLAG', () => {
    it( 'should set updateAfterpayWidget as false', () => {
      const actionCreator = {
        type: RESET_UPDATE_AFTER_PAY_WIDGET_FLAG
      }
      expect( reducer( initialState, actionCreator ).updateAfterpayWidget ).toEqual( false );
    } );
  } );

  describe( 'submitOrderService', () => {
    it( 'should set paymentType for submitOrderService loading', () => {
      const actionCreator = {
        type:getServiceType( 'submitOrderService', 'loading' ),
        data: {
          paymentType: 'afterpay'
        }
      }

      expect( reducer( {}, actionCreator ).paymentType ).toEqual( 'afterpay' );
    } );
    it( 'should set updateAfterpayWidget as true, afterpayErrorMessage if success is false, paymentType is afterpay and paymentInfo has error messages', () => {
      const paymentInfoMessage = [
        {
          type: 'Error',
          message: 'Oh no! Were experiencing difficulty processing your payment. Try again later or use another payment method.'
        }
      ];
      const mockState = {
        isSignedIn: true,
        paymentType: 'afterpay'
      }
      const actionCreator = {
        type:getServiceType( 'submitOrderService', 'success' ),
        data: {
          success: false,
          paymentInfo: {
            messages: {
              items: paymentInfoMessage
            }
          }
        }
      }

      expect( reducer( mockState, actionCreator ).updateAfterpayWidget ).toEqual( true );
      expect( reducer( mockState, actionCreator ).afterpayErrorMessage ).toEqual( paymentInfoMessage );
    } );
    it( 'should not set afterpayErrorMessage if success is false, paymentType is not afterpay and paymentInfo has error messages', () => {
      const paymentInfoMessage = [
        {
          type: 'Error',
          message: 'Oh no! Were experiencing difficulty processing your payment. Try again later or use another payment method.'
        }
      ];
      const mockState = {
        isSignedIn: true,
        paymentType: 'paypal',
        afterpayErrorMessage: undefined
      }
      const actionCreator = {
        type:getServiceType( 'submitOrderService', 'success' ),
        data: {
          success: false,
          paymentInfo: {
            messages: {
              items: paymentInfoMessage
            }
          }
        }
      }
      expect( reducer( mockState, actionCreator ).afterpayErrorMessage ).toEqual( undefined );
    } );
    it( 'should not set afterpayErrorMessage if success is false, paymentType is afterpay and paymentInfo has no error messages', () => {
      const mockState = {
        isSignedIn: true,
        paymentType: 'afterpay',
        afterpayErrorMessage: undefined
      }
      const actionCreator = {
        type:getServiceType( 'submitOrderService', 'success' ),
        data: {
          success: false,
          paymentInfo: {
            messages: {
              items: null
            }
          }
        }
      }
      expect( reducer( mockState, actionCreator ).afterpayErrorMessage ).toEqual( undefined );
    } );
  } );

  describe( 'initcart success', () => {
    it( 'should set expected output for initcart success', () => {
      const actionCreator = {
        type:getServiceType( 'initCart', 'success' ),
        data: {
          result: {
            afterpay: {
              afterpayEligible : true,
              isTokenRequired: true,
              messages: null
            },
            cartSummary: {
              estimatedTotal: '35'
            }
          },
          isSignedIn: true
        }
      }
      const expectedOutput = {
        afterpayEligible: true,
        isAfterpayTokenRequired: true,
        renderAfterpayButton: false,
        afterpayErrorMessage: undefined,
        estimatedTotalInCents: 3500,
        paymentType: 'creditCard',
        updateAfterpayWidget: false,
        isSignedIn: true,
        profileCreditCards: null,
        afterpayClientToken: undefined,
        paymentInvokeFromInitCart: false
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set afterpayEligible as false if action.data.result.afterPay.afterpayEligible is false', () => {
      const mockState = {
        afterpayEligible : true
      }
      const actionCreator = {
        type:getServiceType( 'initCart', 'success' ),
        data: {
          result: {
            afterpay: {
              afterpayEligible : false
            },
            cartSummary: {
              estimatedTotal: '35'
            }
          }
        }
      }
      expect( reducer( mockState, actionCreator ).afterpayEligible ).toEqual( false );
    } );

    it( 'should set isAfterpayTokenRequired as false if action.data.result.afterPay.isTokenRequired is false', () => {
      const mockState = {
        isTokenRequired : true
      }
      const actionCreator = {
        type:getServiceType( 'initCart', 'success' ),
        data: {
          result: {
            afterpay: {
              isTokenRequired : false
            },
            cartSummary: {
              estimatedTotal: '35'
            }
          }
        }
      }
      expect( reducer( mockState, actionCreator ).isAfterpayTokenRequired ).toEqual( false );
    } );

    it( 'should set afterpayErrorMessage if message is defined in initcart success response', () => {
      const mockState = {
        afterpayErrorMessage : undefined
      }
      const afterpayErrorMessage = [
        {
          type: 'error',
          message: 'error message'
        }
      ];
      const actionCreator = {
        type:getServiceType( 'initCart', 'success' ),
        data: {
          result: {
            afterpay: {
              messages : {
                items: afterpayErrorMessage
              }
            },
            cartSummary: {
              estimatedTotal: '35'
            }
          }
        }
      }
      expect( reducer( mockState, actionCreator ).afterpayErrorMessage ).toEqual( afterpayErrorMessage );
    } );

    it( 'should set isSignedIn as false if isSignedIn is false', () => {
      const actionCreator = {
        type:getServiceType( 'initCart', 'success' ),
        data: {
          result: {},
          isSignedIn : false
        }
      }
      expect( reducer( {}, actionCreator ).isSignedIn ).toEqual( false );
    } );
  } );

  describe( 'paymentServiceResponse requested', () => {
    it( 'should set expected output', () => {
      const mockState = {
        paymentInvokeFromInitCart: false
      }
      const actionCreator = {
        type:getServiceType( 'paymentServiceResponse', 'requested' ),
        data:{
          paymentInvokeFromInitCart: true
        }
      }

      const expectedOutput = {
        paymentInvokeFromInitCart: true
      }

      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should set paymentInvokeFromInitCart as false if paymentInvokeFromInitCart is undefined', () => {
      const mockState = {
        paymentInvokeFromInitCart: true
      }
      const actionCreator = {
        type:getServiceType( 'paymentServiceResponse', 'requested' ),
        data:{
          paymentInvokeFromInitCart: undefined
        }
      }

      const expectedOutput = {
        paymentInvokeFromInitCart: false
      }

      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'paymentServiceResponse success', () => {
    it( 'should set expected output', () => {
      const mockState = {
        isSignedIn: false,
        paymentType: 'afterpay',
        afterpayClientToken: 'test token',
        paymentInvokeFromInitCart: false,
        updateAfterpayWidget: false
      }
      const actionCreator = {
        type:getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          result: {
            afterpay: {
              afterpayEligible : true,
              isTokenRequired: true,
              messages: null
            },
            cartSummary: {
              estimatedTotal: '35'
            }
          }
        }
      }

      const expectedOutput = {
        afterpayEligible: true,
        isAfterpayTokenRequired: true,
        renderAfterpayButton: true,
        afterpayErrorMessage: undefined,
        updateAfterpayWidget: true,
        estimatedTotalInCents: 3500,
        paymentType: 'afterpay',
        isSignedIn: false,
        afterpayClientToken: 'test token',
        paymentInvokeFromInitCart: false
      }

      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should not update afterpay widget if paymentInvokeFromInitCart is true', () => {
      const mockState = {
        paymentInvokeFromInitCart: true,
        updateAfterpayWidget: false,
        paymentType: 'afterpay'
      }
      const actionCreator = {
        type:getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          result: {
            afterpay: {
              afterpayEligible : true,
              isTokenRequired: true,
              messages: null
            }
          }
        }
      }

      expect( reducer( mockState, actionCreator ).updateAfterpayWidget ).toEqual( false );
    } );
  } );

  describe( 'removePaymentService success', () => {
    it( 'should set expected output', () => {
      const mockState = {
        isSignedIn: false,
        paymentType: 'afterpay',
        afterpayClientToken: 'test token'
      }
      const actionCreator = {
        type:getServiceType( 'removePaymentService', 'success' ),
        data:{
          result: {
            afterpay: {
              afterpayEligible : true,
              isTokenRequired: true,
              messages: null
            },
            cartSummary: {
              estimatedTotal: '35'
            }
          }
        }
      }

      const expectedOutput = {
        afterpayEligible: true,
        isAfterpayTokenRequired: true,
        renderAfterpayButton: true,
        afterpayErrorMessage: undefined,
        updateAfterpayWidget: true,
        estimatedTotalInCents: 3500,
        paymentType: 'afterpay',
        isSignedIn: false,
        afterpayClientToken: 'test token'
      }

      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'pickupContactInfoUpdate success', () => {
    it( 'should set expected output', () => {
      const mockState = {
        isSignedIn: false,
        paymentType: 'afterpay',
        afterpayClientToken: 'test token'
      }
      const actionCreator = {
        type:getServiceType( 'pickupContactInfoUpdate', 'success' ),
        data:{
          result: {
            afterpay: {
              afterpayEligible : true,
              isTokenRequired: true,
              messages: null
            },
            cartSummary: {
              estimatedTotal: '35'
            }
          }
        }
      }

      const expectedOutput = {
        afterpayEligible: true,
        isAfterpayTokenRequired: true,
        renderAfterpayButton: true,
        afterpayErrorMessage: undefined,
        updateAfterpayWidget: true,
        estimatedTotalInCents: 3500,
        paymentType: 'afterpay',
        isSignedIn: false,
        afterpayClientToken: 'test token'
      }

      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'shippingUpdate success', () => {
    it( 'should set expected output', () => {
      const mockState = {
        isSignedIn: false,
        paymentType: 'afterpay',
        afterpayClientToken: 'test token'
      }
      const actionCreator = {
        type:getServiceType( 'shippingUpdate', 'success' ),
        data: {
          response: {
            afterpay: {
              afterpayEligible : true,
              isTokenRequired: true,
              messages: null
            },
            cartSummary: {
              estimatedTotal: '35'
            }
          }
        }
      }
      const expectedOutput = {
        updateAfterpayWidget: true,
        afterpayEligible: true,
        isAfterpayTokenRequired: true,
        renderAfterpayButton: true,
        afterpayErrorMessage: undefined,
        estimatedTotalInCents: 3500,
        paymentType: 'afterpay',
        isSignedIn: false,
        afterpayClientToken: 'test token'
      }
      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'removecoupon success', () => {
    it( 'should set expected output for removecoupon success', () => {
      const mockState = {
        isSignedIn: false,
        paymentType: 'afterpay',
        afterpayClientToken: 'test token'
      }
      const actionCreator = {
        type:getServiceType( 'removecoupon', 'success' ),
        data:{
          afterpay: {
            afterpayEligible : true,
            isTokenRequired: true,
            messages: null
          }
        }
      }

      const expectedOutput = {
        afterpayEligible: true,
        isAfterpayTokenRequired: true,
        renderAfterpayButton: true,
        afterpayErrorMessage: undefined,
        updateAfterpayWidget: true,
        paymentType: 'afterpay',
        isSignedIn: false,
        afterpayClientToken: 'test token'
      }

      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'applycoupon success', () => {
    it( 'should set expected output for applycoupon success', () => {
      const mockState = {
        isSignedIn: false,
        paymentType: 'afterpay',
        afterpayClientToken: 'test token'
      }
      const actionCreator = {
        type:getServiceType( 'applycoupon', 'success' ),
        data:{
          afterpay: {
            afterpayEligible : true,
            isTokenRequired: true,
            messages: null
          }
        }
      }

      const expectedOutput = {
        afterpayEligible: true,
        isAfterpayTokenRequired: true,
        renderAfterpayButton: true,
        afterpayErrorMessage: undefined,
        updateAfterpayWidget: true,
        paymentType: 'afterpay',
        isSignedIn: false,
        afterpayClientToken: 'test token'
      }

      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'applyPayPalPayment success', () => {
    it( 'should set expected output for applyPayPalPayment success', () => {
      const mockState = {
        isSignedIn: false,
        paymentType: 'afterpay',
        afterpayClientToken: 'test token'
      }
      const actionCreator = {
        type:getServiceType( 'applyPayPalPayment', 'success' ),
        data:{
          afterpay: {
            afterpayEligible : true,
            isTokenRequired: true,
            messages: null
          }
        }
      }

      const expectedOutput = {
        afterpayEligible: true,
        isAfterpayTokenRequired: true,
        renderAfterpayButton: true,
        afterpayErrorMessage: undefined,
        updateAfterpayWidget: true,
        paymentType: 'afterpay',
        isSignedIn: false,
        afterpayClientToken: 'test token'
      }

      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'afterpayClientToken services', () => {
    it( 'should set afterpayClientToken as undefined for afterpayToken loading', () => {
      let actionCreator = {
        type: getServiceType( 'afterpayToken', 'loading' )
      }

      let expected = { afterpayClientToken: undefined };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'should set afterpayClientToken for afterpayToken success', () => {
      const mockState = {
        afterpayEligible: true,
        isAfterpayTokenRequired: false
      }
      let actionCreator = {
        type: getServiceType( 'afterpayToken', 'success' ),
        data:{
          afterpayClientToken:'eyJ2ZXJzaW9uIjoyLCJhdXRob3J'
        }
      }
      let expected = {
        afterpayClientToken: 'eyJ2ZXJzaW9uIjoyLCJhdXRob3J',
        renderAfterpayButton: false,
        afterpayEligible: true,
        isAfterpayTokenRequired: false
      }
      expect( reducer( mockState, actionCreator ) ).toEqual( expected );
    } );

    it( 'should set afterpayErrorMessage for afterpayToken success if there is error', () => {
      const mockState = {
        afterpayEligible: true,
        isAfterpayTokenRequired: false
      }
      let actionCreator = {
        type: getServiceType( 'afterpayToken', 'success' ),
        data:{
          messages: {
            items: [{
              message: 'not eligible for afterpay',
              type: 'error'
            }]
          }
        }
      }
      let expected = {
        afterpayClientToken: undefined,
        renderAfterpayButton: false,
        afterpayEligible: true,
        isAfterpayTokenRequired: false,
        afterpayErrorMessage: [{
          message: 'not eligible for afterpay',
          type: 'error'
        }]
      }
      expect( reducer( mockState, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'profileCreditCards success', () => {
    it( 'should set expected output for profileCreditCards success', () => {
      const mockState = {
        updateAfterpayWidget: true
      }
      const actionCreator = {
        type:getServiceType( 'profileCreditCards', 'success' ),
        data: {
          data: {
            profileCreditCards:[
              {
                creditCard: {
                  nickName: 'VISA - 4111'
                }
              }
            ]
          }
        }
      }

      const expectedOutput = {
        updateAfterpayWidget: false,
        profileCreditCards: [
          {
            creditCard: {
              nickName: 'VISA - 4111'
            }
          }
        ],
        afterpayErrorMessage: undefined
      }

      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'SET_PAYMENT_FORM_TYPE', () => {
    it( 'should set paymentType flag as creditcard if paymentType is creditcard', ()=>{
      let actionCreator = {
        type: SET_PAYMENT_FORM_TYPE,
        paymentType: 'creditcard'
      }

      let excepted = {
        paymentType: 'creditcard'
      }

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
    it( 'should set paymentType flag as paypal if paymentType is paypal', ()=>{
      let actionCreator = {
        type: SET_PAYMENT_FORM_TYPE,
        paymentType: 'paypal'
      }

      let excepted = {
        paymentType: 'paypal'
      }

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
    it( 'should set paymentType flag as afterpay if paymentType is afterpay', ()=>{
      let actionCreator = {
        type: SET_PAYMENT_FORM_TYPE,
        paymentType: 'afterpay'
      }

      let excepted = {
        paymentType: 'afterpay'
      }

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
  } );

  describe( 'populateAfterpayData', () => {
    it( 'should return expected data', () => {
      const mockState = {
        afterpayClientToken: 'test token'
      }
      const data = {
        afterpayEligible : true,
        isTokenRequired: true,
        messages: null
      }
      const expectedData = {
        afterpayEligible: true,
        isAfterpayTokenRequired: true,
        afterpayErrorMessage: undefined,
        renderAfterpayButton: true
      }
      expect( populateAfterpayData( data, mockState ) ).toEqual( expectedData );
    } );
    it( 'should set afterpayEligible as false if afterpayEligible is false', () => {
      const mockState = {
        afterpayClientToken: 'test token'
      }
      const data = {
        afterpayEligible : false
      }
      expect( populateAfterpayData( data, mockState ).afterpayEligible ).toEqual( false );
    } );
    it( 'should set isAfterpayTokenRequired as false if isTokenRequired is false', () => {
      const mockState = {
        afterpayClientToken: 'test token'
      }
      const data = {
        isTokenRequired: false
      }
      expect( populateAfterpayData( data, mockState ).isAfterpayTokenRequired ).toEqual( false );
    } );
    it( 'should set afterpayErrorMessage if data.messages is defined', () => {
      const mockState = {
        afterpayClientToken: 'test token'
      }
      const afterpayErrorMessage = [
        {
          type: 'error',
          message: 'error message'
        }
      ];
      const data = {
        messages: {
          items: afterpayErrorMessage
        }
      }
      expect( populateAfterpayData( data, mockState ).afterpayErrorMessage ).toEqual( afterpayErrorMessage );
    } );
  } );

  describe( 'renderAfterpayButton', () => {
    it( 'should return true if afterpayEligible and isTokenRequired is true from data and has valid afterpayClientToken in state', () => {
      const mockState = {
        afterpayEligible: false,
        isTokenRequired: false,
        afterpayClientToken: 'test token'
      }
      const data = {
        afterpayEligible: true,
        isTokenRequired: true,
        afterpayClientToken: undefined
      }
      expect( renderAfterpayButton( data, mockState ) ).toEqual( true );
    } );
    it( 'should return true if data has valid afterpayClientToken and afterpayEligible,isAfterpayTokenRequired are true in state', () => {
      const mockState = {
        afterpayEligible: true,
        isAfterpayTokenRequired: true,
        afterpayClientToken: undefined
      }
      const data = {
        afterpayEligible: undefined,
        isTokenRequired: undefined,
        afterpayClientToken: 'test token'
      }
      expect( renderAfterpayButton( data, mockState ) ).toEqual( true );
    } );
    it( 'should return false if afterpayEligible is false', () => {
      const mockState = {
        afterpayEligible: true,
        isTokenRequired: true,
        afterpayClientToken: 'test token'
      }
      const data = {
        afterpayEligible: false,
        isTokenRequired: true,
        afterpayClientToken: undefined
      }
      expect( renderAfterpayButton( data, mockState ) ).toEqual( false );
    } );
    it( 'should return false if isTokenRequired is false', () => {
      const mockState = {
        afterpayClientToken: 'test token',
        afterpayEligible: true,
        isAfterpayTokenRequired: true
      }
      const data = {
        afterpayEligible: true,
        isTokenRequired: false,
        afterpayClientToken: undefined
      }
      expect( renderAfterpayButton( data, mockState ) ).toEqual( false );
    } );
    it( 'should return false if afterpayClientToken is undefined', () => {
      const mockState = {
        afterpayClientToken: undefined,
        afterpayEligible: true,
        isAfterpayTokenRequired: true
      }
      const data = {
        afterpayEligible: undefined,
        isTokenRequired: undefined,
        afterpayClientToken: undefined
      }
      expect( renderAfterpayButton( data, mockState ) ).toEqual( false );
    } );
  } );

  describe( 'calculateEstimatedTotalInCents', () => {
    it( 'should estimated total in cents', () => {
      const data = {
        cartSummary: {
          estimatedTotal: '75'
        }
      }
      expect( calculateEstimatedTotalInCents( data, initialState ) ).toEqual( 7500 );
    } );
    it( 'should set estimated total as 0 if cartSummary is undefined', () => {
      const data = {
        cartSummary: undefined
      }
      expect( calculateEstimatedTotalInCents( data, initialState ) ).toEqual( 0 );
    } );
    it( 'should set estimated total from state if cartSummary is undefined and state has valid estimatedTotalInCents', () => {
      const mockState = {
        estimatedTotalInCents : 6500
      }
      const data = {
        cartSummary: undefined
      }
      expect( calculateEstimatedTotalInCents( data, mockState ) ).toEqual( 6500 );
    } );
  } );

  describe( 'updateAfterpayWidget', () => {
    it( 'should return true for signed user if state has profileCreditCards', () => {
      const mockState = {
        isSignedIn : true,
        paymentType : 'creditCard',
        profileCreditCards: [{
          nickName: 'VISA - 1111'
        }]
      }
      expect( updateAfterpayWidget( mockState ) ).toEqual( true );
    } );
    it( 'should return false for signed user if state has no profileCreditCards', () => {
      const mockState = {
        isSignedIn : true,
        paymentType : 'creditCard',
        profileCreditCards : null
      }
      expect( updateAfterpayWidget( mockState ) ).toEqual( false );
    } );
    it( 'should return true if paymentType is afterpay', () => {
      const mockState = {
        isSignedIn : false,
        paymentType : 'afterpay'
      }
      expect( updateAfterpayWidget( mockState ) ).toEqual( true );
    } );
    it( 'should return false for guest user if paymentType is creditCard', () => {
      const mockState = {
        isSignedIn : false,
        paymentType : 'creditCard'
      }
      expect( updateAfterpayWidget( mockState ) ).toEqual( false );
    } );
    it( 'should return false for guest user if paymentType is paypal', () => {
      const mockState = {
        isSignedIn : false,
        paymentType : 'paypal'
      }
      expect( updateAfterpayWidget( mockState ) ).toEqual( false );
    } );
  } );
} );
