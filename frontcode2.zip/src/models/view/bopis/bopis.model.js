/**
 * BOPIS Redux reducer Module
 *
 */

import { CHANGE as REDUXFORM_CHANGE } from 'redux-form/lib/actionTypes';
import {
  ALERT_WINDOW_RESIZE
} from 'ulta-fed-core/dist/js/events/global/global.events';
import {
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import has from 'lodash/has';
import VMasker from 'vanilla-masker';
import { isIntlSite } from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import get from 'lodash/get'
import {
  TOGGLE_BOPIS_CONTACT_FORM_DISPLAY
} from '../../../events/bopis/bopis.events';
/**
 * default state for the BOPIS reducer
 */

export const initialState = {
  // BOPIS pickup related data will go under pickupInformation object
  pickupInformation: {
    isDisplayPickupContactForm: true, // is used to show/hide pickup contact form
    isDisplayAlternatePickupPersonForm: false, // is used to show/hide alternate pickup person form
    tempPickupContactInfoData: {}, // set initial Pickup Contact Info to empty when users switches between input fields
    tempAlternatePickupPersonData: {} // set initial alternate Pickup Person Info to empty when users switches between input fields
  },
  deliveryOption: 'ship', // Set the delivery option to ship by default
  pickupStoreInfo: null,
  pickupStoreAddressInfo: {
    address1: null,
    city: null,
    state: null,
    zipCode: null
  },
  isBopisEnabledMobile: false,
  isBopisEnabledDesktop: false,
  isEligibleToDisplayShipOrPickup: false,
  isDeliveryOptionPickup: false,
  isBopisEnabled: false,
  pickupStoreInfoUpdateSuccess: false,
  bopisFullChainEnabled: false,
  onlineOnly: false
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now( ) or Math.random( ).
 */
export default function reducer( state = initialState, action ){

  switch ( action.type ){

    case getServiceType( 'pickupContactInfoUpdate', 'loading' ):

      return {
        ...state,
        pickupInformation: {
          ...state.pickupInformation,
          ...( has( action.data, 'data.primaryContactInfo' ) && {
            tempPickupContactInfoData: {
              firstName:action.data.data.primaryContactInfo.firstName,
              lastName:action.data.data.primaryContactInfo.lastName,
              emailaddress:action.data.data.primaryContactInfo.email,
              phoneNumber: VMasker.toPattern( action.data.data.primaryContactInfo.phoneNumber, '(999) 999-9999' )
            }
          } ),
          ...( get( action.data, 'data.alternateContactInfo' ) && {
            tempAlternatePickupPersonData: {
              firstName:action.data.data.alternateContactInfo.firstName,
              lastName:action.data.data.alternateContactInfo.lastName,
              email:action.data.data.alternateContactInfo.email
            }
          } )
        }
      };

    case TOGGLE_BOPIS_CONTACT_FORM_DISPLAY:
      return {
        ...state,
        pickupInformation: {
          ...state.pickupInformation,
          isDisplayPickupContactForm: action.data
        }
      };

    case getServiceType( 'pickupContactInfoUpdate', 'success' ):

      return {
        ...state,
        pickupInformation: {
          ...state.pickupInformation,
          // isPrimaryContactInfoUpdated flag added to ensure that contact form is in the open view until we click on save option
          ...( action.data.isSignedIn && action.data.isPrimaryContactInfoUpdated && { isDisplayPickupContactForm: false } ),
          // if alternate contact is deleted then set tempAlternatePickupPersonData to null else populate details to it
          tempAlternatePickupPersonData:get( action.data, 'result.pickupInfo.alternateContactInfo' ) ? {
            firstName:action.data.result.pickupInfo.alternateContactInfo.firstName.value,
            lastName:action.data.result.pickupInfo.alternateContactInfo.lastName.value,
            email:action.data.result.pickupInfo.alternateContactInfo.emailAddress.value
          } : null,
          ...( !action.data.isPrimaryContactInfoUpdated && !get( action.data, 'result.pickupInfo.alternateContactInfo' ) && { tempAlternatePickupPersonData:null } )

        }
      };

    case REDUXFORM_CHANGE:
      if( action.meta.form === 'AlternatePickupPersonForm' && action.meta.field === 'isAlternatePickupPersonEnable' ){
        return {
          ...state,
          pickupInformation: {
            ...state.pickupInformation,
            isDisplayAlternatePickupPersonForm: ( action.payload ) ? action.payload : false
          }
        }
      }
      else {
        return {
          ...state
        }
      }

    case getServiceType( 'initiateCheckout', 'success' ):
      return {
        ...state,
        ...( !action.data.result && populateBOPISInfo( action, state.bopisFullChainEnabled, state.onlineOnly ) )
      };

    case getServiceType( 'loadCart', 'loading' ):
      return {
        ...state,
        // To ensure that When redirecting to cart page from checkoutpage, ShipOrPickup section should not be displayed on loading
        isEligibleToDisplayShipOrPickup:false
      }

    case getServiceType( 'loadCart', 'success' ):
      return {
        ...state,
        ...( state.isBopisEnabled && {
          ...populateBOPISInfo( action, state.bopisFullChainEnabled, state.onlineOnly ),
          // BOPIS loader should be displayed for initial cart page load only
          // setting isEligibleToDisplayShipOrPickup as false since ShipOrPickup section should not be displayed on initial loadcart
          ...( !state.pickupStoreInfo && {
            isEligibleToDisplayShipOrPickup:false,
            showBOPISLoader:true
          } )
        } )
      };
    case getServiceType( 'deliveryOptionsUpdate', 'success' ):
      return {
        ...state,
        ...populateBOPISInfo( action, state.bopisFullChainEnabled, state.onlineOnly ),
        showBOPISLoader : false,
        pickupStoreInfoUpdateSuccess: !!action.data.pickupStoreInfo
      };
    case getServiceType( 'removeGiftFromCart', 'success' ):
    case getServiceType( 'addItemToCart', 'success' ):
    case getServiceType( 'selectGiftVariant', 'success' ):
      return {
        ...state,
        ...populateBOPISInfo( action, state.bopisFullChainEnabled, state.onlineOnly ),
        showBOPISLoader : false
      };

    case getServiceType( 'moveToBagFromSaveForLater', 'success' ):
    case getServiceType( 'moveToSaveForLater', 'success' ):
      return {
        ...state,
        ...( action.data.cart && populateBOPISInfo( { data :action.data.cart }, state.bopisFullChainEnabled, state.onlineOnly ) )
      }

    case getServiceType( 'cartPickupInfoUpdate', 'success' ):
      return {
        ...state,
        ...populateBOPISInfo( action, state.bopisFullChainEnabled, state.onlineOnly ),
        showBOPISLoader : false,
        pickupStoreInfoUpdateSuccess: !!action.data.pickupStoreInfo
      };

    case getServiceType( 'removeItemFromCart', 'success' ):
      return {
        ...state,
        ...populateBOPISInfo( { data: action.data.type }, state.bopisFullChainEnabled, state.onlineOnly )
      };

    case getServiceType( 'pickupStoreInfoUpdate', 'success' ):
      const { cartResponse, storeAvailable } = action.data;
      return {
        ...state,
        ...( storeAvailable && {
          pickupStoreInfo: cartResponse.pickupStoreInfo,
          pickupStoreAddressInfo:{
            ...state.pickupStoreAddressInfo,
            address1: cartResponse.pickupStoreInfo?.storeContactInfo?.address?.address1 ?? null,
            city: cartResponse.pickupStoreInfo?.storeContactInfo?.address?.city ?? null,
            state: cartResponse.pickupStoreInfo?.storeContactInfo?.address?.state ?? null,
            zipCode: cartResponse.pickupStoreInfo?.storeContactInfo?.address?.zipCode ?? null
          },
          deliveryOption: cartResponse.deliveryOption
        } ),
        onlineOnly: cartResponse?.onlineOnly ?? state.onlineOnly
      };

    case getServiceType( 'cartPickupInfoUpdate', 'failure' ):
    case getServiceType( 'cartPickupInfoUpdate', 'canceled' ):
      return {
        ...state,
        deliveryOption: 'ship',
        pickupStoreInfo: null,
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: state.bopisFullChainEnabled,
        showBOPISLoader : false
      };

    case ALERT_WINDOW_RESIZE:
      return {
        ...state,
        isBopisEnabledMobile: state.isBopisEnabled && window.innerWidth < 992,
        isBopisEnabledDesktop: state.isBopisEnabled && window.innerWidth >= 992
      };

    case getServiceType( 'initCart', 'success' ):
      const pickupInfo = action.data.result.pickupInfo;
      return {
        ...state,
        isDeliveryOptionPickup:!!pickupInfo,
        pickupInformation: {
          ...state.pickupInformation,
          isDisplayPickupContactForm:!( pickupInfo && pickupInfo.primaryContactInfo ),
          isDisplayAlternatePickupPersonForm: !!( pickupInfo && pickupInfo.alternateContactInfo ),
          // populate tempAlternatePickupPersonData details if alternate contact details are already updated
          ...( pickupInfo && pickupInfo.alternateContactInfo && {
            tempAlternatePickupPersonData: {
              firstName:pickupInfo.alternateContactInfo.firstName.value,
              lastName:pickupInfo.alternateContactInfo.lastName.value,
              email:pickupInfo.alternateContactInfo.emailAddress.value
            }
          } )
        }
      };

    case getServiceType( 'switches', 'success' ):
      return {
        ...state,
        ...( has( action, 'data.switches.storePickupEnabled' ) && !isIntlSite() &&
        {
          isBopisEnabled: action.data.switches.storePickupEnabled,
          isBopisEnabledMobile: action.data.switches.storePickupEnabled && window.innerWidth < 992,
          isBopisEnabledDesktop: action.data.switches.storePickupEnabled && window.innerWidth >= 992
        } ),
        bopisFullChainEnabled: action?.data?.switches?.bopisFullChainEnabled ?? false
      };

    case getServiceType( 'updateCartItems', 'success' ):
      return {
        ...state,
        onlineOnly: action.data?.onlineOnly ?? state.onlineOnly
      };

    default:
      return state;

  }
}

export const populateBOPISInfo = ( action, bopisFullChainEnabled, onlineOnly )=>{
  return {
    deliveryOption: ( action.data.deliveryOption ) ? action.data.deliveryOption : 'ship',
    pickupStoreInfo: ( action.data.pickupStoreInfo ) ? action.data.pickupStoreInfo : null,
    pickupStoreAddressInfo: {
      address1: ( action.data.pickupStoreInfo ) ? action.data.pickupStoreInfo.storeContactInfo?.address?.address1 ?? null : null,
      city: ( action.data.pickupStoreInfo ) ? action.data.pickupStoreInfo.storeContactInfo?.address?.city ?? null : null,
      state: ( action.data.pickupStoreInfo ) ? action.data.pickupStoreInfo.storeContactInfo?.address?.state ?? null : null,
      zipCode: ( action.data.pickupStoreInfo ) ? action.data.pickupStoreInfo.storeContactInfo?.address?.zipCode ?? null : null
    },
    isEligibleToDisplayShipOrPickup: bopisFullChainEnabled || !!action.data.pickupStoreInfo,
    isDeliveryOptionPickup: ( action.data.deliveryOption === 'pickup' ),
    // onlineOnly flag will be set to true, if all the items in the bag are online only (not eligibile for pickup)
    onlineOnly: action.data?.onlineOnly ?? onlineOnly
  }
};

export const getPickupInformation = state => state.BOPIS.pickupInformation;

export const getBOPISState = state => state.BOPIS;
