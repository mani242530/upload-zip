
import {
  CHANGE as REDUXFORM_CHANGE
} from 'redux-form/lib/actionTypes';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import isFunction from 'lodash/isFunction';
import * as formatters from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import {
  TOGGLE_BOPIS_CONTACT_FORM_DISPLAY
} from '../../../events/bopis/bopis.events';
import reducer, {
  initialState,
  getPickupInformation,
  getBOPISState,
  populateBOPISInfo
} from './bopis.model';

describe( 'BOPIS reducer', () => {
  registerServiceName( 'user' );
  registerServiceName( 'cartPickupInfoUpdate' );
  registerServiceName( 'loadCart' );
  registerServiceName( 'deliveryOptionsUpdate' );
  registerServiceName( 'pickupStores' );
  registerServiceName( 'pickupStoreInfoUpdate' );
  registerServiceName( 'initCart' );
  registerServiceName( 'removeGiftFromCart' );
  registerServiceName( 'addItemToCart' );
  registerServiceName( 'selectGiftVariant' );
  registerServiceName( 'initiateCheckout' );
  registerServiceName( 'pickupContactInfoUpdate' );
  registerServiceName( 'removeItemFromCart' );
  registerServiceName( 'moveToSaveForLater' );
  registerServiceName( 'moveToBagFromSaveForLater' );
  registerServiceName( 'updateCartItems' );

  it( 'should have the proper default state', () =>{

    let expectedState = {
      pickupInformation: {
        isDisplayPickupContactForm: true,
        isDisplayAlternatePickupPersonForm: false,
        tempPickupContactInfoData: {},
        tempAlternatePickupPersonData: {}
      },
      pickupStoreAddressInfo: {
        address1: null,
        city: null,
        state: null,
        zipCode: null
      },
      deliveryOption: 'ship',
      pickupStoreInfo: null,
      isBopisEnabledMobile: false,
      isBopisEnabledDesktop: false,
      isEligibleToDisplayShipOrPickup: false,
      isDeliveryOptionPickup: false,
      isBopisEnabled: false,
      pickupStoreInfoUpdateSuccess: false,
      bopisFullChainEnabled: false,
      onlineOnly: false
    };

    expect( initialState ).toEqual( expectedState );
  } );

  it( 'should be a function', () =>{
    expect( isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the state', () => {
    const data = {
      data: {
        primaryContactInfo: {
          firstName:'testFirstName',
          lastName:undefined,
          emailaddress:undefined,
          phoneNumber:'(000) 000-0000'
        },
        alternateContactInfo: {
          firstName:'testAlternateContactFirstName',
          lastName:'last',
          email:undefined
        }
      },
      switches: {
        storePickupEnabled: false
      }
    }
    const res = {
      deliveryOption: 'ship',
      isDeliveryOptionPickup: false,
      isBopisEnabledMobile: false,
      isBopisEnabledDesktop: false,
      isEligibleToDisplayShipOrPickup: false,
      pickupInformation: {
        isDisplayAlternatePickupPersonForm: false,
        isDisplayPickupContactForm: true,
        tempAlternatePickupPersonData: {},
        tempPickupContactInfoData: {}
      },
      pickupStoreAddressInfo: {
        address1: null,
        city: null,
        state: null,
        zipCode: null
      },
      pickupStoreInfo: null,
      isBopisEnabled: false,
      pickupStoreInfoUpdateSuccess: false,
      bopisFullChainEnabled: false,
      onlineOnly: false
    }

    expect( reducer( undefined, { data } ) ).toEqual( res );
  } );

  describe( 'Pickup information', () => {

    it( 'should toggle Bopis Contact Form Display', () => {
      let actionCreator = {
        type: TOGGLE_BOPIS_CONTACT_FORM_DISPLAY,
        data: true
      };
      let expectedOutput1 = {
        pickupInformation: {
          isDisplayPickupContactForm: true
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput1 );
    } );

    it( 'should alternate pickup person form toggle button', () => {

      let actionCreator = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:'AlternatePickupPersonForm',
          field:'isAlternatePickupPersonEnable'
        },
        payload: true
      };

      let expectedOutput = {
        pickupInformation: {
          isDisplayAlternatePickupPersonForm: true
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

      let actionCreator1 = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:'AlternatePickupPersonForm',
          field:'isAlternatePickupPersonEnable'
        },
        payload: ''
      };

      let expectedOutput1 = {
        pickupInformation: {
          isDisplayAlternatePickupPersonForm: false
        }
      };
      expect( reducer( {}, actionCreator1 ) ).toEqual( expectedOutput1 );

      let actionCreator2 = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:'AlternatePickupPersonForm',
          field:'alternateFirstName'
        },
        payload: 'Test'
      };

      expect( reducer( {}, actionCreator2 ) ).toEqual( {} );

    } );

  } );

  describe( 'cart success reducers', () => {
    const services = [
      'removeGiftFromCart',
      'addItemToCart',
      'selectGiftVariant'
    ];

    for ( let service of services ){
      // eslint-disable-next-line no-loop-func
      it( `${ service } success is requested`, () => {

        let res = {
          deliveryOption: 'pickup',
          pickupStoreInfo: {
            storeContactInfo: {
              displayName: 'Test',
              address: {}
            },
            onlineOnly: true,
            storeTimings: '09:00 AM - 09:00PM'
          }
        };

        const actionCreator = {
          type: getServiceType( service, 'success' ),
          data: res
        };

        let excepted = {
          deliveryOption: 'pickup',
          isDeliveryOptionPickup: true,
          pickupStoreInfo: {
            storeContactInfo: {
              displayName: 'Test',
              address: {}
            },
            onlineOnly: true,
            storeTimings: '09:00 AM - 09:00PM'
          },
          pickupStoreAddressInfo: {
            address1: null,
            city: null,
            state: null,
            zipCode: null
          },
          showBOPISLoader : false,
          isEligibleToDisplayShipOrPickup: true
        };

        expect( reducer( {}, actionCreator ) ).toEqual( excepted );

      } );

      // eslint-disable-next-line no-loop-func
      it( `${ service } success is requested with pickupStoreInfo undefined`, () => {

        let res = {
          pickupStoreInfo: null
        };

        const actionCreator = {
          type: getServiceType( service, 'success' ),
          data: res
        };

        let excepted = {
          deliveryOption: 'ship',
          isDeliveryOptionPickup: false,
          pickupStoreInfo: null,
          pickupStoreAddressInfo: {
            address1: null,
            city: null,
            state: null,
            zipCode: null
          },
          showBOPISLoader : false,
          isEligibleToDisplayShipOrPickup: false
        };

        expect( reducer( {}, actionCreator ) ).toEqual( excepted );

      } );

      // eslint-disable-next-line no-loop-func
      it( `${ service } success is requested`, () => {

        let res = {
          deliveryOption: 'pickup',
          pickupStoreInfo: {
            storeContactInfo: {
              displayName: 'Test',
              address: {}
            },
            storeTimings: '09:00 AM - 09:00PM'
          }
        };

        const actionCreator = {
          type: getServiceType( service, 'success' ),
          data: res
        };

        let excepted = {
          deliveryOption: 'pickup',
          isDeliveryOptionPickup: true,
          pickupStoreInfo: {
            storeContactInfo: {
              displayName: 'Test',
              address: {}
            },
            storeTimings: '09:00 AM - 09:00PM'
          },
          pickupStoreAddressInfo: {
            address1: null,
            city: null,
            state: null,
            zipCode: null
          },
          showBOPISLoader : false,
          isEligibleToDisplayShipOrPickup: true
        };

        expect( reducer( {}, actionCreator ) ).toEqual( excepted );

      } );
    }
  } );
  describe( 'deliveryOptionsUpdate success reducers', () => {
    const service = 'deliveryOptionsUpdate'


    it( `${ service } success is requested`, () => {

      let res = {
        deliveryOption: 'pickup',
        pickupStoreInfo: {
          storeContactInfo: {
            displayName: 'Test'
          },
          onlineOnly: true,
          storeTimings: '09:00 AM - 09:00PM'
        }
      };

      const actionCreator = {
        type: getServiceType( service, 'success' ),
        data: res
      };

      let excepted = {
        deliveryOption: 'pickup',
        isDeliveryOptionPickup: true,
        pickupStoreInfo: {
          storeContactInfo: {
            displayName: 'Test'
          },
          onlineOnly: true,
          storeTimings: '09:00 AM - 09:00PM'
        },
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        showBOPISLoader : false,
        isEligibleToDisplayShipOrPickup: true,
        pickupStoreInfoUpdateSuccess:true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );

    } );


    it( `${ service } success is requested with pickupStoreInfo undefined`, () => {

      let res = {
        pickupStoreInfo: null
      };

      const actionCreator = {
        type: getServiceType( service, 'success' ),
        data: res
      };

      let excepted = {
        deliveryOption: 'ship',
        isDeliveryOptionPickup: false,
        pickupStoreInfo: null,
        showBOPISLoader : false,
        isEligibleToDisplayShipOrPickup: false,
        pickupStoreInfoUpdateSuccess:false,
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );

    } );

  } );

  it( 'cartPickupInfoUpdate success-pickupStoreInfoUpdateSuccess set to true if store information is present', () => {

    let res = {
      deliveryOption: 'pickup',
      pickupStoreInfo: {
        storeContactInfo: {
          displayName: 'Test',
          address: {}
        },
        storeTimings: '09:00 AM - 09:00PM'
      }
    };

    const actionCreator = {
      type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
      data: res
    };

    let expectedOutput = {
      deliveryOption: 'pickup',
      isDeliveryOptionPickup: true,
      pickupStoreInfo: {
        storeContactInfo: {
          displayName: 'Test',
          address: {}
        },
        storeTimings: '09:00 AM - 09:00PM'
      },
      pickupStoreAddressInfo: {
        address1: null,
        city: null,
        state: null,
        zipCode: null
      },
      isEligibleToDisplayShipOrPickup: true,
      showBOPISLoader: false,
      pickupStoreInfoUpdateSuccess: true
    };

    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'cartPickupInfoUpdate success-pickupStoreInfoUpdateSuccess set to false if store information is not present', () => {

    let res = {
      deliveryOption: 'pickup',
      pickupStoreInfo: null
    };

    const actionCreator = {
      type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
      data: res
    };

    let expectedOutput = {
      deliveryOption: 'pickup',
      isDeliveryOptionPickup: true,
      pickupStoreInfo:null,
      pickupStoreAddressInfo: {
        address1: null,
        city: null,
        state: null,
        zipCode: null
      },
      isEligibleToDisplayShipOrPickup: false,
      showBOPISLoader: false,
      pickupStoreInfoUpdateSuccess: false
    };

    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'cartPickupInfoUpdate success- onlineOnly set to true if onlineOnly flag is true', () => {

    let res = {
      deliveryOption: 'pickup',
      pickupStoreInfo: {
        storeContactInfo: {
          displayName: 'Test',
          address: {}
        },
        storeTimings: '09:00 AM - 09:00PM'
      },
      onlineOnly: true
    };

    const actionCreator = {
      type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
      data: res
    };

    let expectedOutput = {
      deliveryOption: 'pickup',
      isDeliveryOptionPickup: true,
      pickupStoreInfo: {
        storeContactInfo: {
          displayName: 'Test',
          address: {}
        },
        storeTimings: '09:00 AM - 09:00PM'
      },
      pickupStoreAddressInfo: {
        address1: null,
        city: null,
        state: null,
        zipCode: null
      },
      isEligibleToDisplayShipOrPickup: true,
      showBOPISLoader: false,
      pickupStoreInfoUpdateSuccess: true,
      onlineOnly: true
    };

    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'cartPickupInfoUpdate success- onlineOnly set to false if onlineOnly flag is false', () => {

    let res = {
      deliveryOption: 'pickup',
      pickupStoreInfo: {
        storeContactInfo: {
          displayName: 'Test',
          address: {}
        },
        storeTimings: '09:00 AM - 09:00PM'
      },
      onlineOnly: false
    };

    const actionCreator = {
      type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
      data: res
    };

    let expectedOutput = {
      deliveryOption: 'pickup',
      isDeliveryOptionPickup: true,
      pickupStoreInfo: {
        storeContactInfo: {
          displayName: 'Test',
          address: {}
        },
        storeTimings: '09:00 AM - 09:00PM'
      },
      pickupStoreAddressInfo: {
        address1: null,
        city: null,
        state: null,
        zipCode: null
      },
      isEligibleToDisplayShipOrPickup: true,
      showBOPISLoader: false,
      pickupStoreInfoUpdateSuccess: true,
      onlineOnly: false
    };

    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'cartPickupInfoUpdate success - onlineOnly set to state.onlineOnly if onlineOnly flag is undefined', () => {

    let state = {
      onlineOnly: false
    };
    let res = {
      deliveryOption: 'pickup',
      pickupStoreInfo: {
        storeContactInfo: {
          displayName: 'Test',
          address: {}
        },
        storeTimings: '09:00 AM - 09:00PM'
      }
    };

    const actionCreator = {
      type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
      data: res
    };

    let expectedOutput = {
      deliveryOption: 'pickup',
      isDeliveryOptionPickup: true,
      pickupStoreInfo: {
        storeContactInfo: {
          displayName: 'Test',
          address: {}
        },
        storeTimings: '09:00 AM - 09:00PM'
      },
      pickupStoreAddressInfo: {
        address1: null,
        city: null,
        state: null,
        zipCode: null
      },
      isEligibleToDisplayShipOrPickup: true,
      showBOPISLoader: false,
      pickupStoreInfoUpdateSuccess: true,
      onlineOnly: false
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'removeItemFromCart success', () => {

    let res = {
      data: {
        type:{
          deliveryOption: 'ship',
          pickupStoreInfo: {
            available: false,
            storeContactInfo: {
              displayName: 'Test',
              address: {}
            },
            storeTimings: '09:00 AM - 09:00PM'
          },
          onlineOnly: true
        }
      }
    };
    const actionCreator = {
      type: getServiceType( 'removeItemFromCart', 'success' ),
      data: res.data
    };
    let expectedOutput = {
      deliveryOption: 'ship',
      isDeliveryOptionPickup: false,
      pickupStoreInfo: {
        available: false,
        storeContactInfo: {
          displayName: 'Test',
          address: {}
        },
        storeTimings: '09:00 AM - 09:00PM'
      },
      pickupStoreAddressInfo: {
        address1: null,
        city: null,
        state: null,
        zipCode: null
      },
      isEligibleToDisplayShipOrPickup: true,
      onlineOnly: true
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'initCart success - to set isDeliveryOptionPickup to true if pickupInfo is not null in initcart response ', () => {

    let res = {
      result:{
        pickupInfo: {
          storeInfo:{}
        }
      }
    };
    const actionCreator = {
      type: getServiceType( 'initCart', 'success' ),
      data: res
    };

    let excepted = {
      isDeliveryOptionPickup: true,
      pickupInformation: {
        isDisplayAlternatePickupPersonForm: false,
        isDisplayPickupContactForm:true
      }
    };

    expect( reducer( {}, actionCreator ) ).toEqual( excepted );

  } );
  it( 'initCart success -  to set isDisplayAlternatePickupPersonForm to true if pickupInfo contains alternateContactInfo', () => {

    let res = {
      result:{
        pickupInfo: {
          alternateContactInfo: {
            firstName:{ value:'testAlternateContactFirstName' },
            lastName:{ value:'lastName' },
            emailAddress:{ value:'test@ulta.com' }
          }
        }
      }
    };

    const actionCreator = {
      type: getServiceType( 'initCart', 'success' ),
      data: res
    };

    let excepted = {
      isDeliveryOptionPickup: true,
      pickupInformation: {
        isDisplayAlternatePickupPersonForm: true,
        isDisplayPickupContactForm:true,
        tempAlternatePickupPersonData:{
          'email':'test@ulta.com',
          firstName:'testAlternateContactFirstName',
          lastName:'lastName'
        }
      }
    };

    expect( reducer( {}, actionCreator ) ).toEqual( excepted );

  } );

  describe( 'init cart success scenarios for isDisplayPickupContactForm', () => {

    it( 'initCart success - to set isDisplayPickupContactForm to false if primaryContactInfo details is present', () => {
      let res = {
        result:{
          pickupInfo: {
            primaryContactInfo:{
              firstName:'john'
            }
          }
        }
      };
      const actionCreator = {
        type: getServiceType( 'initCart', 'success' ),
        data: res
      };
      let expected = {
        isDeliveryOptionPickup: true,
        pickupInformation: {
          isDisplayAlternatePickupPersonForm: false,
          isDisplayPickupContactForm:false
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'initCart success - to set isDisplayPickupContactForm to true if primaryContactInfo details is not present', () => {
      let res = {
        result:{
          pickupInfo: {
            primaryContactInfo:null
          }
        }
      };
      const actionCreator = {
        type: getServiceType( 'initCart', 'success' ),
        data: res
      };
      let expected = {
        isDeliveryOptionPickup: true,
        pickupInformation: {
          isDisplayAlternatePickupPersonForm: false,
          isDisplayPickupContactForm:true
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

  } )

  describe( 'pickupStoreInfoUpdate', () => {

    it( 'should set the pickup store info correctly if all items are available for pickup', () => {
      let res = {
        storeAvailable: true,
        cartResponse: {
          pickupStoreInfo:{
            storeContactInfo: {
              displayName: 'Test',
              address: {
                address1: 'xyz',
                city: 'abc',
                state: 'IL',
                zipCode: '12345-6789'
              }
            }
          },
          deliveryOption: 'pickup',
          storeTimings: '09:00 AM - 09:00PM'
        }
      };

      const actionCreator = {
        type: getServiceType( 'pickupStoreInfoUpdate', 'success' ),
        data: res
      };

      let excepted = {
        deliveryOption:'pickup',
        pickupStoreInfo: res.cartResponse.pickupStoreInfo,
        pickupStoreAddressInfo: {
          address1: 'xyz',
          city: 'abc',
          state: 'IL',
          zipCode: '12345-6789'
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );

    } );

    it( 'should not set the pickup store info if all items are not available for pickup', () => {
      let res = {
        storeAvailable: false,
        store: {
          storeContactInfo: {
            displayName: 'Test'
          },
          storeTimings: '09:00 AM - 09:00PM'
        }
      };

      const actionCreator = {
        type: getServiceType( 'pickupStoreInfoUpdate', 'success' ),
        data: res
      };

      expect( reducer( {}, actionCreator ) ).toEqual( { } );

    } );

    it( 'should set onlineOnly as true if onlineOnly flag is true', () => {
      let res = {
        storeAvailable: true,
        cartResponse: {
          pickupStoreInfo:{
            storeContactInfo: {
              displayName: 'Test',
              address: {}
            }
          },
          onlineOnly: true,
          storeTimings: '09:00 AM - 09:00PM',
          deliveryOption: 'ship'
        }
      };

      const actionCreator = {
        type: getServiceType( 'pickupStoreInfoUpdate', 'success' ),
        data: res
      };

      let excepted = {
        deliveryOption:'ship',
        pickupStoreInfo: res.cartResponse.pickupStoreInfo,
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        onlineOnly: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );

    } );

    it( 'should set onlineOnly as false if onlineOnly flag is false', () => {
      let res = {
        storeAvailable: true,
        cartResponse: {
          pickupStoreInfo:{
            storeContactInfo: {
              displayName: 'Test',
              address: {}
            }
          },
          onlineOnly: false,
          storeTimings: '09:00 AM - 09:00PM',
          deliveryOption: 'pickup'
        }
      };

      const actionCreator = {
        type: getServiceType( 'pickupStoreInfoUpdate', 'success' ),
        data: res
      };

      let excepted = {
        deliveryOption:'pickup',
        pickupStoreInfo: res.cartResponse.pickupStoreInfo,
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        onlineOnly: false
      };

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );

    } );

    it( 'should set onlineOnly as state.onlineOnly if onlineOnly flag is undefined', () => {
      let state = {
        onlineOnly: false
      }
      let res = {
        storeAvailable: true,
        cartResponse: {
          pickupStoreInfo:{
            storeContactInfo: {
              displayName: 'Test',
              address: {}
            }
          },
          storeTimings: '09:00 AM - 09:00PM',
          deliveryOption: 'pickup'
        }
      };

      const actionCreator = {
        type: getServiceType( 'pickupStoreInfoUpdate', 'success' ),
        data: res
      };

      let expected = {
        deliveryOption:'pickup',
        pickupStoreInfo: res.cartResponse.pickupStoreInfo,
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        onlineOnly: false
      };

      expect( reducer( state, actionCreator ) ).toEqual( expected );

    } );


  } );

  describe( 'updateCartItems success', () => {
    it( 'should set onlineOnly as true if onlineOnly flag is true', () => {

      let res = {
        onlineOnly: true
      };
      const actionCreator = {
        type: getServiceType( 'updateCartItems', 'success' ),
        data: res
      };
      let expectedOutput = {
        onlineOnly: true
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set onlineOnly as false if onlineOnly flag is false', () => {

      let res = {
        onlineOnly: false
      };
      const actionCreator = {
        type: getServiceType( 'updateCartItems', 'success' ),
        data: res
      };
      let expectedOutput = {
        onlineOnly: false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set onlineOnly as state.onlineOnly if onlineOnly flag is undefined', () => {

      let state = {
        onlineOnly: false
      };
      let res = {};
      const actionCreator = {
        type: getServiceType( 'updateCartItems', 'success' ),
        data: res
      };
      let expectedOutput = {
        onlineOnly: false
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'pickupContactInfoUpdate loading', () => {

    it( 'should set the pickupInformation correctly if it has alternateContactInfo', () => {
      const data = {
        data: {
          alternateContactInfo: {
            firstName:'testAlternateContactFirstName',
            lastName:'lastName',
            email:'test@ulta.com'
          }
        }
      }

      const actionCreator = {
        type: getServiceType( 'pickupContactInfoUpdate', 'loading' ),
        data
      };

      const excepted = {
        pickupInformation: {
          tempAlternatePickupPersonData: {
            firstName:'testAlternateContactFirstName',
            lastName:'lastName',
            email:'test@ulta.com'
          }
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );

    } );

    it( 'should set the pickupInformation correctly if it has primaryContactInfo', () => {
      const data = {
        data: {
          primaryContactInfo: {
            firstName:'testAlternateContactFirstName',
            lastName:'lastName',
            email:'test@ulta.com',
            phoneNumber:'379-513-2513'
          }
        }
      }

      const actionCreator = {
        type: getServiceType( 'pickupContactInfoUpdate', 'loading' ),
        data
      };

      const excepted = {
        pickupInformation: {
          tempPickupContactInfoData: {
            firstName:'testAlternateContactFirstName',
            lastName:'lastName',
            emailaddress:'test@ulta.com',
            phoneNumber:'(379) 513-2513'
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should not have any error and return initial state if alternateContactInfo is null', () => {
      const data = {
        data: {
          alternateContactInfo: null
        }
      }

      const actionCreator = {
        type: getServiceType( 'pickupContactInfoUpdate', 'loading' ),
        data
      };

      const innitialState = {
        pickupInformation: {
          tempAlternatePickupPersonData: { }
        }
      };

      expect( reducer( initialState, actionCreator ) ).toEqual( initialState );

    } );
  } );

  describe( 'getPickupInformation', () => {
    it( 'getPickupInformation should return pickupInformation data', () => {
      const state = {
        BOPIS: {
          pickupInformation: {
            isDisplayPickupContactForm: true,
            isDisplayAlternatePickupPersonForm: false,
            tempPickupContactInfoData: {},
            tempAlternatePickupPersonData: {}
          }
        }
      };
      expect( getPickupInformation( state ) ).toEqual( state.BOPIS.pickupInformation );
    } );
  } );

  describe( 'getBOPISState', () => {
    it( 'should return BOPIS state', () => {
      const state = {
        BOPIS: {
          pickupInformation: {
            isDisplayPickupContactForm: true,
            isDisplayAlternatePickupPersonForm: false,
            tempPickupContactInfoData: {},
            tempAlternatePickupPersonData: {}
          },
          deliveryOption: 'ship',
          pickupStoreInfo: null,
          pickupStoreAddressInfo: {
            address1: null,
            city: null,
            state: null,
            zipCode: null
          },
          isBopisEnabledMobile: false,
          isBopisEnabledDesktop: false,
          isEligibleToDisplayShipOrPickup: false,
          isDeliveryOptionPickup: false,
          isBopisEnabled: false,
          pickupStoreInfoUpdateSuccess: false
        }
      };
      expect( getBOPISState( state ) ).toEqual( state.BOPIS );
    } );
  } );

  describe( 'pickupContactInfoUpdate success', () => {
    it( 'should set the isDisplayPickupContactForm as false if isSignedIn and isPrimaryContactInfoUpdated is true', () => {
      const data = {
        isSignedIn: true,
        isPrimaryContactInfoUpdated: true
      }
      const actionCreator = {
        type: getServiceType( 'pickupContactInfoUpdate', 'success' ),
        data
      };
      const excepted = {
        pickupInformation: {
          isDisplayPickupContactForm: false,
          tempAlternatePickupPersonData:null
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should not return isDisplayPickupContactForm in pickupInformation if isSaveAction is undefined', () => {
      const data = {
        isSignedIn: true
      }
      const actionCreator = {
        type: getServiceType( 'pickupContactInfoUpdate', 'success' ),
        data
      };
      const excepted = {
        pickupInformation: {
          tempAlternatePickupPersonData:null
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
  } );

  describe( 'cartPickupInfoUpdate', () => {
    const types = [
      'failure',
      'canceled'
    ];

    for ( let type of types ){
      // eslint-disable-next-line no-loop-func
      it( `cartPickupInfoUpdate is ${ type }`, () => {
        const actionCreator = {
          type: getServiceType( 'cartPickupInfoUpdate', type ),
          data: null
        };

        const excepted = {
          deliveryOption: 'ship',
          pickupStoreInfo: null,
          pickupStoreAddressInfo: {
            address1: null,
            city: null,
            state: null,
            zipCode: null
          },
          isEligibleToDisplayShipOrPickup: false,
          showBOPISLoader : false,
          bopisFullChainEnabled: false
        };
        const state = {
          bopisFullChainEnabled: false
        };

        expect( reducer( state, actionCreator ) ).toEqual( excepted );
      } );

    }
  } );

  describe( 'switches success', () => {
    it( 'should set isBopisEnabled flag as true and isBopisEnabledDesktop as true if storePickupEnabled is true for desktop view', () => {
      window.innerWidth = 1280;
      const data = {
        switches: {
          storePickupEnabled : true
        }
      }
      const actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data
      };
      const excepted = {
        isBopisEnabled : true,
        isBopisEnabledMobile: false,
        isBopisEnabledDesktop: true,
        bopisFullChainEnabled: false
      };

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should set isBopisEnabled flag as true and isBopisEnabledMobile as true if storePickupEnabled is true for mobile view', () => {
      window.innerWidth = 990;
      const data = {
        switches: {
          storePickupEnabled : true
        }
      }
      const actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data
      };
      const excepted = {
        isBopisEnabled : true,
        isBopisEnabledMobile: true,
        isBopisEnabledDesktop: false,
        bopisFullChainEnabled: false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should return bopisFullChainEnabled as false if switches is empty', () => {
      const data = {
        switches: {}
      }
      const actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data
      };
      expect( reducer( {}, actionCreator ) ).toEqual( { bopisFullChainEnabled: false } );
    } );

    it( 'should not set bopis flags for canada shipping (isIntlSite is true)', () => {
      formatters.isIntlSite = () => true;
      const data = {
        switches: {
          storePickupEnabled:true
        }
      }
      const actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data
      };
      let initialState = {
        isBopisEnabled:false,
        isBopisEnabledMobile:false,
        isBopisEnabledDesktop:false,
        bopisFullChainEnabled: false
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( initialState );
    } );

    it( 'should set bopis flags properly if isIntlSite is false', () => {
      formatters.isIntlSite = () => false;
      window.innerWidth = 990;
      const data = {
        switches: {
          storePickupEnabled:true
        }
      }
      const actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data
      };
      let initialState = {
        isBopisEnabled:false,
        isBopisEnabledMobile:false,
        isBopisEnabledDesktop:false
      }
      let expectedOutput = {
        isBopisEnabled:true,
        isBopisEnabledMobile:true,
        isBopisEnabledDesktop:false,
        bopisFullChainEnabled: false
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set bopisFullChainEnabled flag as true  if bopisFullChainEnabled is true', () => {
      const data = {
        switches: {
          bopisFullChainEnabled: true
        }
      }
      const actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data
      };
      let expectedbopisFullChainEnabled = true
      expect( reducer( {}, actionCreator ).bopisFullChainEnabled ).toEqual( expectedbopisFullChainEnabled );
    } );

    it( 'should set bopisFullChainEnabled flag as false  if bopisFullChainEnabled is false', () => {
      const data = {
        switches: {
          bopisFullChainEnabled: false
        }
      }
      const actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data
      };
      let expectedbopisFullChainEnabled = false
      expect( reducer( {}, actionCreator ).bopisFullChainEnabled ).toEqual( expectedbopisFullChainEnabled );
    } );

    it( 'should set bopisFullChainEnabled flag as false  if bopisFullChainEnabled is undefined', () => {
      const data = {
        switches: {
          bopisFullChainEnabled: undefined
        }
      }
      const actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data
      };
      let expectedbopisFullChainEnabled = false
      expect( reducer( {}, actionCreator ).bopisFullChainEnabled ).toEqual( expectedbopisFullChainEnabled );
    } );

  } );

  describe( 'loadCart success', () => {
    it( 'should return expected if isBopisEnabled is false', () => {
      const state = {
        isBopisEnabled: false
      }
      const data = {
        deliveryOption: 'ship'
      }
      const actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data
      };
      const excepted = {
        isBopisEnabled: false
      };
      expect( reducer( state, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should return expected if isBopisEnabled is true', () => {
      const state = {
        isBopisEnabled: true
      }
      const data = {
        deliveryOption: 'ship'
      }
      const actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data
      };
      const excepted = {
        deliveryOption: 'ship',
        isBopisEnabled: true,
        isDeliveryOptionPickup: false,
        pickupStoreInfo: null,
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: false,
        showBOPISLoader : true
      };
      expect( reducer( state, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should return expected without showBOPISLoader if isBopisEnabled is true and pickupStoreInfo is not empty', () => {
      const state = {
        isBopisEnabled: true,
        pickupStoreInfo:{
          storeContactInfo: {
            displayName: 'Test',
            address: {
            }
          }
        }
      }
      const data = {
        deliveryOption: 'pickup',
        pickupStoreInfo:{
          storeContactInfo: {
            displayName: 'Test',
            address: {}
          }
        }
      }
      const actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data
      };
      const excepted = {
        deliveryOption: 'pickup',
        isBopisEnabled: true,
        isDeliveryOptionPickup: true,
        pickupStoreInfo: {
          storeContactInfo: {
            displayName: 'Test',
            address: {}
          }
        },
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: true
      };
      expect( reducer( state, actionCreator ) ).toEqual( excepted );
    } );
  } );

  describe( 'loadCart loading', () => {
    it( 'should return isEligibleToDisplayShipOrPickup false on initial cart load', () => {

      const actionCreator = {
        type: getServiceType( 'loadCart', 'loading' )
      };
      const excepted = {
        isEligibleToDisplayShipOrPickup: false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should return isEligibleToDisplayShipOrPickup false on load of loadcart', () => {
      const state = {
        isEligibleToDisplayShipOrPickup: true
      }

      const actionCreator = {
        type: getServiceType( 'loadCart', 'loading' )
      };
      const excepted = {
        isEligibleToDisplayShipOrPickup: false
      };
      expect( reducer( state, actionCreator ) ).toEqual( excepted );
    } );

  } );

  describe( 'initiateCheckout success', () => {
    it( 'should return expected if result is false', () => {
      const state = {
        onlineOnly: false
      }
      const data = {
        result: false
      };
      const actionCreator = {
        type: getServiceType( 'initiateCheckout', 'success' ),
        data
      };
      const excepted = {
        deliveryOption: 'ship',
        pickupStoreInfo: null,
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: false,
        isDeliveryOptionPickup: false,
        onlineOnly: false
      };

      expect( reducer( state, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should return expected if result is true', () => {
      const data = {
        result: true
      };
      const actionCreator = {
        type: getServiceType( 'initiateCheckout', 'success' ),
        data
      };

      expect( reducer( { }, actionCreator ) ).toEqual( { } );
    } );

  } );

  describe( 'moveToSaveForLater success', () => {

    it( 'should update pickup store information on moveToSaveForLater success', () => {
      const data = {
        saveForLaterItems:{},
        cart:{
          deliveryOption:'ship',
          pickupStoreInfo:{
            available:false,
            selected:true,
            storeId:269,
            storeContactInfo: {
              address: {
                address1: 'xyz',
                city: 'abc',
                state: 'IL',
                zipCode: '12345-6789'
              }
            }
          }
        }
      };
      const actionCreator = {
        type: getServiceType( 'moveToSaveForLater', 'success' ),
        data
      };
      const excepted = {
        deliveryOption: 'ship',
        pickupStoreInfo:{
          available:false,
          selected:true,
          storeId:269,
          storeContactInfo: {
            address: {
              address1: 'xyz',
              city: 'abc',
              state: 'IL',
              zipCode: '12345-6789'
            }
          }
        },
        pickupStoreAddressInfo: {
          address1: 'xyz',
          city: 'abc',
          state: 'IL',
          zipCode: '12345-6789'
        },
        isEligibleToDisplayShipOrPickup: true,
        isDeliveryOptionPickup: false
      };

      expect( reducer( { }, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should return existing state if cart is null in the data', () => {
      const data = {
        saveForLaterItems:{},
        cart:null
      };
      const actionCreator = {
        type: getServiceType( 'moveToSaveForLater', 'success' ),
        data
      };
      const state = {
        deliveryOption: 'ship',
        pickupStoreInfo:{
          available:false,
          selected:true,
          storeId:269
        },
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: true,
        isDeliveryOptionPickup: false
      };

      expect( reducer( state, actionCreator ) ).toEqual( state );
    } );

    it( 'should update onlineOnly on moveToSaveForLater success', () => {
      const state = {
        onlineOnly: true
      }
      const data = {
        saveForLaterItems:{},
        cart:{
          deliveryOption:'ship',
          pickupStoreInfo:{
            available:false,
            selected:true,
            storeId:269,
            storeContactInfo: {
              address: {}
            }
          },
          onlineOnly: true
        }
      };
      const actionCreator = {
        type: getServiceType( 'moveToSaveForLater', 'success' ),
        data
      };
      const expected = {
        deliveryOption: 'ship',
        pickupStoreInfo:{
          available:false,
          selected:true,
          storeId:269,
          storeContactInfo: {
            address: {}
          }
        },
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: true,
        isDeliveryOptionPickup: false,
        onlineOnly: true
      };

      expect( reducer( state, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'moveToBagFromSaveForLater success', () => {

    it( 'should update deliveryOption on moveToBagFromSaveForLater success', () => {
      const state = {
        deliveryOption: 'pickup',
        pickupStoreInfo: null
      }
      const data = {
        cart:{
          deliveryOption:'ship',
          pickupStoreInfo:{
            storeId: 1,
            storeContactInfo: {
              address: {
                address1: 'xyz'
              }
            }
          }
        }
      };
      const actionCreator = {
        type: getServiceType( 'moveToBagFromSaveForLater', 'success' ),
        data
      };
      const expected = {
        deliveryOption: 'ship',
        pickupStoreInfo:{
          storeId: 1,
          storeContactInfo: {
            address: {
              address1: 'xyz'
            }
          }
        },
        pickupStoreAddressInfo: {
          address1: 'xyz',
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: true,
        isDeliveryOptionPickup: false
      };

      expect( reducer( state, actionCreator ) ).toEqual( expected );
    } );

    it( 'should update onlineOnly on moveToBagFromSaveForLater success', () => {
      const state = {
        deliveryOption: 'pickup',
        pickupStoreInfo: null,
        onlineOnly: true
      }
      const data = {
        cart:{
          deliveryOption:'ship',
          pickupStoreInfo:{
            storeId: 1,
            storeContactInfo: {
              address: {
              }
            }
          },
          onlineOnly: true
        }
      };
      const actionCreator = {
        type: getServiceType( 'moveToBagFromSaveForLater', 'success' ),
        data
      };
      const expected = {
        deliveryOption: 'ship',
        pickupStoreInfo:{
          storeId: 1,
          storeContactInfo: {
            address: {
            }
          }
        },
        pickupStoreAddressInfo: {
          address1: null,
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: true,
        isDeliveryOptionPickup: false,
        onlineOnly: true
      };

      expect( reducer( state, actionCreator ) ).toEqual( expected );
    } );

  } );

  describe( 'populateBOPISInfo ', () => {

    it( 'should return the isEligibleToDisplayShipOrPickup as true if bopisFullChainEnabled is undefined and pickupStoreInfo is present', () => {
      const bopisFullChainEnabled = undefined;
      const action = {
        data:{
          deliveryOption:'ship',
          pickupStoreInfo:{
            storeId: 1,
            storeContactInfo: {
              address: {
                address1: 'xyz'
              }
            }
          }
        }
      };
      const expectedisEligibleToDisplayShipOrPickup = true ;

      expect( populateBOPISInfo( action, bopisFullChainEnabled ).isEligibleToDisplayShipOrPickup ).toEqual( expectedisEligibleToDisplayShipOrPickup );
    } );

    it( 'should return the isEligibleToDisplayShipOrPickup as false if bopisFullChainEnabled is false and pickupStoreInfo is null ', () => {
      const bopisFullChainEnabled = false;
      const action = {
        data:{
          deliveryOption:'ship',
          pickupStoreInfo: null
        }
      };
      const expectedisEligibleToDisplayShipOrPickup = false ;

      expect( populateBOPISInfo( action, bopisFullChainEnabled ).isEligibleToDisplayShipOrPickup ).toEqual( expectedisEligibleToDisplayShipOrPickup );
    } );

    it( 'should return the isEligibleToDisplayShipOrPickup as true if both bopisFullChainEnabled  and pickupStoreInfo is present ', () => {
      const bopisFullChainEnabled = true;
      const action = {
        data:{
          deliveryOption:'ship',
          pickupStoreInfo:{
            storeId: 1,
            storeContactInfo: {
              address: {
                address1: 'xyz'
              }
            }
          }
        }
      };
      const expectedisEligibleToDisplayShipOrPickup = true ;

      expect( populateBOPISInfo( action, bopisFullChainEnabled ).isEligibleToDisplayShipOrPickup ).toEqual( expectedisEligibleToDisplayShipOrPickup );
    } );

    it( 'should return isEligibleToDisplayShipOrPickup flag as boolean value of action.data.pickupStoreInfo if bopisFullChainEnabled is undefined ', () => {

      const bopisFullChainEnabled = undefined;
      const action = {
        data:{
          deliveryOption:'ship',
          pickupStoreInfo:null
        }
      };
      const expectedisEligibleToDisplayShipOrPickup = false ;

      expect( populateBOPISInfo( action, bopisFullChainEnabled ).isEligibleToDisplayShipOrPickup ).toEqual( expectedisEligibleToDisplayShipOrPickup );
    } );

    it( 'should return the isEligibleToDisplayShipOrPickup as true if bopisFullChainEnabled is true and pickupStoreInfo is null ', () => {
      const bopisFullChainEnabled = true;
      const action = {
        data:{
          deliveryOption:'ship',
          pickupStoreInfo:null
        }
      };
      const expectedisEligibleToDisplayShipOrPickup = true ;

      expect( populateBOPISInfo( action, bopisFullChainEnabled ).isEligibleToDisplayShipOrPickup ).toEqual( expectedisEligibleToDisplayShipOrPickup );
    } );

    it( 'should return the  deliveryoption as ship and isDeliveryOptionPickup as false when deliveryOption is ship ', () => {
      const bopisFullChainEnabled = true;
      const action = {
        data:{
          deliveryOption:'ship',
          pickupStoreInfo:{
            storeId: 1,
            storeContactInfo: {
              address: {
                address1: 'xyz'
              }
            }
          }
        }
      };
      const expectedOutput = {
        deliveryOption: 'ship',
        pickupStoreInfo:{
          storeId:1,
          storeContactInfo: {
            address: {
              address1: 'xyz'
            }
          }
        },
        pickupStoreAddressInfo: {
          address1: 'xyz',
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: true,
        isDeliveryOptionPickup: false

      } ;

      expect( populateBOPISInfo( action, bopisFullChainEnabled ) ).toEqual( expectedOutput );
    } );

    it( 'should return the  deliveryoption as pickup and isDeliveryOptionPickup as true when deliveryOption is pickup ', () => {
      const bopisFullChainEnabled = true;
      const action = {
        data:{
          deliveryOption:'pickup',
          pickupStoreInfo:{
            storeId: 1,
            storeContactInfo: {
              address: {
                address1: 'xyz'
              }
            }
          }
        }
      };
      const expectedOutput = {
        deliveryOption: 'pickup',
        pickupStoreInfo:{
          storeId:1,
          storeContactInfo: {
            address: {
              address1: 'xyz'
            }
          }
        },
        pickupStoreAddressInfo: {
          address1: 'xyz',
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: true,
        isDeliveryOptionPickup: true

      } ;

      expect( populateBOPISInfo( action, bopisFullChainEnabled ) ).toEqual( expectedOutput );
    } );

    it( 'should return the onlineOnly as true when onlineOnly is true ', () => {
      const bopisFullChainEnabled = true;
      const onlineOnly = false;
      const action = {
        data:{
          deliveryOption:'pickup',
          pickupStoreInfo:{
            storeId: 1,
            storeContactInfo: {
              address: {
                address1: 'xyz'
              }
            }
          },
          onlineOnly: true
        }
      };
      const expectedOutput = {
        deliveryOption: 'pickup',
        pickupStoreInfo:{
          storeId:1,
          storeContactInfo: {
            address: {
              address1: 'xyz'
            }
          }
        },
        pickupStoreAddressInfo: {
          address1: 'xyz',
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: true,
        isDeliveryOptionPickup: true,
        onlineOnly: true
      } ;

      expect( populateBOPISInfo( action, bopisFullChainEnabled, onlineOnly ) ).toEqual( expectedOutput );
    } );

    it( 'should return the onlineOnly as false when onlineOnly is false ', () => {
      const bopisFullChainEnabled = true;
      const onlineOnly = false;
      const action = {
        data:{
          deliveryOption:'pickup',
          pickupStoreInfo:{
            storeId: 1,
            storeContactInfo: {
              address: {
                address1: 'xyz'
              }
            }
          },
          onlineOnly: false
        }
      };
      const expectedOutput = {
        deliveryOption: 'pickup',
        pickupStoreInfo:{
          storeId:1,
          storeContactInfo: {
            address: {
              address1: 'xyz'
            }
          }
        },
        pickupStoreAddressInfo: {
          address1: 'xyz',
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: true,
        isDeliveryOptionPickup: true,
        onlineOnly: false
      } ;

      expect( populateBOPISInfo( action, bopisFullChainEnabled, onlineOnly ) ).toEqual( expectedOutput );
    } );
    it( 'should return the onlineOnly as state.onlineOnly when onlineOnly is undefined ', () => {
      const bopisFullChainEnabled = true;
      const onlineOnly = false;
      const action = {
        data:{
          deliveryOption:'pickup',
          pickupStoreInfo:{
            storeId: 1,
            storeContactInfo: {
              address: {
                address1: 'xyz'
              }
            }
          }
        }
      };
      const expectedOutput = {
        deliveryOption: 'pickup',
        pickupStoreInfo:{
          storeId:1,
          storeContactInfo: {
            address: {
              address1: 'xyz'
            }
          }
        },
        pickupStoreAddressInfo: {
          address1: 'xyz',
          city: null,
          state: null,
          zipCode: null
        },
        isEligibleToDisplayShipOrPickup: true,
        isDeliveryOptionPickup: true,
        onlineOnly: false
      } ;

      expect( populateBOPISInfo( action, bopisFullChainEnabled, onlineOnly ) ).toEqual( expectedOutput );
    } );

  } );
} );
