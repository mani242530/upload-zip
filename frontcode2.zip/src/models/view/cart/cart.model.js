/**
 * Cart Redux reducer Module
 *
 */



import {
  getServiceType,
  getActionDefinition,
  SESSION_TIMEOUT
} from 'ulta-fed-core/dist/js/events/services/services.events';
import has from 'lodash/has';
import find from 'lodash/find';
import isUndefined from 'lodash/isUndefined';
import isEmpty from 'lodash/isEmpty';
import concat from 'lodash/concat';
import filter from 'lodash/filter';
import forIn from 'lodash/forIn';
import forEach from 'lodash/forEach';
import get from 'lodash/get';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { CHANGE as REDUXFORM_CHANGE } from 'redux-form/lib/actionTypes';
import {
  RESET_CHECKOUT_ELIGIBILITY,
  CLEAR_COUPON_ERROR,
  SET_GIFT_MESSAGE,
  SET_GIFT_BOX_TOGGLE_STATE,
  SET_CHKOUT_BTN_STATE,
  SHOW_BAG_SUMMARY,
  SET_PRODUCT_SAMPLE,
  CART_RIGHT_PANEL_COLLAPSE,
  UPDATE_CART,
  ADD_TO_CART,
  REMOVE_FROM_CART,
  OPEN_CART,
  FOCUS_GIFT_BOX,
  BLUR_GIFT_BOX,
  SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE
} from '../../../events/mini_cart/mini_cart.events';
import {
  MOVE_ITEM_TO_SAVE_FOR_LATER
} from '../../../events/save_for_later/save_for_later.events';
import ProductCellItemMessages from '../../../views/ProductCellItem/ProductCellItem.messages';

/**
 * default state for the Cart reducer
 */


export const initialState = {
  cartDataAvailable: false,
  switchesDataAvailable: false,
  giftBoxActiveFlag: false,
  quantity: undefined,
  giftText: '',
  giftBoxToggle: false,
  cartPageData: {
    messages: null,
    removedItems: undefined,
    updatedItems: undefined
  },
  recommendedProducts: {},
  chkoutbtnClk: false,
  eligibleForCheckout: false,
  showBagSummary: false,
  removingItem: '',
  productSampleCatalogID: '-1',
  cartRightPanelCollapse: {
    userRewards:false,
    samples: false,
    gifts: false,
    coupons: false,
    giftCard: false
  },
  errorRemoving: '',
  giftTextChange: false,
  hideOOSPanel: false,
  cartSignIn:false,
  payPalClientToken: undefined,
  showPaypalButton: undefined,
  isShipEntireOrderLinkDisplayed:false,
  giftPickupAvailability:{},
  isCartUpdated:false,
  // bagUpdatedCounter property will indicate if there are any bag updates, and will be incremented each time the bag update section gets udpated
  // this will help to handle the functionality like scrolling, which has to happen whenever this an update to the 'bag updates'
  bagUpdatedCounter:0,
  isUserSignedIn:false,
  // this property will keep track of the count of items being moved to sfl from bag updates section
  addedToSflItemCount:0
};

/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */

export const reducerSwitch = function( state, action, serverMessage, serverUpdatedItemMessage ){

  const messageMethods = {
    serverMessage,
    serverUpdatedItemMessage
  };

  switch ( action.type ){

    case getServiceType( 'initiateCheckout', 'success' ):

      return {
        ...state,
        // Display cart response if the result is not eligible for checkout
        ...( !action.data.result && populateCartData( action.data, state, messageMethods ) ),
        // Allow user to checkout if result is true
        ...( action.data.result && { eligibleForCheckout: true } )
      };

    case REDUXFORM_CHANGE:

      if( action.meta.form === 'Coupon' && action.meta.field === 'couponID' && has( state.cartPageData, 'appliedCouponSummary.messages.items' ) &&
        has( state, 'cartPageData.appliedCouponSummary.couponCode' ) &&
        state.cartPageData.appliedCouponSummary.couponCode.toUpperCase() !== action.payload.toUpperCase() ){
        return {
          ...state,
          cartPageData: {
            ...state.cartPageData,
            appliedCouponSummary:{
              ...state.cartPageData.appliedCouponSummary,
              messages:null
            }
          }
        }
      }
      else {
        return {
          ...state
        }
      }

    case RESET_CHECKOUT_ELIGIBILITY:


      return Object.assign(
        {},
        state,
        {
          eligibleForCheckout: false
        }
      )

    case getServiceType( 'initiateCheckout', 'failure' ):

      return state

    // Data from service to populate the shopping cart count
    case getServiceType( 'qsAddItem', 'success' ):
    case getServiceType( 'pdpAddItem', 'success' ):

      return {
        ...state,
        quantity: parseInt( action.data.responseData.cartSummary.itemCount, 10 ) // Updated based on v2 user lite services
      }

    case getServiceType( 'user', 'success' ):
      const isUserSignedIn = has( action.data, 'user.accountInfo.firstName' )
      return {
        ...state,
        isUserSignedIn,
        quantity: parseInt( action.data.cart.itemCount, 10 ), // Updated based on v2 user lite services
        // If user was previously signed in and if is anonymous now, then we should clear out the bag updates data
        // this can happen when the user explicitly logs out, or if the logged in user receives a session time out
        ...( !isUserSignedIn && state.isUserSignedIn && {
          cartPageData:{
            ...state.cartPageData,
            messages: null,
            removedItems: undefined,
            updatedItems: undefined
          }
        }
        )
      }

    case getServiceType( 'switches', 'success' ):
      return {
        ...state,
        switchesDataAvailable: true
      }

    case SESSION_TIMEOUT:
    case getServiceType( 'logout', 'success' ):
      return {
        ...state,
        cartDataAvailable: false
      }

    case getServiceType( 'loadCart', 'loading' ):
      return {
        ...state,
        // chkoutbtnClk flag ensures that gift variant should be selected before proceeding to checkoutpage
        // focus on warning message if variant of the included gift is not selected on click of checkout buttton ( chkoutbtnClk:true )
        // chkoutbtnClk should be reset to false on cart loading to ensure cartpage renders properly as part of cartmerge functionality
        chkoutbtnClk:false
      }
    case getServiceType( 'loadCart', 'success' ):
      return {
        ...state,
        ...populateCartData( action.data, state, messageMethods, 'loadCart' )
      };

    // Data from service to populate the cart data
    case getServiceType( 'addProductSamples', 'success' ):
    case getServiceType( 'addGiftWrap', 'success' ):
    case getServiceType( 'removeProductSamples', 'success' ):
    case getServiceType( 'removeGiftFromCart', 'success' ):
    case getServiceType( 'addItemToCart', 'success' ):
    case getServiceType( 'selectGiftVariant', 'success' ):
    case getServiceType( 'applyPayPalPayment', 'success' ):

      return {
        ...state,
        ...populateCartData( action.data, state, messageMethods )
      };

    case getServiceType( 'pickupStoreInfoUpdate', 'success' ):
      const { storeAvailable, cartResponse } = action.data;
      return {
        ...state,
        ...(
          storeAvailable &&
          populateCartData( cartResponse, state, messageMethods )
        )
      };

    case getServiceType( 'cartPickupInfoUpdate', 'success' ):
      return {
        ...state,
        ...mergeAndPopulateCartData( action.data, state, messageMethods ),
        ...( action.data.deliveryOption === 'pickup' && { cartRightPanelCollapse: { ...initialState.cartRightPanelCollapse } } )
      }
    case getServiceType( 'deliveryOptionsUpdate', 'success' ):

      return {
        ...state,
        ...populateCartData( action.data, state, messageMethods, 'deliveryOptionsUpdate' ),
        cartRightPanelCollapse: { ...initialState.cartRightPanelCollapse }

      }

    case getServiceType( 'moveToSaveForLater', 'loading' ):
      return {
        ...state,
        ...updateCartItemDisplayInfo( state, action.data.skuId, { showSpinner:true, showTransition:false } )
      }

    case MOVE_ITEM_TO_SAVE_FOR_LATER:
      return {
        ...state,
        ...updateCartItemDisplayInfo( state, action.data.skuId, { showSpinner:false, showTransition:true, transitionMessage: formatMessage( ProductCellItemMessages.movedToSaveForLaterLabel ) } )
      }

    case getServiceType( 'addToSaveForLater', 'success' ):
      // updating te removedItems by removing the item that has been added to SFL section
      let removedItems = state.cartPageData.removedItems?.filter( removedItem => removedItem.catalogRefId !== action.data.skuId )
      return {
        ...state,
        isCartUpdated:false,
        cartPageData:{
          ...state.cartPageData,
          // this will return the list of removed items, which will have all the existing items except the one which was moved to saveforlater
          removedItems: removedItems,
          messages: removedItems.length > 0 ? state.cartPageData.messages : null
        },
        addedToSflItemCount:state.addedToSflItemCount + 1
      }

    case getServiceType( 'moveToSaveForLater', 'success' ):
    case getServiceType( 'moveToBagFromSaveForLater', 'success' ):
      return {
        ...state,
        ...( action.data.cart && populateCartData( action.data.cart, state, messageMethods ) )
      };

    case getServiceType( 'deliveryOptionsUpdate', 'loading' ):
      return {
        ...state,
        // chkoutbtnClk flag ensures that gift variant should be selected before proceeding to checkoutpage
        // focus on warning message if variant of the included gift is not selected on click of checkout buttton ( chkoutbtnClk:true )
        // chkoutbtnClk should be reset to false on deliveryOptionsUpdate loading to ensure cartpage renders properly as part of items restore functionality
        chkoutbtnClk:false
      }

    case getServiceType( 'addGiftNote', 'success' ):
      return {
        ...state,
        ...populateCartData( action.data, state, messageMethods ),
        giftTextChange: false
      }

    case getServiceType( 'applyExpressPayPalPayment', 'success' ):
      if( !action.data.result ){
        return {
          ...state,
          ...populateCartData( action.data, state, messageMethods ),
          chkoutbtnClk: true
        }
      }
      else {
        return Object.assign( {},
          state, {
            chkoutbtnClk: true,
            eligibleForCheckout: true
          } )
      }

    case getServiceType( 'productRecs', 'success' ):

      if( action.data.data.recommendations ){
        return {
          ...state,
          recommendedProducts: action.data.data
        }
      }
      else {
        return {
          ...state
        }
      }

    case getServiceType( 'paypalToken', 'success' ):
      if( !isUndefined( action.data.result ) && action.data.result === 'Error' ){
        return {
          ...state
        }
      }
      else {
        return {
          ...state,
          payPalClientToken: action.data.payPalClientToken
        }
      }

    case getServiceType( 'paypalToken', 'loading' ):
      return {
        ...state,
        payPalClientToken: undefined
      }

    case getServiceType( 'removeItemFromCart', 'success' ):
      return {
        ...state,
        ...populateCartData( action.data.type, state, messageMethods ),
        errorRemoving: action.data.type.messages && action.data.type.messages.items[0].messageDesc,
        removingItem: action.data.type.messages ? action.data.item : ''
      }

    case getServiceType( 'removeItemFromCart', 'failure' ):
      return {
        ...state,
        errorRemoving: '',
        removingItem: '',
        ...updateCartItemDisplayInfo( state, action.data.catalogRefId, { showSpinner:false } )
      }
    case getServiceType( 'removeItemFromCart', 'loading' ):
      return {
        ...state,
        errorRemoving: '',
        removingItem: action.data,
        ...updateCartItemDisplayInfo( state, action.data.catalogRefId, { showSpinner:true, showTransition: false } )
      }

    case SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE:
      return {
        ...state,
        errorRemoving: '',
        removingItem: action.data,
        ...updateCartItemDisplayInfo( state, action.data.catalogRefId, { showSpinner:false, showTransition:true, transitionMessage: formatMessage( ProductCellItemMessages.removeItemFromBagLabel ) } )
      }

    case getServiceType( 'updateCartItems', 'success' ):
      return {
        ...state,
        ...populateCartData( action.data, state, messageMethods )
      }
    case getServiceType( 'removecoupon', 'success' ):
    case getServiceType( 'applycoupon', 'success' ):

      return {
        ...state,
        ...( has( action.data, 'cartSummary' ) && populateCartData( action.data, state, messageMethods ) )
      }

    case CLEAR_COUPON_ERROR:
      let cartPageData =  state.cartPageData;
      delete cartPageData.appliedCouponSummary
      cartPageData.appliedCouponSummary = { couponAppliedStatus: 'Initial' }
      return {
        ...state,
        cartPageData

      }

    case SET_GIFT_MESSAGE:
      return Object.assign( {},
        state, {
          giftText: action.text,
          gitBoxActiveFlag: setGiftBoxActiveFlag( state.giftBoxActiveFlag, action.text ),
          giftTextChange: true
        } )

    case SET_GIFT_BOX_TOGGLE_STATE:
      return Object.assign( {},
        state, {
          giftBoxToggle: action.status
        } )
    case SET_CHKOUT_BTN_STATE:
      return Object.assign( {},
        state, {
          chkoutbtnClk: action.status
        } )
    case SHOW_BAG_SUMMARY:
      return Object.assign( {},
        state, {
          showBagSummary: action.status
        } )
    case SET_PRODUCT_SAMPLE:
      return Object.assign( {},
        state, {
          productSampleCatalogID: action.catalogId
        } )

    case CART_RIGHT_PANEL_COLLAPSE:
      return {
        ...state,
        cartRightPanelCollapse: toggleCartPageRightPanelOptionsCollapse( action.panelID, state )
      }

    // ToDo we need this at later point of time
    case UPDATE_CART:
      return Object.assign( {},
        state, {
          arg: action.arg
        } )
    case ADD_TO_CART:
      return Object.assign( {},
        state, {
          item: action.item
        } )
    case REMOVE_FROM_CART:
      return Object.assign( {},
        state, {
          item: action.item
        } )


    case OPEN_CART:
      return Object.assign( {},
        state, {} )
    case getServiceType( 'removeBagUpdateMessage', 'success' ):
      return {
        ...state,
        cartPageData:{
          ...state.cartPageData,
          messages: null,
          removedItems: undefined
        }
      }

    case getServiceType( 'login', 'success' ):
      return {
        ...state,
        ...( get( action, 'data.res.success' ) && { cartSignIn: true } )
      }

    case FOCUS_GIFT_BOX:

      return {
        ...state,
        giftBoxActiveFlag: setGiftBoxActiveFlag( true, state.giftText )

      }

    case BLUR_GIFT_BOX:

      return {
        ...state,
        giftBoxActiveFlag: setGiftBoxActiveFlag( false, state.giftText )
      }

    default:
      return state;
  }
};

export default function reducer( state = initialState, action ){
  return reducerSwitch( state, action, serverMessage, serverUpdatedItemMessage )
}

export const toggleCartPageRightPanelOptionsCollapse = ( panelID, state ) => {
  let panelsOpened = {}
  forIn( state.cartRightPanelCollapse, ( val, key ) => {
    if( panelID === key ){
      panelsOpened[ key ] = !val;
    }
    else {
      panelsOpened[ key ] = val;

    }
  } );
  return panelsOpened;
}

export const toggleSampleProductRightPanelCollapse = ( cartPageData, state ) => {
  let cartRightPanelCollapse = null;
  if( has( cartPageData, 'freeSamplesInfo.items' ) ){
    cartPageData.freeSamplesInfo.items.filter( ( samples, index ) => {
      {
        if( samples.selected && ! isEmpty( samples.shippingRestriction ) &&
          cartPageData.showShippingRestrictionMsg ){
          cartRightPanelCollapse = {
            ...state.cartRightPanelCollapse,
            samples:true
          }
        }
      }
    } )
  }
  if( !get( cartPageData, 'appliedCouponSummary.couponAppliedStatus' ) && has( cartPageData, 'appliedCouponSummary.messages.items' ) ){
    cartRightPanelCollapse = {
      ...state.cartRightPanelCollapse,
      ...cartRightPanelCollapse,
      coupons:true
    }
  }
  if( cartRightPanelCollapse ){
    return cartRightPanelCollapse;
  }
  return state.cartRightPanelCollapse;
}

export const toggleOutOfStockPanelView = ( cartPageData ) =>{
  if( ( cartPageData.cartItems && cartPageData.cartItems.items.filter( cartItem => cartItem.displayType === 'removed' ).length > 0 ) || cartPageData.messages ){
    return false;
  }
}

export const serverMessage = ( data, state ) => {
  // if both response mesagse and message in state exist concatenate and return.
  // else return response if no message exist in state
  if( !isEmpty( data.messages ) ){
    if( state.cartPageData.messages ){
      return { items: concat( state.cartPageData.messages.items, data.messages.items ) };
    }
    else {
      return data.messages ;
    }
  }
  else {
    return state.cartPageData.messages;
  }

}

export const setGiftBoxActiveFlag = ( giftBoxActiveFlag, giftText ) => {

  return ( giftBoxActiveFlag || giftText !== '' )
}



export const serverUpdatedItemMessage = ( data, state ) => {
  // if updated items exist in the action payload, add it to the existing list of updated items in the state,
  // else return the updatedItems
  // if there is a message in the quantity, it means that the item is updated
  const currentUpdatedItems = data.cartItems && data.cartItems.items.filter( cartItem => !!cartItem.quantity.messages );

  if( !isEmpty( currentUpdatedItems ) ){

    if( state.cartPageData.updatedItems ){
      return concat( state.cartPageData.updatedItems, currentUpdatedItems );
    }
    else {
      return currentUpdatedItems;
    }
  }
  else {
    return state.cartPageData.updatedItems;
  }
};

// this method will retain any of the item level messages which were present in the previous state
// this method is used to handle cartPickupInfoUpdate success,
// so that item level messages received as part of load cart are not lost
export const mergeAndPopulateCartData = ( data, state, messageMethods ) => {
  // get newCartData object from the new response obtained
  const newCartData = populateCartData( data, state, messageMethods )
  newCartData.cartPageData.messages = messageMethods.serverMessage( data, state );

  // previouslyUpdatedItems will have the list of items which were updated as part of previous service call
  const previouslyUpdatedItems = state.cartPageData.updatedItems;

  // if previouslyUpdatedItems exists, retrieve the item level messages from each of the previously updatedItem
  // and populate it in the messages node correspond to that item in the newCartData
  if( !isEmpty( previouslyUpdatedItems ) ){
    forEach( previouslyUpdatedItems, ( previouslyUpdatedItem ) => {
      let currentItem = find( newCartData.cartPageData.cartItems.items, { commerceItemid:previouslyUpdatedItem.commerceItemid } );
      if( currentItem ){
        currentItem.quantity.messages = previouslyUpdatedItem.quantity.messages;
      }
    } );
  }

  return newCartData;
}

// any common logic applicable to the cart response should be kept inside this method
export const populateCartData = ( data, state, messageMethods, actionType ) => {
  const giftText = ( data.giftOptions && data.giftOptions.giftNote ) || '';
  const removedItems = data?.cartItems?.items.filter( cartItem => cartItem.displayType === 'removed' ) ;
  // updatedItems is used to retain any of the item level messages across loadCart and cartPickupInfoUpdate call
  // only for loadCart response updatedItems will be retained, and will be cleared for all other actions
  const updatedItems =  actionType === 'loadCart' ? messageMethods.serverUpdatedItemMessage( data, state ) : undefined;
  const selectedSample = data.freeSamplesInfo && filter( data.freeSamplesInfo.items, { selected: true } )[0];
  // if there is a message or removeditem as part of the new response, the bagUpdatedCounter is incremented
  const bagUpdatedCounter = data.messages || ( data.cartItems && find( data.cartItems.items, { displayType:'removed' } ) ) ? state.bagUpdatedCounter + 1 : state.bagUpdatedCounter;
  return {
    cartPageData: {
      ...data,
      ...( has( data, 'appliedCouponSummary' ) && data.appliedCouponSummary.couponAppliedStatus === false && { appliedCouponSummary: data.appliedCouponSummary } ),
      messages: data.messages,
      ...( { 'removedItems': !isEmpty( removedItems ) ? removedItems : undefined } ),
      updatedItems
    },
    isCartUpdated:true,
    giftPickupAvailability:populateGiftPickupAvailability( data ),
    hideOOSPanel: toggleOutOfStockPanelView( data ),
    giftText,
    giftBoxActiveFlag: setGiftBoxActiveFlag( state.giftBoxActiveFlag, giftText ),
    giftBoxToggle: data.giftOptions && data.giftOptions.giftBoxSelected,
    productSampleCatalogID: selectedSample ? selectedSample.catalogRefId : '-1',
    quantity: parseInt( data.cartSummary.itemCount, 10 ),
    cartDataAvailable: true,
    cartRightPanelCollapse : toggleSampleProductRightPanelCollapse( data, state ),
    showPaypalButton: data.deliveryOption !== 'pickup',
    // isShipEntireOrderLinkDisplayed is populated for any bag updates happening once the user is on bag and if the selected deliveryOption is pickup
    isShipEntireOrderLinkDisplayed: ( data.deliveryOption === 'pickup' && data.cartItems && populatePickupUnavailableItemDetails( data ) ),
    bagUpdatedCounter
  }
};

export const populateGiftPickupAvailability = ( data ) => {
  let giftAvailability = {};
  // selectedGiftItems will return the list of the selected gift items. If any of the gift had multiple options, and if a selection was not made, then it will not be included
  // also it check if for the selectedgifts if there is a giftAvailabilityStatus flag available which indicates the pickup availability
  const selectedGiftItems = data.giftItems && data.giftItems.items.filter( giftItem => !!find( giftItem.freeGifts.items, ( freeGift ) =>{
    return freeGift.selected === 'true' && !!freeGift.giftAvailabilityStatus
  } ) );

  if( selectedGiftItems ){
    forEach( selectedGiftItems, ( giftItem ) => {
      // for the selected gifts which has giftAvailabilityStatus available, the availability status is captured in this object
      giftAvailability[ giftItem.promoId ] = find( giftItem.freeGifts.items, { selected:'true' } ).giftAvailabilityStatus;
    } );
  }
  return giftAvailability;

};

// this method will filter items which were  either removed or updated as part of the delivery options update
// and identify items which are available online
export const populatePickupUnavailableItemDetails = ( data ) => {

  // the items removed when selecting pickup, should be considered for restoration only if the item had the moveToBag flag set to true

  let pickupUnavailableItems = [];
  data.cartItems.items.forEach( function( item ){
    if( item.displayType === 'removed' && !item.availabilityStatus?.pickup ){
      pickupUnavailableItems.push( item.catalogRefId )
    }
  } )
  let isShipEntireOrderLinkDisplayed = false;
  if( !isEmpty( pickupUnavailableItems ) ){
    isShipEntireOrderLinkDisplayed = true;
  }
  return isShipEntireOrderLinkDisplayed
};

// For the skuId passed in the parameter, this method will update the cartItemDisplayInfo flag (showSpinner,Showtransition ) of the item in the cart
export const updateCartItemDisplayInfo = ( state, skuID, cartItemDisplayInfo ) => {
  const updatedItems = state.cartPageData.cartItems.items.map( ( cartItem ) =>{
    if( cartItem.catalogRefId === skuID ){
      return { ...cartItem, ...cartItemDisplayInfo }
    }
    return cartItem;
  } )

  return {
    cartPageData:{
      ...state.cartPageData,
      cartItems:{
        ...state.cartPageData.cartItems,
        items: updatedItems
      }
    }
  }
}

export const getCartState = state => state.cart;
