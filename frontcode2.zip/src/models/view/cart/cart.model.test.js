


import {
  registerServiceName,
  getServiceType,
  getActionDefinition,
  SESSION_TIMEOUT
} from 'ulta-fed-core/dist/js/events/services/services.events';

import isFunction from 'lodash/isFunction';

import concat from 'lodash/concat';

import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { initializeIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import React from 'react';
import {
  RESET_CHECKOUT_ELIGIBILITY,
  CLEAR_COUPON_ERROR,
  SET_GIFT_MESSAGE,
  SET_GIFT_BOX_TOGGLE_STATE,
  SET_CHKOUT_BTN_STATE,
  SHOW_BAG_SUMMARY,
  SET_PRODUCT_SAMPLE,
  CART_RIGHT_PANEL_COLLAPSE,
  UPDATE_CART,
  ADD_TO_CART,
  REMOVE_FROM_CART,
  OPEN_CART,
  FOCUS_GIFT_BOX,
  BLUR_GIFT_BOX,
  SELECT_GIFT_VARIANT,
  SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE
} from '../../../events/mini_cart/mini_cart.events';
import configureStore from '../../../modules/ccr/ccr.store';
import CONFIG from '../../../modules/ccr/ccr.config';
import ProductCellItemMessages from '../../../views/ProductCellItem/ProductCellItem.messages';
import {
  MOVE_ITEM_TO_SAVE_FOR_LATER
} from '../../../events/save_for_later/save_for_later.events';
import reducer, {
  initialState,
  reducerSwitch,
  toggleOutOfStockPanelView,
  serverMessage,
  serverUpdatedItemMessage,
  toggleSampleProductRightPanelCollapse,
  populateGiftPickupAvailability,
  populateCartData,
  updateCartItemDisplayInfo,
  populatePickupUnavailableItemDetails
} from './cart.model';

const serverMessageMock = jest.fn();
const serverUpdatedItemMessageMock = jest.fn();
const state = {
  cartPageData:{
    messages:null,
    removedItems: undefined,
    updatedItems: undefined
  }
};

describe( 'Cart reducer', ( ) => {

  registerServiceName( 'user' );
  registerServiceName( 'loadCart' );
  registerServiceName( 'addProductSamples' );
  registerServiceName( 'removeProductSamples' );
  registerServiceName( 'removeItemFromCart' );
  registerServiceName( 'updateCartItems' );
  registerServiceName( 'removeGiftFromCart' );
  registerServiceName( 'addItemToCart' );
  registerServiceName( 'selectGiftVariant' );
  registerServiceName( 'addGiftNote' );
  registerServiceName( 'addGiftWrap' );
  registerServiceName( 'applycoupon' );
  registerServiceName( 'removecoupon' );
  registerServiceName( 'initiateCheckout' );
  registerServiceName( 'switches' );
  registerServiceName( 'applyExpressPayPalPayment' );
  registerServiceName( 'productrecs' );
  registerServiceName( 'applyPayPalPayment' );
  registerServiceName( 'paypalToken' );
  registerServiceName( 'login' );
  registerServiceName( 'cartPickupInfoUpdate' );
  registerServiceName( 'miniCart' );
  registerServiceName( 'deliveryOptionsUpdate' );
  registerServiceName( 'qsAddItem' );
  registerServiceName( 'pdpAddItem' );
  registerServiceName( 'pickupStoreInfoUpdate' );
  registerServiceName( 'moveToSaveForLater' );
  registerServiceName( 'moveToBagFromSaveForLater' );
  let store = configureStore( {}, CONFIG );
  initializeIntl();

  it( 'should have the proper default state', ( ) => {
    let expectedState = {
      cartDataAvailable: false,
      switchesDataAvailable: false,
      giftBoxActiveFlag: false,
      quantity: undefined,
      giftText: '',
      giftBoxToggle: false,
      cartPageData: {
        messages: null,
        removedItems: undefined,
        updatedItems: undefined
      },
      recommendedProducts: {},
      chkoutbtnClk: false,
      eligibleForCheckout: false,
      showBagSummary: false,
      removingItem: '',
      productSampleCatalogID: '-1',
      cartRightPanelCollapse: {
        userRewards:false,
        samples: false,
        gifts: false,
        coupons: false,
        giftCard: false
      },
      errorRemoving: '',
      giftTextChange: false,
      hideOOSPanel: false,
      cartSignIn:false,
      payPalClientToken: undefined,
      showPaypalButton: undefined,
      giftPickupAvailability: {},
      isCartUpdated:false,
      bagUpdatedCounter:0,
      isUserSignedIn:false,
      addedToSflItemCount:0,
      isShipEntireOrderLinkDisplayed:false
    }

    expect( initialState ).toEqual( expectedState );

  } );

  it( 'should be a function', ( ) => {
    expect( isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  describe( 'qsaddItem and pdpaddItem success calls', ( ) => {
    it( 'qsaddItem success', ( ) => {
      let res = {
        responseData:{
          cartSummary: {
            itemCount: 33
          }
        }
      };

      let actionCreator = {
        type: getServiceType( 'qsaddItem', 'success' ),
        data: res
      }

      let expectedOutput = {
        quantity: 33
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'pdpaddItem success', ( ) => {
      let res = {
        responseData:{
          cartSummary: {
            itemCount: 33
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'pdpaddItem', 'success' ),
        data: res
      }

      let expectedOutput = {
        quantity: 33
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );
  } );

  describe( 'User data successfullly loaded', ( ) => {
    it( 'should set the cart quantity', ( ) => {
      let res = {
        cart: {
          itemCount: 33
        }
      }

      let actionCreator = {
        type: getServiceType( 'user', 'success' ),
        data: res
      }

      let expectedOutput = {
        quantity: 33,
        isUserSignedIn:false
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'should remove the removed items, updated items and messages from cartpage data if user success action is triggered as part of logout action ( isUserSignedIn value in state is true and action is false )', ( ) => {
      let res = {
        cart: {
          itemCount: 33
        }
      }
      let state = {
        isUserSignedIn:true,
        cartPageData:{
          cartSummary:{},
          messages:'test',
          removedItems:'test',
          updatedItems:'test'
        }
      }

      let actionCreator = {
        type: getServiceType( 'user', 'success' ),
        data: res
      }

      let expectedOutput = {
        quantity: 33,
        isUserSignedIn:false,
        cartPageData:{
          cartSummary:{},
          messages:null,
          removedItems:undefined,
          updatedItems:undefined
        }
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'should not remove the removed items, updated items and messages from cartpage data if user success action is triggered not as part of logout ( isUserSignedIn in state and action have same value )', ( ) => {
      let res = {
        cart: {
          itemCount: 33
        }
      }
      let state = {
        isUserSignedIn:false,
        cartPageData:{
          cartSummary:{},
          messages:'test',
          removedItems:'test',
          updatedItems:'test'
        }
      }

      let actionCreator = {
        type: getServiceType( 'user', 'success' ),
        data: res
      }

      let expectedOutput = {
        quantity: 33,
        isUserSignedIn:false,
        cartPageData:{
          cartSummary:{},
          messages:'test',
          removedItems:'test',
          updatedItems:'test'
        }
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );
  } );

  describe( 'product related test cases', ( ) => {
    it( 'should set the product recommendation data', ( ) => {
      let res = {
        data:{
          recommendations :{}
        }
      }
      let actionCreator = {
        type: getServiceType( 'productrecs', 'success' ),
        data: res
      }

      let expectedOutput = {
        'recommendedProducts': {
          'recommendations': {}
        }
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'Product samples failure event', ( ) => {

      let res = {
        giftBoxActiveFlag: false,
        cartPageData: {
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: null,
            giftBoxSelected: false
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'addProductSamples', 'success' ),
        data: res.cartPageData
      }

      let expectedOutput = {
        bagUpdatedCounter: undefined,
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        cartPageData: {
          cartSummary: {},
          giftOptions: {
            giftBoxSelected: false,
            giftNote: null
          },
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        },
        cartRightPanelCollapse: undefined,
        giftBoxToggle: false,
        giftPickupAvailability: {},
        giftText: '',
        hideOOSPanel: undefined,
        quantity: NaN,
        showPaypalButton: true,
        productSampleCatalogID:'-1',
        isCartUpdated:true,
        isShipEntireOrderLinkDisplayed: false
      }
      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'product recommendation failure event', ( ) => {
      let actionCreator = {
        type: getServiceType( 'productRecs', 'failure' ),
        data:{}
      };
      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'CartPage Data successfullly loaded', ( ) => {
    it( 'should set the cart quantity', ( ) => {
      let res = {
        giftBoxActiveFlag: false,
        cartPageData: {
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: null,
            giftBoxSelected: false
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data: res.cartPageData
      }

      let expectedOutput = {
        bagUpdatedCounter: undefined,
        cartRightPanelCollapse: undefined,
        isShipEntireOrderLinkDisplayed: false,
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        cartPageData: {
          cartSummary: {},
          giftOptions: {
            giftBoxSelected: false,
            giftNote: null
          },
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        },
        giftBoxToggle: false,
        giftPickupAvailability: {},
        giftText: '',
        hideOOSPanel: undefined,
        quantity: NaN,
        showPaypalButton: true,
        productSampleCatalogID:'-1',
        isCartUpdated:true
      }
      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should call serverUpdatedItemMessageMock function after loadCart success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data:{
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: null,
            giftBoxSelected: false
          }
        }
      }
      reducerSwitch( state, actionCreator, serverMessageMock, serverUpdatedItemMessageMock );
      expect( serverUpdatedItemMessageMock ).toBeCalled();
    } );

    it( 'load cart success when couponAppliedStatus is false', ( ) => {
      let res = {
        giftBoxActiveFlag: false,
        cartPageData: {
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: null,
            giftBoxSelected: false
          },
          appliedCouponSummary: {
            couponAppliedStatus: false
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data: res.cartPageData
      }
      let expectedOutput = {
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        isCartUpdated:true,
        cartPageData: {
          cartSummary: {},
          giftOptions: {
            giftBoxSelected: false,
            giftNote: null
          },
          messages: null,
          appliedCouponSummary: {
            couponAppliedStatus: false
          },
          removedItems: undefined,
          updatedItems: undefined
        },
        cartRightPanelCollapse : undefined,
        productSampleCatalogID:'-1',
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        giftBoxToggle: false,
        giftPickupAvailability: {},
        giftText: '',
        hideOOSPanel: undefined,
        quantity: NaN,
        showPaypalButton: true
      }
      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'load cart success', ( ) => {
      let res = {
        giftBoxActiveFlag: false,
        cartPageData: {
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: 'Happy Birthday',
            giftBoxSelected: false
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data: res.cartPageData
      }

      let expectedOutput = {
        giftBoxActiveFlag: true,
        cartDataAvailable: true,
        cartPageData: {
          cartSummary: {},
          giftOptions: {
            giftBoxSelected: false,
            giftNote: 'Happy Birthday'
          },
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        },
        cartRightPanelCollapse: undefined,
        giftBoxToggle: false,
        giftPickupAvailability: {},
        giftText: 'Happy Birthday',
        hideOOSPanel: undefined,
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        quantity: NaN,
        showPaypalButton: true,
        productSampleCatalogID:'-1',
        isCartUpdated:true
      }
      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should populate upatedItems on loadCart Success if there are any items which has quantity level messages in the response', ( ) => {
      let res = {
        giftBoxActiveFlag: false,
        cartPageData: {
          cartSummary: {},
          cartItems:{
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:{
                    items:[
                      {
                        type:'info',
                        message:'quantity 5 not available, and has been updated to 3'
                      }
                    ]
                  }
                }
              },
              {
                commerceItemid:'2',
                quantity:{
                  value:3,
                  messages:{
                    items:[
                      {
                        type:'info',
                        message:'quantity 4 not available, and has been updated to 3'
                      }
                    ]
                  }
                }
              }
            ]
          },
          messages: null
        }
      }

      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data: res.cartPageData
      }

      let expectedOutput = [
        {
          commerceItemid:'1',
          quantity:{
            value:3,
            messages:{
              items:[
                {
                  type:'info',
                  message:'quantity 5 not available, and has been updated to 3'
                }
              ]
            }
          }
        },
        {
          commerceItemid:'2',
          quantity:{
            value:3,
            messages:{
              items:[
                {
                  type:'info',
                  message:'quantity 4 not available, and has been updated to 3'
                }
              ]
            }
          }
        }
      ];

      expect( reducer( res, actionCreator ).cartPageData.updatedItems ).toEqual( expectedOutput );
    } );

    it( 'should not populate upatedItems if action is not loadCart Success even if there are any items which has quantity level messages in the response', ( ) => {
      let res = {
        giftBoxActiveFlag: false,
        cartPageData: {
          cartSummary: {},
          cartItems:{
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:{
                    items:[
                      {
                        type:'info',
                        message:'quantity 5 not available, and has been updated to 3'
                      }
                    ]
                  }
                }
              },
              {
                commerceItemid:'2',
                quantity:{
                  value:3,
                  messages:{
                    items:[
                      {
                        type:'info',
                        message:'quantity 4 not available, and has been updated to 3'
                      }
                    ]
                  }
                }
              }
            ]
          },
          messages: null
        }
      }

      let actionCreator = {
        type: getServiceType( 'deliveryOptionsUpdate', 'success' ),
        data: res.cartPageData
      }

      expect( reducer( res, actionCreator ).cartPageData.updatedItems ).toEqual( undefined );
    } );
  } );

  describe( 'cart Pickup Info Update Data successfullly loaded', ( ) => {

    it( 'cart Pickup Info Update success when couponAppliedStatus is false', ( ) => {
      let res = {
        giftBoxActiveFlag: false,
        cartPageData: {
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: null,
            giftBoxSelected: false
          },
          appliedCouponSummary: {
            couponAppliedStatus: false
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: res.cartPageData
      }

      let expectedOutput = {
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        isCartUpdated:true,
        cartPageData: {
          cartSummary: {},
          giftOptions: {
            giftBoxSelected: false,
            giftNote: null
          },
          messages: null,
          appliedCouponSummary: {
            couponAppliedStatus: false
          },
          removedItems: undefined,
          updatedItems: undefined
        },
        cartRightPanelCollapse: undefined,
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        giftBoxToggle: false,
        giftPickupAvailability: {},
        giftText: '',
        hideOOSPanel: undefined,
        quantity: NaN,
        showPaypalButton: true,
        productSampleCatalogID:'-1'
      }
      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'cart Pickup Info Update success when couponAppliedStatus is false and delivery option is pickup', ( ) => {
      let res = {
        giftBoxActiveFlag: false,
        cartPageData: {
          cartSummary: {},
          messages: null,
          deliveryOption: 'pickup',
          giftOptions: {
            giftNote: null,
            giftBoxSelected: false
          },
          appliedCouponSummary: {
            couponAppliedStatus: false
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: res.cartPageData
      }

      let expectedOutput = {
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        isCartUpdated:true,
        cartPageData: {
          cartSummary: {},
          deliveryOption: 'pickup',
          giftOptions: {
            giftBoxSelected: false,
            giftNote: null
          },
          messages: null,
          appliedCouponSummary: {
            couponAppliedStatus: false
          },
          removedItems: undefined,
          updatedItems: undefined
        },
        cartRightPanelCollapse: {
          userRewards:false,
          samples: false,
          gifts: false,
          coupons: false,
          giftCard: false
        },
        giftBoxToggle: false,
        giftPickupAvailability: {},
        giftText: '',
        hideOOSPanel: undefined,
        quantity: NaN,
        showPaypalButton: false,
        productSampleCatalogID:'-1'
      }
      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'cart Pickup Info Update success when couponAppliedStatus is true', () => {
      let res = {
        giftBoxActiveFlag: false,
        cartPageData: {
          cartSummary: {},
          messages: null,
          giftOptions: {
            giftNote: null,
            giftBoxSelected: false
          },
          appliedCouponSummary: {
            couponAppliedStatus: true
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: res.cartPageData
      }

      let expectedOutput = {
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        isCartUpdated:true,
        cartPageData: {
          cartSummary: {},
          giftOptions: {
            giftBoxSelected: false,
            giftNote: null
          },
          messages: null,
          appliedCouponSummary: {
            couponAppliedStatus: true
          },
          removedItems: undefined,
          updatedItems: undefined
        },
        cartRightPanelCollapse:undefined,
        giftBoxToggle: false,
        giftPickupAvailability: {},
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        giftText: '',
        hideOOSPanel: undefined,
        quantity: NaN,
        productSampleCatalogID:'-1',
        showPaypalButton: true
      }
      expect( reducer( res, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'cartPickupInfoUpdate success should set updated quantity message in cartItems, if updatedItems in state has quantity message, commerceItemid of updatedItems in state and cartItems in response are equal', () => {
      let res = {
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            },
            {
              commerceItemid:'2',
              quantity:{
                value:6,
                messages:null
              }
            }
          ]
        },
        messages:null
      }

      let state = {
        cartPageData:{
          cartSummary:{
            itemCount:3
          },
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:null
                }
              }
            ]
          },
          updatedItems:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:{
                  items:[
                    {
                      type:'info',
                      message:'quantity 5 not available, and has been updated to 3'
                    }
                  ]
                }
              }
            }
          ]
        }
      }

      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: res
      }

      let expectedOutput = {
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        isCartUpdated:true,
        cartPageData: {
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:{
                    items:[
                      {
                        type:'info',
                        message:'quantity 5 not available, and has been updated to 3'
                      }
                    ]
                  }
                }
              },
              {
                commerceItemid:'2',
                quantity:{
                  value:6,
                  messages:null
                }
              }
            ]
          },
          removedItems: undefined,
          updatedItems:undefined,
          messages:undefined,
          cartSummary:{
            itemCount:3
          }
        },
        cartRightPanelCollapse:undefined,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        giftText: '',
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        hideOOSPanel: undefined,
        quantity: 3,
        productSampleCatalogID:'-1',
        showPaypalButton: true
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'cartPickupInfoUpdate success should set updated server message, if we have server messages returned from API and are previously in state ', () => {
      let res = {
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            },
            {
              commerceItemid:'2',
              quantity:{
                value:6,
                messages:null
              }
            }
          ]
        },
        messages:{
          items: [
            {
              type:'info',
              message:'quantity 5 not available, and has been updated to 3'
            }
          ]
        }
      }

      let state = {
        bagUpdatedCounter: 1,
        cartPageData:{
          messages: {
            items: [
              {
                type:'error',
                message:'quantity 5 not available, and has been updated to 1'
              }
            ]
          },
          cartSummary:{
            itemCount:3
          },
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:null
                }
              }
            ]
          },
          updatedItems:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:{
                  items:[
                    {
                      type:'info',
                      message:'quantity 5 not available, and has been updated to 3'
                    }
                  ]
                }
              }
            }
          ]
        }
      }

      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: res
      }

      let expectedOutput = {
        bagUpdatedCounter: 2,
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        isCartUpdated:true,
        cartPageData: {
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:{
                    items:[
                      {
                        type:'info',
                        message:'quantity 5 not available, and has been updated to 3'
                      }
                    ]
                  }
                }
              },
              {
                commerceItemid:'2',
                quantity:{
                  value:6,
                  messages:null
                }
              }
            ]
          },
          removedItems: undefined,
          updatedItems:undefined,
          messages:{
            items:[
              {
                type:'error',
                message:'quantity 5 not available, and has been updated to 1'
              },
              {
                type:'info',
                message:'quantity 5 not available, and has been updated to 3'
              }
            ]
          },
          cartSummary:{
            itemCount:3
          }
        },
        cartRightPanelCollapse:undefined,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        isShipEntireOrderLinkDisplayed: false,
        giftText: '',
        hideOOSPanel: false,
        quantity: 3,
        productSampleCatalogID:'-1',
        showPaypalButton: true
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'cartPickupInfoUpdate success should set server message from state if API returns no messages', () => {
      let res = {
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            },
            {
              commerceItemid:'2',
              quantity:{
                value:6,
                messages:null
              }
            }
          ]
        },
        messages: null
      }

      let state = {
        bagUpdatedCounter: 1,
        cartPageData:{
          messages: {
            items: [
              {
                type:'error',
                message:'quantity 5 not available, and has been updated to 1'
              }
            ]
          },
          cartSummary:{
            itemCount:3
          },
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:null
                }
              }
            ]
          },
          updatedItems:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:{
                  items:[
                    {
                      type:'info',
                      message:'quantity 5 not available, and has been updated to 3'
                    }
                  ]
                }
              }
            }
          ]
        }
      }

      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: res
      }

      let expectedOutput = {
        bagUpdatedCounter: 1,
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        isCartUpdated:true,
        cartPageData: {
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:{
                    items:[
                      {
                        type:'info',
                        message:'quantity 5 not available, and has been updated to 3'
                      }
                    ]
                  }
                }
              },
              {
                commerceItemid:'2',
                quantity:{
                  value:6,
                  messages:null
                }
              }
            ]
          },
          removedItems: undefined,
          updatedItems:undefined,
          messages:{
            items:[
              {
                type:'error',
                message:'quantity 5 not available, and has been updated to 1'
              }
            ]
          },
          cartSummary:{
            itemCount:3
          }
        },
        cartRightPanelCollapse:undefined,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        isShipEntireOrderLinkDisplayed: false,
        giftText: '',
        hideOOSPanel: undefined,
        quantity: 3,
        productSampleCatalogID:'-1',
        showPaypalButton: true
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'cartPickupInfoUpdate success should set server message from API if there is nor messages in State', () => {
      let res = {
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            },
            {
              commerceItemid:'2',
              quantity:{
                value:6,
                messages:null
              }
            }
          ]
        },
        messages: {
          items: [
            {
              type:'error',
              message:'quantity 5 not available, and has been updated to 1'
            }
          ]
        }
      }

      let state = {
        bagUpdatedCounter: 1,
        cartPageData:{
          messages: null,
          cartSummary:{
            itemCount:3
          },
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:null
                }
              }
            ]
          },
          updatedItems:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:{
                  items:[
                    {
                      type:'info',
                      message:'quantity 5 not available, and has been updated to 3'
                    }
                  ]
                }
              }
            }
          ]
        }
      }

      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: res
      }

      let expectedOutput = {
        bagUpdatedCounter: 2,
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        isCartUpdated:true,
        cartPageData: {
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:{
                    items:[
                      {
                        type:'info',
                        message:'quantity 5 not available, and has been updated to 3'
                      }
                    ]
                  }
                }
              },
              {
                commerceItemid:'2',
                quantity:{
                  value:6,
                  messages:null
                }
              }
            ]
          },
          removedItems: undefined,
          updatedItems:undefined,
          messages:{
            items:[
              {
                type:'error',
                message:'quantity 5 not available, and has been updated to 1'
              }
            ]
          },
          cartSummary:{
            itemCount:3
          }
        },
        cartRightPanelCollapse:undefined,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        isShipEntireOrderLinkDisplayed: false,
        giftText: '',
        hideOOSPanel: false,
        quantity: 3,
        productSampleCatalogID:'-1',
        showPaypalButton: true
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'cartPickupInfoUpdate success should not set quantity message when updatedItems in state is undefined', () => {
      let res = {
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            }
          ]
        },
        messages:null
      }

      let state = {
        cartPageData:{
          cartSummary:{
            itemCount:3
          },
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:null
                }
              }
            ]
          },
          updatedItems: undefined
        }
      }

      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: res
      }

      let expectedOutput = {
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        isCartUpdated:true,
        cartPageData: {
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:null
                }
              }
            ]
          },
          removedItems: undefined,
          updatedItems:undefined,
          messages:undefined,
          cartSummary:{
            itemCount:3
          }
        },
        cartRightPanelCollapse: undefined,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        giftText: '',
        hideOOSPanel: undefined,
        quantity: 3,
        productSampleCatalogID:'-1',
        showPaypalButton: true
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'cartPickupInfoUpdate success should not set quantity message when commerceItemid of updatedItems in state and cartItems in response are not equal', () => {
      let res = {
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            }
          ]
        },
        messages:null
      }

      let state = {
        cartPageData:{
          cartSummary:{
            itemCount:3
          },
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:null
                }
              }
            ]
          },
          updatedItems:[
            {
              commerceItemid:'2',
              quantity:{
                value:3,
                messages:{
                  items:[
                    {
                      type:'info',
                      message:'quantity 5 not available, and has been updated to 3'
                    }
                  ]
                }
              }
            }
          ]
        }
      }

      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: res
      }

      let expectedOutput = {
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        bagUpdatedCounter:undefined,
        isCartUpdated:true,
        cartPageData: {
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages: null
                }
              }
            ]
          },
          removedItems: undefined,
          updatedItems:undefined,
          messages:undefined,
          cartSummary:{
            itemCount:3
          }
        },
        cartRightPanelCollapse:undefined,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        isShipEntireOrderLinkDisplayed: false,
        giftText: '',
        hideOOSPanel: undefined,
        quantity: 3,
        productSampleCatalogID:'-1',
        showPaypalButton: true
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'cartPickupInfoUpdate success should not set updated quantity message if  message of updatedItems in state is null', () => {
      let res = {
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            }
          ]
        },
        messages:null
      }

      let state = {
        cartPageData:{
          cartSummary:{
            itemCount:3
          },
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:null
                }
              }
            ]
          },
          updatedItems:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            }
          ]
        }
      }

      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: res
      }

      let expectedOutput = {
        giftBoxActiveFlag: false,
        cartDataAvailable: true,
        isCartUpdated:true,
        cartPageData: {
          cartItems: {
            items:[
              {
                commerceItemid:'1',
                quantity:{
                  value:3,
                  messages:null
                }
              }
            ]
          },
          removedItems: undefined,
          updatedItems:undefined,
          messages:undefined,
          cartSummary:{
            itemCount:3
          }
        },
        cartRightPanelCollapse: undefined,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        giftText: '',
        hideOOSPanel: undefined,
        quantity: 3,
        productSampleCatalogID:'-1',
        showPaypalButton: true
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'remove item Data successfullly loaded', ( ) => {
    it( 'should set the cart quantity to empty on success', ( ) => {
      let res = {
        type: {
          cartItems: {
            'items': [
              {
                'displayType': 'default',
                'couponApplied': false,
                'brandName': 'Jack Black',
                'quantity': {
                  'messages': null,
                  'value': 10
                },
                'productId': 'xlsImpprod3730155',
                'excludedFromCoupon': false,
                'adbugMessageMap': null,
                'catalogRefId': '2211507',
                'categoryName': 'Shaving Cream & Razors',
                'commerceItemid': 'ci15804000058',
                'priceInfo': {
                  'salePrice': null,
                  'regularPrice': '$170.00',
                  'bfxPriceMap': [
                    {
                      'bfxQty': '10',
                      'bfxPrice': '$17.00'
                    }
                  ],
                  'unitPriceMessage': '10 @ $17.00',
                  'messages': null
                },
                'productDisplayName': 'Beard Lube Conditioning Shave',
                'imageURL': 'https://images.ulta.com/is/image/Ulta/2211507?$md$',
                'variantInfo': {
                  'Size': '6.0 oz'
                },
                'skuDisplayName': 'Beard Lube Conditioning Shave',
                'shippingRestriction': null,
                'maxQty': 10,
                'productURL': '/beard-lube-conditioning-shave?productId=xlsImpprod3730155&sku=2211507',
                'messages': null
              }
            ]
          },
          cartSummary: {
            itemCount: 3
          },
          messages: null
        },
        removingItem: ''
      }

      let actionCreator = {
        type: getServiceType( 'removeItemFromCart', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartItems':  {
            'items': [
              {
                'displayType': 'default',
                'couponApplied': false,
                'brandName': 'Jack Black',
                'quantity': {
                  'messages': null,
                  'value': 10
                },
                'productId': 'xlsImpprod3730155',
                'excludedFromCoupon': false,
                'adbugMessageMap': null,
                'catalogRefId': '2211507',
                'categoryName': 'Shaving Cream & Razors',
                'commerceItemid': 'ci15804000058',
                'priceInfo': {
                  'salePrice': null,
                  'regularPrice': '$170.00',
                  'bfxPriceMap': [
                    {
                      'bfxQty': '10',
                      'bfxPrice': '$17.00'
                    }
                  ],
                  'unitPriceMessage': '10 @ $17.00',
                  'messages': null
                },
                'productDisplayName': 'Beard Lube Conditioning Shave',
                'imageURL': 'https://images.ulta.com/is/image/Ulta/2211507?$md$',
                'variantInfo': {
                  'Size': '6.0 oz'
                },
                'skuDisplayName': 'Beard Lube Conditioning Shave',
                'shippingRestriction': null,
                'maxQty': 10,
                'productURL': '/beard-lube-conditioning-shave?productId=xlsImpprod3730155&sku=2211507',
                'messages': null
              }
            ]
          },
          'cartSummary': {
            'itemCount': 3
          },
          'messages':null,
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'isCartUpdated':true,
        'quantity': 3,
        'hideOOSPanel': undefined,
        'removingItem': '',
        'bagUpdatedCounter': undefined,
        'isShipEntireOrderLinkDisplayed': false,
        'cartDataAvailable':true,
        'cartRightPanelCollapse': undefined,
        'errorRemoving': null,
        'giftBoxActiveFlag': false,
        'giftBoxToggle': undefined,
        'giftPickupAvailability': {},
        'giftText': '',
        'productSampleCatalogID': '-1',
        'showPaypalButton': true
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'should call serverUpdatedItemMessageMock function after removeItemFromCart success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removeItemFromCart', 'success' ),
        data: {
          type: {
            cartItems: {
              items:[]
            },
            cartSummary: {
              itemCount: 3
            },
            messages: null
          },
          removingItem: ''
        }
      }
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock )
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );

    it( 'should set the cart quantity to empty if no item is in cart', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removeItemFromCart', 'success' ),
        data: {
          type: {
            cartItems: null,
            cartSummary: {
              itemCount: 0
            },
            messages: null
          },
          removingItem: ''
        }
      }

      let expectedOutput = {
        cartPageData:  {
          messages: null,
          removedItems: undefined,
          updatedItems: undefined,
          cartItems: null,
          cartSummary: {
            itemCount: 0
          }
        },
        isCartUpdated:true,
        errorRemoving: null,
        quantity: 0,
        hideOOSPanel: undefined,
        removingItem: '',
        cartDataAvailable:true,
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        cartRightPanelCollapse: undefined,
        giftBoxActiveFlag: false,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        giftText: '',
        productSampleCatalogID: '-1',
        showPaypalButton: true
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set the cart quantity to empty on success1', ( ) => {
      let res = {
        cartSummary: {
          itemCount: 3
        },
        messages: null
      }

      let actionCreator = {
        type: getServiceType( 'removeGiftFromCart', 'success' ),
        data: res
      }

      let expectedOutput = {
        cartPageData: {
          cartSummary: {
            itemCount: 3
          },
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        },
        isCartUpdated:true,
        hideOOSPanel: undefined,
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        quantity: 3,
        cartDataAvailable:true,
        cartRightPanelCollapse: undefined,
        giftBoxActiveFlag: false,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        giftText: '',
        productSampleCatalogID: '-1',
        showPaypalButton: true
      }


      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'should call serverUpdatedItemMessageMock function after removeGiftFromCart success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removeGiftFromCart', 'success' ),
        data: {
          cartSummary: {
            itemCount: 3
          },
          messages: null
        }
      }
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock )
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );
    it( 'RemoveGiftFromCart failure', ( ) => {

      let res1 = '';

      let actionCreator1 = {
        type: getServiceType( 'removeGiftFromCart', 'failure' )
      }

      let expectedOutput1 = {}

      expect( reducer( {}, actionCreator1 ) ).toEqual( expectedOutput1 );

    } );


    it( 'should set the showSpinner as true and showTransition as false on removeItemFromCart loading', ( ) => {
      const state = {
        cartPageData:{
          cartItems:{
            items: [
              {
                catalogRefId: 123123
              }
            ]
          }
        }
      };

      let actionCreator1 = {
        type: getServiceType( 'removeItemFromCart', 'loading' ),
        data: {
          catalogRefId :123123
        }
      }


      let expectedOutput1 = {
        cartPageData: {
          cartItems: {
            items:[
              {
                catalogRefId : 123123,
                showSpinner: true,
                showTransition: false
              }
            ]
          }
        },
        removingItem: {
          catalogRefId: 123123
        },
        errorRemoving: ''
      }

      expect( reducer( state, actionCreator1 ) ).toEqual( expectedOutput1 );

    } );

    it( 'should set showSpinner flag as false,transitionMessage and showTransition as true for the removed item on SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE action', () => {
      let actionCreator = {
        type: SHOW_REMOVED_FROM_BAG_SUCCESS_MESSAGE,
        data: {
          catalogRefId: '2210015'
        }
      }
      let state = {
        cartPageData:{
          cartItems:{
            items:[
              {
                catalogRefId:'2210015'
              }
            ]
          }
        }
      }

      let expectedOutput = {
        cartPageData:{
          cartItems:{
            items: [
              {
                catalogRefId: '2210015',
                showSpinner: false,
                showTransition: true,
                transitionMessage: formatMessage( ProductCellItemMessages.removeItemFromBagLabel )
              }
            ]
          }
        },
        removingItem: {
          catalogRefId: '2210015'
        },
        errorRemoving: ''
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set showSpinner as false on removeItemFromCart failure', ( ) => {
      const state = {
        cartPageData:{
          cartItems:{
            items: [
              {
                catalogRefId: 123123
              }
            ]
          }
        }
      };

      let actionCreator2 = {
        type: getServiceType( 'removeItemFromCart', 'failure' ),
        data: {
          catalogRefId :123123
        }
      }

      let expectedOutput2 = {
        cartPageData: {
          cartItems: {
            items:[
              {
                catalogRefId : 123123,
                showSpinner: false
              }
            ]
          }
        },
        removingItem: '',
        errorRemoving: ''
      }

      expect( reducer( state, actionCreator2 ) ).toEqual( expectedOutput2 );

    } );
  } );
  describe( 'Coupons applied and removed', ( ) => {



    it( 'should apply coupon to cart on success', ( ) => {
      let res = {
        appliedCouponSummary: {
          couponAppliedStatus: false
        },
        cartSummary: {
          itemCount: 3
        },
        messages:null
      }
      let actionCreator2 = {
        type: getServiceType( 'applycoupon', 'success' ),
        data: res,
        couponAppliedStatus: false
      }
      let expectedOutput = {
        'cartDataAvailable': true,
        'isCartUpdated':true,
        'cartPageData': {
          'appliedCouponSummary': {
            'couponAppliedStatus': false
          },
          'cartSummary': {
            'itemCount': 3
          },
          'messages': null,
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'cartRightPanelCollapse': undefined,
        'bagUpdatedCounter': undefined,
        'isShipEntireOrderLinkDisplayed': false,
        'giftBoxActiveFlag': false,
        'giftBoxToggle': undefined,
        'giftPickupAvailability':  {},
        'giftText': '',
        'hideOOSPanel': undefined,
        'productSampleCatalogID': '-1',
        'quantity': 3,
        'showPaypalButton': true
      }
      expect( reducer( state, actionCreator2 ) ).toEqual( expectedOutput );

    } );

    it( 'should apply coupon to cart on success if cartSummary is not present in action.data', ( ) => {
      let res = {
        appliedCouponSummary: {
          couponAppliedStatus: false
        },
        messages:null
      }
      let actionCreator2 = {
        type: getServiceType( 'applycoupon', 'success' ),
        data: res,
        couponAppliedStatus: false
      }
      let expectedOutput = {
        'cartPageData': {
          'messages': null,
          'removedItems': undefined,
          'updatedItems': undefined
        }
      }
      expect( reducer( state, actionCreator2 ) ).toEqual( expectedOutput );

    } );

    it( 'should remove coupon to cart on success', ( ) => {
      let res = {
        appliedCouponSummary: {
          couponAppliedStatus: false
        },
        cartSummary: {
          itemCount: 3
        },
        messages:null
      }
      let actionCreator2 = {
        type: getServiceType( 'removecoupon', 'success' ),
        data: res,
        couponAppliedStatus: false
      }
      let expectedOutput = {
        'cartDataAvailable': true,
        'cartPageData': {
          'appliedCouponSummary': {
            'couponAppliedStatus': false
          },
          'cartSummary': {
            'itemCount': 3
          },
          'messages': null,
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'cartRightPanelCollapse': undefined,
        'giftBoxActiveFlag': false,
        'giftBoxToggle': undefined,
        'giftPickupAvailability': {},
        'giftText': '',
        'bagUpdatedCounter': undefined,
        'isShipEntireOrderLinkDisplayed': false,
        'hideOOSPanel': undefined,
        'productSampleCatalogID': '-1',
        'quantity': 3,
        'showPaypalButton': true,
        'isCartUpdated':true
      }

      expect( reducer( state, actionCreator2 ) ).toEqual( expectedOutput );

    } );

    it( 'should remove coupon to cart on success if cartSummary is not present in action.data', ( ) => {
      let res = {
        appliedCouponSummary: {
          couponAppliedStatus: false
        },
        messages:null
      }
      let actionCreator2 = {
        type: getServiceType( 'removecoupon', 'success' ),
        data: res,
        couponAppliedStatus: false
      }
      let expectedOutput = {
        'cartPageData': {
          'messages': null,
          'removedItems': undefined,
          'updatedItems': undefined
        }
      }
      expect( reducer( state, actionCreator2 ) ).toEqual( expectedOutput );

    } );

    it( 'should call serverUpdatedItemMessageMock function after removecoupon success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removecoupon', 'success' ),
        data: {
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          messages: null
        }
      }
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock )
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );


    it( 'should call serverUpdatedItemMessageMock function', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applycoupon', 'success' ),
        data:{
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          messages:null
        }
      }
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock )
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );

    it( 'should call serverUpdatedItemMessageMock function on removecoupon success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removecoupon', 'success' ),
        data:{
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          messages:null
        }
      }
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock )
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );


  } );

  describe( 'OPEN_CART', ( ) => {


    let actionCreator = {
      type: OPEN_CART
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'removeBagUpdateMessage', ( ) => {


    let actionCreator = {
      type: getServiceType( 'removeBagUpdateMessage', 'success' )
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        cartPageData:{
          messages: null,
          removedItems: undefined,
          updatedItems: undefined
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'REMOVE_FROM_CART', ( ) => {

    let actionCreator = {
      type: REMOVE_FROM_CART
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'ADD TO CART', ( ) => {
    let item = {
      price: '$2221',
      title: 'awer'
    }

    let actionCreator = {
      type: ADD_TO_CART,
      item
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        item: { ...item }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'REMOVE_FROM_CART', ( ) => {

    let actionCreator = {
      type: REMOVE_FROM_CART
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'ADD_TO_CART', ( ) => {

    let actionCreator = {
      type: ADD_TO_CART
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'SELECT_GIFT_VARIANT', ( ) => {

    let actionCreator = {
      type: SELECT_GIFT_VARIANT
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'UPDATE_CART', ( ) => {

    let item = {
      somekey: 333
    }
    let actionCreator = {
      type: UPDATE_CART,
      item
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {};

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'SET_GIFT_MESSAGE', ( ) => {

    let text = 'GiftWrap Selected';
    let actionCreator = {
      type: SET_GIFT_MESSAGE,
      text
    }

    it( 'should handle the event and set the state', ( ) => {

      const gitBoxActiveFlag = true;
      let expectedOutput = {
        giftText: 'GiftWrap Selected',
        giftTextChange: true,
        gitBoxActiveFlag
      };

      expect( reducer( { gitBoxActiveFlag }, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'SET_GIFT_BOX_TOGGLE_STATE', ( ) => {

    let status = true;
    let actionCreator = {
      type: SET_GIFT_BOX_TOGGLE_STATE,
      status
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        giftBoxToggle: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'SET_CHKOUT_BTN_STATE', ( ) => {

    let status = true;
    let actionCreator = {
      type: SET_CHKOUT_BTN_STATE,
      status
    }
    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        chkoutbtnClk: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'SHOW_BAG_SUMMARY', ( ) => {

    let status = true;
    let actionCreator = {
      type: SHOW_BAG_SUMMARY,
      status
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        showBagSummary: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'Product Sample added successfully', ( ) => {

    it( 'should set the selected Product Sample', ( ) => {
      let res = {
        cartSummary: {
          itemCount: 3
        },
        cartItems: {
          'items': [
            {
              'displayType': 'default',
              'couponApplied': false,
              'brandName': 'Jack Black',
              'quantity': {
                'messages': null,
                'value': 10
              },
              'productId': 'xlsImpprod3730155',
              'excludedFromCoupon': false,
              'adbugMessageMap': null,
              'catalogRefId': '2211507',
              'categoryName': 'Shaving Cream & Razors',
              'commerceItemid': 'ci15804000058',
              'priceInfo': {
                'salePrice': null,
                'regularPrice': '$170.00',
                'bfxPriceMap': [
                  {
                    'bfxQty': '10',
                    'bfxPrice': '$17.00'
                  }
                ],
                'unitPriceMessage': '10 @ $17.00',
                'messages': null
              },
              'productDisplayName': 'Beard Lube Conditioning Shave',
              'imageURL': 'https://images.ulta.com/is/image/Ulta/2211507?$md$',
              'variantInfo': {
                'Size': '6.0 oz'
              },
              'skuDisplayName': 'Beard Lube Conditioning Shave',
              'shippingRestriction': null,
              'maxQty': 10,
              'productURL': '/beard-lube-conditioning-shave?productId=xlsImpprod3730155&sku=2211507',
              'messages': null
            }
          ]
        },
        freeSampleInfo: {
          freeSamples: [{
            'catalogRefId': '2252998',
            'sampleDesc': 'Fragrance',
            'selected': true
          }]
        },
        messages: null
      }

      let actionCreator = {
        type: getServiceType( 'addProductSamples', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartItems': {
            'items': [
              {
                'displayType': 'default',
                'couponApplied': false,
                'brandName': 'Jack Black',
                'quantity': {
                  'messages': null,
                  'value': 10
                },
                'productId': 'xlsImpprod3730155',
                'excludedFromCoupon': false,
                'adbugMessageMap': null,
                'catalogRefId': '2211507',
                'categoryName': 'Shaving Cream & Razors',
                'commerceItemid': 'ci15804000058',
                'priceInfo': {
                  'salePrice': null,
                  'regularPrice': '$170.00',
                  'bfxPriceMap': [
                    {
                      'bfxQty': '10',
                      'bfxPrice': '$17.00'
                    }
                  ],
                  'unitPriceMessage': '10 @ $17.00',
                  'messages': null
                },
                'productDisplayName': 'Beard Lube Conditioning Shave',
                'imageURL': 'https://images.ulta.com/is/image/Ulta/2211507?$md$',
                'variantInfo': {
                  'Size': '6.0 oz'
                },
                'skuDisplayName': 'Beard Lube Conditioning Shave',
                'shippingRestriction': null,
                'maxQty': 10,
                'productURL': '/beard-lube-conditioning-shave?productId=xlsImpprod3730155&sku=2211507',
                'messages': null
              }
            ]
          },
          'cartSummary': {
            'itemCount': 3
          },
          'freeSampleInfo': {
            'freeSamples': [{
              'catalogRefId': '2252998',
              'sampleDesc': 'Fragrance',
              'selected': true
            }]
          },
          'messages': null,
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'isCartUpdated':true,
        'bagUpdatedCounter': undefined,
        'isShipEntireOrderLinkDisplayed': false,
        'hideOOSPanel': undefined,
        'quantity': 3,
        'cartDataAvailable':true,
        'cartRightPanelCollapse': undefined,
        'giftBoxActiveFlag': false,
        'giftBoxToggle': undefined,
        'giftPickupAvailability': {},
        'giftText': '',
        'productSampleCatalogID': '-1',
        'showPaypalButton': true
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'should call serverUpdatedItemMessageMock function after addProductSamples success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addProductSamples', 'success' ),
        data: {
          cartSummary: {
            itemCount: 3
          },
          cartItems: {
            items:[]
          },
          freeSampleInfo: {
            freeSamples: [{
              'catalogRefId': '2252998',
              'sampleDesc': 'Fragrance',
              'selected': true
            }]
          },
          messages: null
        }
      }
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock )
      expect( serverUpdatedItemMessageMock ).toBeCalled();
    } );
  } );

  describe( 'SET_PRODUCT_SAMPLE', ( ) => {

    let catalogId = '1234';
    let actionCreator = {
      type: SET_PRODUCT_SAMPLE,
      catalogId
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        productSampleCatalogID: '1234'
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'CART_RIGHT_PANEL_COLLAPSE', ( ) => {
    let state1 = {
      cartRightPanelCollapse: {
        samples: false,
        gifts: false,
        coupons: false
      }
    }
    let panelID = 'gifts';
    let actionCreator = {
      type: CART_RIGHT_PANEL_COLLAPSE,
      panelID
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        cartRightPanelCollapse: {
          samples: false,
          gifts: true,
          coupons: false
        }
      };

      expect( reducer( state1, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'initiateCheckout action dipatched sucessfully ', ( ) => {
    it( 'should set the cart quantity to 3', ( ) => {
      let state = {
        cartPageData:{
          messages:null,
          removedItems: undefined,
          updatedItems: undefined
        },
        bagUpdatedCounter: 0
      };
      let res = {
        cartSummary: {
          itemCount: 3
        },
        messages: {
          items:[{ 'message':'cart' }]
        }
      };

      let actionCreator = {
        type: getServiceType( 'initiateCheckout', 'success' ),
        data: res
      };

      let expectedOutput = {
        cartDataAvailable: true,
        cartPageData: {
          cartSummary: { itemCount: 3 },
          messages: { items: [{ message: 'cart' }] },
          removedItems: undefined,
          updatedItems: undefined

        },
        cartRightPanelCollapse: undefined,
        isShipEntireOrderLinkDisplayed: false,
        giftBoxActiveFlag: false,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        giftText: '',
        hideOOSPanel: false,
        productSampleCatalogID: '-1',
        quantity: 3,
        showPaypalButton: true,
        isCartUpdated:true,
        bagUpdatedCounter: 1
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'If the result is empty then eligibilty should be true', ( ) => {
      let actionCreator = {
        type: getServiceType( 'initiateCheckout', 'success' ),
        data:{
          result:{}
        }
      };
      let expectedOutput = { eligibleForCheckout:true };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should call serverUpdatedItemMessageMock function', ( ) => {
      let actionCreator = {
        type: getServiceType( 'initiateCheckout', 'success' ),
        data:{
          cartSummary:{
            itemCount:10
          }
        }
      };
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock )
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );
    it( 'Intiate Checkout failure event ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'initiateCheckout', 'failure' )
      }

      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Reset Checkout eligibility ', ( ) => {
      let actionCreator = {
        type: RESET_CHECKOUT_ELIGIBILITY
      }
      let expectedOutput = { eligibleForCheckout: false };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Payment related testcases', ( ) => {
    it( 'should set the cart quantity to 3', ( ) => {
      let res = {
        cartSummary: {
          itemCount: 3
        },
        messages: null
      }

      let actionCreator = {
        type: getServiceType( 'applyExpressPayPalPayment', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartSummary': {
            'itemCount': 3
          },
          'messages': null,
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'isCartUpdated':true,
        'bagUpdatedCounter': undefined,
        'isShipEntireOrderLinkDisplayed': false,
        'hideOOSPanel' : undefined,
        'quantity': 3,
        'chkoutbtnClk': true,
        'cartDataAvailable':true,
        'cartRightPanelCollapse': undefined,
        'giftBoxActiveFlag': false,
        'giftBoxToggle': undefined,
        'giftPickupAvailability': {},
        'giftText': '',
        'productSampleCatalogID': '-1',
        'showPaypalButton': true
      }
      const currentState = {
        cartPageData:{
          messages:null
        }
      }
      expect( reducer( currentState, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'should call serverUpdatedItemMessageMock function after applyExpressPayPalPayment success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applyExpressPayPalPayment', 'success' ),
        data: {
          cartSummary: {
            itemCount: 3
          },
          messages: null
        }
      }
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock )
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );
    it( 'Apply Express Payment success which has result object', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applyExpressPayPalPayment', 'success' ),
        data:{
          result:{}
        }
      }
      let expectedOutput = { chkoutbtnClk: true, eligibleForCheckout: true };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'apply payment success case', ( ) => {
      let actionCreator = {
        type: getServiceType( 'applyPayPalPayment', 'success' ),
        data:{
          cartSummary: {
            itemCount: 3
          }
        }
      };
      let expectedOutput = {
        cartPageData: {
          cartSummary: {
            itemCount: 3
          },
          messages:undefined,
          removedItems:undefined,
          updatedItems:undefined
        },
        isCartUpdated:true,
        cartDataAvailable:true,
        cartRightPanelCollapse: undefined,
        giftBoxActiveFlag: false,
        giftBoxToggle: undefined,
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        giftPickupAvailability: {},
        giftText: '',
        productSampleCatalogID: '-1',
        showPaypalButton: true,
        hideOOSPanel: undefined,
        quantity:3
      };
      expect( reducer( { cartPageData:{} }, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Pickup store info update test cases', () => {
    it( 'should populate cart from the result if store is available for pickup', () => {
      let actionCreator = {
        type: getServiceType( 'pickupStoreInfoUpdate', 'success' ),
        data:{
          storeAvailable: true,
          cartResponse: {
            cartSummary: {
              itemCount: 3
            }
          }
        }
      };
      let expectedOutput = {
        cartPageData: {
          cartSummary: {
            itemCount: 3
          },
          messages:undefined,
          removedItems:undefined,
          updatedItems:undefined
        },
        isCartUpdated:true,
        cartDataAvailable:true,
        cartRightPanelCollapse: undefined,
        giftBoxActiveFlag: false,
        bagUpdatedCounter: undefined,
        isShipEntireOrderLinkDisplayed: false,
        giftBoxToggle: undefined,
        giftPickupAvailability: {},
        giftText: '',
        productSampleCatalogID: '-1',
        showPaypalButton: true,
        hideOOSPanel: undefined,
        quantity:3
      };
      expect( reducer( { cartPageData:{} }, actionCreator ) ).toEqual( expectedOutput );
    } )

    it( 'should do nothing if store is not available for pickup', () => {
      let actionCreator = {
        type: getServiceType( 'pickupStoreInfoUpdate', 'success' ),
        data:{
          storeAvailable: false,
          cartResponse: {
            cartSummary: {
              itemCount: 3
            }
          }
        }
      };
      let expectedOutput = {
        cartPageData: {}
      };
      expect( reducer( { cartPageData:{} }, actionCreator ) ).toEqual( expectedOutput );
    } )
  } );

  describe( 'Switches related cases', ( ) => {
    it( 'switches case is success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'switches', 'success' )
      }
      let expectedOutput = { switchesDataAvailable: true }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Add Gift Note and Gift Wrap Test cases', ( ) => {
    it( 'add Gift Note success', ( ) => {
      let state = {
        cartPageData:{
          messages:null
        }
      }
      let actionCreator = {
        type: getServiceType( 'addGiftNote', 'success' ),
        data: {
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          giftOptions: {
            giftNote: 'Happy Birthday'
          },
          messages:null
        }
      }
      let expectedOutput = {
        cartPageData: {
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          giftOptions: {
            giftNote: 'Happy Birthday'
          },
          messages:null
        },
        giftText: 'Happy Birthday',
        giftTextChange: false,
        hideOOSPanel: undefined,
        quantity: 3
      }
      // expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock );
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );
    it( 'should call serverUpdatedItemMessageMock function after giftNote success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'giftNote', 'success' ),
        data: {
          appliedCouponSummary: {
            couponOfferReqNotMet: false
          },
          cartSummary: {
            itemCount: 3
          },
          giftOptions: {
            giftNote: 'Happy Birthday'
          },
          messages:null
        }
      }
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock )
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );
    it( 'addGiftNote Failure case', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addGiftNote', 'failure' )
      }
      let expectedOutput = { }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    describe( 'giftBoxActiveFlag', () => {

      describe( 'FOCUS GIFT BOX ', () => {


        it( 'should set giftBoxActiveFlag to false when the gift message is empty', ( ) => {
          const giftText = '';
          let actionCreator = {
            type: FOCUS_GIFT_BOX
          }
          let expectedOutput = {
            giftBoxActiveFlag: true,
            giftText
          };
          expect( reducer( { giftText }, actionCreator ) ).toEqual( expectedOutput );
        } );

        it( 'should set giftBoxActiveFlag to true when the gift message is populated', ( ) => {
          const giftText = 'this is a gift message';
          let actionCreator = {
            type: FOCUS_GIFT_BOX
          }
          let expectedOutput = {
            giftBoxActiveFlag: true,
            giftText
          };
          expect( reducer( { giftText }, actionCreator ) ).toEqual( expectedOutput );
        } );


      } );

      describe( 'BLUR GIFT BOX', () => {
        it( 'should set giftBoxActiveFlag to false when the gift message is empty', ( ) => {
          const giftText = '';
          let actionCreator = {
            type: BLUR_GIFT_BOX
          }
          let expectedOutput = {
            giftBoxActiveFlag: false,
            giftText
          };
          expect( reducer( { giftText }, actionCreator ) ).toEqual( expectedOutput );
        } );

        it( 'should set the giftBoxACtiveFlag to true when the gift message is populated', ( ) => {

          const giftText = 'another gift text message';
          let actionCreator = {
            type: BLUR_GIFT_BOX
          }
          let expectedOutput = {
            giftBoxActiveFlag: true,
            giftText
          };
          expect( reducer( { giftText }, actionCreator ) ).toEqual( expectedOutput );

        } );

      } );


    } )

    it( 'should set the cart quantity', ( ) => {
      let state = {
        cartPageData:{
          messages:null
        }
      }
      let res = {
        cartSummary: {
          itemCount: 3
        },
        cartPageData: {
          giftOptions: {}
        },
        giftOptions: {
          giftNote: ''
        },
        giftText: '',
        giftBoxToggle: {},
        messages: null
      }


      let actionCreator = {
        type: getServiceType( 'addGiftWrap', 'success' ),
        data: res
      }

      let expectedOutput = {
        'cartPageData': {
          'cartPageData': {
            'giftOptions': {}
          },
          'cartSummary': {
            'itemCount': 3
          },
          'giftBoxToggle': {},
          'giftOptions': {
            'giftNote': ''
          },
          'giftText': '',
          'messages': null,
          'updatedItems':undefined,
          'removedItems':undefined
        },
        'giftBoxToggle': undefined,
        'giftPickupAvailability': {},
        'hideOOSPanel': undefined,
        'quantity': 3,
        'bagUpdatedCounter': undefined,
        'isShipEntireOrderLinkDisplayed': false,
        'cartDataAvailable':true,
        'cartRightPanelCollapse': undefined,
        'giftBoxActiveFlag': false,
        'giftText': '',
        'productSampleCatalogID': '-1',
        'showPaypalButton': true,
        'isCartUpdated':true
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( 'should call serverUpdatedItemMessageMock function after addGiftWrap success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addGiftWrap', 'success' ),
        data: {
          cartSummary: {
            itemCount: 3
          },
          cartPageData: {
            giftOptions: {}
          },
          giftOptions: {
            giftNote: {}
          },
          giftText: {},
          giftBoxToggle: {},
          messages: null
        }
      }
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock )
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );

    it( 'Add Gift Wrap failure case', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addGiftWrap', 'failure' )
      };
      let expectedOutput = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Paypal Token', ( ) => {
    it( 'Paypal Token success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'success' ),
        data: {
          result: 'Error'
        }
      }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Paypal Token success if result is empty', ( ) => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'success' ),
        data: {
          result: '',
          payPalClientToken: undefined
        }
      }
      let expectedOutput = {
        payPalClientToken: undefined
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Paypal Token loading', ( ) => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'loading' )
      }
      let expectedOutput = {
        payPalClientToken: undefined
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Remove Product Samples', ( ) => {
    it( 'should rermove coupon from cart on success', ( ) => {
      let res = {
        cartItems:{
          items:[
            {
              'skuId':'12312312',
              'quantity': {
                value: 3,
                messages:null
              }
            }
          ]
        },
        cartSummary: {
          itemCount: 3
        }
      }
      let couponOfferReqMet = false;
      let actionCreator = {
        type: getServiceType( 'removeProductSamples', 'success' ),
        data: res
      }
      let expectedOutput = {
        'cartPageData': {
          'cartItems':{
            'items':[
              {
                'skuId':'12312312',
                'quantity': {
                  value: 3,
                  messages:null
                }
              }
            ]
          },
          'cartSummary': {
            'itemCount': 3
          },
          'messages': undefined,
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'hideOOSPanel': undefined,
        'quantity': 3,
        'isShipEntireOrderLinkDisplayed': false,
        'bagUpdatedCounter': undefined,
        'giftBoxToggle': undefined,
        'cartDataAvailable':true,
        'cartRightPanelCollapse': undefined,
        'giftBoxActiveFlag': false,
        'giftPickupAvailability': {},
        'giftText': '',
        'productSampleCatalogID': '-1',
        'showPaypalButton': true,
        'isCartUpdated':true
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Remove Product Samples success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removeProductSamples', 'success' ),
        data:{
          cartSummary:{
            itemCount:3
          }
        }
      }
      let expectedOutput = {
        'cartPageData': {
          'cartSummary': {
            'itemCount': 3
          },
          'messages': undefined,
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'isCartUpdated':true,
        'hideOOSPanel': undefined,
        'quantity': 3,
        'cartDataAvailable':true,
        'cartRightPanelCollapse': undefined,
        'giftBoxActiveFlag': false,
        'isShipEntireOrderLinkDisplayed': false,
        'bagUpdatedCounter': undefined,
        'giftBoxToggle': undefined,
        'giftPickupAvailability': {},
        'giftText': '',
        'productSampleCatalogID': '-1',
        'showPaypalButton': true
      }
      expect( reducer( { cartPageData: {} }, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'Remove Product Samples failure', ( ) => {
      let actionCreator = {
        type: getServiceType( 'removeProductSamples', 'failure' )
      }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Update Cart Items', ( ) => {
    it( 'Update Cart Items success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'updateCartItems', 'success' ),
        data: {
          cartSummary: {
            itemCount: 11
          }
        }
      }
      const expectedOutput = {
        'cartPageData': {
          'cartSummary': {
            'itemCount': 11
          },
          'messages': undefined,
          'removedItems': undefined,
          'updatedItems': undefined
        },
        'isCartUpdated':true,
        'hideOOSPanel': undefined,
        'quantity': 11,
        'isShipEntireOrderLinkDisplayed': false,
        'bagUpdatedCounter': undefined,
        'cartDataAvailable':true,
        'cartRightPanelCollapse': undefined,
        'giftBoxActiveFlag': false,
        'giftPickupAvailability': {},
        'giftText': '',
        'productSampleCatalogID': '-1',
        'showPaypalButton': true,
        'giftBoxToggle': undefined
      }
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock );
      expect( serverUpdatedItemMessageMock ).toBeCalled();
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Add Item To Cart', ( ) => {
    it( 'Add Item To Cart success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'addItemToCart', 'success' ),
        data: {
          cartSummary: {
            itemCount: 11
          }
        }
      }
      let expectedOutput = {}
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock );
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );
    it( 'Add Item To Cart failure', ( ) => {
      let actionCreator = { type: getServiceType( 'addItemToCart', 'failure' ) }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Select Gift Variant', ( ) => {
    it( 'Select Gift Variant success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'selectGiftVariant', 'success' ),
        data: {
          cartSummary: {
            itemCount: 11
          }
        }
      }
      let expectedOutput = {}
      reducerSwitch( state, actionCreator, serverUpdatedItemMessageMock );
      expect( serverUpdatedItemMessageMock ).toBeCalled();

    } );
    it( 'Select Gift Variant failure', ( ) => {
      let actionCreator = { type: getServiceType( 'selectGiftVariant', 'failure' ) }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Login', ( ) => {
    it( 'login success', ( ) => {
      let actionCreator = {
        type: getServiceType( 'login', 'success' ),
        data: {
          res:{
            success: 'true'
          }
        }
      }
      let expectedOutput = {
        cartSignIn: true
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'MiniCart flyout', ( ) => {

    it( 'MiniCart success case', ( ) => {
      let actionCreator = {
        type: getServiceType( 'miniCart', 'success' )
      }
      let expectedOutput = {}
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );
} );

describe( 'tests for toggleOutOfStockPanelView', ( ) => {

  it( 'toggleOutOfStockPanelView should not return false when cart items messages are empty and updated/remove items not present', ( ) => {
    const cartPageData = {
      cartItems:{
        items:[
          {
            'skuId':'12312312'
          }
        ]
      },
      messages:null
    };
    expect( toggleOutOfStockPanelView( cartPageData ) ).not.toBe( false );
  } )

  it( 'toggleOutOfStockPanelView should false when cart data has messages', ( ) => {
    const cartPageData = {
      cartItems:{
        items:[
          {
            'skuId':'12312312'
          }
        ]
      },
      messages:{
        items:[
          {
            'type':'error',
            'message':'cart merged'
          }
        ]
      }
    };
    expect( toggleOutOfStockPanelView( cartPageData ) ).toBe( false );
  } )

  it( 'toggleOutOfStockPanelView should false when removed items not present', ( ) => {
    const cartPageData = {
      cartItems:{
        items:[
          {
            'skuId':'12312312',
            'displayType':'removed'
          }
        ]
      },
      messages:null
    };
    expect( toggleOutOfStockPanelView( cartPageData ) ).toBe( false );
  } )

} );

describe( 'tests for serverMessage', ( ) => {

  it( 'if there are no messages in the incoming data should return existing messages in state', ( ) => {
    const data = {};
    const state = {
      cartPageData:{
        messages: {
          items:[
            {
              type:'Info',
              message:'cart merged'
            }
          ]
        }
      }
    }
    expect( serverMessage( data, state ) ).toBe( state.cartPageData.messages );
  } )

  it( 'if there are messages in the incoming data and existing messages in state, it should return the concatenated messages', ( ) => {
    const data = {
      messages: {
        items:[
          {
            type:'Info',
            message:'cart updated'
          }
        ]
      }
    };
    const state = {
      cartPageData:{
        messages: {
          items:[
            {
              type:'Info',
              message:'cart merged'
            }
          ]
        }
      }
    }
    expect( serverMessage( data, state ) ).toEqual( { items: concat( state.cartPageData.messages.items, data.messages.items ) } );
  } )

  it( 'if there are messages in the incoming data and no existing messages in state, it should return the incoming messages', ( ) => {
    const data = {
      messages: {
        items:[
          {
            type:'Info',
            message:'cart updated'
          }
        ]
      }
    };
    const state = {
      cartPageData:{
        messages: null
      }
    }
    expect( serverMessage( data, state ) ).toEqual( data.messages );
  } )
} );



describe( 'tests for serverUpdatedItemMessage', ( ) => {

  it( 'if there are no updated items in the incoming data should return updated items in state', ( ) => {
    const data = {
      cartItems:{
        items:[
          {
            skuId:'12312312',
            displayType:'default',
            quantity:{
              value:3,
              messages:null
            }
          }
        ]
      }
    };
    const state = {
      cartPageData:{
        updatedItems:[
          {
            skuId:'2323232',
            displayType:'removed'
          }
        ]
      }
    }
    expect( serverUpdatedItemMessage( data, state ) ).toBe( state.cartPageData.updatedItems );
  } )

  it( 'if there are updated items in the incoming data and updated items exist in state, it should return the concatenated items', ( ) => {
    const data = {
      cartItems:{
        items:[
          {
            skuId:'12312312',
            displayType:'default',
            commerceItemid:'111',
            quantity:{
              messages: {
                items: [
                  {
                    type: 'Info',
                    message: 'Selected quantity (10) not available. Your bag has been updated.'
                  }
                ],
                value:3
              }
            }
          }
        ]
      }
    };
    const state = {
      cartPageData:{
        cartItems:{
          items:[
            {
              commerceItemid:'111',
              skuId:'2323232'
            }
          ]
        },
        updatedItems:[
          {
            skuId:'2323232',
            commerceItemid:'111',
            displayType:'default',
            quantity:{
              messages: {
                items: [
                  {
                    type: 'Info',
                    message: 'Selected quantity (6) not available. Your bag has been updated.'
                  }
                ],
                value:3
              }
            }
          }
        ]
      }
    }
    expect( serverUpdatedItemMessage( data, state ) ).toEqual( concat( state.cartPageData.updatedItems, data.cartItems.items ) );

  } )

  it( 'if there are updated items in the incoming data and no updated items in state, it should return the incoming updated items', ( ) => {
    const data = {
      cartItems:{
        items:[
          {
            skuId:'12312312',
            displayType:'default',
            quantity:{
              messages: {
                items: [
                  {
                    type: 'Info',
                    message: 'Selected quantity (10) not available. Your bag has been updated.'
                  }
                ],
                value:3
              }
            }
          }
        ]
      }
    };
    const state = {
      cartPageData:{}
    }
    expect( serverUpdatedItemMessage( data, state ) ).toEqual( concat( data.cartItems.items ) );
  } )
} );

describe( 'tests for toggleSampleProductRightPanelCollapse', ( ) => {

  it( 'if selected sample have ShippingRestriction Message but showShippingRestrictionMsg is false then should return cartRightPanelCollapse in state', ( ) => {
    const cartpageData = {
      showShippingRestrictionMsg:false,
      freeSamplesInfo: {
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Fragrance Added'
            }
          ]
        },
        items: [
          {
            catalogRefId: '2252998',
            sampleDesc: 'Fragrance',
            shippingRestriction: 'Cannot ship to your selected address. Please select a different free sample.',
            selected: true
          },
          {
            catalogRefId: '2252999',
            sampleDesc: 'Skincare',
            shippingRestriction: null,
            selected: false
          },
          {
            catalogRefId: '2253000',
            sampleDesc: 'Variety',
            shippingRestriction: null,
            selected: false
          }
        ]
      }
    };
    const state = {
      cartRightPanelCollapse: {
        userRewards:false,
        samples: false,
        gifts: false,
        coupons: false,
        giftCard: false
      }
    }
    expect( toggleSampleProductRightPanelCollapse( cartpageData, state ) ).toBe( state.cartRightPanelCollapse );
  } )
  it( 'Should set coupons as true for RightPanelCollapse if there is a applied coupn error ', ( ) => {
    const cartpageData = {
      'appliedCouponSummary': {
        'couponAppliedStatus': false,
        'messages': {
          'items': [{
            'type': 'Error',
            'message': 'Code has expired'
          }]
        },
        'couponCode': '3-5OFFCPN'
      }
    };
    const state = {
      cartRightPanelCollapse: {
        coupons:true
      }
    }
    expect( toggleSampleProductRightPanelCollapse( cartpageData, state ) ).toEqual( state.cartRightPanelCollapse );
  } )
  it( 'if selected sample doesn\'t have shippingRestriction message then should return cartRightPanelCollapse in state', ( ) => {
    const cartpageData = {
      showShippingRestrictionMsg:true,
      freeSamplesInfo: {
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Fragrance Added'
            }
          ]
        },
        items: [
          {
            catalogRefId: '2252998',
            sampleDesc: 'Fragrance',
            shippingRestriction: null,
            selected: true
          },
          {
            catalogRefId: '2252999',
            sampleDesc: 'Skincare',
            shippingRestriction: null,
            selected: false
          },
          {
            catalogRefId: '2253000',
            sampleDesc: 'Variety',
            shippingRestriction: null,
            selected: false
          }
        ]
      }
    };
    const state = {
      cartRightPanelCollapse: {
        userRewards:false,
        samples: false,
        gifts: false,
        coupons: false,
        giftCard: false
      }
    }
    expect( toggleSampleProductRightPanelCollapse( cartpageData, state ) ).toBe( state.cartRightPanelCollapse );
  } )

  it( 'if selected sample is ShippingRestricted and showShippingRestrictionMsg is true then should return cartRightPanelCollapse in state with sample node in it as true', ( ) => {
    const cartpageData = {
      showShippingRestrictionMsg:true,
      freeSamplesInfo: {
        messages: {
          items: [
            {
              type: 'Info',
              message: 'Fragrance Added'
            }
          ]
        },
        items: [
          {
            catalogRefId: '2252998',
            sampleDesc: 'Fragrance',
            shippingRestriction: 'Cannot ship to your selected address. Please select a different free sample.',
            selected: true
          },
          {
            catalogRefId: '2252999',
            sampleDesc: 'Skincare',
            shippingRestriction: null,
            selected: false
          },
          {
            catalogRefId: '2253000',
            sampleDesc: 'Variety',
            shippingRestriction: null,
            selected: false
          }
        ]
      }
    };
    const state = {
      cartRightPanelCollapse: {
        userRewards:false,
        samples: false,
        gifts: false,
        coupons: false,
        giftCard: false
      }
    }

    const expectedState = {
      cartRightPanelCollapse: {
        userRewards:false,
        samples: true,
        gifts: false,
        coupons: false,
        giftCard: false
      }
    }
    expect( JSON.stringify( toggleSampleProductRightPanelCollapse( cartpageData, state ) ) ).toBe( JSON.stringify( expectedState.cartRightPanelCollapse ) );
  } )

  it( 'if no sample been selected then should return cartRightPanelCollapse in state', ( ) => {
    const cartpageData = {
      showShippingRestrictionMsg:true,
      freeSamplesInfo: {
        messages: null,
        items: [
          {
            catalogRefId: '2252998',
            sampleDesc: 'Fragrance',
            shippingRestriction: 'Cannot ship to your selected address. Please select a different free sample.',
            selected: false
          },
          {
            catalogRefId: '2252999',
            sampleDesc: 'Skincare',
            shippingRestriction: null,
            selected: false
          },
          {
            catalogRefId: '2253000',
            sampleDesc: 'Variety',
            shippingRestriction: null,
            selected: false
          }
        ]
      }
    };
    const state = {
      cartRightPanelCollapse: {
        userRewards:false,
        samples: false,
        gifts: false,
        coupons: false,
        giftCard: false
      }
    }
    expect( toggleSampleProductRightPanelCollapse( cartpageData, state ) ).toBe( state.cartRightPanelCollapse );
  } )

} );

describe( 'tests for session time out', ( ) => {
  it( 'should set cartDataAvailable to false on SESSION_TIMEOUT', ( ) => {

    let state = {
      cartPageData: {},
      cartDataAvailable:true
    }

    let actionCreator = {
      type: SESSION_TIMEOUT
    }

    let expectedOutput = {
      cartPageData: {},
      cartDataAvailable:false
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } )
  it( 'should set cartDataAvailable to false on logout success', ( ) => {

    let state = {
      cartPageData: {},
      cartDataAvailable:true
    }

    let actionCreator = {
      type: getServiceType( 'logout', 'success' )
    }

    let expectedOutput = {
      cartPageData: {},
      cartDataAvailable:false
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } )
} );

describe( 'Delivery Options Update', () => {

  it( 'should handle delivery options update and set the state', ( ) => {
    let actionCreator = {
      type: getServiceType( 'deliveryOptionsUpdate', 'success' ),
      data: {
        'cartItems':  {
          'items': [
            {
              'displayType': 'default',
              'couponApplied': false,
              'brandName': 'Jack Black',
              'quantity': {
                'messages': null,
                'value': 10
              },
              'productId': 'xlsImpprod3730155',
              'excludedFromCoupon': false,
              'adbugMessageMap': null,
              'catalogRefId': '2211507',
              'categoryName': 'Shaving Cream & Razors',
              'commerceItemid': 'ci15804000058',
              'priceInfo': {
                'salePrice': null,
                'regularPrice': '$170.00',
                'bfxPriceMap': [
                  {
                    'bfxQty': '10',
                    'bfxPrice': '$17.00'
                  }
                ],
                'unitPriceMessage': '10 @ $17.00',
                'messages': null
              },
              'productDisplayName': 'Beard Lube Conditioning Shave',
              'imageURL': 'https://images.ulta.com/is/image/Ulta/2211507?$md$',
              'variantInfo': {
                'Size': '6.0 oz'
              },
              'skuDisplayName': 'Beard Lube Conditioning Shave',
              'shippingRestriction': null,
              'maxQty': 10,
              'productURL': '/beard-lube-conditioning-shave?productId=xlsImpprod3730155&sku=2211507',
              'messages': null
            }
          ]
        },
        'cartSummary': {
          'itemCount': 3
        },
        'giftOptions': {
          'giftBoxSelected': false,
          'giftNote': null
        },
        'freeSamplesInfo': {
          'items': [
            {
              'catalogRefId': '2252998',
              'sampleDesc': 'Fragrance',
              'shippingRestriction': null,
              'selected': false
            },
            {
              'catalogRefId': '2252999',
              'sampleDesc': 'Skincare',
              'shippingRestriction': null,
              'selected': false
            },
            {
              'catalogRefId': '2253000',
              'sampleDesc': 'Variety',
              'shippingRestriction': null,
              'selected': true
            }
          ]
        },
        'messages':null
      }
    }
    let expectedOutput = {
      cartPageData: {
        'cartItems':  {
          'items': [
            {
              'displayType': 'default',
              'couponApplied': false,
              'brandName': 'Jack Black',
              'quantity': {
                'messages': null,
                'value': 10
              },
              'productId': 'xlsImpprod3730155',
              'excludedFromCoupon': false,
              'adbugMessageMap': null,
              'catalogRefId': '2211507',
              'categoryName': 'Shaving Cream & Razors',
              'commerceItemid': 'ci15804000058',
              'priceInfo': {
                'salePrice': null,
                'regularPrice': '$170.00',
                'bfxPriceMap': [
                  {
                    'bfxQty': '10',
                    'bfxPrice': '$17.00'
                  }
                ],
                'unitPriceMessage': '10 @ $17.00',
                'messages': null
              },
              'productDisplayName': 'Beard Lube Conditioning Shave',
              'imageURL': 'https://images.ulta.com/is/image/Ulta/2211507?$md$',
              'variantInfo': {
                'Size': '6.0 oz'
              },
              'skuDisplayName': 'Beard Lube Conditioning Shave',
              'shippingRestriction': null,
              'maxQty': 10,
              'productURL': '/beard-lube-conditioning-shave?productId=xlsImpprod3730155&sku=2211507',
              'messages': null
            }
          ]
        },
        'cartSummary': {
          'itemCount': 3
        },
        'giftOptions': {
          'giftBoxSelected': false,
          'giftNote': null
        },
        'freeSamplesInfo': {
          'items': [
            {
              'catalogRefId': '2252998',
              'sampleDesc': 'Fragrance',
              'shippingRestriction': null,
              'selected': false
            },
            {
              'catalogRefId': '2252999',
              'sampleDesc': 'Skincare',
              'shippingRestriction': null,
              'selected': false
            },
            {
              'catalogRefId': '2253000',
              'sampleDesc': 'Variety',
              'shippingRestriction': null,
              'selected': true
            }
          ]
        },
        'messages':null,
        'removedItems': undefined,
        'updatedItems': undefined
      },
      'quantity':3,
      'isCartUpdated':true,
      'isShipEntireOrderLinkDisplayed': false,
      'bagUpdatedCounter': undefined,
      'cartDataAvailable':true,
      'giftBoxActiveFlag': false,
      'giftText': '',
      'giftBoxToggle': false,
      'giftPickupAvailability': {},
      'productSampleCatalogID': '2253000',
      'cartRightPanelCollapse': {
        'userRewards':false,
        'samples': false,
        'gifts': false,
        'coupons': false,
        'giftCard': false
      },
      'showPaypalButton': true,
      'hideOOSPanel':undefined
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should handle delivery options update and set the state when deliveryOption is pickup and removed items with availabilityStatus.online is true ', ( ) => {
    let actionCreator = {
      type: getServiceType( 'deliveryOptionsUpdate', 'success' ),
      data: {
        'cartItems':  {
          'items': [
            {
              'catalogRefId':'1232131',
              'displayType': 'default',
              'productId': 'xlsImpprod3730155',
              'availabilityStatus': {
                'online': true,
                'pickup': true
              },
              quantity: {
                messages: null,
                value: 1
              }
            },
            {
              'catalogRefId':'1232132',
              'quantity':2,
              'productId': 'xlsImpprod3730156',
              'displayType': 'removed',
              'availabilityStatus': {
                'online': true,
                'pickup': false
              },
              'moveToBag': true
            }
          ]
        },
        'cartSummary': {
          'itemCount': 2
        },
        'giftOptions': {
          'giftBoxSelected': false,
          'giftNote': null
        },
        'freeSamplesInfo': {
          'items': [
            {
              'catalogRefId': '2252998',
              'sampleDesc': 'Fragrance',
              'shippingRestriction': null,
              'selected': false
            },
            {
              'catalogRefId': '2252999',
              'sampleDesc': 'Skincare',
              'shippingRestriction': null,
              'selected': false
            },
            {
              'catalogRefId': '2253000',
              'sampleDesc': 'Variety',
              'shippingRestriction': null,
              'selected': true
            }
          ]
        },
        'messages':null,
        'deliveryOption': 'pickup'
      }
    }
    let expectedOutput = {
      cartPageData: {
        'cartItems':  {
          'items': [
            {
              'catalogRefId':'1232131',
              'displayType': 'default',
              'productId': 'xlsImpprod3730155',
              'availabilityStatus': {
                'online': true,
                'pickup': true
              },
              quantity: {
                messages: null,
                value: 1
              }
            },
            {
              'catalogRefId':'1232132',
              'quantity':2,
              'productId': 'xlsImpprod3730156',
              'displayType': 'removed',
              'availabilityStatus': {
                'online': true,
                'pickup': false
              },
              'moveToBag': true
            }
          ]
        },
        'cartSummary': {
          'itemCount': 2
        },
        'giftOptions': {
          'giftBoxSelected': false,
          'giftNote': null
        },
        'freeSamplesInfo': {
          'items': [
            {
              'catalogRefId': '2252998',
              'sampleDesc': 'Fragrance',
              'shippingRestriction': null,
              'selected': false
            },
            {
              'catalogRefId': '2252999',
              'sampleDesc': 'Skincare',
              'shippingRestriction': null,
              'selected': false
            },
            {
              'catalogRefId': '2253000',
              'sampleDesc': 'Variety',
              'shippingRestriction': null,
              'selected': true
            }
          ]
        },
        'deliveryOption': 'pickup',
        'messages':null,
        'removedItems': [
          {
            'catalogRefId':'1232132',
            'productId': 'xlsImpprod3730156',
            'quantity':2,
            'displayType': 'removed',
            'availabilityStatus': {
              'online': true,
              'pickup': false
            },
            'moveToBag': true
          }
        ],
        'updatedItems': undefined
      },
      'quantity':2,
      'cartDataAvailable':true,
      'isCartUpdated':true,
      'isShipEntireOrderLinkDisplayed':true,
      'giftBoxActiveFlag': false,
      'giftText': '',
      'giftBoxToggle': false,
      'giftPickupAvailability': {},
      'productSampleCatalogID': '2253000',
      'showPaypalButton': false,
      'hideOOSPanel':false,
      'cartRightPanelCollapse': {
        'userRewards':false,
        'samples': false,
        'gifts': false,
        'coupons': false,
        'giftCard': false
      },
      bagUpdatedCounter: 1
    };

    const existingState = {
      cartPageData:{
        messages:null,
        cartItems:{
          items:[
            {
              'catalogRefId':'1232131',
              'displayType': 'default',
              'productId': 'xlsImpprod3730155',
              'availabilityStatus': {
                'online': true,
                'pickup': true
              },
              'moveToBag':true,
              quantity: {
                messages: null,
                value: 1
              }
            }
          ]
        }
      },
      bagUpdatedCounter: 0
    }

    expect( reducer( existingState, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set isItemsRestoreSuccess as false if deliveryType is pickup while deliveryOptionsUpdate is loading', ( ) => {
    const actionCreator = {
      type: getServiceType( 'deliveryOptionsUpdate', 'loading' ),
      data: {
        'deliveryType': 'pickup'
      }
    }
    const expectedOutput = {
      cartPageData: {
        'messages':null,
        'removedItems': undefined,
        'updatedItems': undefined
      },
      chkoutbtnClk: false
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should return giftPickupAvailability object conatins promoId when gift item is selected', ( ) => {
    const data = {
      giftItems:{
        items : [
          {
            'freeGifts': {
              'items': [
                {
                  'giftCatalogRefId': '112023775',
                  'giftDisplayName': 'Eternity for Men Eau de Toilette',
                  'selected': 'true',
                  'giftAvailabilityStatus': 'true'
                },
                {
                  'giftCatalogRefId': '122023776',
                  'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                  'selected': 'false'
                },
                {
                  'giftCatalogRefId': '132023776',
                  'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                  'selected': 'default'
                }
              ]
            },
            'promoId': 1143243243
          },
          {
            'freeGifts': {
              'items': [
                {
                  'giftCatalogRefId': '122023776',
                  'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                  'selected': 'true',
                  'giftAvailabilityStatus': 'false'
                },
                {
                  'giftCatalogRefId': '132023776',
                  'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                  'selected': 'default'
                }
              ]
            },
            'promoId': 1220237766
          }
        ]
      }
    };
    const giftPickupAvailability = {
      '1143243243': 'true',
      '1220237766': 'false'
    };
    expect( populateGiftPickupAvailability( data ) ).toEqual( giftPickupAvailability );
  } );

  it( 'should return empty giftPickupAvailability object when gift item is not selected', ( ) => {
    const data = {
      giftItems:{
        items : [
          {
            'freeGifts': {
              'items': [
                {
                  'giftCatalogRefId': '112023775',
                  'giftDisplayName': 'Eternity for Men Eau de Toilette',
                  'selected': 'false'
                },
                {
                  'giftCatalogRefId': '122023776',
                  'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                  'selected': 'false'
                },
                {
                  'giftCatalogRefId': '132023776',
                  'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                  'selected': 'default'
                }
              ]
            },
            'promoId': 1143243243
          },
          {
            'freeGifts': {
              'items': [
                {
                  'giftCatalogRefId': '122023776',
                  'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                  'selected': 'false'
                },
                {
                  'giftCatalogRefId': '132023776',
                  'giftDisplayName': 'Hair Building Fibers-Medium Blonde',
                  'selected': 'default'
                }
              ]
            },
            'promoId': 1220237766
          }
        ]
      }
    };
    const giftPickupAvailability = {};
    expect( populateGiftPickupAvailability( data ) ).toEqual( giftPickupAvailability );
  } );

  it( 'populateCartData should not return pickupUnavailableItems if cartItems is null', ( ) => {
    const messageMethods = {
      serverUpdatedItemMessage
    };
    let state = {
      cartPageData:{
        cartItems: {
          items:[
            {
              catalogRefId:'123'
            }
          ]
        }
      }
    }
    const data = {
      cartSummary:{
        itemCount: 0
      },
      cartItems: null,
      deliveryOption: 'pickup'
    }

    let expectedOutput = {
      cartPageData:  {
        messages: undefined,
        removedItems: undefined,
        updatedItems: undefined,
        cartItems: null,
        cartSummary: {
          itemCount: 0
        },
        deliveryOption: 'pickup'
      },
      isCartUpdated:true,
      isShipEntireOrderLinkDisplayed: null,
      bagUpdatedCounter: undefined,
      giftPickupAvailability:{},
      hideOOSPanel: undefined,
      giftText: '',
      giftBoxActiveFlag: false,
      giftBoxToggle: undefined,
      productSampleCatalogID: '-1',
      quantity: 0,
      cartDataAvailable:true,
      cartRightPanelCollapse: undefined,
      showPaypalButton: false
    }

    expect( populateCartData( data, state, messageMethods ) ).toEqual( expectedOutput );
  } );

  it( 'should return populateCartData with empty pickupUnavailableItems if deliveryOption is not pickup and action type is not deliveryOptionsUpdate', ( ) => {
    const messageMethods = {
      serverUpdatedItemMessage
    };
    let state = {
      cartPageData:{
        cartItems: {
          items:[
            {
              catalogRefId:'123'
            }
          ]
        }
      }
    }
    const data = {
      cartSummary:{
        itemCount: 0
      },
      cartItems: null,
      deliveryOption: 'test'
    }

    let expectedOutput = {
      cartPageData:  {
        messages: undefined,
        removedItems: undefined,
        updatedItems: undefined,
        cartItems: null,
        cartSummary: {
          itemCount: 0
        },
        deliveryOption: 'test'
      },
      isCartUpdated:true,
      isShipEntireOrderLinkDisplayed: false,
      bagUpdatedCounter: undefined,
      giftPickupAvailability:{},
      hideOOSPanel: undefined,
      giftText: '',
      giftBoxActiveFlag: false,
      giftBoxToggle: undefined,
      productSampleCatalogID: '-1',
      quantity: 0,
      cartDataAvailable:true,
      cartRightPanelCollapse: undefined,
      showPaypalButton: true
    }

    expect( populateCartData( data, state, messageMethods ) ).toEqual( expectedOutput );
  } );

  it( 'should not populate updated item on deliveryOptionsUpdate success', ( ) => {
    let actionCreator = {
      type: getServiceType( 'deliveryOptionsUpdate', 'success' ),
      data: {
        'cartItems':  {
          'items': [
            {
              'displayType': 'default',
              'quantity': {
                'messages': 'test message',
                'value': 10
              },
              'productId': 'xlsImpprod3730155'
            }
          ]
        },
        'cartSummary': {
          'itemCount': 3
        },
        'messages':null
      }
    }
    let expectedOutput = {
      bagUpdatedCounter: undefined,
      cartPageData: {
        'cartItems':  {
          'items': [
            {
              'displayType': 'default',
              'quantity': {
                'messages': 'test message',
                'value': 10
              },
              'productId': 'xlsImpprod3730155'
            }
          ]
        },
        'cartSummary': {
          'itemCount': 3
        },
        'messages':null,
        'removedItems': undefined
      },
      'quantity':3,
      'isCartUpdated':true,
      'cartDataAvailable':true,
      'giftBoxActiveFlag': false,
      'isShipEntireOrderLinkDisplayed': false,
      'updatedItems': undefined,
      'giftText': '',
      'giftBoxToggle': undefined,
      'giftPickupAvailability': {},
      'productSampleCatalogID': '-1',
      'cartRightPanelCollapse': {
        'userRewards':false,
        'samples': false,
        'gifts': false,
        'coupons': false,
        'giftCard': false
      },
      'showPaypalButton': true,
      'hideOOSPanel':undefined
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  describe( 'bagUpdatedCounter cases for populateCartData', () => {

    it( 'should return bagUpdatedCounter value as in state if cartItems is doesn\'t have any item with displayType as removed or messages is null', ( ) => {
      const messageMethods = {
        serverUpdatedItemMessage
      };
      let state = {
        cartPageData:{
          cartItems: {
            items:[
              {
                catalogRefId:'123'
              }
            ]
          }
        },
        bagUpdatedCounter: 0
      }
      const data = {
        cartSummary:{
          itemCount: 0
        },
        cartItems: null,
        deliveryOption: 'pickup'
      }
      const expectedOutput = populateCartData( data, state, messageMethods );
      expect( expectedOutput.bagUpdatedCounter ).toEqual( state.bagUpdatedCounter );
    } );

    it( 'should return incremented bagUpdatedCounter value of the same in state,  messages is not null', ( ) => {
      const messageMethods = {
        serverUpdatedItemMessage
      };
      let state = {
        cartPageData:{},
        bagUpdatedCounter: 0
      }

      const data = {
        cartSummary:{
          itemCount: 1
        },
        cartItems:{
          items:[
            {
              catalogRefId:'123',
              displayType: 'default',
              quantity: {
                messages: null,
                value: 1
              }
            }
          ]
        },
        messages: {
          items:[
            {
              type:'info',
              message:'quantity 5 not available, and has been updated to 3'
            }
          ]
        }
      }
      const expectedOutput = populateCartData( data, state, messageMethods );
      expect( expectedOutput.bagUpdatedCounter ).toEqual( state.bagUpdatedCounter + 1 );
    } );

    it( 'should return incremented bagUpdatedCounter value of the same in state, if cartItems have any item with displayType as removed', ( ) => {
      const messageMethods = {
        serverUpdatedItemMessage
      };
      let state = {
        cartPageData:{},
        bagUpdatedCounter: 0
      }
      const data = {
        cartSummary:{
          itemCount: 1
        },
        cartItems:{
          items:[
            {
              catalogRefId:'123',
              displayType: 'removed',
              quantity: {
                value:1,
                messages:null
              }
            },
            {
              catalogRefId:'456',
              displayType: 'default',
              quantity: {
                value:1,
                messages:null
              }
            }
          ]
        }
      }
      const expectedOutput = populateCartData( data, state, messageMethods );
      expect( expectedOutput.bagUpdatedCounter ).toEqual( state.bagUpdatedCounter + 1 );
    } );
  } );
} );

describe( 'Move To Save For Later', () => {
  const state = {
    cartPageData:{
      cartItems:{
        items: [
          {
            catalogRefId: '2210015'
          }
        ]
      }
    },
    bagUpdatedCounter: 0
  };
  it( 'should handle moveToSaveForLater loading and set the state', ( ) => {
    let actionCreator = {
      type: getServiceType( 'moveToSaveForLater', 'loading' ),
      data: {
        skuId: '2210015'
      }
    }
    let expectedOutput = {
      cartPageData:{
        cartItems:{
          items: [
            {
              catalogRefId: '2210015',
              showSpinner: true,
              showTransition: false
            }
          ]
        }
      },
      bagUpdatedCounter: 0
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should handle MOVE_ITEM_TO_SAVE_FOR_LATER action and set the state', ( ) => {
    let actionCreator = {
      type: MOVE_ITEM_TO_SAVE_FOR_LATER,
      data: {
        skuId: '2210015'
      }
    }
    let expectedOutput = {
      cartPageData:{
        cartItems:{
          items: [
            {
              catalogRefId: '2210015',
              showSpinner: false,
              showTransition: true,
              transitionMessage: formatMessage( ProductCellItemMessages.movedToSaveForLaterLabel )
            }
          ]
        }
      },
      bagUpdatedCounter: 0
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should handle moveToSaveForLater success and set the cartItems in state', ( ) => {
    let actionCreator = {
      type: getServiceType( 'moveToSaveForLater', 'success' ),
      data: {
        'cart': {
          'cartSummary': {
            'itemCount': 4
          },
          'cartItems': {
            'items': [
              {
                'productId': 'xlsImpprod12601019',
                quantity: {
                  messages: null,
                  value: 4
                }
              }
            ]
          }
        }
      }
    }
    let expectedOutput = {
      cartPageData:  {
        messages: undefined,
        removedItems: undefined,
        updatedItems: undefined,
        cartItems: {
          items: [
            {
              'productId': 'xlsImpprod12601019',
              quantity: {
                messages: null,
                value: 4
              }
            }
          ]
        },
        cartSummary: {
          itemCount: 4
        }
      },
      isCartUpdated:true,
      giftPickupAvailability:{},
      isShipEntireOrderLinkDisplayed: false,
      hideOOSPanel: undefined,
      giftText: '',
      giftBoxActiveFlag: false,
      giftBoxToggle: undefined,
      productSampleCatalogID: '-1',
      quantity: 4,
      cartDataAvailable:true,
      cartRightPanelCollapse: undefined,
      showPaypalButton: true,
      bagUpdatedCounter: 0
    }

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should handle addToSaveForLater success and update pickupUnavailableItems and removedItems in the state', ( ) => {
    let actionCreator = {
      type: getServiceType( 'addToSaveForLater', 'success' ),
      data: {
        skuId:'123'
      }
    }
    let expectedOutput = {
      isCartUpdated:false,
      cartPageData:{
        messages:{
          items: [{
            type: 'error',
            message: 'Item(s) were removed'
          }]
        },
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            }
          ]
        },
        removedItems:[
          {
            catalogRefId:'234'
          }
        ]
      },
      addedToSflItemCount:1
    }
    let state = {
      cartPageData:{
        messages:{
          items: [{
            type: 'error',
            message: 'Item(s) were removed'
          }]
        },
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            }
          ]
        },
        removedItems:[
          {
            commerceItemid:'1',
            catalogRefId:'123'
          },
          {
            catalogRefId:'234'
          }
        ]
      },
      addedToSflItemCount:0
    }

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should handle addToSaveForLater success and remove the messages when removedItems list is empty', ( ) => {
    let actionCreator = {
      type: getServiceType( 'addToSaveForLater', 'success' ),
      data: {
        skuId:'124'
      }
    }
    let expectedOutput = {
      isCartUpdated:false,
      cartPageData:{
        messages: null,
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            }
          ]
        },
        removedItems:[]
      },
      addedToSflItemCount:1
    }
    let state = {
      cartPageData:{
        messages:{
          items: [{
            type: 'error',
            message: 'Item(s) were removed'
          }]
        },
        cartSummary:{
          itemCount:3
        },
        cartItems: {
          items:[
            {
              commerceItemid:'1',
              quantity:{
                value:3,
                messages:null
              }
            }
          ]
        },
        removedItems:[
          {
            commerceItemid:'1',
            catalogRefId:'124'
          }
        ]
      },
      addedToSflItemCount:0
    }

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should handle moveToBagFromSaveForLater success and set the cartItems in state', ( ) => {
    let actionCreator = {
      type: getServiceType( 'moveToBagFromSaveForLater', 'success' ),
      data: {
        'cart': {
          'cartSummary': {
            'itemCount': 4
          },
          'cartItems': {
            'items': [
              {
                'productId': 'xlsImpprod12601019',
                quantity: {
                  messages: null,
                  value: 1
                }
              }
            ]
          }
        }
      }
    }
    let expectedOutput = {
      cartPageData:  {
        messages: undefined,
        removedItems: undefined,
        updatedItems: undefined,
        cartItems: {
          items: [
            {
              'productId': 'xlsImpprod12601019',
              quantity: {
                messages: null,
                value: 1
              }
            }
          ]
        },
        cartSummary: {
          itemCount: 4
        }
      },
      isCartUpdated:true,
      giftPickupAvailability:{},
      hideOOSPanel: undefined,
      giftText: '',
      giftBoxActiveFlag: false,
      giftBoxToggle: undefined,
      productSampleCatalogID: '-1',
      isShipEntireOrderLinkDisplayed: false,
      quantity: 4,
      cartDataAvailable:true,
      cartRightPanelCollapse: undefined,
      showPaypalButton: true,
      bagUpdatedCounter: 0
    }

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'updateCartItemDisplayInfo should append cartItemDisplayInfo with cartItem if skuID and catalogRefId are same', ( ) => {
    const skuID = '2210015';
    const cartItemDisplayInfo = {
      showSpinner: false,
      showTransition: true
    }
    let expectedOutput = {
      cartPageData:  {
        cartItems: {
          items: [
            {
              catalogRefId: '2210015',
              showSpinner: false,
              showTransition: true
            }
          ]
        }
      }
    }

    expect( updateCartItemDisplayInfo( state, skuID, cartItemDisplayInfo ) ).toEqual( expectedOutput );
  } );

  it( 'updateCartItemDisplayInfo should not append cartItemDisplayInfo with cartItem if skuID and catalogRefId are different', ( ) => {
    const skuID = '2210015';
    const state = {
      cartPageData:{
        cartItems:{
          items: [
            {
              catalogRefId: '2286651'
            }
          ]
        }
      }
    };
    const cartItemDisplayInfo = {
      showSpinner: false,
      showTransition: true
    }
    let expectedOutput = {
      cartPageData:  {
        cartItems: {
          items: [
            {
              catalogRefId: '2286651'
            }
          ]
        }
      }
    }

    expect( updateCartItemDisplayInfo( state, skuID, cartItemDisplayInfo ) ).toEqual( expectedOutput );
  } );
} );

describe( 'load cart data loading', ( ) => {
  it( 'should set cartpage message to null and chkoutbtnClk to false on loadcart loading ', ( ) => {

    let actionCreator = {
      type: getServiceType( 'loadCart', 'loading' ),
      data: {}
    }

    let expectedOutput = {
      chkoutbtnClk:false
    }

    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );
} );

describe( 'testing if populatePickupUnavailableItemDetails yields correct results', () => {
  it( 'should return with true if any of the items have pickup false and displayType is removed', () => {
    let testData = {
      cartItems: {
        items: [{
          displayType: 'removed',
          availabilityStatus: {
            pickup: false,
            online: true
          },
          catalogRefId: '123abc'
        },
        {
          catalogRefId: '1232132abc',
          quantity: 2,
          productId: 'xlsImpprod3730156',
          displayType: 'default',
          availabilityStatus: {
            online: true,
            pickup: true
          },
          moveToBag: true
        }]
      }
    }
    expect( populatePickupUnavailableItemDetails( testData ) ).toEqual( true );
  } );

  it( 'should return with false if none of the items have displayType is removed', () => {
    let testData1 = {
      cartItems: {
        items: [{
          displayType: 'default',
          availabilityStatus: {
            pickup: false,
            online: true
          },
          catalogRefId: '123abc'
        },
        {
          catalogRefId: '1232132abc',
          quantity: 2,
          productId: 'xlsImpprod3730156',
          displayType: 'default',
          availabilityStatus: {
            online: true,
            pickup: false
          },
          moveToBag: true
        }]
      }
    }
    expect( populatePickupUnavailableItemDetails( testData1 ) ).toEqual( false );
  } );

  it( 'should return with false if none of the items have displayType is removed', () => {
    let testData2 = {
      cartItems: {
        items: [{
          displayType: 'removed',
          availabilityStatus: {
            pickup: true,
            online: true
          },
          catalogRefId: '123abc'
        },
        {
          catalogRefId: '1232132abc',
          quantity: 2,
          productId: 'xlsImpprod3730156',
          displayType: 'removed',
          availabilityStatus: {
            online: true,
            pickup: true
          },
          moveToBag: true
        }]
      }
    }
    expect( populatePickupUnavailableItemDetails( testData2 ) ).toEqual( false );
  } );
} );
