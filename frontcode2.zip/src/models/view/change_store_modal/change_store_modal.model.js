/**
 * Change Store Modal Redux reducer Module
 *
 */
import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import isEmpty from 'lodash/isEmpty';
import { createSelector } from 'reselect';
import {
  DISPLAY_CHANGE_STORE,
  CLOSE_CHANGE_STORE_MODAL,
  SEARCH_BUTTON_FOCUSED,
  SEARCH_BUTTON_UNFOCUSED,
  SEARCH_FOCUSED,
  SEARCH_UNFOCUSED,
  TOGGLE_FILTER_STORE
} from '../../../events/change_store_modal/change_store_modal.events';
import ChangeStoreModalMessages from '../../../views/ChangeStoreModal/ChangeStoreModal.messages';
import {
  retrieveFilterStores
} from '../../../utils/local_storage/local_storage';

/**
 * default state for the ChangeStoreModal reducer
 */


export const initialState = {
  pickupStoresData: null,
  isPickupStoresLoading: false,
  isChangeStoreModalOpen: false,
  switchLabel: false,
  pickupStoreStatus: {},
  searchButtonFocus: false,
  inputFieldFocus: false,
  isLocationBlocked: true, // to indcate if location is blocked or not
  filterStores:false
};

export default function reducer( state = initialState, action ){
  return reducerSwitch( state, action )
}

export const reducerSwitch = function( state, action ){

  switch ( action.type ){
    case getServiceType( 'pickupStores', 'loading' ):
      return {
        ...state,
        pickupStoresData: null,
        pickupStoreStatus: {},
        searchButtonFocus: false,
        switchLabel: !!action.data.searchValue,
        isPickupStoresLoading:true,
        isChangeStoreModalOpen: true
      };

    case getServiceType( 'pickupStores', 'requested' ):
      return {
        ...state,
        isPickupStoresLoading:true,
        isChangeStoreModalOpen: true,
        filterStores: retrieveFilterStores() || false
      }

    case getServiceType( 'latLong', 'success' ):
      return {
        ...state,
        // If location access is blocked then action.data will be undefined
        isLocationBlocked: !action.data
      }
    case getServiceType( 'cartPickupInfoUpdate', 'success' ):
      return {
        ...state,
        // cartPickupInfoUpdate success indicates the user have allowed to acccess the location
        isLocationBlocked:false
      }

    case getServiceType( 'pickupStores', 'success' ):
      return {
        ...state,
        pickupStoresData: action.data.pickupStoresData,
        completelyAvailableStores: action.data.pickupStoresData && action.data.pickupStoresData.filter( store => store?.itemAvailability?.status === 'completelyAvailable' ),
        realTimeDataAvailable: action.data.realTimeDataAvailable,
        isPickupStoresLoading: false,
        // If empty stores are returned ( isStoresDataEmpty will be true and pickupStoresData will be undefined )'No results found' message should be displayed.
        ...( action.data.isStoresDataEmpty && { errorMsgOnLocationUnavailableDesc: formatMessage( ChangeStoreModalMessages.errorMsgNoResult ) } ),
        // If location is not found ( pickupStoresData will be undefined and isStoresDataEmpty will be false ) corresponding message will be displayed
        ...( !action.data.pickupStoresData && !action.data.isStoresDataEmpty && {
          errorMsgOnLocationUnavailableTitle: formatMessage( ChangeStoreModalMessages.errorMsgCantFind ),
          errorMsgOnLocationUnavailableDesc: formatMessage( ChangeStoreModalMessages.errorMsgLocationUnavailable1 )
        } )
      };

    case DISPLAY_CHANGE_STORE:
      return {
        ...initialState,
        isChangeStoreModalOpen: true,
        errorMsgOnLocationUnavailableDesc: formatMessage( ChangeStoreModalMessages.errorMsgLocationUnavailable1 )
      };

    case CLOSE_CHANGE_STORE_MODAL:
      return {
        ...state,
        isChangeStoreModalOpen: false
      };

    case SEARCH_BUTTON_FOCUSED:
      return {
        ...state,
        searchButtonFocus: true
      };

    case SEARCH_BUTTON_UNFOCUSED:
      return {
        ...state,
        searchButtonFocus: false
      };

    case SEARCH_FOCUSED:
      return {
        ...state,
        /* Set labels & icons to labelSearch & search icon if the InputField is focused*/
        switchLabel: true,
        inputFieldFocus: true
      };

    case SEARCH_UNFOCUSED:
      return {
        ...state,
        /* Set labels & icons to labelSearch & Search icon if the InputField has data
        *  or else set label & icons to labelDefault & Geo-locate icon
        * */
        switchLabel: !!action.data.searchValue,
        inputFieldFocus: false
      };

    case TOGGLE_FILTER_STORE:
      return {
        ...state,
        filterStores:action.data
      }


    case getServiceType( 'pickupStoreInfoUpdate', 'success' ):
      const { storeId, storeAvailable } = action.data;

      return {
        ...state,
        // keep the modal open if the store is unavailable for pickup
        isChangeStoreModalOpen: !storeAvailable,
        // map which has storeId's mapped to boolean values based on store availability for pickup
        pickupStoreStatus: {
          ...state.pickupStoreStatus,
          ...{ [storeId]: storeAvailable }
        }
      };

    default:
      return state;

  }
};

// input selectors for showFilterOption
export const getRealTimeDataAvailable = ( state ) => state.ChangeStoreModal.realTimeDataAvailable;
export const getPickupStoresData = ( state ) => state.ChangeStoreModal.pickupStoresData;

// A memorized selector that recalculates showFilterOption when the value of state.ChangeStoreModal.realTimeDataAvailable or state.ChangeStoreModal.pickupStoresData changes,
// but not when changes occur in other (unrelated) parts of the state tree.
export const showFilterOption = createSelector(
  [getRealTimeDataAvailable, getPickupStoresData],
  ( realTimeDataAvailable, pickupStoresData ) => {
    return realTimeDataAvailable && !isEmpty( pickupStoresData )
  }
)

// input selectors for showFilterStoreErrorMessage
export const isLocationBlocked = ( state ) => state.ChangeStoreModal.isLocationBlocked;
export const isPickupStoresLoading = ( state ) => state.ChangeStoreModal.isPickupStoresLoading;
export const getfilterStores = ( state ) => state.ChangeStoreModal.filterStores;
export const getcompletelyAvailableStores = ( state ) => state.ChangeStoreModal.completelyAvailableStores;

// A memorized selector that recalculates showFilterStoreErrorMessage when the value of state.ChangeStoreModal.getPickupStoresData,
// state.ChangeStoreModal.isPickupStoresLoading, state.ChangeStoreModal.filterStores or state.ChangeStoreModal.completelyAvailableStores changes,
// but not when changes occur in other (unrelated) parts of the state tree.
export const showFilterStoreErrorMessage = createSelector(
  [getPickupStoresData, isPickupStoresLoading, getfilterStores, getcompletelyAvailableStores],
  ( pickupStoresData, isPickupStoresLoading, filterStores, completelyAvailableStores ) => {
    return !!pickupStoresData && !isPickupStoresLoading && filterStores && isEmpty( completelyAvailableStores )
  }
)
