import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { initializeIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import React from 'react';
import CONFIG from '../../../modules/ccr/ccr.config';
import configureStore from '../../../modules/ccr/ccr.store';
import {
  DISPLAY_CHANGE_STORE,
  CLOSE_CHANGE_STORE_MODAL,
  SEARCH_BUTTON_FOCUSED,
  SEARCH_BUTTON_UNFOCUSED,
  SEARCH_FOCUSED,
  SEARCH_UNFOCUSED,
  TOGGLE_FILTER_STORE
} from '../../../events/change_store_modal/change_store_modal.events';
import reducer, {
  initialState,
  showFilterOption,
  showFilterStoreErrorMessage
} from './change_store_modal.model';
import ChangeStoreModalMessages from '../../../views/ChangeStoreModal/ChangeStoreModal.messages';

describe( 'ChangeStoreModal reducer', ( ) => {
  registerServiceName( 'pickupStores' );
  registerServiceName( 'pickupStoreInfoUpdate' );
  initializeIntl();


  it( 'should have the proper default state', ( ) => {
    const expectedState = {
      pickupStoresData: null,
      isChangeStoreModalOpen: false,
      switchLabel : false,
      pickupStoreStatus: {},
      isPickupStoresLoading: false,
      inputFieldFocus: false,
      searchButtonFocus: false,
      isLocationBlocked: true,
      filterStores:false
    };
    expect( initialState ).toEqual( expectedState );
  } );

  it( 'pickupStores success case - store are available', ( ) => {
    const data = {
      pickupStoresData:[{
        storeid:'1',
        itemAvailability:{
          status:'completelyAvailable'
        }
      },
      {
        storeid:'2',
        itemAvailability:{
          status:'partiallyAvailable'
        }
      }],
      realTimeDataAvailable:false,
      isStoresDataEmpty:false
    };
    let actionCreator = {
      type: getServiceType( 'pickupStores', 'success' ),
      data
    };
    let expectedOutput = {
      pickupStoresData:[{
        storeid:'1',
        itemAvailability:{
          status:'completelyAvailable'
        }
      },
      {
        storeid:'2',
        itemAvailability:{
          status:'partiallyAvailable'
        }
      }],
      completelyAvailableStores:[
        {
          storeid:'1',
          itemAvailability:{
            status:'completelyAvailable'
          }
        }
      ],
      isPickupStoresLoading: false,
      realTimeDataAvailable:false
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'pickupStores success case - stores are not available', ( ) => {
    const data = {
      pickupStoresData:undefined,
      isStoresDataEmpty:true
    };
    let actionCreator = {
      type: getServiceType( 'pickupStores', 'success' ),
      data
    };
    let expectedOutput = {
      pickupStoresData: undefined,
      isPickupStoresLoading: false,
      errorMsgOnLocationUnavailableDesc:formatMessage( ChangeStoreModalMessages.errorMsgNoResult )
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'pickupStores success case - location not available ', ( ) => {
    const data = {
      pickupStoresData:undefined,
      isStoresDataEmpty:false
    };
    let actionCreator = {
      type: getServiceType( 'pickupStores', 'success' ),
      data
    };
    let expectedOutput = {
      pickupStoresData: undefined,
      isPickupStoresLoading: false,
      errorMsgOnLocationUnavailableTitle: formatMessage( ChangeStoreModalMessages.errorMsgCantFind ),
      errorMsgOnLocationUnavailableDesc: formatMessage( ChangeStoreModalMessages.errorMsgLocationUnavailable1 )
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set isPickupStoresLoading as true', () => {
    let actionCreator = {
      type: getServiceType( 'pickupStores', 'loading' ),
      data: { searchValue: 'testVal' }
    };
    let expectedOutput = {
      pickupStoresData: null,
      pickupStoreStatus: {},
      searchButtonFocus: false,
      switchLabel: true,
      inputFieldFocus: true,
      isPickupStoresLoading:true,
      isChangeStoreModalOpen: true
    };
    expect( reducer( { inputFieldFocus: true }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set isPickupStoresLoading and isChangeStoreModalOpen as true during pickupStores requested', () => {
    let actionCreator = {
      type: getServiceType( 'pickupStores', 'requested' )
    };
    let expectedOutput = {
      isPickupStoresLoading:true,
      isChangeStoreModalOpen: true,
      filterStores:false
    };
    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set isChangeStoreModalOpen as true and set the error message', () => {
    let actionCreator = {
      type: DISPLAY_CHANGE_STORE
    };
    let expectedOutput = {
      ...initialState,
      isChangeStoreModalOpen: true,
      errorMsgOnLocationUnavailableDesc: formatMessage( ChangeStoreModalMessages.errorMsgLocationUnavailable1 )
    };
    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set isChangeStoreModalOpen as false', () => {
    let actionCreator = {
      type: CLOSE_CHANGE_STORE_MODAL
    };
    let expectedOutput = {
      isChangeStoreModalOpen: false
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should switch label if field is focused', () => {
    let actionCreator = {
      type: SEARCH_FOCUSED
    };
    let expectedOutput = {
      switchLabel: true,
      inputFieldFocus: true
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should switch label if searchValue is not empty and field is not focused', () => {
    let actionCreator = {
      type: SEARCH_UNFOCUSED,
      data: { searchValue: 'test' }
    };
    let expectedOutput = {
      switchLabel: true,
      inputFieldFocus: false
    };
    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should not switch label searchValue is empty and field is not focused', () => {
    let actionCreator = {
      type: SEARCH_UNFOCUSED,
      data: { searchValue: undefined }
    };
    let expectedOutput = {
      switchLabel: false,
      inputFieldFocus: false
    };
    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should not show geo locate icon if search icon is focused', () => {
    let actionCreator = {
      type: SEARCH_BUTTON_FOCUSED
    };
    let expectedOutput = {
      searchButtonFocus: true
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should not show geo locate icon if search icon is not focused', () => {
    let actionCreator = {
      type: SEARCH_BUTTON_UNFOCUSED
    };
    let expectedOutput = {
      searchButtonFocus: false
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set store status to true if store is available for pickup', ( ) => {
    const expectedOutput = {
      isChangeStoreModalOpen: false,
      pickupStoreStatus: { testId: true }
    };
    const actionCreator = {
      type: getServiceType( 'pickupStoreInfoUpdate', 'success' ),
      data:{
        cartResponse: { test: 'test' },
        storeId: 'testId',
        storeAvailable : true
      }
    };

    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set store status to false if store is available for pickup', ( ) => {
    const expectedOutput = {
      isChangeStoreModalOpen: true,
      pickupStoreStatus: { testId: false }
    };
    const actionCreator = {
      type: getServiceType( 'pickupStoreInfoUpdate', 'success' ),
      data:{
        cartResponse: { test: 'test' },
        storeId: 'testId',
        storeAvailable : false
      }
    };

    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set isLocationBlocked to false if lat and long value is present in latLong success', ( ) => {
    const state = {
      isLocationBlocked: true
    }
    const expectedOutput = {
      isLocationBlocked: false
    };
    const actionCreator = {
      type: getServiceType( 'latLong', 'success' ),
      data:{
        lat: 76.2
      }
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set isLocationBlocked to false if no value is present in latLong success', ( ) => {
    const state = {
      isLocationBlocked: false
    }
    const expectedOutput = {
      isLocationBlocked: true
    };
    const actionCreator = {
      type: getServiceType( 'latLong', 'success' )
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set isLocationBlocked to false on cartPickupInfoUpdate success', ( ) => {

    const expectedOutput = {
      isLocationBlocked: false
    };
    const actionCreator = {
      type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
      data:{}
    };

    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set filterStores when TOGGLE_FILTER_STORE action is triggered', ( ) => {

    const expectedOutput = {
      filterStores: true
    };
    const actionCreator = {
      type: TOGGLE_FILTER_STORE,
      data:true
    };

    expect( reducer( { filterStores: false }, actionCreator ) ).toEqual( expectedOutput );
  } );

} );

describe( 'showFilterOption selector tests', () => {

  let state = {
    ChangeStoreModal : {
      realTimeDataAvailable: true,
      pickupStoresData: [{
        storeId:'1'
      }]
    }
  };

  it( 'should return true if realTimeDataAvailable is true and pickupStoresData is not empty', () => {
    let returnValue = showFilterOption( state );
    expect( returnValue ).toBe( true );
    expect( showFilterOption.recomputations() ).toBe( 1 );
  } );

  it( 'should return true if the state has not changed', () => {
    let returnValue = showFilterOption( state );
    expect( returnValue ).toBe( true );
    // since the state value has not changed the selector will return the memorized value and will not do the recomputation
    expect( showFilterOption.recomputations() ).toBe( 1 );
  } );

  it( 'should return false if the realTimeDataAvailable is false', () => {
    state = {
      ChangeStoreModal : {
        realTimeDataAvailable: false,
        pickupStoresData: [{
          storeId:'1'
        }]
      }
    };
    let returnValue = showFilterOption( state );
    expect( returnValue ).toBe( false );
    // since the state value has not changed the selector will return the memorized value and will not do the recomputation
    expect( showFilterOption.recomputations() ).toBe( 2 );
  } );

  it( 'should return false and compute since the state has changed', () => {
    state = {
      ChangeStoreModal : {
        realTimeDataAvailable: true,
        pickupStoresData: null
      }
    };
    let returnValue = showFilterOption( state );
    expect( returnValue ).toBe( false );
    // since the state value has changed the selector will do the recomputation and the recomputation count will increase by 1
    expect( showFilterOption.recomputations() ).toBe( 3 );

  } );
} );

describe( 'showFilterStoreErrorMessage selector tests', () => {

  let state = {
    ChangeStoreModal : {
      isLocationBlocked: false,
      isPickupStoresLoading:false,
      filterStores:true,
      completelyAvailableStores:[],
      pickupStoresData:[
        { storeId:'1' }
      ]
    }
  };

  it( 'should return true if pickupStoresData is not null,isPickupStoresLoading is false , filterStores is true  and completelyAvailableStores is empty', () => {
    let returnValue = showFilterStoreErrorMessage( state );
    expect( returnValue ).toBe( true );
    expect( showFilterStoreErrorMessage.recomputations() ).toBe( 1 );
  } );

  it( 'should return true if the state has not changed', () => {
    let returnValue = showFilterStoreErrorMessage( state );
    expect( returnValue ).toBe( true );
    // since the state value has not changed the selector will return the memorized value and will not do the recomputation
    expect( showFilterStoreErrorMessage.recomputations() ).toBe( 1 );
  } );

  it( 'should return false if the pickupStoresData is null', () => {
    state = {
      ChangeStoreModal : {
        isLocationBlocked: true,
        isPickupStoresLoading:false,
        filterStores:true,
        completelyAvailableStores:[],
        pickupStoresData: null
      }
    };
    let returnValue = showFilterStoreErrorMessage( state );
    expect( returnValue ).toBe( false );
    // since the state value has changed the selector will do the recomputation and the recomputation count will increase by 1
    expect( showFilterStoreErrorMessage.recomputations() ).toBe( 2 );
  } );

  it( 'should return false if the isPickupStoresLoading is true and compute since the state has changed', () => {
    state = {
      ChangeStoreModal : {
        isLocationBlocked: false,
        isPickupStoresLoading:true,
        filterStores:true,
        completelyAvailableStores:[]
      }
    };
    let returnValue = showFilterStoreErrorMessage( state );
    expect( returnValue ).toBe( false );
    // since the state value has changed the selector will do the recomputation and the recomputation count will increase by 1
    expect( showFilterStoreErrorMessage.recomputations() ).toBe( 3 );

  } );

  it( 'should return false if the filterStores is false and compute since the state has changed', () => {
    state = {
      ChangeStoreModal : {
        isLocationBlocked: false,
        isPickupStoresLoading:false,
        filterStores:false,
        completelyAvailableStores:[]
      }
    };
    let returnValue = showFilterStoreErrorMessage( state );
    expect( returnValue ).toBe( false );
    // since the state value has changed the selector will do the recomputation and the recomputation count will increase by 1
    expect( showFilterStoreErrorMessage.recomputations() ).toBe( 4 );

  } );

  it( 'should return false if the completelyAvailableStores is not empty and compute since the state has changed', () => {
    state = {
      ChangeStoreModal : {
        isLocationBlocked: false,
        isPickupStoresLoading:false,
        filterStores:true,
        completelyAvailableStores:[
          { storeId:'1' }
        ]
      }
    };
    let returnValue = showFilterStoreErrorMessage( state );
    expect( returnValue ).toBe( false );
    // since the state value has changed the selector will do the recomputation and the recomputation count will increase by 1
    expect( showFilterStoreErrorMessage.recomputations() ).toBe( 5 );

  } );

} );
