/**
 * CheckoutPage Redux reducer Module
 *
 */

import isUndefined from 'lodash/isUndefined';
import {
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY,
  TOGGLE_INPUTFIELD_DISPLAY
} from 'ulta-fed-core/dist/js/events/forms/forms.events';

import forIn from 'lodash/forIn';
import has from 'lodash/has';
import find from 'lodash/find';
import isEmpty from 'lodash/isEmpty';


import {
  isMobileDevice
} from 'ulta-fed-core/dist/js/utils/device_detection/device_detection';
import {
  ALERT_WINDOW_RESIZE
} from 'ulta-fed-core/dist/js/events/global/global.events';


import {
  CHANGE as REDUXFORM_CHANGE,
  FOCUS as REDUXFORM_FOCUS
} from 'redux-form/lib/actionTypes';

import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import get from 'lodash/get';
import PaymentFormMessages from '../../../views/PaymentForm/PaymentForm.messages';
import {
  SET_PAYMENT_FORM_TYPE,
  RESET_CHECKOUT_DATA_AVAILABLE,
  SET_EDIT_ADDRESS_DATA,
  UPDATE_PAYMENT_STATUS,
  SET_EDIT_CREDITCARD_DATA,
  RESET_CART_MERGED,
  SET_CREDITCARD_PAYMENT_TYPE,
  SET_TEMP_PAYMENT_CCV_NUMBER,
  RESET_CARTPAGE_NAVIGATION,
  RESET_ORDER_STATUS,
  CHECKOUT_PANEL_COLLAPSE,
  UPDATE_STATE_DROPDOWN_VALUE,
  PAYPAL_RESPONSE,
  SET_SHOW_PAYPAL_BUTTON,
  SET_IS_COUPON_BUTTON_CLICKED,
  SET_SHOW_DEFAULT_SHIPPING_METHOD,
  SET_SHIPPING_ADDRESS_VIEW,
  SET_PAYMENT_INFORMATION_VIEW,
  SET_DISPLAY_DAV_POPUP,
  ADD_EDIT_PAYMENT_METHOD,
  TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY,
  TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY,
  BILLING_ADDRESS_SAME_AS_SHIPPING,
  BILLING_ADDRESS_SAME_AS_CONTACT_INFO,
  TOGGLE_OPTIN_FOR_SMS,
  UPDATE_MOBILE_NUMBER
} from '../../../events/checkout_page/checkout_page.events';

import {
  persistPickupSmsInfo,
  retrievePickupSmsInfo
} from '../../../utils/local_storage/local_storage';


/**
 * default state for the CheckoutPage reducer
 */


export const initialState = {
  stateDropdownValues: {
    billing: '',
    shipping: ''
  },
  checkoutFormAddressOpen: {
    paymentAddressForm: false,
    shippingAddressForm: false
  },
  checkoutFormAddress2Open: {
    paymentAddressForm: false,
    shippingAddressForm: false
  },
  paymentServiceResponse: {},
  checkoutServicesData: {},
  paypalResponse: {},
  callPaypalService: true,
  paypal: false,
  giftCardDetails: {},
  giftCardErrorMessage:null,
  loyaltyCardDetails: {},
  creditCardDetails: null,
  payPalDetails:null,
  afterpayDetails: null,
  giftCardApplying: false,
  editAddressData: {},
  editCreditCardData: {},
  submitOrderService: {},
  isCouponButtonClicked: false,
  isShippingError: false,
  shippingSuccess: false,
  paymentSuccess: false,
  paymentError: undefined,
  joinNowRewardsError: [],
  displayDavPopUp: false,
  paymentType: 'creditCard',
  previousPaymentType: null,
  cartMerged: false,
  checkoutFormConfig: {
    showHideCheckoutToggleData: {
      securityCode: false,
      ccSecurityCode: false
    }
  },
  remainingPaymentDue: undefined,
  navigateToCartPage: false,
  checkoutError: [],
  orderSuccess: false,
  orderId: undefined,
  isCheckoutDataAvailable: false,
  submitOrderSpinner: false,
  tempPaymentCCVNumber: null,
  isErrorBeforeSubmitOrder: undefined,
  payPalClientToken: undefined,
  profileCreditCardListCount: 0,
  showSecurityIcon: true,
  anchorAfterSubmitServiceCall: undefined,
  displayCheckoutLevelErrorMessage: false,
  activeField:'',
  isGiftCardRemoved: false,
  isRewardPointsRemoved: false,
  changeShippingAddress:false,
  showDefaultShippingMethod:true,
  shippingAddressView:'addEditShippingAddressView',
  shippingErrorMessages:null,
  shippingWarningMessages:null,
  incompatibleShippingMessges:null,
  isPaymentCreditCardPayPalView: true,
  isPaymentDefaultCreditCardView: false,
  isProfileCreditCardListView:false,
  isPaymentAddEditMode:false,
  showUltamateRewardsCreditCard:true,
  shouldDisplayExpiryAndCvv:false,
  isBillingAddressSameAsShipping: true,
  isBillingAddressSameAsContactInfo: true,
  pickupPaymentAddress:null,
  billingAddress:null,
  creditCardType:'DefaultCreditCard',
  isValidCardType:true,
  showPaypalButton: false,
  paymentsCCKey: undefined,
  checkoutPanelCollapse: {
    coupons: false,
    giftCard: false,
    redeemPanel: false
  },
  redeemPointLevels: {},
  redeemPointsMessages: {},
  selectedPoints: null,
  hasMessages: false,
  canDisplayPoints: false,
  pointsApplied: false,
  isUltamateRewardCard:false,
  reloadCheckoutPage:false,
  pickupSmsOptInStatus: false,
  pickupMobileNumber: undefined,
  showGiftCard: true,
  isPaymentTypeAfterPay: false,
  showAfterpay: false
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now( ) or Math.random( ).
 */
export default function reducer( state = initialState, action ){

  switch ( action.type ){

    case SET_PAYMENT_FORM_TYPE:
      const isPaymentTypeAfterPay = action.paymentType === 'afterpay' && state.showAfterpay;
      return {
        ...state,
        paymentType: action.paymentType,
        isPaymentTypeAfterPay,
        showGiftCard: showGiftCard( action.paymentType, state.giftCardDetails, state.loyaltyCardDetails, isPaymentTypeAfterPay )
      }

    case getServiceType( 'switches', 'success' ):
      return {
        ...state,
        afterpayEnabled: action.data.switches.enableAfterpay
      };

    case getServiceType( 'afterpay', 'loading' ):
      return {
        ...state,
        showAfterpay: false
      }

    case getServiceType( 'afterpay', 'success' ):
      return {
        ...state,
        showAfterpay: true,
        enableAfterpay: state.afterpayEnabled
      }

    case REDUXFORM_FOCUS:
      return {
        ...state,
        activeField:action.meta.field,
        ...( action.meta.form === 'PaymentCCSecurityCode' && action.meta.field === 'ccSecurityCode' && { showSecurityIcon:true } ),
        ...( action.meta.form === 'paymentForm' && action.meta.field === 'securityCode' && { showSecurityIcon:true } )
      }

    case REDUXFORM_CHANGE:

      if( ( action.meta.form === 'Shipping' || action.meta.form === 'shippingAddressList' ) &&
           ( state.activeField === action.meta.field || action.meta.field === 'state' ) &&
           isShippingErrorPresent( state ) &&
           isShippingFieldUpdated( state, action.meta.field, action.payload ) ){
        return {
          ...state,
          isShippingAddressErrorCleared : true,
          shippingErrorMessages:null
        }

      }
      else if( action.meta.form === 'giftCard' && state.giftCardErrorMessage &&
        isGiftCardFieldUpdated( state, action.meta.field, action.payload )
      ){
        return {
          ...state,
          giftCardDetails: { ...state.giftCardDetails, messages:null },
          giftCardErrorMessage:null
        }
      }
      else if( action.meta.form === 'Coupon' && has( state, 'checkoutServicesData.appliedCouponSummary.couponAppliedErrorMsg' ) &&
        !isEmpty( state.checkoutServicesData.appliedCouponSummary.couponAppliedErrorMsg ) && isCouponFieldUpdated( state, action.meta.field, action.payload )
      ){
        return {
          ...state,
          checkoutServicesData: {
            ...state.checkoutServicesData,
            appliedCouponSummary:{
              ...state.checkoutServicesData.appliedCouponSummary,
              couponAppliedErrorMsg:undefined
            }
          }
        }
      }
      else if( action.meta.form === 'paymentForm' && action.payload && state.activeField === action.meta.field &&
      isPaymentFieldUpdated( state, action.meta.field, action.payload ) ){
        const isErrorPresent = isPaymentErrorPresent( state );
        return {
          ...state,
          ...( isErrorPresent && {
            paymentError : [],
            creditCardDetails: {
              ...state.creditCardDetails,
              messages: []
            },
            isPaymentErrorCleared:true,
            creditCardMessages:null
          } ),
          ...( action.meta.field === 'creditCardNumber' && { loadMaskCreditcard:false } ),
          ...( action.meta.field === 'securityCode' && { showSecurityIcon:setShowSecurityIcon( action.payload ) } )
        }

      }
      else if( action.meta.form === 'PaymentCCSecurityCode' && action.payload &&
      isPaymentFieldUpdated( state, action.meta.field, action.payload ) ){
        const isErrorPresent = isPaymentErrorPresent( state );
        return {
          ...state,
          ...( isErrorPresent && {
            paymentError : [],
            creditCardDetails: {
              ...state.creditCardDetails,
              messages: []
            },
            isPaymentErrorCleared:true,
            creditCardMessages:null
          } ),
          showSecurityIcon: setShowSecurityIcon( action.payload )
        }
      }
      else {
        return {
          ...state
        }
      }
    case getServiceType( 'login', 'success' ):
      return {
        ...state,
        cartMerged: action.data.res.cartMerged,
        // reload checkoutpage when user login in from checkoutpage with mergcart false
        reloadCheckoutPage: !action.data.res.cartMerged && action.data.res.success
      }

    case RESET_CHECKOUT_DATA_AVAILABLE:
      return {
        ...state,
        isCheckoutDataAvailable: false
      }

    case getServiceType( 'initCart', 'requested' ):
      return {
        ...state,
        isCheckoutDataAvailable: action.data.hideSpinner,
        // resetting isPaymentTypeAfterPay flag, when user soft redirects to cart page and again lands in checkout page
        // isPaymentTypeAfterPay will be set in initCart success according to initcart service response
        isPaymentTypeAfterPay: false
      }

    case getServiceType( 'addressbook', 'success' ):
      const addressBookResponse = find( action.data.addressBookResponse.items, { 'isSelected':true } );
      return {
        ...state,
        editAddressData:{
          ...state.editAddressData,
          refId: addressBookResponse ? addressBookResponse.refId : null
        }
      }
    case getServiceType( 'shippingUpdate', 'requested' ):
      return {
        ...state,
        // isShippingAddressErrorCleared field is used to indicate that any error that was returned from the previous server call
        // was cleared on client side as part of any address edit. This flag is reset to false anytime the next server call is made
        isShippingAddressErrorCleared : false,
        shippingErrorMessages:null
      }
    case getServiceType( 'estimatedDeliveryDate', 'success' ):
      return {
        ...state,
        checkoutServicesData: {
          ...state.checkoutServicesData,
          shippingInfo:{
            ...state.checkoutServicesData.shippingInfo,
            shipMethodInfo:{
              items:state.checkoutServicesData.shippingInfo.shipMethodInfo.items.map( ( shipMethod ) => {
                let shipMethodItem = shipMethod
                shipMethodItem.estimatedDelivery = action.data.shipMethodList.items.find( shipMethodInfo => shipMethodInfo.shipMethod === shipMethodItem.shipMethod ).estimatedDelivery
                return shipMethodItem ;
              } )
            }
          }
        },
        selectedShippingMethod: {
          ...state.selectedShippingMethod,
          // get the estimatedDelivery corresponding to the selected shipMethod
          estimatedDelivery: action.data.shipMethodList &&
          action.data.shipMethodList.items.find( shipMethodInfo => shipMethodInfo.shipMethod === state.selectedShippingMethod.shipMethod ).estimatedDelivery
        }
      }

    case getServiceType( 'shippingUpdate', 'success' ):

      const shippingInfo = action.data.response.shippingInfo;
      return {
        ...state,
        shippingSuccess: true,
        checkoutServicesData: {
          ...state.checkoutServicesData,
          cartSummary: has( action.data, 'response.cartSummary' ) ? action.data.response.cartSummary : state.checkoutServicesData.cartSummary,
          shippingInfo:shippingInfo,
          paymentDetails: has( action.data, 'response.paymentDetails' ) ? action.data.response.paymentDetails : state.checkoutServicesData.paymentDetails
        },
        selectedShippingMethod: has( action.data, 'response.shippingInfo.shipMethodInfo.items' ) ? action.data.response.shippingInfo.shipMethodInfo.items.find( shipMethodInfo => shipMethodInfo.isSelected === true ) : null,
        ...( action.data.response.shippingInfo && filterShippingMesssages( shippingInfo ) ),
        displayDavPopUp: action.data.response.shippingInfo && action.data.response.shippingInfo.shippingStatus === 'CorrectedAddress',
        // isShippingMethodUpdated flag is added to ensure that shipping address section is not affected when shipping method is updated
        // editAddressData will be updated only if isShippingMethodUpdated is false
        editAddressData: has( action.data, 'response.shippingInfo.shippingAddress' ) && !action.data.isShippingMethodUpdated ? Object.assign( {}, action.data.response.shippingInfo.shippingAddress ) : null,
        shippingAddressView:action.data.response.shippingInfo && setShippingAddressView( action.data.response.shippingInfo, state.shippingAddressView ),
        ...( action.data.response.shippingInfo && action.data.response.shippingInfo.shippingAddress && state.isBillingAddressSameAsShipping && { billingAddress:action.data.response.shippingInfo.shippingAddress } )
      }

    // Data from service to populate the cart data
    case getServiceType( 'initCart', 'success' ):
      const creditCardDetails = action.data.result.paymentInfo && find( action.data.result.paymentInfo.items, { paymentType:'creditCard' } );
      return {
        ...state,
        isCheckoutDataAvailable: true,
        checkoutServicesData: action.data.result,
        selectedShippingMethod: has( action.data.result, 'shippingInfo.shipMethodInfo.items' ) ? action.data.result.shippingInfo.shipMethodInfo.items.find( shipMethodInfo => shipMethodInfo.isSelected === true ) : null,
        orderId: action.data.result.id,
        ...( action.data.result.shippingInfo && filterShippingMesssages( action.data.result.shippingInfo ) ),
        editAddressData: action.data.result.shippingInfo && action.data.result.shippingInfo.shippingAddress ? Object.assign( {}, action.data.result.shippingInfo.shippingAddress ) : null,
        shippingAddressView:action.data.result.shippingInfo && setShippingAddressView( action.data.result.shippingInfo, state.shippingAddressView ),
        ...populatePaymentData( action.data.result, state, action.data.isSignedIn ),
        ...setPaymentInformationView( {
          paymentInfo:action.data.result.paymentInfo,
          isSignedIn:action.data.isSignedIn,
          creditCardDetails
        } ),
        // For a guest user on load of checkout page billingAddress will be same as shipping even if shippingAddress address is not present
        // if deliveryOption is pickup then shippingInfo will be null
        ...( !action.data.isSignedIn && ( !action.data.result.shippingInfo || !action.data.result.shippingInfo.shippingAddress ) && !action.data.result.pickupInfo && { isBillingAddressSameAsShipping:true, billingAddress:null } ),
        ...updatePickupSmsInfo( action, state )
      }

    case TOGGLE_OPTIN_FOR_SMS:
      return {
        ...state,
        ...populatePickupSmsInfo( { pickupSmsOptInStatus: action.data }, state, 'toggleOptinSms' )
      }

    case UPDATE_MOBILE_NUMBER:
      return {
        ...state,
        ...populatePickupSmsInfo( { pickupMobileNumber: action.data }, state, 'updateMobileNumber' )
      }

    case getServiceType( 'paymentServiceResponse', 'requested' ):
      return {
        ...state,
        // isPaymentErrorCleared field is used to indicate that any error that was returned from the previous server call
        // was cleared on client side as part of any address edit. This flag is reset to false anytime the next server call is made
        isPaymentErrorCleared : false,
        isPaymentTypeAfterPay: false
      }

    case getServiceType( 'paymentServiceResponse', 'success' ):
      const istokenizationFailure = action.data.istokenizationFailure;
      return {
        ...state,
        ...( !istokenizationFailure && {
          paymentError: [],
          checkoutServicesData: {
            ...state.checkoutServicesData,
            cartSummary: action.data.result.cartSummary,
            paymentInfo: action.data.result.paymentInfo,
            appliedCouponSummary:action.data.result.appliedCouponSummary
          },
          ...populatePaymentData( action.data.result, state, state.isSignedIn, action.data.paymentType ),
          ...( action.data.paymentType !== 'giftCard' &&
          setPaymentInformationView(
            {
              paymentInfo : action.data.result.paymentInfo,
              isSignedIn:state.isSignedIn,
              profileCreditCardListCount:state.profileCreditCardListCount
            }
          ) ),
          paymentSuccess:true,
          previousPaymentType: 'creditCard',
          giftCardApplying: false
        } ),
        // To display error message in payment section when cybersource API return errors
        ...( istokenizationFailure && {
          creditCardMessages: [
            {
              type: 'Error',
              message: formatMessage( PaymentFormMessages.tokenizationError )
            }
          ],
          istokenizationFailure
        } )
      }

    case getServiceType( 'removePaymentService', 'success' ):
      return {
        ...state,
        ...( action.data.paymentType && {
          ...( action.data.paymentType === 'giftCard' && { isGiftCardRemoved: true } ),
          ...( action.data.paymentType === 'loyalty' && {
            canDisplayPoints: true,
            isRewardPointsRemoved:true,
            pointsApplied: false,
            loyaltyCardDetails: {},
            checkoutPanelCollapse:{
              ...state.checkoutPanelCollapse,
              redeemPanel:false
            }
          } )
        } ),
        checkoutServicesData: {
          ...state.checkoutServicesData,
          cartSummary: action.data.result.cartSummary,
          paymentDetails: action.data.result.paymentDetails
        },
        ...populatePaymentData( action.data.result, state, state.isSignedIn, action.data.paymentType )
      }

    case getServiceType( 'paymentServiceResponse', 'loading' ):
      let giftCardApplying = !!( action.data.giftcardNumber );
      return {
        ...state,
        ...( ( action.data.paymentType && action.data.paymentType === 'giftCard' ) && { isGiftCardRemoved: false } ),
        ...( ( action.data.paymentType && action.data.paymentType === 'loyalty' ) && { isRewardPointsRemoved:false } ),
        giftCardApplying
      }

    case getServiceType( 'profileCreditCards', 'success' ):
      let profileCreditCardListCount = action.data.data.profileCreditCards ? action.data.data.profileCreditCards.items.length : 0;
      return {
        ...state,
        ...( action.data.view && { ...paymentView( action.data.view ) } ),
        // creditcard messages should be null if the user clicks on change credit card option from checkout page.
        // The same action is also triggered from initcart saga passing view as empty string
        ...( action.data.view && { creditCardMessages:null } ),
        profileCreditCardListCount:profileCreditCardListCount,
        // On checkout page load - To set the view for a user without any saved credit card and having payment option as paypal
        ...( !action.data.view && profileCreditCardListCount === 0 && { ...paymentView( 'PaymentCreditCardPayPal' ) } )
      }
    case getServiceType( 'profileCreditCards', 'requested' ):
      if( isPaymentErrorPresent( state ) ){
        return {
          ...state,
          paymentError : [],
          creditCardDetails: {
            ...state.creditCardDetails,
            messages: null
          }
        }
      }
      else {
        return {
          ...state
        }
      }

    case getServiceType( 'payPal', 'success' ):
      return {
        ...state,
        paypal: true
      };

    case TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY:

      return {
        ...state,
        checkoutFormAddressOpen: toggleFormAddress( action.formName, state )
      }

    case SET_EDIT_ADDRESS_DATA:
      return {
        ...state,
        editAddressData: {
          refId: action.data.refId,
          firstName: {
            value:action.data.firstName
          },
          lastName: {
            value:action.data.lastName
          },
          phoneNumber: {
            value:action.data.phoneNumber
          },
          isDefault: action.data.isDefault,
          emailaddress: {
            value:action.data.email
          },
          isPaypal: action.data.isPaypal,
          address1: {
            value:action.data.address1
          },
          address2: {
            value:action.data.address2
          },
          city: {
            value:action.data.city
          },
          state: {
            value:action.data.state
          },
          postalCode: {
            value:action.data.postalCode
          }
        }
      }
    case UPDATE_PAYMENT_STATUS:
      return {
        ...state,
        paymentSuccess: !action.data
      }
    case SET_EDIT_CREDITCARD_DATA:

      return {
        ...state,
        editCreditCardData: {
          ...action.data
        },
        ...( action.data.creditCardNumber && { maskCreditCardNumber: '****' + action.data.creditCardNumber.value, loadMaskCreditcard:true } )
      }
    case RESET_CART_MERGED:

      return {
        ...state,
        cartMerged: false
      }
    case SET_CREDITCARD_PAYMENT_TYPE:
      return {
        ...state,
        ...getCreditCardTypeDetails( action.data, state.editCreditCardData.nickName )
      }
    case SET_TEMP_PAYMENT_CCV_NUMBER:
      return {
        ...state,
        tempPaymentCCVNumber: action.data
      }
    case RESET_CARTPAGE_NAVIGATION:
      return {
        ...state,
        navigateToCartPage: false
      }

    case RESET_ORDER_STATUS:
      return {
        ...state,
        orderSuccess: false
      }

    case CHECKOUT_PANEL_COLLAPSE:
      return {
        ...state,
        checkoutPanelCollapse: toggleCheckoutPanelOptionsCollapse( action.panelID, state )
      }

    case UPDATE_STATE_DROPDOWN_VALUE:

      let newState = {};

      if( action.form === 'billing' ){
        newState = {
          billing: action.value,
          shipping: state.stateDropdownValues.shipping
        }
      }
      else if( action.form === 'shipping' ){
        newState = {
          billing: state.stateDropdownValues.billing,
          shipping: action.value
        }
      }

      return Object.assign(
        {},
        state,
        {
          stateDropdownValues: newState
        }
      )

    case getServiceType( 'redeemPoints', 'success' ):
      const hasPoints = !has( action.data, 'messages' );
      const hasMessages = has( action.data, 'messages' );
      const canDisplayPoints = hasPoints && isEmpty( state.loyaltyCardDetails );

      return {
        ...state,
        canDisplayPoints: canDisplayPoints,
        hasMessages: hasMessages,
        ...( hasPoints && { redeemPointLevels: action.data } ),
        ...( hasMessages && { redeemPointsMessages: action.data.messages } )
      }

    case getServiceType( 'submitOrderService', 'requested' ):
      return {
        ...state,
        submitOrderSpinner: true,
        isErrorBeforeSubmitOrder: undefined,
        anchorAfterSubmitServiceCall: undefined,
        displayCheckoutLevelErrorMessage: false
      }
    case getServiceType( 'submitOrderService', 'failure' ):
      return {
        ...state,
        submitOrderSpinner: false,
        displayCheckoutLevelErrorMessage: !( action.data.displayCheckoutLevelErrorMessage === 'false' ),
        isErrorBeforeSubmitOrder: ( action.data.setFocusTo ) ? action.data.setFocusTo : undefined
      }
    case getServiceType( 'submitOrderService', 'success' ):
      let updatedSOSState = {};
      let displayCheckoutLevelErrorMessage = false;
      if( action.data.success ){
        return {
          ...state,
          ...updatedSOSState,
          orderSuccess: true,
          submitOrderSpinner: false
        }
      }
      else {
        let anchorAfterSubmitServiceCall;
        displayCheckoutLevelErrorMessage = true;
        updatedSOSState = messageSort( action.data, state );

        return {
          ...state,
          ...updatedSOSState,
          displayCheckoutLevelErrorMessage,
          submitOrderService: action.data.submitOrder,
          submitOrderSpinner: false
        }
      }

    case PAYPAL_RESPONSE:
      return {
        ...state,
        paypalResponse: action.info
      }
    case getServiceType( 'applyPayPalPayment', 'success' ):
      return {
        ...state,
        checkoutServicesData: {
          ...state.checkoutServicesData,
          cartSummary: action.data.cartSummary,
          // TODO need if have to switch back to show paypal button as tab commit #04e3d5317cc
          paymentInfo: action.data.paymentInfo,
          appliedCouponSummary:action.data.appliedCouponSummary
        },
        paymentType: 'paypal',
        previousPaymentType: 'paypal',
        payPalDetails: action.data.paymentInfo && find( action.data.paymentInfo.items, { paymentType:'paypal' } ),
        ...setPaymentInformationView( {
          paymentInfo:action.data.paymentInfo,
          isSignedIn: state.isSignedIn
        } ),
        // If guest user or user having no saved credit card selects payment option has paypal from checkoutpage
        ...( state.profileCreditCardListCount === 0 && { ...paymentView( 'PaymentCreditCardPayPal' ) } ),
        creditCardDetails: null,
        editCreditCardData:{},
        creditCardType:'DefaultCreditCard',
        maskCreditCardNumber:null,
        creditCardMessages:null,
        shouldDisplayExpiryAndCvv:false,
        showPaypalButton:false,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false,
        showGiftCard: true,
        afterpayDetails: null
      }

    case getServiceType( 'applyExpressPayPalPayment', 'success' ):
      return {
        ...state,
        paymentType: 'paypal',
        previousPaymentType: 'paypal',
        isPaymentTypeAfterPay: false
      }


    case getServiceType( 'paypalToken', 'success' ):
      if( !isUndefined( action.data.result ) && action.data.result === 'Error' ){
        return {
          ...state
        }
      }
      else {
        return {
          ...state,
          payPalClientToken: action.data.payPalClientToken
        }
      }

    case getServiceType( 'paypalToken', 'loading' ):
      return {
        ...state,
        payPalClientToken: undefined
      }

    case SET_SHOW_PAYPAL_BUTTON:
      return {
        ...state,
        showPaypalButton:true
      }

    case getServiceType( 'userRewards', 'success' ):
      if( has( action.data, 'cartSummary' ) ){
        return {
          ...state,
          checkoutServicesData: {
            ...state.checkoutServicesData,
            cartSummary: action.data.cartSummary
          }

        }
      }
      else {
        return {
          ...state,
          joinNowRewardsError: action.data.messages

        }
      }


    case getServiceType( 'userRewards', 'requested' ):
      return {
        ...state,
        joinNowRewardsError: []
      }

    case getServiceType( 'paymentsCCKey', 'requested' ):
      return {
        ...state,
        paymentsCCKey: undefined
      }

    case getServiceType( 'paymentsCCKey', 'success' ):
      if( has( action.data, 'jwk' ) ){
        return {
          ...state,
          paymentsCCKey: action.data
        }
      }
      else {
        return {
          ...state,
          paymentError: action.data.messages.items
        }
      }

    case TOGGLE_INPUTFIELD_DISPLAY:
      return {
        ...state,
        checkoutFormConfig: {
          ...state.checkoutFormConfig,
          showHideCheckoutToggleData: {
            ...state.checkoutFormConfig.showHideCheckoutToggleData,
            [ action.fieldName ]: !state.checkoutFormConfig.showHideCheckoutToggleData[ action.fieldName ]
          }
        }
      }
    case TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY:
      return {
        ...state,
        checkoutFormAddress2Open: {
          shippingAddressForm: !state.checkoutFormAddress2Open.shippingAddressForm,
          paymentAddressForm: state.checkoutFormAddress2Open.paymentAddressForm
        }
      }
    case TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY:
      return {
        ...state,
        checkoutFormAddress2Open: {
          shippingAddressForm: state.checkoutFormAddress2Open.shippingAddressForm,
          paymentAddressForm: !state.checkoutFormAddress2Open.paymentAddressForm
        }
      }
    case SET_IS_COUPON_BUTTON_CLICKED:
      return {
        ...state,
        isCouponButtonClicked: action.data
      }
    case ALERT_WINDOW_RESIZE:

      return {
        ...state,
        showSecurityIcon: action.screenWidth > 1024
      }
    case SET_SHOW_DEFAULT_SHIPPING_METHOD:
      return {
        ...state,
        showDefaultShippingMethod:action.data
      }
    case SET_SHIPPING_ADDRESS_VIEW:
      return {
        ...state,
        shippingAddressView:action.data,
        shippingErrorMessages:null
      }
    case SET_PAYMENT_INFORMATION_VIEW:
      return {
        ...state,
        ...paymentView( action.data )
      }
    case SET_DISPLAY_DAV_POPUP:
      return {
        ...state,
        displayDavPopUp:true
      }
    case ADD_EDIT_PAYMENT_METHOD:
      const addressData = !isEmpty( action.data ) ? {
        ...action.data.addressData,
        firstName:action.data.firstName,
        lastName:action.data.lastName,
        phoneNumber:action.data.phoneNumber
      } : null;
      const billingAddressSameAsShipping = isBillingAddressSameAsShipping( addressData, state.checkoutServicesData.shippingInfo );
      const shippingAddress = has( state.checkoutServicesData, 'shippingInfo.shippingAddress' ) && state.checkoutServicesData.shippingInfo.shippingAddress;
      return {
        ...state,
        isPaymentAddEditMode:true,
        showUltamateRewardsCreditCard:false,
        editCreditCardData:!isEmpty( action.data ) ? {
          nickName: action.data.nickName,
          creditCardType: action.data.creditCardType,
          creditCardNumber: action.data.creditCardNumber,
          expirationMonth: action.data.expirationMonth,
          expirationYear: action.data.expirationYear,
          isPrimary: action.data.isPrimary,
          contactInfo: ( action.data.addressData ) ? {
            firstName: action.data.firstName,
            lastName: action.data.lastName,
            phoneNumber: action.data.phoneNumber,
            address1: action.data.addressData.address1,
            address2: action.data.addressData.address2,
            city: action.data.addressData.city,
            state: action.data.addressData.state,
            postalCode: action.data.addressData.postalCode
          } : null
        } : {},
        editAddressData:{},
        ...paymentView( 'PaymentCreditCardPayPal' ),
        paymentType:'creditCard',
        maskCreditCardNumber: action.data.creditCardNumber ? '****' + action.data.creditCardNumber.value : null,
        loadMaskCreditcard: !!action.data.creditCardNumber,
        creditCardType:action.data.creditCardType ? action.data.creditCardType.value : 'DefaultCreditCard',
        shouldDisplayExpiryAndCvv: action.data.creditCardType && displayExpiryAndCvv( action.data.creditCardType.value, action.data.nickName ),
        isBillingAddressSameAsShipping:billingAddressSameAsShipping,
        billingAddress:isBillingAddressSameAsShipping ? shippingAddress : null,
        // If user click on add option then BillingAddressSameAsShipping should be set as true by default
        ...( isEmpty( action.data ) && { isBillingAddressSameAsShipping:true, billingAddress:shippingAddress } ),
        isPaymentTypeAfterPay: false
      }
    case BILLING_ADDRESS_SAME_AS_SHIPPING:
      // Clear address form fields when toggled from 'on' to 'off'
      // If user wants to add a new billing address.
      // If user doest not have a shipping address then toggle to sameasShipping should be disabled
      const billingAddress = has( state.checkoutServicesData, 'shippingInfo.shippingAddress' ) && state.checkoutServicesData.shippingInfo.shippingAddress ;
      const isBillingSameAsShippingAddress = billingAddress ? action.data : false;
      return {
        ...state,
        isBillingAddressSameAsShipping:isBillingSameAsShippingAddress,
        paymentSuccess:false,
        billingAddress:isBillingSameAsShippingAddress ? billingAddress : null,
        editCreditCardData : !isEmpty( state.editCreditCardData ) ? {
          ...state.editCreditCardData,
          ...( !action.data && { contactInfo: null } )
        } : {}
      }
    case getServiceType( 'pickupContactInfoUpdate', 'success' ):
      return {
        ...state,
        checkoutServicesData:{
          ...state.checkoutServicesData,
          pickupInfo: action.data.result.pickupInfo
        },
        ...( state.isBillingAddressSameAsContactInfo && { pickupPaymentAddress:action.data.result.pickupInfo.primaryContactInfo } ),
        ...updatePickupSmsInfo( action, state )
      }
    case BILLING_ADDRESS_SAME_AS_CONTACT_INFO:
      // Clear address form fields when toggled from 'on' to 'off'
      // If user wants to add a new billing address.
      // If user doest not have a shipping address then toggle to sameasShipping should be disabled
      const pickupPaymentAddress = has( state.checkoutServicesData, 'pickupInfo.primaryContactInfo' ) && state.checkoutServicesData.pickupInfo.primaryContactInfo ;
      const isBillingSameAsContactInfo = pickupPaymentAddress ? action.data : false;
      return {
        ...state,
        isBillingAddressSameAsContactInfo:isBillingSameAsContactInfo,
        pickupPaymentAddress: isBillingSameAsContactInfo ? pickupPaymentAddress : { firstName:{ value:'' }, lastName:{ value:'' }, phoneNumber:{ value:'' } }
      }

    default:
      return state;

  }
}

export const toggleCheckoutPanelOptionsCollapse = ( panelID, state ) => {
  let panelsOpened = {}
  forIn( state.checkoutPanelCollapse, ( val, key ) => {
    if( panelID === key ){
      panelsOpened[ key ] = !val;
    }
    else {
      panelsOpened[ key ] = val;

    }
  } );
  return panelsOpened;
}


export const setShippingAddressView = ( shipMethodInfo, currentShippingAddressView ) =>{
  let shippingAddressView = undefined;
  if( shipMethodInfo.shippingStatus === 'InvalidAddress' ){
    shippingAddressView = 'addEditShippingAddressView';
  }
  else if( ( shipMethodInfo.shippingStatus === 'Complete' || shipMethodInfo.shippingStatus === 'IncompatibleShipping' ||
    shipMethodInfo.shippingStatus === 'CorrectedAddress' ) ){
    shippingAddressView = 'defaultShippingAddressView';
  }
  else {
    shippingAddressView = currentShippingAddressView;
  }
  return shippingAddressView;
};

export const setPaymentInformationView = ( params ) =>{
  const {
    paymentInfo, isSignedIn, creditCardDetails, profileCreditCardListCount
  } = params;

  let tempObj = {
    isPaymentAddEditMode :false,
    isPaymentDefaultCreditCardView :false,
    isProfileCreditCardListView:false,
    isPaymentCreditCardPayPalView: false
  }
  // For a registered user if contact info null in paymentInfo (initCart data response) or
  // if the saved card have expired then on load payment section should have AddEditPaymentFormView
  if( isSignedIn && creditCardDetails && ( creditCardDetails.messages || !creditCardDetails.contactInfo ) ){
    tempObj.isPaymentAddEditMode = true;
    tempObj.isPaymentCreditCardPayPalView = true;
  }
  // PaymentCreditCardPayPalView should be set to true for
  // guest user
  // signed in user with paymentInfo null
  // signed in user who don't have any credit card details (payment option may be giftcard or paypal) and saved credit cards
  else if( !isSignedIn || !paymentInfo || ( !find( paymentInfo.items, { paymentType:'creditCard' } ) && profileCreditCardListCount === 0 ) ){
    tempObj.isPaymentCreditCardPayPalView = true;
  }
  else {
    tempObj.isPaymentDefaultCreditCardView = true
  }

  if( !tempObj.isPaymentAddEditMode && creditCardDetails ){
    tempObj.showUltamateRewardsCreditCard = true;
  }
  else {
    tempObj.showUltamateRewardsCreditCard = false;
  }
  return tempObj;
}

export const toggleFormAddress = ( formName, state ) =>{
  let obj = {}
  forIn( state.checkoutFormAddressOpen, ( val, key ) =>{
    if( formName === key ){
      obj[key] = !val;

    }
    else {
      obj[key] = val;
    }
  } );

  return obj;
};

export const messageSort = ( data, state ) =>{
  const tempState = {};
  tempState.creditCardMessages = null;
  tempState.shippingErrorMessages = null;
  tempState.checkoutError = null;
  // should set creditCardMessages only for creditcard payment type
  if( data?.paymentInfo?.messages?.items && state.paymentType === 'creditCard' ){
    tempState.creditCardMessages = data.paymentInfo.messages.items;
    tempState.anchorAfterSubmitServiceCall = 'payment';
  }
  if( has( data, 'shippingInfo.messages.items' ) ){
    tempState.shippingErrorMessages = data.shippingInfo.messages.items;
    tempState.anchorAfterSubmitServiceCall = 'shipping';
  }
  if( has( data, 'cartItems' ) && data.cartItems ){
    tempState.navigateToCartPage = true;

  }
  if( data.messages ){
    tempState.checkoutError = data.messages.items;
    tempState.anchorAfterSubmitServiceCall = 'header';
  }
  return tempState;
};

export const updateCreditCardDetails = ( formName ) =>{
  const tempState = {};
  tempState.creditCardDetails = [];
  forIn( formName, ( val, key ) =>{
    if( val.paymentInfo.paymentType === 'creditCard' ){
      tempState.creditCardDetails = val;
    }
  } );
  return tempState;
};
export const assignCreditCardDetails = ( creditCardDetails, isSignedIn )=>{

  let tempCCDetailsObj = {
    nickName: creditCardDetails.nickName,
    creditCardType: creditCardDetails.paymentDetails.creditCardType,
    creditCardNumber: creditCardDetails.paymentDetails.creditCardNumber,
    expirationMonth: creditCardDetails.paymentDetails.expirationMonth,
    expirationYear: creditCardDetails.paymentDetails.expirationYear,
    contactInfo: ( creditCardDetails.contactInfo ) ? {
      firstName: creditCardDetails.contactInfo.firstName,
      lastName: creditCardDetails.contactInfo.lastName,
      phoneNumber: creditCardDetails.contactInfo.phoneNumber,
      address1: creditCardDetails.contactInfo.address1,
      address2: creditCardDetails.contactInfo.address2,
      city: creditCardDetails.contactInfo.city,
      state: creditCardDetails.contactInfo.state,
      postalCode: creditCardDetails.contactInfo.postalCode

    } : null
  }
  return tempCCDetailsObj;
}

export const getCreditCardTypeDetails = ( value, nickName ) =>{

  let cardType;
  let isValidCardType = true;
  const newValue = value.replace( '****', '' ).replace( ' ', '' );

  if( newValue.match( /^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)/ ) ){
    cardType = 'Discover';
  }
  else if( newValue.match( /^5780|9710[5-9]/ ) ){
    cardType = 'Ultamate Rewards Credit Card';
  }
  else if( newValue.match( /^3[47]/ ) ){
    cardType = 'AmericanExpress';
  }
  else if( newValue.match( /^536817/ ) ){
    cardType = 'Ultamate Rewards MasterCard';
  }
  else if( newValue.match( /^(5([1-6][0-9][0-9][0-9][0-9])|22([2-9][1-9][0-9][0-9])|23([0-9][0-9][0-9][0-9])|24([0-9][0-9][0-9][0-9])|25([0-9][0-9][0-9][0-9])|26([0-9][0-9][0-9][0-9])|27([0-2]0[0-9][0-9]))/ ) ){
    cardType = 'Mastercard';
  }
  else if( newValue.match( /^4[0-9]/ ) ){
    cardType = 'Visa';
  }
  else {
    cardType = 'DefaultCreditCard';
  }
  const shouldDisplayExpiryAndCvv = displayExpiryAndCvv( cardType, nickName );
  if( cardType === 'DefaultCreditCard' && !isEmpty( newValue ) && newValue.length > 11 ){
    isValidCardType = false;
  }

  return {
    creditCardType:cardType,
    shouldDisplayExpiryAndCvv,
    maskCreditCardNumber:newValue,
    isValidCardType:isValidCardType
  }

}

export const displayExpiryAndCvv = ( cardType, nickName ) => {
  return cardType === 'Discover' || cardType === 'AmericanExpress' || cardType === 'Mastercard' || cardType === 'Visa' || ( cardType === 'Ultamate Rewards MasterCard' && nickName !== 'tempCBCC' )
}



export const isShippingFieldUpdated = ( state, fieldName, value ) =>{

  let changed = false;
  if( has( state, 'editAddressData' ) &&
      !isEmpty( state.editAddressData ) ){

    if( fieldName === 'address1shippingAddressForm' ){
      changed = state.editAddressData.address1.value !== value;
    }
    else if( fieldName === 'address2shippingAddressForm' ){
      changed = state.editAddressData.address2.value !== value;
    }
    else if( fieldName === 'postalCodeshippingAddressForm' ){
      changed = state.editAddressData.postalCode.value !== value;
    }
    else if( fieldName === 'cityshippingAddressForm' ){
      changed = state.editAddressData.city.value !== value;
    }
    else if( fieldName === 'state' ){
      changed = state.editAddressData.state.value !== value;
    }
  }
  return changed;
}

export const isGiftCardFieldUpdated = ( state, fieldName, value ) =>{
  let changed = false;
  let unformattedValue = value;
  while ( unformattedValue.indexOf( ' ' ) !== -1 ){
    unformattedValue = unformattedValue.replace( ' ', '' );
  }
  if( has( state, 'giftCardDetails.paymentInfo.paymentDetails.giftcardNumber.value' ) &&
    !isEmpty( state.giftCardDetails.paymentInfo.paymentDetails.giftcardNumber.value )
  ){
    if( fieldName === 'giftCardNumber' ){
      changed = state.giftCardDetails.paymentInfo.paymentDetails.giftcardNumber.value !== unformattedValue;
    }
    if( fieldName === 'giftCardPin' && value.length !== 8 ){
      changed = true;
    }
  }
  return changed;
}

export const isCouponFieldUpdated = ( state, fieldName, value ) =>{
  let changed = false;
  if( has( state, 'checkoutServicesData.appliedCouponSummary.couponCode' ) &&
    !isEmpty( state.checkoutServicesData.appliedCouponSummary.couponCode )
  ){
    if( fieldName === 'couponID' ){
      changed = state.checkoutServicesData.appliedCouponSummary.couponCode !== value;
    }
  }
  return changed;
}

export const isPaymentFieldUpdated = ( state, fieldName, value ) =>{

  let changed = false;
  if( !isEmpty( state.creditCardDetails ) ){
    const paymentDetails = state.creditCardDetails.paymentDetails;

    if( fieldName === 'creditCardNumber' ){
      const creditCardNumber = paymentDetails.creditCardNumber.value ;
      let unformattedValue = value.replace( / /g, '' );
      if( ( creditCardNumber === value ) || ( creditCardNumber === value.replace( '****', '' ) ) ){
        changed = false;
      }
      else if( ( paymentDetails.creditCardType.value === 'AmericanExpress' && unformattedValue.length !== 15 ) ||
            ( paymentDetails.creditCardType.value !== 'AmericanExpress' && unformattedValue.length !== 16 ) ){
        changed = true;
      }
    }
    else if( fieldName === 'expirationDate' ){
      const dateVals = value.split( '/' );
      changed = ( paymentDetails.expirationMonth.value !== dateVals[0] ) || ( paymentDetails.expirationYear.value !== dateVals[1] );
    }
    else if( fieldName === 'securityCode' || fieldName === 'ccSecurityCode' ){
      changed = value.length > 0 &&
              ( ( paymentDetails.creditCardType.value === 'AmericanExpress' && value.length < 4 ) ||
                  ( paymentDetails.creditCardType.value !== 'AmericanExpress' && value.length < 3 ) ) ;
    }
  }
  return changed;
}

export const filterShippingMesssages = ( shippingInfo )=>{
  let shippingMessages = {
    shippingErrorMessages:null,
    incompatibleShippingMessges:null,
    shippingWarningMessages:null
  };
  if( has( shippingInfo, 'shippingAddress.messages.items' ) ){
    const shippingErrorMessages = shippingInfo.shippingAddress.messages.items.filter( message => message.type === 'Error' );
    if( !isEmpty( shippingErrorMessages ) ){
      shippingMessages.shippingErrorMessages = shippingErrorMessages;
    }
  }
  if( shippingInfo.shippingAddress && shippingInfo.messages ){
    if( shippingInfo.shippingStatus === 'IncompatibleShipping' ){
      shippingMessages.incompatibleShippingMessges = shippingInfo.messages.items.filter( message => message.type === 'Error' );
    }
    else {
      shippingMessages.shippingWarningMessages = shippingInfo.messages.items.filter( message => message.type === 'Info' );
    }

  }
  return shippingMessages;
}

const isPaymentErrorPresent = ( state ) => {

  return ( has( state, 'creditCardDetails.messages.items' ) && !isEmpty( state.creditCardDetails.messages.items ) ) ||
           ( has( state, 'paymentError' ) && !isEmpty( state.paymentError ) || state.creditCardMessages ) ;
}

const isShippingErrorPresent = ( state ) => {
  return state.shippingErrorMessages;
}

export const populatePaymentData = ( data, state, isSignedIn, paymentType ) => {

  let creditCardDetails = data.paymentInfo && find( data.paymentInfo.items, { paymentType:'creditCard' } );
  const payPalDetails = data.paymentInfo && find( data.paymentInfo.items, { paymentType:'paypal' } )
  const afterpayDetails = data.paymentInfo && find( data.paymentInfo.items, { paymentType:'afterpay' } )
  const giftCardDetails = data.paymentInfo && find( data.paymentInfo.items, { paymentType:'giftCard' } )
  const loyaltyCardDetails = data.paymentInfo && find( data.paymentInfo.items, { paymentType:'loyalty' } )
  const shippingInfo = !isEmpty( state.checkoutServicesData ) ? state.checkoutServicesData.shippingInfo : data.shippingInfo
  const creditCardType = creditCardDetails && get( creditCardDetails, 'paymentDetails.creditCardType.value' );
  // pickupInfo node will not be present in update payment service API
  const pickupPaymentAddress = ( has( data, 'pickupInfo.primaryContactInfo' ) && data.pickupInfo.primaryContactInfo ) || ( has( state, 'checkoutServicesData.pickupInfo.primaryContactInfo' ) && state.checkoutServicesData.pickupInfo.primaryContactInfo ) ;
  const billingAddress = creditCardDetails && creditCardDetails.contactInfo
  const isBillingAddressSameAsContactInfo = pickupPaymentAddress && creditCardDetails ? isBillingAddressSameAsConatctInfo( billingAddress, pickupPaymentAddress ) : true
  const paymenTypeValue =  afterpayDetails ? 'afterpay' : ( payPalDetails ? 'paypal' : 'creditCard' );
  if( creditCardDetails ){
    const expirationMonth = creditCardDetails.paymentDetails && creditCardDetails.paymentDetails.expirationMonth.value ;
    const expirationYear = creditCardDetails.paymentDetails && creditCardDetails.paymentDetails.expirationYear.value;
    creditCardDetails.paymentDetails.expirationDate = expirationMonth && expirationYear ?
      expirationMonth + '/' + expirationYear : null
    creditCardDetails.showPaymentSecurityCode = creditCardType !== 'Ultamate Rewards Credit Card' && creditCardDetails.nickName !== 'tempCBCC';
  }
  if( giftCardDetails && giftCardDetails.paymentDetails ){
    const giftAmount = Intl.NumberFormat( 'en-US', {
      style: 'currency',
      currency: 'USD'
    } ).format( giftCardDetails.amount );
    const cardBalance = Intl.NumberFormat( 'en-US', {
      style: 'currency',
      currency: 'USD'
    } ).format( giftCardDetails.paymentDetails.giftCardBalance.value );
    giftCardDetails.giftAmountFormatted = giftAmount;
    giftCardDetails.cardBalanceFormatted = cardBalance;
  }
  const isBillingSameAsShippingAddress = creditCardDetails ? isBillingAddressSameAsShipping( creditCardDetails.contactInfo, shippingInfo ) : true
  const paymentData = {
    creditCardDetails: creditCardDetails,
    creditCardMessages:creditCardDetails && creditCardDetails.messages ? creditCardDetails.messages.items : null,
    payPalDetails: payPalDetails,
    afterpayDetails: afterpayDetails,
    showAfterpayContent: !!afterpayDetails && state.showAfterpay,
    ...( loyaltyCardDetails && {
      loyaltyCardDetails:loyaltyCardDetails,
      selectedPoints:loyaltyCardDetails.paymentDetails.pointsApplied,
      canDisplayPoints : false,
      pointsApplied : true
    } ),
    isSignedIn:isSignedIn,
    editCreditCardData:creditCardDetails ? assignCreditCardDetails( creditCardDetails, isSignedIn ) : {},
    // Payment need not to be updated on applying Gift Card
    ...( paymentType !== 'giftCard' && {
      paymentType: paymenTypeValue,
      ...( ( creditCardType === 'Ultamate Rewards MasterCard' || creditCardType === 'Ultamate Rewards Credit Card' ) && {
        isUltamateRewardCard:true
      } ),
      creditCardType:creditCardDetails ? creditCardDetails.paymentDetails.creditCardType.value : 'DefaultCreditCard',
      shouldDisplayExpiryAndCvv: creditCardDetails && displayExpiryAndCvv( creditCardDetails.paymentDetails.creditCardType.value, creditCardDetails.paymentDetails.nickName ),
      maskCreditCardNumber: creditCardDetails ? '****' + creditCardDetails.paymentDetails.creditCardNumber.value : null,
      loadMaskCreditcard: !!creditCardDetails,
      isPaymentTypeAfterPay: paymenTypeValue === 'afterpay' && state.showAfterpay
    } ),
    remainingPaymentDue: has( data, 'remainingPaymentDue' ) ? parseFloat( data.remainingPaymentDue ) : undefined,
    isBillingAddressSameAsShipping :isBillingSameAsShippingAddress,
    billingAddress:isBillingSameAsShippingAddress ? shippingInfo && shippingInfo.shippingAddress : null,
    giftCardDetails:giftCardDetails,
    giftCardErrorMessage:giftCardDetails && giftCardDetails.messages ? find( giftCardDetails.messages.items, { type:'Error' } ) : null,
    pickupPaymentAddress:billingAddress || pickupPaymentAddress,
    isBillingAddressSameAsContactInfo:isBillingAddressSameAsContactInfo,
    showGiftCard: showGiftCard( paymenTypeValue, giftCardDetails, loyaltyCardDetails, state.isPaymentTypeAfterPay )
  }

  return paymentData;
}

export const isBillingAddressSameAsShipping = ( addressData, shippingInfo ) => {
  const postalCode = has( shippingInfo, 'shippingAddress.postalCode.value' ) && shippingInfo.shippingAddress.postalCode.value && shippingInfo.shippingAddress.postalCode.value.split( '-' );
  if( addressData && postalCode && addressData.postalCode.value === postalCode[0] &&
    addressData.firstName.value === shippingInfo.shippingAddress.firstName.value &&
    addressData.lastName.value === shippingInfo.shippingAddress.lastName.value &&
    addressData.address1.value === shippingInfo.shippingAddress.address1.value &&
    addressData.address2.value === shippingInfo.shippingAddress.address2.value &&
    addressData.state.value === shippingInfo.shippingAddress.state.value &&
    addressData.city.value === shippingInfo.shippingAddress.city.value &&
    addressData.phoneNumber.value === shippingInfo.shippingAddress.phoneNumber.value
  ){
    return true;
  }
  else {
    return false;
  }

}
const isBillingAddressSameAsConatctInfo = ( addressData, conatctInfo )=>{
  if( addressData.firstName.value === conatctInfo.firstName.value &&
    addressData.lastName.value === conatctInfo.lastName.value &&
  addressData.phoneNumber.value === conatctInfo.phoneNumber.value ){
    return true;
  }
  return false;
}
const setShowSecurityIcon = ( securityCode )=>{
  if( window.innerWidth > 1024 ){
    return true;
  }
  else if( securityCode !== '' ){
    return true;
  }
  else {
    return false;
  }
}
const paymentView = ( paymentView ) => {
  return (
    {
      isPaymentCreditCardPayPalView: paymentView === 'PaymentCreditCardPayPal',
      isPaymentDefaultCreditCardView: paymentView === 'PaymentDefaultCreditCard',
      isProfileCreditCardListView: paymentView === 'ProfileCreditCardList'
    }
  )
}

export const updatePickupSmsInfo = ( action, state ) => {
  // pickupSmsInfo is the info present in local_storage
  const pickupSmsInfo =  retrievePickupSmsInfo();
  // check if local_storage has the optInStatus and mobileNumber data
  if( !pickupSmsInfo ){
    // if local_storage doesn't have the data, set the pickupSmsOptInStatus and pickupMobileNumber from the service response if present in service response, else set it from the state.
    return {
      pickupSmsOptInStatus: action.data.result?.smsCommunicationInfo?.transactionalContactInfo?.optInStatus ?? state.pickupSmsOptInStatus,
      pickupMobileNumber: action.data.result?.smsCommunicationInfo?.transactionalContactInfo?.phoneNumber ?? state.pickupMobileNumber
    };
  }
  else {
    // if local_storage has the data set the pickupSmsOptInStatus and pickupMobileNumber from the local_storage.
    return {
      pickupSmsOptInStatus: pickupSmsInfo?.optInStatus,
      pickupMobileNumber: pickupSmsInfo?.mobileNumber
    };
  }
}

export const populatePickupSmsInfo = ( data, state, type ) => {
  // pickupSmsInfo is the info present in local_storage
  const pickupSmsInfo =  retrievePickupSmsInfo();
  // next two lines needed because if we are updating the mobileNumber/optin from ui, we will have to check optin/mobileNumber value from either local_storage or from state
  let mobileNumber = pickupSmsInfo?.mobileNumber ?? state.pickupMobileNumber; // toCheck if the mobileNumber is already in the local_storage, if yes use it, else use from state.pickupMobileNumber
  let optInStatus = pickupSmsInfo?.optInStatus ?? state.pickupSmsOptInStatus; // to check if optInStatus is already in local_storage, if yes use it, else use from state.pickupSmsOptInStatus
  // check for the method type to identify if user is trying to edit mobile number or optin and then, modify the mobileNumber or optInStatus
  if( type === 'updateMobileNumber' ){
    // set mobileNumber with users input value
    mobileNumber = data.pickupMobileNumber;
  }
  else {
    // set the optInStatus with users input value
    optInStatus = !data.pickupSmsOptInStatus;
  }
  // use the mobileNumber and optInStatus and persist them in the local_storage
  persistPickupSmsInfo( { optInStatus, mobileNumber } );
  // after persisting return to set them in the state.
  return {
    pickupSmsOptInStatus: optInStatus,
    pickupMobileNumber: mobileNumber
  };
}

// showGiftCard method will show/hide the giftcard in payment section according to payment types
export const showGiftCard = ( paymentType, giftCardDetails, loyaltyCardDetails, isPaymentTypeAfterPay ) => {
  let showGiftCard = true;

  // if paymentType is creditcard or paypal, show the giftcard section
  // if paymentType is afterpay without giftCardDetails or loyaltyCardDetails, hide the giftcard section
  if( paymentType === 'afterpay' || isPaymentTypeAfterPay ){
    showGiftCard = false;
    // if paymentType is afterpay with giftCardDetails or loyaltyCardDetails, show the giftcard section with error message in afterpay payment tab
    if( !isEmpty( giftCardDetails ) || !isEmpty( loyaltyCardDetails ) ){
      showGiftCard = true;
    }
  }

  return showGiftCard;
}

export const getCheckoutPageState = state => state.checkoutPage;
