import React from 'react';


import {
  TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY,
  TOGGLE_INPUTFIELD_DISPLAY
} from 'ulta-fed-core/dist/js/events/forms/forms.events';
import {
  ALERT_WINDOW_RESIZE
} from 'ulta-fed-core/dist/js/events/global/global.events';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import _ from 'lodash';
import {
  actionTypes as ReduxActionType
} from 'redux-form';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { initializeIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import CONFIG from '../../../modules/ccr/ccr.config';
import configureStore from '../../../modules/ccr/ccr.store';
import {
  SET_PAYMENT_FORM_TYPE,
  RESET_CHECKOUT_DATA_AVAILABLE,
  SET_EDIT_ADDRESS_DATA,
  UPDATE_PAYMENT_STATUS,
  SET_EDIT_CREDITCARD_DATA,
  RESET_CART_MERGED,
  SET_CREDITCARD_PAYMENT_TYPE,
  SET_TEMP_PAYMENT_CCV_NUMBER,
  RESET_CARTPAGE_NAVIGATION,
  RESET_ORDER_STATUS,
  CHECKOUT_PANEL_COLLAPSE,
  UPDATE_STATE_DROPDOWN_VALUE,
  PAYPAL_RESPONSE,
  SET_SHOW_PAYPAL_BUTTON,
  SET_IS_COUPON_BUTTON_CLICKED,
  SET_SHOW_DEFAULT_SHIPPING_METHOD,
  SET_SHIPPING_ADDRESS_VIEW,
  SET_PAYMENT_INFORMATION_VIEW,
  SET_DISPLAY_DAV_POPUP,
  ADD_EDIT_PAYMENT_METHOD,
  TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY,
  TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY,
  BILLING_ADDRESS_SAME_AS_SHIPPING,
  BILLING_ADDRESS_SAME_AS_CONTACT_INFO,
  TOGGLE_OPTIN_FOR_SMS,
  UPDATE_MOBILE_NUMBER
} from '../../../events/checkout_page/checkout_page.events';
import reducer, {
  initialState,
  isPaymentFieldUpdated,
  setPaymentInformationView,
  messageSort,
  isBillingAddressSameAsShipping,
  updatePickupSmsInfo,
  populatePickupSmsInfo,
  showGiftCard,
  populatePaymentData
} from './checkout_page.model';
import PaymentFormMessages from '../../../views/PaymentForm/PaymentForm.messages';
import {
  persistPickupSmsInfo,
  retrievePickupSmsInfo
} from '../../../utils/local_storage/local_storage';

jest.mock( '../../../utils/local_storage/local_storage', () => {
  return {
    persistPickupSmsInfo: jest.fn(),
    retrievePickupSmsInfo:jest.fn()
  }
} );

describe( 'CheckoutPage reducer', () =>{

  registerServiceName( 'initCart' );
  let store = configureStore( {}, CONFIG );
  initializeIntl();

  registerServiceName( 'readCart' );
  registerServiceName( 'getQualifiedShipMethod' );
  registerServiceName( 'submitOrderService' );
  registerServiceName( 'estimatedDeliveryDate' );
  registerServiceName( 'payPal' );
  registerServiceName( 'submitCreditCard' );
  registerServiceName( 'shippingUpdate' );
  registerServiceName( 'applycoupon' );
  registerServiceName( 'login' );
  registerServiceName( 'removecoupon' );
  registerServiceName( 'paypalToken' );
  registerServiceName( 'applyExpressPayPalPayment' );
  registerServiceName( 'userRewards' );
  registerServiceName( 'redeemPoints' );
  registerServiceName( 'paymentServiceResponse' );
  registerServiceName( 'removePaymentService' );
  registerServiceName( 'profileCreditCards' );
  registerServiceName( 'paymentsCCKey' );
  registerServiceName( 'pickupContactInfoUpdate' );
  registerServiceName( 'applyPayPalPayment' );
  registerServiceName( 'afterpay' );
  registerServiceName( 'switches' );

  it( 'should have the proper default state', () =>{

    let expectedState = {
      stateDropdownValues: {
        billing: '',
        shipping: ''
      },
      checkoutFormAddressOpen: {
        paymentAddressForm: false,
        shippingAddressForm: false
      },
      checkoutFormAddress2Open: {
        paymentAddressForm: false,
        shippingAddressForm: false
      },
      paymentServiceResponse: {},
      checkoutServicesData: {},
      paypalResponse: {},
      callPaypalService: true,
      billingAddress: null,
      paypal: false,
      giftCardDetails: {},
      loyaltyCardDetails: {},
      creditCardDetails: null,
      payPalDetails:null,
      giftCardApplying: false,
      showPaypalButton: false,
      editAddressData: {},
      editCreditCardData: {},
      submitOrderService: {},
      isCouponButtonClicked: false,
      isShippingError: false,
      shippingSuccess: false,
      paymentSuccess: false,
      paymentError: undefined,
      joinNowRewardsError: [],
      displayDavPopUp: false,
      paymentType: 'creditCard',
      previousPaymentType: null,
      cartMerged: false,
      checkoutFormConfig: {
        showHideCheckoutToggleData: {
          securityCode: false,
          ccSecurityCode: false
        }
      },
      remainingPaymentDue: undefined,
      navigateToCartPage: false,
      giftCardErrorMessage: null,
      checkoutError: [],
      orderSuccess: false,
      orderId: undefined,
      isCheckoutDataAvailable: false,
      submitOrderSpinner: false,
      tempPaymentCCVNumber: null,
      isErrorBeforeSubmitOrder: undefined,
      payPalClientToken: undefined,
      profileCreditCardListCount: 0,
      showSecurityIcon: true,
      anchorAfterSubmitServiceCall: undefined,
      displayCheckoutLevelErrorMessage: false,
      activeField:'',
      isGiftCardRemoved: false,
      isRewardPointsRemoved: false,
      changeShippingAddress:false,
      showDefaultShippingMethod:true,
      shippingAddressView:'addEditShippingAddressView',
      shippingErrorMessages:null,
      shippingWarningMessages:null,
      incompatibleShippingMessges:null,
      isPaymentAddEditMode:false,
      shouldDisplayExpiryAndCvv:false,
      isBillingAddressSameAsShipping: true,
      isBillingAddressSameAsContactInfo: true,
      pickupPaymentAddress:null,
      creditCardType:'DefaultCreditCard',
      paymentsCCKey: undefined,
      checkoutPanelCollapse: {
        coupons: false,
        giftCard: false,
        redeemPanel: false
      },
      redeemPointLevels: {},
      redeemPointsMessages: {},
      selectedPoints: null,
      hasMessages: false,
      canDisplayPoints: false,
      pointsApplied: false,
      isPaymentCreditCardPayPalView: true,
      isPaymentDefaultCreditCardView: false,
      isProfileCreditCardListView:false,
      isValidCardType: true,
      showUltamateRewardsCreditCard: true,
      isUltamateRewardCard:false,
      reloadCheckoutPage:false,
      pickupSmsOptInStatus: false,
      pickupMobileNumber: undefined,
      showGiftCard: true,
      isPaymentTypeAfterPay: false,
      afterpayDetails: null,
      showAfterpay: false
    };
    expect( initialState ).toEqual( expectedState );
  } );

  it( 'should be a function', () =>{
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', () => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  describe( 'SET_EDIT_ADDRESS_DATA', ( ) => {

    let data = {
      refId : 'checkoutaddress',
      firstName : 'joe',
      lastName:'joe',
      phoneNumber: '1234567876',
      isDefault: true,
      isPaypal: true,
      isPrimaryAddress: true,
      isPaypalFlag: true,
      email: 'test@ulta.com',
      address1: 'address',
      address2: '',
      city: 'chicago',
      state: 'IL',
      postalCode: 12345
    }
    let actionCreator = {
      type: SET_EDIT_ADDRESS_DATA,
      data
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        editAddressData: {
          isDefault: true,
          isPaypal: true,
          refId: 'checkoutaddress',
          firstName: {
            value: 'joe'
          },
          lastName:  {
            value:'joe'
          },
          phoneNumber:{
            value:'1234567876'
          },
          emailaddress: {
            value:'test@ulta.com'
          },
          address1: {
            value:'address'
          },
          address2: {
            value:''
          },
          city: {
            value:'chicago'
          },
          state: {
            value:'IL'
          },
          postalCode: {
            value:12345
          }
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should return the initial state', () =>{
      expect( reducer( undefined, {} ) ).toEqual( initialState );
    } );

  } );
  describe( 'INIT_CART_CASES', () => {
    it( 'reset cart merged', () => {
      let actionCreator = {
        type: RESET_CART_MERGED
      }
      let excepted = {
        cartMerged: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'reseting the cart page Navigation', () => {
      let actionCreator = {
        type: RESET_CARTPAGE_NAVIGATION
      }

      let excepted = {
        navigateToCartPage: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'init cart is requested', () => {
      let actionCreator = {
        type: getServiceType( 'initCart', 'requested' ),
        data:{
          hideSpinner:false
        }
      }

      let excepted = {
        isCheckoutDataAvailable: false,
        isPaymentTypeAfterPay: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );

    } );

    it( 'should set the checkoutServicesData', () => {

      const action = {
        data:{
          isSignedIn:true,
          result: {
            cartSummary: {
              shippingCost: 'TBD',
              subTotal: 5.99,
              itemCount: 1,
              orderGiftWrapAmt: 0,
              additionalDiscount: null,
              couponDiscount: 0,
              estimatedTax: 'TBD',
              giftCard: null,
              rewardPointsDiscount: null,
              estimatedTotal: 5.99,
              rewardPointsEarned: null,
              currencyCode: 'USD'
            },
            shippingInfo:{
              shippingAddress:null,
              messages:null
            },
            paymentInfo: {
              items: [{
                paymentType: 'creditCard',
                messages:null,
                nickName:'VISA - 9999',
                paymentDetails: {
                  expirationDate: '09/2021',
                  expirationMonth:  { messages: null, value: '09' },
                  expirationYear:  { messages: null, value: 2021 },
                  creditCardNumber:  { messages: null, value: '1111' },
                  currencyCode: 'USD',
                  creditCardType:  { messages: null, value: 'Visa' }
                },
                amount: 46.18,
                currencyCode: 'USD',
                contactInfo: {
                  firstName: 'Pushpendra',
                  lastName: 'Kabdaula',
                  phoneNumber: '123-456-7890',
                  email: 'pkabdaula@ulta.com',
                  address1: '1000 remngton blvd',
                  address2: 'Ste 200',
                  city: 'Boolingbrook',
                  state: 'IL',
                  postalCode: '07105',
                  country: 'US'
                },
                showPaymentSecurityCode: true
              }],
              remainingPaymentDue :0
            },
            smsCommunicationInfo : {
              promotionalContactInfo : {
                optInStatus : false,
                phoneNumber : '(222) 111 1111'
              },
              transactionalContactInfo : {
                optInStatus : true,
                phoneNumber : '(222) 222 2222'
              }
            }
          }
        }
      }
      let actionCreator = {
        type: getServiceType( 'initCart', 'success' ),
        data: action.data
      }

      let expectedOutput =  {
        isSignedIn:true,
        isCheckoutDataAvailable: true,
        billingAddress: null,
        checkoutServicesData: action.data.result,
        orderId:undefined,
        shippingErrorMessages: null,
        incompatibleShippingMessges: null,
        shippingWarningMessages: null,
        editAddressData:null,
        shippingAddressView:undefined,
        selectedShippingMethod:null,
        isPaymentAddEditMode :false,
        creditCardDetails: {
          paymentType: 'creditCard',
          showPaymentSecurityCode: true,
          messages:null,
          nickName:'VISA - 9999',
          paymentDetails: {
            expirationDate: '09/2021',
            expirationMonth:  { messages: null, value: '09' },
            expirationYear:  { messages: null, value: 2021 },
            creditCardNumber:  { messages: null, value: '1111' },
            currencyCode: 'USD',
            creditCardType:  { messages: null, value: 'Visa' }
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        },
        creditCardMessages:null,
        creditCardType:'Visa',
        editCreditCardData: {
          contactInfo:{
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city : 'Boolingbrook',
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            postalCode: '07105',
            state: 'IL'
          },
          creditCardNumber:{
            messages: null,
            value: '1111'
          },
          creditCardType:{
            messages: null,
            value:'Visa'
          },
          'expirationMonth': {
            messages: null,
            value: '09'
          },
          expirationYear:{
            messages: null,
            value: 2021
          },
          nickName: 'VISA - 9999'
        },
        loadMaskCreditcard:true,
        maskCreditCardNumber: '****1111',
        payPalDetails:undefined,
        giftCardDetails: undefined,
        paymentType: 'creditCard',
        remainingPaymentDue: undefined,
        shouldDisplayExpiryAndCvv: true,
        isBillingAddressSameAsShipping: false,
        isBillingAddressSameAsContactInfo: true,
        pickupPaymentAddress:{
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          email: 'pkabdaula@ulta.com',
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city: 'Boolingbrook',
          state: 'IL',
          postalCode: '07105',
          country: 'US'
        },
        isPaymentDefaultCreditCardView: true,
        isPaymentCreditCardPayPalView: false,
        isProfileCreditCardListView:false,
        showUltamateRewardsCreditCard: true,
        giftCardErrorMessage: null,
        pickupSmsOptInStatus: true,
        pickupMobileNumber: '(222) 222 2222',
        showGiftCard: true,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should check if setPaymentInformationView returns expected ouput ', () =>{
      const paymentInfo =  {
        items: [{
          paymentType: 'creditCard',
          messages:null,
          nickName:'VISA - 9999',
          paymentDetails: {
            expirationDate: '09/2021',
            expirationMonth:  { messages: null, value: '09' },
            expirationYear:  { messages: null, value: 2021 },
            creditCardNumber:  { messages: null, value: '1111' },
            currencyCode: 'USD',
            creditCardType:  { messages: null, value: 'Visa' }
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          },
          showPaymentSecurityCode: true
        }],
        remainingPaymentDue :0
      }
      const isSignedIn = true;
      const creditCardDetails = {
        paymentType: 'creditCard',
        showPaymentSecurityCode: true,
        messages:null,
        nickName:'VISA - 9999',
        paymentDetails: {
          expirationDate: '09/2021',
          expirationMonth:  { messages: null, value: '09' },
          expirationYear:  { messages: null, value: 2021 },
          creditCardNumber:  { messages: null, value: '1111' },
          currencyCode: 'USD',
          creditCardType:  { messages: null, value: 'Visa' }
        },
        amount: 46.18,
        currencyCode: 'USD',
        contactInfo: {
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          email: 'pkabdaula@ulta.com',
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city: 'Boolingbrook',
          state: 'IL',
          postalCode: '07105',
          country: 'US'
        }
      };
      const expectedOutput = {
        'isPaymentAddEditMode': false,
        'isPaymentCreditCardPayPalView': false,
        'isPaymentDefaultCreditCardView': true,
        'isProfileCreditCardListView': false,
        'showUltamateRewardsCreditCard': true
      };
      expect( setPaymentInformationView( { paymentInfo, isSignedIn, creditCardDetails } ) ).toEqual( expectedOutput );
    } );

    it( 'should check if setPaymentInformationView returns isPaymentCreditCardPayPalView as true when paymentInfo is null', () =>{
      const paymentInfo =  null;
      const isSignedIn = true;
      const creditCardDetails = {
        paymentType: 'creditCard',
        showPaymentSecurityCode: true,
        messages:null,
        nickName:'VISA - 9999',
        paymentDetails: {
          expirationDate: '09/2021',
          expirationMonth:  { messages: null, value: '09' },
          expirationYear:  { messages: null, value: 2021 },
          creditCardNumber:  { messages: null, value: '1111' },
          currencyCode: 'USD',
          creditCardType:  { messages: null, value: 'Visa' }
        },
        amount: 46.18,
        currencyCode: 'USD',
        contactInfo: {
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          email: 'pkabdaula@ulta.com',
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city: 'Boolingbrook',
          state: 'IL',
          postalCode: '07105',
          country: 'US'
        }
      };
      const expectedOutput = {
        'isPaymentAddEditMode': false,
        'isPaymentCreditCardPayPalView': true,
        'isPaymentDefaultCreditCardView': false,
        'isProfileCreditCardListView': false,
        'showUltamateRewardsCreditCard': true
      };
      expect( setPaymentInformationView( { paymentInfo, isSignedIn, creditCardDetails } ) ).toEqual( expectedOutput );
    } );

    it( 'should check if setPaymentInformationView returns isPaymentCreditCardPayPalView as true when user have no saved credit cards', () =>{
      const paymentInfo = {
        items: [{
          paymentType: 'paypal',
          messages:null
        }]
      };
      const isSignedIn = true;
      const profileCreditCardListCount = 0;
      const expectedOutput = {
        'isPaymentAddEditMode': false,
        'isPaymentCreditCardPayPalView': true,
        'isPaymentDefaultCreditCardView': false,
        'isProfileCreditCardListView': false,
        'showUltamateRewardsCreditCard': false
      };
      expect( setPaymentInformationView( paymentInfo, isSignedIn, null, profileCreditCardListCount ) ).toEqual( expectedOutput );
    } );

    it( 'should check if setPaymentInformationView returns isPaymentDefaultCreditCardView as true when user have saved credit cards', () =>{
      const paymentInfo = {
        items: [{
          paymentType: 'paypal',
          messages:null
        }]
      };
      const isSignedIn = true;
      const profileCreditCardListCount = 1;
      const expectedOutput = {
        'isPaymentAddEditMode': false,
        'isPaymentCreditCardPayPalView': false,
        'isPaymentDefaultCreditCardView': true,
        'isProfileCreditCardListView': false,
        'showUltamateRewardsCreditCard': false
      };
      expect( setPaymentInformationView( { paymentInfo, isSignedIn, profileCreditCardListCount } ) ).toEqual( expectedOutput );
    } );

    it( 'should set the checkoutServicesData when shippingInfo is null', () => {

      let action = {
        data :{
          isSignedIn:true,
          result:{
            cartSummary: {
              shippingCost: 'TBD',
              subTotal: 5.99,
              itemCount: 1,
              orderGiftWrapAmt: 0,
              additionalDiscount: null,
              couponDiscount: 0,
              estimatedTax: 'TBD',
              giftCard: null,
              rewardPointsDiscount: null,
              estimatedTotal: 5.99,
              rewardPointsEarned: null,
              currencyCode: 'USD'
            },
            shippingInfo: {
              shippingAddress: null,
              messages: null
            },
            paymentInfo: {
              items: [{
                paymentType: 'creditCard',
                messages:null,
                nickName:'VISA - 9999',
                paymentDetails: {
                  expirationDate: '09/2021',
                  expirationMonth:  { messages: null, value: '09' },
                  expirationYear:  { messages: null, value: 2021 },
                  creditCardNumber:  { messages: null, value: '1111' },
                  currencyCode: 'USD',
                  creditCardType:  { messages: null, value: 'Visa' }
                },
                amount: 46.18,
                currencyCode: 'USD',
                contactInfo: {
                  firstName: 'Pushpendra',
                  lastName: 'Kabdaula',
                  phoneNumber: '123-456-7890',
                  email: 'pkabdaula@ulta.com',
                  address1: '1000 remngton blvd',
                  address2: 'Ste 200',
                  city: 'Boolingbrook',
                  state: 'IL',
                  postalCode: '07105',
                  country: 'US'
                },
                showPaymentSecurityCode: true
              }],
              remainingPaymentDue :0
            },
            smsCommunicationInfo : {}
          }
        }
      }

      const mockState = {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: '(222) 222 2222'
      }

      let actionCreator = {
        type: getServiceType( 'initCart', 'success' ),
        data: action.data
      }

      let expectedOutput =  {
        isSignedIn:true,
        billingAddress: null,
        isCheckoutDataAvailable: true,
        checkoutServicesData:action.data.result,
        orderId:action.data.result.id,
        editAddressData:null,
        shippingAddressView:undefined,
        selectedShippingMethod:null,
        shippingErrorMessages: null,
        isPaymentAddEditMode :false,
        isPaymentDefaultCreditCardView: true,
        incompatibleShippingMessges: null,
        isPaymentCreditCardPayPalView: false,
        isProfileCreditCardListView:false,
        giftCardDetails: undefined,
        loadMaskCreditcard:true,
        maskCreditCardNumber: '****1111',
        shippingWarningMessages: null,
        creditCardDetails: {
          paymentType: 'creditCard',
          showPaymentSecurityCode: true,
          messages:null,
          nickName:'VISA - 9999',
          paymentDetails: {
            expirationDate: '09/2021',
            expirationMonth:  { messages: null, value: '09' },
            expirationYear:  { messages: null, value: 2021 },
            creditCardNumber:  { messages: null, value: '1111' },
            currencyCode: 'USD',
            creditCardType:  { messages: null, value: 'Visa' }
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        },
        paymentType: 'creditCard',
        creditCardType:'Visa',
        creditCardMessages:null,
        shouldDisplayExpiryAndCvv: true,
        remainingPaymentDue: undefined,
        isBillingAddressSameAsShipping: false,
        isBillingAddressSameAsContactInfo: true,
        pickupPaymentAddress:{
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city : 'Boolingbrook',
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          postalCode: '07105',
          state: 'IL',
          country: 'US',
          email: 'pkabdaula@ulta.com'
        },
        payPalDetails:undefined,
        editCreditCardData: {
          contactInfo:{
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city : 'Boolingbrook',
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            postalCode: '07105',
            state: 'IL'
          },
          creditCardNumber:{
            messages: null,
            value: '1111'
          },
          creditCardType:{
            messages: null,
            value:'Visa'
          },
          'expirationMonth': {
            messages: null,
            value: '09'
          },
          expirationYear:{
            messages: null,
            value: 2021
          },
          nickName: 'VISA - 9999'
        },
        showUltamateRewardsCreditCard: true,
        giftCardErrorMessage: null,
        pickupSmsOptInStatus: true,
        pickupMobileNumber: '(222) 222 2222',
        showGiftCard: true,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      }
      expect( reducer( mockState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set the checkoutServicesData when shippingInfo is not null', () => {

      let action = {
        data :{
          isSignedIn:true,
          result:{
            cartSummary: {
              shippingCost: 'TBD',
              subTotal: 5.99,
              itemCount: 1,
              orderGiftWrapAmt: 0,
              additionalDiscount: null,
              couponDiscount: 0,
              estimatedTax: 'TBD',
              giftCard: null,
              rewardPointsDiscount: null,
              estimatedTotal: 5.99,
              rewardPointsEarned: null,
              currencyCode: 'USD'
            },
            shippingInfo: {
              shippingAddress: {
                lastName: {
                  value: 'User'
                },
                country: {
                  value: 'US'
                },
                city: {
                  value: 'Chicago'
                },
                address1: {
                  value: 'Street 20'
                },
                postalCode: {
                  value: '60603'
                },
                firstName: {
                  value: 'Test '
                },
                phoneNumber: {
                  value: '123-455-6677'
                },
                state: {
                  value: 'IL'
                },
                email: {
                  value: 'test@ulta.com'
                }
              },
              messages: null
            },
            paymentInfo: {
              items: [{
                paymentType: 'creditCard',
                messages:null,
                nickName:'VISA - 9999',
                paymentDetails: {
                  expirationDate: '09/2021',
                  expirationMonth:  { messages: null, value: '09' },
                  expirationYear:  { messages: null, value: 2021 },
                  creditCardNumber:  { messages: null, value: '1111' },
                  currencyCode: 'USD',
                  creditCardType:  { messages: null, value: 'Visa' }
                },
                amount: 46.18,
                currencyCode: 'USD',
                contactInfo: {
                  firstName: 'Pushpendra',
                  lastName: 'Kabdaula',
                  phoneNumber: '123-456-7890',
                  email: 'pkabdaula@ulta.com',
                  address1: '1000 remngton blvd',
                  address2: 'Ste 200',
                  city: 'Boolingbrook',
                  state: 'IL',
                  postalCode: '07105',
                  country: 'US'
                },
                showPaymentSecurityCode: true
              }],
              remainingPaymentDue :0
            }
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'initCart', 'success' ),
        data: action.data
      }

      let expectedOutput =  {
        isSignedIn:true,
        billingAddress: null,
        isCheckoutDataAvailable: true,
        checkoutServicesData:action.data.result,
        orderId:action.data.result.id,
        editAddressData:{
          lastName: {
            value: 'User'
          },
          country: {
            value: 'US'
          },
          city: {
            value: 'Chicago'
          },
          address1: {
            value: 'Street 20'
          },
          postalCode: {
            value: '60603'
          },
          firstName: {
            value: 'Test '
          },
          phoneNumber: {
            value: '123-455-6677'
          },
          state: {
            value: 'IL'
          },
          email: {
            value: 'test@ulta.com'
          }

        },
        shippingAddressView:undefined,
        selectedShippingMethod:null,
        shippingErrorMessages: null,
        isPaymentAddEditMode :false,
        isPaymentDefaultCreditCardView: true,
        incompatibleShippingMessges: null,
        isPaymentCreditCardPayPalView: false,
        isProfileCreditCardListView:false,
        giftCardDetails: undefined,
        loadMaskCreditcard:true,
        maskCreditCardNumber: '****1111',
        shippingWarningMessages: null,
        creditCardDetails: {
          paymentType: 'creditCard',
          showPaymentSecurityCode: true,
          messages:null,
          nickName:'VISA - 9999',
          paymentDetails: {
            expirationDate: '09/2021',
            expirationMonth:  { messages: null, value: '09' },
            expirationYear:  { messages: null, value: 2021 },
            creditCardNumber:  { messages: null, value: '1111' },
            currencyCode: 'USD',
            creditCardType:  { messages: null, value: 'Visa' }
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        },
        paymentType: 'creditCard',
        creditCardType:'Visa',
        creditCardMessages:null,
        shouldDisplayExpiryAndCvv: true,
        remainingPaymentDue: undefined,
        isBillingAddressSameAsShipping: false,
        isBillingAddressSameAsContactInfo: true,
        pickupPaymentAddress:{
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city : 'Boolingbrook',
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          postalCode: '07105',
          state: 'IL',
          country: 'US',
          email: 'pkabdaula@ulta.com'
        },
        payPalDetails:undefined,
        editCreditCardData: {
          contactInfo:{
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city : 'Boolingbrook',
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            postalCode: '07105',
            state: 'IL'
          },
          creditCardNumber:{
            messages: null,
            value: '1111'
          },
          creditCardType:{
            messages: null,
            value:'Visa'
          },
          'expirationMonth': {
            messages: null,
            value: '09'
          },
          expirationYear:{
            messages: null,
            value: 2021
          },
          nickName: 'VISA - 9999'
        },
        showUltamateRewardsCreditCard: true,
        giftCardErrorMessage: null,
        showGiftCard: true,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should display the updated billing address for a guest user if delivery type is pick up - isBillingAddressSameAsShipping should be set to false', () => {
      let action = {
        data :{
          isSignedIn:false,
          result:{
            cartSummary: {
              shippingCost: 'TBD',
              subTotal: 5.99,
              itemCount: 1,
              orderGiftWrapAmt: 0,
              additionalDiscount: null,
              couponDiscount: 0,
              estimatedTax: 'TBD',
              giftCard: null,
              rewardPointsDiscount: null,
              estimatedTotal: 5.99,
              rewardPointsEarned: null,
              currencyCode: 'USD'
            },
            shippingInfo: null,
            paymentInfo: {
              items: [{
                paymentType: 'creditCard',
                messages:null,
                nickName:'VISA - 9999',
                paymentDetails: {
                  expirationDate: '09/2021',
                  expirationMonth:  { messages: null, value: '09' },
                  expirationYear:  { messages: null, value: 2021 },
                  creditCardNumber:  { messages: null, value: '1111' },
                  currencyCode: 'USD',
                  creditCardType:  { messages: null, value: 'Visa' }
                },
                amount: 46.18,
                currencyCode: 'USD',
                contactInfo: {
                  firstName: 'Pushpendra',
                  lastName: 'Kabdaula',
                  phoneNumber: '123-456-7890',
                  email: 'pkabdaula@ulta.com',
                  address1: '1000 remngton blvd',
                  address2: 'Ste 200',
                  city: 'Boolingbrook',
                  state: 'IL',
                  postalCode: '07105',
                  country: 'US'
                },
                showPaymentSecurityCode: true
              }],
              remainingPaymentDue :0
            },
            pickupInfo:{
              storeInfo:{}
            }
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'initCart', 'success' ),
        data: action.data
      }

      let expectedOutput =  {
        isSignedIn:false,
        billingAddress: null,
        isCheckoutDataAvailable: true,
        checkoutServicesData:action.data.result,
        orderId:action.data.result.id,
        editAddressData:null,
        selectedShippingMethod:null,
        shippingAddressView: null,
        isPaymentAddEditMode :false,
        isPaymentDefaultCreditCardView: false,
        isPaymentCreditCardPayPalView: true,
        isProfileCreditCardListView:false,
        giftCardDetails: undefined,
        loadMaskCreditcard:true,
        maskCreditCardNumber: '****1111',
        creditCardDetails: {
          paymentType: 'creditCard',
          showPaymentSecurityCode: true,
          messages:null,
          nickName:'VISA - 9999',
          paymentDetails: {
            expirationDate: '09/2021',
            expirationMonth:  { messages: null, value: '09' },
            expirationYear:  { messages: null, value: 2021 },
            creditCardNumber:  { messages: null, value: '1111' },
            currencyCode: 'USD',
            creditCardType:  { messages: null, value: 'Visa' }
          },
          amount: 46.18,
          currencyCode: 'USD',
          contactInfo: {
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            email: 'pkabdaula@ulta.com',
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            state: 'IL',
            postalCode: '07105',
            country: 'US'
          }
        },
        paymentType: 'creditCard',
        creditCardType:'Visa',
        creditCardMessages:null,
        shouldDisplayExpiryAndCvv: true,
        remainingPaymentDue: undefined,
        isBillingAddressSameAsShipping: false,
        isBillingAddressSameAsContactInfo: true,
        pickupPaymentAddress:{
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city : 'Boolingbrook',
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          postalCode: '07105',
          state: 'IL',
          country: 'US',
          email: 'pkabdaula@ulta.com'
        },
        payPalDetails:undefined,
        editCreditCardData: {
          contactInfo:{
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city : 'Boolingbrook',
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            postalCode: '07105',
            state: 'IL'
          },
          creditCardNumber:{
            messages: null,
            value: '1111'
          },
          creditCardType:{
            messages: null,
            value:'Visa'
          },
          'expirationMonth': {
            messages: null,
            value: '09'
          },
          expirationYear:{
            messages: null,
            value: 2021
          },
          nickName: 'VISA - 9999'
        },
        showUltamateRewardsCreditCard: true,
        giftCardErrorMessage: null,
        showGiftCard: true,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set the checkoutServicesData when shippingInfo is null', () => {

      let res = {
        response:{
          cartSummary: {
            shippingCost: 'TBD',
            subTotal: 5.99,
            itemCount: 1,
            orderGiftWrapAmt: 0,
            additionalDiscount: null,
            couponDiscount: 0,
            estimatedTax: 'TBD',
            giftCard: null,
            rewardPointsDiscount: null,
            estimatedTotal: 5.99,
            rewardPointsEarned: null,
            currencyCode: 'USD'
          },
          shippingInfo: null,
          paymentDetails: null
        },
        isShippingMethodUpdated:false
      }

      let actionCreator = {
        type: getServiceType( 'shippingUpdate', 'success' ),
        data: res
      }

      let expectedOutput = {
        shippingSuccess: true,
        checkoutServicesData: res.response,
        selectedShippingMethod:null,
        displayDavPopUp:null,
        editAddressData: null,
        shippingAddressView:null
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Should not update editAddressData if it is shipping method update flow -isShippingMethodUpdated:true', () =>{
      let data = {
        response:{
          shippingInfo:{
            shippingAddress:{
              firstName:{
                value:null
              },
              message:'please enter a valid shipping address'
            },
            shipMethodInfo:{
              items:[
                {
                  'cost': '$5.95',
                  'displayName': 'Standard',
                  'shipMethod': 'ups_ground',
                  'isSelected': false,
                  'estimatedDelivery': null
                },
                {
                  'cost': '$16.95',
                  'displayName': 'Premium',
                  'shipMethod': 'ups_next_day',
                  'isSelected': true,
                  'estimatedDelivery': null
                }
              ]
            }
          }
        },
        isShippingMethodUpdated:true
      }
      let initialState = {
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:null,
            shipMethodInfo:null
          }
        },
        editAddressData:null
      }

      let actionCreator = {
        type: getServiceType( 'shippingUpdate', 'success' ),
        data: data
      }
      let expectedOutput = {
        'checkoutServicesData': {
          'cartSummary': undefined,
          'paymentDetails': undefined,
          'shippingInfo': {
            'shipMethodInfo': {
              'items': [{
                'cost': '$5.95',
                'displayName': 'Standard',
                'estimatedDelivery': null,
                'isSelected': false,
                'shipMethod': 'ups_ground'
              }, {
                'cost': '$16.95',
                'displayName': 'Premium',
                'estimatedDelivery': null,
                'isSelected': true,
                'shipMethod': 'ups_next_day'
              }]
            },
            'shippingAddress':{
              'firstName':{
                'value':null
              },
              'message':'please enter a valid shipping address'
            }
          }
        },
        'displayDavPopUp': false,
        'editAddressData': null,
        'incompatibleShippingMessges': null,
        'selectedShippingMethod': {
          'cost': '$16.95',
          'displayName': 'Premium',
          'estimatedDelivery': null,
          'isSelected': true,
          'shipMethod': 'ups_next_day'
        },
        'shippingAddressView': undefined,
        'shippingErrorMessages': null,
        'shippingSuccess': true,
        'shippingWarningMessages': null
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'CHECKOUT_PANEL_COLLAPSE', ( ) => {
    let iniitalState = {
      checkoutPanelCollapse: {
        coupons: false,
        giftCard: false,
        redeemPanel: false
      }
    }

    let panelID = 'redeemPanel';
    let actionCreator = {
      type: CHECKOUT_PANEL_COLLAPSE,
      panelID
    }

    it( 'should update the state of checkoutPanelCollapse', () => {

      let expectedOutput = {
        checkoutPanelCollapse: {
          coupons: false,
          giftCard: false,
          redeemPanel: true
        }
      }

      expect( reducer( iniitalState, actionCreator ) ).toEqual( expectedOutput );

    } )


  } );

  describe( 'TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY', () =>{

    it( 'should handle the event and set the state', () =>{
      let formName = 'paymentAddressForm';
      let actionCreator = {
        type: TOGGLE_CHECKOUT_FORMS_ADDRESS_FIELD_DISPLAY,
        formName
      }
      let state = {
        checkoutFormAddressOpen: {
          paymentAddressForm: false,
          shippingAddressForm: false
        }
      }
      let expectedOutput = {
        checkoutFormAddressOpen: {
          paymentAddressForm: true,
          shippingAddressForm: false
        }
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );
  } );

  describe( 'TOGGLE_ADDRESS2', () => {
    it( 'Checking the toggle for checkout form', () => {
      let actionCreator = {
        type: TOGGLE_ADDRESS2_SHIPPING_FIELD_DISPlAY
      }

      let state = {
        checkoutFormAddress2Open: {
          shippingAddressForm: true,
          paymentAddressForm: true
        }
      }

      let expectedOutput = {
        checkoutFormAddress2Open:{
          shippingAddressForm: false,
          paymentAddressForm: true
        }

      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'checking the toggle for the payment form', () => {
      let actionCreator = {
        type: TOGGLE_ADDRESS2_PAYMENT_FIELD_DISPlAY
      }

      let state = {
        checkoutFormAddress2Open: {
          shippingAddressForm: true,
          paymentAddressForm: true
        }
      }

      let expectedOutput = {
        checkoutFormAddress2Open: {
          shippingAddressForm: true,
          paymentAddressForm: false
        }
      }

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'SUBMIT_ADDRESS_CASE', () => {
    it( 'reset the order status', () => {
      let actionCreator = {
        type: RESET_ORDER_STATUS
      }

      let excepted = {
        orderSuccess: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
    it( 'If the sumbit order is requested', () => {
      let actionCreator = {
        type: getServiceType( 'submitOrderService', 'requested' )
      }

      let excepted = {
        submitOrderSpinner:true,
        isErrorBeforeSubmitOrder: undefined,
        anchorAfterSubmitServiceCall: undefined,
        displayCheckoutLevelErrorMessage: false
      }

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'If the submit order is successfull', () => {
      let data = { 'success':true }
      let actionCreator = {
        type: getServiceType( 'submitOrderService', 'success' ),
        data
      }

      let expected = {
        success: true,
        orderSuccess: true,
        submitOrderSpinner: false
      }

      expect( reducer( data, actionCreator ) ).toEqual( expected );
    } );

    it( 'If the submit order is failure', () => {
      const data = {
        'data': {
          'success': false,
          'shippingInfo': null,
          'paymentInfo': {
            'messages': {
              'items': [{
                'type': 'Error',
                'message': 'Please enter a valid Security Code.'
              }]
            }
          },
          'cartItems': null,
          'messages': {
            'items': [{
              'type': 'error',
              'message': 'Error commitiing error'
            }]
          }
        }
      }
      let actionCreator = {
        type: getServiceType( 'submitOrderService', 'success' ),
        data
      }
      const excepted = {
        'checkoutError': null,
        'creditCardMessages': null,
        'data': {
          'cartItems': null,
          'messages': {
            'items': [{
              'message': 'Error commitiing error',
              'type': 'error'
            }]
          },
          'paymentInfo': {
            'messages': {
              'items': [{
                'message': 'Please enter a valid Security Code.',
                'type': 'Error'
              }]
            }
          },
          'shippingInfo': null,
          'success': false
        },
        'displayCheckoutLevelErrorMessage': true,
        'shippingErrorMessages': null,
        'submitOrderSpinner': false
      };
      expect( reducer( data, actionCreator ) ).toEqual( excepted );
    } );

    it( 'submit order is failure displayCheckoutLevelErrorMessage has to be false', () => {
      const data = { displayCheckoutLevelErrorMessage : 'false' };
      const actionCreator = {
        type: getServiceType( 'submitOrderService', 'failure' ),
        data
      }
      const excepted = { submitOrderSpinner: false, displayCheckoutLevelErrorMessage: false, isErrorBeforeSubmitOrder: undefined };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
    it( 'submit order is failure and  displayCheckoutLevelErrorMessage is not \'false\', then it has to be true', () => {
      const data = { displayCheckoutLevelErrorMessage : false };
      const actionCreator = {
        type: getServiceType( 'submitOrderService', 'failure' ),
        data
      }
      const excepted = { submitOrderSpinner: false, displayCheckoutLevelErrorMessage: true, isErrorBeforeSubmitOrder: undefined };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
  } );

  describe( 'PAYPAL_CASE', () => {
    it( 'Checking the paypal flag', () => {
      let actionCreator = {
        type: getServiceType( 'payPal', 'success' )
      }

      let excepted = { paypal: true };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'Checking the paypal token loading', () => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'loading' )
      }

      let expected = { payPalClientToken: undefined };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Checking the paypal client token success', () => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'success' ),
        data:{
          result:'success',
          payPalClientToken:'eyJ2ZXJzaW9uIjoyLCJhdXRob3J'
        }
      }

      let expected = { payPalClientToken: 'eyJ2ZXJzaW9uIjoyLCJhdXRob3J' }
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Checking whether the paypal client token error', () => {
      let actionCreator = {
        type: getServiceType( 'paypalToken', 'success' ),
        data:{
          result:'Error'
        }
      }

      let expected = {};
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Checking the paypal Response event', () => {
      let actionCreator = {
        type: PAYPAL_RESPONSE,
        info: 'eyJ2ZXJzaW9uIjoyLCJhdXRob3J'
      }

      let expected = { paypalResponse: 'eyJ2ZXJzaW9uIjoyLCJhdXRob3J' };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Checking applyExpressPayPalPayment success event', () => {
      let actionCreator = {
        type: getServiceType( 'applyExpressPayPalPayment', 'success' )
      }

      let expected = {
        paymentType: 'paypal',
        previousPaymentType: 'paypal',
        isPaymentTypeAfterPay: false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( ' applyPayPalPayment success should set isPaymentTypeAfterPay and showAfterpayContent as false, showGiftCard as true', () => {
      let actionCreator = {
        type: getServiceType( 'applyPayPalPayment', 'success' ),
        data: {}
      }

      expect( reducer( {}, actionCreator ).isPaymentTypeAfterPay ).toEqual( false );
      expect( reducer( {}, actionCreator ).showAfterpayContent ).toEqual( false );
      expect( reducer( {}, actionCreator ).showGiftCard ).toEqual( true );
      expect( reducer( {}, actionCreator ).afterpayDetails ).toEqual( null );
    } );


  } );

  describe( 'PAYMENT_CASES', () => {
    it( 'setting the payment cvv number', () => {
      let data = '311';
      let actionCreator = {
        type: SET_TEMP_PAYMENT_CCV_NUMBER,
        data
      }

      let excepted = {
        tempPaymentCCVNumber: '311'
      }

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } )

    it( 'setting the credit card type', () => {
      const data = '12345678901234';
      const actionCreator = {
        type: SET_CREDITCARD_PAYMENT_TYPE,
        data
      }
      const excepted = {
        editCreditCardData: {
          nickName: 'VISA - 9999'
        },
        creditCardType:'DefaultCreditCard',
        shouldDisplayExpiryAndCvv: false,
        maskCreditCardNumber:'12345678901234',
        isValidCardType: false
      }
      const state =  {
        editCreditCardData: {
          nickName: 'VISA - 9999'
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( excepted );
    } );

    it( 'editing the credit card data', () => {
      let data = {
        nickName: 'Mastercard - 4444',
        creditCardType: 'Mastercard',
        creditCardNumber: '4444',
        expirationMonth: '06',
        expirationYear: '2031',
        firstName: 'Jane',
        lastName: 'Doe',
        phoneNumber: '123-456-7890',
        addressData: {
          address1: '724 Greenwood Circle',
          address2: 'Apt#102',
          city: 'Naperville',
          state: 'IL',
          postalCode: '92476'
        }
      }

      let actionCreator = {
        type: SET_EDIT_CREDITCARD_DATA,
        data
      }

      let excepted = {
        'addressData':
      {
        'address1': '724 Greenwood Circle',
        'address2': 'Apt#102',
        'city': 'Naperville',
        'postalCode': '92476',
        'state': 'IL'
      },
        'creditCardNumber': '4444',
        'creditCardType': 'Mastercard',
        'editCreditCardData': {
          'addressData': {
            'address1': '724 Greenwood Circle',
            'address2': 'Apt#102',
            'city': 'Naperville',
            'postalCode': '92476',
            'state': 'IL'
          },
          'creditCardNumber': '4444',
          'creditCardType': 'Mastercard',
          'expirationMonth': '06',
          'expirationYear': '2031',
          'firstName': 'Jane',
          'lastName': 'Doe',
          'nickName': 'Mastercard - 4444',
          'phoneNumber': '123-456-7890'
        },
        'expirationMonth': '06',
        'expirationYear':'2031',
        'firstName': 'Jane',
        'lastName': 'Doe',
        'loadMaskCreditcard': true,
        'maskCreditCardNumber': '****undefined',
        'nickName':'Mastercard - 4444',
        'phoneNumber': '123-456-7890'
      }

      expect( reducer( data, actionCreator ) ).toEqual( excepted );
    } );

    it( 'checking the payment status', () => {
      let data = true;
      let actionCreator = {
        type: UPDATE_PAYMENT_STATUS,
        data
      }

      let excepted = {
        paymentSuccess: false
      }
      expect( reducer( data, actionCreator ) ).toEqual( excepted );
    } );

    it( 'setting the payment form type', ()=>{
      let actionCreator = {
        type: SET_PAYMENT_FORM_TYPE,
        paymentType: 'creditcard'
      }

      let excepted = {
        paymentType: 'creditcard',
        showGiftCard: true,
        isPaymentTypeAfterPay: false
      }

      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );

    it( 'setting the payment form type as afterpay', ()=>{
      const mockState = {
        showAfterpay: true
      }
      let actionCreator = {
        type: SET_PAYMENT_FORM_TYPE,
        paymentType: 'afterpay'
      }

      let excepted = {
        paymentType: 'afterpay',
        showGiftCard: false,
        isPaymentTypeAfterPay: true,
        showAfterpay: true
      }

      expect( reducer( mockState, actionCreator ) ).toEqual( excepted );
    } );

    it( 'should set isPaymentTypeAfterPay as false when showAfterpay is false even if paymentType is afterpay', ()=>{
      const mockState = {
        showAfterpay: false
      }
      let actionCreator = {
        type: SET_PAYMENT_FORM_TYPE,
        paymentType: 'afterpay'
      }
      expect( reducer( mockState, actionCreator ).isPaymentTypeAfterPay ).toEqual( false );
    } );

  } );

  describe( 'SHIPPING_CASES', () => {

    it( 'updating shipping status with data', () => {
      let data = {
        cartSummary: {
          shippingCost: 'TBD',
          subTotal: 5.99,
          itemCount: 1,
          orderGiftWrapAmt: 0,
          additionalDiscount: null,
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftCard: null,
          rewardPointsDiscount: null,
          estimatedTotal: 5.99,
          rewardPointsEarned: null,
          currencyCode: 'USD'
        },
        'shippingInfo': {
          'shippingStatus': 'IncompatibleShipping',
          'correctedShippingAddress': null,
          'shipMethodInfo': null,
          'shippingAddress': {
            'firstName': {
              'messages': null,
              'value': 'testfirstName'
            },
            'lastName': {
              'messages': null,
              'value': 'testSecondname'
            },
            'country': {
              'messages': null,
              'value': 'US'
            },
            'phoneNumber': {
              'messages': null,
              'value': '999-999-9999'
            },
            'address2': {
              'messages': null,
              'value': 'Ste 105'
            },
            'city': {
              'messages': null,
              'value': 'Lihue'
            },
            'address1': {
              'messages': null,
              'value': '4444 Rice St'
            },
            'postalCode': {
              'messages': null,
              'value': '96766-1340'
            },
            'messages': null,
            'state': {
              'messages': null,
              'value': 'HI'
            },
            'email': {
              'messages': null,
              'value': '9003517@ulta.com'
            }
          },
          'messages': {
            'items': [
              {
                'type': 'Error',
                'message': 'Items in your Bag cannot be shipped to HI.'
              }
            ]
          }
        }
      }

      let actionCreator = {
        type: getServiceType( 'shippingUpdate', 'success' ),
        data :
        {
          response:data,
          isShippingMethodUpdated:false
        }
      }

      let expected = {
        shippingSuccess: true,
        checkoutServicesData: data,
        shippingErrorMessages:null,
        incompatibleShippingMessges:[
          {
            'type': 'Error',
            'message': 'Items in your Bag cannot be shipped to HI.'
          }
        ],
        shippingWarningMessages:null,
        selectedShippingMethod:null,
        displayDavPopUp:false,
        editAddressData: { ...data.shippingInfo.shippingAddress },
        shippingAddressView:'defaultShippingAddressView'
      };
      expect( reducer( { checkoutServicesData:{ shippingInfo:{} } }, actionCreator ) ).toEqual( expected );
    } );

    it( 'should set shippingAddressView to defaultShippingAddressView and shippingErrorMessages as null when status is correctedAddress', () => {
      let data = {
        'shippingInfo': {
          'shippingStatus': 'CorrectedAddress',
          'shippingAddress':{
            messages:{
              items:[
                {
                  message:'USPS recommends the following address to ensure your package is delivered without issues.',
                  type:'Info'
                }
              ]
            }
          }
        }
      }
      let actionCreator = {
        type: getServiceType( 'shippingUpdate', 'success' ),
        data :
        {
          response:data,
          isShippingMethodUpdated:false
        }
      }

      expect( reducer( { checkoutServicesData:{} }, actionCreator ).shippingAddressView ).toEqual( 'defaultShippingAddressView' );
      expect( reducer( { checkoutServicesData:{} }, actionCreator ).shippingErrorMessages ).toEqual( null );
    } );

    it( 'Should set estimatedDelivery when estimatedDeliveryDate success action is triggered', () => {

      let state = {
        'checkoutServicesData': {
          'shippingInfo': {
            'shippingAddress': {
            },
            'shipMethodInfo':{
              items:[
                {
                  'shipMethod': 'ups_ground',
                  'estimatedDelivery':null
                },
                {
                  'shipMethod': 'free_shipping',
                  'estimatedDelivery':null
                }
              ]
            }
          }
        },
        'selectedShippingMethod': {
          'shipMethod': 'ups_ground',
          'estimatedDelivery': null,
          'cost': '$5.95',
          'displayName': 'Standard Ground Shipping'
        }
      }
      let data = {
        shipMethodList:{
          items:[
            {
              'shipMethod': 'ups_ground',
              'estimatedDelivery':'Get it by Thu, August 10'
            },
            {
              'shipMethod': 'free_shipping',
              'estimatedDelivery':'Get it by Thu, August 10'
            }
          ]
        }
      }
      let actionCreator = {
        type: getServiceType( 'estimatedDeliveryDate', 'success' ),
        data
      }

      let excepted = {
        'checkoutServicesData': {
          'shippingInfo': {
            'shippingAddress': {
            },
            'shipMethodInfo':{
              items:[
                {
                  'shipMethod': 'ups_ground',
                  'estimatedDelivery':'Get it by Thu, August 10'
                },
                {
                  'shipMethod': 'free_shipping',
                  'estimatedDelivery':'Get it by Thu, August 10'
                }
              ]
            }
          }
        },
        'selectedShippingMethod': {
          'shipMethod': 'ups_ground',
          'estimatedDelivery': 'Get it by Thu, August 10',
          'cost': '$5.95',
          'displayName': 'Standard Ground Shipping'
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( excepted );
    } )
    it( 'Shipping update event when requested', () => {

      let actionCreator = {
        type: getServiceType( 'shippingUpdate', 'requested' )
      }

      let expected = {
        isShippingAddressErrorCleared : false,
        shippingErrorMessages:null
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Shipping update success event with failure', () => {
      let actionCreator = {
        type: getServiceType( 'shippingUpdate', 'success' ),
        data:{
          response:{
            'shippingInfo': {
              'shippingStatus': 'InvalidAddress',
              'correctedShippingAddress': null,
              'shipMethodInfo': {
                'cost': 'FREE',
                'displayName': 'Standard Shipping',
                'shipMethod': 'free_shipping',
                'estimatedDelivery': null
              },
              'shippingAddress': {
                'lastName': {
                  'messages': null,
                  'value': 'Doe'
                },
                'country': {
                  'messages': null,
                  'value': null
                },
                'address2': {
                  'messages': null,
                  'value': 'Suite # 120'
                },
                'city': {
                  'messages': null,
                  'value': 'Bolingbrook'
                },
                'address1': {
                  'messages': null,
                  'value': '1000 Remington Blvd'
                },
                'postalCode': {
                  'messages': null,
                  'value': '60460'
                },
                'firstName': {
                  'messages': null,
                  'value': null
                },
                'phoneNumber': {
                  'messages': null,
                  'value': '510-213-8347'
                },
                'messages': {
                  'items': [
                    {
                      'type': 'Error',
                      'message': 'Please enter a valid address and re-submit.'
                    }
                  ]
                },
                'state': {
                  'messages': null,
                  'value': 'IL'
                },
                'email': {
                  'messages': null,
                  'value': 'da21@da2.com'
                }
              },
              'messages': null
            }
          },
          isShippingMethodUpdated:false
        }
      }

      let expected = {
        'displayDavPopUp': false,
        'editAddressData': {
          'address1': {
            'messages': null,
            'value': '1000 Remington Blvd'
          },
          'address2': {
            'messages': null,
            'value': 'Suite # 120'
          },
          'city': {
            'messages': null,
            'value': 'Bolingbrook'
          },
          'country': {
            'messages': null,
            'value': null
          },
          'email': {
            'messages': null,
            'value': 'da21@da2.com'
          },
          'firstName': {
            'messages': null,
            'value': null
          },
          'lastName': {
            'messages': null,
            'value': 'Doe'
          },
          'messages': {
            'items': [
              {
                'message': 'Please enter a valid address and re-submit.',
                'type': 'Error'
              }
            ]
          },
          'phoneNumber': {
            'messages': null,
            'value': '510-213-8347'
          },
          'postalCode': {
            'messages': null,
            'value': '60460'
          },
          'state': {
            'messages': null,
            'value': 'IL'
          }
        },
        'checkoutServicesData': {
          'cartSummary': undefined,
          'paymentDetails': undefined,
          'shippingInfo': {
            'correctedShippingAddress': null,
            'messages': null,
            'shipMethodInfo': {
              'cost': 'FREE',
              'displayName': 'Standard Shipping',
              'estimatedDelivery': null,
              'shipMethod': 'free_shipping'
            },
            'shippingAddress': {
              'address1': {
                'messages': null,
                'value': '1000 Remington Blvd'
              },
              'address2': {
                'messages': null,
                'value': 'Suite # 120'
              },
              'city': {
                'messages': null,
                'value': 'Bolingbrook'
              },
              'country': {
                'messages': null,
                'value': null
              },
              'email': {
                'messages': null,
                'value': 'da21@da2.com'
              },
              'firstName': {
                'messages': null,
                'value': null
              },
              'lastName': {
                'messages': null,
                'value': 'Doe'
              },
              'messages': {
                'items': [
                  {
                    'message': 'Please enter a valid address and re-submit.',
                    'type': 'Error'
                  }
                ]
              },
              'phoneNumber': {
                'messages': null,
                'value': '510-213-8347'
              },
              'postalCode': {
                'messages': null,
                'value': '60460'
              },
              'state': {
                'messages': null,
                'value': 'IL'
              }
            },
            'shippingStatus': 'InvalidAddress'
          }
        },
        'shippingAddressView': 'addEditShippingAddressView',
        'shippingErrorMessages': [
          {
            'message': 'Please enter a valid address and re-submit.',
            'type': 'Error'
          }
        ],
        shippingWarningMessages:null,
        incompatibleShippingMessges:null,
        'selectedShippingMethod': null,
        'shippingSuccess': true
      };

      expect( reducer( { checkoutServicesData:{ shippingInfo:{} } }, actionCreator ) ).toEqual( expected );
    } );

  } );

  describe( 'JOIN_NOW_CASES', () => {
    it( 'User rewards requested events', () => {
      let actionCreator = {
        type: getServiceType( 'userRewards', 'requested' )
      }

      let expected = { joinNowRewardsError: [] };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'User rewards success event with success scenario', () => {
      let actionCreator = {
        type: getServiceType( 'userRewards', 'success' ),
        data:{
          cartSummary: {
            shippingCost: 6.95,
            subTotal: 26,
            itemCount: '1',
            orderGiftWrapAmt: 0,
            additionalDiscount: null,
            couponDiscount: 0,
            estimatedTax: 0.96,
            rewardPointsDiscount: null,
            estimatedTotal: 33.91,
            rewardPointsEarned: 208,
            currencyCode: 'USD'
          },
          isRewardsMember: true
        }
      }

      let expected = {
        checkoutServicesData:{
          cartSummary:{
            shippingCost: 6.95,
            subTotal: 26,
            itemCount: '1',
            orderGiftWrapAmt: 0,
            additionalDiscount: null,
            couponDiscount: 0,
            estimatedTax: 0.96,
            rewardPointsDiscount: null,
            estimatedTotal: 33.91,
            rewardPointsEarned: 208,
            currencyCode: 'USD'
          }
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'User rewards success event with error scenario', () => {
      let actionCreator = {
        type: getServiceType( 'userRewards', 'success' ),
        data:{
          isRewardsMember:true,
          messages: [
            {
              messageKey: 'errorComputingPoints',
              messageType: 'Error',
              messageDesc: 'You will earn points with this order.'
            }
          ]
        }
      }

      let expected = {
        joinNowRewardsError: [
          {
            messageKey: 'errorComputingPoints',
            messageType: 'Error',
            messageDesc: 'You will earn points with this order.'
          }
        ]
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'REDEEM_POINTS', () => {
    it( 'Redeem Points success case', () => {
      let actionCreator = {
        type: getServiceType( 'redeemPoints', 'success' ),
        data:{
          profileRedeemLevels:{
            items: [
              { value: '2', points:'50.0' },
              { value: '14', points: '450.0' },
              { value: '16', points: '500.0' },
              { value: '19.5', points: '550.0' },
              { value: '22.5', points: '650.0' }
            ]
          }
        }
      }

      let expected = {
        canDisplayPoints: true,
        hasMessages: false,
        redeemPointLevels: {
          profileRedeemLevels:{
            items: [
              { value: '2', points:'50.0' },
              { value: '14', points: '450.0' },
              { value: '16', points: '500.0' },
              { value: '19.5', points: '550.0' },
              { value: '22.5', points: '650.0' }
            ]
          }
        }
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'PAYMENT SERVICE RESPOSSE', () => {
    it( 'should set isPaymentTypeAfterPay as false for paymentServiceResponse requested', () => {
      let actionCreator = {
        type: getServiceType( 'paymentServiceResponse', 'requested' )
      }
      expect( reducer( {}, actionCreator ).isPaymentTypeAfterPay ).toEqual( false );
    } );
    it( 'Payment Success Case With Payment Type as creditCard', () => {
      let actionCreator = {
        type: getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          result:{
            appliedCouponSummary:{
              couponCode:null
            },
            cartSummary:{
              shippingCost: 5.95,
              subTotal: 25,
              itemCount: 1,
              estimatedTotal: 32.89
            },
            paymentInfo: {
              items:[{
                amount: 32.89,
                contactInfo: {
                  address1: '4583 Delaware St',
                  address2: '',
                  city: 'San Diego',
                  country: 'US',
                  email: null,
                  firstName: 'Test',
                  lastName: 'Test',
                  phoneNumber: '435-647-8754',
                  postalCode: '92116',
                  state: 'CA'
                },
                nickName: 'VISA - 1111',
                paymentDetails: {
                  creditCardNumber: 1111,
                  creditCardType: 'Visa',
                  expirationDate: null,
                  expirationMonth: 12,
                  expirationYear: 2020
                },
                paymentType: 'creditCard'
              }]
            },
            remainingPaymentDue: 0,
            paymentDetails: [
              {
                messages: [],
                paymentInfo:{
                  amount: 32.89,
                  nickName: 'VISA - 1111',
                  paymentType: 'creditCard',
                  paymentDetails: {
                    expirationDate: null,
                    expirationYear: 2020,
                    creditCardNumber: 1111,
                    creditCardType: 'Visa',
                    expirationMonth: 12
                  },
                  contactInfo: {
                    firstName: 'Test',
                    lastName: 'Test',
                    address1: '4583 Delaware St',
                    address2: '',
                    city: 'San Diego',
                    state: 'CA',
                    country: 'US',
                    postalCode: '92116',
                    phoneNumber: '435-647-8754',
                    email: null
                  }
                },
                showPaymentSecurityCode: true
              }
            ]
          },
          paymentType: 'creditCard'
        }
      }

      let expected = {
        'billingAddress': null,
        'checkoutServicesData': {
          'appliedCouponSummary': {
            'couponCode':null
          },
          'cartSummary': {
            'estimatedTotal': 32.89,
            'itemCount': 1,
            'shippingCost': 5.95,
            'subTotal': 25
          },
          'paymentInfo': {
            'items': [
              {
                'amount': 32.89,
                'contactInfo': {
                  'address1': '4583 Delaware St',
                  'address2': '',
                  'city': 'San Diego',
                  'country': 'US',
                  'email': null,
                  'firstName': 'Test',
                  'lastName': 'Test',
                  'phoneNumber': '435-647-8754',
                  'postalCode': '92116',
                  'state': 'CA'
                },
                'nickName': 'VISA - 1111',
                'paymentDetails': {
                  'creditCardNumber': 1111,
                  'creditCardType': 'Visa',
                  'expirationDate': null,
                  'expirationMonth': 12,
                  'expirationYear': 2020
                },
                'paymentType': 'creditCard',
                'showPaymentSecurityCode': true
              }
            ]
          }
        },
        'creditCardDetails': {
          'amount': 32.89,
          'contactInfo': {
            'address1': '4583 Delaware St',
            'address2': '',
            'city': 'San Diego',
            'country': 'US',
            'email': null,
            'firstName': 'Test',
            'lastName': 'Test',
            'phoneNumber': '435-647-8754',
            'postalCode': '92116',
            'state': 'CA'
          },
          'nickName': 'VISA - 1111',
          'paymentDetails': {
            'creditCardNumber': 1111,
            'creditCardType': 'Visa',
            'expirationDate': null,
            'expirationMonth': 12,
            'expirationYear': 2020
          },
          'paymentType': 'creditCard',
          'showPaymentSecurityCode': true
        },
        'creditCardMessages': null,
        'creditCardType': undefined,
        'editCreditCardData': {
          'contactInfo': {
            'address1': '4583 Delaware St',
            'address2': '',
            'city': 'San Diego',
            'firstName': 'Test',
            'lastName': 'Test',
            'phoneNumber': '435-647-8754',
            'postalCode': '92116',
            'state': 'CA'
          },
          'creditCardNumber': 1111,
          'creditCardType': 'Visa',
          'expirationMonth': 12,
          'expirationYear': 2020,
          'nickName': 'VISA - 1111'
        },
        'giftCardApplying': false,
        'giftCardDetails': undefined,
        'isBillingAddressSameAsShipping': false,
        'isBillingAddressSameAsContactInfo': true,
        'pickupPaymentAddress':{
          'address1': '4583 Delaware St',
          'address2': '',
          'city': 'San Diego',
          'firstName': 'Test',
          'lastName': 'Test',
          'phoneNumber': '435-647-8754',
          'postalCode': '92116',
          'state': 'CA',
          'country': 'US',
          'email': null
        },
        'isPaymentAddEditMode': false,
        'isSignedIn': undefined,
        'loadMaskCreditcard': true,
        'maskCreditCardNumber': '****undefined',
        'payPalDetails': undefined,
        'paymentError': [],
        'paymentSuccess': true,
        'paymentType': 'creditCard',
        'previousPaymentType': 'creditCard',
        'remainingPaymentDue': 0,
        'shouldDisplayExpiryAndCvv': false,
        'isPaymentDefaultCreditCardView': false,
        'isPaymentCreditCardPayPalView': true,
        'isProfileCreditCardListView':false,
        'giftCardErrorMessage': null,
        'showUltamateRewardsCreditCard': false,
        'showGiftCard': true,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      }
      expect( reducer( { paymentType: 'creditCard' }, actionCreator ) ).toEqual( expected );
    } );

    it( 'should set isUltamateRewardCard as true when the card used is of type ultamate', () => {
      let actionCreator = {
        type: getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          result:{
            appliedCouponSummary:{
              couponCode:null
            },
            cartSummary:{
              shippingCost: 5.95,
              subTotal: 25,
              itemCount: 1,
              estimatedTotal: 32.89
            },
            paymentInfo: {
              items:[{
                amount: 32.89,
                contactInfo: {
                  address1: '4583 Delaware St',
                  address2: '',
                  city: 'San Diego',
                  country: 'US',
                  email: null,
                  firstName: 'Test',
                  lastName: 'Test',
                  phoneNumber: '435-647-8754',
                  postalCode: '92116',
                  state: 'CA'
                },
                nickName: 'VISA - 1111',
                paymentDetails: {
                  creditCardNumber: 1111,
                  creditCardType: {
                    value:'Ultamate Rewards Credit Card',
                    message:null
                  },
                  expirationDate: null,
                  expirationMonth: 12,
                  expirationYear: 2020
                },
                paymentType: 'creditCard'
              }]
            },
            remainingPaymentDue: 0,
            paymentDetails: [
              {
                messages: [],
                paymentInfo:{
                  amount: 32.89,
                  nickName: 'VISA - 1111',
                  paymentType: 'creditCard',
                  paymentDetails: {
                    expirationDate: null,
                    expirationYear: 2020,
                    creditCardNumber: 1111,
                    creditCardType: 'Visa',
                    expirationMonth: 12
                  },
                  contactInfo: {
                    firstName: 'Test',
                    lastName: 'Test',
                    address1: '4583 Delaware St',
                    address2: '',
                    city: 'San Diego',
                    state: 'CA',
                    country: 'US',
                    postalCode: '92116',
                    phoneNumber: '435-647-8754',
                    email: null
                  }
                },
                showPaymentSecurityCode: true
              }
            ]
          },
          paymentType: 'creditCard'
        }
      }

      let expected = {
        'billingAddress': null,
        'checkoutServicesData': {
          'appliedCouponSummary': {
            'couponCode':null
          },
          'cartSummary': {
            'estimatedTotal': 32.89,
            'itemCount': 1,
            'shippingCost': 5.95,
            'subTotal': 25
          },
          'paymentInfo': {
            'items': [
              {
                'amount': 32.89,
                'contactInfo': {
                  'address1': '4583 Delaware St',
                  'address2': '',
                  'city': 'San Diego',
                  'country': 'US',
                  'email': null,
                  'firstName': 'Test',
                  'lastName': 'Test',
                  'phoneNumber': '435-647-8754',
                  'postalCode': '92116',
                  'state': 'CA'
                },
                'nickName': 'VISA - 1111',
                'paymentDetails': {
                  'creditCardNumber': 1111,
                  'creditCardType': {
                    'value':'Ultamate Rewards Credit Card',
                    'message':null
                  },
                  'expirationDate': null,
                  'expirationMonth': 12,
                  'expirationYear': 2020
                },
                'paymentType': 'creditCard',
                'showPaymentSecurityCode': false
              }
            ]
          }
        },
        'creditCardDetails': {
          'amount': 32.89,
          'contactInfo': {
            'address1': '4583 Delaware St',
            'address2': '',
            'city': 'San Diego',
            'country': 'US',
            'email': null,
            'firstName': 'Test',
            'lastName': 'Test',
            'phoneNumber': '435-647-8754',
            'postalCode': '92116',
            'state': 'CA'
          },
          'nickName': 'VISA - 1111',
          'paymentDetails': {
            'creditCardNumber': 1111,
            'creditCardType': {
              'value':'Ultamate Rewards Credit Card',
              'message':null
            },
            'expirationDate': null,
            'expirationMonth': 12,
            'expirationYear': 2020
          },
          'paymentType': 'creditCard',
          'showPaymentSecurityCode': false
        },
        'creditCardMessages': null,
        'creditCardType': 'Ultamate Rewards Credit Card',
        'editCreditCardData': {
          'contactInfo': {
            'address1': '4583 Delaware St',
            'address2': '',
            'city': 'San Diego',
            'firstName': 'Test',
            'lastName': 'Test',
            'phoneNumber': '435-647-8754',
            'postalCode': '92116',
            'state': 'CA'
          },
          'creditCardNumber': 1111,
          'creditCardType': {
            'value':'Ultamate Rewards Credit Card',
            'message':null
          },
          'expirationMonth': 12,
          'expirationYear': 2020,
          'nickName': 'VISA - 1111'
        },
        'giftCardApplying': false,
        'giftCardDetails': undefined,
        'isBillingAddressSameAsShipping': false,
        'isBillingAddressSameAsContactInfo': true,
        'pickupPaymentAddress':{
          'address1': '4583 Delaware St',
          'address2': '',
          'city': 'San Diego',
          'firstName': 'Test',
          'lastName': 'Test',
          'phoneNumber': '435-647-8754',
          'postalCode': '92116',
          'state': 'CA',
          'country': 'US',
          'email': null
        },
        'isPaymentAddEditMode': false,
        'isSignedIn': undefined,
        'loadMaskCreditcard': true,
        'maskCreditCardNumber': '****undefined',
        'payPalDetails': undefined,
        'paymentError': [],
        'paymentSuccess': true,
        'paymentType': 'creditCard',
        'previousPaymentType': 'creditCard',
        'remainingPaymentDue': 0,
        'shouldDisplayExpiryAndCvv': false,
        'isPaymentDefaultCreditCardView': false,
        'isPaymentCreditCardPayPalView': true,
        'isProfileCreditCardListView':false,
        'giftCardErrorMessage': null,
        'showUltamateRewardsCreditCard': false,
        'isUltamateRewardCard':true,
        'showGiftCard': true,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      }
      expect( reducer( { paymentType: 'creditCard' }, actionCreator ) ).toEqual( expected );
    } );

    it( 'Payment Success Case With Credit Card but Payment Type as Paypal and Profile Credit Card Count as 0', () => {
      let actionCreator = {
        type: getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          result:{
            cartSummary:{
              shippingCost: 5.95,
              subTotal: 25,
              itemCount: 1,
              estimatedTotal: 32.89
            },
            remainingPaymentDue: 0,
            paymentDetails: [
              {
                messages: [],
                paymentInfo:{
                  amount: 32.89,
                  nickName: 'VISA - 1111',
                  paymentType: 'creditCard',
                  paymentDetails: {
                    expirationYear: 2020,
                    creditCardNumber: 1111,
                    creditCardType: 'Visa',
                    expirationMonth: 12
                  },
                  contactInfo: {
                    firstName: 'Test',
                    lastName: 'Test',
                    address1: '4583 Delaware St',
                    address2: '',
                    city: 'San Diego',
                    state: 'CA',
                    country: 'US',
                    postalCode: '92116',
                    phoneNumber: '435-647-8754',
                    email: null
                  }
                }
              }
            ]
          },
          paymentType: 'creditCard'
        }
      }

      let expected = {
        'checkoutServicesData': {
          'appliedCouponSummary': undefined,
          'cartSummary': {
            'estimatedTotal': 32.89,
            'itemCount': 1,
            'shippingCost': 5.95,
            'subTotal': 25
          },
          'paymentInfo': undefined
        },
        'creditCardDetails': undefined,
        'creditCardMessages': null,
        'creditCardType': 'DefaultCreditCard',
        'editCreditCardData': {

        },
        'giftCardApplying': false,
        'giftCardDetails': undefined,
        'isBillingAddressSameAsShipping': true,
        'isBillingAddressSameAsContactInfo': true,
        'pickupPaymentAddress':false,
        'isPaymentAddEditMode': false,
        'loadMaskCreditcard': false,
        'maskCreditCardNumber': null,
        'isSignedIn': undefined,
        'payPalDetails': undefined,
        'paymentError': [

        ],
        'paymentSuccess': true,
        'paymentType': 'creditCard',
        'previousPaymentType': 'creditCard',
        'profileCreditCardListCount': 0,
        'remainingPaymentDue': 0,
        'shouldDisplayExpiryAndCvv': undefined,
        'isPaymentDefaultCreditCardView': false,
        'isPaymentCreditCardPayPalView': true,
        'isProfileCreditCardListView': false,
        'showUltamateRewardsCreditCard': false,
        'giftCardErrorMessage': null,
        'showGiftCard': true,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      };
      expect( reducer( { paymentType: 'paypal', profileCreditCardListCount: 0 }, actionCreator ) ).toEqual( expected );
    } );

    it( 'Payment Success Case by retaining Payment Type as credit Card on applying Gift Card after entering Paypal details', () => {
      let actionCreator = {
        type: getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          result:{
            appliedCouponSummary:{
              couponCode:null
            },
            cartSummary:{
              shippingCost: 5.95,
              subTotal: 25,
              itemCount: 1,
              estimatedTotal: 32.89
            },
            paymentInfo: {
              items:[{
                amount: 32.89,
                contactInfo: {
                  address1: '4583 Delaware St',
                  address2: '',
                  city: 'San Diego',
                  country: 'US',
                  email: null,
                  firstName: 'Test',
                  lastName: 'Test',
                  phoneNumber: '435-647-8754',
                  postalCode: '92116',
                  state: 'CA'
                },
                nickName: 'VISA - 1111',
                paymentDetails: {
                  creditCardNumber: 1111,
                  creditCardType: 'Visa',
                  expirationDate: null,
                  expirationMonth: 12,
                  expirationYear: 2020
                },
                paymentType: 'creditCard'
              }]
            },
            remainingPaymentDue: 0,
            paymentDetails: [
              {
                messages: [],
                paymentInfo:{
                  amount: 32.89,
                  nickName: 'VISA - 1111',
                  paymentType: 'creditCard',
                  paymentDetails: {
                    expirationDate: null,
                    expirationYear: 2020,
                    creditCardNumber: 1111,
                    creditCardType: 'Visa',
                    expirationMonth: 12
                  },
                  contactInfo: {
                    firstName: 'Test',
                    lastName: 'Test',
                    address1: '4583 Delaware St',
                    address2: '',
                    city: 'San Diego',
                    state: 'CA',
                    country: 'US',
                    postalCode: '92116',
                    phoneNumber: '435-647-8754',
                    email: null
                  }
                },
                showPaymentSecurityCode: true
              }
            ]
          },
          paymentType: 'creditCard'
        }
      }

      let expected = {
        'billingAddress': null,
        'checkoutServicesData': {
          'appliedCouponSummary': {
            'couponCode':null
          },
          'cartSummary': {
            'estimatedTotal': 32.89,
            'itemCount': 1,
            'shippingCost': 5.95,
            'subTotal': 25
          },
          'paymentInfo': {
            'items': [
              {
                'amount': 32.89,
                'contactInfo': {
                  'address1': '4583 Delaware St',
                  'address2': '',
                  'city': 'San Diego',
                  'country': 'US',
                  'email': null,
                  'firstName': 'Test',
                  'lastName': 'Test',
                  'phoneNumber': '435-647-8754',
                  'postalCode': '92116',
                  'state': 'CA'
                },
                'nickName': 'VISA - 1111',
                'paymentDetails': {
                  'creditCardNumber': 1111,
                  'creditCardType': 'Visa',
                  'expirationDate': null,
                  'expirationMonth': 12,
                  'expirationYear': 2020
                },
                'paymentType': initialState.paymentType,
                'showPaymentSecurityCode': true
              }
            ]
          }
        },
        'creditCardDetails': {
          'amount': 32.89,
          'contactInfo': {
            'address1': '4583 Delaware St',
            'address2': '',
            'city': 'San Diego',
            'country': 'US',
            'email': null,
            'firstName': 'Test',
            'lastName': 'Test',
            'phoneNumber': '435-647-8754',
            'postalCode': '92116',
            'state': 'CA'
          },
          'nickName': 'VISA - 1111',
          'paymentDetails': {
            'creditCardNumber': 1111,
            'creditCardType': 'Visa',
            'expirationDate': null,
            'expirationMonth': 12,
            'expirationYear': 2020
          },
          'paymentType': 'creditCard',
          'showPaymentSecurityCode': true
        },
        'creditCardMessages': null,
        'creditCardType': undefined,
        'editCreditCardData': {
          'contactInfo': {
            'address1': '4583 Delaware St',
            'address2': '',
            'city': 'San Diego',
            'firstName': 'Test',
            'lastName': 'Test',
            'phoneNumber': '435-647-8754',
            'postalCode': '92116',
            'state': 'CA'
          },
          'creditCardNumber': 1111,
          'creditCardType': 'Visa',
          'expirationMonth': 12,
          'expirationYear': 2020,
          'nickName': 'VISA - 1111'
        },
        'giftCardApplying': false,
        'giftCardDetails': undefined,
        'isBillingAddressSameAsShipping': false,
        'isBillingAddressSameAsContactInfo': true,
        'pickupPaymentAddress':{
          'address1': '4583 Delaware St',
          'address2': '',
          'city': 'San Diego',
          'firstName': 'Test',
          'lastName': 'Test',
          'phoneNumber': '435-647-8754',
          'postalCode': '92116',
          'state': 'CA',
          'country': 'US',
          'email': null
        },
        'isPaymentAddEditMode': false,
        'isSignedIn': undefined,
        'loadMaskCreditcard': true,
        'maskCreditCardNumber': '****undefined',
        'payPalDetails': undefined,
        'paymentError': [],
        'paymentSuccess': true,
        'paymentType': 'creditCard',
        'previousPaymentType': 'creditCard',
        'remainingPaymentDue': 0,
        'shouldDisplayExpiryAndCvv': false,
        'isPaymentDefaultCreditCardView': false,
        'isPaymentCreditCardPayPalView': true,
        'isProfileCreditCardListView':false,
        'giftCardErrorMessage': null,
        'showUltamateRewardsCreditCard': false,
        'showGiftCard': true,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      }
      expect( reducer( { paymentType: 'paypal' }, actionCreator ) ).toEqual( expected );
    } );

    it( 'should succesfully submit a payment by retaining payment Type,creditCardType and creditcard details in the state when user applys Gift Card ', () => {
      let actionCreator = {
        type: getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          result:{
            appliedCouponSummary:{
              couponCode:null
            },
            cartSummary:{
              shippingCost: 5.95,
              subTotal: 25,
              itemCount: 1,
              estimatedTotal: 32.89
            },
            paymentInfo: {
              items:[{
                amount: 32.89,
                contactInfo: {
                  address1: '4583 Delaware St',
                  address2: '',
                  city: 'San Diego',
                  country: 'US',
                  email: null,
                  firstName: 'Test',
                  lastName: 'Test',
                  phoneNumber: '435-647-8754',
                  postalCode: '92116',
                  state: 'CA'
                },
                nickName: 'VISA - 1111',
                paymentDetails: {
                  creditCardNumber: 1111,
                  creditCardType: 'Visa',
                  expirationDate: null,
                  expirationMonth: 12,
                  expirationYear: 2020
                },
                paymentType: 'creditCard'
              },
              {
                amount:0,
                paymentType:'giftCard'
              }]
            },
            remainingPaymentDue: 0,
            paymentDetails: [
              {
                messages: [],
                paymentInfo:{
                  amount: 32.89,
                  nickName: 'VISA - 1111',
                  paymentType: 'creditCard',
                  paymentDetails: {
                    expirationDate: null,
                    expirationYear: 2020,
                    creditCardNumber: 1111,
                    creditCardType: 'Visa',
                    expirationMonth: 12
                  },
                  contactInfo: {
                    firstName: 'Test',
                    lastName: 'Test',
                    address1: '4583 Delaware St',
                    address2: '',
                    city: 'San Diego',
                    state: 'CA',
                    country: 'US',
                    postalCode: '92116',
                    phoneNumber: '435-647-8754',
                    email: null
                  }
                },
                showPaymentSecurityCode: true
              }
            ]
          },
          paymentType: 'giftCard'
        }
      }

      let expected = {
        'billingAddress': null,
        'checkoutServicesData': {
          'appliedCouponSummary': {
            'couponCode':null
          },
          'cartSummary': {
            'estimatedTotal': 32.89,
            'itemCount': 1,
            'shippingCost': 5.95,
            'subTotal': 25
          },
          'paymentInfo': {
            'items': [
              {
                'amount': 32.89,
                'contactInfo': {
                  'address1': '4583 Delaware St',
                  'address2': '',
                  'city': 'San Diego',
                  'country': 'US',
                  'email': null,
                  'firstName': 'Test',
                  'lastName': 'Test',
                  'phoneNumber': '435-647-8754',
                  'postalCode': '92116',
                  'state': 'CA'
                },
                'nickName': 'VISA - 1111',
                'paymentDetails': {
                  'creditCardNumber': 1111,
                  'creditCardType': 'Visa',
                  'expirationDate': null,
                  'expirationMonth': 12,
                  'expirationYear': 2020
                },
                'paymentType': 'creditCard',
                'showPaymentSecurityCode': true
              },
              {
                amount:0,
                paymentType:'giftCard'
              }
            ]
          }
        },
        'creditCardDetails': {
          'amount': 32.89,
          'contactInfo': {
            'address1': '4583 Delaware St',
            'address2': '',
            'city': 'San Diego',
            'country': 'US',
            'email': null,
            'firstName': 'Test',
            'lastName': 'Test',
            'phoneNumber': '435-647-8754',
            'postalCode': '92116',
            'state': 'CA'
          },
          'nickName': 'VISA - 1111',
          'paymentDetails': {
            'creditCardNumber': 1111,
            'creditCardType': 'Visa',
            'expirationDate': null,
            'expirationMonth': 12,
            'expirationYear': 2020
          },
          'paymentType': 'creditCard',
          'showPaymentSecurityCode': true
        },
        'creditCardMessages': null,
        'creditCardType': 'Visa',
        'editCreditCardData': {
          'contactInfo': {
            'address1': '4583 Delaware St',
            'address2': '',
            'city': 'San Diego',
            'firstName': 'Test',
            'lastName': 'Test',
            'phoneNumber': '435-647-8754',
            'postalCode': '92116',
            'state': 'CA'
          },
          'creditCardNumber': 1111,
          'creditCardType': 'Visa',
          'expirationMonth': 12,
          'expirationYear': 2020,
          'nickName': 'VISA - 1111'
        },
        'giftCardApplying': false,
        'giftCardDetails':{
          amount:0,
          paymentType:'giftCard'
        },
        'isBillingAddressSameAsShipping': false,
        'isBillingAddressSameAsContactInfo': true,
        'pickupPaymentAddress':{
          'address1': '4583 Delaware St',
          'address2': '',
          'city': 'San Diego',
          'firstName': 'Test',
          'lastName': 'Test',
          'phoneNumber': '435-647-8754',
          'postalCode': '92116',
          'state': 'CA',
          'country': 'US',
          'email': null
        },
        'isSignedIn': undefined,
        'payPalDetails': undefined,
        'paymentError': [],
        'paymentSuccess': true,
        'paymentType': 'creditCard',
        'previousPaymentType': 'creditCard',
        'remainingPaymentDue': 0,
        'shouldDisplayExpiryAndCvv': true,
        'giftCardErrorMessage': null,
        'showGiftCard': true,
        afterpayDetails: undefined,
        showAfterpayContent: false
      }
      let initialState = {
        paymentType: 'creditCard',
        creditCardType:'Visa',
        shouldDisplayExpiryAndCvv:true
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expected );
    } );

    it( 'should succesfully submit a payment by retaining the paymentType, creditcardtype and creditcard details in the state when user removes applied Gift Card ', () => {
      let actionCreator = {
        type: getServiceType( 'removePaymentService', 'success' ),
        data:{
          result:{
            appliedCouponSummary:{
              couponCode:null
            },
            cartSummary:{
              shippingCost: 5.95,
              subTotal: 25,
              itemCount: 1,
              estimatedTotal: 32.89
            },
            paymentInfo: null,
            remainingPaymentDue: 0
          },
          paymentType: 'giftCard'
        }
      }

      let expected = {
        'billingAddress': undefined,
        'checkoutServicesData': {
          'cartSummary': {
            'estimatedTotal': 32.89,
            'itemCount': 1,
            'shippingCost': 5.95,
            'subTotal': 25
          },
          'paymentDetails': undefined
        },
        'creditCardDetails': null,
        'creditCardMessages': null,
        'creditCardType': 'Visa',
        'editCreditCardData': {},
        'giftCardDetails': null,
        'giftCardErrorMessage': null,
        'isBillingAddressSameAsContactInfo': true,
        'isBillingAddressSameAsShipping': true,
        'isGiftCardRemoved': true,
        'isSignedIn': undefined,
        'payPalDetails': null,
        'paymentType': 'creditCard',
        'pickupPaymentAddress': false,
        'remainingPaymentDue': 0,
        'shouldDisplayExpiryAndCvv': true,
        'showGiftCard': true,
        afterpayDetails: null,
        showAfterpayContent: false
      }
      let initialState = {
        paymentType: 'creditCard',
        creditCardType:'Visa',
        shouldDisplayExpiryAndCvv:true,
        showGiftCard: true
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expected );
    } );

    it( 'Payment Success Case With Payment Type as loyalty', () => {
      let actionCreator = {
        type: getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          result:{
            appliedCouponSummary:{
              couponCode:null
            },
            cartSummary:{
              shippingCost: 5.95,
              subTotal: 25,
              itemCount: 1,
              estimatedTotal: 32.89,
              rewardPointsDiscount:9
            },
            paymentInfo: {
              items:[
                {
                  'amount': 9,
                  'paymentType': 'loyalty',
                  'messages': null,
                  'paymentDetails': {
                    'pointsApplied': 1000,
                    'pointsBalance': 0,
                    'currencyCode': 'USD'
                  }
                }
              ]
            }
          }
        }
      }

      let expected = {
        'billingAddress': undefined,
        'canDisplayPoints': false,
        'pointsApplied': true,
        'checkoutServicesData': {
          'appliedCouponSummary': {
            'couponCode':null
          },
          'cartSummary': {
            'estimatedTotal': 32.89,
            'itemCount': 1,
            'shippingCost': 5.95,
            'subTotal': 25,
            'rewardPointsDiscount': 9
          },
          paymentInfo: {
            items:[
              {
                'amount': 9,
                'paymentType': 'loyalty',
                'messages': null,
                'paymentDetails': {
                  'pointsApplied': 1000,
                  'pointsBalance': 0,
                  'currencyCode': 'USD'
                }
              }
            ]
          }
        },
        'creditCardDetails': undefined,
        loyaltyCardDetails:{
          'amount': 9,
          'paymentType': 'loyalty',
          'messages': null,
          'paymentDetails': {
            'pointsApplied': 1000,
            'pointsBalance': 0,
            'currencyCode': 'USD'
          }
        },
        'creditCardMessages': null,
        'creditCardType': 'DefaultCreditCard',
        'editCreditCardData': {},
        'giftCardApplying': false,
        'giftCardDetails': undefined,
        'isBillingAddressSameAsShipping': true,
        'isBillingAddressSameAsContactInfo': true,
        'pickupPaymentAddress':false,
        'isPaymentAddEditMode': false,
        'loadMaskCreditcard': false,
        'maskCreditCardNumber': null,
        'isSignedIn': undefined,
        'payPalDetails': undefined,
        'paymentError': [],
        'paymentSuccess': true,
        'paymentType': 'creditCard',
        'previousPaymentType': 'creditCard',
        'isPaymentDefaultCreditCardView': false,
        'isPaymentCreditCardPayPalView': true,
        'isProfileCreditCardListView':false,
        'remainingPaymentDue': undefined,
        'selectedPoints': 1000,
        'shouldDisplayExpiryAndCvv': undefined,
        'giftCardErrorMessage': null,
        'showUltamateRewardsCreditCard': false,
        'showGiftCard': true,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      }
      expect( reducer( { paymentType: 'creditCard' }, actionCreator ) ).toEqual( expected );
    } );

    it( 'Should return error message if card validation error message is returned as part of tokenization ( istokenizationFailure:true )', () => {
      let actionCreator = {
        type: getServiceType( 'paymentServiceResponse', 'success' ),
        data:{
          istokenizationFailure:true
        }
      }

      let expected = {
        creditCardMessages: [
          {
            type: 'Error',
            message: 'Oops! We weren\'t able to process your payment method. Please verify your card info and try again. If the problem persists, contact us.'
          }
        ],
        istokenizationFailure:true,
        paymentType: 'creditCard'
      }
      expect( reducer( { paymentType: 'creditCard' }, actionCreator ) ).toEqual( expected );
    } );

  } );

  describe( 'PAYMENTS_CC_KEY_AND_TOEKN_CASES', () => {

    it( 'Payments CC key requested events', () => {
      let actionCreator = {
        type: getServiceType( 'paymentsCCKey', 'requested' )
      }

      let expected = { paymentsCCKey: undefined };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Payments CC key success event with success scenario', () => {
      let actionCreator = {
        type: getServiceType( 'paymentsCCKey', 'success' ),
        data:{
          jwk: {
            e: 'AQAB',
            kid: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5',
            kty: 'RSA',
            n: 'tev92CxyXVx7yHr_ICaQoGtp7icbPG',
            use: 'enc'
          },
          keyId: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5'
        }
      }

      let expected = {
        paymentsCCKey:{
          jwk: {
            e: 'AQAB',
            kid: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5',
            kty: 'RSA',
            n: 'tev92CxyXVx7yHr_ICaQoGtp7icbPG',
            use: 'enc'
          },
          keyId: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5'
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Payments CC key success event with failure scenario', () => {
      let actionCreator = {
        type: getServiceType( 'paymentsCCKey', 'success' ),
        data:{
          messages: {
            items: [{
              messageKey: 'CYBERSOURCE_KEY_GEN_FAILED',
              messageType: 'Error',
              messageDesc: 'Error while generating encryption keys. Use a different payment method.'
            }]
          }
        }
      }

      let expected = {
        paymentError:[{
          messageKey: 'CYBERSOURCE_KEY_GEN_FAILED',
          messageType: 'Error',
          messageDesc: 'Error while generating encryption keys. Use a different payment method.'
        }]
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

  } );

  describe( 'PAYMENTS_CC_KEY_AND_TOEKN_CASES', () => {

    it( 'Payments CC key requested events', () => {
      let actionCreator = {
        type: getServiceType( 'paymentsCCKey', 'requested' )
      }

      let expected = { paymentsCCKey: undefined };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Payments CC key success event with success scenario', () => {
      let actionCreator = {
        type: getServiceType( 'paymentsCCKey', 'success' ),
        data:{
          jwk: {
            e: 'AQAB',
            kid: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5',
            kty: 'RSA',
            n: 'tev92CxyXVx7yHr_ICaQoGtp7icbPG',
            use: 'enc'
          },
          keyId: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5'
        }
      }

      let expected = {
        paymentsCCKey:{
          jwk: {
            e: 'AQAB',
            kid: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5',
            kty: 'RSA',
            n: 'tev92CxyXVx7yHr_ICaQoGtp7icbPG',
            use: 'enc'
          },
          keyId: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5'
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Payments CC key success event with failure scenario', () => {
      let actionCreator = {
        type: getServiceType( 'paymentsCCKey', 'success' ),
        data:{
          messages: {
            items: [{
              messageKey: 'CYBERSOURCE_KEY_GEN_FAILED',
              messageType: 'Error',
              messageDesc: 'Error while generating encryption keys. Use a different payment method.'
            }]
          }
        }
      }

      let expected = {
        paymentError:[{
          messageKey: 'CYBERSOURCE_KEY_GEN_FAILED',
          messageType: 'Error',
          messageDesc: 'Error while generating encryption keys. Use a different payment method.'
        }]
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

  } );

  describe( 'PAYMENTS_CC_KEY_AND_TOEKN_CASES', () => {

    it( 'Payments CC key requested events', () => {
      let actionCreator = {
        type: getServiceType( 'paymentsCCKey', 'requested' )
      }

      let expected = { paymentsCCKey: undefined };
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Payments CC key success event with success scenario', () => {
      let actionCreator = {
        type: getServiceType( 'paymentsCCKey', 'success' ),
        data:{
          jwk: {
            e: 'AQAB',
            kid: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5',
            kty: 'RSA',
            n: 'tev92CxyXVx7yHr_ICaQoGtp7icbPG',
            use: 'enc'
          },
          keyId: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5'
        }
      }

      let expected = {
        paymentsCCKey:{
          jwk: {
            e: 'AQAB',
            kid: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5',
            kty: 'RSA',
            n: 'tev92CxyXVx7yHr_ICaQoGtp7icbPG',
            use: 'enc'
          },
          keyId: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5'
        }
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Payments CC key success event with failure scenario', () => {
      let actionCreator = {
        type: getServiceType( 'paymentsCCKey', 'success' ),
        data:{
          messages: {
            items: [{
              messageKey: 'CYBERSOURCE_KEY_GEN_FAILED',
              messageType: 'Error',
              messageDesc: 'Error while generating encryption keys. Use a different payment method.'
            }]
          }
        }
      }

      let expected = {
        paymentError:[{
          messageKey: 'CYBERSOURCE_KEY_GEN_FAILED',
          messageType: 'Error',
          messageDesc: 'Error while generating encryption keys. Use a different payment method.'
        }]
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

  } );

  describe( 'PROFILE CREDIT CARDS COUNT', () => {
    it( 'Profile Credit Cards Success Case With No Credit Cards In File', () => {
      let actionCreator = {
        type: getServiceType( 'profileCreditCards', 'success' ),
        data:{
          data: {
            profileCreditCards:{
              items: []
            }
          }
        }
      }

      let expected = {
        profileCreditCardListCount: 0,
        isPaymentCreditCardPayPalView: true,
        isPaymentDefaultCreditCardView: false,
        isProfileCreditCardListView: false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'Profile Credit Cards Success Case With Credit Cards In File', () => {
      let actionCreator = {
        type: getServiceType( 'profileCreditCards', 'success' ),
        data:{
          data:{
            profileCreditCards:{
              items: [
                {
                  creditCard: {
                    nickName: 'VISA - 4111',
                    creditCardNumber: '4111',
                    contactInfo: {}
                  }
                },
                {
                  creditCard: {
                    nickName: 'VISA - 5433',
                    creditCardNumber: '5433',
                    contactInfo: {}
                  }
                }
              ]
            }
          }
        }
      }

      let expected = {
        profileCreditCardListCount: 2
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'ALERT_WINDOW_RESIZE', () => {

    let screenHeight = 700;
    let screenWidth = 700;

    let actionCreator = {
      type: ALERT_WINDOW_RESIZE,
      screenHeight,
      screenWidth
    }

    it( 'should set `showSecurityIcon` attribute to false if the screenWidth is below 992px', () => {
      window.innerWidth = 991;
      let screenHeight = 768;
      let screenWidth = 991;
      let actionCreator1 = {
        type: ALERT_WINDOW_RESIZE,
        screenHeight,
        screenWidth
      }

      let expectedOutput1 = {
        'showSecurityIcon': false
      };
      expect( reducer( {}, actionCreator1 ) ).toEqual( expectedOutput1 );
    } );

    it( 'should set `showSecurityIcon` attribute to true if the screenWidth is above 1024px', () => {
      let screenHeight = 768;
      let screenWidth = 1025;
      let actionCreator1 = {
        type: ALERT_WINDOW_RESIZE,
        screenHeight,
        screenWidth
      }

      let expectedOutput1 = {
        'showSecurityIcon': true
      };
      expect( reducer( {}, actionCreator1 ) ).toEqual( expectedOutput1 );
    } );



  } );

  describe( 'SET_SHOW_PAYPAL_BUTTON', () => {
    it( 'should set `showPaypalButton` attribute to true when the status is set to false', () => {
      let actionCreator = {
        type: SET_SHOW_PAYPAL_BUTTON,
        status: false
      }
      let expectedOutput1 = {
        'showPaypalButton': true
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput1 );
    } );

  } )

  describe( 'Value check for isRewardPointsRemoved and isGiftCardRemoved during paymentService loading and removed', ( ) => {

    it( 'paymentServiceResponse loading should return isGiftCardRemoved as false when applying Gift Card', ( ) => {
      const res = {
        paymentType: 'giftCard'
      }
      const actionCreator2 = {
        type: getServiceType( 'paymentServiceResponse', 'loading' ),
        data: res,
        couponOfferReqNotMet: false
      }
      const expectedOutput = {
        giftCardApplying: false,
        isGiftCardRemoved: false
      }
      expect( reducer( {}, actionCreator2 ) ).toEqual( expectedOutput );

    } );

    it( 'paymentServiceResponse loading should return isRewardPointsRemoved as false when applying Rewards Points', ( ) => {
      const res = {
        paymentType: 'loyalty'
      }
      const actionCreator2 = {
        type: getServiceType( 'paymentServiceResponse', 'loading' ),
        data: res,
        couponOfferReqNotMet: false
      }
      const expectedOutput = {
        giftCardApplying: false,
        isRewardPointsRemoved: false
      }
      expect( reducer( {}, actionCreator2 ) ).toEqual( expectedOutput );

    } );

    it( 'removePaymentService success should return isRewardPointsRemoved as true when clicked on remove rewards points link', ( ) => {
      const action = {
        data:{
          paymentType: 'loyalty',
          result: {
            paymentDetails: {},
            cartSummary:{}
          }
        }
      };
      const actionCreator2 = {
        type: getServiceType( 'removePaymentService', 'success' ),
        data: action.data,
        couponOfferReqNotMet: false
      }
      const expectedOutput = {
        'checkoutServicesData': {
          'cartSummary': {},
          'paymentDetails': {}
        },
        'creditCardDetails': undefined,
        'creditCardMessages': null,
        'creditCardType': 'DefaultCreditCard',
        'editCreditCardData': {},
        'loadMaskCreditcard': false,
        'maskCreditCardNumber':null,
        'giftCardDetails': undefined,
        'isBillingAddressSameAsShipping': true,
        'isBillingAddressSameAsContactInfo': true,
        'pickupPaymentAddress':false,
        'isRewardPointsRemoved': true,
        'pointsApplied': false,
        'canDisplayPoints': true,
        'loyaltyCardDetails': {},
        'isSignedIn': undefined,
        'checkoutPanelCollapse':{
          'redeemPanel':false,
          'coupons': false,
          'giftCard': false
        },
        'payPalDetails': undefined,
        'paymentType': 'creditCard',
        'remainingPaymentDue': undefined,
        'shouldDisplayExpiryAndCvv': undefined,
        'showGiftCard': true,
        giftCardErrorMessage: null,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      }
      expect( reducer(
        {
          'checkoutPanelCollapse':{
            'redeemPanel':false,
            'coupons': false,
            'giftCard': false
          }
        }, actionCreator2
      ) ).toEqual( expectedOutput );
    } );

    it( 'removePaymentService success should return isGiftCardRemoved as true when clicked on remove rewards points link', ( ) => {
      const action = {
        data:{
          result: {
            paymentDetails: {},
            cartSummary: {},
            paymentInfo: {
              items: [{
                paymentType: 'creditCard',
                messages:null,
                nickName:'VISA - 9999',
                paymentDetails: {
                  expirationMonth:  { messages: null, value: '09' },
                  expirationYear:  { messages: null, value: '2021' },
                  creditCardNumber:  { messages: null, value: '1111' },
                  currencyCode: 'USD',
                  creditCardType:  { messages: null, value: 'Visa' }
                },
                amount: 46.18,
                currencyCode: 'USD',
                contactInfo: {
                  firstName: 'Pushpendra',
                  lastName: 'Kabdaula',
                  phoneNumber: '123-456-7890',
                  email: 'pkabdaula@ulta.com',
                  address1: '1000 remngton blvd',
                  address2: 'Ste 200',
                  city: 'Boolingbrook',
                  state: 'IL',
                  postalCode: '07105',
                  country: 'US'
                }
              }],
              remainingPaymentDue :0
            }
          }
        }
      };
      const actionCreator2 = {
        type: getServiceType( 'removePaymentService', 'success' ),
        data: action.data,
        couponOfferReqNotMet: false
      }
      const expectedOutput = {
        giftCardDetails: undefined,
        creditCardDetails:  {
          amount: 46.18,
          contactInfo:  {
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            country: 'US',
            email: 'pkabdaula@ulta.com',
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            postalCode: '07105',
            state: 'IL'
          },
          currencyCode: 'USD',
          messages: null,
          nickName: 'VISA - 9999',
          paymentDetails:  {
            expirationDate: '09/2021',
            creditCardNumber:  {
              messages: null,
              value: '1111'
            },
            creditCardType:  {
              messages: null,
              value: 'Visa'
            },
            currencyCode: 'USD',
            expirationMonth:  {
              messages: null,
              value: '09'
            },
            expirationYear:  {
              messages: null,
              value: '2021'
            }
          },
          paymentType: 'creditCard',
          showPaymentSecurityCode: true
        },
        creditCardMessages:null,
        creditCardType:'Visa',
        billingAddress: null,
        checkoutServicesData: {
          paymentDetails: {},
          cartSummary: {}
        },
        remainingPaymentDue: undefined,
        paymentType:'creditCard',
        shouldDisplayExpiryAndCvv:true,
        isSignedIn:true,
        editCreditCardData:  {
          contactInfo:  {
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city: 'Boolingbrook',
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            postalCode: '07105',
            state: 'IL'
          },
          creditCardNumber:  {
            messages: null,
            value: '1111'
          },
          creditCardType:  {
            messages: null,
            value: 'Visa'
          },
          expirationMonth:  {
            messages: null,
            value: '09'
          },
          expirationYear:  {
            messages: null,
            value: '2021'
          },
          nickName: 'VISA - 9999'
        },
        isBillingAddressSameAsShipping:false,
        isBillingAddressSameAsContactInfo: true,
        pickupPaymentAddress: {
          address1: '1000 remngton blvd',
          address2: 'Ste 200',
          city: 'Boolingbrook',
          firstName: 'Pushpendra',
          lastName: 'Kabdaula',
          phoneNumber: '123-456-7890',
          postalCode: '07105',
          state: 'IL',
          country: 'US',
          email: 'pkabdaula@ulta.com'
        },
        payPalDetails:undefined,
        loadMaskCreditcard: true,
        maskCreditCardNumber: '****1111',
        giftCardErrorMessage: null,
        showGiftCard: true,
        afterpayDetails: undefined,
        isPaymentTypeAfterPay: false,
        showAfterpayContent: false
      }
      const state = {
        isSignedIn:true
      };
      expect( reducer( state, actionCreator2 ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Clear server level error logs', ( ) => {

    describe( 'Coupon Form server level error logs', ( ) => {
      it( 'Coupon Form - should clear coupon error message upon change in coupon formdata', () => {
        let state = {
          checkoutServicesData:{
            appliedCouponSummary: {
              couponCode:'test',
              couponAppliedErrorMsg: 'code is invalid'
            }
          }
        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Coupon',
            field:'couponID'
          },
          payload: 'tes'
        }
        let expectedOutput = {
          checkoutServicesData:{
            appliedCouponSummary: {
              couponCode:'test',
              couponAppliedErrorMsg: undefined
            }
          }
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
    } );
    describe( 'Shipping Form server level error logs', ( ) => {

      let state = {
        editAddressData:{
          lastName: { value: 'lastName' },
          country: { value:'US' },
          address2: { value:null },
          city: { value:'city' },
          address1: { value:'address1' },
          postalCode: { value:'99999' },
          firstName: { value:'firstname' },
          phoneNumber:{ value: '111-111-1111' },
          state:{ value: 'AP' },
          email:{ value: 'test@ulta.com' }
        },
        checkoutServicesData:{
          shippingInfo: {
            shippingAddress: {
              lastName: 'lastName',
              country: 'US',
              address2: null,
              city: 'city',
              address1: 'address1',
              postalCode: '99999',
              firstName: 'firstname',
              phoneNumber: '111-111-1111',
              state: 'AP',
              email: 'test@ulta.com'
            }
          }
        },
        shippingErrorMessages: [
          {
            messageKey: 'ERR_SHIPPING_INVALID_ADDRESS',
            messageType: 'Error',
            messageRef: 'shipAddrInfo',
            messageDesc: 'Please enter a valid address and re-submit.'
          }
        ]
      }

      let expectedOutput = {
        editAddressData:{
          lastName: { value: 'lastName' },
          country: { value:'US' },
          address2: { value:null },
          city: { value:'city' },
          address1: { value:'address1' },
          postalCode: { value:'99999' },
          firstName: { value:'firstname' },
          phoneNumber:{ value: '111-111-1111' },
          state:{ value: 'AP' },
          email:{ value: 'test@ulta.com' }
        },
        checkoutServicesData:{
          shippingInfo: {
            shippingAddress: {
              lastName: 'lastName',
              country: 'US',
              address2: null,
              city: 'city',
              address1: 'address1',
              postalCode: '99999',
              firstName: 'firstname',
              phoneNumber: '111-111-1111',
              state: 'AP',
              email: 'test@ulta.com'
            }
          }
        },
        isShippingAddressErrorCleared : true,
        shippingErrorMessages:null
      }

      it( 'Shipping Form - should set activeField in the state on focus of addressline1', () => {
        const action = {
          type: ReduxActionType.FOCUS,
          meta:{
            form:'Shipping',
            field:'address1shippingAddressForm'
          },
          payload: 'addressLine1'
        }
        const tempState = { activeField:'' } ;
        const formFocusExpectedOutput = { activeField:'address1shippingAddressForm' };
        expect( reducer( tempState, action ) ).toEqual( formFocusExpectedOutput );
      } );

      it( 'Shipping Form - should clear Shipping error message upon change in addressline1 of Shippingform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'address1shippingAddressForm'
          },
          payload: 'addressLine1'
        }
        state.activeField = 'address1shippingAddressForm';
        expectedOutput.activeField = 'address1shippingAddressForm';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Shipping Form - should clear Shipping error message upon change in addressline2 of Shippingform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'address2shippingAddressForm'
          },
          payload: 'addressLine2'
        }
        state.activeField = 'address2shippingAddressForm';
        expectedOutput.activeField = 'address2shippingAddressForm';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Shipping Form - should clear Shipping error message upon change in postalCode of Shippingform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'postalCodeshippingAddressForm'
          },
          payload: '88888'
        }
        state.activeField = 'postalCodeshippingAddressForm';
        expectedOutput.activeField = 'postalCodeshippingAddressForm';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Shipping Form - should clear Shipping error message upon change in city of Shippingform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'cityshippingAddressForm'
          },
          payload: 'cit'
        }
        state.activeField = 'cityshippingAddressForm';
        expectedOutput.activeField = 'cityshippingAddressForm';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Shipping Form - should clear Shipping error message upon change in state of Shippingform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'state'
          },
          payload: 'A'
        }
        state.activeField = 'state';
        expectedOutput.activeField = 'state';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
      it( 'Shipping Form - should clear Shipping error message upon change in state of Shippingform data, even if activefield is not set for state', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'Shipping',
            field:'state'
          },
          payload: 'A'
        }
        state.activeField = '';
        expectedOutput.activeField = '';
        const actual = reducer( state, action );
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
    } );

    describe( 'Payment Form server level error logs', ( ) => {

      let state = {
        paymentError : [{
          messageKey: 'errorCardInvExpirationYear',
          messageType: 'Error',
          messageRef: 'paymentInfo.paymentDetails.expirationYear',
          messageDesc: 'Enter valid expiration date'
        }],
        creditCardDetails :{
          paymentDetails:{
            creditCardNumber : { value:'9887' },
            creditCardType : { value:'visa' },
            expirationMonth : { value:'11' },
            expirationYear: { value:'3333' }
          },
          messages:[{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }]
        }
      }
      let expectedOutput = {
        paymentError : [],
        creditCardDetails :{
          paymentDetails:{
            creditCardNumber : { value:'9887' },
            creditCardType : { value:'visa' },
            expirationMonth : { value:'11' },
            expirationYear: { value:'3333' }
          },
          messages:[]
        },
        loadMaskCreditcard: false,
        isPaymentErrorCleared : true,
        creditCardMessages:null
      }

      it( 'Payment Form - should clear Payment error message upon change in creditcardnumber of paymentform data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'paymentForm',
            field:'creditCardNumber'
          },
          payload: '****988'
        }
        state.activeField = 'creditCardNumber';
        expectedOutput.activeField = 'creditCardNumber';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Payment Form - should return the state if  no Payment error message and activeField is creditCardNumber', () => {
        let state = {
          paymentError : null,
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber : { value:'9887' },
              creditCardType : { value:'visa' },
              expirationMonth : { value:'11' },
              expirationYear: { value:'3333' }
            },
            messages:null
          },
          activeField :'creditCardNumber'
        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'paymentForm',
            field:'creditCardNumber'
          },
          payload: '****988'
        }
        let expectedOutput = {
          paymentError : null,
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber : { value:'9887' },
              creditCardType : { value:'visa' },
              expirationMonth : { value:'11' },
              expirationYear: { value:'3333' }
            },
            messages:null
          },
          loadMaskCreditcard: false
        }
        expectedOutput.activeField = 'creditCardNumber';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Payment Form - should return the state if  no Payment error message and activeField isnot creditCardNumber', () => {
        let state = {
          paymentError : null,
          creditCardDetails :null,
          activeField :'expirationDate'
        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'paymentForm',
            field:'creditCardNumber'
          },
          payload: '****988'
        }
        let expectedOutput = {
          paymentError : null,
          creditCardDetails :null,
          activeField :'expirationDate'
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Payment Form - should clear Payment error message upon change in expirationDate of paymentform data', () => {
        let state = {
          paymentError : [{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }],
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber : { value:'9887' },
              creditCardType : { value:'visa' },
              expirationMonth : { value:'11' },
              expirationYear: { value:'3333' }
            },
            messages:[{
              messageKey: 'errorCardInvExpirationYear',
              messageType: 'Error',
              messageRef: 'paymentInfo.paymentDetails.expirationYear',
              messageDesc: 'Enter valid expiration date'
            }]
          }
        }
        let expectedOutput = {
          paymentError : [],
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber : { value:'9887' },
              creditCardType : { value:'visa' },
              expirationMonth : { value:'11' },
              expirationYear: { value:'3333' }
            },
            messages:[]
          },
          isPaymentErrorCleared : true,
          creditCardMessages:null
        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'paymentForm',
            field:'expirationDate'
          },
          payload: '11/2022'
        }
        state.activeField = 'expirationDate';
        expectedOutput.activeField = 'expirationDate';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Payment Form - should clear Payment error message upon change in securityCode of paymentform data -cardType :visa', () => {
        let state = {
          paymentError : [{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }],
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber : { value:'9887' },
              creditCardType : { value:'visa' },
              expirationMonth : { value:'11' },
              expirationYear: { value:'3333' }
            },
            messages:[{
              messageKey: 'errorCardInvExpirationYear',
              messageType: 'Error',
              messageRef: 'paymentInfo.paymentDetails.expirationYear',
              messageDesc: 'Enter valid expiration date'
            }]
          }
        }
        let expectedOutput = {
          paymentError : [],
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber : { value:'9887' },
              creditCardType : { value:'visa' },
              expirationMonth : { value:'11' },
              expirationYear: { value:'3333' }
            },
            messages:[]
          },
          isPaymentErrorCleared : true,
          creditCardMessages:null
        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'paymentForm',
            field:'securityCode'
          },
          payload: '11'
        }
        state.activeField = 'securityCode';
        expectedOutput.activeField = 'securityCode';
        expectedOutput.showSecurityIcon = true;
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Payment Form - should clear Payment error message upon change in securityCode of paymentform data -cardType :AmericanExpress', () => {
        state = {
          paymentError : [{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }],
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber : { value:'9887' },
              creditCardType : { value:'AmericanExpress' },
              expirationMonth : { value:'11' },
              expirationYear: { value:'3333' }
            },
            messages:[{
              messageKey: 'errorCardInvExpirationYear',
              messageType: 'Error',
              messageRef: 'paymentInfo.paymentDetails.expirationYear',
              messageDesc: 'Enter valid expiration date'
            }]
          }
        }
        expectedOutput = {
          paymentError : [],
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber : { value:'9887' },
              creditCardType : { value:'AmericanExpress' },
              expirationMonth :{ value:'11' },
              expirationYear: { value:'3333' }
            },
            messages:[]
          },
          isPaymentErrorCleared : true,
          showSecurityIcon: true,
          creditCardMessages:null
        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'paymentForm',
            field:'securityCode'
          },
          payload: '111'
        }
        state.activeField = 'securityCode';
        expectedOutput.activeField = 'securityCode';
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
    } );

    describe( 'Gift card Form server level error logs', ( ) => {
      let state = {
        giftCardDetails:{
          messages:[{
            messageKey: 'invalidPin',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.giftCardPin',
            messageDesc: 'Enter valid pin number'
          }],
          paymentInfo: {
            amount: 0,
            paymentType: 'giftCard',
            paymentDetails: {
              giftcardNumber: '7777082394783534',
              giftcardBalance: 0,
              currencyCode: 'USD'
            }
          }
        }
      }
      let expectedOutput = {
        giftCardDetails:{
          messages:[
            {
              messageDesc: 'Enter valid pin number',
              messageKey: 'invalidPin',
              messageRef: 'paymentInfo.paymentDetails.giftCardPin',
              messageType: 'Error'
            }
          ],
          paymentInfo: {
            amount: 0,
            paymentType: 'giftCard',
            paymentDetails: {
              giftcardNumber: '7777082394783534',
              giftcardBalance: 0,
              currencyCode: 'USD'
            }
          }
        }
      }

      it( 'GiftCard Form - should clear error message upon change in giftcard number of giftCard form data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'giftCard',
            field:'giftCardNumber'
          },
          payload: '777708239478353'
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'GiftCard Form - should clear error message upon change in giftCardPin of giftCard form data', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'giftCard',
            field:'giftCardPin'
          },
          payload: '1234567'
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'isPaymentFieldUpdated method should return false when creditCardDetails state object is empty', () => {
        let state = {
          creditCardDetails: {}
        };
        expect( isPaymentFieldUpdated( state, 'creditCardNumber', '1111' ) ).toBeFalsy();
      } );

    } );
    describe( 'clear server level error log when we click change creditcard option', ( )=> {
      let state = {
        creditCardDetails :{
          paymentInfo:{
            paymentDetails:{
              creditCardNumber : '9887',
              creditCardType : 'visa',
              expirationMonth : '11',
              expirationYear: '3333'
            }
          },
          messages:[{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }]
        }
      }
      let expectedOutput = {
        paymentError : [],
        creditCardDetails :{
          paymentInfo:{
            paymentDetails:{
              creditCardNumber : '9887',
              creditCardType : 'visa',
              expirationMonth : '11',
              expirationYear: '3333'
            }
          },
          messages: null
        }
      }
      it( 'Profile Credit Cards request Case', () => {
        let state = {
          paymentError : [{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }],
          creditCardDetails :{
            paymentInfo:{
              paymentDetails:{
                creditCardNumber : '9887',
                creditCardType : 'visa',
                expirationMonth : '11',
                expirationYear: '3333'
              }
            },
            messages:[{
              messageKey: 'errorCardInvExpirationYear',
              messageType: 'Error',
              messageRef: 'paymentInfo.paymentDetails.expirationYear',
              messageDesc: 'Enter valid expiration date'
            }]
          }
        }
        let actionCreator = {
          type: getServiceType( 'profileCreditCards', 'requested' ),
          data:{
            profileCreditCards:[]
          }
        }
        expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
      } );
    } )
    describe( 'PaymentCCSecurityCode form clear server level ', ( )=> {
      let state = {
        paymentError : [{
          messageKey: 'errorCardInvExpirationYear',
          messageType: 'Error',
          messageRef: 'paymentInfo.paymentDetails.expirationYear',
          messageDesc: 'Enter valid expiration date'
        }],
        creditCardDetails :{
          paymentDetails:{
            creditCardNumber : { value:'9887' },
            creditCardType : { value:'visa' },
            expirationMonth : { value:'11' },
            expirationYear: { value:'3333' }
          },
          messages:[{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }]
        }
      }
      let expectedOutput = {
        paymentError : [],
        creditCardDetails :{
          paymentDetails:{
            creditCardNumber : { value:'9887' },
            creditCardType : { value:'visa' },
            expirationMonth : { value:'11' },
            expirationYear: { value:'3333' }
          },
          messages:[]
        },
        showSecurityIcon: true,
        isPaymentErrorCleared:true,
        creditCardMessages:null
      }
      it( 'Payment Form - should clear Payment error message upon change in securityCode of paymentform data -cardType :visa', () => {
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'PaymentCCSecurityCode',
            field:'ccSecurityCode'
          },
          payload: '11'
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Payment Form - should return the state and showSecurityIcon if there is no Payment error message ', () => {
        state = {
          paymentError : null,
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber :{ value:'9887' },
              creditCardType :  { value:'AmericanExpress' },
              expirationMonth :  { value:'11' },
              expirationYear:  { value:'3333' }
            },
            messages:null
          }
        }
        expectedOutput = {
          paymentError : null,
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber :{ value:'9887' },
              creditCardType :  { value:'AmericanExpress' },
              expirationMonth :  { value:'11' },
              expirationYear:  { value:'3333' }
            },
            messages:null
          },
          showSecurityIcon: true

        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'PaymentCCSecurityCode',
            field:'ccSecurityCode'
          },
          payload: '111'
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );

      it( 'Payment Form - should clear Payment error message upon change in securityCode of paymentform data -cardType :AmericanExpress', () => {
        state = {
          paymentError : [{
            messageKey: 'errorCardInvExpirationYear',
            messageType: 'Error',
            messageRef: 'paymentInfo.paymentDetails.expirationYear',
            messageDesc: 'Enter valid expiration date'
          }],
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber :{ value:'9887' },
              creditCardType :  { value:'AmericanExpress' },
              expirationMonth :  { value:'11' },
              expirationYear:  { value:'3333' }
            },
            messages:[{
              messageKey: 'errorCardInvExpirationYear',
              messageType: 'Error',
              messageRef: 'paymentInfo.paymentDetails.expirationYear',
              messageDesc: 'Enter valid expiration date'
            }]
          }
        }
        expectedOutput = {
          paymentError : [],
          creditCardDetails :{
            paymentDetails:{
              creditCardNumber : { value:'9887' },
              creditCardType : { value:'AmericanExpress' },
              expirationMonth : { value:'11' },
              expirationYear: { value:'3333' }
            },
            messages:[]
          },
          showSecurityIcon: true,
          creditCardMessages: null,
          isPaymentErrorCleared: true
        }
        let action = {
          type: ReduxActionType.CHANGE,
          meta:{
            form:'PaymentCCSecurityCode',
            field:'ccSecurityCode'
          },
          payload: '111'
        }
        expect( reducer( state, action ) ).toEqual( expectedOutput );
      } );
    } );
  } );

  describe( 'CheckoutPage unmount', () => {
    it( 'should set isCheckoutDataAvailable to false when leaving CheckoutPage', () => {
      let actionCreator = {
        type: RESET_CHECKOUT_DATA_AVAILABLE
      };

      let excepted = {
        isCheckoutDataAvailable: false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( excepted );
    } );
  } );

  it( 'messageSort should return expected output', () => {
    const mockState = {
      paymentType: 'creditCard'
    }
    const data = {
      'success': false,
      'shippingInfo': null,
      'paymentInfo': {
        'messages': {
          'items': [{
            'type': 'Error',
            'message': 'Please enter a valid Security Code.'
          }]
        }
      },
      'cartItems': {
        'messages': {
          'items': [{
            'type': 'error',
            'message': 'SKU 12345 is Out of Stock'
          }]
        }
      },
      'messages': {
        'items': [{
          'type': 'error',
          'message': 'Error commitiing error'
        }]
      }
    }
    const expected =   {
      'anchorAfterSubmitServiceCall': 'header',
      'checkoutError': [{
        'message': 'Error commitiing error',
        'type': 'error'
      }],
      'creditCardMessages': [{
        'message': 'Please enter a valid Security Code.',
        'type':'Error'
      }],
      'navigateToCartPage': true,
      'shippingErrorMessages': null
    };
    expect( messageSort( data, mockState ) ).toEqual( expected );
  } );

  it( 'messageSort should not set creditCardMessages if paymentType is not creditCard', () => {
    const mockState = {
      paymentType: 'afterpay'
    }
    const creditCardMessages = [{
      'message': 'Please enter a valid Security Code.',
      'type':'Error'
    }]
    const data = {
      'paymentInfo': {
        'messages': {
          'items': creditCardMessages
        }
      }
    }
    expect( messageSort( data, mockState ).creditCardMessages ).toEqual( null );
  } );

  it( 'should set the pickupInfo with data', () => {

    let action = {
      'result': {
        'pickupInfo':{
          'primaryContactInfo': {
            'firstName': 'Teenu',
            'lastName': 'Jacob',
            'phoneNumber': '1234567876',
            'email': 'teenu.jacob@ulta.com'
          }
        },
        'result':{
          'pickupInfo': {}
        },
        'smsCommunicationInfo' : {
          'promotionalContactInfo' : {
            'optInStatus' : false,
            'phoneNumber' : '(222) 222 1111'
          },
          'transactionalContactInfo' : {
            'optInStatus' : true,
            'phoneNumber' : '(222) 222 2222'
          }
        }
      }
    }

    let state = {
      checkoutServicesData: {
        cartSummary: {
          shippingCost: 'TBD',
          subTotal: 5.99,
          itemCount: 1,
          orderGiftWrapAmt: 0,
          additionalDiscount: null,
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftCard: null,
          rewardPointsDiscount: null,
          estimatedTotal: 5.99,
          rewardPointsEarned: null,
          currencyCode: 'USD'
        },
        shippingInfo:{
          shippingAddress:null,
          messages:null
        }
      },
      isBillingAddressSameAsContactInfo: true,
      pickupSmsOptInStatus: false,
      pickupMobileNumber: undefined
    }

    let actionCreator = {
      type: getServiceType( 'pickupContactInfoUpdate', 'success' ),
      data: action
    }

    let expectedOutput = {
      checkoutServicesData: {
        cartSummary: {
          shippingCost: 'TBD',
          subTotal: 5.99,
          itemCount: 1,
          orderGiftWrapAmt: 0,
          additionalDiscount: null,
          couponDiscount: 0,
          estimatedTax: 'TBD',
          giftCard: null,
          rewardPointsDiscount: null,
          estimatedTotal: 5.99,
          rewardPointsEarned: null,
          currencyCode: 'USD'
        },
        shippingInfo:{
          shippingAddress:null,
          messages:null
        },
        pickupInfo:{
          primaryContactInfo: {
            firstName: 'Teenu',
            lastName: 'Jacob',
            phoneNumber: '1234567876',
            email: 'teenu.jacob@ulta.com'
          }
        }
      },
      pickupPaymentAddress: {
        firstName: 'Teenu',
        lastName: 'Jacob',
        phoneNumber: '1234567876',
        email: 'teenu.jacob@ulta.com'
      },
      isBillingAddressSameAsContactInfo: true,
      pickupSmsOptInStatus: true,
      pickupMobileNumber: '(222) 222 2222'
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'BILLING_ADDRESS_SAME_AS_CONTACT_INFO should set isBillingAddressSameAsContactInfo, pickupPaymentAddress if it has primaryContactInfo', () => {
    const pickupInfo = {
      primaryContactInfo: {
        firstName: 'Jane',
        lastName: 'Doe',
        phoneNumber: '1234567876',
        email: 'test@ulta.com'
      }
    };
    let action = {
      pickupInfo
    }

    let state = {
      checkoutServicesData: {
        pickupInfo
      },
      isBillingAddressSameAsContactInfo: true
    }

    let actionCreator = {
      type: BILLING_ADDRESS_SAME_AS_CONTACT_INFO,
      data: action
    }

    let expectedOutput = {
      checkoutServicesData: {
        pickupInfo:{
          primaryContactInfo: {
            firstName: 'Jane',
            lastName: 'Doe',
            phoneNumber: '1234567876',
            email: 'test@ulta.com'
          }
        }
      },
      pickupPaymentAddress: {
        firstName: 'Jane',
        lastName: 'Doe',
        phoneNumber: '1234567876',
        email: 'test@ulta.com'
      },
      isBillingAddressSameAsContactInfo: {
        pickupInfo:{
          primaryContactInfo: {
            firstName: 'Jane',
            lastName: 'Doe',
            phoneNumber: '1234567876',
            email: 'test@ulta.com'
          }
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'BILLING_ADDRESS_SAME_AS_CONTACT_INFO should set clear address form fields if it does not have primaryContactInfo', () => {
    const pickupInfo = {
      primaryContactInfo: {
        firstName: 'Jane',
        lastName: 'Doe',
        phoneNumber: '1234567876',
        email: 'test@ulta.com'
      }
    };
    const action = {
      pickupInfo
    }

    let state = {
      checkoutServicesData: {}
    }

    let actionCreator = {
      type: BILLING_ADDRESS_SAME_AS_CONTACT_INFO,
      data: action
    }

    let expectedOutput = {
      checkoutServicesData: {},
      pickupPaymentAddress: {
        firstName:{ value:'' },
        lastName:{ value:'' },
        phoneNumber:{ value:'' }
      },
      isBillingAddressSameAsContactInfo: false
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  describe( 'isBillingAddressSameAsShipping method', ()=>{

    it( 'should return true if all the values of shipping address and billing address is equal', ()=>{
      let addressData = {
        firstName:{
          value:'test'
        },
        lastName:{
          value:'test'
        },
        address1:{
          value:'test'
        },
        address2:{
          value:null
        },
        state:{
          value:'test'
        },
        city:{
          value:'test'
        },
        phoneNumber:{
          value:'test'
        },
        postalCode:{
          value:'123456'
        }
      };
      let shippingInfo = {
        shippingAddress:{
          firstName:{
            value:'test'
          },
          lastName:{
            value:'test'
          },
          address1:{
            value:'test'
          },
          address2:{
            value:null
          },
          state:{
            value:'test'
          },
          city:{
            value:'test'
          },
          phoneNumber:{
            value:'test'
          },
          postalCode:{
            value:'123456'
          }
        }
      }
      expect( isBillingAddressSameAsShipping( addressData, shippingInfo ) ).toEqual( true )
    } );

    it( 'should return false if all the firstName of shipping address and billing address is not equal', ()=>{
      let addressData = {
        firstName:{
          value:'test1'
        },
        lastName:{
          value:'test'
        },
        address1:{
          value:'test'
        },
        address2:{
          value:null
        },
        state:{
          value:'test'
        },
        city:{
          value:'test'
        },
        phoneNumber:{
          value:'test'
        },
        postalCode:{
          value:'123456'
        }
      };
      let shippingInfo = {
        shippingAddress:{
          firstName:{
            value:'test'
          },
          lastName:{
            value:'test'
          },
          address1:{
            value:'test'
          },
          address2:{
            value:null
          },
          state:{
            value:'test'
          },
          city:{
            value:'test'
          },
          phoneNumber:{
            value:'test'
          },
          postalCode:{
            value:'123456'
          }
        }
      }
      expect( isBillingAddressSameAsShipping( addressData, shippingInfo ) ).toEqual( false )
    } )

    it( 'should return false if all the lastName of shipping address and billing address is not equal', ()=>{
      let addressData = {
        firstName:{
          value:'test'
        },
        lastName:{
          value:'test1'
        },
        address1:{
          value:'test'
        },
        address2:{
          value:null
        },
        state:{
          value:'test'
        },
        city:{
          value:'test'
        },
        phoneNumber:{
          value:'test'
        },
        postalCode:{
          value:'123456'
        }
      };
      let shippingInfo = {
        shippingAddress:{
          firstName:{
            value:'test'
          },
          lastName:{
            value:'test'
          },
          address1:{
            value:'test'
          },
          address2:{
            value:null
          },
          state:{
            value:'test'
          },
          city:{
            value:'test'
          },
          phoneNumber:{
            value:'test'
          },
          postalCode:{
            value:'123456'
          }
        }
      }
      expect( isBillingAddressSameAsShipping( addressData, shippingInfo ) ).toEqual( false )
    } )

  } )

  describe( 'ADD_EDIT_PAYMENT_METHOD', () => {
    it( 'should set proper payment views and details on click of add new card', () => {
      let actionCreator = {
        type: ADD_EDIT_PAYMENT_METHOD,
        data: { }
      }
      let expectedOutput1 = {
        'billingAddress': false,
        'checkoutServicesData':  {
          'shippingInfo': null
        },
        'creditCardType': 'DefaultCreditCard',
        'editAddressData': {},
        'editCreditCardData': {},
        'isBillingAddressSameAsShipping': true,
        'isPaymentAddEditMode': true,
        'isPaymentCreditCardPayPalView': true,
        'isPaymentDefaultCreditCardView': false,
        'isProfileCreditCardListView': false,
        'loadMaskCreditcard': false,
        'maskCreditCardNumber': null,
        'paymentType': 'creditCard',
        'shouldDisplayExpiryAndCvv': undefined,
        'showUltamateRewardsCreditCard': false,
        'isPaymentTypeAfterPay': false
      };
      let state = {
        checkoutServicesData:{
          shippingInfo:null
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput1 );
    } );

    it( 'should set proper payment views and details on click of edit saved card', () => {
      let actionCreator = {
        type: ADD_EDIT_PAYMENT_METHOD,
        data: {
          'firstName': {
            'value': 'test'
          },
          'lastName': {
            'value': 'test'
          },
          'phoneNumber': {
            'value': '424-242-4242'
          },
          'addressData':{
            'country': {
              'value': 'US'
            },
            'address2': {
              'value': null
            },
            'city': {
              'value': 'Orlando'
            },
            'address1': {
              'value': '255 E Concord St'
            },
            'postalCode': {
              'value': '32801'
            },
            'state': {
              'value': 'FL'
            },
            'email': {
              'value': '9003517@ulta.com'
            }
          }
        }
      }
      let expectedOutput1 = {
        'billingAddress':{
          'firstName': {
            'value': 'test'
          },
          'lastName': {
            'value': 'test'
          },
          'phoneNumber': {
            'value': '424-242-4242'
          },
          'country': {
            'value': 'US'
          },
          'address2': {
            'value': null
          },
          'city': {
            'value': 'Orlando'
          },
          'address1': {
            'value': '255 E Concord St'
          },
          'postalCode': {
            'value': '32801'
          },
          'state': {
            'value': 'FL'
          },
          'email': {
            'value': '9003517@ulta.com'
          }
        },
        'checkoutServicesData':  {
          'shippingInfo': {
            shippingAddress:{
              'firstName': {
                'value': 'test'
              },
              'lastName': {
                'value': 'test'
              },
              'country': {
                'value': 'US'
              },
              'phoneNumber': {
                'value': '424-242-4242'
              },
              'address2': {
                'value': null
              },
              'city': {
                'value': 'Orlando'
              },
              'address1': {
                'value': '255 E Concord St'
              },
              'postalCode': {
                'value': '32801'
              },
              'state': {
                'value': 'FL'
              },
              'email': {
                'value': '9003517@ulta.com'
              }
            }
          }
        },
        'creditCardType': 'DefaultCreditCard',
        'editAddressData': {},
        'editCreditCardData': {
          nickName: actionCreator.data.nickName,
          creditCardType: actionCreator.data.creditCardType,
          creditCardNumber: actionCreator.data.creditCardNumber,
          expirationMonth: actionCreator.data.expirationMonth,
          expirationYear: actionCreator.data.expirationYear,
          isPrimary: actionCreator.data.isPrimary,
          contactInfo:{
            'address1':  {
              'value': '255 E Concord St'
            },
            'address2':  {
              'value': null
            },
            'city':  {
              'value': 'Orlando'
            },
            'firstName':  {
              'value': 'test'
            },
            'lastName':  {
              'value': 'test'
            },
            'phoneNumber':  {
              'value': '424-242-4242'
            },
            'postalCode':  {
              'value': '32801'
            },
            'state':  {
              'value': 'FL'
            }
          }
        },
        'isBillingAddressSameAsShipping': true,
        'isPaymentAddEditMode': true,
        'isPaymentCreditCardPayPalView': true,
        'isPaymentDefaultCreditCardView': false,
        'isProfileCreditCardListView': false,
        'loadMaskCreditcard': false,
        'maskCreditCardNumber': null,
        'paymentType': 'creditCard',
        'shouldDisplayExpiryAndCvv': undefined,
        'showUltamateRewardsCreditCard': false,
        'isPaymentTypeAfterPay': false
      };
      let state = {
        checkoutServicesData:{
          shippingInfo:{
            shippingAddress:{
              'firstName': {
                'value': 'test'
              },
              'lastName': {
                'value': 'test'
              },
              'country': {
                'value': 'US'
              },
              'phoneNumber': {
                'value': '424-242-4242'
              },
              'address2': {
                'value': null
              },
              'city': {
                'value': 'Orlando'
              },
              'address1': {
                'value': '255 E Concord St'
              },
              'postalCode': {
                'value': '32801'
              },
              'state': {
                'value': 'FL'
              },
              'email': {
                'value': '9003517@ulta.com'
              }
            }
          }
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput1 );
    } );
  } )

  describe( 'BILLING_ADDRESS_SAME_AS_SHIPPING', () =>{

    it( 'BILLING_ADDRESS_SAME_AS_SHIPPING should set billingAddress same as shippingAddress if it has shippingInfo.shippingAddress', () => {
      const shippingInfo = {
        shippingAddress: {
          lastName: {
            value: 'User'
          },
          country: {
            value: 'US'
          },
          city: {
            value: 'Chicago'
          },
          address1: {
            value: 'Street 20'
          },
          postalCode: {
            value: '60603'
          },
          firstName: {
            value: 'Test '
          },
          phoneNumber: {
            value: '123-455-6677'
          },
          state: {
            value: 'IL'
          },
          email: {
            value: 'test@ulta.com'
          }
        },
        messages: null
      };

      let state = {
        checkoutServicesData: {
          shippingInfo
        },
        isBillingAddressSameAsShipping:true,
        editCreditCardData:{
          contactInfo:{
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city : 'Boolingbrook',
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            postalCode: '07105',
            state: 'IL'
          },
          creditCardNumber:{
            messages: null,
            value: '1111'
          },
          creditCardType:{
            messages: null,
            value:'Visa'
          },
          'expirationMonth': {
            messages: null,
            value: '09'
          },
          expirationYear:{
            messages: null,
            value: 2021
          },
          nickName: 'VISA - 9999'
        }
      }

      let actionCreator = {
        type: BILLING_ADDRESS_SAME_AS_SHIPPING,
        data: true
      }

      let expectedOutput = {
        checkoutServicesData: {
          shippingInfo:{
            shippingAddress: {
              lastName: {
                value: 'User'
              },
              country: {
                value: 'US'
              },
              city: {
                value: 'Chicago'
              },
              address1: {
                value: 'Street 20'
              },
              postalCode: {
                value: '60603'
              },
              firstName: {
                value: 'Test '
              },
              phoneNumber: {
                value: '123-455-6677'
              },
              state: {
                value: 'IL'
              },
              email: {
                value: 'test@ulta.com'
              }
            },
            messages: null
          }
        },
        billingAddress: shippingInfo.shippingAddress,
        isBillingAddressSameAsShipping: true,
        paymentSuccess: false,
        editCreditCardData: {
          contactInfo:{
            address1: '1000 remngton blvd',
            address2: 'Ste 200',
            city : 'Boolingbrook',
            firstName: 'Pushpendra',
            lastName: 'Kabdaula',
            phoneNumber: '123-456-7890',
            postalCode: '07105',
            state: 'IL'
          },
          creditCardNumber:{
            messages: null,
            value: '1111'
          },
          creditCardType:{
            messages: null,
            value:'Visa'
          },
          'expirationMonth': {
            messages: null,
            value: '09'
          },
          expirationYear:{
            messages: null,
            value: 2021
          },
          nickName: 'VISA - 9999'
        }
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'BILLING_ADDRESS_SAME_AS_SHIPPING should set isBillingAddressSameAsShipping as false if shippingInfo is not present', () => {

      let state = {
        checkoutServicesData: {},
        isBillingAddressSameAsShipping: true
      }

      let actionCreator = {
        type: BILLING_ADDRESS_SAME_AS_SHIPPING,
        data: true
      }

      let expectedOutput = {
        checkoutServicesData: {},
        billingAddress: null,
        editCreditCardData: {},
        isBillingAddressSameAsShipping: false,
        paymentSuccess:false
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Login', () =>{

    it( 'login success should set cartMerged flag', () => {
      const state = {
        cartMerged: false
      }
      const actionCreator = {
        type: getServiceType( 'login', 'success' ),
        data: {
          res: {
            cartMerged: true
          }
        }
      }

      const expectedOutput = {
        cartMerged: true,
        reloadCheckoutPage:false
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'LOGIN SUCCESS', () => {
    it( 'should set cartMerged as false and reloadCheckoutPage as true user successfully login and carttMerged in response is false', () => {
      let actionCreator = {
        type: getServiceType( 'login', 'success' ),
        data: { res: { cartMerged:false, success:true } }
      }
      let expectedOutput1 = {
        cartMerged:false,
        reloadCheckoutPage:true
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput1 );
    } );

    it( 'should set cartMerged as true if logged in user have an exisitng item in cart (cartMerged:true)', () => {
      let actionCreator = {
        type: getServiceType( 'login', 'success' ),
        data: { res: { cartMerged:true } }
      }
      let expectedOutput1 = {
        cartMerged:true,
        reloadCheckoutPage:false
      }
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput1 );
    } );
  } )

  describe( 'afterpay services', () => {
    it( 'should set showAfterpay as false for afterpay loading', () => {
      let actionCreator = {
        type: getServiceType( 'afterpay', 'loading' )
      }

      let expected = { showAfterpay: false };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'should set showAfterpay as true for afterpay success', () => {
      const mockState = {
        showAfterpay: false,
        afterpayEnabled: true
      }
      let actionCreator = {
        type: getServiceType( 'afterpay', 'success' )
      }
      let expected = {
        showAfterpay: true,
        enableAfterpay: true,
        afterpayEnabled: true
      }
      expect( reducer( mockState, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'switches services', () => {

    it( 'should set afterpayEnabled as true if enableAfterpay is returned as true', () => {
      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data: {
          switches: {
            enableAfterpay: true
          }
        }
      }

      let expected = { afterpayEnabled: true };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );

    it( 'should set afterpayEnabled as false if enableAfterpay is returned as false', () => {
      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data: {
          switches: {
            enableAfterpay: false
          }
        }
      }

      let expected = { afterpayEnabled: false };

      expect( reducer( {}, actionCreator ) ).toEqual( expected );
    } );
  } );

  describe( 'updatePickupSmsInfo method', ()=>{
    it( 'should return pickupSmsOptInStatus and pickupMobileNumber from smsCommunicationInfo if smsCommunicationInfo is not empty', ()=>{
      const action = {
        data:{
          result: {
            smsCommunicationInfo : {
              promotionalContactInfo : {
                optInStatus : true,
                phoneNumber : '(111) 111 2222'
              },
              transactionalContactInfo : {
                optInStatus : true,
                phoneNumber : '(111) 111 1111'
              }
            }
          }
        }
      }
      const mockState = {
        pickupSmsOptInStatus :false,
        pickupMobileNumber : undefined
      }
      expect( updatePickupSmsInfo( action, mockState ) ).toEqual( {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: '(111) 111 1111'
      } );
    } );

    it( 'should return pickupSmsOptInStatus and pickupMobileNumber from checkout store if smsCommunicationInfo is empty', ()=>{
      const action = {
        data:{
          result: {
            smsCommunicationInfo : {}
          }
        }
      }
      const mockState = {
        pickupSmsOptInStatus :true,
        pickupMobileNumber : '(111) 111 1111'
      }
      expect( updatePickupSmsInfo( action, mockState ) ).toEqual( {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: '(111) 111 1111'
      } );
    } );

    it( 'should return pickupSmsOptInStatus and pickupMobileNumber from local storage if local storage has pickupSmsInfo', ()=>{
      retrievePickupSmsInfo.mockImplementation( () => {
        return {
          optInStatus : true,
          mobileNumber : '(111) 111 1111'
        };
      } );

      const action = {
        data:{
          result: {
            smsCommunicationInfo : {
              promotionalContactInfo : {
                optInStatus : true,
                phoneNumber : '(222) 222 2222'
              },
              transactionalContactInfo : {
                optInStatus : true,
                phoneNumber : '(222) 222 2222'
              }
            }
          }
        }
      }
      const mockState = {
        pickupSmsOptInStatus :false,
        pickupMobileNumber : '(333) 333 3333'
      }
      expect( updatePickupSmsInfo( action, mockState ) ).toEqual( {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: '(111) 111 1111'
      } );
    } );
  } );

  describe( 'populatePickupSmsInfo method', ()=>{
    it( 'should set pickupSmsOptInStatus as !data.pickupSmsOptInStatus which is passed as input if type is toggleOptinSms', ()=>{
      const type = 'toggleOptinSms';
      jest.resetAllMocks();
      const data = {
        pickupSmsOptInStatus : false
      }
      const mockState = {
        pickupSmsOptInStatus :false,
        pickupMobileNumber : undefined
      };

      expect( populatePickupSmsInfo( data, mockState, type ) ).toEqual( {
        pickupSmsOptInStatus: !data.pickupSmsOptInStatus,
        pickupMobileNumber: undefined
      } );
      expect( persistPickupSmsInfo ).toHaveBeenCalledWith( { optInStatus : true, mobileNumber : undefined } );
    } );

    it( 'should set pickupSmsOptInStatus as !data.pickupSmsOptInStatus in local storage which is passed as input if type is toggleOptinSms', ()=>{
      const type = 'toggleOptinSms';
      retrievePickupSmsInfo.mockImplementation( () => {
        return {
          optInStatus : false,
          mobileNumber : '(111) 111 1111'
        };
      } );
      const data = {
        pickupSmsOptInStatus : false
      }
      const mockState = {
        pickupSmsOptInStatus :false,
        pickupMobileNumber : undefined
      };

      expect( populatePickupSmsInfo( data, mockState, type ) ).toEqual( {
        pickupSmsOptInStatus: !data.pickupSmsOptInStatus,
        pickupMobileNumber: '(111) 111 1111'
      } );
      expect( persistPickupSmsInfo ).toHaveBeenCalledWith( { optInStatus : true, mobileNumber : '(111) 111 1111' } );
    } );

    it( 'should update mobile number as data.pickupMobileNumber in local storage if type is updateMobileNumber', ()=>{
      const type = 'updateMobileNumber'
      retrievePickupSmsInfo.mockImplementation( () => {
        return {
          optInStatus : true,
          mobileNumber : '(111) 111 1111'
        };
      } );

      const data = {
        pickupMobileNumber : '(222) 222 2222'
      }
      const mockState = {
        pickupSmsOptInStatus :false,
        pickupMobileNumber : '(333) 333 3333'
      }
      expect( populatePickupSmsInfo( data, mockState, type ) ).toEqual( {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: data.pickupMobileNumber
      } );
      expect( persistPickupSmsInfo ).toHaveBeenCalledWith( { optInStatus : true, mobileNumber : '(222) 222 2222' } );
    } );
    it( 'should update mobile number as data.pickupMobileNumber which is passed as input if type is updateMobileNumber', ()=>{
      const type = 'updateMobileNumber'
      jest.resetAllMocks();

      const data = {
        pickupMobileNumber : '(222) 222 2222'
      }
      const mockState = {
        pickupSmsOptInStatus :false,
        pickupMobileNumber : '(333) 333 3333'
      }
      expect( populatePickupSmsInfo( data, mockState, type ) ).toEqual( {
        pickupSmsOptInStatus: false,
        pickupMobileNumber: data.pickupMobileNumber
      } );
    } );
  } );

  describe( 'TOGGLE_OPTIN_FOR_SMS', () =>{
    it( 'set pickupSmsOptInStatus as true if actionCreator.data is false', () => {
      jest.resetAllMocks();
      const state = {
        pickupSmsOptInStatus: false,
        pickupMobileNumber: undefined
      }
      const actionCreator = {
        type: TOGGLE_OPTIN_FOR_SMS,
        data: false
      }

      const expectedOutput = {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: undefined
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'set pickupSmsOptInStatus as false if actionCreator.data is true', () => {
      jest.resetAllMocks();
      const state = {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: '(222) 222 2222'
      }
      const actionCreator = {
        type: TOGGLE_OPTIN_FOR_SMS,
        data: true
      }

      const expectedOutput = {
        pickupSmsOptInStatus: false,
        pickupMobileNumber: '(222) 222 2222'
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'UPDATE_MOBILE_NUMBER', () =>{
    it( 'should set pickupMobileNumber in state', () => {
      jest.resetAllMocks();
      const state = {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: undefined
      }
      const actionCreator = {
        type: UPDATE_MOBILE_NUMBER,
        data: '(111) 111 1111'
      }

      const expectedOutput = {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: '(111) 111 1111'
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should clear pickupMobileNumber in state if data is undefined', () => {
      jest.resetAllMocks();
      const state = {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: '(111) 111 1111'
      }
      const actionCreator = {
        type: UPDATE_MOBILE_NUMBER,
        data: undefined
      }

      const expectedOutput = {
        pickupSmsOptInStatus: true,
        pickupMobileNumber: undefined
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'showGiftCard', () =>{
    it( 'should return true if paymentType is creditcard', () => {
      const paymentType = 'creditcard';
      expect( showGiftCard( paymentType ) ).toEqual( true );
    } );
    it( 'should return true if paymentType is paypal', () => {
      const paymentType = 'paypal';
      expect( showGiftCard( paymentType ) ).toEqual( true );
    } );
    it( 'should return true if paymentType is afterpay with valid giftCardDetails and loyaltyCardDetails', () => {
      const paymentType = 'afterpay';
      const giftCardDetails = {
        paymentType:'giftCard'
      };
      const loyaltyCardDetails = {
        'paymentType': 'loyalty'
      };
      expect( showGiftCard( paymentType, giftCardDetails, loyaltyCardDetails ) ).toEqual( true );
    } );
    it( 'should return false if paymentType is afterpay with empty giftCardDetails and loyaltyCardDetails', () => {
      const paymentType = 'afterpay';
      const giftCardDetails = undefined;
      const loyaltyCardDetails = undefined;
      expect( showGiftCard( paymentType, giftCardDetails, loyaltyCardDetails ) ).toEqual( false );
    } );
    it( 'should return false if isPaymentTypeAfterPay is true', () => {
      const paymentType = 'creditCard';
      const giftCardDetails = undefined;
      const loyaltyCardDetails = undefined;
      const isPaymentTypeAfterPay = true;
      expect( showGiftCard( paymentType, giftCardDetails, loyaltyCardDetails, isPaymentTypeAfterPay ) ).toEqual( false );
    } );
  } );

  describe( 'populatePaymentData', () =>{
    const isSignedIn = false;
    it( 'should return showGiftCard as true if paymentType is creditcard', () => {
      const state = {
        paymentType : 'creditcard'
      }
      const data = {
        paymentInfo: {}
      }
      expect( populatePaymentData( data, state, isSignedIn ).showGiftCard ).toEqual( true );
    } );
    it( 'should return showGiftCard as true if paymentType is paypal', () => {
      const state = {
        paymentType : 'paypal'
      }
      const data = {
        paymentInfo: {}
      }
      expect( populatePaymentData( data, state, isSignedIn ).showGiftCard ).toEqual( true );
    } );
    it( 'should return showGiftCard as true if paymentType is afterpay with valid giftCardDetails and loyaltyCardDetails', () => {
      const state = {
        paymentType : 'afterpay'
      }
      const data = {
        paymentInfo: {
          items: [
            {
              paymentType: 'giftCard'
            },
            {
              paymentType: 'loyalty',
              paymentDetails: {
                pointsApplied: '1000'
              }
            }
          ]
        }
      }
      expect( populatePaymentData( data, state, isSignedIn ).showGiftCard ).toEqual( true );
    } );
    it( 'should return showGiftCard as false if paymentType is afterpay with empty giftCardDetails and loyaltyCardDetails', () => {
      const state = {
        paymentType : 'creditCard',
        isPaymentTypeAfterPay: false
      }
      const data = {
        paymentInfo: {
          items: [
            {
              paymentType : 'afterpay'
            }
          ]
        }
      }
      expect( populatePaymentData( data, state, isSignedIn ).showGiftCard ).toEqual( false );
    } );
    it( 'should set afterpayDetails, isPaymentTypeAfterPay as true and showAfterpayContent as true if paymentType is afterpay and showAfterpay is true', () => {
      const state = {
        paymentType : 'afterpay',
        showAfterpay: true
      }
      const data = {
        paymentInfo: {
          items: [
            {
              paymentType: 'afterpay'
            }
          ]
        }
      }
      const expectedOutput = {
        paymentType: 'afterpay'
      }
      expect( populatePaymentData( data, state, isSignedIn ).afterpayDetails ).toEqual( expectedOutput );
      expect( populatePaymentData( data, state, isSignedIn ).paymentType ).toEqual( 'afterpay' );
      expect( populatePaymentData( data, state, isSignedIn ).isPaymentTypeAfterPay ).toEqual( true );
      expect( populatePaymentData( data, state, isSignedIn ).showAfterpayContent ).toEqual( true );
    } );
    it( 'should set showAfterpayContent as false and isPaymentTypeAfterPay as false when showAfterpay is false even if paymentType is afterpay', () => {
      const state = {
        paymentType : 'paypal',
        showAfterpay: false
      }
      const data = {
        paymentInfo: {
          items: [
            {
              paymentType: 'afterpay'
            }
          ]
        }
      }
      expect( populatePaymentData( data, state, isSignedIn ).showAfterpayContent ).toEqual( false );
      expect( populatePaymentData( data, state, isSignedIn ).isPaymentTypeAfterPay ).toEqual( false );
    } );
    it( 'should set afterpayDetails as undefined, isPaymentTypeAfterPay as false and showAfterpayContent as false if paymentType is not afterpay', () => {
      const state = {
        paymentType : 'afterpay',
        showAfterpay: true
      }
      const data = {
        paymentInfo: {
          items: [
            {
              paymentType: 'paypal'
            }
          ]
        }
      }
      expect( populatePaymentData( data, state, isSignedIn ).afterpayDetails ).toEqual( undefined );
      expect( populatePaymentData( data, state, isSignedIn ).paymentType ).toEqual( 'paypal' );
      expect( populatePaymentData( data, state, isSignedIn ).isPaymentTypeAfterPay ).toEqual( false );
      expect( populatePaymentData( data, state, isSignedIn ).showAfterpayContent ).toEqual( false );
    } );
  } );
} );
