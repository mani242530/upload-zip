/**
 * Coupon Redux reducer Module
 *
 */
import find from 'lodash/find';

import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  actionTypes as ReduxActionType
} from 'redux-form';

/**
 * default state for the Coupons reducer
 */



export const initialState = {
  couponAppliedStatus: false,
  couponRemoved: false,
  couponApplying: false,
  couponDescription: undefined,
  couponCode: null,
  couponAppliedMessage: null,
  couponAppliedErrorMsg: null,
  appliedCouponSummary: {},
  fromCheckout: false
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */


export default function reducer( state = initialState, action ){

  switch ( action.type ){

    case getServiceType( 'loadCart', 'success' ):
      return {
        ...state,
        ...populateCouponDetails( action.data.appliedCouponSummary ),
        isCouponErrorPresent: !action.data.appliedCouponSummary.couponAppliedStatus && !!action.data.appliedCouponSummary.messages
      }
    case getServiceType( 'applycoupon', 'success' ):
    case getServiceType( 'updateCartItems', 'success' ):
      return {
        ...state,
        ...populateCouponDetails( action.data.appliedCouponSummary )
      }
    case getServiceType( 'initCart', 'success' ):
      return {
        ...state,
        ...populateCouponDetails( action.data.result.appliedCouponSummary )
      }
    case getServiceType( 'removeItemFromCart', 'success' ):
      return {
        ...state,
        ...populateCouponDetails( action.data.type.appliedCouponSummary )
      }

    case getServiceType( 'applycoupon', 'failure' ):
      return {
        ...state,
        couponApplying:false
      }

    case getServiceType( 'removecoupon', 'success' ):
      return {
        ...state,
        couponApplying: false,
        isCouponRemoved : true,
        couponAppliedStatus: false,
        couponOfferReqMet: false,
        couponRemoved: true,
        appliedCouponSummary: {},
        couponAppliedMessage: {},
        couponDescription:undefined
      }

    case getServiceType( 'applycoupon', 'loading' ):
      return {
        ...state,
        couponApplying:true,
        isCouponRemoved : false
      }

    default:
      return state;
  }

}

export const populateCouponDetails = ( appliedCouponSummary ) => {
  return {
    couponAppliedStatus: appliedCouponSummary.couponAppliedStatus,
    couponDescription:  appliedCouponSummary.couponDescription,
    couponCode: appliedCouponSummary.couponCode,
    couponAppliedErrorMessage: !appliedCouponSummary.couponAppliedStatus && appliedCouponSummary.messages ? find( appliedCouponSummary.messages.items, { type:'Error' } ) : null,
    couponAppliedMessage: appliedCouponSummary.couponAppliedStatus && appliedCouponSummary.messages ? find( appliedCouponSummary.messages.items, { type:'Info' } ) : null,
    couponApplying: false,
    appliedCouponSummary: appliedCouponSummary
  }
}



export const getCouponState = state => state.coupon;
