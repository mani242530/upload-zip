
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import isFunction from 'lodash/isFunction';
import reducer, {
  initialState
} from './coupons.model';

const state = {
  couponAppliedStatus: false,
  couponRemoved: false,
  couponApplying: false,
  couponDescription: undefined,
  couponCode: null,
  couponAppliedMessage: null,
  couponAppliedErrorMsg: null,
  appliedCouponSummary: {
    couponAppliedStatus: true,
    couponDescription: [
      'QA-Item level $1 Off'
    ],
    messages: {
      items: [
        {
          type: 'Info',
          message: 'ITM1QAOFF Coupon Added'
        }
      ]
    },
    couponCode: 'ITM1QAOFF'
  },
  fromCheckout: false
}


describe( 'Coupons reducer', () => {

  registerServiceName( 'applycoupon' );
  registerServiceName( 'removecoupon' );
  registerServiceName( 'loadCart' );
  registerServiceName( 'initCart' );
  registerServiceName( 'removeItemFromCart' );
  registerServiceName( 'updateCartItems' );
  it( 'should have the proper default state', () =>{

    let expectedState = {
      couponAppliedStatus: false,
      couponRemoved: false,
      couponApplying: false,
      couponDescription: undefined,
      couponCode: null,
      couponAppliedMessage: null,
      couponAppliedErrorMsg: null,
      appliedCouponSummary: {},
      fromCheckout: false
    };

    expect( initialState ).toEqual( expectedState );
  } );

  it( 'should be a function', () =>{
    expect( isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', () => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  it( 'should apply coupon on success', ( ) => {
    let res = {
      'appliedCouponSummary': {
        'couponAppliedStatus': true,
        'messages': {
          'items': [{
            'type': 'Info',
            'message': 'CPWK3415H1 Coupon Added'
          }]
        },
        'couponCode': '3-5OFFCPN'
      }
    }

    let actionCreator = {
      type: getServiceType( 'applycoupon', 'success' ),
      data: res
    }
    let expectedOutput = {

      'couponAppliedStatus': true,
      'couponDescription': undefined,
      'couponRemoved': false,
      'couponCode': '3-5OFFCPN',
      'couponAppliedErrorMessage': null,
      'couponAppliedErrorMsg': null,
      'couponAppliedMessage': {
        'type': 'Info',
        'message': 'CPWK3415H1 Coupon Added'
      },
      'appliedCouponSummary': {
        'couponAppliedStatus': true,
        'messages': {
          'items': [{
            'type': 'Info',
            'message': 'CPWK3415H1 Coupon Added'
          }]
        },
        'couponCode': '3-5OFFCPN'
      },
      couponApplying: false,
      fromCheckout: false


    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should call loadCart on success', ( ) => {
    let res = {
      'appliedCouponSummary': {
        'couponAppliedStatus': true,
        'messages': {
          'items': [{
            'type': 'Info',
            'message': 'CPWK3415H1 Coupon Added'
          }]
        },
        'couponCode': '3-5OFFCPN'
      }
    }

    let actionCreator = {
      type: getServiceType( 'loadCart', 'success' ),
      data: res
    }
    let expectedOutput = {

      'couponAppliedStatus': true,
      'couponDescription': undefined,
      'couponRemoved': false,
      'couponCode': '3-5OFFCPN',
      'couponAppliedErrorMessage': null,
      'couponAppliedErrorMsg': null,
      'couponAppliedMessage': {
        'type': 'Info',
        'message': 'CPWK3415H1 Coupon Added'
      },
      'appliedCouponSummary': {
        'couponAppliedStatus': true,
        'messages': {
          'items': [{
            'type': 'Info',
            'message': 'CPWK3415H1 Coupon Added'
          }]
        },
        'couponCode': '3-5OFFCPN'
      },
      couponApplying: false,
      fromCheckout: false,
      isCouponErrorPresent: false

    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should set isCouponErrorPresent as true when coupon error is present in loadCart success', ( ) => {
    let res = {
      'appliedCouponSummary': {
        'couponAppliedStatus': false,
        'messages': {
          'items': [{
            'type': 'Error',
            'message': 'Code has expired'
          }]
        },
        'couponCode': '3-5OFFCPN'
      }
    }

    let actionCreator = {
      type: getServiceType( 'loadCart', 'success' ),
      data: res
    }
    let expectedOutput = {

      'couponAppliedStatus': false,
      'couponDescription': undefined,
      'couponRemoved': false,
      'couponCode': '3-5OFFCPN',
      'couponAppliedMessage': null,
      'couponAppliedErrorMsg': null,
      'couponAppliedErrorMessage': {
        'type': 'Error',
        'message': 'Code has expired'
      },
      'appliedCouponSummary': {
        'couponAppliedStatus': false,
        'messages': {
          'items': [{
            'type': 'Error',
            'message': 'Code has expired'
          }]
        },
        'couponCode': '3-5OFFCPN'
      },
      couponApplying: false,
      fromCheckout: false,
      isCouponErrorPresent: true

    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should handle action with type updateCartItems', ( ) => {
    let res = {
      'appliedCouponSummary': {
        'couponAppliedStatus': true,
        'messages': {
          'items': [{
            'type': 'Info',
            'message': 'CPWK3415H1 Coupon Added'
          }]
        },
        'couponCode': '3-5OFFCPN'
      }
    }

    let actionCreator = {
      type: getServiceType( 'updateCartItems', 'success' ),
      data: res
    }
    let expectedOutput = {

      'couponAppliedStatus': true,
      'couponDescription': undefined,
      'couponRemoved': false,
      'couponCode': '3-5OFFCPN',
      'couponAppliedErrorMessage': null,
      'couponAppliedErrorMsg': null,
      'couponAppliedMessage': {
        'type': 'Info',
        'message': 'CPWK3415H1 Coupon Added'
      },
      'appliedCouponSummary': {
        'couponAppliedStatus': true,
        'messages': {
          'items': [{
            'type': 'Info',
            'message': 'CPWK3415H1 Coupon Added'
          }]
        },
        'couponCode': '3-5OFFCPN'
      },
      couponApplying: false,
      fromCheckout: false


    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should call initCart on success', ( ) => {
    let res = {
      'result':{
        'appliedCouponSummary': {
          'couponAppliedStatus': true,
          'messages': {
            'items': [{
              'type': 'Info',
              'message': 'CPWK3415H1 Coupon Added'
            }]
          },
          'couponCode': '3-5OFFCPN'
        }
      }
    }

    let actionCreator = {
      type: getServiceType( 'initCart', 'success' ),
      data: res
    }
    let expectedOutput = {

      'couponAppliedStatus': true,
      'couponDescription': undefined,
      'couponRemoved': false,
      'couponCode': '3-5OFFCPN',
      'couponAppliedErrorMessage': null,
      'couponAppliedErrorMsg': null,
      'couponAppliedMessage': {
        'type': 'Info',
        'message': 'CPWK3415H1 Coupon Added'
      },
      'appliedCouponSummary': {
        'couponAppliedStatus': true,
        'messages': {
          'items': [{
            'type': 'Info',
            'message': 'CPWK3415H1 Coupon Added'
          }]
        },
        'couponCode': '3-5OFFCPN'
      },
      couponApplying: false,
      fromCheckout: false


    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should call removeItemFromCart on success', ( ) => {
    let res = {
      'type':{
        'appliedCouponSummary': {
          'couponAppliedStatus': false,
          'couponDescription': [
            'QA Order level 35% off coupon'
          ],
          'messages': {
            'items': [
              {
                'type': 'Error',
                'message': 'Review bag for items that will be excluded from this coupon.'
              }
            ]
          },
          'couponCode': 'ORD35QAOFF'
        }
      }
    }

    let actionCreator = {
      type: getServiceType( 'removeItemFromCart', 'success' ),
      data: res
    }
    let expectedOutput = {

      'couponAppliedStatus': false,
      'couponRemoved': false,
      'couponCode': 'ORD35QAOFF',
      'couponDescription': [
        'QA Order level 35% off coupon'
      ],
      'couponAppliedErrorMessage':{
        'type': 'Error',
        'message': 'Review bag for items that will be excluded from this coupon.'
      },
      'appliedCouponSummary': {
        'couponAppliedStatus': false,
        'couponDescription': [
          'QA Order level 35% off coupon'
        ],
        'messages': {
          'items': [{
            'type': 'Error',
            'message': 'Review bag for items that will be excluded from this coupon.'
          }]
        },
        'couponCode': 'ORD35QAOFF'
      },
      'couponAppliedErrorMsg':null,
      'couponAppliedMessage':null,
      couponApplying: false,
      fromCheckout: false


    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should removecoupon on success', ( ) => {
    let res = {
      'appliedCouponSummary': {
        'couponAppliedStatus': true,
        'messages': {
          'items': [{
            'type': 'Info',
            'message': 'CPWK3415H1 Coupon Added'
          }]
        },
        'couponCode': '3-5OFFCPN'
      }
    }

    let actionCreator = {
      type: getServiceType( 'removecoupon', 'success' ),
      data: res
    }
    let expectedOutput = {

      'couponAppliedStatus': false,
      'couponDescription': undefined,
      'isCouponRemoved': true,
      'couponCode': null,
      'couponAppliedErrorMsg':null,
      'couponAppliedMessage': {
      },
      'appliedCouponSummary': {
      },
      couponApplying: false,
      couponOfferReqMet: false,
      couponRemoved: true,
      fromCheckout: false


    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

} );
