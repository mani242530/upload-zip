/**
 * Find In Store Redux reducer Module
 *
 */
import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import isEmpty from 'lodash/isEmpty';
import {
  CHANGE as REDUXFORM_CHANGE
} from 'redux-form/lib/actionTypes';
import { createSelector } from 'reselect';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import {
  SEARCH_FOCUSED, SEARCH_UNFOCUSED, CLOSE_FIND_IN_STORE_MODAL, SEARCH_BUTTON_FOCUSED, SEARCH_BUTTON_UNFOCUSED
} from '../../../events/find_in_store/find_in_store.events';
import appConstants from '../../../shared/appConstants';
import messages from '../../../views/StoreList/StoreList.messages';
/**
 * default state for the FindInStore reducer
 */

export const initialState = {
  storeDetailData:undefined,
  storeServiceData:undefined,
  storeCurrentPageNum:1,
  storeTotalPages:0,
  loadMoreResults:false,
  storeNotFound:false,
  storeSearchValue: '',
  inputFieldFocus:false,
  loadingMoreStores:false,
  openFindInStoreModal: false,
  searchButtonFocus: false,
  isLocationBlocked: true, // to indicate if location is blocked or not
  storeServiceRequested: false
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){
  return reducerSwitch( state, action )
}

export const reducerSwitch = function( state, action ){

  switch ( action.type ){
    case getServiceType( 'storeDetail', 'requested' ):
      return {
        ...state,
        ...initialState,
        openFindInStoreModal: true,
        storeSearchValue: action.data.searchValue,
        isLocationBlocked: state.isLocationBlocked
      }


    case getServiceType( 'storeDetail', 'loading' ):
      return {
        ...state,
        loadingMoreStores:true,
        storeServiceRequested: true
      }
    case getServiceType( 'latLong', 'loading' ):
    case getServiceType( 'loadMoreResults', 'loading' ):
      return {
        ...state,
        loadingMoreStores:true
      }
    case getServiceType( 'loadMoreResults', 'requested' ):
      return {
        ...state,
        loadMoreResults:false,
        storeCurrentPageNum:state.storeCurrentPageNum + 1
      }

    case getServiceType( 'storeDetail', 'success' ):
      return {
        ...state,
        storeNotFound: state.storeServiceRequested && !action.data?.stores?.items,
        loadingMoreStores:false,
        ...( action.data && action.data.stores?.items &&
          {

            storeServiceData: action.data.stores,
            storeDetailData: displayStoreData( action.data.stores.items, state.storeCurrentPageNum ),
            storeTotalPages:  Math.ceil( action.data.stores.items.length / 10 ),
            loadMoreResults:  action.data.stores.items.length > 10
          } ),
        ...( action.data && action.data.useCachedValue && { isLocationBlocked: action.data.isLocationBlocked } )
      }
    case SEARCH_FOCUSED:
      return {
        ...state,
        // Set searchicon when input field is focused
        inputFieldFocus: true
      };
    case SEARCH_UNFOCUSED:
      return {
        ...state,
        // Remove searchicon when input field is unfocused
        inputFieldFocus: false
      };
    case SEARCH_BUTTON_FOCUSED:
      return {
        ...state,
        searchButtonFocus: true
      };

    case SEARCH_BUTTON_UNFOCUSED:
      return {
        ...state,
        searchButtonFocus: false
      };
    case CLOSE_FIND_IN_STORE_MODAL:
      return {
        ...state,
        openFindInStoreModal:false
      }
      // In future Store Availability will be avaialable as part of  itemAvailability in  store detail service .
      // When user requested the store avaiablity , insert the availability status and info messages into the selected store detail .
      // So only minimum change is rquired  when its available as part of the store service .
    case getServiceType( 'storeProductAvailability', 'success' ):
      return {
        ...state,
        storeDetailData:state.storeDetailData.map(
          ( storeDetail ) => {
            return ( storeDetail.storeId === action.data.storeId ? {
              ...( storeDetail && {
                ...storeDetail,
                displayCheckAvailabilityButton: false,
                showStoreAvailability : true,
                showPickUpAvailability : !isEmpty( storeDetail.bopisAvailability )
              } ),
              storeAvailability:{
                status : action.data.inventoryStatus,
                message : getStoreAvailabilityMessage( action.data.inventoryStatus )
              }
            } :
              storeDetail
            )
          }
        )
      };
    case getServiceType( 'loadMoreResults', 'success' ):
      return {
        ...state,
        loadingMoreStores:false,
        loadMoreResults:state.storeCurrentPageNum < state.storeTotalPages,
        storeDetailData:[
          ...state.storeDetailData,
          ...( displayStoreData( state.storeServiceData.items, state.storeCurrentPageNum ) )
        ]
      };
    case getServiceType( 'latLong', 'success' ):
      return {
        ...state,
        // once the user allows the location (state.isLocationBlocked is false) isLocationBlocked need not be reset
        // If location is allowed geoLocationOverride will be false, geoLocationOverride will be true only when user enters his location in text field
        ...( state.isLocationBlocked && ( isEmpty( state.storeSearchValue ) && action.data && { isLocationBlocked: action.data.geoLocationOverride } ) )
      };
    case REDUXFORM_CHANGE:
      return {
        ...state,
        ...( action.meta.form === appConstants.FIND_IN_STORE_CONFIG.FORMNAME && action.meta.field === appConstants.FIND_IN_STORE_CONFIG.FIELDNAME &&
        {
          ...( state.storeNotFound && action.payload.length < 1 && { storeNotFound: false } )
        } )
      }
    default:
      return state;
  }
};

// The following is for handling the number of store results displayed. Max number of results is 10
export const displayStoreData = ( storeDetail, pageNum ) => {
  let endIndex =  10 * pageNum ;
  if( endIndex > storeDetail.length ){
    endIndex = storeDetail.length;
  }
  let storeDisplayList = storeDetail.slice( 10 * ( pageNum - 1 ), endIndex );
  // For each store , will return bopisAvailability and storeAvailability  based on pickup(BOPIS) and fis(Store) object of response data .
  // bopisAvailability contain status and message about BOPIS availability
  // storeAvailability contain status and message about Store availability
  storeDisplayList = storeDisplayList.map( ( storeDisplayData ) => {
    const fis = storeDisplayData.itemAvailability?.fis;
    return {
      ...storeDisplayData,
      ...( !fis && { displayCheckAvailabilityButton: true } ),
      ...( fis && {
        showStoreAvailability : true,
        displayCheckAvailabilityButton: false,
        storeAvailability:{
          message : storeDisplayData.itemAvailability.fis.statusMessage,
          status : storeDisplayData.itemAvailability.fis.status
        }
      }
      ),
      ...( storeDisplayData.itemAvailability?.pickup && {
        showPickUpAvailability: !!fis,
        bopisAvailability:{
          message : storeDisplayData.itemAvailability.pickup.statusMessage,
          status : storeDisplayData.itemAvailability.pickup.status
        }
      }
      )
    }
  } );
  return storeDisplayList;
}

// input selectors for shouldDisplayDefaultLocationMessage
export const getSearchTerm = ( state ) => state.form.FindInStore?.values?.searchField || '' ;
export const getStoreDetailData = ( state ) => state.findInStore.storeDetailData
export const getStoreNotFound = ( state ) => state.findInStore.storeNotFound
export const getStoreServiceRequested = ( state ) => state.findInStore.storeServiceRequested
export const getLoadingMoreStores = ( state ) => state.findInStore.loadingMoreStores

// A memorized selector that recalculates showDefaultLocationMessage when the value of state.findInStore.storeDetailData, state.findInStore.storeNotFound or state.form.FindInStore changes,
// but not when changes occur in other (unrelated) parts of the state tree.
export const shouldDisplayDefaultLocationMessage = createSelector(
  [getStoreDetailData, getStoreNotFound, getSearchTerm, getStoreServiceRequested, getLoadingMoreStores],
  ( storeDetailData, storeNotFound, searchTerm, storeServiceRequested, loadingMoreStores ) => {
    return !storeDetailData && isEmpty( searchTerm ) && !storeNotFound && !storeServiceRequested && !loadingMoreStores
  }
)

export const getCurrentLocationBlockedState = state => state.findInStore.isLocationBlocked;

// Retrun info message based on the stock status
export const getStoreAvailabilityMessage = ( status ) => {
  switch ( status ){
    case 'IN STOCK':
    case 'available':
      return ( formatMessage( messages.inStock ) );
    case 'OUT OF STOCK':
    case 'notAvailable':
      return ( formatMessage( messages.outOfStock ) );
    case 'notEligible':
      return ( formatMessage( messages.notSoldStore ) );
    case 'NO DATA':
      return ( formatMessage( messages.availabilityError ) );
    default:
      return null;

  }

}
