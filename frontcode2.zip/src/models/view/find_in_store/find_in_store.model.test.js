

import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import { Provider } from 'react-redux';
import React from 'react';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { initializeIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import {
  CHANGE as REDUXFORM_CHANGE
} from 'redux-form/lib/actionTypes';
import CONFIG from '../../../modules/pdp/pdp.config';
import configureStore from '../../../modules/pdp/pdp.store';
import reducer, {
  initialState, getSearchTerm, getStoreDetailData, getStoreNotFound, getStoreServiceRequested, getLoadingMoreStores, shouldDisplayDefaultLocationMessage
} from './find_in_store.model';
import {
  SEARCH_FOCUSED, SEARCH_UNFOCUSED, CLOSE_FIND_IN_STORE_MODAL, SEARCH_BUTTON_FOCUSED, SEARCH_BUTTON_UNFOCUSED
} from '../../../events/find_in_store/find_in_store.events';

describe( 'FindInStore reducer', ( ) => {
  registerServiceName( 'findInStore' );
  registerServiceName( 'pdpSkuDetails' );
  registerServiceName( 'storeDetail' );
  registerServiceName( 'storeProductAvailability' );
  registerServiceName( 'loadMoreResults' );
  registerServiceName( 'latLong' );

  initializeIntl();

  it( 'should have the proper default state', ( ) => {
    const expectedState = {
      storeDetailData:undefined,
      storeServiceData:undefined,
      storeCurrentPageNum:1,
      storeTotalPages:0,
      storeNotFound:false,
      storeSearchValue: '',
      inputFieldFocus:false,
      loadingMoreStores:false,
      loadMoreResults:false,
      openFindInStoreModal: false,
      searchButtonFocus: false,
      isLocationBlocked: true,
      storeServiceRequested: false
    }
    expect( initialState ).toEqual( expectedState );
  } );

  it( 'storeDetail requested case', ( ) => {
    const data = {
      searchValue: '60007'
    }
    let actionCreator = {
      type: getServiceType( 'storeDetail', 'requested' ),
      data
    }
    let expectedOutput = {
      storeDetailData:undefined,
      storeServiceData:undefined,
      storeCurrentPageNum:1,
      storeTotalPages:0,
      storeNotFound:false,
      storeSearchValue:'60007',
      inputFieldFocus:false,
      loadingMoreStores:false,
      loadMoreResults:false,
      openFindInStoreModal: true,
      searchButtonFocus: false,
      isLocationBlocked: undefined,
      storeServiceRequested: false
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'storeDetail loading case', ( ) => {
    let actionCreator = {
      type: getServiceType( 'storeDetail', 'loading' )
    }
    let expectedOutput = {
      loadingMoreStores:true,
      storeServiceRequested: true
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'storeDetail success case with more than 10 stores', ( ) => {
    const data = {
      stores:{
        items: [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          },
          {
            'storeId': '566'
          },
          {
            'storeId': '567'
          },
          {
            'storeId': '568'
          },
          {
            'storeId': '569'
          },
          {
            'storeId': '570'
          },
          {
            'storeId': '571'
          }
        ]
      }
    }
    let actionCreator = {
      type: getServiceType( 'storeDetail', 'success' ),
      data
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '560',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '561',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '562',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '563',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '564',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '565',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '566',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '567',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '568',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '569',
          'displayCheckAvailabilityButton': true
        }
      ],
      storeServiceData:{
        'items': [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          },
          {
            'storeId': '566'
          },
          {
            'storeId': '567'
          },
          {
            'storeId': '568'
          },
          {
            'storeId': '569'
          },
          {
            'storeId': '570'
          },
          {
            'storeId': '571'
          }
        ]
      },
      storeTotalPages:2,
      storeNotFound:false,
      loadingMoreStores:false,
      loadMoreResults:true,
      storeCurrentPageNum:1,
      storeServiceRequested:true
    }
    expect( reducer( { storeCurrentPageNum:1, storeServiceRequested:true }, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'storeDetail success case with less than 10 stores', ( ) => {
    const data = {
      stores:{
        items: [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          }
        ]
      }
    }
    let actionCreator = {
      type: getServiceType( 'storeDetail', 'success' ),
      data
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '560',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '561',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '562',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '563',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '564',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '565',
          'displayCheckAvailabilityButton': true
        }
      ],
      storeServiceData:{
        'items': [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          }
        ]
      },
      storeTotalPages:1,
      storeNotFound:false,
      loadingMoreStores:false,
      loadMoreResults:false,
      storeCurrentPageNum:1,
      storeServiceRequested:true
    }
    expect( reducer( { storeCurrentPageNum:1, storeServiceRequested:true }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Should set showPickUpAvailability to false and bopisAvailability for each store, if pickup node is available and fis node is null in the response ', ( ) => {
    const data = {
      stores:{
        items: [
          {
            'storeId': '560',
            itemAvailability: {
              fis: null,
              pickup: {
                statusMessage: 'Not Available for Buy Online & Pickup in store',
                status:'notAvailable'
              }
            }
          },
          {
            'storeId': '561',
            itemAvailability: {
              fis: null,
              pickup: {
                status: 'available',
                statusMessage: 'Available for Buy Online & Pickup in store'
              }
            }
          }
        ]
      }
    }
    let actionCreator = {
      type: getServiceType( 'storeDetail', 'success' ),
      data
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '560',
          'displayCheckAvailabilityButton': true,
          showPickUpAvailability:false,
          itemAvailability: {
            fis: null,
            pickup: {
              statusMessage : 'Not Available for Buy Online & Pickup in store',
              status: 'notAvailable'
            }
          },
          bopisAvailability:{
            status: 'notAvailable',
            message: 'Not Available for Buy Online & Pickup in store'
          }
        },
        {
          'storeId': '561',
          'displayCheckAvailabilityButton': true,
          showPickUpAvailability:false,
          itemAvailability: {
            fis: null,
            pickup: {
              statusMessage: 'Available for Buy Online & Pickup in store',
              status: 'available'
            }
          },
          bopisAvailability:{
            status: 'available',
            message: 'Available for Buy Online & Pickup in store'
          }
        }
      ],
      storeServiceData:{
        'items': [
          {
            'storeId': '560',
            itemAvailability: {
              fis: null,
              pickup: {
                statusMessage: 'Not Available for Buy Online & Pickup in store',
                status: 'notAvailable'
              }
            }
          },
          {
            'storeId': '561',
            itemAvailability: {
              fis: null,
              pickup: {
                statusMessage: 'Available for Buy Online & Pickup in store',
                status: 'available'
              }
            }
          }
        ]
      },
      storeTotalPages:1,
      storeNotFound:false,
      loadingMoreStores:false,
      loadMoreResults:false,
      storeCurrentPageNum:1,
      storeServiceRequested:true
    }
    expect( reducer( { storeCurrentPageNum:1, storeServiceRequested:true }, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'Should set showPickUpAvailability to true for each store, if pickup node is available and fis node is not null in the response ', ( ) => {
    const data = {
      stores:{
        items: [
          {
            'storeId': '560',
            itemAvailability: {
              fis: {
                statusMessage: 'In Stock at the Store',
                status: 'available'
              },
              pickup: {
                statusMessage: 'Not Available for Buy Online & Pickup in store',
                status:'notAvailable'
              }
            }
          },
          {
            'storeId': '561',
            itemAvailability: {
              fis: {
                statusMessage: 'In Stock at the Store',
                status: 'available'
              },
              pickup: {
                status: 'available',
                statusMessage: 'Available for Buy Online & Pickup in store'
              }
            }
          }
        ]
      }
    }
    let actionCreator = {
      type: getServiceType( 'storeDetail', 'success' ),
      data
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '560',
          'displayCheckAvailabilityButton': false,
          showPickUpAvailability:true,
          showStoreAvailability:true,
          itemAvailability: {
            fis: {
              statusMessage: 'In Stock at the Store',
              status: 'available'
            },
            pickup: {
              statusMessage : 'Not Available for Buy Online & Pickup in store',
              status: 'notAvailable'
            }
          },
          bopisAvailability:{
            status: 'notAvailable',
            message: 'Not Available for Buy Online & Pickup in store'
          },
          storeAvailability:{
            message: 'In Stock at the Store',
            status: 'available'
          }
        },
        {
          'storeId': '561',
          'displayCheckAvailabilityButton': false,
          showPickUpAvailability:true,
          showStoreAvailability:true,
          itemAvailability: {
            fis: {
              statusMessage: 'In Stock at the Store',
              status: 'available'
            },
            pickup: {
              statusMessage: 'Available for Buy Online & Pickup in store',
              status: 'available'
            }
          },
          bopisAvailability:{
            status: 'available',
            message: 'Available for Buy Online & Pickup in store'
          },
          storeAvailability:{
            message: 'In Stock at the Store',
            status: 'available'
          }
        }
      ],
      storeServiceData:{
        'items': [
          {
            'storeId': '560',
            itemAvailability: {
              fis: {
                statusMessage: 'In Stock at the Store',
                status: 'available'
              },
              pickup: {
                statusMessage: 'Not Available for Buy Online & Pickup in store',
                status: 'notAvailable'
              }
            }
          },
          {
            'storeId': '561',
            itemAvailability: {
              fis: {
                statusMessage: 'In Stock at the Store',
                status: 'available'
              },
              pickup: {
                statusMessage: 'Available for Buy Online & Pickup in store',
                status: 'available'
              }
            }
          }
        ]
      },
      storeTotalPages:1,
      storeNotFound:false,
      loadingMoreStores:false,
      loadMoreResults:false,
      storeCurrentPageNum:1,
      storeServiceRequested:true
    }
    expect( reducer( { storeCurrentPageNum:1, storeServiceRequested:true }, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'add storeAvailability in each store when fis node is available in the response ', ( ) => {
    const data = {
      stores:{
        items: [
          {
            'storeId': '560',
            itemAvailability: {
              fis:  {
                statusMessage: 'In Stock at the Store',
                status: 'available'
              },
              pickup: {
                statusMessage: 'Not Available for Buy Online & Pickup in store',
                status: 'notAvailable'
              }
            }
          },
          {
            'storeId': '561',
            itemAvailability: {
              fis:  {
                statusMessage: 'Not In Stock at the Store',
                status: 'notAvailable'
              },
              pickup: {
                statusMessage: 'Available for Buy Online & Pickup in store',
                status: 'available'
              }
            }
          },
          {
            'storeId': '562',
            itemAvailability: {
              fis:  {
                statusMessage: 'Not Sold at this Store',
                status: 'notEligible'
              },
              pickup: {
                statusMessage: 'Not Available for Buy Online & Pickup in store',
                status: 'notAvailable'
              }
            }
          }
        ]
      }
    }
    let actionCreator = {
      type: getServiceType( 'storeDetail', 'success' ),
      data
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '560',
          'displayCheckAvailabilityButton': false,
          showPickUpAvailability:true,
          showStoreAvailability:true,
          itemAvailability: {
            fis:  {
              statusMessage: 'In Stock at the Store',
              status: 'available'
            },
            pickup: {
              statusMessage: 'Not Available for Buy Online & Pickup in store',
              status: 'notAvailable'
            }
          },
          bopisAvailability:{
            status: 'notAvailable',
            message: 'Not Available for Buy Online & Pickup in store'
          },
          storeAvailability:{
            status: 'available',
            message: 'In Stock at the Store'
          }
        },
        {
          'storeId': '561',
          'displayCheckAvailabilityButton': false,
          showPickUpAvailability:true,
          showStoreAvailability:true,
          itemAvailability: {
            fis:  {
              statusMessage: 'Not In Stock at the Store',
              status: 'notAvailable'
            },
            pickup: {
              statusMessage: 'Available for Buy Online & Pickup in store',
              status: 'available'
            }
          },
          bopisAvailability:{
            status: 'available',
            message: 'Available for Buy Online & Pickup in store'
          },
          storeAvailability:{
            status: 'notAvailable',
            message: 'Not In Stock at the Store'
          }
        },
        {
          'storeId': '562',
          'displayCheckAvailabilityButton': false,
          showPickUpAvailability:true,
          showStoreAvailability:true,
          itemAvailability: {
            fis:  {
              statusMessage: 'Not Sold at this Store',
              status: 'notEligible'
            },
            pickup: {
              statusMessage: 'Not Available for Buy Online & Pickup in store',
              status: 'notAvailable'
            }
          },
          bopisAvailability:{
            status: 'notAvailable',
            message: 'Not Available for Buy Online & Pickup in store'
          },
          storeAvailability:{
            status: 'notEligible',
            message: 'Not Sold at this Store'
          }
        }
      ],
      storeServiceData:{
        'items': [
          {
            'storeId': '560',
            itemAvailability: {
              fis:  {
                statusMessage: 'In Stock at the Store',
                status: 'available'
              },
              pickup: {
                statusMessage: 'Not Available for Buy Online & Pickup in store',
                status: 'notAvailable'
              }
            }
          },
          {
            'storeId': '561',
            itemAvailability: {
              fis:  {
                statusMessage: 'Not In Stock at the Store',
                status: 'notAvailable'
              },
              pickup: {
                statusMessage: 'Available for Buy Online & Pickup in store',
                status: 'available'
              }
            }
          },
          {
            'storeId': '562',
            itemAvailability: {
              fis:  {
                statusMessage: 'Not Sold at this Store',
                status: 'notEligible'
              },
              pickup: {
                statusMessage: 'Not Available for Buy Online & Pickup in store',
                status: 'notAvailable'
              }
            }
          }
        ]
      },
      storeTotalPages:1,
      storeNotFound:false,
      loadingMoreStores:false,
      loadMoreResults:false,
      storeCurrentPageNum:1,
      storeServiceRequested:true
    }
    expect( reducer( { storeCurrentPageNum:1, storeServiceRequested:true }, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'storeDetail success case with location blocked true', ( ) => {
    const data = {
      stores:{
        items: [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          }
        ]
      },
      isLocationBlocked:true,
      useCachedValue:true
    }
    let actionCreator = {
      type: getServiceType( 'storeDetail', 'success' ),
      data
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '560',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '561',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '562',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '563',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '564',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '565',
          'displayCheckAvailabilityButton': true
        }
      ],
      storeServiceData:{
        'items': [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          }
        ]
      },
      storeTotalPages:1,
      storeNotFound:false,
      loadingMoreStores:false,
      loadMoreResults:false,
      isLocationBlocked:true,
      storeCurrentPageNum:1,
      storeServiceRequested:true
    }
    expect( reducer( { storeCurrentPageNum:1, storeServiceRequested:true }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'storeDetail success case with location blocked false', ( ) => {
    const data = {
      stores:{
        items: [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          }
        ]
      },
      isLocationBlocked:false,
      useCachedValue: true
    }
    let actionCreator = {
      type: getServiceType( 'storeDetail', 'success' ),
      data
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '560',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '561',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '562',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '563',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '564',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '565',
          'displayCheckAvailabilityButton': true
        }
      ],
      storeServiceData:{
        'items': [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          }
        ]
      },
      storeTotalPages:1,
      storeNotFound:false,
      loadingMoreStores:false,
      loadMoreResults:false,
      isLocationBlocked:false,
      storeCurrentPageNum:1,
      storeServiceRequested:true
    }
    expect( reducer( { storeCurrentPageNum:1, storeServiceRequested:true, isLocationBlocked:true }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'storeDetail success case with useCachedValue false', ( ) => {
    const data = {
      stores:{
        items: [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          }
        ]
      },
      useCachedValue: false
    }
    let actionCreator = {
      type: getServiceType( 'storeDetail', 'success' ),
      data
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '560',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '561',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '562',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '563',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '564',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '565',
          'displayCheckAvailabilityButton': true
        }
      ],
      storeServiceData:{
        'items': [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          }
        ]
      },
      storeTotalPages:1,
      storeNotFound:false,
      loadingMoreStores:false,
      loadMoreResults:false,
      isLocationBlocked:true,
      storeCurrentPageNum:1,
      storeServiceRequested:true
    }
    expect( reducer( { storeCurrentPageNum:1, storeServiceRequested:true, isLocationBlocked:true }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set inputFieldFocus to true if field is focused', () => {
    let actionCreator = {
      type: SEARCH_FOCUSED
    };
    let expectedOutput = {
      inputFieldFocus: true
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set inputFieldFocus to false if field is not focused', () => {
    let actionCreator = {
      type: SEARCH_UNFOCUSED
    };
    let expectedOutput = {
      inputFieldFocus: false
    };
    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set searchButtonFocus to true if field is focused', () => {
    let actionCreator = {
      type: SEARCH_BUTTON_FOCUSED
    };
    let expectedOutput = {
      searchButtonFocus: true
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set searchButtonFocus to false if field is not focused', () => {
    let actionCreator = {
      type: SEARCH_BUTTON_UNFOCUSED
    };
    let expectedOutput = {
      searchButtonFocus: false
    };
    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );


  it( 'should set openFindInStoreModal to false if the close button is clicked', () => {
    let actionCreator = {
      type: CLOSE_FIND_IN_STORE_MODAL
    };
    let expectedOutput = {
      openFindInStoreModal: false
    };
    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'storeProductAvailability success case with inventoryStatus response as IN STOCK', ( ) => {
    const data = {
      storeId:'121',
      inventoryStatus:'IN STOCK'
    }
    let actionCreator = {
      type: getServiceType( 'storeProductAvailability', 'success' ),
      data
    }
    let state = {
      storeDetailData:[
        {
          'storeId': '121',
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          }
        },
        {
          'storeId': '561',
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          }
        }
      ]
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '121',
          'displayCheckAvailabilityButton': false,
          'showStoreAvailability': true,
          'showPickUpAvailability': true,
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          },
          storeAvailability:{
            message: 'In Stock at the Store',
            status: 'IN STOCK'
          }
        },
        {
          'storeId': '561',
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          }
        }
      ]
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'storeProductAvailability success case with inventoryStatus response as OUT OF STOCK', ( ) => {
    const data = {
      storeId:'121',
      inventoryStatus:'OUT OF STOCK'
    }
    let actionCreator = {
      type: getServiceType( 'storeProductAvailability', 'success' ),
      data
    }
    let state = {
      storeDetailData:[
        {
          'storeId': '121',
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          }
        },
        {
          'storeId': '561',
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          }
        }

      ]
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '121',
          'displayCheckAvailabilityButton': false,
          'showStoreAvailability': true,
          'showPickUpAvailability': true,
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          },
          storeAvailability:{
            message: 'Not In Stock at the Store',
            status: 'OUT OF STOCK'
          }
        },
        {
          'storeId': '561',
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          }
        }

      ]
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'storeProductAvailability success case with inventoryStatus response as NO DATA', ( ) => {
    const data = {
      storeId:'121',
      inventoryStatus:'NO DATA'
    }
    let actionCreator = {
      type: getServiceType( 'storeProductAvailability', 'success' ),
      data
    }
    let state = {
      storeDetailData:[
        {
          'storeId': '121',
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          }
        },
        {
          'storeId': '561',
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          }
        }

      ]
    }
    let expectedOutput = {
      storeDetailData:[
        {
          'storeId': '121',
          'displayCheckAvailabilityButton': false,
          'showStoreAvailability': true,
          'showPickUpAvailability': true,
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          },
          storeAvailability:{
            message: 'Oh no!  We don\'t have information for that store right now.',
            status: 'NO DATA'
          }
        },
        {
          'storeId': '561',
          bopisAvailability: {
            message: 'Not Available for Buy Online & Pickup in store',
            status: 'notAvailable'
          }
        }

      ]
    }

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'loadMoreResults requested case', ( ) => {
    let actionCreator = {
      type: getServiceType( 'loadMoreResults', 'requested' )
    }
    let state = {
      storeServiceData:{
        'items': [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          },
          {
            'storeId': '566'
          },
          {
            'storeId': '567'
          },
          {
            'storeId': '568'
          },
          {
            'storeId': '569'
          },
          {
            'storeId': '570'
          },
          {
            'storeId': '571'
          }
        ]
      },
      storeCurrentPageNum:1,
      storeTotalPages:2

    }
    let expectedOutput = {
      storeServiceData:{
        'items': [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          },
          {
            'storeId': '566'
          },
          {
            'storeId': '567'
          },
          {
            'storeId': '568'
          },
          {
            'storeId': '569'
          },
          {
            'storeId': '570'
          },
          {
            'storeId': '571'
          }
        ]
      },
      storeCurrentPageNum:2,
      storeTotalPages:2,
      loadMoreResults:false
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'loadMoreResults success case ', ( ) => {
    let actionCreator = {
      type: getServiceType( 'loadMoreResults', 'success' )
    };
    let state = {
      storeCurrentPageNum:2,
      storeTotalPages:3,
      loadingMoreStores:true,
      loadMoreResults:false,
      storeDetailData:[
        {
          'storeId': '560'
        },
        {
          'storeId': '561'
        },
        {
          'storeId': '562'
        },
        {
          'storeId': '563'
        },
        {
          'storeId': '564'
        },
        {
          'storeId': '565'
        },
        {
          'storeId': '566'
        },
        {
          'storeId': '567'
        },
        {
          'storeId': '568'
        },
        {
          'storeId': '569'
        }
      ],
      storeServiceData:{
        'items': [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          },
          {
            'storeId': '566'
          },
          {
            'storeId': '567'
          },
          {
            'storeId': '568'
          },
          {
            'storeId': '569'
          },
          {
            'storeId': '570'
          },
          {
            'storeId': '571'
          }
        ]
      }
    }
    let expectedOutput = {
      storeCurrentPageNum:2,
      storeTotalPages:3,
      loadingMoreStores:false,
      loadMoreResults:true,
      storeDetailData:[
        {
          'storeId': '560'
        },
        {
          'storeId': '561'
        },
        {
          'storeId': '562'
        },
        {
          'storeId': '563'
        },
        {
          'storeId': '564'
        },
        {
          'storeId': '565'
        },
        {
          'storeId': '566'
        },
        {
          'storeId': '567'
        },
        {
          'storeId': '568'
        },
        {
          'storeId': '569'
        },
        {
          'storeId': '570',
          'displayCheckAvailabilityButton': true
        },
        {
          'storeId': '571',
          'displayCheckAvailabilityButton': true
        }
      ],
      storeServiceData:{
        'items': [
          {
            'storeId': '560'
          },
          {
            'storeId': '561'
          },
          {
            'storeId': '562'
          },
          {
            'storeId': '563'
          },
          {
            'storeId': '564'
          },
          {
            'storeId': '565'
          },
          {
            'storeId': '566'
          },
          {
            'storeId': '567'
          },
          {
            'storeId': '568'
          },
          {
            'storeId': '569'
          },
          {
            'storeId': '570'
          },
          {
            'storeId': '571'
          }
        ]
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'should remove the store not found error when user clear the  input field ', ( ) => {
    const state = {
      storeNotFound:true
    }
    let actionCreator = {
      type: REDUXFORM_CHANGE,
      meta:{
        form:'FindInStore',
        field:'searchField',
        active: false
      },
      payload:''
    }
    let expectedOutput = {
      storeNotFound:false
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );
  describe( 'search term is empty test cases', ( ) => {
    it( 'should set isLocationBlocked to false if geoLocationOverride is false and search term is empty on latLong success', ( ) => {
      const state = {
        isLocationBlocked: true,
        storeSearchValue: ''
      }
      const expectedOutput = {
        isLocationBlocked: false,
        storeSearchValue: ''
      };
      const actionCreator = {
        type: getServiceType( 'latLong', 'success' ),
        data:{
          geoLocationOverride: false
        }
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should retain isLocationBlocked to true if no data is returned on latLong success', ( ) => {
      const state = {
        isLocationBlocked: true,
        storeSearchValue: ''
      }
      const expectedOutput = {
        isLocationBlocked: true,
        storeSearchValue: ''
      };
      const actionCreator = {
        type: getServiceType( 'latLong', 'success' )
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'search term is not empty test cases', ( ) => {

    it( 'should return loadingMoreStores true when on latLong loading', ( ) => {
      const state = {
        isLocationBlocked: true,
        storeSearchValue: 'fgdgdg'
      }
      const expectedOutput = {
        isLocationBlocked: true,
        storeSearchValue: 'fgdgdg',
        loadingMoreStores:true
      };
      const actionCreator = {
        type: getServiceType( 'latLong', 'loading' )
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should retain isLocationBlocked to true if geoLocationOverride is false on latLong success', ( ) => {
      const state = {
        isLocationBlocked: true,
        storeSearchValue: 'fgdgdg'
      }
      const expectedOutput = {
        isLocationBlocked: true,
        storeSearchValue: 'fgdgdg'
      };
      const actionCreator = {
        type: getServiceType( 'latLong', 'success' ),
        data:{
          geoLocationOverride: false
        }
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should retain isLocationBlocked to true if no data is returned on latLong success', ( ) => {
      const state = {
        isLocationBlocked: true,
        storeSearchValue: 'fgdgdg'
      }
      const expectedOutput = {
        isLocationBlocked: true,
        storeSearchValue: 'fgdgdg'
      };
      const actionCreator = {
        type: getServiceType( 'latLong', 'success' )
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'selector tests', () => {

    it( 'should return search term when  getSearchTerm is invoked', () => {

      let state = {
        form:{
          FindInStore:{
            values:{
              searchField:'test'
            }
          }
        }
      };
      expect( getSearchTerm( state ) ).toBe( 'test' ) ;
      state = {
        form:{
        }
      };
      expect( getSearchTerm( state ) ).toBe( '' );

    } );

    it( 'should return storeDetails data  when  getStoreDetailData is invoked', () => {

      let state = {
        findInStore : {
          storeDetailData: {
            name:'bolingbrook',
            address:'430 weber'
          },
          storeNotFound: false
        }
      };
      expect( getStoreDetailData( state ) ).toBe( state.findInStore.storeDetailData ) ;

    } );

    it( 'should return storeNotFound value when getStoreNotFound is invoked', () => {

      let state = {
        findInStore : {
          storeNotFound: false
        }
      };
      expect( getStoreNotFound( state ) ).toBe( false ) ;
      state.findInStore.storeNotFound = true;
      expect( getStoreNotFound( state ) ).toBe( true ) ;

    } );

    it( 'should return storeServiceRequested value when getStoreServiceRequested is invoked', () => {

      let state = {
        findInStore : {
          storeServiceRequested: false
        }
      };
      expect( getStoreServiceRequested( state ) ).toBe( false ) ;
      state.findInStore.storeServiceRequested = true;
      expect( getStoreServiceRequested( state ) ).toBe( true ) ;

    } );

    it( 'should return loadingMoreStores value when getloadingMoreStores is invoked', () => {

      let state = {
        findInStore : {
          loadingMoreStores: false
        }
      };
      expect( getLoadingMoreStores( state ) ).toBe( false ) ;
      state.findInStore.loadingMoreStores = true;
      expect( getLoadingMoreStores( state ) ).toBe( true ) ;

    } );



    describe( 'shouldDisplayDefaultLocationMessage selector tests', () => {

      let state = {
        findInStore : {
          storeDetailData: undefined,
          storeNotFound: false,
          loadingMoreStores: false,
          storeServiceRequested: false
        },
        form:{
          FindInStore:{
            values:{
              searchField:''
            }
          }
        }
      };

      it( 'should return true', () => {
        let returnValue = shouldDisplayDefaultLocationMessage( state );
        expect( returnValue ).toBe( true );
        expect( shouldDisplayDefaultLocationMessage.recomputations() ).toBe( 1 );
      } );

      it( 'should return true if the state has not changed', () => {
        let returnValue = shouldDisplayDefaultLocationMessage( state );
        expect( returnValue ).toBe( true );
        // since the state value has not changed the selector will return the memoized value and will not do the recomputattion
        expect( shouldDisplayDefaultLocationMessage.recomputations() ).toBe( 1 );
      } );

      it( 'should return false and compute since the state has changed', () => {
        state.form.FindInStore.values.searchField = 'test';
        let returnValue = shouldDisplayDefaultLocationMessage( state );
        expect( returnValue ).toBe( false );
        // since the state value has changed the selector will do the recomputattion and the recomputation count will increase by 1
        expect( shouldDisplayDefaultLocationMessage.recomputations() ).toBe( 2 );

      } );
    } );

  } );
} );
