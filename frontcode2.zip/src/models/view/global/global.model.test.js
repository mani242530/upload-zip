import _ from 'lodash';


import {
  getServiceType,
  registerServiceName
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  TOGGLE_SEARCH_MODE
} from 'ulta-fed-core/dist/js/events/header/header.events';

import {
  REGISTER_REMOVE_IOS_RUBBER_EFFECT,
  ENABLE_QUBIT_READY_FLAG,
  ALERT_WINDOW_RESIZE,
  ENABLE_DISABLE_DOCUMENT_SCROLL,
  BROADCAST_MESSAGE_SET,
  OPEN_STATUS_ERROR_POPUP,
  CLOSE_STATUS_ERROR_POPUP
} from 'ulta-fed-core/dist/js/events/global/global.events';

import {
  TOGGLE_SHOW_EMAIL_SIGN_UP_FORM
} from 'ulta-fed-core/dist/js/events/email_sign_up/email_sign_up.events';

import { isServer } from 'ulta-fed-core/dist/js/utils/device_detection/device_detection';

import { configureStore } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';

import reducer, {
  initialState,
  selectGlobal,
  makeGetSwitchesData,
  makeGetDocumentDimensions
} from './global.model';


let store = configureStore( );

store.getState().global = {
  switchData : {
    switches:{
      test:'test'
    }
  }
};

const getInnerWidth = function(){
  return window.innerWidth < 992
};

describe( 'Global Reducer', () => {

  it( 'should be a function', () => {
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  it( 'should have the proper default state', ( ) => {
    const expectedState = {
      HTML_ELEMENT_CLASS: '',
      screenWidth: 0,
      screenHeight: 0,
      mobileWidth:992,
      currentScrollPosition: 0,
      displayType:'',
      blockDocumentScroll: false,
      noRubberEffect: [],
      switchData: undefined,
      qubitReady: false,
      fireLps: false,
      canFireLpsEvent: false,
      assertiveMessageAdd: '',
      isMobileDevice: isServer() ? false : getInnerWidth(),
      isWiderDevice:true,
      isServerSideRendered:false,
      displayStatusErrorPopUp:false
    };
    expect( initialState ).toEqual( expectedState );
  } );

  describe( 'register remove ios rubber effects', () => {

    let elem = '<div></div>';

    let actionCreator = {
      type: REGISTER_REMOVE_IOS_RUBBER_EFFECT,
      elem
    };

    it( 'should handle the event and set the \'noRubberEffect\' attribute', () => {
      let registry = [];
      registry.push( elem );

      let expectedOutput = {
        noRubberEffect: registry
      };

      expect( reducer( { noRubberEffect: [] }, actionCreator ) ).toEqual( expectedOutput );
    } );


  } );

  describe( 'register ENABLE_QUBIT_READY_FLAG', () => {

    let expectedOutput = {
      'canFireLpsEvent': false,
      'qubitReady': true
    };

    let actionCreator = {
      type: ENABLE_QUBIT_READY_FLAG
    };

    it( 'should handle the event and set the \'noRubberEffect\' attribute', () => {

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );


  } );

  describe( 'ALERT_WINDOW_RESIZE', () => {

    let screenHeight = 400;
    let screenWidth = 400;

    let actionCreator = {
      type: ALERT_WINDOW_RESIZE,
      screenHeight,
      screenWidth
    };

    it( 'should set displayType attribute to mobile if the screenWidth is below 992px', () => {

      window.innerWidth = 991;
      let screenHeight = 400;
      let screenWidth = 991;
      let actionCreator1 = {
        type: ALERT_WINDOW_RESIZE,
        screenHeight,
        screenWidth
      };

      let expectedOutput1 = {
        isMobileDevice: true,
        isWiderDevice:false,
        screenHeight,
        screenWidth,
        mobileWidth:992,
        displayType: 'mobile'
      };
      expect( reducer( { mobileWidth:992 }, actionCreator1 ) ).toEqual( expectedOutput1 );
    } );

    it( 'should set displayType attribute to desktop if the screenWidth is equal and above 992px', () => {
      window.innerWidth = 993;
      let screenHeight = 400;
      let screenWidth = 993;
      let actionCreator2 = {
        type: ALERT_WINDOW_RESIZE,
        screenHeight,
        screenWidth
      };

      let expectedOutput2 = {
        isMobileDevice: false,
        isWiderDevice:true,
        screenHeight,
        screenWidth,
        mobileWidth:992,
        displayType: 'desktop'
      };
      expect( reducer( { mobileWidth:992 }, actionCreator2 ) ).toEqual( expectedOutput2 );
    } );

    it( 'should handle the event and set the \'screenHeight\' attribute', () => {
      let expectedOutput = {
        isMobileDevice: true,
        isWiderDevice:true,
        screenHeight,
        screenWidth,
        displayType: 'mobile',
        mobileWidth:992
      };

      expect( reducer( { mobileWidth:992 }, actionCreator ) ).toEqual( expectedOutput );
    } );



    it( 'should update the states \'screenHeight\' attribute', () => {
      let screenWidth = Math.random();
      window.innerWidth = screenWidth;
      actionCreator.screenHeight = Math.random();
      actionCreator.screenWidth = Math.random();

      let expectedOutput = {
        ...initialState,
        isMobileDevice: screenWidth < 992,
        isWiderDevice:screenWidth > 991,
        screenHeight: actionCreator.screenHeight,
        screenWidth: actionCreator.screenWidth,
        displayType: 'mobile'
      };

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );
  describe( 'ENABLE_DISABLE_DOCUMENT_SCROLL', () => {

    let enable = true;

    let actionCreator = {
      type: ENABLE_DISABLE_DOCUMENT_SCROLL,
      enable
    };

    it( 'should handle the event and set the \'enabled\' attribute', () => {

      let expectedOutput = {
        blockDocumentScroll: true
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should update the states \'blockDocumentScroll\' attribute', () => {

      actionCreator.enable = false;
      let expectedOutput = Object.assign( {}, initialState,
        {
          blockDocumentScroll: false
        } );

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'TOGGLE_SHOW_EMAIL_SIGN_UP_FORM', () => {

    let actionCreator = {
      type: TOGGLE_SHOW_EMAIL_SIGN_UP_FORM,
      data: false
    };

    it( 'should handle the event and set the \'HTML_ELEMENT_CLASS\' when closed', () => {
      let expectedOutput = {
        HTML_ELEMENT_CLASS: ''
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should handle the event and set the \'HTML_ELEMENT_CLASS\' when open', () => {
      actionCreator.data = true;
      let expectedOutput = {
        HTML_ELEMENT_CLASS: 'BLOCK_PAGE_SCROLL'
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'TOGGLE_SEARCH_MODE', () => {

    let actionCreator = {
      type: TOGGLE_SEARCH_MODE,
      mode: 'close'
    };

    it( 'should handle the event and set the \'HTML_ELEMENT_CLASS\' when closed', () => {

      let expectedOutput = {
        HTML_ELEMENT_CLASS: ''
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should handle the event and set the \'HTML_ELEMENT_CLASS\' when open', () => {

      actionCreator.mode = 'open';

      let expectedOutput = {
        HTML_ELEMENT_CLASS: 'BLOCK_PAGE_SCROLL'
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );


  } );

  describe( 'RealtimeOLPS data  request success', () => {

    registerServiceName( 'RealtimeOLPS' );


    it( 'should set tfireLps to true', () => {
      let res = {
        'olpsResponse': {
          'cardType': null,
          'firstName': null,
          'responseType': '03',
          'preScreenId': null
        }
      };

      let actionCreator = {
        type: getServiceType( 'RealtimeOLPS', 'success' ),
        data: res
      };

      let expectedOutput = {
        ...initialState,
        fireLps: true
      };
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Broadcast Message Set', () => {

    it( 'should set assertiveMessageAdd attribute', () => {

      let actionCreator = {
        type: BROADCAST_MESSAGE_SET,
        data: '$5 Gift Card (****1212 1212 1212 1212) Applied!'
      };

      let expectedOutput = {
        assertiveMessageAdd: '$5 Gift Card (****1212 1212 1212 1212) Applied!'
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'OPEN_STATUS_ERROR_POPUP', () => {

    it( 'should set displayStatusErrorPopUp attribute to true', () => {

      let actionCreator = {
        type: OPEN_STATUS_ERROR_POPUP
      };

      let expectedOutput = {
        displayStatusErrorPopUp: true
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'CLOSE_STATUS_ERROR_POPUP', () => {

    it( 'should set displayStatusErrorPopUp attribute to false', () => {

      let actionCreator = {
        type: CLOSE_STATUS_ERROR_POPUP
      };

      let expectedOutput = {
        displayStatusErrorPopUp: false
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Switches data initialization', () => {

    it( 'should set the correct data on the state', () => {

      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data: { switches: { test: 'test' } }
      };

      let expectedOutput = {
        switchData: {
          switches: {
            test: 'test',
            enableRefBeaconScript: false
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set a derived flag of \'enableRefBeaconScript\' to false if both of the reflektion related flags are not present', () => {

      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data: { switches: { test: 'test' } }
      };

      let expectedOutput = {
        switchData: {
          switches: {
            test: 'test',
            enableRefBeaconScript: false
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set a derived flag of \'enableRefBeaconScript\' to false if either of the reflektion related flags are present and set to false', () => {

      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data: { switches: { test: 'test', visualSearchEnabled : false } }
      };

      let expectedOutput = {
        switchData: {
          switches: {
            test: 'test',
            visualSearchEnabled : false,
            enableRefBeaconScript: false
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set a derived flag of \'enableRefBeaconScript\' to false if all the reflektion related flags are present and set to false', () => {

      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data: {
          switches: {
            test: 'test', visualSearchEnabled : false, enableRfkRecommendation : false, enableRfkEvents:false
          }
        }
      };

      let expectedOutput = {
        switchData: {
          switches: {
            test: 'test',
            visualSearchEnabled : false,
            enableRfkRecommendation : false,
            enableRefBeaconScript: false,
            enableRfkEvents:false
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set a derived flag of \'enableRefBeaconScript\' to true if either of the reflektion related flags are present and set to true', () => {

      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data: { switches: { test: 'test', visualSearchEnabled : true } }
      };

      let expectedOutput = {
        switchData: {
          switches: {
            test: 'test',
            visualSearchEnabled : true,
            enableRefBeaconScript: true
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set a derived flag of \'enableRefBeaconScript\' to true if all the reflektion related flags are present and set to true', () => {

      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data: {
          switches: {
            test: 'test', visualSearchEnabled : true, enableRfkRecommendation : true, enableRfkEvents:true
          }
        }
      };

      let expectedOutput = {
        switchData: {
          switches: {
            test: 'test',
            visualSearchEnabled : true,
            enableRfkRecommendation : true,
            enableRefBeaconScript: true,
            enableRfkEvents:true
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set a derived flag of \'enableVirtualTryOn\' to true if  enableVirtualTryOn and enableVirtualTryOnLandingPage flags are true', () => {

      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data: {
          switches: {
            test: 'test', enableVirtualTryOn : true, enableVirtualTryOnLandingPage : true
          }
        }
      };

      let expectedOutput = {
        switchData: {
          switches: {
            test: 'test',
            enableVirtualTryOn: true,
            virtualTryOnEnabled:true,
            enableVirtualTryOnLandingPage:true,
            enableRefBeaconScript: false
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set a derived flag of \'enableVirtualTryOn\' to false if either of enableVirtualTryOn and enableVirtualTryOnLandingPage flags are false', () => {

      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data: {
          switches: {
            test: 'test', enableVirtualTryOn : true, enableVirtualTryOnLandingPage : false
          }
        }
      };

      let expectedOutput = {
        switchData: {
          switches: {
            test: 'test',
            enableVirtualTryOn: true,
            virtualTryOnEnabled:false,
            enableVirtualTryOnLandingPage:false,
            enableRefBeaconScript: false
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'selectGlobal', () => {
    it( 'selectGlobal should return global state', () => {
      const state = {
        global: {
          HTML_ELEMENT_CLASS: '',
          screenWidth: 0,
          screenHeight: 0,
          currentScrollPosition: 0,
          displayType:'',
          blockDocumentScroll: false,
          noRubberEffect: [],
          switchData: undefined,
          qubitReady: false,
          fireLps: false,
          canFireLpsEvent: false,
          assertiveMessageAdd: '',
          isMobileDevice: isServer() ? false : getInnerWidth(),
          isServerSideRendered:false,
          displayStatusErrorPopUp:false
        }
      };
      expect( selectGlobal( state ) ).toEqual( state.global );
    } );
    it( 'should return the switchData attribute from the Global reducer', () => {
      const globalState =         {
        switchData: {
          switches:{
            test:'test'
          }
        }
      }
      store.getState().global.switchData = {
        switches:{
          test:'test'
        }
      };
      const selector = makeGetSwitchesData();
      expect( selector( store.getState() ) ).toEqual( globalState.switchData );

    } );
    it( 'should return the width and height attribute from the Global reducer', () => {
      const globalState = {
        screenWidth: 88,
        screenHeight: 5
      }
      store.getState().global = {
        screenWidth: 88,
        screenHeight: 5
      };
      const selector = makeGetDocumentDimensions();
      expect( selector( store.getState() ) ).toEqual( { width: globalState.screenWidth, height: globalState.screenHeight } );

    } );
  } );

} );
