import { createSelector } from 'reselect';

import {
  ALERT_WINDOW_RESIZE
} from 'ulta-fed-core/dist/js/events/global/global.events'

import {
  SET_HEADER_DISPLAY_MODE,
  SET_HEADER_HEIGHT,
  GET_NAV_ITEM_LIST,
  SET_SHIPPING_BANNER_HEIGHT,
  TOGGLE_REWARDS_OPTION,
  TOGGLE_SIGNIN_OPTION
} from 'ulta-fed-core/dist/js/events/header/header.events'

import {
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import has from 'lodash/has';
import get from 'lodash/get';
/**
 * default state for the Header
 */

export const initialState = {
  mobileHeaderDisplayMode: 'no_search',
  desktopHeaderDisplayMode: {
    displayLeftNav: true,
    displaySearchBar: true,
    displayLinks: true,
    displayMiniCartIcon: true,
    displayMiniCartFlyout: true,
    displayShippingBanner: true,
    isReactPage: true,
    isHeaderSticky: true
  },
  shippingBanner: {
    message: undefined,
    mobileMessage: undefined,
    desktopMessage: undefined,
    url: undefined
  },
  cartPageShippingBanner: {
    message: undefined
  },
  headerHeight:undefined,
  signInOption: false,
  rewardsOption: false
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){
  let newState;
  switch ( action.type ){

    case SET_HEADER_DISPLAY_MODE:

      return {
        ...state,
        [action.deviceType]: action.mode
      }

    case SET_HEADER_HEIGHT:
      return {
        ...state,
        headerHeight: action.headerHeight
      }


    case getServiceType( 'navigation', 'success' ):

      let shippingBanner = {
        mobileMessage: action.data.mobileNavContent.shippingPromoContent.mobileContent,
        desktopMessage: action.data.desktopNavContent.shippingPromoContent.content,
        message: action.data.mobileNavContent.shippingPromoContent.mobileContent
      }

      return {
        ...state,
        shippingBanner
      }

    case getServiceType( 'updateCartItems', 'success' ):
    case getServiceType( 'initiateCheckout', 'success' ):
    case getServiceType( 'addGiftWrap', 'success' ):
    case getServiceType( 'applycoupon', 'success' ):
    case getServiceType( 'removecoupon', 'success' ):
    case getServiceType( 'addItemToCart', 'success' ):
    case getServiceType( 'selectGiftVariant', 'success' ):
    case getServiceType( 'loadCart', 'success' ):
    case getServiceType( 'deliveryOptionsUpdate', 'success' ):
    case getServiceType( 'cartPickupInfoUpdate', 'success' ):
      if( has( action.data, 'banner.messages.items' ) ){
        return {
          ...state,
          cartPageShippingBanner: {
            message: action.data.banner.messages.items[0].message
          }
        }
      }
      else {
        return {
          ...state,
          cartPageShippingBanner: {
            message: undefined
          }
        }
      }
    case getServiceType( 'moveToBagFromSaveForLater', 'success' ):
    case getServiceType( 'moveToSaveForLater', 'success' ):

      return {
        ...state,
        ...( action.data.cart && {
          cartPageShippingBanner:{
            message:get( action.data, 'cart.banner.messages.items[0].message' )
          }
        } )
      }

    case getServiceType( 'removeItemFromCart', 'success' ):
      if( has( action.data.type, 'banner.messages.items' ) ){
        return {
          ...state,
          cartPageShippingBanner: {
            message: action.data.type.banner.messages.items[0].message
          }
        }
      }
      else {
        return {
          ...state,
          cartPageShippingBanner: {
            message: undefined
          }
        }
      }


    case GET_NAV_ITEM_LIST:

      let navData = action.navData
      let navItems = {};

      let desktopNavPanelList = navData.navList.map( ( navPanelItem, index ) => {

        let navItems = {};
        let panelPaginationLength = 30;
        let flyout = navPanelItem.flyout;

        let paginatedNavItems = [];
        let panelIndex = 0;
        let flattenedNavItemList;

        if( navPanelItem.categories && navPanelItem.categories.length > 0 ){

          // iterate over categories and flatten them into a single array
          flattenedNavItemList = navPanelItem.categories.map( ( navItem ) => {
            const arrayDepth = 0;
            return flattenNavItem( navItem, arrayDepth )
          } )

          // extract nested arrays
          let combinedNavItems = [].concat( ...flattenedNavItemList );

          // calculate number of panels needed
          const numberOfPanels = Math.ceil( combinedNavItems.length / panelPaginationLength );

          // iterate over panels and add them to the paginatedNavItems list
          for ( var currentPanelNumber = 0; currentPanelNumber < numberOfPanels; currentPanelNumber++ ){
            paginatedNavItems.push( paginateNavItems( combinedNavItems, currentPanelNumber, panelPaginationLength ) )
          }
        }

        if( flyout && flyout.length > 0 ){

          let flyoutList = flyout.map( ( imageData, index ) => {
            return [imageData];
          } )

          for ( var i = 0; i < flyoutList.length; i++ ){
            paginatedNavItems.push( flyoutList[ i ] );
          }
        }

        let _navPanelItem = navPanelItem;
        _navPanelItem.paginatedNavItems = paginatedNavItems
        return _navPanelItem
      } )

      navItems.desktopNavPanelList = desktopNavPanelList;

      return {
        ...state,
        ...navItems
      }

    case SET_SHIPPING_BANNER_HEIGHT:

      return Object.assign( {}, state, {
        shippingBannerHeight: action.height
      } );

    case TOGGLE_REWARDS_OPTION:

      return {
        ...state,
        rewardsOption: !state.rewardsOption,
        signInOption: false
      }

    case TOGGLE_SIGNIN_OPTION:

      return {
        ...state,
        signInOption: !state.signInOption,
        rewardsOption: false
      }


    case ALERT_WINDOW_RESIZE:

      return Object.assign( {}, state, {
        // setting the MobileHeaderHeight here is a way to force the reducer to update the props and force a setHeaderHeight method call
        MobileHeaderHeight: state.MobileHeaderHeight + 1,
        screenHeight: action.screenHeight
      } );

    case getServiceType( 'logout', 'success' ):
      let cartPageShippingBanner = {
        message: undefined
      }

      if( action.data.redirectURL ){
        return {
          ...state,
          cartPageShippingBanner
        }
      }


    default:
      return state;
  }
}


/**
 * takes a navItem with nested arrays of categories of 'n' depth
 * and flattens them into a single array while adding an attribute
 * of 'displayAsSubCategory' set to true for all nested objects so
 * we can display them properly
 *
 */
export const flattenNavItem = ( navItem, arrayDepth ) => {

  let navItemList = [navItem];
  let subNavItems = [];

  if( navItem.categories && navItem.categories.length > 0 ){
    subNavItems = navItem.categories.map( ( subNavItem ) => {

      let _subNavItem = subNavItem;

      // setting 'displayAsSubCategory' to true will allow us to add
      // a class to this item in the display so we can display this
      // nav Item as 'capitalized' rather than 'uppercase'
      _subNavItem.displayAsSubCategory = true;

      let subNavList = [_subNavItem]
      let flattenedNavItems = [];

      // if the navItem has more categories, recursively call this
      // function again to flatten and combine them into the
      // final list
      if( _subNavItem.categories && _subNavItem.categories.length > 0 ){
        flattenedNavItems = flattenNavItem( _subNavItem, arrayDepth + 1 );
      }

      return subNavList;
    } )
  }

  // pull the objects out of the nested inner array, which is not necessary
  let new_subNavItems = [].concat( ...subNavItems );

  // combine the navItemList (original navItem ) with the new_subNavItems
  let flattenedNavItemList = [...navItemList, ...new_subNavItems];

  return flattenedNavItemList;
}

/**
 * takes a list of navItems and a panelNumber and
 * returns the appropriate slice of the list for that
 * panelNumber for display purposes
 *
 */
export const paginateNavItems = ( navItemsList, panelNumber, panelPaginationLength ) => {
  let length = panelPaginationLength;
  return navItemsList.slice( panelNumber * length, ( panelNumber + 1 ) * length )
}
