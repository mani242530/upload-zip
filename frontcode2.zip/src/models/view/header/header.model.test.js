
import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  ALERT_DOCUMENT_SCROLL,
  ALERT_WINDOW_RESIZE
} from 'ulta-fed-core/dist/js/events/global/global.events';

import {
  SET_HEADER_HEIGHT,
  SET_SHIPPING_BANNER_HEIGHT,
  getNavItemList,
  TOGGLE_SIGNIN_OPTION,
  TOGGLE_REWARDS_OPTION
} from 'ulta-fed-core/dist/js/events/header/header.events';


import _ from 'lodash';
import navData from '../../../views/LeftNav/Desktop/DesktopLeftNav/DesktopLeftNavData';
import reducer, {
  initialState,
  flattenNavItem,
  paginateNavItems
} from './header.model';



describe( 'Header Reducer', () => {

  registerServiceName( 'moveToBagFromSaveForLater' );
  registerServiceName( 'moveToSaveForLater' );

  it( 'should have the proper default state', () => {

    let expectedState1 = {
      mobileHeaderDisplayMode: 'no_search',
      desktopHeaderDisplayMode: {
        displayLeftNav: true,
        displaySearchBar: true,
        displayLinks: true,
        displayMiniCartIcon: true,
        displayMiniCartFlyout: true,
        displayShippingBanner: true,
        isReactPage: true,
        isHeaderSticky: true
      },
      shippingBanner: {
        message: undefined,
        url: undefined
      },
      cartPageShippingBanner: {
        message: undefined
      },
      signInOption: false,
      rewardsOption: false
    }

    expect( initialState ).toEqual( expectedState1 );

  } );

  it( 'should be a function', () => {
    expect( _.isFunction( reducer ) ).toBe( true );

  } );

  it( 'should be a function', () => {
    expect( _.isFunction( reducer ) ).toBe( true );

  } );


  describe( 'ALERT_DOCUMENT_SCROLL', () => {
    let currentScrollPosition = 100;
    let actionCreator = {
      type: ALERT_DOCUMENT_SCROLL,
      currentScrollPosition
    }


    it( 'should handle the event', () => {

      let expectedOutput1 = {
        searchMode: 'close'
      };

      let expectedOutput2 = {
        searchMode: 'close',
        currentScrollPosition,
        previousScrollPosition: currentScrollPosition,
        headerAnimationStyles: {},
        searchModeAnimationStyles: {}

      };

      expect( reducer( { searchMode: 'close' }, actionCreator ) ).toEqual( expectedOutput1 );

    } );

  } );

  describe( 'GET_NAV_ITEM_LIST', () => {

    let truncatedNavData = {
      'mobileNavContent': {
        'navType': 'LeftNav',
        'shippingPromoContent': null,
        'navList': [
          {
            'navDisplayContent': 'SHOP BY BRAND',
            'navElementType': 'rootCategory',
            'categories': [],
            'categoryLink': {
              'showInNewPage': false,
              'navTargetLink': 'http://local.ulta.com/global/nav/allbrands.jsp',
              'data-nav-description': 'm - shop by brand',
              'linkText': ''
            },
            'fontColor': 'nav-menu-style-melon'
          },
          {
            'displayFeatured': 'true',
            'flyout': [
              {
                'imageLink': {
                  'showInNewPage': false,
                  'navTargetLink': 'http://local.ulta.com/ulta/a/_/Ntt-urbanbeyondlookingglass/Nty-1?Dy=1&ciSelector=searchResults',
                  'linkText': '',
                  'data-slot-position': 'makeup_flyout_051516_makeup'
                },
                'navElementType': 'subcategory',
                'navAttributes': 'promoflyout',
                'imageAlt': 'Alice in Wonderland Makeup',
                'imgSrc': 'http://images.ulta.com/is/image/Ulta/flyout_051516_makeup'
              }
            ],
            'navDisplayContent': 'MAKEUP',
            'featuredDataNav': 'makeup:featured',
            'displayBookAppt': 'false',
            'navElementType': 'rootCategory',
            'featuredLabel': 'Featured',
            'categories': [
              {
                'navDisplayContent': 'Face',
                'navTargetLink': 'http://local.ulta.com/makeup-face?N=26y3',
                'navElementType': 'subCategory'
              }
            ],
            'categoryLink': {
              'showInNewPage': false,
              'navTargetLink': 'http://local.ulta.com/makeup?N=26y1',
              'data-nav-description': 'm - makeup',
              'linkText': ''
            },
            'fontColor': 'nav-menu-style-black'
          }
        ]
      }
    }

    let action = getNavItemList( truncatedNavData.mobileNavContent );


    it( 'should update the state', () => {
      expect( reducer( initialState, action ).desktopNavPanelList[0].navDisplayContent ).toBe( 'SHOP BY BRAND' )
    } );

    let fullDataAction = getNavItemList( navData.mobileNavContent );

    it( 'should return a list of paginatedNavItems of the passed in navItems', () => {
      expect( reducer( initialState, fullDataAction ).desktopNavPanelList.length ).toBe( 19 );
      expect( reducer( initialState, fullDataAction ).desktopNavPanelList[3].navDisplayContent ).toBe( 'SKIN CARE' )
    } );

  } );

  let navItem = navData.mobileNavContent.navList;
  let flattenedNavItemList = flattenNavItem( navItem, 0 );

  describe( 'flattenNavItem', () => {

    it( 'should flatten a nested list of navItems', () => {
      expect( flattenedNavItemList[0].length ).toBe( 19 );
    } );


  } );

  let navItem2 = {
    'navDisplayContent': 'Makeup by ULTA',
    'navTargetLink': 'http://local.ulta.com/ulta-collection-makeup?N=26vs',
    'navElementType': 'subCategory',
    'categories':
         [
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' },
           { navDisplayContent: 'Face' }
         ],
    dataNavDescription: 'm - ulta collection:makeup by ulta'
  };
  let flattenedNavItemList2 = flattenNavItem( navItem2, 0 );
  let paginatedNavItemsPanel1 = paginateNavItems( flattenedNavItemList2, 0, 30 );
  let paginatedNavItemsPanel2 = paginateNavItems( flattenedNavItemList2, 1, 30 );

  describe( 'paginateNavItems', () => {
    it( 'should paginate a list of navItems', () => {
      expect( paginatedNavItemsPanel1.length ).toBe( 30 );
      expect( paginatedNavItemsPanel2.length ).toBe( 3 );
    } );
  } );



  describe( 'ALERT_WINDOW_RESIZE', () => {
    let screenHeight = 400;

    let actionCreator = {
      type: ALERT_WINDOW_RESIZE,
      screenHeight
    }

    it( 'should handle the event and set the \'screenHeight\' attribute', () => {
      let expectedOutput = {
        screenHeight,
        MobileHeaderHeight: 101
      };
      expect( reducer( { MobileHeaderHeight: 100 }, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should update the states \'screenHeight\' attribute', () => {

      actionCreator.screenHeight = Math.random();
      initialState.MobileHeaderHeight = 100;
      let expectedOutput = Object.assign( {}, initialState,
        {
          screenHeight: actionCreator.screenHeight,
          MobileHeaderHeight:101
        } );

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

    } );


  } );

  describe( 'pagedatasuccess', () => {

    it( 'should set the shipping banner message', () => {
      let type = 'page';
      registerServiceName( type );
      let actionCreator = {
        type: getServiceType( 'navigation', 'success' ),
        data: {
          mobileNavContent: {
            shippingPromoContent: {
              mobileContent: 'DEMO'
            }
          },
          desktopNavContent: {
            shippingPromoContent: {
              content: 'WOW'
            }
          }
        }
      }

      let expectedOutput = {
        shippingBanner: {
          message: 'DEMO',
          mobileMessage: 'DEMO',
          desktopMessage: 'WOW'
        }
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'loadCart data success', () => {

    it( 'should set the shipping banner message in cart page', () => {
      let type = 'loadCart';
      registerServiceName( type );
      let actionCreator = {
        type: getServiceType( 'loadCart', 'success' ),
        data: {
          banner: {
            messages: {
              items: [
                {
                  type: 'info',
                  message: 'CartPage Header Message'
                }
              ]
            }
          }
        }
      }
      let expectedOutput = {
        cartPageShippingBanner: {
          message: 'CartPage Header Message'
        }
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'deliveryOptionsUpdate data success', () => {

    it( 'should set the shipping banner message in cart page', () => {
      let type = 'deliveryOptionsUpdate';
      registerServiceName( type );
      let actionCreator = {
        type: getServiceType( 'deliveryOptionsUpdate', 'success' ),
        data: {
          banner: {
            messages: {
              items: [
                {
                  type: 'info',
                  message: 'FREE In Store Pickup!'
                }
              ]
            }
          }
        }
      }
      let expectedOutput = {
        cartPageShippingBanner: {
          message: 'FREE In Store Pickup!'
        }
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'cartPickupInfoUpdate data success', () => {

    it( 'should set the shipping banner message in cart page', () => {
      let type = 'cartPickupInfoUpdate';
      registerServiceName( type );
      let actionCreator = {
        type: getServiceType( 'cartPickupInfoUpdate', 'success' ),
        data: {
          banner: {
            messages: {
              items: [
                {
                  type: 'info',
                  message: 'FREE In Store Pickup!'
                }
              ]
            }
          }
        }
      }
      let expectedOutput = {
        cartPageShippingBanner: {
          message: 'FREE In Store Pickup!'
        }
      }

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );


  describe( 'SET_SHIPPING_BANNER_HEIGHT', () => {

    let height = 55;

    let actionCreator = {
      type: SET_SHIPPING_BANNER_HEIGHT,
      height
    }

    it( 'should handle the event and set the \'shippingBannerHeight\' attribute', () => {

      let expectedOutput = {
        shippingBannerHeight: height
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should update the states \'shippingBannerHeight\' attribute', () => {

      actionCreator.height = Math.random();

      let expectedOutput = Object.assign( {}, initialState,
        {
          shippingBannerHeight: actionCreator.height
        } );

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'TOGGLE_REWARDS_OPTION', () => {

    const actionCreator = {
      type: TOGGLE_REWARDS_OPTION
    }

    it( 'should update the states \'rewardsOption\' and \'signInOption\' attribute', () => {

      const initialState = {
        rewardsOption: false,
        signInOption: true
      }

      const expectedOutput = {
        rewardsOption: true,
        signInOption: false
      }

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'TOGGLE_SIGNIN_OPTION', () => {

    const actionCreator = {
      type: TOGGLE_SIGNIN_OPTION
    }

    it( 'should update the states \'rewardsOption\' and \'signInOption\' attribute', () => {

      const initialState = {
        rewardsOption: false,
        signInOption: false
      }

      const expectedOutput = {
        rewardsOption: false,
        signInOption: true
      }

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );


  describe( 'set header height', () => {
    let headerHeight = 100;

    let actionCreator = {
      type: SET_HEADER_HEIGHT,
      headerHeight
    }

    it( 'should handle the event and set the headerHeight attribute', () => {

      let expectedOutput = {
        headerHeight
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'moveToBagFromSaveForLater success event', () => {



    it( 'should update cartPageShippingBanner if the move to bag from save for later event success response has banner message', () => {

      const data = {
        cart:{
          banner:{
            messages:{
              items:[{
                message:'You\'re $23.01 away from FREE shipping'
              }]
            }
          }
        }
      }
      const actionCreator = {
        type: getServiceType( 'moveToBagFromSaveForLater', 'success' ),
        data
      }

      const initialState = {
        cartPageShippingBanner:{
          message:'You\'re $43.01 away from FREE shipping'
        }
      }

      const expectedOutput = {
        cartPageShippingBanner:{
          message:'You\'re $23.01 away from FREE shipping'
        }
      }

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'should set cartPageShippingBanner has undefined if the move to bag from save for later success event doesnot response has banner message', () => {

      const data = {
        cart:{
          banner:{
            messages:undefined
          }
        }
      }
      const actionCreator = {
        type: getServiceType( 'moveToBagFromSaveForLater', 'success' ),
        data
      }

      const initialState = {
        cartPageShippingBanner:{
          message:'You\'re $43.01 away from FREE shipping'
        }
      }

      const expectedOutput = {
        cartPageShippingBanner:{
          message:undefined
        }
      }

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'moveToSaveForLater success event', () => {



    it( 'should update cartPageShippingBanner if the move to save for later event success response has banner message', () => {

      const data = {
        cart:{
          banner:{
            messages:{
              items:[{
                message:'You\'re $23.01 away from FREE shipping'
              }]
            }
          }
        }
      }
      const actionCreator = {
        type: getServiceType( 'moveToSaveForLater', 'success' ),
        data
      }

      const initialState = {
        cartPageShippingBanner:{
          message:'You\'re $43.01 away from FREE shipping'
        }
      }

      const expectedOutput = {
        cartPageShippingBanner:{
          message:'You\'re $23.01 away from FREE shipping'
        }
      }

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'should set cartPageShippingBanner has undefined if the move to save for later success event doesnot response has banner message', () => {

      const data = {
        cart:{
          banner:{
            messages:undefined
          }
        }
      }
      const actionCreator = {
        type: getServiceType( 'moveToSaveForLater', 'success' ),
        data
      }

      const initialState = {
        cartPageShippingBanner:{
          message:'You\'re $43.01 away from FREE shipping'
        }
      }

      const expectedOutput = {
        cartPageShippingBanner:{
          message:undefined
        }
      }

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

} );
