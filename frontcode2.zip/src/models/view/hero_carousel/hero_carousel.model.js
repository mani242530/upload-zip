/**
 * HeroCarousel Redux reducer Module
 *
 */

import {
  TOGGLE_AUTO_PLAY,
  SET_CURRENT_CAROUSEL_SLIDE
} from 'ulta-fed-core/dist/js/events/hero_carousel/hero_carousel.events';

/**
 * default state for the HeroCarousel reducer
 */

export const initialState = {
  settings: {
    accessibility: true,
    arrows: false,
    dots: true,
    lazyLoad: false,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    pauseOnHover: true
  },
  currentSlide: 0,
  carouselList: undefined
};

/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){

  switch ( action.type ){

    // Set Auto Play flag to true or false
    case TOGGLE_AUTO_PLAY:
      return {
        ...state,
        settings: {
          ...state.settings,
          autoplay: action.data
        }
      }

    // Set currentSlide to change the tabbing order for ADA
    case SET_CURRENT_CAROUSEL_SLIDE:
      return {
        ...state,
        currentSlide: action.data
      }

    default:
      return state;
  }

}
