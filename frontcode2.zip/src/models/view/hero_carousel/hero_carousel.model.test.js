import isFunction from 'lodash/isFunction';
import {
  TOGGLE_AUTO_PLAY,
  SET_CURRENT_CAROUSEL_SLIDE
} from 'ulta-fed-core/dist/js/events/hero_carousel/hero_carousel.events';
import reducer, {
  initialState
} from './hero_carousel.model';



describe( 'HeroCarousel reducer', ( ) => {

  it( 'should have the proper default state', ( ) => {

    let expectedOutput = {
      settings: {
        accessibility: true,
        arrows: false,
        dots: true,
        lazyLoad: false,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 5000,
        pauseOnHover: true
      },
      currentSlide: 0,
      carouselList: undefined
    };
    expect( initialState ).toEqual( expectedOutput );

  } );

  it( 'should be a function', ( ) => {
    expect( isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  it( 'toggle auto play hero carousel event', () => {
    let actionCreator = {
      type: TOGGLE_AUTO_PLAY,
      data: true
    }

    let expectedOutput = {
      settings: {
        autoplay: true
      }
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'check the set current carousel slide event', () => {
    let actionCreator = {
      type: SET_CURRENT_CAROUSEL_SLIDE,
      data: 1
    }

    let expectedOutput = {
      currentSlide: 1
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

} );
