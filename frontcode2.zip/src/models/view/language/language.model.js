/**
 * Language Reducer
 *
 * This reducer handles all data for the cart
 */

import { createSelector } from 'reselect';
import {
  CHANGE_LOCALE
} from 'ulta-fed-core/dist/js/events/language/language.events'

export const initialState = {
  locale: 'en'
};

export default ( state = initialState, action ) => {

  switch ( action.type ){

    case CHANGE_LOCALE:
      return { ...state, locale: action.locale };


    default:
      return state;
  }

}

/**
 * returns the langauge state object from the MAIN combine reducers reducer
 *
 * @return { object } - The language state object
 */
export const getLanguageState = () => ( state ) => state.language;



/**
 * gets the current locale value
 *
 * @return {object} An object that contains the server response for the chart data
 */
export const getLocale = () => createSelector(
  getLanguageState(),
  ( languageState ) => languageState.locale
);
