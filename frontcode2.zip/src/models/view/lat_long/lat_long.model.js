/*
* LatLong Reducer : stores the users searchValue ( city/state/zipCode etc.)
* and their translated values in redux
* */

import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

export const initialState = {
  searchValue: '',
  coordinates: undefined,
  currentLocationRequested : false
};

export default function reducer( state = initialState, action ){
  switch ( action.type ){
    case getServiceType( 'latLong', 'requested' ):
      return {
        ...state,
        searchValue: action.data,
        currentLocationRequested: state.currentLocationRequested
      };
    case getServiceType( 'latLong', 'success' ):
      return {
        ...state,
        coordinates: action.data,
        currentLocationRequested: true
      };

    default:
      return state;
  }
}

export const getLatLongState = state => state.latLong;