import {
  getServiceType,
  registerServiceName
} from 'ulta-fed-core/dist/js/events/services/services.events';
import reducer, {
  initialState,
  getLatLongState
} from './lat_long.model';



describe( 'LatLong reducer', ( ) => {

  registerServiceName( 'latLong' );

  const latLongData = {
    latitude: 121,
    longitude: 101
  };

  it( 'should have the proper default state', ( ) => {
    const expectedState = {
      searchValue: '',
      coordinates: undefined,
      currentLocationRequested: false
    };
    expect( initialState ).toEqual( expectedState );
  } );

  it( 'LatLong requested case', ( ) => {
    let actionCreator = {
      type: getServiceType( 'latLong', 'requested' ),
      data: 'testData'
    };
    let expectedOutput = {
      searchValue: 'testData'
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'LatLong success case', ( ) => {
    let actionCreator = {
      type: getServiceType( 'latLong', 'success' ),
      data: latLongData
    };
    let expectedOutput = {
      coordinates: latLongData,
      currentLocationRequested: true
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'getLatLongState should return global state', () => {
    const state = {
      latLong: {
        searchValue: '',
        coordinates: latLongData,
        currentLocationRequested : false
      }
    };
    expect( getLatLongState( state ) ).toEqual( state.latLong );
  } );

} );
