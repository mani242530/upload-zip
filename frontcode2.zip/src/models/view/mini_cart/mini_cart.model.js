/**
 * MiniBag Redux reducer Module
 *
 */
import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';


import {
  DISPLAY_MINI_CART_FLYOUT,
  HIDE_MINI_CART_FLYOUT
} from '../../../events/mini_cart/mini_cart.events';

/**
 * default state for the MiniBag reducer
 */

export const initialState = {
  showMiniCartFlyout: false,
  cartServiceData: undefined
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */

export default function reducer( state = initialState, action ){

  switch ( action.type ){

    case DISPLAY_MINI_CART_FLYOUT:
      return {
        ...state,
        showMiniCartFlyout: true
      }

    case HIDE_MINI_CART_FLYOUT:
      return {
        ...state,
        showMiniCartFlyout: false
      }

    case getServiceType( 'miniCart', 'success' ):
      return {
        ...state,
        cartServiceData: action.data
      }
    default:
      return state;
  }
}


export const getMiniBagCartServiceData  = state => state.miniBag.cartServiceData;
