
import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import reducer, {
  initialState
} from './mini_cart.model';


import {
  DISPLAY_MINI_CART_FLYOUT,
  HIDE_MINI_CART_FLYOUT
} from '../../../events/mini_cart/mini_cart.events';


describe( 'MiniBag reducer', ( ) => {
  registerServiceName( 'miniCart' );

  it( 'should have the proper default state', ( ) => {
    const expectedState = {
      showMiniCartFlyout: false,
      cartServiceData: undefined
    }
    expect( initialState ).toEqual( expectedState );
  } );

  it( 'MiniBag success case', ( ) => {
    const res = {
      cartSummary:{}
    }
    let actionCreator = {
      type: getServiceType( 'miniCart', 'success' ),
      data: res
    }
    let expectedOutput = {
      cartServiceData: {
        cartSummary:{}
      }
    }
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should handle the event DISPLAY_MINI_CART_FLYOUT and set the state', ( ) => {
    const actionCreator = {
      type:DISPLAY_MINI_CART_FLYOUT
    }
    const expectedOutput = {
      showMiniCartFlyout: true
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should handle the event HIDE_MINI_CART_FLYOUT and set the state', ( ) => {
    const actionCreator = {
      type: HIDE_MINI_CART_FLYOUT
    }
    const expectedOutput = {
      showMiniCartFlyout: false
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

} );
