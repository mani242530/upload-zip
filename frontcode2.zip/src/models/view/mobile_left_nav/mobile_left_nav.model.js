import { createSelector } from 'reselect';

import {
  types as globalActionTypes
} from 'ulta-fed-core/dist/js/events/global/global.events'

import {
  SET_ACTIVE_LEVEL,
  SET_MOBILE_LEFT_NAV_DIMENSIONS,
  TOGGLE_LEFT_NAV,
  OPEN_REWARDS,
  SET_MOBILE_LEFT_NAV_SCROLL
} from 'ulta-fed-core/dist/js/events/mobile_left_nav/mobile_left_nav.events'

import {
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

/**
 * default state for the MobileLeftNav duck module.
 */
export const initialState = {

  activeLevel: [],

  mobileLeftNavHeight: undefined,
  mobileLeftNavWidth: undefined,

  leftNavAnimationOffset: '0px',
  menuActive: false,

  leftNavScrollPosition: 0,
  leftNavScrollAdjust: 0,
  leftNavStyle: {},
  rewardsOpen: false,
  mobileNavContent: {},
  desktopNavPanelList: [],
  isScrollableMenu: false
};

export const dispatchCreatedEvent = ( eventName ) => {
  document.dispatchEvent( eventName );
}

export const createEvent = ( name, val ) => {
  let cEvent = new CustomEvent( name, {
    detail: {
      IsMenuOpen: val
    }
  } );
  return cEvent;
};




/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){

  let newState;

  switch ( action.type ){

    // Data from service to populate the navigation service data
    case getServiceType( 'navigation', 'success' ):

      let navData = action.data.desktopNavContent
      let navItems = {};

      let desktopNavPanelList = navData.navList.map( ( navPanelItem, index ) => {

        let navItems = {};
        let panelPaginationLength = 30;
        let maxBrandPanelLength = 3;
        let flyout = navPanelItem.flyout;

        let paginatedNavItems = [];
        let panelIndex = 0;
        let flattenedNavItemList;

        if( navPanelItem.categories && navPanelItem.categories.length > 0 ){

          // iterate over categories and flatten them into a single array
          flattenedNavItemList = navPanelItem.categories.map( ( navItem ) => {
            const arrayDepth = 0;
            return flattenNavItem( navItem, arrayDepth )
          } )

          // extract nested arrays
          let combinedNavItems = [].concat( ...flattenedNavItemList );

          // calculate number of panels needed and panelPaginationLength changed to max brand length for brand navigation
          panelPaginationLength = navPanelItem?.primaryTitle ? maxBrandPanelLength : panelPaginationLength;
          const numberOfPanels = Math.ceil( combinedNavItems.length / panelPaginationLength );

          // iterate over panels and add them to the paginatedNavItems list
          for ( var currentPanelNumber = 0; currentPanelNumber < numberOfPanels; currentPanelNumber++ ){
            paginatedNavItems.push( paginateNavItems( combinedNavItems, currentPanelNumber, panelPaginationLength ) )
          }
        }

        if( flyout && flyout.length > 0 ){

          let flyoutList = flyout.map( ( imageData, index ) => {
            return [imageData];
          } )

          for ( var i = 0; i < flyoutList.length; i++ ){
            paginatedNavItems.push( flyoutList[ i ] );
          }
        }

        let _navPanelItem = navPanelItem;
        _navPanelItem.paginatedNavItems = paginatedNavItems
        return _navPanelItem
      } )

      navItems.desktopNavPanelList = desktopNavPanelList;


      return {
        ...state,
        mobileNavContent: action.data.mobileNavContent,
        ...navItems,
        desktopNavPanelList: navItems.desktopNavPanelList
      }



    case SET_ACTIVE_LEVEL:
      let alevel;
      let offset;
      let level;
      if( action.level.length >= 1 ){
        alevel = parseInt( action.level[ action.level.length - 1 ].split( '|' )[0], 10 ) + 1;
        offset = `-${ alevel * state.mobileLeftNavWidth }px`;
        level = action.level;
      }
      else {
        level = [];
        offset = '0px';
      }

      // scroll

      return {
        ...state,
        activeLevel: level,
        leftNavAnimationOffset: offset
      }


    case SET_MOBILE_LEFT_NAV_DIMENSIONS:

      return Object.assign( {}, state, {
        mobileLeftNavWidth: action.width,
        mobileLeftNavHeight: action.height
      } );



    case TOGGLE_LEFT_NAV:
      // SENDING CUSTOM EVENT TO emailSignUp TO TOGGLE BETWEEN SHOWING AND HIDING THE STICKY FOOTER.
      dispatchCreatedEvent( createEvent( 'MobileMenuOpened', !state.menuActive ) );
      return {
        ...state,
        activeLevel: [],
        leftNavAnimationOffset: '0px',
        menuActive: !state.menuActive
      }

    case OPEN_REWARDS:
      return Object.assign(
        {},
        state,
        {
          rewardsOpen: !state.rewardsOpen
        }
      )

    case SET_MOBILE_LEFT_NAV_SCROLL:
      return {
        ...state,
        isScrollableMenu: action.data.globalHeight < ( action.data.navContentHeight + action.data.navHeaderHeight + action.data.navFooterHeight )
      }


    default:
      return state;
  }
}

/**
 * takes a navItem with nested arrays of categories of 'n' depth
 * and flattens them into a single array while adding an attribute
 * of 'displayAsSubCategory' set to true for all nested objects so
 * we can display them properly
 *
 */
export const flattenNavItem = ( navItem, arrayDepth ) => {

  let navItemList = [navItem];
  let subNavItems = [];

  if( navItem.categories && navItem.categories.length > 0 ){
    subNavItems = navItem.categories.map( ( subNavItem ) => {

      let _subNavItem = subNavItem;
      // setting 'displayAsSubCategory' to true will allow us to add
      // a class to this item in the display so we can display this
      // nav Item as 'capitalized' rather than 'uppercase'
      _subNavItem.displayAsSubCategory = true;

      let subNavList = [_subNavItem]
      let flattenedNavItems = [];

      // if the navItem has more categories, recursively call this
      // function again to flatten and combine them into the
      // final list
      if( _subNavItem.categories && _subNavItem.categories.length > 0 ){
        flattenedNavItems = flattenNavItem( _subNavItem, arrayDepth + 1 );
      }

      return subNavList;
    } )
  }

  // pull the objects out of the nested inner array, which is not necessary
  let new_subNavItems = [].concat( ...subNavItems );

  // combine the navItemList (original navItem ) with the new_subNavItems
  let flattenedNavItemList = [...navItemList, ...new_subNavItems];

  return flattenedNavItemList;
}

/**
 * takes a list of navItems and a panelNumber and
 * returns the appropriate slice of the list for that
 * panelNumber for display purposes
 *
 */
export const paginateNavItems = ( navItemsList, panelNumber, panelPaginationLength ) => {
  let length = panelPaginationLength;
  return navItemsList.slice( panelNumber * length, ( panelNumber + 1 ) * length )
}


const selectLeftNav = ( state ) => state.mobileLeftNav;

export const makeGetLeftNavData = () => createSelector(
  selectLeftNav,
  ( leftNavState ) => ( {
    mobile: lefNavState.mobileNavContent,
    desktop: lefNavState.desktopNavPanelList
  } )

);
