

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  SET_MOBILE_LEFT_NAV_DIMENSIONS,
  TOGGLE_LEFT_NAV,
  SET_ACTIVE_LEVEL,
  OPEN_REWARDS,
  SET_MOBILE_LEFT_NAV_SCROLL
} from 'ulta-fed-core/dist/js/events/mobile_left_nav/mobile_left_nav.events';

import _ from 'lodash';
import reducer, {
  initialState,
  createEvent,
  dispatchCreatedEvent
} from './mobile_left_nav.model';

document.dispatchEvent = jest.fn();

describe( 'MobileLeftNav Reducer', () => {

  it( 'should have the proper default state', () => {
    let expectedState = {
      activeLevel: [],
      mobileLeftNavHeight: undefined,
      mobileLeftNavWidth: undefined,
      leftNavAnimationOffset: '0px',
      menuActive: false,
      leftNavScrollPosition: 0,
      leftNavScrollAdjust: 0,
      leftNavStyle: {},
      rewardsOpen: false,
      mobileNavContent: {},
      desktopNavPanelList: [],
      isScrollableMenu: false
    };

    expect( initialState ).toEqual( expectedState );
  } );


  it( 'should be a function', () => {
    expect( _.isFunction( reducer ) ).toBe( true );
    expect( _.isFunction( CustomEvent ) ).toBe( true );
    expect( _.isFunction( dispatchCreatedEvent ) ).toBe( true );
  } );

  it( 'returns a custom Event', () => {
    let cEvent = new CustomEvent( 'NEWTEST', {
      detail: {
        IsMenuOpen: true
      }
    } );

    let nEvent = createEvent( 'NEWTEST', true );
    expect( JSON.stringify( nEvent ) ).toEqual( JSON.stringify( cEvent ) );
  } );

  it( 'invokes the Dispatch Event', () => {
    dispatchCreatedEvent( 'NEWTEST' );
    expect( document.dispatchEvent ).toHaveBeenCalled();
  } );

  describe( 'Navigation data  request success', () => {

    let data = {
      mobileNavContent: {
        body: {},
        fakestuff: {}
      },
      desktopNavContent: {
        navList: [{
          categories: []
        }]
      }
    };

    let res = {
      mobileNavContent: {
        body: {},
        fakestuff: {}
      },
      desktopNavPanelList: [{
        categories: [],
        paginatedNavItems: []
      }]
    };

    registerServiceName( 'navigation' );


    it( 'should set the navContent when the data is loaded', () => {
      let actionCreator = {
        type: getServiceType( 'navigation', 'success' ),
        data: data
      }

      let expectedOutput = {
        ...initialState,
        ...res
      }

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set mobileNavContent and desktopNavPanelList when the data is loaded', () => {
      const data = {
        mobileNavContent: {
          body: {},
          fakestuff: {}
        },
        desktopNavContent: {
          navList: [{
            categories: [{
              navDisplayContent: 'Brands',
              navElementType: 'rootCategory',
              categories: [],
              categoryLink: {
                showInNewPage: false,
                navTargetLink: 'http://qa3.ulta.com/global/nav/allbrands.jsp',
                'data-nav-description': 'm - brands',
                linkText: ''
              },
              fontColor: 'nav-menu-style-melon'
            }]
          }]
        }
      };
      const actionCreator = {
        type: getServiceType( 'navigation', 'success' ),
        data: data
      }
      const expectedOutput = {
        ...initialState,
        mobileNavContent: data.mobileNavContent,
        desktopNavPanelList: data.desktopNavContent.navList
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set the navContent when the data is loaded and has flyout', () => {
      const data = {
        mobileNavContent: {
          body: {},
          fakestuff: {}
        },
        desktopNavContent: {
          navList: [{
            categories: [{
              navDisplayContent: 'Brands',
              navElementType: 'rootCategory',
              categories: [],
              categoryLink: {
                showInNewPage: false,
                navTargetLink: 'http://qa3.ulta.com/global/nav/allbrands.jsp',
                'data-nav-description': 'm - brands',
                linkText: ''
              },
              fontColor: 'nav-menu-style-melon'
            }],
            flyout: [
              {
                imageLink: {
                  showInNewPage: false,
                  navTargetLink: 'http://da3.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod14051007',
                  linkText: '',
                  'data-slot-position': 'makeup_flyout_050916_makeup'
                },
                navElementType: 'subcategory',
                navAttributes: 'promoflyout',
                imageAlt: '',
                imgSrc: 'http://images.ulta.com/is/image/Ulta/flyout_050916_makeup'
              }
            ]
          }]
        }
      };
      const actionCreator = {
        type: getServiceType( 'navigation', 'success' ),
        data: data
      }
      const expectedOutput = {
        ...initialState,
        mobileNavContent: data.mobileNavContent,
        desktopNavPanelList: data.desktopNavContent.navList
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );


  describe( 'SET_MOBILE_LEFT_NAV_DIMENSIONS', () => {

    let height = 2255;
    let width = 220;

    let actionCreator = {
      type: SET_MOBILE_LEFT_NAV_DIMENSIONS,
      width,
      height
    }

    it( 'should handle the event and set the \'mobileLeftNav\' attribute', () => {

      let expectedOutput = {
        mobileLeftNavHeight: height,
        mobileLeftNavWidth: width
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );


  } );

  describe( 'SET_MOBILE_LEFT_NAV_SCROLL', () => {

    it( 'should handle the event and set the \'isScrollableMenu\' prop to false if nav content is less than the screen height', () => {
      let data = {
        globalHeight: 768, navContentHeight: 460, navHeaderHeight: 30, navFooterHeight: 130
      };

      let actionCreator = {
        type: SET_MOBILE_LEFT_NAV_SCROLL,
        data
      }
      let expectedOutput = { isScrollableMenu: false };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should handle the event and set the \'isScrollableMenu\' prop to true if nav content is greater than the screen height', () => {
      let data = {
        globalHeight: 768, navContentHeight: 680, navHeaderHeight: 30, navFooterHeight: 130
      };

      let actionCreator = {
        type: SET_MOBILE_LEFT_NAV_SCROLL,
        data
      }
      let expectedOutput = { isScrollableMenu: true };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );


  } );

  describe( 'TOGGLE_LEFT_NAV', () => {

    let mode = 1323;

    let actionCreator = {
      type: TOGGLE_LEFT_NAV,
      mode
    }

    it( 'should handle the event and set the \'menuActive\' attribute', () => {

      let expectedOutput = {
        menuActive: true,
        activeLevel: [],
        leftNavAnimationOffset: '0px'
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should update the states \'menuActive\' attribute', () => {


      let expectedOutput = Object.assign( {}, initialState,
        {
          leftNavScrollPosition: 0,
          menuActive: true
        } );

      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'SET_ACTIVE_LEVEL', () => {

    it( 'should handle the event and set the \'leftNavAnimationOffset\' attribute and activeLevel as empty', () => {
      const actionCreator = {
        type: SET_ACTIVE_LEVEL,
        level: []
      }
      const expectedOutput = {
        activeLevel: [],
        leftNavAnimationOffset: '0px'
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should handle the event and set the \'leftNavAnimationOffset\' attribute and activeLevel', () => {
      const actionCreator = {
        type: SET_ACTIVE_LEVEL,
        level: ['1|1']
      }
      const state = { mobileLeftNavWidth: '1' };
      const expectedOutput = {
        ...state,
        activeLevel: ['1|1'],
        leftNavAnimationOffset: '-2px'
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'OPEN_REWARDS', () => {

    it( 'should handle the event and set rewards as true', () => {
      const actionCreator = { type: OPEN_REWARDS }
      const expectedOutput = { rewardsOpen: true };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  it( 'should set the navContent when the data is loaded and has flyout', () => {
    const data = {
      mobileNavContent: {
        body: {},
        fakestuff: {}
      },
      desktopNavContent: {
        navList: [{
          'primaryTitle': 'Featured Brands',
          'secondaryTitleColor': 'mad-for-magenta-ada',
          'flyout': [],
          'categoryImageAlt': '',
          'secondaryTitleLink': 'https://da1.ulta.com/global/nav/allbrands.jsp',
          'primaryTitleColor': 'nav-menu-style-black',
          'navDisplayContent': 'Shop By Brand-Heather!',
          'featuredDataNav': 'm - shop by brand-heather!:featured brands',
          'secondaryTitle': 'Shop All Brands',
          'navElementType': 'rootCategory',
          'categories': [
            {
              'image': 'https://images.ulta.com/is/image/Ulta/flyout_coverfx_logo?scl=1&fmt=png-alpha',
              'imageLink': 'https://da1.ulta.com/brand/cover-fx',
              'navDisplayContent': 'Cover FX',
              'navElementType': 'ImageSubCategory',
              'imageAlt': 'Cover FX',
              'dataSlotPosition': 'm - shop by brand-heather!:featured brands:cover fx'
            },
            {
              'image': 'https://images.ulta.com/is/image/Ulta/flyout_dermalogica_logo?scl=1&fmt=png-alpha',
              'imageLink': 'https://da1.ulta.com/brand/dermalogica',
              'navDisplayContent': 'Dermalogica',
              'navElementType': 'ImageSubCategory',
              'imageAlt': 'Dermalogica',
              'dataSlotPosition': 'm - shop by brand-heather!:featured brands:dermalogica'
            },
            {
              'image': 'https://images.ulta.com/is/image/Ulta/flyout_drybar_logo?scl=1&fmt=png-alpha',
              'imageLink': 'https://da1.ulta.com/brand/drybar',
              'navDisplayContent': 'Drybar',
              'navElementType': 'ImageSubCategory',
              'imageAlt': '',
              'dataSlotPosition': 'm - shop by brand-heather!:featured brands:drybar'
            },
            {
              'image': 'https://images.ulta.com/is/image/Ulta/flyout_it_cos_logo?scl=1&fmt=png-alpha',
              'imageLink': 'https://da1.ulta.com/brand/it-cosmetics',
              'navDisplayContent': 'IT Cosmetics',
              'navElementType': 'ImageSubCategory',
              'imageAlt': 'IT Cosmetics',
              'dataSlotPosition': 'm - shop by brand-heather!:featured brands:it cosmetics'
            }
          ]
        }]
      }
    };
    const actionCreator = {
      type: getServiceType( 'navigation', 'success' ),
      data: data
    }
    const expectedOutput = {
      ...initialState,
      mobileNavContent: data.mobileNavContent,
      desktopNavPanelList: data.desktopNavContent.navList
    }
    expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
  } );
} );
