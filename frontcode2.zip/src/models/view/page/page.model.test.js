import _ from 'lodash';

import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import {
  TOGGLE_EDIT_USER_DATA,
  TOGGLE_INPUTFIELD_DISPLAY,
  TOGGLE_ADDRESS_FIELD_DISPlAY,
  INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK,
  TOGGLE_ADDRESS2_FIELD_DISPlAY,
  CLEAR_VALIDATION_ERROR
} from 'ulta-fed-core/dist/js/events/forms/forms.events';

import reducer, {
  initialState
} from './page.model';

describe( 'Page reducer', () => {
  registerServiceName( 'page' );
  registerServiceName( 'banner' );
  registerServiceName( 'applyForm' );
  registerServiceName( 'lpsLookUp' );
  registerServiceName( 'profile' );
  registerServiceName( 'prescreenApply' );
  registerServiceName( 'switches' );

  it( 'should have the proper default state', () => {
    let expectedState = {
      formConfig: {
        fieldShowHideToggleData: {
          password: false,
          ssn: false,
          LoginPassword: false,
          ResetPassword:false
        }
      },
      creditcards: {
        lpsRequestComplete: false,
        editUserData: false,
        addressOpen: false,
        address2Open: false,
        applyFormIsSubmitting: false,
        lpsFlag: undefined,
        beautyClubNumberisRequired: false,
        hasProfileData: false,
        instantCreditResponse: {}
      },
      homepage:{}
    }

    expect( initialState ).toEqual( expectedState );

  } );

  it( 'should be a function', () => {
    expect( _.isFunction( reducer ) ).toBe( true );
  } );


  it( 'should return the initial state', () => {
    expect( reducer( undefined, { type: '' } ) ).toEqual( initialState );
  } );


  describe( 'Page data successfully loaded', () => {

    let data = {
      pageData: true
    }

    let actionCreator = {
      type: getServiceType( 'page', 'success' ),
      data
    }

    let expectedOutput = {
      ...initialState,
      homepage:{
        pageData:true
      }

    }

    expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );

  } );


  describe( 'lpsLookUp related Test cases', () => {

    it( 'lpsLookUp data successfully loaded', () => {
      let res = {
        ...initialState,
        creditcards:{
          lpsFlag : ''
        }
      }
      let actionCreator = {
        type: getServiceType( 'lpsLookUp', 'success' ),
        data:res

      }

      let expectedOutput = {
        ...initialState,
        creditcards: {
          address2Open: false,
          addressOpen: false,
          applyFormIsSubmitting: false,
          beautyClubNumberisRequired: false,
          instantCreditResponse:{},
          editUserData: false,
          hasProfileData: false,
          lpsRequestComplete: true,
          lpsFlag : res.creditcards.LookupExactMatchResult
        }
      }
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'lpsLookup requested event', () => {
      let actionCreator = {
        type: getServiceType( 'lpsLookUp', 'requested' )
      }

      let expectedOutput = { creditcards: { lpsRequestComplete: false } };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput )
    } );
  } );


  describe( 'Loader spinner successfully loaded', () => {
    it( 'should show the loading spinner', () => {
      let actionCreator1 = {
        type: getServiceType( 'applyForm', 'loading' ),
        applyFormIsSubmitting: true
      }
      let expectedOutput = {
        creditcards: {
          'applyFormIsSubmitting': true
        }
      }

      expect( reducer( {}, actionCreator1 ) ).toEqual( expectedOutput );
    } );

    it( 'should show the loading spinner during apply success', () => {

      let actionCreator2 = {
        type: getServiceType( 'applyForm', 'loading' ),
        applyFormIsSubmitting: true
      }
      let expectedOutput = {
        creditcards: {
          'applyFormIsSubmitting': true
        }
      }

      expect( reducer( {}, actionCreator2 ) ).toEqual( expectedOutput );

    } );

    it( 'should show the loading spinner during apply failure', () => {

      let actionCreator3 = {
        type: getServiceType( 'applyForm', 'failure' ),
        applyFormIsSubmitting: false
      }
      let expectedOutput = {
        creditcards: {
          'applyFormIsSubmitting': false
        }
      }
      expect( reducer( {}, actionCreator3 ) ).toEqual( expectedOutput );

    } );

    it( 'Apply Form success case without any errors', () => {
      let actionCreator = {
        type: getServiceType( 'applyForm', 'success' ),
        data:{
          instantCreditResponse:{
            type_1: {
              aprReasons: null, aprValue: '26.99', bureauCode: null, cardType: 'PL', '@class': 'com.ulta.ads.UltaADSResponse', creditLimit: '4500', creditScore: 725, errorCode: null, errorMessage: null, firstName: 'MARK', creditLimitExceeded:'false', rewardsMemberCreated:true, tenderPromoMessage:'Get 20% off on your first purchase by using URCC', firstTimeTransactionLimit:'3000', responseType: '01'
            }
          }
        }
      }

      let expectedOutput = {
        creditcards:{
          applyFormIsSubmitting: false,
          instantCreditResponse: {
            type_1: {
              aprReasons: null, aprValue: '26.99', bureauCode: null, cardType: 'PL', '@class': 'com.ulta.ads.UltaADSResponse', creditLimit: '4500', creditScore: 725, errorCode: null, errorMessage: null, firstName: 'MARK', creditLimitExceeded:'false', rewardsMemberCreated:true, tenderPromoMessage:'Get 20% off on your first purchase by using URCC', firstTimeTransactionLimit:'3000', responseType: '01'
            }
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Apply Form success case with errors', () => {
      let actionCreator = {
        type: getServiceType( 'applyForm', 'success' ),
        data:{
          messageBeans:'Please enter a valid SSN'
        }
      }

      let expectedOutput = { creditcards:{ applyFormIsSubmitting: false, instantCreditResponse: undefined, messageBeans: 'Please enter a valid SSN' } };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );


  } );

  describe( 'Banner Related TestCases', () => {
    it( 'Banner success event', () => {
      let actionCreator = {
        type: getServiceType( 'banner', 'success' ),
        data:{
          bannerImageUri:''
        }
      }

      let expectedOutput = { creditcards: { bannerImageUri: '' } };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Profile Related Test Cases', () => {
    it( 'should set hasProfileData to true on profile success if address is present', () => {
      let actionCreator = {
        type: getServiceType( 'profile', 'success' ),
        data:{
          profileInfo:{
            address:{
              city:'bolingbrook'
            }
          }
        }
      }

      let expectedOutput = { creditcards: { hasProfileData: true } };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should not set hasProfileData to true on profile success if address is not present', () => {
      let actionCreator = {
        type: getServiceType( 'profile', 'success' ),
        data:{
          profileInfo:{
            address:null
          }
        }
      }

      let expectedOutput = { creditcards: {} };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'PrescreenApply and Switches related cases', () => {
    it( 'Pre Screen Apply loading cases', () => {
      let actionCreator = {
        type: getServiceType( 'prescreenApply', 'loading' )
      }

      let expectedOutput = { creditcards: { applyFormIsSubmitting: true } };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Pre Screen Apply success case without messageBeans ', () => {
      let actionCreator = {
        type: getServiceType( 'prescreenApply', 'success' ),
        data:{
          instantCreditResponse:{
            type_1: {
              aprReasons: null, aprValue: '26.99', bureauCode: null, cardType: 'PL', '@class': 'com.ulta.ads.UltaADSResponse', creditLimit: '4500', creditScore: 725, errorCode: null, errorMessage: null, firstName: 'MARK', creditLimitExceeded:'false', rewardsMemberCreated:true, tenderPromoMessage:'Get 20% off on your first purchase by using URCC', firstTimeTransactionLimit:'3000', responseType: '01'
            }
          }
        }
      }

      let expectedOutput = {
        creditcards: {
          applyFormIsSubmitting: false,
          instantCreditResponse: {
            type_1: {
              aprReasons: null, aprValue: '26.99', bureauCode: null, cardType: 'PL', '@class': 'com.ulta.ads.UltaADSResponse', creditLimit: '4500', creditScore: 725, errorCode: null, errorMessage: null, firstName: 'MARK', creditLimitExceeded:'false', rewardsMemberCreated:true, tenderPromoMessage:'Get 20% off on your first purchase by using URCC', firstTimeTransactionLimit:'3000', responseType: '01'
            }
          }
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Pre Screen Apply success case with messageBeans', () => {
      let actionCreator = {
        type: getServiceType( 'prescreenApply', 'success' ),
        data:{
          instantCreditResponse:{
            type_1: {
              aprReasons: null, aprValue: '26.99', bureauCode: null, cardType: 'PL', '@class': 'com.ulta.ads.UltaADSResponse', creditLimit: '4500', creditScore: 725, errorCode: null, errorMessage: null, firstName: 'MARK', creditLimitExceeded:'false', rewardsMemberCreated:true, tenderPromoMessage:'Get 20% off on your first purchase by using URCC', firstTimeTransactionLimit:'3000', responseType: '01'
            }
          },
          messageBeans: 'Please enter a valid SSN'
        }
      }

      let expectedOutput = {
        creditcards:{
          applyFormIsSubmitting: false,
          instantCreditResponse:{
            type_1: {
              aprReasons: null, aprValue: '26.99', bureauCode: null, cardType: 'PL', '@class': 'com.ulta.ads.UltaADSResponse', creditLimit: '4500', creditScore: 725, errorCode: null, errorMessage: null, firstName: 'MARK', creditLimitExceeded:'false', rewardsMemberCreated:true, tenderPromoMessage:'Get 20% off on your first purchase by using URCC', firstTimeTransactionLimit:'3000', responseType: '01'
            }
          },
          messageBeans: 'Please enter a valid SSN'
        }
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Pre Screen Apply failure case', ()=>{
      let actionCreator = {
        type: getServiceType( 'prescreenApply', 'failure' )
      }

      let expectedOutput = { creditcards:{ applyFormIsSubmitting: false } };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Switches success case', () => {
      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data:{
          switches:{ guestServiceNumber:'1-866-983-8582' }
        }
      }

      let expectedOutput = { creditcards: { guestServiceNumber: '1-866-983-8582' } };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  describe( 'Form type cases', () => {
    it( 'Toggle Edit User Data event', () => {
      let req = { creditcards: { editUserData: false } }
      let actionCreator = {
        type: TOGGLE_EDIT_USER_DATA
      }

      let expectedOutput = { creditcards: { editUserData: true } };
      expect( reducer( req, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Toggle address field open event', () => {
      let req = { creditcards: { addressOpen: true } };
      let actionCreator = {
        type: TOGGLE_ADDRESS_FIELD_DISPlAY
      }

      let expectedOutput = { creditcards: { addressOpen: false } };
      expect( reducer( req, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Instant Credit Card Response Page Go Back event', () => {
      let actionCreator = {
        type: INSTANT_CREDIT_RESPONSE_PAGE_GO_BACK
      }

      let expectedOutput = { creditcards:{ instantCreditResponse: {}, hasProfileData: false } };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Toggle address2 field display event', () => {
      let req = { creditcards: { address2Open: true } };
      let actionCreator = {
        type: TOGGLE_ADDRESS2_FIELD_DISPlAY
      }

      let expectedOutput = { creditcards: { address2Open: false } };
      expect( reducer( req, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Clear Validation Error event', () => {
      let actionCreator = {
        type: CLEAR_VALIDATION_ERROR
      }

      let expectedOutput = { creditcards: { messageBeans: undefined } };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

} );
