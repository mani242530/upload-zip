/**
 * Product Page Redux reducer Module
 *
 */
import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import forIn from 'lodash/forIn';
import {
  ALERT_WINDOW_RESIZE
} from 'ulta-fed-core/dist/js/events/global/global.events'
import {
  formatDate,
  fullyQualifyLink,
  host
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import {
  PRODUCT_RIGHT_PANEL_COLLAPSE,
  PRODUCT_SWATCHES_VIEW_ALL_OPTIONS,
  PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS,
  PRODUCT_SWATCHES_COUNT_PER_ROW,
  PRODUCT_MAINIMAGE_LOADER,
  PRODUCT_SWATCHES_MAX_HEIGHT,
  PRODUCT_SWATCHES_WIDTH_AND_MARGIN,
  PRODUCT_PAGE_MODAL_OPEN,
  PRODUCT_PAGE_MODAL_CLOSE,
  PRODUCT_THUMBNAILIMAGE_SELECT,
  PRODUCT_POWERREVIEW_READY_FLAG
} from '../../../events/product_detail/product_detail.events';
import CONFIG from '../../../modules/pdp/pdp.config';
import appConstants from '../../../shared/appConstants';
import messages from '../../../views/ProductSwatches/ProductSwatches.messages';

/**
 * default state for the ProductDetail reducer
 */

export const initialState = {
  productDetails: null,
  isValidProduct:false,
  isProductUnavailable:undefined,
  viewAllOption: false,
  displayMoreOptions:false,
  // swatchesCountPerRow will be the number of elements that can be accomodated in a row for mobile view
  // initializing to a hight count, and the actual value  will be set in the code based on the width
  swatchesCountPerRow:999,
  swatchesSectionMaxHeight:'none',
  swatchesSectionWidth:'none',
  swatchesCellMargin:0,
  productRightPanelCollapse: {
    findInStore: false,
    productDetails:true,
    howToUse: false,
    ingredients: false,
    productRestrictions: false
  },
  isEmailMeModalOpen:false,
  addToBagErrorMessages:null,
  recommendedProducts:null,
  breadCrumbLinks:undefined,
  openFindInStoreModal:false,
  powerReviewsScriptLoaded:false,
  resizeEventOccurrence:0,
  openProductVariantDrodownModal:false,
  showPromotionLoader:true,
  showMainImageLoader:true
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){
  return reducerSwitch( state, action )
}

export const reducerSwitch = function( state, action ){

  switch ( action.type ){

    case PRODUCT_RIGHT_PANEL_COLLAPSE:
      return {
        ...state,
        productRightPanelCollapse: toggleProductDetailRightPanelOptionsCollapse( action.panelID, state )
      }
    case getServiceType( 'pdpProductDetails', 'success' ):
      return {
        ...state,
        ...setSeoProductData( action.data ),
        // any data to be set in the store on product details success should be set inside
        // the method getNextStateOnProductSuccess method defined below. This method is being used in
        // creating store in SSR also in pdp.controllers. This will ensure that any code changes are shared
        // across the logic for both client and server side rendering
        ...getNextStateOnProductSuccess( action.data, state )
      }
    case PRODUCT_SWATCHES_VIEW_ALL_OPTIONS:
      return {
        ...state,
        viewAllOption: !state.viewAllOption
      }
    case PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS:
      return {
        ...state,
        displayMoreOptions: action.display
      }
    case PRODUCT_SWATCHES_COUNT_PER_ROW:
      return {
        ...state,
        swatchesCountPerRow: action.count
      }
    case PRODUCT_MAINIMAGE_LOADER:
      return {
        ...state,
        showMainImageLoader:false
      }
    case PRODUCT_SWATCHES_MAX_HEIGHT:
      return {
        ...state,
        swatchesSectionMaxHeight: action.height
      }
    case PRODUCT_SWATCHES_WIDTH_AND_MARGIN:
      return {
        ...state,
        swatchesSectionWidth: action.data.sectionWidth,
        swatchesCellMargin: action.data.cellMargin
      }
    case getServiceType( 'pdpSkuDetails', 'success' ):
      return {
        ...state,
        // any data to be set in the store on sku details success should be set inside
        // the method getNextStateOnSkuSuccess method defined below. This method is being used in
        // creating store in SSR also in pdp.controllers. This will ensure that any code changes are shared
        // across the logic for both client and server side rendering
        ...getNextStateOnSkuSuccess( state, action.data ),
        showPromotionLoader:true
      }
    case getServiceType( 'pdpPurchaseEligibility', 'success' ):
      return {
        ...state,
        productDetails: {
          ...state.productDetails,
          purchaseEligibility: setEligibilityDetails( action.data ),
          sku: {
            ...state.productDetails.sku,
            favoriteId: action.data.favoriteId,
            enableFindStore: action.data.findInStore?.enabled
          }
        }
      }
    case getServiceType( 'pdpSkuDynamicData', 'requested' ):
      return {
        ...state,
        showPromotionLoader:true
      }
    case getServiceType( 'pdpSkuDynamicData', 'success' ):
      return {
        ...state,
        productDetails: {
          ...state.productDetails,
          sku: {
            ...state.productDetails.sku,
            ...getpromotionDetails( action.data ),
            ...( action.data.dynamicData.price && { price: action.data.dynamicData.price } )
          }
        },
        showPromotionLoader:false
      }

    case getServiceType( 'pdpSkuDetails', 'requested' ):
      return {
        ...state,
        addToBagErrorMessages:null,
        showMainImageLoader:true
      }
    case getServiceType( 'pdpAddItem', 'requested' ):
      return {
        ...state,
        addToBagErrorMessages:null
      }
    case getServiceType( 'pdpAddItem', 'success' ):
      return {
        ...state,
        ...( action.data.responseData.messages && { addToBagErrorMessages:action.data.responseData.messages } )
      }

    case getServiceType( 'pdpFindFavorite', 'success' ):
      return {
        ...state,
        productDetails:{
          ...state.productDetails,
          sku: {
            ...state.productDetails.sku,
            favoriteId: action.data.favoriteId
          }
        }
      }
    case getServiceType( 'pdpAddFavorite', 'success' ):
      return {
        ...state,
        productDetails:{
          ...state.productDetails,
          sku: {
            ...state.productDetails.sku,
            favoriteId: action.data.favoriteId,
            addToFavoriteErrorMessages:action.data.messages
          }
        }
      }
    case getServiceType( 'pdpRemoveFavorite', 'success' ):
      return {
        ...state,
        productDetails:{
          ...state.productDetails,
          sku: {
            ...state.productDetails.sku,
            favoriteId: null
          }
        }
      }
    case PRODUCT_PAGE_MODAL_OPEN:
      return {
        ...state,
        // this notation will set the value to true of the key with the same value of the modalId being passed in
        // this event can be used set the the value of any boolean key in the state. we just need to pass the appropriate modalId
        // and modalID is just a key in the state
        [ action.modalID ]: true
      }

    case PRODUCT_PAGE_MODAL_CLOSE:
      return {
        ...state,
        // this notation will set the value to false of the key with the same value of the modalId being passed in
        // this event can be used set the the value of any boolean key in the state. we just need to pass the appropriate modalId
        // and modalID is just a key in the state
        [ action.modalID ]: false
      }

    case PRODUCT_THUMBNAILIMAGE_SELECT:
      return {
        ...state,
        productDetails: {
          ...state.productDetails,
          selectedThumbnailIndex: action.thumbnailIndex
        }
      }

    case getServiceType( 'pdpEmailNotification', 'success' ):
      return {
        ...state,
        productDetails: {
          ...state.productDetails,
          purchaseEligibility: {
            ...state.productDetails.purchaseEligibility,
            isNotifyMeEligible:false,
            availabilityMessage1:null,
            emailStockNotifyMessage: action.data.messages.items[0].message
          }
        }
      }
    case getServiceType( 'pdpProductRecs', 'success' ):
      return {
        ...state,
        recommendedProducts: action.data.data.recommendations
      }
      // Checking the criteria for displaying reviews and showing WriteAReview Button.
    case PRODUCT_POWERREVIEW_READY_FLAG:
      return {
        ...state,
        powerReviewsScriptLoaded:true,
        productDetails: {
          ...state.productDetails,
          displayReviews: state.productDetails?.reviewNum > 0 || state.productDetails?.questionCount > 0
        }
      }
    case ALERT_WINDOW_RESIZE:
      return {
        ...state,
        // setting the resizeEventOccurrence here is a way to force the reducer to update the props and force a handleSwatchesResize method call
        resizeEventOccurrence:state.resizeEventOccurrence + 1
      }
    default:
      return state;
  }
};

export const toggleProductDetailRightPanelOptionsCollapse = ( panelID, state ) => {
  let panelsOpened = {}
  // other than the findInStore panel, only one other panel can be in the expanded state at a time
  forIn( state.productRightPanelCollapse, ( val, key ) => {
    if( panelID === key ){
      panelsOpened[ key ] = !val;
    }
    else if( key === 'findInStore' || panelID === 'findInStore' ){
      panelsOpened[ key ] = val;
    }
    else {
      panelsOpened[ key ] = false;

    }
  } );
  return panelsOpened;
}

export const getpromotionDetails = ( actionData, page )=>{
  let promotionData = null;
  let showOfferSection = false;
  const {
    dynamicData,
    skuId,
    displayGWPEligibleLink
  } =  actionData;

  if( dynamicData.promotions ){

    promotionData = {
      isGiftItem:false,
      gwpPresent:false,
      actionUrl:null,
      promotions:null
    };

    dynamicData.promotions.items.map( ( promotion ) => {
      if( displayGWPEligibleLink && promotion.type === 'G' && promotion.qualifyingSKUs.items[0].id === skuId ){
        promotionData.isGiftItem = true;
        promotionData.actionUrl = promotion.actionUrl;

      }
      else {
        if( !promotionData.promotions ){
          promotionData.promotions = [];
        }

        let promo = {};
        promo.id = promotion.id;
        promo.displayName = promotion.displayName;
        promo.description = promotion.description;
        promo.type = promotion.type;

        if( promo.type === 'G' ){
          promotionData.gwpPresent = true;
        }

        if( promotion.qualifyingSKUs ){
          let qualifyingSKU = {};
          qualifyingSKU.id = promotion.qualifyingSKUs.items[0].id;
          qualifyingSKU.displayName = promotion.qualifyingSKUs.items[0].displayName;
          qualifyingSKU.imageUrl = promotion.qualifyingSKUs.items[0].images.smallImage;
          promo.qualifyingSKU = qualifyingSKU;
        }
        promotionData.promotions.push( promo );
      }
    } )
    if( page === 'quickShop' ){
      showOfferSection = !!( promotionData.promotions?.filter( promotion => promotion.type !== 'G' ).length );
      promotionData = {
        ...promotionData,
        gwpPresent:false
      }
    }
    else {
      showOfferSection = !!( promotionData.promotions || promotionData.gwpPresent );
    }
  }


  return { promotionData, showOfferSection };

}

export const setEligibilityDetails = ( purchaseEligibility ) => {

  let purchaseEligibilityData = {
    isAddToCartEligible:false,
    isComingSoonProduct:false,
    isOutOfStock:false,
    isNotifyMeSignUp:false,
    isNotifyMeEligible:false,
    isInStoreOnlyProduct:false,
    isPlatinumAndUserAnonymous:false,
    isPlatinumAndUserIneligible:false,
    availabilityMessage1:null,
    availabilityMessage2:null,
    emailStockNotifyMessage:null,
    platinumEligibilityMessage:null,
    comingSoonDate:null,
    inStoreDate:null,
    isNotAvailable:null
  }
  const eligibilityState = purchaseEligibility.eligibilityState;
  const ELIGIBILITY_STATE_MAPPING = CONFIG.PURCHASE_ELIGIBILITY_STATE_MAPPING;

  switch ( eligibilityState ){

    case ELIGIBILITY_STATE_MAPPING.ADD_TO_CART_ELIGIBLE:
      purchaseEligibilityData.isAddToCartEligible = true;
      break;

    case ELIGIBILITY_STATE_MAPPING.COMING_SOON:
      purchaseEligibilityData.isComingSoonProduct = true;
      break;

    case ELIGIBILITY_STATE_MAPPING.OUT_OF_STOCK:
      purchaseEligibilityData.isOutOfStock = true;
      break;

    case ELIGIBILITY_STATE_MAPPING.NOTIFY_ME_SIGNEDUP:
      purchaseEligibilityData.isNotifyMeSignUp = true;
      break;

    case ELIGIBILITY_STATE_MAPPING.NOTIFY_ME:
      purchaseEligibilityData.isNotifyMeEligible = true;
      break;

    case ELIGIBILITY_STATE_MAPPING.IN_STORE_ONLY:
      purchaseEligibilityData.isInStoreOnlyProduct = true;
      break;

    case ELIGIBILITY_STATE_MAPPING.PLATINUM_PRODUCT_ANONYMOUS_USER:
      purchaseEligibilityData.isPlatinumAndUserAnonymous = true;
      break;

    case ELIGIBILITY_STATE_MAPPING.PLATINUM_PRODUCT_NONPLATINUM_MEMBER:
      purchaseEligibilityData.isPlatinumAndUserIneligible = true;
      break;
  }
  purchaseEligibilityData.isNotAvailable = purchaseEligibilityData.isNotifyMeSignUp || purchaseEligibilityData.isNotifyMeEligible || purchaseEligibilityData.isOutOfStock;
  /* Messages to be displayed on product details page load */
  if( purchaseEligibility.messages ){

    const message = purchaseEligibility.messages.items[0].message;

    if( purchaseEligibilityData.isNotifyMeSignUp ){
      /* If user is already signed up email stock notify message */
      purchaseEligibilityData.emailStockNotifyMessage = message;
    }
    else if( purchaseEligibilityData.isPlatinumAndUserAnonymous || purchaseEligibilityData.isPlatinumAndUserIneligible ){
      /* message to be displayed for platinum products */
      purchaseEligibilityData.platinumEligibilityMessage = message;
    }
    else {
      /* Out of stock message */
      purchaseEligibilityData.availabilityMessage1 = message;
    }
    if( purchaseEligibility.messages.items.length > 1 ){
      /* Other variant available message */
      purchaseEligibilityData.availabilityMessage2 = purchaseEligibility.messages.items[1].message;
    }
  }
  return {
    ...purchaseEligibilityData,
    ...availabilityDate( purchaseEligibility.comingSoon?.availableDate, purchaseEligibility.findInStore?.availableDate )
  }
}

export const availabilityDate = ( comingSoonDate, inStoreDate )=>{
  let purchaseEligibilityData1 = {
    comingSoonDate:null,
    inStoreDate:null
  }
  // Display coming soon and in store date in (MMM dd) format
  if( comingSoonDate ){
    purchaseEligibilityData1.comingSoonDate = formatDate( comingSoonDate );
  }
  if( inStoreDate ){
    purchaseEligibilityData1.inStoreDate = formatDate( inStoreDate );
  }
  return purchaseEligibilityData1;
}

// any data to be set in the store on product details success should be set inside
// the method getNextStateOnProductSuccess method defined below. This method is being used in
// creating store in SSR also in pdp.controllers. This will ensure that any code changes are shared
// across the logic for both client and server side rendering
// this method is used in QuickShop.reducer as well
export const getNextStateOnProductSuccess = ( data ) => {

  let reviewRoute = undefined;

  if( global.location && global.location.href.indexOf( '/ui' ) !== -1 ){
    reviewRoute = '/ui/pdp/review';
  }
  else {
    reviewRoute = process.env.NODE_ENV === 'development' ? '/pdp/review' : appConstants.URLS.PDP_REVIEW_PAGE;
  }
  let prWriteUrl =  fullyQualifyLink( host, `${reviewRoute}/?pr_page_id=${data?.product?.id}&pr_source=web` );

  const variantType = data?.sku?.variant?.variantType;
  const isVariantColorOrScent = variantType === 'Color' || variantType === 'Scent' ;
  const swatches = data?.swatches?.items ;
  const swatchesCount = swatches?.length || 0;

  const nextState = {
    productDetails:{
      ...data,
      selectedThumbnailIndex:0,
      reviewNum: data.reviewSummary?.reviewCount || 0,
      ratingNum:  data.reviewSummary?.rating || 0,
      questionCount: data.reviewSummary?.questionCount || 0,
      displayQaSection: ( data.sku && data.sku.enableAskaQuestion ),
      displayQAs: ( !!data.reviewSummary && data.reviewSummary.questionCount !== 0 ),
      displayAskLink: ( data.sku && data.sku.enableAskaQuestion && ( !data.reviewSummary || data.reviewSummary.questionCount === 0 ) ),
      ...( data.product && { breadCrumbNames: getBreadCrumbForPowerReview( data ) } ),
      enablePrAskQuestion : ( data.sku && data.sku.enableAskaQuestion && !!data.reviewSummary && data.reviewSummary.questionCount !== 0 ),
      // this node will contain message and the border shape based on the variantType.
      variantInfo:createVariantInfo( data ),
      // dont display the favorites button if that is a GWP item
      displayFavoritesButton : !data?.product?.gwp
    },
    isValidProduct:!!data.product && data.product.live,
    isProductUnavailable:data.isProductUnavailable || ( !!data.product && !data.product.live ),
    ...( data.product && { breadCrumbLinks: getBreadCrumbLinks( data ) } ),
    combinedAltImages:( data.sku?.images ) ? combineAltImages( data ) : [],
    ...( data.product?.live &&
      {
        prWriteUrl : prWriteUrl,
        prAskUrl : `${prWriteUrl}&appName=askQuestion`
      } ),
    showVarientDropDown: isVariantColorOrScent && swatchesCount >= 3,
    showColorPanel: variantType && ( !isVariantColorOrScent || swatchesCount < 3 ),
    ...( swatches && { selectedSwatch : swatches.find( swatch => swatch.skuId === data.sku?.id ) || swatches[0] } )
  }
  return nextState;
}

export const setSeoProductData = ( data ) => {
  let seoProductData;
  if( data?.product?.live ){
    seoProductData = {
      '@context': 'http://schema.org',
      '@type': 'Product',
      ...( data.reviewSummary && data.reviewSummary.reviewCount >= 1 && {
        'aggregateRating': {
          '@type': 'AggregateRating',
          'ratingValue': data.reviewSummary.rating,
          'reviewCount': data.reviewSummary.reviewCount
        }
      } ),
      'description': data.sku.description,
      'brand': data.brand.brandName,
      'name': data.sku.displayName,
      'image': data.sku.images.mainImage,
      'productID': data.sku.id,
      'offers': {
        '@type': 'Offer',
        'availability': `http://schema.org/${data.sku.inventoryStatus}`,
        'price':  data.sku?.price?.salePrice?.amount?.toFixed( 2 ) || data.sku?.price?.listPrice?.amount?.toFixed( 2 ) || '0.00',
        'priceCurrency': data.sku?.price?.salePrice?.currencyCode || data.sku?.price?.listPrice?.currencyCode || 'USD'
      }
    }
  }
  return { seoProductData };
}

// any data to be set in the store on sku details success should be set inside
// the method getNextStateOnSkuSuccess method defined below. This method is being used in
// creating store in SSR also in pdp.controllers. This will ensure that any code changes are shared
// across the logic for both client and server side rendering
// this method is used in QuickShop.reducer as well
export const getNextStateOnSkuSuccess = ( state, data ) => {

  const variantType = data?.sku?.variant?.variantType;
  const isVariantColorOrScent = variantType === 'Color' || variantType === 'Scent' ;
  const swatches = state.productDetails?.swatches?.items ;
  const swatchesCount = swatches?.length || 0;

  const nextState = {
    ...state,
    productDetails: {
      ...state.productDetails,
      sku:data.sku,
      selectedThumbnailIndex:0
    },
    combinedAltImages:combineAltImages( {
      ...state.productDetails,
      sku:data.sku,
      selectedThumbnailIndex:0
    } ),
    showVarientDropDown: isVariantColorOrScent && swatchesCount >= 3,
    // should show color panel section if the product has variant and if there is no variant drop down
    showColorPanel: variantType && ( !isVariantColorOrScent || swatchesCount < 3 ),
    ...( swatches && { selectedSwatch: swatches.find( swatch=> swatch.skuId === data.sku?.id ) || swatches[0] } )
  }
  return nextState;
}

// this method prepares the data to be displayed as breadcrumbs in the product page
// the breadcrumbs links will have the home link, and then the cateogries returned by the service and finally the product name
export const getBreadCrumbLinks = ( productDetails ) => {

  let breadCrumbLinks = [];
  const categoryPath = productDetails.product.categoryPath;
  const homeLink = {
    url:'/',
    dataNavDescription:'bc - home',
    name:'home',
    format:true // format value of true, will indicate that the display value will have to be fetched from the messages file
  }
  // this adds the home page link to the breadcrumb data
  breadCrumbLinks.push( homeLink );
  let omnitureAttribute = undefined;
  let categoryLink = undefined;

  categoryPath && categoryPath.items.map( ( breadCrumb, index ) => {
    omnitureAttribute = omnitureAttribute ? `${omnitureAttribute}:${ breadCrumb.name.toLowerCase() }` : breadCrumb.name.toLowerCase();
    categoryLink = {
      url:breadCrumb.actionUrl,
      dataNavDescription:`bc - ${ omnitureAttribute }`,
      name:breadCrumb.name
    }
    // this adds the category link to the breadcrumb data
    breadCrumbLinks.push( categoryLink );
  } )

  const productLink = {
    name:productDetails.product.displayName
  }
  // this adds the product name to the breadcrumb data
  breadCrumbLinks.push( productLink );

  return breadCrumbLinks;

}
// This method will return an array that contains main image url & thumbnail image Url of  main product , hover state of main product and  altimages
export const combineAltImages = ( productDetails ) => {
  let combineAltImages = [];
  combineAltImages.push( { mainImage: productDetails.sku?.images?.mainImage, thumbnailImage: productDetails.sku?.images?.thumbnailImage } );
    productDetails.swatches?.items?.map( ( swatch, index ) =>{
      if( ( productDetails.sku.id === swatch.skuId ) && swatch.hoverImages ){
        combineAltImages.push( { mainImage: swatch.hoverImages.mainImage, thumbnailImage: swatch.hoverImages.thumbnailImage } );
      }
    } )
    if( productDetails.product?.altImages?.items ){
      combineAltImages = combineAltImages.concat( productDetails.product.altImages.items );
    }
    return combineAltImages;
}

// This method will populate the variantInfo node based on variantType
export const createVariantInfo = ( productDetails ) => {
  switch ( productDetails.sku?.variant?.variantType ){
    case 'Color':
      return {
        message:messages.colorVariant,
        treatmentType : appConstants.TREATMENT_TYPE.CIRCLE
      }

    case 'Scent':
      return {
        message:messages.scentVariant,
        treatmentType : appConstants.TREATMENT_TYPE.CIRCLE
      }

    case 'Size':
      return {
        message:messages.sizeVariant,
        treatmentType : appConstants.TREATMENT_TYPE.RECTANGLE
      }

    case 'Other':
      return {
        message:messages.otherVariant,
        treatmentType : appConstants.TREATMENT_TYPE.DEFAULT
      }

    default:
      return {
        message:'',
        treatmentType : appConstants.TREATMENT_TYPE.DEFAULT
      }
  }
}

export const getProductDetailsState = state => state.productPage.productDetails;

// the PowerReviews-formatted category hierarchy of the product
export const getBreadCrumbForPowerReview = ( productDetails ) => {
  // This method is being used in creating store in SSR .
  const crumbPath = productDetails.product.categoryPath?.items.map( ( breadCrumb ) => {
    return ( `${breadCrumb.name}>` );
  } ).join( '' );
  return `Home>${ crumbPath ?? '' }${productDetails.product.displayName}` ;
}
