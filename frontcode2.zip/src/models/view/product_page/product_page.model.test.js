/**
 * Test for ProductDetail Reducer
 */

import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import _ from 'lodash';

import {
  actionTypes as ReduxActionType
} from 'redux-form';
import {
  ALERT_WINDOW_RESIZE
} from 'ulta-fed-core/dist/js/events/global/global.events'
import {
  formatDate,
  fullyQualifyLink,
  host
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import {
  PRODUCT_RIGHT_PANEL_COLLAPSE,
  PRODUCT_SWATCHES_VIEW_ALL_OPTIONS,
  PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS,
  PRODUCT_SWATCHES_COUNT_PER_ROW,
  PRODUCT_SWATCHES_MAX_HEIGHT,
  PRODUCT_SWATCHES_WIDTH_AND_MARGIN,
  PRODUCT_PAGE_MODAL_OPEN,
  PRODUCT_PAGE_MODAL_CLOSE,
  PRODUCT_MAINIMAGE_LOADER,
  PRODUCT_THUMBNAILIMAGE_SELECT,
  PRODUCT_POWERREVIEW_READY_FLAG
} from '../../../events/product_detail/product_detail.events';
import reducer, {
  initialState,
  reducerSwitch,
  toggleProductDetailRightPanelOptionsCollapse,
  getBreadCrumbLinks,
  getBreadCrumbForPowerReview,
  createVariantInfo,
  combineAltImages,
  getNextStateOnProductSuccess
} from './product_page.model';
jest.mock( 'ulta-fed-core/dist/js/utils/formatters/formatters', ()=>{
  return {
    formatDate:()=> 'Nov 12',
    fullyQualifyLink:jest.fn( ( host, url ) => {
      return host + url;
    } ),
    host: 'www.ulta.com'
  }
} );


describe( 'Product Page reducer', ( ) => {
  const serviceType = 'pdpProductDetails';
  registerServiceName( serviceType );
  registerServiceName( 'switches' );
  registerServiceName( 'pdpSkuDetails' );
  registerServiceName( 'pdpPurchaseEligibility' );
  registerServiceName( 'pdpSkuDynamicData' );
  registerServiceName( 'pdpAddItem' );
  registerServiceName( 'pdpRemoveFromFavorites' );
  registerServiceName( 'pdpFindFavorite' );
  registerServiceName( 'pdpAddFavorite' );
  registerServiceName( 'pdpRemoveFavorite' );
  registerServiceName( 'pdpEmailNotification' );
  registerServiceName( 'pdpProductRecs' );

  it( 'should have the proper default state', ( ) => {
    let expectedState = {
      productDetails: null,
      isValidProduct:false,
      isProductUnavailable:undefined,
      displayMoreOptions:false,
      swatchesCountPerRow:999,
      swatchesSectionMaxHeight:'none',
      swatchesSectionWidth:'none',
      productRightPanelCollapse: {
        findInStore: false,
        productDetails:true,
        howToUse: false,
        ingredients: false,
        productRestrictions: false
      },
      viewAllOption: false,
      addToBagErrorMessages:null,
      isEmailMeModalOpen: false,
      recommendedProducts: null,
      breadCrumbLinks:undefined,
      openFindInStoreModal:false,
      powerReviewsScriptLoaded:false,
      resizeEventOccurrence:0,
      swatchesCellMargin:0,
      openProductVariantDrodownModal:false,
      showPromotionLoader:true,
      showMainImageLoader:true
    }
    expect( initialState ).toEqual( expectedState );
  } )

  it( 'should be a function', ( ) => {
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  describe( 'Product Page Right Panel Options Collapse', ( ) => {
    let state1 = {
      productRightPanelCollapse: {
        findInStore: false,
        productDetails:false,
        howToUse: false,
        ingredients: false,
        productRestrictions: false
      }
    }
    let panelID = 'findInStore';
    let actionCreator = {
      type: PRODUCT_RIGHT_PANEL_COLLAPSE,
      panelID
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        productRightPanelCollapse: {
          findInStore: true,
          productDetails:false,
          howToUse: false,
          ingredients: false,
          productRestrictions: false
        }
      };

      expect( reducer( state1, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Should have only one accordin open at a time except for FindInStore section', ( ) => {

      let state1 = {
        productRightPanelCollapse: {
          findInStore: true,
          productDetails:true,
          howToUse: false,
          ingredients: false,
          productRestrictions: false
        }
      }
      panelID = 'howToUse';
      actionCreator = {
        type: PRODUCT_RIGHT_PANEL_COLLAPSE,
        panelID
      }
      let expectedOutput = {
        productRightPanelCollapse: {
          findInStore: true,
          productDetails:false,
          howToUse: true,
          ingredients: false,
          productRestrictions: false
        }
      };

      expect( reducer( state1, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'Should be able to open FindInStore section without changing the other sections of accordion', ( ) => {

      let state1 = {
        productRightPanelCollapse: {
          findInStore: false,
          productDetails:true,
          howToUse: false,
          ingredients: false,
          productRestrictions: false
        }
      }
      panelID = 'findInStore';
      actionCreator = {
        type: PRODUCT_RIGHT_PANEL_COLLAPSE,
        panelID
      }
      let expectedOutput = {
        productRightPanelCollapse: {
          findInStore: true,
          productDetails:true,
          howToUse: false,
          ingredients: false,
          productRestrictions: false
        }
      };

      expect( reducer( state1, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );

  it( 'should execute case getServiceType( \'pdpProductDetails\', \'success\' )', ( ) => {
    let res = {
      product: {
        maxQty: 3,
        displayName:'Online Only TexasLash Mascara',
        live: true,
        categoryPath: {
          items:[
            {
              name : 'Nails'
            },
            {
              name : 'Nail Care'
            }
          ]
        },
        'altImages': {
          'items': []
        },
        id:'xlsImpprod12421349'
      },
      brand: {
        brandName: 'Red Carpet Manicure'
      },
      sku:{
        id:1,
        images:{
          mainImage:'//mainUrl',
          thumbnailImage:'//url'
        },
        enableAskaQuestion: true,
        inventoryStatus: 'In Stock',
        description: 'description',
        displayName: 'displayName'
      },
      reviewSummary: {
        rating: 5,
        reviewCount: 1,
        questionCount: 1
      },
      isProductUnavailable:true
    }
    let actionCreator = {
      type: getServiceType( 'pdpProductDetails', 'success' ),
      data: res
    }
    let expectedOutput = {
      isValidProduct: true,
      showVarientDropDown:false,
      productDetails: {
        brand: {
          brandName : 'Red Carpet Manicure'
        },
        selectedThumbnailIndex: 0,
        product: {
          maxQty: 3,
          displayName:'Online Only TexasLash Mascara',
          live: true,
          categoryPath: {
            items:[
              {
                name : 'Nails'
              },
              {
                name : 'Nail Care'
              }
            ]
          },
          'altImages': {
            'items': []
          },
          id:'xlsImpprod12421349'
        },
        sku:{
          description: 'description',
          displayName: 'displayName',
          id:1,
          images:{
            mainImage:'//mainUrl',
            thumbnailImage:'//url'
          },
          enableAskaQuestion: true,
          inventoryStatus: 'In Stock'
        },
        reviewSummary: {
          rating: 5,
          reviewCount: 1,
          questionCount: 1
        },
        ratingNum: 5,
        reviewNum: 1,
        questionCount:1,
        displayQaSection: true,
        displayQAs: true,
        displayAskLink: false,
        displayFavoritesButton: true,
        isProductUnavailable: true,
        breadCrumbNames: 'Home>Nails>Nail Care>Online Only TexasLash Mascara',
        enablePrAskQuestion : true,
        variantInfo: {
          message:'',
          treatmentType:'default'
        }
      },
      prAskUrl:'www.ulta.com/ulta/review/?pr_page_id=xlsImpprod12421349&pr_source=web&appName=askQuestion',
      prWriteUrl:'www.ulta.com/ulta/review/?pr_page_id=xlsImpprod12421349&pr_source=web',
      seoProductData: {
        '@context': 'http://schema.org',
        '@type': 'Product',
        'aggregateRating':  {
          '@type': 'AggregateRating',
          'ratingValue': 5,
          'reviewCount': 1
        },
        'brand': 'Red Carpet Manicure',
        'description': 'description',
        'image': '//mainUrl',
        'name': 'displayName',
        'offers':  {
          '@type': 'Offer',
          'availability': 'http://schema.org/In Stock',
          'price': '0.00',
          'priceCurrency': 'USD'
        },
        'productID': 1
      },
      breadCrumbLinks: [
        {
          dataNavDescription: 'bc - home',
          format: true,
          name: 'home',
          url: '/'
        },
        {
          dataNavDescription: 'bc - nails',
          name: 'Nails',
          url: undefined
        },
        {
          dataNavDescription: 'bc - nails:nail care',
          name: 'Nail Care',
          url: undefined
        },
        {
          name : 'Online Only TexasLash Mascara'
        }
      ],
      isProductUnavailable: true,
      combinedAltImages:[{
        mainImage:'//mainUrl',
        thumbnailImage:'//url'
      }]
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should not display aggregateRating in seo product schema if reviewCount is less than 0 for valid product in pdpProductDetails success ', ( ) => {
    let res = {
      product: {
        maxQty: 3,
        displayName: 'Online Only TexasLash Mascara',
        live: true,
        categoryPath: {
          items: [
            {
              name : 'Nails'
            },
            {
              name : 'Nail Care'
            }
          ]
        },
        'altImages': {
          'items': []
        },
        id:'xlsImpprod12421349'
      },
      brand: {
        brandName: 'Red Carpet Manicure'
      },
      sku: {
        id: 1,
        images: {
          mainImage: '//mainUrl',
          thumbnailImage: '//url'
        },
        enableAskaQuestion: true,
        inventoryStatus: 'In Stock',
        description: 'description',
        displayName: 'displayName'
      },
      reviewSummary: {
        rating: 5,
        reviewCount: 0,
        questionCount: 1
      },
      isProductUnavailable: true
    }
    let actionCreator = {
      type: getServiceType( 'pdpProductDetails', 'success' ),
      data: res
    }
    let expectedOutput = {
      isValidProduct: true,
      showVarientDropDown: false,
      productDetails: {
        brand: {
          brandName : 'Red Carpet Manicure'
        },
        selectedThumbnailIndex: 0,
        product: {
          maxQty: 3,
          displayName: 'Online Only TexasLash Mascara',
          live: true,
          categoryPath: {
            items: [
              {
                name : 'Nails'
              },
              {
                name : 'Nail Care'
              }
            ]
          },
          'altImages': {
            'items': []
          },
          id:'xlsImpprod12421349'
        },
        sku:{
          description: 'description',
          displayName: 'displayName',
          id: 1,
          images: {
            mainImage: '//mainUrl',
            thumbnailImage: '//url'
          },
          enableAskaQuestion: true,
          inventoryStatus: 'In Stock'
        },
        reviewSummary: {
          rating: 5,
          reviewCount: 0,
          questionCount: 1
        },
        ratingNum: 5,
        reviewNum: 0,
        questionCount:1,
        displayQaSection: true,
        displayQAs: true,
        displayAskLink: false,
        displayFavoritesButton: true,
        isProductUnavailable: true,
        breadCrumbNames: 'Home>Nails>Nail Care>Online Only TexasLash Mascara',
        enablePrAskQuestion : true,
        variantInfo: {
          message:'',
          treatmentType:'default'
        }
      },
      prAskUrl:'www.ulta.com/ulta/review/?pr_page_id=xlsImpprod12421349&pr_source=web&appName=askQuestion',
      prWriteUrl:'www.ulta.com/ulta/review/?pr_page_id=xlsImpprod12421349&pr_source=web',
      seoProductData: {
        '@context': 'http://schema.org',
        '@type': 'Product',
        'brand': 'Red Carpet Manicure',
        'description': 'description',
        'image': '//mainUrl',
        'name': 'displayName',
        'offers':  {
          '@type': 'Offer',
          'availability': 'http://schema.org/In Stock',
          'price': '0.00',
          'priceCurrency': 'USD'
        },
        'productID': 1
      },
      breadCrumbLinks: [
        {
          dataNavDescription: 'bc - home',
          format: true,
          name: 'home',
          url: '/'
        },
        {
          dataNavDescription: 'bc - nails',
          name: 'Nails',
          url: undefined
        },
        {
          dataNavDescription: 'bc - nails:nail care',
          name: 'Nail Care',
          url: undefined
        },
        {
          name : 'Online Only TexasLash Mascara'
        }
      ],
      isProductUnavailable: true,
      combinedAltImages:[{
        mainImage:'//mainUrl',
        thumbnailImage:'//url'
      }]
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpProductDetails\', \'success\' ) with isValidProduct as false if product is null', ( ) => {
    let res = {
      product: null,
      sku: {
        enableAskaQuestion: false
      },
      reviewSummary: null,
      isProductUnavailable: true
    }
    let actionCreator = {
      type: getServiceType( 'pdpProductDetails', 'success' ),
      data: res
    }
    let expectedOutput = {
      combinedAltImages:[],
      isValidProduct: false,
      showVarientDropDown:false,
      productDetails: {
        product: null,
        isProductUnavailable: true,
        selectedThumbnailIndex: 0,
        ratingNum: 0,
        reviewNum: 0,
        questionCount:0,
        displayQaSection: false,
        displayQAs: false,
        displayFavoritesButton: true,
        displayAskLink: false,
        enablePrAskQuestion : false,
        variantInfo: {
          message:'',
          treatmentType:'default'
        },
        reviewSummary: null,
        sku: {
          enableAskaQuestion: false
        }
      },
      isProductUnavailable: true
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpProductDetails\', \'success\' ) with isProductUnavailable as true if it returns isProductUnavailable in product response', ( ) => {
    let res = {
      product: null,
      isProductUnavailable:true
    }
    let actionCreator = {
      type: getServiceType( 'pdpProductDetails', 'success' ),
      data: res
    }
    let expectedOutput = {
      combinedAltImages:[],
      showVarientDropDown:false,
      isValidProduct: false,
      productDetails: {
        ...res,
        selectedThumbnailIndex: 0,
        ratingNum: 0,
        reviewNum: 0,
        questionCount:0,
        displayQaSection: undefined,
        displayQAs: false,
        displayAskLink: undefined,
        displayFavoritesButton: true,
        enablePrAskQuestion : undefined,
        variantInfo: {
          message:'',
          treatmentType:'default'
        }
      },
      isProductUnavailable:true
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpProductDetails\', \'success\' ) when reviewSummary is present and review count is 0', ( ) => {
    let res = {
      reviewSummary: {
        rating: 0,
        reviewCount: 0,
        questionCount: 1
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpProductDetails', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        ...res,
        selectedThumbnailIndex: 0,
        ratingNum : 0,
        reviewNum : 0,
        questionCount:1,
        displayQaSection: undefined,
        displayQAs: true,
        displayAskLink: undefined,
        displayFavoritesButton: true,
        enablePrAskQuestion : undefined,
        variantInfo: {
          message:'',
          treatmentType:'default'
        }
      },
      isValidProduct : false,
      isProductUnavailable:false,
      combinedAltImages:[],
      showVarientDropDown:false
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );


  it( 'should execute case getServiceType( \'pdpProductDetails\', \'success\' with live as false )', ( ) => {
    let res = {
      product: {
        maxQty: 3,
        displayName:'Online Only TexasLash Mascara',
        live: false,
        'altImages': {
          'items': []
        }
      },
      sku:{
        id:1,
        images:{
          mainImage:'//mainUrl',
          thumbnailImage:'//url'
        },
        enableAskaQuestion: true
      },
      reviewSummary: {
        rating: 5,
        reviewCount: 1,
        questionCount: 1
      },
      isProductUnavailable:true
    }
    let actionCreator = {
      type: getServiceType( 'pdpProductDetails', 'success' ),
      data: res
    }
    let expectedOutput = {
      isValidProduct: false,
      productDetails: {
        selectedThumbnailIndex: 0,
        product: {
          maxQty: 3,
          displayName:'Online Only TexasLash Mascara',
          live:false,
          'altImages': {
            'items': []
          }
        },
        sku:{
          id:1,
          images:{
            mainImage:'//mainUrl',
            thumbnailImage:'//url'
          },
          enableAskaQuestion: true
        },
        reviewSummary: {
          rating: 5,
          reviewCount: 1,
          questionCount: 1
        },
        ratingNum: 5,
        reviewNum: 1,
        questionCount:1,
        displayQaSection: true,
        displayQAs: true,
        displayAskLink: false,
        displayFavoritesButton: true,
        isProductUnavailable: true,
        breadCrumbNames: 'Home>Online Only TexasLash Mascara',
        enablePrAskQuestion : true,
        variantInfo: {
          message:'',
          treatmentType:'default'
        }

      },
      breadCrumbLinks:  [{
        dataNavDescription: 'bc - home',
        format: true,
        name: 'home',
        url: '/'
      },
      {
        name:'Online Only TexasLash Mascara'
      }
      ],
      isProductUnavailable: true,
      showVarientDropDown:false,
      combinedAltImages:[{
        'mainImage': '//mainUrl',
        'thumbnailImage': '//url'
      }]
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );



  it( 'should execute case getServiceType( \'pdpSkuDetails\', \'success\' ) and set showColorPanel to true if variant is present and swatches is null ', ( ) => {
    let skuData = {
      sku: {
        'longDescription': '<br><li>Physicians Formula First ever Beauty Balm Powder form for a smoothing effect that instantly diffuses the appearance of imperfections, evens out skin tone and minimizes the appearance of pores.<br><li>Weightless powder acts as a protective veil from UV damage & moisture loss so skin looks and feels smooth, glowing and naturally flawless.<br><li>Use with the Concealer & Cream for the ultimate, high-performance wear.<br><li>Hypoallergenic. Fragrance-Free. Paraben-Free. Gluten Free. Dermatologist approved. Non-Comedogenic.',
        'enableFindStore': true,
        'images': {
          'thumbnailImage': 'http://images.ulta.com/is/image/Ulta/2260978?$tn$',
          'mainImage': 'http://images.ulta.com/is/image/Ulta/2260978',
          'blowupImage': 'http://images.ulta.com/is/image/Ulta/2260978?$detail$',
          'largeImage': 'http://images.ulta.com/is/image/Ulta/2260978?$lg$',
          'smallImage': 'http://images.ulta.com/is/image/Ulta/2260978?$sm$',
          'mediumImageUrl': 'http://images.ulta.com/is/image/Ulta/2260978?$md$'
        },
        'salePrice': {
          'price': 6.89,
          'currencyCode': 'USD'
        },
        'displayName': 'Superstay Lipcolor',
        'description': 'Physicians Formula First ever Beauty Balm Powder form for a smoothing effect that instantly diffuses the appearance of imperfections, evens out skin tone and minimizes the appearance of pores',
        'badges': {
          'items': [
            {
              'badgeName': 'onSale_badge',
              'priority': 5,
              'badgeImageUrl': 'http://s7d5.scene7.com/is/image/Ulta/badge-sale'
            }
          ]
        },
        'UOM': 'oz',
        'directions': 'Apply liberally 15 minutes before sun exposure. Use water resistant sunscreen if swimming or sweating. Reapply at least every 2 hours. Children under 6 months: Ask a doctor.',
        'size': '0.14',
        'enableAskaQuestion': true,
        'variant': {
          'variantType': 'Color',
          'variantDesc': 'Sienna Ever After'
        },
        'ingredients': 'Active: Titanium Dioxide, Zinc Oxide. Inactive: Mica, Zinc Stearate, Octyldodecyl Stearoyl Stearate, Dimethicone, Boron Nitride, Vinyl Dimethicone/Methicone Silsesquioxane Crosspolymer, Magnesium Silicate, Lauroyl Lysine, Triethylhexanoin, Salix Alba (Willow) Bark Extract, Perilla Ocymoides Seed Oil, Lysolecithin, Glycerin, Tetrahexyldecyl Ascorbate, Tocopheryl Acetate, Calcium Aluminum Borosilicate, Silica, Glyceryl Caprylate, Potassium Sorbate, Sodium Dehydroacetate. May Contain: Iron Oxides, Titanium Dioxide.',
        'onSale': true,
        'id': '2260978',
        'couponRestriction': null,
        'shippingRestriction': 'Shipping Restrictions : This item cannot be shipped via air.',
        'isCouponEligible': true,
        'listPrice': {
          'price': 8.99,
          'currencyCode': 'USD'
        }
      }
    }
    let state2 = {
      productDetails: {
        sku : skuData
      },
      combinedAltImages:[{
        'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
        'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$'
      }]
    }
    let res1 = {
      sku: {
        'longDescription': '<b>SHIPS FREE: Purchase bareMinerals foundation and ALWAYS get free shipping on your ENTIRE ORDER! No Minimum</b><br>(Purchase Original, Matte, Ready, or BareSkin Foundation, and you automatically get Free Shipping on your Entire Order)<br><br>bareMinerals Original Foundation is the #1 U.S. Prestige Loose Powder Foundation*<br><br>*Source: The NPD Group, Inc. / U.S. Prestige Beauty Total Department Specialty, Dollar & Unit Sales, Annual 2016<br><br>With just five pure ingredients, bareMinerals SPF 15 Foundation delivers flawless coverage and the creamy minerals are clinically proven to improve the appearance of skin over time. It looks like a powder, feels like a cream, and buffs on like silk, giving skin a natural luminosity while feeling as if you are not wearing any makeup at all.<br><br>Benefits:<ul><li>Clinically proven to promote clearer, healthier-looking skin.<li>Provides buildable, complete coverage.<li>Free of preservatives, talc, oil, waxes, fragrances, and other chemicals that can irritate skin and cause breakouts.<li>Free of parabens, sulfates, and phthalates.<li>Pure enough to sleep in, made with 5 mineral ingredients. Non-acnegenic, hypoallergenic, non-comedogenic. Formulated without binders, fillers or synthetic chemicals.</li></ul><br><a href=\'http://ulta.com/shade-finders/bareminerals-original-foundation-finder/\'target=\'_blank\'>Click here to find your perfect bareMinerals Original shade!</a><br><br><iframe width=\'420\' height=\'315\' src=\'https://www.youtube.com/embed/AYDDxtUVFKA?rel=0\' frameborder=\'0\' allowfullscreen></iframe><br><br><iframe width=\'420\' height=\'315\' src=\'https://www.youtube.com/embed/jSfRkOjjf8U\' frameborder=\'0\' allowfullscreen></iframe></li></ul>\r',
        'enableFindStore': true,
        'images': {
          'blowupImage': 'https://images.ulta.com/is/image/Ulta/5081178?$detail$',
          'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
          'largeImage': 'https://images.ulta.com/is/image/Ulta/5081178?$lg$',
          'smallImage': 'https://images.ulta.com/is/image/Ulta/5081178?$sm$',
          'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$',
          'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/5081178?$md$'
        },
        'salePrice': {
          'price': 0,
          'currencyCode': 'USD'
        },
        'displayName': 'ORIGINAL Foundation Broad Spectrum SPF 15',
        'description': 'bareMinerals SPF 15 Foundation',
        'badges': {
          'items': [
            {
              'badgeName': 'fanFavorite_badge',
              'priority': 9,
              'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-fan-fave'
            }
          ]
        },
        'shippingRestricted': false,
        'UOM': 'oz',
        'couponEligible': false,
        'directions': 'Swirl a small amount of bareMinerals Foundation in the lid until it all disappears into the brush. Tap away excess. Buff onto the skin in a circular motion.<br><br>Pair with the Beautiful Finish Brush, which is designed with a skirted silhouette that fits perfectly into the ORIGINAL and MATTE Foundation lids to help capture (and contain) every mineral.',
        'size': '0.28',
        'comingSoon': false,
        'enableAskaQuestion': true,
        'variant': {
          'variantType': 'Color',
          'variantDesc': 'Fair 01 (fairest porcelain skin w/ cool undertones)'
        },
        'ingredients': 'Active: Titanium Dioxide 12.6%, Zinc Oxide 21%. Inactive: Bismuth Oxychloride, Mica, Iron Oxides, Zinc Oxide, Titanium Dioxide.',
        'onSale': false,
        'storeOnly': false,
        'id': '5081178',
        'maxQty': 10,
        'listPrice': {
          'price': 28.5,
          'currencyCode': 'USD'
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpSkuDetails', 'success' ),
      data: res1
    }
    let expectedOutput = {
      combinedAltImages:[{
        'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
        'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$'
      }],
      productDetails: {
        selectedThumbnailIndex: 0,
        ...res1
      },
      showVarientDropDown:false,
      showColorPanel:true,
      showPromotionLoader:true
    };
    expect( reducer( state2, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpSkuDetails\', \'success\' ) and set selectedSwatch ', ( ) => {
    let skuData = {
      sku: {
        'longDescription': '<br><li>Physicians Formula First ever Beauty Balm Powder form for a smoothing effect that instantly diffuses the appearance of imperfections, evens out skin tone and minimizes the appearance of pores.<br><li>Weightless powder acts as a protective veil from UV damage & moisture loss so skin looks and feels smooth, glowing and naturally flawless.<br><li>Use with the Concealer & Cream for the ultimate, high-performance wear.<br><li>Hypoallergenic. Fragrance-Free. Paraben-Free. Gluten Free. Dermatologist approved. Non-Comedogenic.',
        'enableFindStore': true,
        'images': {
          'thumbnailImage': 'http://images.ulta.com/is/image/Ulta/2260978?$tn$',
          'mainImage': 'http://images.ulta.com/is/image/Ulta/2260978',
          'blowupImage': 'http://images.ulta.com/is/image/Ulta/2260978?$detail$',
          'largeImage': 'http://images.ulta.com/is/image/Ulta/2260978?$lg$',
          'smallImage': 'http://images.ulta.com/is/image/Ulta/2260978?$sm$',
          'mediumImageUrl': 'http://images.ulta.com/is/image/Ulta/2260978?$md$'
        },
        'salePrice': {
          'price': 6.89,
          'currencyCode': 'USD'
        },
        'displayName': 'Superstay Lipcolor',
        'description': 'Physicians Formula First ever Beauty Balm Powder form for a smoothing effect that instantly diffuses the appearance of imperfections, evens out skin tone and minimizes the appearance of pores',
        'badges': {
          'items': [
            {
              'badgeName': 'onSale_badge',
              'priority': 5,
              'badgeImageUrl': 'http://s7d5.scene7.com/is/image/Ulta/badge-sale'
            }
          ]
        },
        'UOM': 'oz',
        'directions': 'Apply liberally 15 minutes before sun exposure. Use water resistant sunscreen if swimming or sweating. Reapply at least every 2 hours. Children under 6 months: Ask a doctor.',
        'size': '0.14',
        'enableAskaQuestion': true,
        'variant': {
          'variantType': 'Color',
          'variantDesc': 'Sienna Ever After'
        },
        'ingredients': 'Active: Titanium Dioxide, Zinc Oxide. Inactive: Mica, Zinc Stearate, Octyldodecyl Stearoyl Stearate, Dimethicone, Boron Nitride, Vinyl Dimethicone/Methicone Silsesquioxane Crosspolymer, Magnesium Silicate, Lauroyl Lysine, Triethylhexanoin, Salix Alba (Willow) Bark Extract, Perilla Ocymoides Seed Oil, Lysolecithin, Glycerin, Tetrahexyldecyl Ascorbate, Tocopheryl Acetate, Calcium Aluminum Borosilicate, Silica, Glyceryl Caprylate, Potassium Sorbate, Sodium Dehydroacetate. May Contain: Iron Oxides, Titanium Dioxide.',
        'onSale': true,
        'id': '2260978',
        'couponRestriction': null,
        'shippingRestriction': 'Shipping Restrictions : This item cannot be shipped via air.',
        'isCouponEligible': true,
        'listPrice': {
          'price': 8.99,
          'currencyCode': 'USD'
        }
      }
    }
    let state2 = {
      productDetails: {
        sku : skuData,
        swatches:{
          items:[
            {
              skuId:'2260978'
            },
            {
              skuId:'5081178'
            }
          ]
        }
      },
      combinedAltImages:[{
        'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
        'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$'
      }]
    }
    let res1 = {
      sku: {
        'longDescription': '<b>SHIPS FREE: Purchase bareMinerals foundation and ALWAYS get free shipping on your ENTIRE ORDER! No Minimum</b><br>(Purchase Original, Matte, Ready, or BareSkin Foundation, and you automatically get Free Shipping on your Entire Order)<br><br>bareMinerals Original Foundation is the #1 U.S. Prestige Loose Powder Foundation*<br><br>*Source: The NPD Group, Inc. / U.S. Prestige Beauty Total Department Specialty, Dollar & Unit Sales, Annual 2016<br><br>With just five pure ingredients, bareMinerals SPF 15 Foundation delivers flawless coverage and the creamy minerals are clinically proven to improve the appearance of skin over time. It looks like a powder, feels like a cream, and buffs on like silk, giving skin a natural luminosity while feeling as if you are not wearing any makeup at all.<br><br>Benefits:<ul><li>Clinically proven to promote clearer, healthier-looking skin.<li>Provides buildable, complete coverage.<li>Free of preservatives, talc, oil, waxes, fragrances, and other chemicals that can irritate skin and cause breakouts.<li>Free of parabens, sulfates, and phthalates.<li>Pure enough to sleep in, made with 5 mineral ingredients. Non-acnegenic, hypoallergenic, non-comedogenic. Formulated without binders, fillers or synthetic chemicals.</li></ul><br><a href=\'http://ulta.com/shade-finders/bareminerals-original-foundation-finder/\'target=\'_blank\'>Click here to find your perfect bareMinerals Original shade!</a><br><br><iframe width=\'420\' height=\'315\' src=\'https://www.youtube.com/embed/AYDDxtUVFKA?rel=0\' frameborder=\'0\' allowfullscreen></iframe><br><br><iframe width=\'420\' height=\'315\' src=\'https://www.youtube.com/embed/jSfRkOjjf8U\' frameborder=\'0\' allowfullscreen></iframe></li></ul>\r',
        'enableFindStore': true,
        'images': {
          'blowupImage': 'https://images.ulta.com/is/image/Ulta/5081178?$detail$',
          'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
          'largeImage': 'https://images.ulta.com/is/image/Ulta/5081178?$lg$',
          'smallImage': 'https://images.ulta.com/is/image/Ulta/5081178?$sm$',
          'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$',
          'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/5081178?$md$'
        },
        'salePrice': {
          'price': 0,
          'currencyCode': 'USD'
        },
        'displayName': 'ORIGINAL Foundation Broad Spectrum SPF 15',
        'description': 'bareMinerals SPF 15 Foundation',
        'badges': {
          'items': [
            {
              'badgeName': 'fanFavorite_badge',
              'priority': 9,
              'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-fan-fave'
            }
          ]
        },
        'shippingRestricted': false,
        'UOM': 'oz',
        'couponEligible': false,
        'directions': 'Swirl a small amount of bareMinerals Foundation in the lid until it all disappears into the brush. Tap away excess. Buff onto the skin in a circular motion.<br><br>Pair with the Beautiful Finish Brush, which is designed with a skirted silhouette that fits perfectly into the ORIGINAL and MATTE Foundation lids to help capture (and contain) every mineral.',
        'size': '0.28',
        'comingSoon': false,
        'enableAskaQuestion': true,
        'variant': {
          'variantType': 'Color',
          'variantDesc': 'Fair 01 (fairest porcelain skin w/ cool undertones)'
        },
        'ingredients': 'Active: Titanium Dioxide 12.6%, Zinc Oxide 21%. Inactive: Bismuth Oxychloride, Mica, Iron Oxides, Zinc Oxide, Titanium Dioxide.',
        'onSale': false,
        'storeOnly': false,
        'id': '5081178',
        'maxQty': 10,
        'listPrice': {
          'price': 28.5,
          'currencyCode': 'USD'
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpSkuDetails', 'success' ),
      data: res1
    }
    let expectedOutput = {
      combinedAltImages:[{
        'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
        'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$'
      }],
      productDetails: {
        selectedThumbnailIndex: 0,
        ...res1,
        swatches:{
          items:[
            {
              skuId:'2260978'
            },
            {
              skuId:'5081178'
            }
          ]
        }
      },
      showVarientDropDown:false,
      showColorPanel:true,
      showPromotionLoader:true,
      selectedSwatch:{
        skuId:'5081178'
      }
    };
    expect( reducer( state2, actionCreator ) ).toEqual( expectedOutput );

  } );


  it( 'should execute case getServiceType( \'pdpSkuDetails\', \'success\' ) and set selectedSwatch as the first swatch if the default swatch is not presents', ( ) => {
    let skuData = {
      sku: {
        'longDescription': '<br><li>Physicians Formula First ever Beauty Balm Powder form for a smoothing effect that instantly diffuses the appearance of imperfections, evens out skin tone and minimizes the appearance of pores.<br><li>Weightless powder acts as a protective veil from UV damage & moisture loss so skin looks and feels smooth, glowing and naturally flawless.<br><li>Use with the Concealer & Cream for the ultimate, high-performance wear.<br><li>Hypoallergenic. Fragrance-Free. Paraben-Free. Gluten Free. Dermatologist approved. Non-Comedogenic.',
        'enableFindStore': true,
        'images': {
          'thumbnailImage': 'http://images.ulta.com/is/image/Ulta/2260978?$tn$',
          'mainImage': 'http://images.ulta.com/is/image/Ulta/2260978',
          'blowupImage': 'http://images.ulta.com/is/image/Ulta/2260978?$detail$',
          'largeImage': 'http://images.ulta.com/is/image/Ulta/2260978?$lg$',
          'smallImage': 'http://images.ulta.com/is/image/Ulta/2260978?$sm$',
          'mediumImageUrl': 'http://images.ulta.com/is/image/Ulta/2260978?$md$'
        },
        'salePrice': {
          'price': 6.89,
          'currencyCode': 'USD'
        },
        'displayName': 'Superstay Lipcolor',
        'description': 'Physicians Formula First ever Beauty Balm Powder form for a smoothing effect that instantly diffuses the appearance of imperfections, evens out skin tone and minimizes the appearance of pores',
        'badges': {
          'items': [
            {
              'badgeName': 'onSale_badge',
              'priority': 5,
              'badgeImageUrl': 'http://s7d5.scene7.com/is/image/Ulta/badge-sale'
            }
          ]
        },
        'UOM': 'oz',
        'directions': 'Apply liberally 15 minutes before sun exposure. Use water resistant sunscreen if swimming or sweating. Reapply at least every 2 hours. Children under 6 months: Ask a doctor.',
        'size': '0.14',
        'enableAskaQuestion': true,
        'variant': {
          'variantType': 'Color',
          'variantDesc': 'Sienna Ever After'
        },
        'ingredients': 'Active: Titanium Dioxide, Zinc Oxide. Inactive: Mica, Zinc Stearate, Octyldodecyl Stearoyl Stearate, Dimethicone, Boron Nitride, Vinyl Dimethicone/Methicone Silsesquioxane Crosspolymer, Magnesium Silicate, Lauroyl Lysine, Triethylhexanoin, Salix Alba (Willow) Bark Extract, Perilla Ocymoides Seed Oil, Lysolecithin, Glycerin, Tetrahexyldecyl Ascorbate, Tocopheryl Acetate, Calcium Aluminum Borosilicate, Silica, Glyceryl Caprylate, Potassium Sorbate, Sodium Dehydroacetate. May Contain: Iron Oxides, Titanium Dioxide.',
        'onSale': true,
        'id': '2260978',
        'couponRestriction': null,
        'shippingRestriction': 'Shipping Restrictions : This item cannot be shipped via air.',
        'isCouponEligible': true,
        'listPrice': {
          'price': 8.99,
          'currencyCode': 'USD'
        }
      }
    }
    let state2 = {
      productDetails: {
        sku : skuData,
        swatches:{
          items:[
            {
              skuId:'2260978'
            },
            {
              skuId:'5081178'
            }
          ]
        }
      },
      combinedAltImages:[{
        'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
        'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$'
      }]
    }
    let res1 = {
      sku: {
        'longDescription': '<b>SHIPS FREE: Purchase bareMinerals foundation and ALWAYS get free shipping on your ENTIRE ORDER! No Minimum</b><br>(Purchase Original, Matte, Ready, or BareSkin Foundation, and you automatically get Free Shipping on your Entire Order)<br><br>bareMinerals Original Foundation is the #1 U.S. Prestige Loose Powder Foundation*<br><br>*Source: The NPD Group, Inc. / U.S. Prestige Beauty Total Department Specialty, Dollar & Unit Sales, Annual 2016<br><br>With just five pure ingredients, bareMinerals SPF 15 Foundation delivers flawless coverage and the creamy minerals are clinically proven to improve the appearance of skin over time. It looks like a powder, feels like a cream, and buffs on like silk, giving skin a natural luminosity while feeling as if you are not wearing any makeup at all.<br><br>Benefits:<ul><li>Clinically proven to promote clearer, healthier-looking skin.<li>Provides buildable, complete coverage.<li>Free of preservatives, talc, oil, waxes, fragrances, and other chemicals that can irritate skin and cause breakouts.<li>Free of parabens, sulfates, and phthalates.<li>Pure enough to sleep in, made with 5 mineral ingredients. Non-acnegenic, hypoallergenic, non-comedogenic. Formulated without binders, fillers or synthetic chemicals.</li></ul><br><a href=\'http://ulta.com/shade-finders/bareminerals-original-foundation-finder/\'target=\'_blank\'>Click here to find your perfect bareMinerals Original shade!</a><br><br><iframe width=\'420\' height=\'315\' src=\'https://www.youtube.com/embed/AYDDxtUVFKA?rel=0\' frameborder=\'0\' allowfullscreen></iframe><br><br><iframe width=\'420\' height=\'315\' src=\'https://www.youtube.com/embed/jSfRkOjjf8U\' frameborder=\'0\' allowfullscreen></iframe></li></ul>\r',
        'enableFindStore': true,
        'images': {
          'blowupImage': 'https://images.ulta.com/is/image/Ulta/5081178?$detail$',
          'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
          'largeImage': 'https://images.ulta.com/is/image/Ulta/5081178?$lg$',
          'smallImage': 'https://images.ulta.com/is/image/Ulta/5081178?$sm$',
          'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$',
          'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/5081178?$md$'
        },
        'salePrice': {
          'price': 0,
          'currencyCode': 'USD'
        },
        'displayName': 'ORIGINAL Foundation Broad Spectrum SPF 15',
        'description': 'bareMinerals SPF 15 Foundation',
        'badges': {
          'items': [
            {
              'badgeName': 'fanFavorite_badge',
              'priority': 9,
              'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-fan-fave'
            }
          ]
        },
        'shippingRestricted': false,
        'UOM': 'oz',
        'couponEligible': false,
        'directions': 'Swirl a small amount of bareMinerals Foundation in the lid until it all disappears into the brush. Tap away excess. Buff onto the skin in a circular motion.<br><br>Pair with the Beautiful Finish Brush, which is designed with a skirted silhouette that fits perfectly into the ORIGINAL and MATTE Foundation lids to help capture (and contain) every mineral.',
        'size': '0.28',
        'comingSoon': false,
        'enableAskaQuestion': true,
        'variant': {
          'variantType': 'Color',
          'variantDesc': 'Fair 01 (fairest porcelain skin w/ cool undertones)'
        },
        'ingredients': 'Active: Titanium Dioxide 12.6%, Zinc Oxide 21%. Inactive: Bismuth Oxychloride, Mica, Iron Oxides, Zinc Oxide, Titanium Dioxide.',
        'onSale': false,
        'storeOnly': false,
        'id': '5081179',
        'maxQty': 10,
        'listPrice': {
          'price': 28.5,
          'currencyCode': 'USD'
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpSkuDetails', 'success' ),
      data: res1
    }
    let expectedOutput = {
      combinedAltImages:[{
        'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
        'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$'
      }],
      productDetails: {
        selectedThumbnailIndex: 0,
        ...res1,
        swatches:{
          items:[
            {
              skuId:'2260978'
            },
            {
              skuId:'5081178'
            }
          ]
        }
      },
      showVarientDropDown:false,
      showColorPanel:true,
      showPromotionLoader:true,
      selectedSwatch:{
        skuId:'2260978'
      }
    };
    expect( reducer( state2, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should view all the swatch options on the event PRODUCT_SWATCHES_VIEW_ALL_OPTIONS', ( ) => {

    let state = {
      viewAllOption: false
    }

    let actionCreator = {
      type: PRODUCT_SWATCHES_VIEW_ALL_OPTIONS,
      viewAllOption: false
    }

    let expectedOutput = { viewAllOption: true };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Should display swatches section on the event PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS', () => {

    const actionCreator = {
      type: PRODUCT_SWATCHES_DISPLAY_MORE_OPTIONS,
      display:true
    }
    let state = {
      displayMoreOptions:false
    }
    let expectedOutput = { displayMoreOptions: true };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Should set swatches section max height on event PRODUCT_SWATCHES_MAX_HEIGHT', () => {

    const actionCreator = {
      type: PRODUCT_SWATCHES_MAX_HEIGHT,
      height : '30px'
    }

    let expectedOutput = { swatchesSectionMaxHeight: '30px' };
    let state = {
      swatchesSectionMaxHeight:'10px'
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Should set swatches section width on event PRODUCT_SWATCHES_WIDTH_AND_MARGIN', () => {

    const actionCreator = {
      type: PRODUCT_SWATCHES_WIDTH_AND_MARGIN,
      data:{
        sectionWidth : '3000px',
        cellMargin : '2px'
      }
    }

    let expectedOutput = {
      swatchesSectionWidth: '3000px',
      swatchesCellMargin: '2px'
    };
    let state = {
      swatchesSectionWidth:'1000px'
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should check if createVariantInfo method returns an object with proper message and treatmentType based on variantType', ( ) => {
    const productDetails = {
      sku: {
        enableAskaQuestion: true,
        id: 1,
        variant: {
          variantType: 'Color',
          variantDesc: 'Sienna Ever After'
        }
      }
    }
    const state = {
      variantInfo: {
        message:'',
        treatmentType:'default'
      }
    }
    let expectedOutput = {
      message:{
        defaultMessage: 'Colors',
        id: 'i18n.ProductSwatches.colorVariant'
      },
      treatmentType:'circle'
    }

    expect( createVariantInfo( productDetails ) ).toEqual( expectedOutput );

  } );

  it( 'should check if createVariantInfo method returns treatmentType as circle if variantType is scent', ( ) => {
    const productDetails = {
      sku: {
        enableAskaQuestion: true,
        id: 1,
        variant: {
          variantType: 'Scent',
          variantDesc: 'Sienna Ever After'
        }
      }
    }
    const state = {
      variantInfo: {
        message:'',
        treatmentType:'default'
      }
    }
    let expectedOutput = {
      message:{
        defaultMessage: 'Scents',
        id: 'i18n.ProductSwatches.scentVariant'
      },
      treatmentType:'circle'
    }

    expect( createVariantInfo( productDetails ) ).toEqual( expectedOutput );

  } );

  it( 'Should set swatchesCountPerRow on the event PRODUCT_SWATCHES_COUNT_PER_ROW', () => {

    const actionCreator = {
      type: PRODUCT_SWATCHES_COUNT_PER_ROW,
      count:5
    }
    let state = {
      swatchesCountPerRow:999
    }
    let expectedOutput = { swatchesCountPerRow: 5 };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );


  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' )', ( ) => {
    let res = {
      eligibilityState: 0,
      favoriteId: 'gi60001',
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:true,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null,
          isNotAvailable : false
        },
        sku : {
          id:12,
          favoriteId: 'gi60001'
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 1', ( ) => {
    let res = {
      eligibilityState: 1,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:true,
          isInStoreOnlyProduct:false,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null,
          isNotAvailable : false
        },
        sku : {
          id:12,
          favouriteId: undefined
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 2', ( ) => {
    let res = {
      eligibilityState: 2,
      messages: {
        items:[{
          message:'sign in to see if you are eligible',
          type:'Info'
        }]
      }
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isPlatinumAndUserAnonymous: true,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:'sign in to see if you are eligible',
          comingSoonDate:null,
          inStoreDate:null,
          isNotAvailable : false
        },
        sku : {
          id:12,
          favouriteId: undefined

        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 3', ( ) => {
    let res = {
      eligibilityState: 3,
      messages: {
        items:[{
          message:'you are not eligible to buy the product',
          type:'Info'
        }]
      }
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isPlatinumAndUserIneligible: true,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:'you are not eligible to buy the product',
          comingSoonDate:null,
          inStoreDate:null,
          isNotAvailable : false
        },
        sku : {
          id:12,
          favoriteId: undefined

        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 5', ( ) => {
    let res = {
      eligibilityState: 5,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isOutOfStock:true,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null,
          isNotAvailable: true
        },
        sku : {
          id:12,
          favoriteId: undefined
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 6', ( ) => {
    let res = {
      eligibilityState: 6,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isOutOfStock:false,
          isNotifyMeEligible:true,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null,
          isNotAvailable: true
        },
        sku : {
          id:12,
          favoriteId:undefined
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 7', ( ) => {
    let res = {
      eligibilityState: 7,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: true,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate: null,
          inStoreDate: null,
          isNotAvailable: true
        },
        sku : {
          id:12,
          favoriteId: undefined
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );
  it( 'should execute case getServiceType( \'pdpPurchaseEligibility\', \'success\' ) with eligibilityState 8', ( ) => {
    let res = {
      eligibilityState: 8,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:true,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          emailStockNotifyMessage:null,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null,
          isNotAvailable : false
        },
        sku : {
          id:12,
          favoriteId: undefined
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );
  it( 'should set comingSoonDate when coming soon end date will be passed from purchaseEligibility sevice', ( ) => {
    let res = {
      eligibilityState: 1,
      comingSoon : {
        availableDate : '2021-11-12 00:00:00.000-06:00'
      }
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id: 1,
        purchaseEligibility: {
          availabilityMessage1: null,
          availabilityMessage2: null,
          emailStockNotifyMessage: null,
          isAddToCartEligible: false,
          isComingSoonProduct: true,
          isInStoreOnlyProduct: false,
          isNotifyMeEligible: false,
          isNotifyMeSignUp: false,
          isOutOfStock : false,
          comingSoonDate:'Nov 12',
          inStoreDate:null,
          isPlatinumAndUserAnonymous: false,
          isPlatinumAndUserIneligible: false,
          platinumEligibilityMessage:null,
          isNotAvailable: false
        },
        sku: {
          id: 12,
          favoriteId: undefined
        }
      }
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );
  it( 'should set inStoreDate,enableFindStore when in store date and enabled property is be passed from purchaseEligibility sevice', ( ) => {
    let res = {
      eligibilityState: 0,
      findInStore : {
        enabled : false,
        availableDate : '2021-11-12 00:00:00.000-06:00'
      },
      comingSoon: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id: 1,
        purchaseEligibility: {
          availabilityMessage1: null,
          availabilityMessage2: null,
          emailStockNotifyMessage: null,
          isAddToCartEligible: true,
          isComingSoonProduct: false,
          isInStoreOnlyProduct: false,
          isNotifyMeEligible: false,
          isNotifyMeSignUp: false,
          isOutOfStock : false,
          inStoreDate:'Nov 12',
          isPlatinumAndUserAnonymous: false,
          isPlatinumAndUserIneligible: false,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          isNotAvailable: false
        },
        sku: {
          id: 12,
          enableFindStore:false
        }
      }
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );
  it( 'should set enableFindStore to true if enabled property from purchaseEligibility sevice is true', ( ) => {
    let res = {
      eligibilityState: 0,
      findInStore : {
        enabled : true,
        availableDate : '2021-11-12 00:00:00.000-06:00'
      },
      comingSoon: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id: 1,
        purchaseEligibility: {
          availabilityMessage1: null,
          availabilityMessage2: null,
          emailStockNotifyMessage: null,
          isAddToCartEligible: true,
          isComingSoonProduct: false,
          isInStoreOnlyProduct: false,
          isNotifyMeEligible: false,
          isNotifyMeSignUp: false,
          isOutOfStock : false,
          inStoreDate:'Nov 12',
          isPlatinumAndUserAnonymous: false,
          isPlatinumAndUserIneligible: false,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          isNotAvailable: false
        },
        sku: {
          id: 12,
          enableFindStore:true
        }
      }
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );
  it( 'should show emailStockNotify message ', ( ) => {
    let res = {
      eligibilityState: 7,
      messages:{
        items:[{
          message:'Hello again! You\'re already signed up to receive an email from us when this item is back in stock.'
        }
        ]
      }
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id: 1,
        purchaseEligibility: {
          availabilityMessage1: null,
          availabilityMessage2: null,
          emailStockNotifyMessage: 'Hello again! You\'re already signed up to receive an email from us when this item is back in stock.',
          isAddToCartEligible: false,
          isComingSoonProduct: false,
          isInStoreOnlyProduct: false,
          isNotifyMeEligible: false,
          isNotifyMeSignUp: true,
          isOutOfStock : false,
          isPlatinumAndUserAnonymous: false,
          isPlatinumAndUserIneligible: false,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null,
          isNotAvailable: true
        },
        sku: {
          id: 12
        }
      }
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should show currently out of stock message ', ( ) => {
    let res = {
      eligibilityState: 8,
      messages:{
        items:[{
          message:'We\'re currently out of stock of this item'
        }
        ]
      }
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id: 1,
        purchaseEligibility: {
          availabilityMessage1: 'We\'re currently out of stock of this item',
          availabilityMessage2: null,
          emailStockNotifyMessage: null,
          isAddToCartEligible: false,
          isComingSoonProduct: false,
          isInStoreOnlyProduct: true,
          isNotifyMeEligible: false,
          isNotifyMeSignUp: false,
          isOutOfStock : false,
          isPlatinumAndUserAnonymous: false,
          isPlatinumAndUserIneligible: false,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null,
          isNotAvailable: false
        },
        sku: {
          id: 12
        }
      }
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should show availability message when item is currently out of stock', ( ) => {
    let res = {
      eligibilityState: 8,
      messages:{
        items:[{
          message:'We\'re currently out of stock of this item'
        },
        {
          message:'Other colors may be available.'
        }
        ]
      }
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id: 1,
        purchaseEligibility: {
          availabilityMessage1: 'We\'re currently out of stock of this item',
          availabilityMessage2: 'Other colors may be available.',
          emailStockNotifyMessage: null,
          isAddToCartEligible: false,
          isComingSoonProduct: false,
          isInStoreOnlyProduct: true,
          isNotifyMeEligible: false,
          isNotifyMeSignUp: false,
          isOutOfStock : false,
          isPlatinumAndUserAnonymous: false,
          isPlatinumAndUserIneligible: false,
          platinumEligibilityMessage:null,
          comingSoonDate:null,
          inStoreDate:null,
          isNotAvailable: false
        },
        sku: {
          id: 12
        }
      }
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'addItem\', \'success\' )', ( ) => {
    let res = {
      success:true
    }
    let actionCreator = {
      type: getServiceType( 'addItem', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails:{}
    };
    let state = {
      productDetails:{}
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpAddItem\', \'success\' )- return error message', ( ) => {
    let res = {
      success:false,
      responseData:{
        messages:{
          items:[{
            message:'That quantity is currently unavailable. Please choose 5 or less.',
            type:'Error'
          }]
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpAddItem', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails:{},
      isAddToBagModalOpen:false,
      addToBagErrorMessages:{
        items:[{
          message:'That quantity is currently unavailable. Please choose 5 or less.',
          type:'Error'
        }]
      }
    };
    let state = {
      productDetails:{},
      isAddToBagModalOpen:false
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpAddItem\', \'requested\' )- and reset error message', ( ) => {

    let actionCreator = {
      type: getServiceType( 'pdpAddItem', 'requested' )
    }
    let state = {
      productDetails:{},
      isAddToBagModalOpen:false,
      addToBagErrorMessages:{
        items:[{
          message:'That quantity is currently unavailable. Please choose 5 or less.',
          type:'Error'
        }]
      }
    }
    let expectedOutput = {
      productDetails:{},
      isAddToBagModalOpen:false,
      addToBagErrorMessages:null
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpSkuDetails\', \'requested\' )- and reset error message', ( ) => {

    let actionCreator = {
      type: getServiceType( 'pdpSkuDetails', 'requested' )
    }
    let state = {
      productDetails:{},
      isAddToBagModalOpen:false,
      addToBagErrorMessages:{
        items:[{
          message:'That quantity is currently unavailable. Please choose 5 or less.',
          type:'Error'
        }]
      },
      showMainImageLoader:false
    }
    let expectedOutput = {
      productDetails:{},
      isAddToBagModalOpen:false,
      addToBagErrorMessages:null,
      showMainImageLoader:true
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );


  it( 'Should open AddToBagModal on the event PRODUCT_PAGE_MODAL_OPEN', () => {
    let modalID = 'isAddToBagModalOpen';
    const actionCreator = {
      type: PRODUCT_PAGE_MODAL_OPEN,
      modalID
    }
    let state = {
      isAddToBagModalOpen:false
    }
    let expectedOutput = {
      isAddToBagModalOpen:true
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'Should open AddToBagModal on the event PRODUCT_PAGE_MODAL_CLOSE', () => {
    let modalID = 'isAddToBagModalOpen';
    const actionCreator = {
      type: PRODUCT_PAGE_MODAL_CLOSE,
      modalID
    }
    let state = {
      isAddToBagModalOpen:true
    }
    let expectedOutput = {
      isAddToBagModalOpen:false
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'Should set showMainImageLoader flag to false when PRODUCT_MAINIMAGE_LOADER event is triggered', () => {
    const actionCreator = {
      type: PRODUCT_MAINIMAGE_LOADER
    }
    let state = {
      showMainImageLoader:true
    }
    let expectedOutput = {
      showMainImageLoader:false
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );
  it( 'should set selected selectedThumbnailImage with the imageurl of the selected thumbnail image', ( ) => {
    let thumbnailIndex = 2 ;
    const actionCreator = {
      type: PRODUCT_THUMBNAILIMAGE_SELECT,
      thumbnailIndex
    }
    let state = {
      productDetails:{
        product:{},
        sku:{}
      }
    }
    let expectedOutput = {
      productDetails:{
        product:{},
        sku:{},
        selectedThumbnailIndex: 2
      }
    };

    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should check if combineAltImages returns an updated array which returns main image url & thumbnail image Url of  main product , hover state of main product and  altimages', ( ) => {
    const productDetails = {
      sku: {
        enableAskaQuestion: true,
        id: 1,
        images: {
          mainImage:'//mainUrl',
          thumbnailImage: '//url'
        }
      },
      swatches: {
        items : [
          {
            skuId : 1,
            hoverImages : {
              mainImage:'//hover image mainUrl',
              thumbnailImage: '//hover image thumbnailurl'
            }
          },
          {
            skuId : 2,
            hoverImages : {
              mainImage:'//hover image mainUrl',
              thumbnailImage: '//hover image thumbnailurl'
            }
          },
          {
            skuId : 3,
            hoverImages : {
              mainImage:'//hover image mainUrl',
              thumbnailImage: '//hover image thumbnailurl'
            }
          }
        ]
      },
      product: {
        altImages : {
          items: [
            { 'mainImage': 'https://images.ulta.com/is/image/Ulta/142566', 'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/142566?$tn$' }
          ]
        }
      }
    }
    let expectedOutput =
      [{ 'mainImage': '//mainUrl', 'thumbnailImage': '//url' }, {
        mainImage:'//hover image mainUrl',
        thumbnailImage: '//hover image thumbnailurl'
      },
      { 'mainImage': 'https://images.ulta.com/is/image/Ulta/142566', 'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/142566?$tn$' }]

    expect( combineAltImages( productDetails ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'pdpEmailNotification\', \'success\' )', ( ) => {
    let state = {
      productDetails: {
        sku:{}
      }
    }
    let res = {
      success:true,
      messages:{
        items:[{
          message:'Okay! We\'ve got you down to be emailed when this item is back in stock.',
          type:'Info'
        }]
      }
    }
    let actionCreator = {
      type: getServiceType( 'pdpEmailNotification', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        purchaseEligibility:{
          isNotifyMeEligible:false,
          availabilityMessage1:null,
          emailStockNotifyMessage:'Okay! We\'ve got you down to be emailed when this item is back in stock.'
        },
        sku: {}
      }
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  describe( 'load sku dynamic data', ( ) => {
    let state = {
      productDetails: {}
    }
    let res = {
      'dynamicData':{
        'promotions': {
          'items': [
            {
              'displayName': 'Purchase',
              'actionUrl': null,
              'description': 'Buy Together and Save! Palette (2299159) and 6 Single Eyeshadow Refills (40 shades) $40. $85 value',
              'type': 'ZZ',
              'qualifyingSKUs': null,
              'id': '1000013022'
            }
          ]
        },
        'price': {
          'salePrice': null,
          'listPrice': {
            'displayAmount': '$89.00',
            'amount': 79,
            'currencyCode': 'USD'
          }
        }
      }
    }

    let expectedOutput = {
      'productDetails': {
        'sku': {
          'promotionData':{
            'isGiftItem': false,
            'actionUrl': null,
            'gwpPresent': false,
            'promotions': [
              {
                'description': 'Buy Together and Save! Palette (2299159) and 6 Single Eyeshadow Refills (40 shades) $40. $85 value',
                'displayName': 'Purchase',
                'id': '1000013022',
                'type': 'ZZ'
              }
            ]
          },
          showOfferSection:true,
          'price': {
            'salePrice': null,
            'listPrice': {
              'displayAmount': '$89.00',
              'amount': 79,
              'currencyCode': 'USD'
            }
          }
        }
      },
      showPromotionLoader:false
    };
    it( ' should execute case getServiceType( \'pdpSkuDynamicData\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'pdpSkuDynamicData', 'success' ),
        data: res
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( ' should execute case getServiceType( \'pdpSkuDynamicData\', \'success\' ) when promotion is null', ( ) => {
      let res = {
        'dynamicData':{
          'promotions':null,
          'price': {
            'salePrice': null,
            'listPrice': {
              'displayAmount': '$89.00',
              'amount': 79,
              'currencyCode': 'USD'
            }
          }
        }
      }
      let state = {
        productDetails: {}
      }
      let expectedOutput = {
        productDetails: {
          sku:{
            promotionData:null,
            showOfferSection:false,
            price: {
              salePrice: null,
              listPrice: {
                displayAmount: '$89.00',
                amount: 79,
                currencyCode: 'USD'
              }
            }
          }
        },
        showPromotionLoader:false
      }
      let actionCreator = {
        type: getServiceType( 'pdpSkuDynamicData', 'success' ),
        data: res
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( ' should isGiftItem true if qualifyingSKUs in the response have the same sku id passed in request', ( ) => {
      let res = {
        'dynamicData':{
          'promotions': {
            'items': [
              {
                'description': 'Buy Together and Save! Palette (2299159) and 6 Single Eyeshadow Refills (40 shades) $40. $85 value',
                'type': 'G',
                'actionUrl': 'https://images.ulta.com/is/image/Ulta/2516173',
                'qualifyingSKUs': {
                  'items':[{
                    'id':1,
                    'images':{
                      'smallImage':'https://images.ulta.com/is/image/Ulta/2516173?$sm$'
                    }
                  }]
                },
                'id': '1000013022'
              }
            ]
          },
          'price': {
            'salePrice': null,
            'listPrice': {
              'displayAmount': '$89.00',
              'amount': 79,
              'currencyCode': 'USD'
            }
          }
        },
        'skuId':1,
        'displayGWPEligibleLink': true
      }
      let state = {
        productDetails: {
          sku:{
            id:1
          }
        }
      }
      let expectedOutput = {
        productDetails: {
          sku:{
            'id':1,
            'promotionData': {
              'isGiftItem': true,
              'actionUrl': 'https://images.ulta.com/is/image/Ulta/2516173',
              'gwpPresent': false,
              'promotions': null
            },
            'price': {
              'salePrice': null,
              'listPrice': {
                'displayAmount': '$89.00',
                'amount': 79,
                'currencyCode': 'USD'
              }
            },
            showOfferSection:false
          }
        },
        showPromotionLoader:false
      }
      let actionCreator = {
        type: getServiceType( 'pdpSkuDynamicData', 'success' ),
        data: res
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( ' should execute case getServiceType( \'pdpSkuDynamicData\', \'requested\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'pdpSkuDynamicData', 'requested' )
      }
      const state = {
        showPromotionLoader:false
      }
      const expectedOutput = {
        showPromotionLoader:true
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'find Favorite Details', ( ) => {
    let state = {
      productDetails: {}
    }

    let expectedOutput = {
      'productDetails': {
        'sku': {
          'favoriteId': 'gi60001'
        }
      }
    };
    it( ' should execute case getServiceType( \'findFavorite\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'pdpFindFavorite', 'success' ),
        data: {
          favoriteId: 'gi60001'
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'add Favorite Sku', ( ) => {
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }

    let expectedOutput = {
      productDetails: {
        id:1,
        sku : {
          id:12,
          favoriteId: 'gi60001',
          'addToFavoriteErrorMessages':{
            items:[{
              message:'test message',
              type:'Info'
            }]
          }
        }
      }
    };
    it( ' should execute case getServiceType( \'addFavorite\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'pdpAddFavorite', 'success' ),
        data: {
          favoriteId: 'gi60001',
          messages:{
            items:[{
              message:'test message',
              type:'Info'
            }]
          }
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'remove Favorite Sku', ( ) => {
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }

    let expectedOutput = {
      productDetails: {
        id:1,
        sku : {
          id:12,
          favoriteId: null
        }
      }
    };
    it( ' should execute case getServiceType( \'removeFavorite\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'pdpRemoveFavorite', 'success' ),
        data: {
          favoriteId: null
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'ProductRecommendation', ( ) => {
    let state = {}
    let res = {
      data:{
        recommendations :{}
      }
    }
    let expectedOutput = {
      recommendedProducts: {}
    };
    it( ' should execute case getServiceType( \'pdpProductRecs\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'pdpProductRecs', 'success' ),
        data: res
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );
  describe( 'ALERT_WINDOW_RESIZE', () => {
    let screenHeight = 400;

    let actionCreator = {
      type: ALERT_WINDOW_RESIZE,
      screenHeight
    }

    it( 'should handle the event and set the \'resizeEventOccurrence\' attribute', () => {
      let expectedOutput = {
        resizeEventOccurrence: 1
      };
      expect( reducer( { resizeEventOccurrence: 0 }, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );
  describe( 'PRODUCT_POWERREVIEW_READY_FLAG', ( ) => {
    let state = {
      productDetails: {
        id:1,
        reviewNum:1,
        sku : {
          id:12
        }
      }
    };
    let expectedOutput = {
      'powerReviewsScriptLoaded': true,
      'productDetails': {
        'displayReviews': true, 'id': 1, 'reviewNum': 1, 'sku': { 'id': 12 }
      }
    };
    it( ' should execute case PRODUCT_POWERREVIEW_READY_FLAG ', ( ) => {
      let actionCreator = {
        type: PRODUCT_POWERREVIEW_READY_FLAG
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( ' should set displayReviews as true if questionCount is > 0 and review count is 0 ', ( ) => {
      let state = {
        productDetails: {
          id:1,
          reviewNum:0,
          questionCount:1,
          sku : {
            id:12
          }
        }
      };
      let actionCreator = {
        type: PRODUCT_POWERREVIEW_READY_FLAG
      }
      let expectedOutput = {
        'powerReviewsScriptLoaded': true,
        'productDetails': {
          'displayReviews': true,
          'id': 1,
          'reviewNum': 0,
          'questionCount':1,
          'sku': { 'id': 12 }
        }
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

    it( ' should set displayReviews as false if questionCount and review count is 0 ', ( ) => {
      let state = {
        productDetails: {
          id:1,
          reviewNum:0,
          questionCount:0,
          sku : {
            id:12
          }
        }
      };
      let actionCreator = {
        type: PRODUCT_POWERREVIEW_READY_FLAG
      }
      let expectedOutput = {
        'powerReviewsScriptLoaded': true,
        'productDetails': {
          'displayReviews': false,
          'id': 1,
          'reviewNum': 0,
          'questionCount':0,
          'sku':{ 'id': 12 }
        }
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'tests for getBreadCrumbLinks', ( ) => {
    let breadCrumbLinks = [];
    let productDetails = {
      product:{
        displayName:'Online Only TexasLash Mascara',
        categoryPath:{
          items:[
            {
              actionUrl:'/category',
              dataNavDescription:`bc - category`,
              name:'category'
            }
          ]
        }
      }
    }
    const categoryPath = productDetails.product.categoryPath;
    const homeLink = {
      url:'/',
      dataNavDescription:'bc - home',
      name:'home',
      format:true
    }
    let omnitureAttribute = undefined;
    let categoryLink = undefined;
    it( 'if there are no updated items in the incoming data should return updated items in state', ( ) => {
      let expectedOutput = [
        {
          dataNavDescription: 'bc - home',
          format: true,
          name: 'home',
          url:'/'
        },
        {
          name:'category',
          dataNavDescription:`bc - category`,
          url:'/category'
        },
        {
          name:productDetails.product.displayName
        }
      ]
      expect( getBreadCrumbLinks( productDetails ) ).toEqual( expectedOutput );
    } )

  } );
  describe( 'tests for getBreadCrumbForPowerReview', ( ) => {

    let productDetails = {
      product:{
        displayName:'Online Only TexasLash Mascara',
        categoryPath:{
          items:[
            {
              name : 'Nails'
            },
            {
              name : 'Nail Care'
            }
          ]
        }
      }
    }
    it( 'should return the PowerReviews-formatted category hierarchy of the product', ( ) => {
      let expectedOutput = 'Home>Nails>Nail Care>Online Only TexasLash Mascara';
      expect( getBreadCrumbForPowerReview( productDetails ) ).toEqual( expectedOutput );
    } )


    it( 'should not return the PowerReviews-formatted category hierarchy of the product if there is no product data', ( ) => {
      let res = {
        sku:{
          id:1,
          images:{
            mainImage:'//mainUrl',
            thumbnailImage:'//url'
          },
          enableAskaQuestion: true
        },
        reviewSummary: {
          rating: 5,
          reviewCount: 1,
          questionCount: 1
        },
        isProductUnavailable:true
      }
      let actionCreator = {
        type: getServiceType( 'pdpProductDetails', 'success' ),
        data: res
      }
      let expectedOutput = {
        isProductUnavailable: true,
        isValidProduct: false,
        showVarientDropDown:false,
        productDetails: {
          displayAskLink: false,
          displayFavoritesButton: true,
          displayQAs: true,
          displayQaSection: true,
          enablePrAskQuestion: true,
          variantInfo: {
            message:'',
            treatmentType:'default'
          },
          isProductUnavailable: true,
          ratingNum: 5,
          reviewNum: 1,
          questionCount:1,
          reviewSummary: {
            questionCount: 1,
            rating: 5,
            reviewCount: 1
          },
          selectedThumbnailIndex: 0,
          sku: {
            enableAskaQuestion: true,
            id: 1,
            images: {
              mainImage:'//mainUrl',
              thumbnailImage: '//url'
            }
          }
        },
        combinedAltImages:[{
          mainImage:'//mainUrl',
          thumbnailImage:'//url'
        }]
      };

      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );
  } );

  describe( 'tests for displayFavoritesButton', ( ) => {

    it( 'should set the displayFavoritesButton to false if it is a GWP item', ( ) => {
      let res = {
        product: {
          maxQty: 3,
          displayName:'Online Only TexasLash Mascara',
          live: false,
          gwp: true,
          'altImages': {
            'items': []
          }
        },
        sku:{
          id:1,
          images:{
            mainImage:'//mainUrl',
            thumbnailImage:'//url'
          },
          enableAskaQuestion: true
        },
        reviewSummary: {
          rating: 5,
          reviewCount: 1,
          questionCount: 1
        },
        isProductUnavailable:true
      }
      let actionCreator = {
        type: getServiceType( 'pdpProductDetails', 'success' ),
        data: res
      }
      let expectedOutput = {
        isValidProduct: false,
        showVarientDropDown:false,
        productDetails: {
          selectedThumbnailIndex: 0,
          product: {
            maxQty: 3,
            displayName:'Online Only TexasLash Mascara',
            live:false,
            gwp: true,
            'altImages': {
              'items': []
            }
          },
          sku:{
            id:1,
            images:{
              mainImage:'//mainUrl',
              thumbnailImage:'//url'
            },
            enableAskaQuestion: true
          },
          reviewSummary: {
            rating: 5,
            reviewCount: 1,
            questionCount: 1
          },
          ratingNum: 5,
          reviewNum: 1,
          questionCount:1,
          displayQaSection: true,
          displayQAs: true,
          displayAskLink: false,
          displayFavoritesButton: false,
          isProductUnavailable: true,
          breadCrumbNames: 'Home>Online Only TexasLash Mascara',
          enablePrAskQuestion : true,
          variantInfo: {
            message:'',
            treatmentType:'default'
          }

        },
        breadCrumbLinks:  [{
          dataNavDescription: 'bc - home',
          format: true,
          name: 'home',
          url: '/'
        },
        {
          name:'Online Only TexasLash Mascara'
        }
        ],
        isProductUnavailable: true,
        combinedAltImages:[{
          'mainImage': '//mainUrl',
          'thumbnailImage': '//url'
        }]
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( 'should set the displayFavoritesButton to true if it is not a GWP item', ( ) => {
      let res = {
        product: {
          maxQty: 3,
          displayName:'Online Only TexasLash Mascara',
          live: false,
          gwp: false,
          'altImages': {
            'items': []
          }
        },
        sku:{
          id:1,
          images:{
            mainImage:'//mainUrl',
            thumbnailImage:'//url'
          },
          enableAskaQuestion: true
        },
        reviewSummary: {
          rating: 5,
          reviewCount: 1,
          questionCount: 1
        },
        isProductUnavailable:true
      }
      let actionCreator = {
        type: getServiceType( 'pdpProductDetails', 'success' ),
        data: res
      }
      let expectedOutput = {
        isValidProduct: false,
        showVarientDropDown:false,
        productDetails: {
          selectedThumbnailIndex: 0,
          product: {
            maxQty: 3,
            displayName:'Online Only TexasLash Mascara',
            live:false,
            gwp: false,
            'altImages': {
              'items': []
            }
          },
          sku:{
            id:1,
            images:{
              mainImage:'//mainUrl',
              thumbnailImage:'//url'
            },
            enableAskaQuestion: true
          },
          reviewSummary: {
            rating: 5,
            reviewCount: 1,
            questionCount: 1
          },
          ratingNum: 5,
          reviewNum: 1,
          questionCount:1,
          displayQaSection: true,
          displayQAs: true,
          displayAskLink: false,
          displayFavoritesButton: true,
          isProductUnavailable: true,
          breadCrumbNames: 'Home>Online Only TexasLash Mascara',
          enablePrAskQuestion : true,
          variantInfo: {
            message:'',
            treatmentType:'default'
          }

        },
        breadCrumbLinks:  [{
          dataNavDescription: 'bc - home',
          format: true,
          name: 'home',
          url: '/'
        },
        {
          name:'Online Only TexasLash Mascara'
        }
        ],
        isProductUnavailable: true,
        combinedAltImages:[{
          'mainImage': '//mainUrl',
          'thumbnailImage': '//url'
        }]
      };
      expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'test cases for getNextStateOnProductSuccess', () =>{
    it( 'should return prWriteUrl and prAskUrl if product.live is true ', ( ) => {
      const data = {
        product:{
          live:true,
          id:'xlsImpprod12421349'
        }
      }
      const expectedOutput = {
        productDetails: {
          product: { live: true, id: 'xlsImpprod12421349' },
          selectedThumbnailIndex: 0,
          reviewNum: 0,
          ratingNum: 0,
          questionCount: 0,
          displayQaSection: undefined,
          displayQAs: false,
          displayAskLink: undefined,
          breadCrumbNames: 'Home>undefined',
          enablePrAskQuestion: undefined,
          variantInfo: { message: '', treatmentType: 'default' },
          displayFavoritesButton: true
        },
        showVarientDropDown:false,
        isValidProduct: true,
        isProductUnavailable: false,
        breadCrumbLinks:[
          {
            url: '/',
            dataNavDescription: 'bc - home',
            name: 'home',
            format: true
          },
          { name: undefined }
        ],
        combinedAltImages: [],
        prWriteUrl: 'www.ulta.com/ulta/review/?pr_page_id=xlsImpprod12421349&pr_source=web',
        prAskUrl: 'www.ulta.com/ulta/review/?pr_page_id=xlsImpprod12421349&pr_source=web&appName=askQuestion'
      }
      expect( getNextStateOnProductSuccess( data ) ).toEqual( expectedOutput );
    } );

    it( 'should not return prWriteUrl and prAskUrl if product.live is false ', ( ) => {
      const data = {
        product:{
          live:false,
          id:'xlsImpprod12421349'
        }
      }
      const expectedOutput = {
        productDetails: {
          product: { live: false, id: 'xlsImpprod12421349' },
          selectedThumbnailIndex: 0,
          reviewNum: 0,
          ratingNum: 0,
          questionCount: 0,
          displayQaSection: undefined,
          displayQAs: false,
          displayAskLink: undefined,
          breadCrumbNames: 'Home>undefined',
          enablePrAskQuestion: undefined,
          variantInfo: { message: '', treatmentType: 'default' },
          displayFavoritesButton: true
        },
        showVarientDropDown:false,
        isValidProduct: false,
        isProductUnavailable: true,
        breadCrumbLinks:[
          {
            url: '/',
            dataNavDescription: 'bc - home',
            name: 'home',
            format: true
          },
          { name: undefined }
        ],
        combinedAltImages: []
      }
      expect( getNextStateOnProductSuccess( data ) ).toEqual( expectedOutput );
    } );

    it( 'should set showVarientDropDown flag to true is product have more than 2 swatches and variant type is either circle or scent ', ( ) => {
      const data = {
        sku:{
          variant:{
            variantType:'Color'
          }
        },
        swatches:{
          'items': [
            {
              'variantDesc': 'Always Blazing',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
              'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
              'isInStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
              'skuId': '2260982'
            },
            {
              'variantDesc': 'Committed Coral',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260981?$sm$',
              'altImageText': 'Maybelline Superstay Lipcolor Committed Coral',
              'isInStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260981?$md$',
              'skuId': '2260981'
            },
            {
              'variantDesc': 'Always Blazing',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
              'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
              'isInStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
              'skuId': '2260983'
            }
          ]
        }
      }
      const expectedOutput = {
        combinedAltImages:  [],
        isProductUnavailable: false,
        isValidProduct: false,
        productDetails:  {
          displayAskLink: undefined,
          displayFavoritesButton: true,
          displayQAs: false,
          displayQaSection: undefined,
          enablePrAskQuestion: undefined,
          ratingNum: 0,
          reviewNum: 0,
          questionCount: 0,
          selectedThumbnailIndex: 0,
          sku:  {
            variant:  {
              variantType: 'Color'
            }
          },
          swatches:  {
            items:  [
              {
                'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
                'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
                'isInStock': true,
                'skuId': '2260982',
                'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
                'variantDesc': 'Always Blazing'
              },
              {
                'altImageText': 'Maybelline Superstay Lipcolor Committed Coral',
                'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260981?$md$',
                'isInStock': true,
                'skuId': '2260981',
                'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260981?$sm$',
                'variantDesc': 'Committed Coral'
              },
              {
                'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
                'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
                'isInStock': true,
                'skuId': '2260983',
                'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
                'variantDesc': 'Always Blazing'
              }
            ]
          },
          'variantInfo':  {
            'message':  {
              'defaultMessage': 'Colors',
              'id': 'i18n.ProductSwatches.colorVariant'
            },
            'treatmentType': 'circle'
          }
        },
        'showVarientDropDown': true,
        showColorPanel:false,
        selectedSwatch:{
          'variantDesc': 'Always Blazing',
          'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
          'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
          'isInStock': true,
          'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
          'skuId': '2260982'
        }
      }
      expect( getNextStateOnProductSuccess( data ) ).toEqual( expectedOutput );
    } );

    it( 'should set first item in the swatches if there is no default sku selected (sku.id is not present in swatches.items.skuId) ', ( ) => {
      const data = {
        sku:{
          id:'1',
          variant:{
            variantType:'Color'
          }
        },
        swatches:{
          'items': [
            {
              'variantDesc': 'Always Blazing',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
              'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
              'isInStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
              'skuId': '2260982'
            },
            {
              'variantDesc': 'Committed Coral',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260981?$sm$',
              'altImageText': 'Maybelline Superstay Lipcolor Committed Coral',
              'isInStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260981?$md$',
              'skuId': '2260981'
            },
            {
              'variantDesc': 'Always Blazing',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
              'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
              'isInStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
              'skuId': '2260983'
            }
          ]
        }
      }
      const expectedOutput = {
        combinedAltImages:  [],
        isProductUnavailable: false,
        isValidProduct: false,
        productDetails:  {
          displayAskLink: undefined,
          displayFavoritesButton: true,
          displayQAs: false,
          displayQaSection: undefined,
          enablePrAskQuestion: undefined,
          ratingNum: 0,
          reviewNum: 0,
          questionCount: 0,
          selectedThumbnailIndex: 0,
          sku:  {
            id:'1',
            variant:  {
              variantType: 'Color'
            }
          },
          swatches:  {
            items:  [
              {
                'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
                'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
                'isInStock': true,
                'skuId': '2260982',
                'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
                'variantDesc': 'Always Blazing'
              },
              {
                'altImageText': 'Maybelline Superstay Lipcolor Committed Coral',
                'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260981?$md$',
                'isInStock': true,
                'skuId': '2260981',
                'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260981?$sm$',
                'variantDesc': 'Committed Coral'
              },
              {
                'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
                'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
                'isInStock': true,
                'skuId': '2260983',
                'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
                'variantDesc': 'Always Blazing'
              }
            ]
          },
          'variantInfo':  {
            'message':  {
              'defaultMessage': 'Colors',
              'id': 'i18n.ProductSwatches.colorVariant'
            },
            'treatmentType': 'circle'
          }
        },
        'showVarientDropDown': true,
        showColorPanel:false,
        selectedSwatch:{
          'variantDesc': 'Always Blazing',
          'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
          'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
          'isInStock': true,
          'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
          'skuId': '2260982'
        }
      }
      expect( getNextStateOnProductSuccess( data ) ).toEqual( expectedOutput );
    } );

    it( 'should set showColorPanel flag to true if product have less than 3 swatches ', ( ) => {
      const data = {
        sku:{
          variant:{
            variantType:'Color'
          }
        },
        swatches:{
          'items': [
            {
              'variantDesc': 'Always Blazing',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
              'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
              'isInStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
              'skuId': '2260982'
            },
            {
              'variantDesc': 'Committed Coral',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260981?$sm$',
              'altImageText': 'Maybelline Superstay Lipcolor Committed Coral',
              'isInStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260981?$md$',
              'skuId': '2260981'
            }
          ]
        }
      }
      const expectedOutput = {
        combinedAltImages:  [],
        isProductUnavailable: false,
        isValidProduct: false,
        productDetails:  {
          displayAskLink: undefined,
          displayFavoritesButton: true,
          displayQAs: false,
          displayQaSection: undefined,
          enablePrAskQuestion: undefined,
          ratingNum: 0,
          reviewNum: 0,
          questionCount: 0,
          selectedThumbnailIndex: 0,
          sku:  {
            variant:  {
              variantType: 'Color'
            }
          },
          swatches:  {
            items:  [
              {
                'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
                'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
                'isInStock': true,
                'skuId': '2260982',
                'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
                'variantDesc': 'Always Blazing'
              },
              {
                'altImageText': 'Maybelline Superstay Lipcolor Committed Coral',
                'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260981?$md$',
                'isInStock': true,
                'skuId': '2260981',
                'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260981?$sm$',
                'variantDesc': 'Committed Coral'
              }
            ]
          },
          'variantInfo':  {
            'message':  {
              'defaultMessage': 'Colors',
              'id': 'i18n.ProductSwatches.colorVariant'
            },
            'treatmentType': 'circle'
          }
        },
        'showVarientDropDown': false,
        showColorPanel:true,
        selectedSwatch:{
          'variantDesc': 'Always Blazing',
          'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
          'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
          'isInStock': true,
          'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
          'skuId': '2260982'
        }
      }
      expect( getNextStateOnProductSuccess( data ) ).toEqual( expectedOutput );
    } );

    it( 'should set swatch details of the selected sku in selectedSwatch', ( ) => {
      const data = {
        sku:{
          id:'2260982',
          variant:{
            variantType:'Color'
          }
        },
        swatches:{
          'items': [
            {
              'variantDesc': 'Always Blazing',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
              'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
              'isInStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
              'skuId': '2260982'
            },
            {
              'variantDesc': 'Committed Coral',
              'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260981?$sm$',
              'altImageText': 'Maybelline Superstay Lipcolor Committed Coral',
              'isInStock': true,
              'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260981?$md$',
              'skuId': '2260981'
            }
          ]
        }
      }
      const expectedOutput = {
        combinedAltImages:  [],
        isProductUnavailable: false,
        isValidProduct: false,
        productDetails:  {
          displayAskLink: undefined,
          displayFavoritesButton: true,
          displayQAs: false,
          displayQaSection: undefined,
          enablePrAskQuestion: undefined,
          ratingNum: 0,
          reviewNum: 0,
          questionCount: 0,
          selectedThumbnailIndex: 0,
          sku:  {
            variant:  {
              variantType: 'Color'
            },
            id:'2260982'
          },
          swatches:  {
            items:  [
              {
                'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
                'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
                'isInStock': true,
                'skuId': '2260982',
                'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
                'variantDesc': 'Always Blazing'
              },
              {
                'altImageText': 'Maybelline Superstay Lipcolor Committed Coral',
                'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260981?$md$',
                'isInStock': true,
                'skuId': '2260981',
                'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260981?$sm$',
                'variantDesc': 'Committed Coral'
              }
            ]
          },
          'variantInfo':  {
            'message':  {
              'defaultMessage': 'Colors',
              'id': 'i18n.ProductSwatches.colorVariant'
            },
            'treatmentType': 'circle'
          }
        },
        'showVarientDropDown': false,
        showColorPanel:true,
        selectedSwatch:{
          'altImageText': 'Maybelline Superstay Lipcolor Always Blazing',
          'hoverImage': 'https://images.ulta.com/is/image/Ulta/2260982?$md$',
          'isInStock': true,
          'skuId': '2260982',
          'skuImageURL': 'https://images.ulta.com/is/image/Ulta/2260982?$sm$',
          'variantDesc': 'Always Blazing'
        }
      }
      expect( getNextStateOnProductSuccess( data ) ).toEqual( expectedOutput );
    } );
  } )
} );
