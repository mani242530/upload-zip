/**
 * Quick Shop Modal Redux reducer Module
 *
 */
import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  CLOSE_QUICK_SHOP_MODAL,
  PRODUCT_SWATCHES_MAX_HEIGHT
} from '../../../events/quick_shop/quick_shop.events';

import {
  setEligibilityDetails,
  getpromotionDetails,
  getNextStateOnProductSuccess,
  getNextStateOnSkuSuccess
} from '../product_page/product_page.model';

/**
 * default state for the AddToBag reducer
 */

export const initialState = {
  isQuickShopModalOpen:false,
  productDetails:null,
  swatchesSectionMaxHeight:'150px',
  isValidProduct:undefined,
  productErrorMessages:undefined,
  addToBagErrorMessages:null
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){
  switch ( action.type ){


    case getServiceType( 'qsProductDetails', 'success' ):
      return {
        ...state,
        ...getNextStateOnProductSuccess( action.data ),
        isQuickShopModalOpen:true
      }

    case getServiceType( 'qsAddItem', 'success' ):
      return {
        ...state,
        isQuickShopModalOpen:!action.data.responseData.success,
        ...( action.data.responseData.messages && { addToBagErrorMessages:action.data.responseData.messages } )
      }

    case getServiceType( 'qsSkuDetails', 'requested' ):
    case getServiceType( 'qsAddItem', 'requested' ):
      return {
        ...state,
        addToBagErrorMessages:null
      }

    case getServiceType( 'qsSkuDetails', 'success' ):
      return {
        ...state,
        ...getNextStateOnSkuSuccess( state, action.data )
      }

    case getServiceType( 'qsPurchaseEligibility', 'success' ):
      return {
        ...state,
        productDetails: {
          ...state.productDetails,
          purchaseEligibility: {
            ...setEligibilityDetails( action.data ),
            isNotifyMeEligible:false
          }
        }
      }
    case getServiceType( 'qsSkuDynamicData', 'success' ):
      return {
        ...state,
        productDetails: {
          ...state.productDetails,
          sku: {
            ...state.productDetails.sku,
            ...getpromotionDetails( action.data, 'quickShop' )
          }
        }
      }
    case getServiceType( 'qsFindFavorite', 'success' ):
      return {
        ...state,
        productDetails:{
          ...state.productDetails,
          sku: {
            ...state.productDetails.sku,
            favoriteId: action.data.favoriteId
          }
        }
      }
    case getServiceType( 'qsAddFavorite', 'success' ):
      return {
        ...state,
        productDetails:{
          ...state.productDetails,
          sku: {
            ...state.productDetails.sku,
            favoriteId: action.data.favoriteId,
            addToFavoriteErrorMessages:action.data.messages
          }
        }
      }
    case getServiceType( 'qsRemoveFavorite', 'success' ):
      return {
        ...state,
        productDetails:{
          ...state.productDetails,
          sku: {
            ...state.productDetails.sku,
            favoriteId: null
          }
        }
      }

    case CLOSE_QUICK_SHOP_MODAL:
      return {
        ...state,
        isQuickShopModalOpen:false
      }

    case PRODUCT_SWATCHES_MAX_HEIGHT:
      return {
        ...state,
        swatchesSectionMaxHeight: action.height
      }

    default:
      return state;
  }
}

export const getQuickShopProductDetailsState = state => state.quickShop.productDetails;
