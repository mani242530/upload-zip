/**
 * Test for QuickShop Reducer
 */
import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';

import _ from 'lodash';

import {
  CLOSE_QUICK_SHOP_MODAL,
  PRODUCT_SWATCHES_MAX_HEIGHT
} from '../../../events/quick_shop/quick_shop.events';
import reducer, {
  initialState
} from './quick_shop.model';


describe( 'Quickshop Page reducer', ( ) => {
  registerServiceName( 'qsProductDetails' );
  registerServiceName( 'qsAddItem' );
  registerServiceName( 'qsSkuDetails' );
  registerServiceName( 'qsPurchaseEligibility' );
  registerServiceName( 'qsSkuDynamicData' );
  registerServiceName( 'qsFindFavorite' );
  registerServiceName( 'qsAddFavorite' );
  registerServiceName( 'qsRemoveFavorite' );

  it( 'should have the proper default state', ( ) => {
    let expectedState = {
      isQuickShopModalOpen:false,
      productDetails:null,
      swatchesSectionMaxHeight:'150px',
      isValidProduct:undefined,
      productErrorMessages:undefined,
      addToBagErrorMessages:null
    }
    expect( initialState ).toEqual( expectedState );
  } )

  it( 'should be a function', ( ) => {
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  it( 'should execute case getServiceType( \'qsProductDetails\', \'success\' )', ( ) => {
    let res = {
      product: {
        live: true,
        maxQty: 3,
        displayName:'lipstick'
      },
      sku:{
        id:1,
        images:{
          mainImage:'//mainUrl',
          thumbnailImage:'//url'
        },
        enableAskaQuestion: true
      },
      reviewSummary: {
        rating: 5,
        reviewCount: 1,
        questionCount: 1
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsProductDetails', 'success' ),
      data: res
    }
    let expectedOutput = {
      isValidProduct: true,
      showVarientDropDown:false,
      prAskUrl:'//www.ulta.com/ulta/review/?pr_page_id=undefined&pr_source=web&appName=askQuestion',
      prWriteUrl:'//www.ulta.com/ulta/review/?pr_page_id=undefined&pr_source=web',
      isProductUnavailable: false,
      productDetails: {
        product: {
          live: true,
          maxQty: 3,
          displayName:'lipstick'
        },
        sku:{
          id:1,
          images:{
            mainImage:'//mainUrl',
            thumbnailImage:'//url'
          },
          enableAskaQuestion: true
        },
        reviewSummary: {
          rating: 5,
          reviewCount: 1,
          questionCount: 1
        },
        variantInfo:{
          'message': '',
          'treatmentType': 'default'
        },
        ratingNum: 5,
        reviewNum: 1,
        questionCount:1,
        displayAskLink: false,
        displayFavoritesButton: true,
        displayQAs: true,
        displayQaSection: true,
        selectedThumbnailIndex: 0,
        breadCrumbNames: 'Home>lipstick',
        enablePrAskQuestion : true
      },
      breadCrumbLinks:[
        {
          dataNavDescription: 'bc - home',
          format: true,
          name: 'home',
          url: '/'
        },
        {
          name:'lipstick'
        }
      ],
      isQuickShopModalOpen:true,
      combinedAltImages:[{
        mainImage:'//mainUrl',
        thumbnailImage:'//url'
      }]
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsAddItem\', \'success\' )- return error message', ( ) => {
    let res = {
      success:false,
      responseData:{
        messages:{
          items:[{
            message:'That quantity is currently unavailable. Please choose 5 or less.',
            type:'Error'
          }]
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsAddItem', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails:{},
      isQuickShopModalOpen: true,
      addToBagErrorMessages:{
        items:[{
          message:'That quantity is currently unavailable. Please choose 5 or less.',
          type:'Error'
        }]
      }
    };
    let state = {
      productDetails:{},
      isQuickShopModalOpen: true
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsAddItem\', \'requested\' )- and reset error message', ( ) => {

    let actionCreator = {
      type: getServiceType( 'qsAddItem', 'requested' )
    }
    let state = {
      productDetails:{},
      isQuickShopModalOpen: true,
      addToBagErrorMessages:{
        items:[{
          message:'That quantity is currently unavailable. Please choose 5 or less.',
          type:'Error'
        }]
      }
    }
    let expectedOutput = {
      productDetails:{},
      isQuickShopModalOpen: true,
      addToBagErrorMessages:null
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsSkuDetails\', \'requested\' )- and reset error message', ( ) => {

    let actionCreator = {
      type: getServiceType( 'qsSkuDetails', 'requested' )
    }
    let state = {
      productDetails:{},
      isQuickShopModalOpen: true,
      addToBagErrorMessages:{
        items:[{
          message:'That quantity is currently unavailable. Please choose 5 or less.',
          type:'Error'
        }]
      }
    }
    let expectedOutput = {
      productDetails:{},
      isQuickShopModalOpen: true,
      addToBagErrorMessages:null
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsSkuDetails\', \'success\' ) and set showColorPanel to true if variant is present and swatches is null ', ( ) => {
    let skuData = {
      sku: {
        'longDescription': '<br><li>Physicians Formula First ever Beauty Balm Powder form for a smoothing effect that instantly diffuses the appearance of imperfections, evens out skin tone and minimizes the appearance of pores.<br><li>Weightless powder acts as a protective veil from UV damage & moisture loss so skin looks and feels smooth, glowing and naturally flawless.<br><li>Use with the Concealer & Cream for the ultimate, high-performance wear.<br><li>Hypoallergenic. Fragrance-Free. Paraben-Free. Gluten Free. Dermatologist approved. Non-Comedogenic.',
        'enableFindStore': true,
        'images': {
          'thumbnailImage': 'http://images.ulta.com/is/image/Ulta/2260978?$tn$',
          'mainImage': 'http://images.ulta.com/is/image/Ulta/2260978',
          'blowupImage': 'http://images.ulta.com/is/image/Ulta/2260978?$detail$',
          'largeImage': 'http://images.ulta.com/is/image/Ulta/2260978?$lg$',
          'smallImage': 'http://images.ulta.com/is/image/Ulta/2260978?$sm$',
          'mediumImageUrl': 'http://images.ulta.com/is/image/Ulta/2260978?$md$'
        },
        'salePrice': {
          'price': 6.89,
          'currencyCode': 'USD'
        },
        'displayName': 'Superstay Lipcolor',
        'description': 'Physicians Formula First ever Beauty Balm Powder form for a smoothing effect that instantly diffuses the appearance of imperfections, evens out skin tone and minimizes the appearance of pores',
        'badges': {
          'items': [
            {
              'badgeName': 'onSale_badge',
              'priority': 5,
              'badgeImageUrl': 'http://s7d5.scene7.com/is/image/Ulta/badge-sale'
            }
          ]
        },
        'UOM': 'oz',
        'directions': 'Apply liberally 15 minutes before sun exposure. Use water resistant sunscreen if swimming or sweating. Reapply at least every 2 hours. Children under 6 months: Ask a doctor.',
        'size': '0.14',
        'enableAskaQuestion': true,
        'variant': {
          'variantType': 'Color',
          'variantDesc': 'Sienna Ever After'
        },
        'ingredients': 'Active: Titanium Dioxide, Zinc Oxide. Inactive: Mica, Zinc Stearate, Octyldodecyl Stearoyl Stearate, Dimethicone, Boron Nitride, Vinyl Dimethicone/Methicone Silsesquioxane Crosspolymer, Magnesium Silicate, Lauroyl Lysine, Triethylhexanoin, Salix Alba (Willow) Bark Extract, Perilla Ocymoides Seed Oil, Lysolecithin, Glycerin, Tetrahexyldecyl Ascorbate, Tocopheryl Acetate, Calcium Aluminum Borosilicate, Silica, Glyceryl Caprylate, Potassium Sorbate, Sodium Dehydroacetate. May Contain: Iron Oxides, Titanium Dioxide.',
        'onSale': true,
        'id': '2260978',
        'couponRestriction': null,
        'shippingRestriction': 'Shipping Restrictions : This item cannot be shipped via air.',
        'isCouponEligible': true,
        'listPrice': {
          'price': 8.99,
          'currencyCode': 'USD'
        }
      }
    }
    let state2 = {
      productDetails: {
        sku : skuData
      }
    }
    let res1 = {
      sku: {
        'longDescription': '<b>SHIPS FREE: Purchase bareMinerals foundation and ALWAYS get free shipping on your ENTIRE ORDER! No Minimum</b><br>(Purchase Original, Matte, Ready, or BareSkin Foundation, and you automatically get Free Shipping on your Entire Order)<br><br>bareMinerals Original Foundation is the #1 U.S. Prestige Loose Powder Foundation*<br><br>*Source: The NPD Group, Inc. / U.S. Prestige Beauty Total Department Specialty, Dollar & Unit Sales, Annual 2016<br><br>With just five pure ingredients, bareMinerals SPF 15 Foundation delivers flawless coverage and the creamy minerals are clinically proven to improve the appearance of skin over time. It looks like a powder, feels like a cream, and buffs on like silk, giving skin a natural luminosity while feeling as if you are not wearing any makeup at all.<br><br>Benefits:<ul><li>Clinically proven to promote clearer, healthier-looking skin.<li>Provides buildable, complete coverage.<li>Free of preservatives, talc, oil, waxes, fragrances, and other chemicals that can irritate skin and cause breakouts.<li>Free of parabens, sulfates, and phthalates.<li>Pure enough to sleep in, made with 5 mineral ingredients. Non-acnegenic, hypoallergenic, non-comedogenic. Formulated without binders, fillers or synthetic chemicals.</li></ul><br><a href=\'http://ulta.com/shade-finders/bareminerals-original-foundation-finder/\'target=\'_blank\'>Click here to find your perfect bareMinerals Original shade!</a><br><br><iframe width=\'420\' height=\'315\' src=\'https://www.youtube.com/embed/AYDDxtUVFKA?rel=0\' frameborder=\'0\' allowfullscreen></iframe><br><br><iframe width=\'420\' height=\'315\' src=\'https://www.youtube.com/embed/jSfRkOjjf8U\' frameborder=\'0\' allowfullscreen></iframe></li></ul>\r',
        'enableFindStore': true,
        'images': {
          'blowupImage': 'https://images.ulta.com/is/image/Ulta/5081178?$detail$',
          'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
          'largeImage': 'https://images.ulta.com/is/image/Ulta/5081178?$lg$',
          'smallImage': 'https://images.ulta.com/is/image/Ulta/5081178?$sm$',
          'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$',
          'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/5081178?$md$'
        },
        'salePrice': {
          'price': 0,
          'currencyCode': 'USD'
        },
        'displayName': 'ORIGINAL Foundation Broad Spectrum SPF 15',
        'description': 'bareMinerals SPF 15 Foundation',
        'badges': {
          'items': [
            {
              'badgeName': 'fanFavorite_badge',
              'priority': 9,
              'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-fan-fave'
            }
          ]
        },
        'shippingRestricted': false,
        'UOM': 'oz',
        'couponEligible': false,
        'directions': 'Swirl a small amount of bareMinerals Foundation in the lid until it all disappears into the brush. Tap away excess. Buff onto the skin in a circular motion.<br><br>Pair with the Beautiful Finish Brush, which is designed with a skirted silhouette that fits perfectly into the ORIGINAL and MATTE Foundation lids to help capture (and contain) every mineral.',
        'size': '0.28',
        'comingSoon': false,
        'enableAskaQuestion': true,
        'variant': {
          'variantType': 'Color',
          'variantDesc': 'Fair 01 (fairest porcelain skin w/ cool undertones)'
        },
        'ingredients': 'Active: Titanium Dioxide 12.6%, Zinc Oxide 21%. Inactive: Bismuth Oxychloride, Mica, Iron Oxides, Zinc Oxide, Titanium Dioxide.',
        'onSale': false,
        'storeOnly': false,
        'id': '5081178',
        'maxQty': 10,
        'listPrice': {
          'price': 28.5,
          'currencyCode': 'USD'
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsSkuDetails', 'success' ),
      data: res1
    }
    let expectedOutput = {
      productDetails: {
        selectedThumbnailIndex: 0,
        ...res1
      },
      combinedAltImages:[{
        mainImage:'https://images.ulta.com/is/image/Ulta/5081178',
        thumbnailImage:'https://images.ulta.com/is/image/Ulta/5081178?$tn$'
      }
      ],
      showVarientDropDown:false,
      showColorPanel:true
    };
    expect( reducer( state2, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsPurchaseEligibility\', \'success\' )', ( ) => {
    let res = {
      eligibilityState: 0,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:true,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: false,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          comingSoonDate: null,
          emailStockNotifyMessage:null,
          inStoreDate: null,
          platinumEligibilityMessage:null
        },
        sku : {
          id:12
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsPurchaseEligibility\', \'success\' ) with eligibilityState 1', ( ) => {
    let res = {
      eligibilityState: 1,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:true,
          isInStoreOnlyProduct:false,
          isNotAvailable: false,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          comingSoonDate: null,
          emailStockNotifyMessage:null,
          inStoreDate: null,
          platinumEligibilityMessage:null
        },
        sku : {
          id:12
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsPurchaseEligibility\', \'success\' ) with eligibilityState 2', ( ) => {
    let res = {
      eligibilityState: 2,
      messages: {
        items:[{
          message:'sign in to see if you are eligible',
          type:'Info'
        }]
      }
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: false,
          isPlatinumAndUserAnonymous: true,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          comingSoonDate: null,
          emailStockNotifyMessage:null,
          inStoreDate: null,
          platinumEligibilityMessage:'sign in to see if you are eligible'
        },
        sku : {
          id:12
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsPurchaseEligibility\', \'success\' ) with eligibilityState 3', ( ) => {
    let res = {
      eligibilityState: 3,
      messages: {
        items:[{
          message:'you are not eligible to buy the product',
          type:'Info'
        }]
      }
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: false,
          isPlatinumAndUserIneligible: true,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          comingSoonDate: null,
          emailStockNotifyMessage:null,
          inStoreDate: null,
          platinumEligibilityMessage:'you are not eligible to buy the product'
        },
        sku : {
          id:12
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsPurchaseEligibility\', \'success\' ) with eligibilityState 5', ( ) => {
    let res = {
      eligibilityState: 5,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: true,
          isOutOfStock:true,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          comingSoonDate: null,
          emailStockNotifyMessage:null,
          inStoreDate: null,
          platinumEligibilityMessage:null
        },
        sku : {
          id:12
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsPurchaseEligibility\', \'success\' ) with eligibilityState 6', ( ) => {
    let res = {
      eligibilityState: 6,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: true,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          comingSoonDate: null,
          emailStockNotifyMessage:null,
          inStoreDate: null,
          platinumEligibilityMessage:null
        },
        sku : {
          id:12
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsPurchaseEligibility\', \'success\' ) with eligibilityState 7', ( ) => {
    let res = {
      eligibilityState: 7,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:false,
          isNotAvailable: true,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: true,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          comingSoonDate: null,
          emailStockNotifyMessage:null,
          inStoreDate: null,
          platinumEligibilityMessage:null
        },
        sku : {
          id:12
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  it( 'should execute case getServiceType( \'qsPurchaseEligibility\', \'success\' ) with eligibilityState 8', ( ) => {
    let res = {
      eligibilityState: 8,
      messages: null
    }
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }
    let actionCreator = {
      type: getServiceType( 'qsPurchaseEligibility', 'success' ),
      data: res
    }
    let expectedOutput = {
      productDetails: {
        id:1,
        purchaseEligibility: {
          isAddToCartEligible:false,
          isComingSoonProduct:false,
          isInStoreOnlyProduct:true,
          isNotAvailable: false,
          isOutOfStock:false,
          isNotifyMeEligible:false,
          isNotifyMeSignUp: false,
          isPlatinumAndUserAnonymous:false,
          isPlatinumAndUserIneligible:false,
          availabilityMessage1:null,
          availabilityMessage2:null,
          comingSoonDate: null,
          emailStockNotifyMessage:null,
          inStoreDate: null,
          platinumEligibilityMessage:null
        },
        sku : {
          id:12
        }
      }
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

  } );

  describe( 'load sku dynamic data', ( ) => {
    let state = {
      productDetails: {}
    }
    let res = {
      'dynamicData':{
        'promotions': {
          'items': [
            {
              'displayName': 'Purchase',
              'actionUrl': null,
              'description': 'Buy Together and Save! Palette (2299159) and 6 Single Eyeshadow Refills (40 shades) $40. $85 value',
              'type': 'ZZ',
              'qualifyingSKUs': null,
              'id': '1000013022'
            }
          ]
        }
      }
    }

    let expectedOutput = {
      'productDetails': {
        'sku': {
          'promotionData':{
            'isGiftItem': false,
            'actionUrl': null,
            'gwpPresent': false,
            'promotions': [
              {
                'description': 'Buy Together and Save! Palette (2299159) and 6 Single Eyeshadow Refills (40 shades) $40. $85 value',
                'displayName': 'Purchase',
                'id': '1000013022',
                'type': 'ZZ'
              }
            ]
          },
          showOfferSection:true
        }
      }
    };
    it( ' should execute case getServiceType( \'qsSkuDynamicData\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'qsSkuDynamicData', 'success' ),
        data: res
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );
    it( ' should execute case getServiceType( \'qsSkuDynamicData\', \'success\' ) when promotion is null', ( ) => {
      let res = {
        'dynamicData':{
          'promotions':null
        }
      }
      let state = {
        productDetails: {}
      }
      let expectedOutput = {
        productDetails: {
          sku:{
            promotionData:null,
            showOfferSection:false
          }
        }
      }
      let actionCreator = {
        type: getServiceType( 'qsSkuDynamicData', 'success' ),
        data: res
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( ' should isGiftItem true if qualifyingSKUs in the response have the same sku id passed in request', ( ) => {
      let res = {
        'dynamicData':{
          'promotions': {
            'items': [
              {
                'description': 'Buy Together and Save! Palette (2299159) and 6 Single Eyeshadow Refills (40 shades) $40. $85 value',
                'type': 'G',
                'actionUrl': 'https://images.ulta.com/is/image/Ulta/2516173',
                'qualifyingSKUs': {
                  'items':[{
                    'id':1,
                    'images':{
                      'smallImage':'https://images.ulta.com/is/image/Ulta/2516173?$sm$'
                    }
                  }]
                },
                'id': '1000013022'
              }
            ]
          }
        },
        'skuId':1,
        'displayGWPEligibleLink': true
      }
      let state = {
        productDetails: {
          sku:{
            id:1
          }
        }
      }
      let expectedOutput = {
        productDetails: {
          sku:{
            'id':1,
            'promotionData': {
              'isGiftItem': true,
              'actionUrl': 'https://images.ulta.com/is/image/Ulta/2516173',
              'gwpPresent': false,
              'promotions': null
            },
            showOfferSection:false
          }
        }
      }
      let actionCreator = {
        type: getServiceType( 'qsSkuDynamicData', 'success' ),
        data: res
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'find Favorite Details', ( ) => {
    let state = {
      productDetails: {}
    }

    let expectedOutput = {
      'productDetails': {
        'sku': {
          'favoriteId': 'gi60001'
        }
      }
    };
    it( ' should execute case getServiceType( \'qsFindFavorite\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'qsFindFavorite', 'success' ),
        data: {
          favoriteId: 'gi60001'
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'add Favorite Sku', ( ) => {
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }

    let expectedOutput = {
      productDetails: {
        id:1,
        sku : {
          id:12,
          favoriteId: 'gi60001',
          'addToFavoriteErrorMessages':{
            items:[{
              message:'test message',
              type:'Info'
            }]
          }
        }
      }
    };
    it( ' should execute case getServiceType( \'qsAddFavorite\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'qsAddFavorite', 'success' ),
        data: {
          favoriteId: 'gi60001',
          messages:{
            items:[{
              message:'test message',
              type:'Info'
            }]
          }
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'remove Favorite Sku', ( ) => {
    let state = {
      productDetails: {
        id:1,
        sku : {
          id:12
        }
      }
    }

    let expectedOutput = {
      productDetails: {
        id:1,
        sku : {
          id:12,
          favoriteId: null
        }
      }
    };
    it( ' should execute case getServiceType( \'qsRemoveFavorite\', \'success\' ) ', ( ) => {
      let actionCreator = {
        type: getServiceType( 'qsRemoveFavorite', 'success' ),
        data: {
          favoriteId: null
        }
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );

    } );

  } );

  describe( 'Close quick shop modal', ( ) => {
    let state1 = {
      isQuickShopModalOpen: true
    }
    let isQuickShopModalOpen = true;
    let actionCreator = {
      type: CLOSE_QUICK_SHOP_MODAL,
      isQuickShopModalOpen
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        isQuickShopModalOpen: false
      };

      expect( reducer( state1, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  it( 'Should set swatches section max height on event PRODUCT_SWATCHES_MAX_HEIGHT', () => {

    const actionCreator = {
      type: PRODUCT_SWATCHES_MAX_HEIGHT,
      height : '30px'
    }

    let expectedOutput = { swatchesSectionMaxHeight: '30px' };
    let state = {
      swatchesSectionMaxHeight:'10px'
    }
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

} );
