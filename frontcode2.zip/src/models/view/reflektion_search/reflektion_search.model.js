/**
 * Reflektion Searchreducer Module
 *
 */
import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  ALERT_WINDOW_RESIZE
} from 'ulta-fed-core/dist/js/events/global/global.events';
import {
  CHANGE as REDUXFORM_CHANGE,
  FOCUS as REDUXFORM_FOCUS
} from 'redux-form/lib/actionTypes';
import {
  fullyQualifyLink,
  host,
  isIntlSite
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import {
  CLOSE_REFLEKTION_SEARCH_MODEL,
  UPDATE_TOP_RESULT
} from '../../../events/reflektion_search/reflektion_search.events';
import { TOGGLE_MOBILE_SEARCH } from '../../../events/search_menu/search_menu.events';
import { searchBarConfig } from '../../../views/SearchBarInput/SearchBarInput';
/**
 * default state for the ReflektionSearch reducer
 */

export const initialState = {
  isReflektionModelOpen: false,
  visualSearchEnabled: false,
  actionUrl:null,
  suggestionsWithProductList:[],
  showMobileSearch: false,
  typeaheadSearchEnabled: false,
  searchTermValue:'',
  isDeviceMobile: false
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */

export default function reducer( state = initialState, action ){
  return reducerSwitch( state, action )
}

export const reducerSwitch = function( state, action ){

  switch ( action.type ){

    case getServiceType( 'reflektionSearch', 'success' ):
      return {
        ...state,
        suggestionsWithProductList : ( action.data.categories?.items ) ? populateSuggestionListWithProduct( action.data ) : [],
        isReflektionModelOpen: !!action.data.categories?.items,
        actionUrl: action.data.searchTerm && buildActionUrl( action.data.searchTerm ),
        searchTermValue: action.data.searchTerm
      }
    case ALERT_WINDOW_RESIZE:
      let isDeviceMobile = action.screenWidth < 992;
      return {
        ...state,
        isDeviceMobile,
        /**
         * If the modal is shown in as a result of a search and on window resize it should remain open
         * until it switches the device mode. This conditions checks on resize
         * if the device is still in desktop or mobile mode only if it switches between the modes it will close the modal
         * * */
        isReflektionModelOpen: ( ( state.isDeviceMobile && isDeviceMobile ) || !( state.isDeviceMobile && isDeviceMobile ) ) && state.isReflektionModelOpen
      }

    case TOGGLE_MOBILE_SEARCH:
      return {
        ...state,
        // flag control whether reflektion searchbar component render in mobile
        showMobileSearch: !state.showMobileSearch,
        // Reset paramter when popup is reloaded
        suggestionList: null,
        topResultFor: null,
        suggestionsWithProductList: []
      };
    case getServiceType( 'fetchTopResults', 'success' ):
      return {
        ...state,
        suggestionsWithProductList : populateHoverOnSuggestion( action.data, state )
      }
    case UPDATE_TOP_RESULT:
      return {
        ...state,
        suggestionsWithProductList : updateSelectedIndexHoverOnSuggestion( action.suggestionName, state )
      }
    case CLOSE_REFLEKTION_SEARCH_MODEL:
      return {
        ...state,
        isReflektionModelOpen: false,
        searchTermValue:action.data
      };

    case getServiceType( 'switches', 'success' ):
      return {
        ...state,
        visualSearchEnabled: action.data.switches.visualSearchEnabled,
        typeaheadSearchEnabled: !action.data.switches.visualSearchEnabled
      }
    case REDUXFORM_CHANGE:
      return {
        ...state,
        ...( action.meta.form === searchBarConfig.FORMNAME && action.meta.field === searchBarConfig.FIELDNAME && {
          suggestionsWithProductList:( action.payload.length > 0 && action.payload.length < 3 ) ? [] : state.suggestionsWithProductList,
          ...( action.meta.active && { isReflektionModelOpen: !( action.payload.length > 0 && action.payload.length < 3 ) } ),
          actionUrl:buildActionUrl( action.payload ),
          searchTermValue:action.payload
        } )
      }

    case REDUXFORM_FOCUS:
      return {
        ...state,
        ...( action.meta.form === searchBarConfig.FORMNAME && action.meta.field === searchBarConfig.FIELDNAME && state.searchTermValue.length > 2 && { isReflektionModelOpen : true } )
      }

    default:
      return state;
  }
};

// this method will create url when user press enter in search bar field and when user click on suggestion list ( if action url is null )
export const buildActionUrl = ( query )=>{
  // sanitize the search params before constucting the URL
  let formAction = [];
  formAction.push( '/ulta/a/_/Ntt-' );
  formAction.push( encodeURIComponent( query ) );
  formAction.push( '/Nty-1' );
  formAction.push( '?Dy=1&' );
  formAction.push( 'ciSelector=searchResults' );
  return formAction.join( '' )
}

// this function returns the suggestion list corresponding to the search term entered.
// first item in the suggestion list will be the object containing our search term and rest of items are filled with items from typeahead response.
// 'default' and 'selected' attributes of the object indicates whether that item should be displayed or not.
export const populateSuggestionListWithProduct = ( data ) => {
  let suggestionsWithDefaultItem = [];
  suggestionsWithDefaultItem.push( { name: data.searchTerm, default:true, selected :true } );
  suggestionsWithDefaultItem = suggestionsWithDefaultItem.concat( data.categories?.items );
  let actionUrl;
  const suggestionsWithProductList = suggestionsWithDefaultItem?.map( ( value ) => {
  // Checks whether actionUrl is returned from backend service ,if not buildActionUrl will form the actionUrl
    actionUrl = formatActionUrl( value )
    return {
      ...value,
      actionUrl: actionUrl,
      ...( data.searchTerm === value.name && {
        skus: data.skus?.items.map( ( sku ) => {
          return {
            ...sku,
            actionUrl:formatActionUrl( sku )
          }

        } )
      } )
    }
  } );
  return suggestionsWithProductList;
}
// it updates product result of selected suggestionlist item.
// 'selected' attribute is true only when that item is focused
export const populateHoverOnSuggestion = ( data, state ) => {

  let updatedsuggestionsWithHoverResult = [];
  updatedsuggestionsWithHoverResult = state.suggestionsWithProductList?.map( ( value ) => {
    return {
      ...value,
      ...( data.searchTerm !== value.name && { selected: false } ),
      ...( data.searchTerm === value.name && {
        skus: data.skus?.items.map( ( sku ) => {
          return {
            ...sku,
            actionUrl:formatActionUrl( sku )
          }

        } ),
        selected: true
      } )
    }
  } )
  return updatedsuggestionsWithHoverResult;

}
// returns updated suggestion list by updating 'selected' attribute of hovering item to true and resetting 'selected' attribute of other items to false
export const updateSelectedIndexHoverOnSuggestion = ( suggestionName, state ) => {

  let updatedsuggestionsWithHoverResult = [];
  updatedsuggestionsWithHoverResult = state.suggestionsWithProductList?.map( ( value ) => {
    return {
      ...value,
      ...{ selected: ( suggestionName === value.name && !value.default ) }
    }
  } );
  return updatedsuggestionsWithHoverResult

}
// Return formatted url for listing pages .
export const formatActionUrl = ( value ) =>{
  // format the url for global site . otherwise no change in the url
  // If url is empty then build url using search term
  let formattedURL;

  // if actionUrl was returned by the service it would have been a fullyQualified URL. Need to modify it for global site
  if( value.actionUrl ){
    formattedURL = isIntlSite() ? fullyQualifyLink( host, value.actionUrl.replace( /^.*\/\/[^\/]+\//, '/' ) ) : value.actionUrl;
  }
  // if action url was not obtained from service, then build url using search term which will be a relative URL
  else {
    formattedURL = buildActionUrl( value.name );
  }
  return formattedURL;
}
