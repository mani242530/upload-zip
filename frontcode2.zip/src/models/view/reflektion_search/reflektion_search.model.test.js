/**
 * Test for Search  Reducer
 */
import {
  CHANGE as REDUXFORM_CHANGE,
  FOCUS as REDUXFORM_FOCUS
} from 'redux-form/lib/actionTypes';
import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import _ from 'lodash';
import * as formatters from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import {
  CLOSE_REFLEKTION_SEARCH_MODEL,
  UPDATE_TOP_RESULT
} from '../../../events/reflektion_search/reflektion_search.events';
import { TOGGLE_MOBILE_SEARCH } from '../../../events/search_menu/search_menu.events';


import reducer, {
  initialState,
  reducerSwitch,
  buildActionUrl,
  formatActionUrl
} from './reflektion_search.model';
describe( 'Reflektion Search reducer', ( ) => {

  it( 'should have the proper default state', ( ) => {
    let expectedState = {
      searchTermValue: '',
      isReflektionModelOpen: false,
      visualSearchEnabled: false,
      actionUrl:null,
      suggestionsWithProductList:[],
      showMobileSearch: false,
      typeaheadSearchEnabled: false,
      isDeviceMobile: false
    }
    expect( initialState ).toEqual( expectedState );
  } )

  it( 'should be a function', ( ) => {
    expect( _.isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', ( ) => {
    expect( reducer( undefined, { type: 'switches' } ) ).toEqual( initialState );
  } );

  describe( 'Open reflektion search modal ', ( ) => {
    it( 'should set correct state on success of reflektionSearch success in INTL site ', ( ) => {
      registerServiceName( 'reflektionSearch' );
      formatters.isIntlSite = () => true;
      formatters.host = 'global-qa1.ulta.com';
      const state = {
        isReflektionModelOpen:false
      }

      let actionCreator = {
        type: getServiceType( 'reflektionSearch', 'success' ),
        data:{
          switches:{
            visualSearchEnabled: true
          },
          categories:{
            items:[{
              'actionUrl': 'https://qa1.ulta.com/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults',
              'name': 'mac'
            }]
          },
          skus:{
            items:[{
              'images':[],
              'displayName': 'Mineralize Skinfinish Natural',
              'actionUrl': 'https://qa1.ulta.com/mineralize-skinfinish-natural?productId=xlsImpprod15921190',
              'brandName': 'MAC'
            }]
          },
          searchTerm:'mac'
        }
      }
      let expectedOutput = {
        'actionUrl': '/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults',
        'isReflektionModelOpen': true,
        'searchTermValue': 'mac',
        'suggestionsWithProductList': [
          {
            'actionUrl': '/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults',
            'default': true,
            'name': 'mac',
            'selected': true,
            'skus': [
              {
                'actionUrl': '//global-qa1.ulta.com/mineralize-skinfinish-natural?productId=xlsImpprod15921190',
                'brandName': 'MAC',
                'displayName': 'Mineralize Skinfinish Natural',
                'images': [

                ]
              }
            ]
          },
          {
            'actionUrl': '//global-qa1.ulta.com/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults',
            'name': 'mac',
            'skus': [
              {
                'actionUrl': '//global-qa1.ulta.com/mineralize-skinfinish-natural?productId=xlsImpprod15921190',
                'brandName': 'MAC',
                'displayName': 'Mineralize Skinfinish Natural',
                'images': [

                ]
              }
            ]
          }
        ]
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should set correct state on success of reflektionSearch success in Non INTL site ', ( ) => {
      registerServiceName( 'reflektionSearch' );
      formatters.isIntlSite = () => false;
      formatters.host = 'qa1.ulta.com';
      const state = {
        isReflektionModelOpen:false
      }

      let actionCreator = {
        type: getServiceType( 'reflektionSearch', 'success' ),
        data:{
          switches:{
            visualSearchEnabled: true
          },
          categories:{
            items:[{
              'actionUrl': 'https://qa1.ulta.com/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults',
              'name': 'mac'
            }]
          },
          skus:{
            items:[{
              'images':[],
              'displayName': 'Mineralize Skinfinish Natural',
              'actionUrl': 'https://qa1.ulta.com/mineralize-skinfinish-natural?productId=xlsImpprod15921190',
              'brandName': 'MAC'
            }]
          },
          searchTerm:'mac'
        }
      }
      let expectedOutput = {
        'actionUrl': '/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults',
        'isReflektionModelOpen': true,
        'searchTermValue': 'mac',
        'suggestionsWithProductList': [
          {
            'actionUrl': '/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults',
            'default': true,
            'name': 'mac',
            'selected': true,
            'skus': [
              {
                'actionUrl': 'https://qa1.ulta.com/mineralize-skinfinish-natural?productId=xlsImpprod15921190',
                'brandName': 'MAC',
                'displayName': 'Mineralize Skinfinish Natural',
                'images': [

                ]
              }
            ]
          },
          {
            'actionUrl': 'https://qa1.ulta.com/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults',
            'name': 'mac',
            'skus': [
              {
                'actionUrl': 'https://qa1.ulta.com/mineralize-skinfinish-natural?productId=xlsImpprod15921190',
                'brandName': 'MAC',
                'displayName': 'Mineralize Skinfinish Natural',
                'images': [

                ]
              }
            ]
          }
        ]
      } ;
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should update the state with empty product list on success of reflektionSearch with no keyPhraseCategories', ( ) => {
      registerServiceName( 'reflektionSearch' );

      const state = {
        isReflektionModelOpen:false
      }

      let actionCreator = {
        type: getServiceType( 'reflektionSearch', 'success' ),
        data:{
          switches:{
            visualSearchEnabled: true
          },
          categories: null,
          skus:null,
          searchTerm:'nail'
        }
      }
      let expectedOutput = {
        isReflektionModelOpen:false,
        suggestionsWithProductList:[],
        actionUrl:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
        searchTermValue:'nail'
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );
  describe( 'Toggle Mobile Search Window', ( ) => {
    let state = {
      showMobileSearch: false
    }
    let actionCreator = {
      type: TOGGLE_MOBILE_SEARCH
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        showMobileSearch: true,
        suggestionList:null,
        topResultFor:null,
        suggestionsWithProductList:[]
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );
  describe( 'Fetch data in reflektion search pop up ', ( ) => {
    it( 'should set correct state with selected flag as false on success of fetchTopResults success ', ( ) => {
      registerServiceName( 'fetchTopResults' );
      const state = {
        suggestionsWithProductList:[{
          default:true,
          name:'nail',
          url:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
          skus:[]
        }]
      }

      let actionCreator = {
        type: getServiceType( 'fetchTopResults', 'success' ),
        data:{
          switches:{
            visualSearchEnabled: true
          },
          skus:{
            items:[{
              'images':[],
              'displayName': 'Mineralize Skinfinish Natural',
              'actionUrl': 'https://qa1.ulta.com/mineralize-skinfinish-natural?productId=xlsImpprod15921190',
              'brandName': 'MAC'
            }]
          },
          searchTerm:'macadamia professional'
        }
      }
      let expectedOutput = {
        suggestionsWithProductList:[{
          selected:false,
          default:true,
          name:'nail',
          url:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
          skus:[]
        }]
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
    it( 'should set correct state with selected flag as true on success of fetchTopResults success ', ( ) => {
      registerServiceName( 'fetchTopResults' );

      const state = {
        suggestionsWithProductList:[{
          default:true,
          name:'nail',
          url:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
          skus:[]
        }]
      }

      let actionCreator = {
        type: getServiceType( 'fetchTopResults', 'success' ),
        data:{
          switches:{
            visualSearchEnabled: true
          },
          categories:{
            items:[]
          },
          skus:{
            items:[]
          },
          searchTerm:'nail'
        }
      }
      let expectedOutput = {
        suggestionsWithProductList:[{
          selected:true,
          default:true,
          name:'nail',
          url:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
          skus:[]
        }]
      }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );
  describe( 'Update top results based on hover ', ( ) => {
    const state = {
      suggestionsWithProductList:[{
        default:false,
        name:'nail',
        url:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
        skus:[]
      }]
    }
    let suggestionName = 'nailp'
    let actionCreator = {
      type: UPDATE_TOP_RESULT,
      suggestionName
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        suggestionsWithProductList:[{
          default:false,
          name:'nail',
          url:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
          skus:[],
          selected:false
        }]
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'Update input value ', ( ) => {
    const state = {
      suggestionsWithProductList:[{
        default:false,
        name:'nail',
        actionUrl:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
        skus:[],
        selected:false
      }]
    }
    let actionCreator = {
      type: REDUXFORM_CHANGE,
      meta:{
        form:'SearchBarInput',
        field:'searchInput',
        active: true
      },
      payload:'nail'
    };

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        suggestionsWithProductList:[{
          default:false,
          name:'nail',
          actionUrl:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
          skus:[],
          selected:false
        }],
        isReflektionModelOpen:true,
        actionUrl:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
        searchTermValue:'nail'
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should display the model if there is no letters in input field ', ( ) => {
      const state = {
        suggestionsWithProductList:[{
          default:false,
          name:'nail',
          actionUrl:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
          skus:[],
          selected:false
        }]
      }
      let actionCreator = {
        type: REDUXFORM_CHANGE,
        meta:{
          form:'SearchBarInput',
          field:'searchInput',
          active: true
        },
        payload:''
      }
      let expectedOutput = {
        suggestionsWithProductList:[{
          default:false,
          name:'nail',
          actionUrl:'/ulta/a/_/Ntt-nail/Nty-1?Dy=1&ciSelector=searchResults',
          skus:[],
          selected:false
        }],
        isReflektionModelOpen:true,
        actionUrl:'/ulta/a/_/Ntt-/Nty-1?Dy=1&ciSelector=searchResults',
        searchTermValue:''
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should display the model if the user clicks on the input field, only when the search term have more than 2 letters', ( ) => {
      const state = {
        searchTermValue:'lip'
      }
      let expectedOutput = {
        isReflektionModelOpen:true,
        searchTermValue:'lip'
      };
      let actionCreator1 = {
        type: REDUXFORM_FOCUS,
        meta:{
          form:'SearchBarInput',
          field:'searchInput',
          active: true
        }
      };

      expect( reducer( state, actionCreator1 ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'Close reflektion search modal ', ( ) => {
    let state = {
      isReflektionModelOpen: true
    }
    let actionCreator = {
      type: CLOSE_REFLEKTION_SEARCH_MODEL,
      data: {
        searchTermValue:'lips'
      }
    }

    it( 'should handle the event and set the state', ( ) => {

      let expectedOutput = {
        isReflektionModelOpen: false,
        searchTermValue:{
          searchTermValue:'lips'
        }
      };

      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );
  describe( 'switches success', () => {
    it( 'should set visualSearchEnabled flag to true and typeaheadSearchEnabled to false', ( ) => {
      registerServiceName( 'switches' );

      const state = {
        visualSearchEnabled:false
      }

      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data:{
          switches:{
            visualSearchEnabled: true
          }
        }
      }
      let expectedOutput = { visualSearchEnabled: true, typeaheadSearchEnabled: false }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set visualSearchEnabled flag to false and typeaheadSearchEnabled to true ', ( ) => {
      registerServiceName( 'switches' );

      const state = {
        visualSearchEnabled:false
      }

      let actionCreator = {
        type: getServiceType( 'switches', 'success' ),
        data:{
          switches:{
            visualSearchEnabled: false
          }
        }
      }
      let expectedOutput = { visualSearchEnabled: false, typeaheadSearchEnabled: true }
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } );
  describe( 'build actionUrl', () => {
    it( 'should return the proper string for a actionUrl', () => {
      let query = encodeURIComponent( 'this_is_a_test' );
      const output = `/ulta/a/_/Ntt-${query}/Nty-1?Dy=1&ciSelector=searchResults`
      expect( buildActionUrl( query ) ).toBe( output );
    } );
  } );
  describe( 'formatActionUrl ', () => {
    it( 'should return the proper actionUrl for CA site', () => {
      formatters.isIntlSite = () => true;
      formatters.host = 'global-qa1.ulta.com';
      let value  = {
        'actionUrl': 'https//qa1.ulta.com/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults',
        'name': 'mac',
        'selected': false
      }
      const output = `//global-qa1.ulta.com/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults`
      expect( formatActionUrl( value ) ).toBe( output );
    } );
    it( 'should return the proper actionUrl for Non Intl site ', () => {
      formatters.isIntlSite = () => false;
      formatters.host = 'qa1.ulta.com';
      let value  = {
        'actionUrl': 'https//qa1.ulta.com/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults',
        'name': 'mac',
        'selected': false
      }
      const output = `https//qa1.ulta.com/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults`
      expect( formatActionUrl( value ) ).toBe( output );
    } );
    it( 'should return the proper actionUrl when actionUrl of request object is undefined ', () => {
      formatters.isIntlSite = () => false;
      formatters.host = 'qa1.ulta.com';
      let value  = {
        'name': 'mac',
        'selected': false
      }
      const output = `/ulta/a/_/Ntt-mac/Nty-1?Dy=1&ciSelector=searchResults`
      expect( formatActionUrl( value ) ).toBe( output );
    } );
  } );
} );