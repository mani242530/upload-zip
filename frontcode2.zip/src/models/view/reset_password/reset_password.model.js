/**
 * Reset Password Redux reducer Module
 *
 */
import get from 'lodash/get'
import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  CHANGE as REDUXFORM_CHANGE,
  FOCUS as REDUXFORM_FOCUS
} from 'redux-form/lib/actionTypes';
import {
  validatePassword,
  validationKeys
} from 'ulta-fed-core/dist/js/utils/form_validations/form_validations';
import { ResetCredentialsFormName } from '../../../views/ResetCredentialsForm/ResetCredentialsForm';


/**
 * default state for the ResetPassword reducer
 */

export const initialState = {
  isResetPageLoading:true,
  showPasswordRules:false,
  isPasswordCaseValid: false,
  isPasswordNumberValid: false,
  isPasswordSplCharValid: false,
  isPasswordSymbolValid: true,
  isPasswordlengthValid: false,
  isResetFormReadyForSubmit: false,
  passwordAndUsernameRequestErrorMessages : undefined,
  resetPasswordRequestErrorMessages: undefined,
  userEmailId: undefined,
  resetCredentialToken: null,
  encryptedEmailId: null
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now() or Math.random().
 */
export default function reducer( state = initialState, action ){
  return reducerSwitch( state, action )
}

export const reducerSwitch = function( state, action ){

  switch ( action.type ){
    case getServiceType( 'resetCredential', 'loading' ):
      return {
        ...state,
        isResetPageLoading:true
      }

    case getServiceType( 'resetCredential', 'success' ):
      return {
        ...state,
        isResetPageLoading:false,
        resetCredentialToken: action.data.t,
        encryptedEmailId: action.data.e
      }

    case REDUXFORM_FOCUS:
      return {
        ...state,
        // On Password field focus display password rules and clear earlier displayed error message
        ...( action.meta.form === ResetCredentialsFormName && action.meta.field === 'password' && { showPasswordRules:true, resetPasswordRequestErrorMessages: undefined } )
      }

    case REDUXFORM_CHANGE:
      if( action.meta.form === ResetCredentialsFormName && action.meta.field === 'password' ){
        return {
          ...state,
          isPasswordCaseValid: validatePassword( action.payload, validationKeys.passwordCase ),
          isPasswordNumberValid: validatePassword( action.payload, validationKeys.passwordNumberExist ),
          isPasswordSplCharValid: validatePassword( action.payload, validationKeys.passwordSplCharExist ),
          isPasswordSymbolValid: validatePassword( action.payload, validationKeys.passwordWithoutInvalidSymbol ),
          isPasswordlengthValid: validatePassword( action.payload, validationKeys.passwordLength ),
          // This key will check if all the above mentioned validations are passing
          isResetFormReadyForSubmit: validatePassword( action.payload, [
            validationKeys.passwordCase,
            validationKeys.passwordNumberExist,
            validationKeys.passwordSplCharExist,
            validationKeys.passwordWithoutInvalidSymbol,
            validationKeys.passwordLength
          ] )
        }
      }

    case getServiceType( 'forgotUserName', 'success' ):
    case getServiceType( 'passwordResetRequest', 'success' ):
    /**
     * field level error messages are handled in frontend level validation . From service they are provided
     * common error message that are happened during rest service implementation . So here is only need to handle global level error .
     */
      const message  = get( action, 'data.messages.items' )
      const userEmailId = get( action, 'data.userEmailId' )
      return {
        ...state,
        passwordAndUsernameRequestErrorMessages : message,
        userEmailId : userEmailId
      }

    case getServiceType( 'validateAndResetPassword', 'success' ):
      return {
        ...state,
        // Reset Password Request error Message on success failure
        resetPasswordRequestErrorMessages : !get( action, 'data.success' ) && get( action, 'data.messages.items' )
      }

    default:
      return state;
  }
};
