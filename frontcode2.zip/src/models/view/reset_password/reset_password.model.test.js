

import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import {
  CHANGE as REDUXFORM_CHANGE,
  FOCUS as REDUXFORM_FOCUS
} from 'redux-form/lib/actionTypes';

import {
  validatePassword,
  validationKeys
} from 'ulta-fed-core/dist/js/utils/form_validations/form_validations';
import reducer, {
  initialState,
  reducerSwitch
} from './reset_password.model';


describe( 'ResetPassword reducer', ( ) => {
  const serviceType = 'passwordResetRequest';
  registerServiceName( serviceType );
  registerServiceName( 'resetCredential' );
  registerServiceName( 'forgotUsername' );

  it( 'should have the proper default state', ( ) => {
    const expectedState = {
      isResetPageLoading: true,
      showPasswordRules:false,
      isPasswordCaseValid: false,
      isPasswordNumberValid: false,
      isPasswordSplCharValid: false,
      isPasswordSymbolValid: true,
      isPasswordlengthValid: false,
      isResetFormReadyForSubmit: false,
      passwordAndUsernameRequestErrorMessages : undefined,
      resetPasswordRequestErrorMessages: undefined,
      userEmailId : undefined,
      resetCredentialToken: null,
      encryptedEmailId: null
    }
    expect( initialState ).toEqual( expectedState );
  } );

  it( 'should set isResetPageLoading as true', () => {
    let actionCreator = {
      type: getServiceType( 'resetCredential', 'loading' )
    };
    let expectedOutput = {
      isResetPageLoading: true
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'resetCredential success case', ( ) => {
    const actionData = { e:'eefehhiuihjk', t:'AAAAjjhug56hj' };
    let actionCreator = {
      type: getServiceType( 'resetCredential', 'success' ),
      data : actionData
    };
    let expectedOutput = {
      isResetPageLoading: false,
      resetCredentialToken: actionData.t,
      encryptedEmailId: actionData.e
    };
    expect( reducer( { }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should execute case getServiceType (\'passwordResetRequest\', \'success\')', ()=>{
    let res = {
      messages: null,
      userEmailId : 'ans@gamail.com'
    }
    let actionCreator = {
      type : getServiceType( 'passwordResetRequest', 'success' ),
      data : res
    }
    let expectedOutput = {
      passwordAndUsernameRequestErrorMessages: undefined,
      userEmailId : 'ans@gamail.com'
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput )
  } )

  it( 'should execute case REDUXFORM_FOCUS', () => {
    const action = {
      type: REDUXFORM_FOCUS,
      meta:{
        form:'resetcredentials',
        field:'password'
      }
    }
    const expectedOutput = { showPasswordRules:true };
    expect( reducer( {}, action ) ).toEqual( expectedOutput );
  } );


  it( 'should execute case REDUXFORM_CHANGE', () => {
    let action = {
      type: REDUXFORM_CHANGE,
      meta:{
        form:'resetcredentials',
        field:'password'
      },
      payload:'Ulta@123'
    }
    let expectedOutput = {
      isPasswordCaseValid: true,
      isPasswordNumberValid: true,
      isPasswordSplCharValid: true,
      isPasswordSymbolValid: true,
      isPasswordlengthValid: true,
      isResetFormReadyForSubmit: true
    };
    expect( reducer( {}, action ) ).toEqual( expectedOutput );
  } );

  it( 'should execute case getServiceType (\'validateAndResetPassword\', \'success\')', ()=>{
    // Success Response from Backend
    let res = {
      status: true,
      messages: null
    }
    let actionCreator = {
      type : getServiceType( 'validateAndResetPassword', 'success' ),
      data : res
    }
    let expectedOutput = {
      resetPasswordRequestErrorMessages: undefined
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
    // Error Response from Backend
    res = {
      status: false,
      messages: {
        items: [
          {
            type: 'Error',
            message: 'Failed to reset password'
          }
        ]
      }
    }
    actionCreator = {
      type : getServiceType( 'validateAndResetPassword', 'success' ),
      data : res
    }
    expectedOutput = {
      resetPasswordRequestErrorMessages: res.messages.items
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

} );
