/**
 * SaveForLater Redux reducer Module
 *
 */

import {
  getServiceType,
  SESSION_TIMEOUT
} from 'ulta-fed-core/dist/js/events/services/services.events';
import get from 'lodash/get';
import isEmpty from 'lodash/isEmpty';
import concat from 'lodash/concat';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import {
  MOVE_ITEM_TO_SAVE_FOR_LATER,
  SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE,
  SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE
} from '../../../events/save_for_later/save_for_later.events';
import SaveForLaterItemsMessages from '../../../views/SaveForLaterItems/SaveForLaterItems.messages';

/**
 * default state for the SaveForLater reducer
 */

export const initialState = {

  // saveForLaterItems is initialised to undefined to ensure that the saveforlaterItem component is displayed only after saveforLater API call is completed.
  // After successfull call if no item is returned, saveForLaterItems is set as empty array
  saveForLaterItems: undefined,
  saveForLaterQuantity: 0,
  showViewMoreOption:false,
  itemEligibilityDetails:{}
};


/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now( ) or Math.random( ).
 */
export default function reducer( state = initialState, action ){

  switch ( action.type ){


    case getServiceType( 'saveForLater', 'success' ):

      return {
        ...state,
        ...prepareSFLList( state, 'append', action.data )
      }

    case getServiceType( 'addToSaveForLater', 'success' ):
      return {
        ...state,
        ...prepareSFLList( state, 'prepend', action.data.movedItems )
      };
    case MOVE_ITEM_TO_SAVE_FOR_LATER:
      return {
        ...state,
        ...prepareSFLList( state, 'prepend', action.data.movedItems.saveForLater )
      };

    case getServiceType( 'saveForLaterItemRemove', 'success' ):
      return {
        ...state,
        ...prepareSFLList( state, 'remove', action.data )
      }

    case getServiceType( 'moveToBagFromSaveForLater', 'success' ):
      return {
        ...state,
        // if action is success, then sfl list will be updated to remove the item from the list
        ...( action.data.cart && prepareSFLList( state, 'remove', action.data.saveForLater, action.data.cart.deliveryOption ) ),
        // if the action is not success, itemEligibilityDetails will be updated to include the messages related to the failure
        ...( !action.data.cart && { itemEligibilityDetails: populateEligibilityDetails( state.itemEligibilityDetails, action.data.saveForLater.saveForLaterItems.items, state.deliveryOption ) } )
      }

    case getServiceType( 'saveForLaterItemRemove', 'loading' ):
    case getServiceType( 'moveToBagFromSaveForLater', 'loading' ):
      return {
        ...state,
        saveForLaterItems:updateSFLItemDisplayStatus( state.saveForLaterItems, action.data, { showSpinner:true } )
      }
    case SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE:
      return {
        ...state,
        saveForLaterItems:updateSFLItemDisplayStatus( state.saveForLaterItems, action.data, { showSpinner:false, showTransitionComponent:true, transitionMessage: formatMessage( SaveForLaterItemsMessages.removeSaveForLaterLabel ) } )
      }

    case SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE:
      return {
        ...state,
        saveForLaterItems: updateSFLItemDisplayStatus( state.saveForLaterItems, action.data.sflItemId, { showSpinner: false, showTransitionComponent: action.data.success, transitionMessage: formatMessage( SaveForLaterItemsMessages.moveToBagFromSaveForLaterLabel ) } )
      }

    case SESSION_TIMEOUT:
    case getServiceType( 'logout', 'success' ):
      return {
        ...initialState
      }

    // as part of these two actions, the deliveryOption can change, and itemEligibiltyDetails will be populated
    case getServiceType( 'loadCart', 'success' ):
    case getServiceType( 'deliveryOptionsUpdate', 'success' ):
      const deliveryOption = get( action, 'data.deliveryOption' ) || 'ship';
      return {
        ...state,
        deliveryOption,
        itemEligibilityDetails:populateEligibilityDetails( state.itemEligibilityDetails, state.saveForLaterItems, deliveryOption )
      }

    // whenever there is a new store selected, eligibilityDetails will be re-populated, which will clear any pickup related messages
    case getServiceType( 'pickupStoreInfoUpdate', 'success' ):
      const { storeAvailable, cartResponse } = action.data;
      return {
        ...state,
        ...(
          storeAvailable &&
          { itemEligibilityDetails:populateEligibilityDetails( state.itemEligibilityDetails, state.saveForLaterItems, cartResponse.deliveryOption ) }
        )
      };

    default:
      return state;

  }
}


export const updateSFLItemDisplayStatus = ( saveForLaterItems, sflItemId, displayStatusInfo ) =>{

  let SFLItemlist = []
  saveForLaterItems.map( saveForLaterItem =>{
    // to create a new SFLItem reference in the list
    let SFLItem = {
      ...saveForLaterItem
    }
    if( saveForLaterItem.sflItemId === sflItemId ){
      SFLItem.displayStatusInfo = displayStatusInfo
    }
    SFLItemlist.push( SFLItem );
  } )
  return SFLItemlist
}

// this method modifies the saveForLaterItems based on different actions
// the action parameter can have three values 'remove', 'append' and 'prepend'
// a. remove will remove the item from the existing list
// b. prepend will first remove the item if it is already present in the current list, and will add the item to the beginning of the list
//    prepend will be passed when a new item is added to the list or move to the list when the user is on the page
// c. append will add the item(s) to the end of the existing list
//    append will be passed on the initial load of the items and when 'view more items' link is clicked by the user
export const prepareSFLList = ( state, action, newData, deliveryOption ) =>{
  const existingList = state.saveForLaterItems;

  let modifiedList = existingList || [];
  let totalNumRecs = state.saveForLaterQuantity;
  let showViewMoreOption = state.showViewMoreOption;
  let itemEligibilityDetails = state.itemEligibilityDetails;

  if( newData.saveForLaterItems ){

    totalNumRecs = newData.totalNumRecs;

    // when an item is being added ( prepend ) to the list, we ensure that the same item if already present in the list is removed and then the item is added
    // this will help to maintain the order of the items.
    if( action === 'remove' || action === 'prepend' ){
      const removedItemId = newData.saveForLaterItems.items[0].sflItemId;
      modifiedList = modifiedList.filter( saveForLaterItem => saveForLaterItem.sflItemId !== removedItemId ) ;
    }
    if( action === 'prepend' ){
      modifiedList = concat( newData.saveForLaterItems.items, modifiedList );
    }
    else if( action === 'append' ){
      modifiedList = concat( modifiedList || [], newData.saveForLaterItems.items );
      showViewMoreOption = totalNumRecs > modifiedList.length;
    }

    // if there is a deliveryOption change, need to ensure that the eligibiltyDetails are populated for all the items
    // Or else eligibilityDetails will be populated for that item(s) whcih are getting added
    if( deliveryOption && deliveryOption !== state.deliveryOption ){
      itemEligibilityDetails = populateEligibilityDetails( {}, modifiedList, deliveryOption );
    }
    else if( action === 'prepend' || action === 'append' ){
      itemEligibilityDetails = populateEligibilityDetails( itemEligibilityDetails, newData.saveForLaterItems.items, state.deliveryOption );
    }

  }

  return {
    saveForLaterItems:modifiedList,
    saveForLaterQuantity:totalNumRecs,
    showViewMoreOption,
    itemEligibilityDetails
  }
}

export const populateEligibilityDetails = ( itemEligibilityDetailsExisting, sflItems, deliveryOption ) => {

  let itemEligibilityDetails = itemEligibilityDetailsExisting;

  if( !isEmpty( sflItems ) ){

    for ( var counter = 0; counter < sflItems.length; counter ++ ){

      const sflItem = sflItems[ counter ];

      // isItemAvailable will indicate if the item is eligible for moveToBag for the current deliveryOption
      const isItemAvailable = !!get( sflItem, `eligibilityStatus.addToBag.${deliveryOption}.status` );

      // shipEntireOrder will be set to true, if the current delivery option is pickup and if it is not available and if the item is available for ship
      const shipEntireOrder = deliveryOption === 'pickup' && !isItemAvailable && !!get( sflItem, 'eligibilityStatus.addToBag.ship.status' );

      // this will get messages at each item level.
      const itemMessages = get( sflItem, 'messages.items' ) || [];
      const actionMessages = [];
      const deliveryMessages = [];
      const actionTypes = Object.keys( sflItem.eligibilityStatus );

      for ( let i = 0;i < actionTypes.length;i++ ){
        const actionType = actionTypes[ i ];
        const action = sflItem[ 'eligibilityStatus' ][ actionType ];
        if( action.messages ){
          // this will get messages at the action level, for eg: addToBag
          actionMessages.push( ...action.messages.items )
        }
        if( get( action, `${deliveryOption}.messages` ) ){
          // this will get messages at the deliveryOption level inside each action
          deliveryMessages.push( ...action[deliveryOption].messages.items )
        }
      }

      itemEligibilityDetails = {
        ...itemEligibilityDetails,
        [ sflItem.sflItemId ]:{
          messages:[itemMessages, actionMessages, deliveryMessages],
          isItemAvailable,
          shipEntireOrder
        }
      }
    }
  }

  return itemEligibilityDetails;
}

export const getSaveForLaterState = state => state.SaveForLater;