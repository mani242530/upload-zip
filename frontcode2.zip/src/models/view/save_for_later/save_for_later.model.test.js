
import {
  registerServiceName,
  getServiceType,
  getActionDefinition,
  SESSION_TIMEOUT
} from 'ulta-fed-core/dist/js/events/services/services.events';
import isFunction from 'lodash/isFunction';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { initializeIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import React from 'react';
import configureStore from '../../../modules/ccr/ccr.store';
import CONFIG from '../../../modules/ccr/ccr.config';
import SaveForLaterItemsMessages from '../../../views/SaveForLaterItems/SaveForLaterItems.messages';
import {
  SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE,
  SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE,
  MOVE_ITEM_TO_SAVE_FOR_LATER
} from '../../../events/save_for_later/save_for_later.events';
import reducer, {
  initialState,
  updateSFLItemDisplayStatus,
  prepareSFLList,
  populateEligibilityDetails,
  getSaveForLaterState
} from './save_for_later.model';

describe( 'SaveForLater reducer', () => {

  registerServiceName( 'saveForLater' );
  registerServiceName( 'saveForLaterItemRemove' );
  registerServiceName( 'moveToSaveForLater' );
  registerServiceName( 'moveToBagFromSaveForLater' );
  let store = configureStore( {}, CONFIG );
  initializeIntl();

  it( 'should have the proper default state', () =>{

    let expectedState = {
      saveForLaterItems: undefined,
      saveForLaterQuantity: 0,
      showViewMoreOption:false,
      itemEligibilityDetails:{}
    };

    expect( initialState ).toEqual( expectedState );
  } );

  it( 'should be a function', () =>{
    expect( isFunction( reducer ) ).toBe( true );
  } );

  it( 'should return the initial state', () => {
    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );


  it( 'should set saveForLaterItems for saveForLater success', () => {
    const data = {
      saveForLaterItems: {
        items: [
          {
            product: {
              displayName: 'CC+ Radiance Ombre Blush',
              actionUrl: 'https://qa3.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073',
              id: 'xlsImpprod12251073'
            },
            messages: null,
            availableForShip: null,
            sku: {
              images: {
                blowupImage: 'https://images.ulta.com/is/image/Ulta/2286651?$detail$',
                mainImage: 'https://images.ulta.com/is/image/Ulta/2286651',
                largeImage: 'https://images.ulta.com/is/image/Ulta/2286651?$lg$',
                smallImage: 'https://images.ulta.com/is/image/Ulta/2286651?$sm$',
                thumbnailImage: 'https://images.ulta.com/is/image/Ulta/2286651?$tn$',
                mediumImageUrl: 'https://images.ulta.com/is/image/Ulta/2286651?$md$'
              },
              displayName: 'CC+ Radiance Ombre Blush',
              description: 'IT Cosmetics CC+ Radiance Ombre Blush is a color correcting + anti-aging blushing veil with hydrolyzed collagen, peptides and Drops of Light Technology.',
              price: {
                salePrice: null,
                listPrice: {
                  displayAmount: '$24.00',
                  amount: 24,
                  currencyCode: 'USD'
                }
              },
              variant: {
                variantType: 'Color',
                variantDesc: 'Je Ne Sais Quoi'
              },
              id: '2286651',
              skuPromotions: [
                {
                  displayName: 'QA-B2G2 OFF  Class-013, Class-102',
                  actionUrl: 'https://qa3.ulta.com/ulta/promotion/buy-more-save-more/detail/0000012350',
                  description: 'Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 Test1 Test2 !!',
                  type: 'B',
                  qualifyingSKUs: null,
                  id: '0000012350'
                }
              ]
            },
            brand: {
              displayName: 'It Cosmetics',
              actionUrl: 'https://qa3.ulta.com/brand/it-cosmetics',
              id: 'xlsImp22900488'
            },
            sflItemId: 'gi115200003',
            eligibilityStatus: {
              addToBag: {
                ship: {
                  messages: null,
                  status: true
                },
                pickup: {
                  messages: {
                    items: [
                      {
                        type: 'Error',
                        message: 'Unavailable for pickup.'
                      }
                    ]
                  },
                  status: false
                },
                messages: null,
                status: true
              }
            }
          }
        ]
      },
      numberOfPages: 1,
      totalNumRecs: 1,
      messages: null
    };
    const itemEligibilityDetails = {
      gi115200003:{
        isItemAvailable:false,
        shipEntireOrder:true,
        messages:[
          [], [], [{ message: 'Unavailable for pickup.', 'type':'Error' }]
        ]
      }
    }
    let actionCreator = {
      type: getServiceType( 'saveForLater', 'success' ),
      data
    }
    let expectedOutput = {
      saveForLaterItems: data.saveForLaterItems.items,
      saveForLaterQuantity: 1,
      showViewMoreOption:false,
      itemEligibilityDetails,
      deliveryOption:'pickup'
    };
    expect( reducer( { deliveryOption:'pickup' }, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should not set saveForLaterQuantity and saveForLaterItems for saveForLater success if saveForLaterItems is empty and totalNumRecs is undefined', () => {
    const data = {
      saveForLaterItems: null,
      totalNumRecs: undefined
    };
    let actionCreator = {
      type: getServiceType( 'saveForLater', 'success' ),
      data
    }
    let expectedOutput = {
      saveForLaterItems: [],
      saveForLaterQuantity: 0,
      showViewMoreOption:false,
      itemEligibilityDetails:{}

    };
    expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should return empty array for saveForLaterItems if saveForLaterItems is null', () => {
    const data = {
      saveForLaterItems: null,
      messages: null
    };
    let actionCreator = {
      type: getServiceType( 'saveForLater', 'success' ),
      data
    }
    let expectedOutput = {
      saveForLaterItems: []
    };
    expect( reducer( {}, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should append saveForLaterItems passed in action with the exisitng saveForLaterItems list in state on saveForLater success ', () => {
    let state = {
      saveForLaterItems:[
        {
          sflItemId:'123',
          eligibilityStatus:{
            addToBag:{
              status:true,
              ship:{
                status:true
              },
              pickup:{
                status:true
              }
            }
          }
        }
      ],
      deliveryOption:'ship'
    }
    const data = {
      saveForLaterItems: {
        items:[
          {
            sflItemId:'1234',
            eligibilityStatus:{
              addToBag:{
                status:true,
                ship:{
                  status:true
                },
                pickup:{
                  status:true
                }
              }
            }
          }
        ]
      },
      totalNumRecs:3,
      messages: null
    };
    let actionCreator = {
      type: getServiceType( 'saveForLater', 'success' ),
      data
    }
    let expectedOutput = {
      saveForLaterItems: [
        {
          sflItemId:'123',
          eligibilityStatus:{
            addToBag:{
              status:true,
              ship:{
                status:true
              },
              pickup:{
                status:true
              }
            }
          }
        },
        {
          sflItemId:'1234',
          eligibilityStatus:{
            addToBag:{
              status:true,
              ship:{
                status:true
              },
              pickup:{
                status:true
              }
            }
          }
        }
      ],
      deliveryOption: 'ship',
      itemEligibilityDetails: {
        '1234': {
          isItemAvailable: true,
          messages: [[], [], []],
          shipEntireOrder: false
        }
      },
      saveForLaterQuantity:3,
      // showViewMoreOption is true since totalNumRecs is greater than number of items in saveForLaterItems
      showViewMoreOption:true
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should append saveForLaterItems passed in action with empty array on saveForLater success if saveForLaterItems in state is undefined ', () => {
    let state = {
      saveForLaterItems:undefined
    }
    const data = {
      saveForLaterItems: {
        items:[
          {
            sflItemId:'123',
            'eligibilityStatus': {
              'addToBag': {
                'ship': {
                  'messages': {
                    'items': [
                      {
                        'type': 'Error',
                        'message': 'Out of Stock.'
                      }
                    ]
                  },
                  'status': false
                },
                'pickup': {
                  'messages': null,
                  'status': true
                },
                'messages': null
              }
            }
          }
        ]
      },
      totalNumRecs:1,
      messages: null
    };
    let actionCreator = {
      type: getServiceType( 'saveForLater', 'success' ),
      data
    }
    let expectedOutput = {
      itemEligibilityDetails:{
        '123':{
          isItemAvailable:false,
          messages:[[], [], []],
          shipEntireOrder:false
        }
      },
      saveForLaterItems: [
        {
          sflItemId:'123',
          'eligibilityStatus': {
            'addToBag': {
              'ship': {
                'messages': {
                  'items': [
                    {
                      'type': 'Error',
                      'message': 'Out of Stock.'
                    }
                  ]
                },
                'status': false
              },
              'pickup': {
                'messages': null,
                'status': true
              },
              'messages': null
            }
          }
        }
      ],
      saveForLaterQuantity:1,
      // showViewMoreOption is false since totalNumRecs is not greater than number of items in saveForLaterItems
      showViewMoreOption:false
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set showViewMoreOption as true if totalNumRecs is greater than saveForLaterItems.length', () => {

    let state = {
      saveForLaterItems:undefined
    }
    const data = {
      saveForLaterItems: {
        items:[
          {
            sflItemId:'123',
            'eligibilityStatus': {
              'addToBag': {
                'ship': {
                  'messages': {
                    'items': [
                      {
                        'type': 'Error',
                        'message': 'Out of Stock.'
                      }
                    ]
                  },
                  'status': false
                },
                'pickup': {
                  'messages': null,
                  'status': true
                },
                'messages': null
              }
            }

          }
        ]
      },
      totalNumRecs:11,
      messages: null
    };
    let actionCreator = {
      type: getServiceType( 'saveForLater', 'success' ),
      data
    }
    let expectedOutput = {
      itemEligibilityDetails:{
        '123':{
          isItemAvailable:false,
          messages:[[], [], []],
          shipEntireOrder:false
        }
      },
      saveForLaterItems: [
        {
          sflItemId:'123',
          'eligibilityStatus': {
            'addToBag': {
              'ship': {
                'messages': {
                  'items': [
                    {
                      'type': 'Error',
                      'message': 'Out of Stock.'
                    }
                  ]
                },
                'status': false
              },
              'pickup': {
                'messages': null,
                'status': true
              },
              'messages': null
            }
          }

        }
      ],
      saveForLaterQuantity:11,
      showViewMoreOption:true
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set showSpinner flag as true for the removed SFL item on saveForLaterItemRemove loading action ', () => {
    const data = 'gi101920006';
    let actionCreator = {
      type: getServiceType( 'saveForLaterItemRemove', 'loading' ),
      data
    }
    let state = {
      saveForLaterItems:[
        {
          sflItemId:'gi101920006'
        },
        {
          sflItemId:'gi101920001'
        }
      ]
    }
    let expectedOutput = {
      saveForLaterItems: [
        {
          sflItemId:'gi101920006',
          displayStatusInfo:{
            showSpinner:true
          }
        },
        {
          sflItemId:'gi101920001'
        }
      ]
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set showSpinner flag as false,transitionMessage and showTransitionComponent as true for the removed SFL item on SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE action', () => {
    const data = 'gi101920006';
    let actionCreator = {
      type:SHOW_SAVE_FOR_LATER_REMOVED_SUCCESS_MESSAGE,
      data
    }
    let state = {
      saveForLaterItems:[
        {
          sflItemId:'gi101920006'
        },
        {
          sflItemId:'gi101920001'
        }
      ]
    }
    let expectedOutput = {
      saveForLaterItems: [
        {
          sflItemId:'gi101920006',
          displayStatusInfo:{
            showSpinner:false,
            showTransitionComponent:true,
            transitionMessage: formatMessage( SaveForLaterItemsMessages.removeSaveForLaterLabel )
          }
        },
        {
          sflItemId:'gi101920001'
        }
      ]
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should remove for the removed SFL item from saveForLaterItems list on saveForLaterItemRemove success action ', () => {
    const data = {
      saveForLaterItems:{
        items:[
          {
            sflItemId:'gi101920006'
          }
        ]
      }
    }
    let actionCreator = {
      type:getServiceType( 'saveForLaterItemRemove', 'success' ),
      data
    }
    let state = {
      saveForLaterItems:[
        {
          sflItemId:'gi101920006'
        },
        {
          sflItemId:'gi101920001'
        }
      ]
    }
    let expectedOutput = {
      saveForLaterItems: [
        {
          sflItemId:'gi101920001'
        }
      ]
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set showSpinner flag as true for the SFL item moved to bag on moveToBagFromSaveForLater loading action ', () => {
    const data = 'gi101920006';
    let actionCreator = {
      type: getServiceType( 'moveToBagFromSaveForLater', 'loading' ),
      data
    }
    let state = {
      saveForLaterItems:[
        {
          sflItemId:'gi101920006'
        },
        {
          sflItemId:'gi101920001'
        }
      ]
    }
    let expectedOutput = {
      saveForLaterItems: [
        {
          sflItemId:'gi101920006',
          displayStatusInfo:{
            showSpinner:true
          }
        },
        {
          sflItemId:'gi101920001'
        }
      ]
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should set showSpinner flag as false, transitionMessage and showTransitionComponent for the SFL item moved to bag on SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE action', () => {
    const data = {
      sflItemId:'gi101920006',
      success:true
    }
    let actionCreator = {
      type:SHOW_MOVED_TO_BAG_SUCCESS_MESSAGE,
      data
    }
    let state = {
      saveForLaterItems:[
        {
          sflItemId:'gi101920006',
          'eligibilityStatus': {
            'addToBag': {
              'ship': {
                'messages': {
                  'items': [
                    {
                      'type': 'Error',
                      'message': 'Out of Stock.'
                    }
                  ]
                },
                'status': false
              },
              'pickup': {
                'messages': null,
                'status': true
              },
              'messages': null
            }
          }
        },
        {
          sflItemId:'gi101920001',
          'eligibilityStatus': {
            'addToBag': {
              'ship': {
                'messages': {
                  'items': [
                    {
                      'type': 'Error',
                      'message': 'Out of Stock.'
                    }
                  ]
                },
                'status': false
              },
              'pickup': {
                'messages': null,
                'status': true
              },
              'messages': null
            }
          }
        }
      ]
    }
    let expectedOutput = {
      saveForLaterItems: [
        {
          sflItemId:'gi101920006',
          displayStatusInfo:{
            showSpinner:false,
            showTransitionComponent:true,
            transitionMessage: formatMessage( SaveForLaterItemsMessages.moveToBagFromSaveForLaterLabel )
          },
          'eligibilityStatus': {
            'addToBag': {
              'ship': {
                'messages': {
                  'items': [
                    {
                      'type': 'Error',
                      'message': 'Out of Stock.'
                    }
                  ]
                },
                'status': false
              },
              'pickup': {
                'messages': null,
                'status': true
              },
              'messages': null
            }
          }
        },
        {
          sflItemId:'gi101920001',
          'eligibilityStatus': {
            'addToBag': {
              'ship': {
                'messages': {
                  'items': [
                    {
                      'type': 'Error',
                      'message': 'Out of Stock.'
                    }
                  ]
                },
                'status': false
              },
              'pickup': {
                'messages': null,
                'status': true
              },
              'messages': null
            }
          }
        }
      ]
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should remove SFL item from saveForLaterItems list on moveToBagFromSaveForLater success action ', () => {
    const data = {
      saveForLater: {
        saveForLaterItems:{
          items:[
            {
              sflItemId:'gi101920006',
              'eligibilityStatus': {
                'addToBag': {
                  'ship': {
                    'messages':null,
                    'status': true
                  },
                  'pickup': {
                    'messages': null,
                    'status': true
                  },
                  'messages': null
                }
              }
            }
          ]
        }
      },
      cart:{
        deliveryOption:'ship'
      }
    }
    let actionCreator = {
      type:getServiceType( 'moveToBagFromSaveForLater', 'success' ),
      data
    }
    let state = {
      itemEligibilityDetails:{
        'gi101920006':{
          isItemAvailable:true,
          messages:[[], [], []],
          shipEntireOrder:true
        }
      },
      deliveryOption:'ship',
      saveForLaterItems:[
        {
          sflItemId:'gi101920006'
        },
        {
          sflItemId:'gi101920001'
        }
      ]
    }
    let expectedOutput = {
      itemEligibilityDetails:{
        'gi101920006':{
          isItemAvailable:true,
          messages:[[], [], []],
          shipEntireOrder:true
        }
      },
      deliveryOption:'ship',
      saveForLaterItems: [
        {
          sflItemId:'gi101920001'
        }
      ]
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should return concated saveForLaterItems when saveForLaterItems in state is empty and action data is not empty', () => {
    const state = {
      saveForLaterItems: []
    }
    const data = {
      movedItems: {
        saveForLater: {
          saveForLaterItems: {
            items: [
              {
                test: 'testData1',
                sflItemId:'123',
                'eligibilityStatus': {
                  'addToBag': {
                    'ship': {
                      'status': false
                    },
                    'pickup': {},
                    'messages': null
                  }
                }
              }
            ]
          }
        }
      }
    };
    let actionCreator = {
      type: MOVE_ITEM_TO_SAVE_FOR_LATER,
      data
    }
    let expectedOutput = {
      itemEligibilityDetails:{
        '123':{
          isItemAvailable:false,
          messages:[[], [], []],
          shipEntireOrder:false
        }
      },
      saveForLaterItems: [
        {
          test: 'testData1',
          sflItemId:'123',
          'eligibilityStatus': {
            'addToBag': {
              'ship': {
                'status': false
              },
              'pickup': {},
              'messages': null
            }
          }
        }
      ]
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should return concated saveForLaterItems when saveForLaterItems in state and action data is not empty', () => {
    const state = {
      saveForLaterItems: [
        {
          test: 'testData'
        }
      ]
    }
    const data = {
      movedItems: {
        saveForLater: {
          saveForLaterItems: {
            items: [
              {
                sflItemId:'123',
                test: 'testData1',
                'eligibilityStatus': {
                  'addToBag': {
                    'ship': {
                      'messages': null,
                      'status': false
                    },
                    'pickup': {
                      'messages': null,
                      'status': true
                    },
                    'messages': null
                  }
                }
              }
            ]
          }
        }
      }
    };
    let actionCreator = {
      type: MOVE_ITEM_TO_SAVE_FOR_LATER,
      data
    }
    let expectedOutput = {
      itemEligibilityDetails:{
        '123':{
          isItemAvailable:false,
          messages:[[], [], []],
          shipEntireOrder:false
        }
      },
      saveForLaterItems: [
        {
          sflItemId:'123',
          test: 'testData1',
          'eligibilityStatus': {
            'addToBag': {
              'ship': {
                'messages': null,
                'status': false
              },
              'pickup': {
                'messages': null,
                'status': true
              },
              'messages': null
            }
          }
        },
        {
          test: 'testData'
        }
      ]
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should return concated saveForLaterItems when saveForLaterItems in action data is empty and action data is empty', () => {
    const state = {
      saveForLaterItems: [
        {
          test: 'testData'
        }
      ]
    }
    const data = {
      movedItems: {
        saveForLater: {
          saveForLaterItems: null
        }
      }
    };
    let actionCreator = {
      type: MOVE_ITEM_TO_SAVE_FOR_LATER,
      data
    }
    let expectedOutput = {
      saveForLaterItems: [
        {
          test: 'testData'
        }
      ]
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should concatenate existing saveForLaterItems in state with the ones passed in action, after removing the duplicate entry if any ', () => {
    const state = {
      saveForLaterItems: [
        {
          sflItemId:'123',
          test: 'testData'
        },
        {
          sflItemId:'234',
          test: 'testData'
        }
      ]
    }
    const data = {
      movedItems: {
        saveForLater: {
          saveForLaterItems: {
            items: [
              {
                sflItemId:'234',
                test: 'testData1',
                'eligibilityStatus': {
                  'addToBag': {
                    'ship': {
                      'messages': {
                        'items': [
                          {
                            'type': 'Error',
                            'message': 'Out of Stock.'
                          }
                        ]
                      },
                      'status': false
                    },
                    'pickup': {
                      'messages': null,
                      'status': true
                    },
                    'messages': null
                  }
                }
              }
            ]
          }
        }
      }
    };
    let actionCreator = {
      type: MOVE_ITEM_TO_SAVE_FOR_LATER, data
    }
    let expectedOutput = {
      itemEligibilityDetails:{
        '234':{
          isItemAvailable:false,
          messages:[[], [], []],
          shipEntireOrder:false
        }
      },
      saveForLaterItems: [
        {
          sflItemId:'234',
          test: 'testData1',
          'eligibilityStatus': {
            'addToBag': {
              'ship': {
                'messages': {
                  'items': [
                    {
                      'type': 'Error',
                      'message': 'Out of Stock.'
                    }
                  ]
                },
                'status': false
              },
              'pickup': {
                'messages': null,
                'status': true
              },
              'messages': null
            }
          }
        },
        {
          sflItemId:'123',
          test: 'testData'
        }
      ]
    };
    expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
  } );

  it( 'should reset current state to initial state for SESSION_TIMEOUT', () => {
    const state = {
      saveForLaterItems: [
        {
          test: 'testData'
        }
      ],
      saveForLaterQuantity: 1
    }

    let actionCreator = {
      type: SESSION_TIMEOUT
    }

    expect( reducer( state, actionCreator ) ).toEqual( initialState );
  } );

  it( 'should reset current state to initial state for logout success', () => {
    const state = {
      saveForLaterItems: [
        {
          test: 'testData'
        }
      ],
      saveForLaterQuantity: 1
    }
    let actionCreator = {
      type: getServiceType( 'logout', 'success' )
    }
    expect( reducer( state, actionCreator ) ).toEqual( initialState );
  } );

  describe( 'updateSFLItemDisplayStatus', () => {
    it( 'updateSFLItemDisplayStatus should return expected SFLItemlist', () => {
      const saveForLaterItems = [
        {
          sflItemId: '123'
        },
        {
          sflItemId: '456'
        }
      ]
      const sflItemId = '123'
      const displayStatusInfo = {
        showSpinner:true
      }

      const expectedSFLItemlist = [
        {
          sflItemId: '123',
          displayStatusInfo : {
            showSpinner:true
          }
        },
        {
          'sflItemId': '456'
        }
      ]
      expect( updateSFLItemDisplayStatus( saveForLaterItems, sflItemId, displayStatusInfo ) ).toEqual( expectedSFLItemlist )
      expect( updateSFLItemDisplayStatus( saveForLaterItems, sflItemId, displayStatusInfo )[0] ).not.toEqual( saveForLaterItems[0] );
    } );
  } );


  describe( 'addItemToSaveForLater', () => {

    it( 'should return concated saveForLaterItems when saveForLaterItems in state is empty and action data is not empty', () => {
      const state = {
        saveForLaterItems: []
      }
      const data = {
        movedItems: {
          saveForLaterItems: {
            items: [
              {
                test: 'testData1',
                sflItemId:'123',
                'eligibilityStatus': {
                  'addToBag': {
                    'ship': {
                      'messages': {
                        'items': [
                          {
                            'type': 'Error',
                            'message': 'Out of Stock.'
                          }
                        ]
                      },
                      'status': false
                    },
                    'pickup': {
                      'messages': null,
                      'status': true
                    },
                    'messages': null
                  }
                }
              }
            ]
          }
        }
      };
      let actionCreator = {
        type: getServiceType( 'addToSaveForLater', 'success' ),
        data
      }
      let expectedOutput = {
        itemEligibilityDetails:{
          '123':{
            isItemAvailable:false,
            messages:[[], [], []],
            shipEntireOrder:false
          }
        },
        saveForLaterItems: [
          {
            test: 'testData1',
            sflItemId:'123',
            'eligibilityStatus': {
              'addToBag': {
                'ship': {
                  'messages': {
                    'items': [
                      {
                        'type': 'Error',
                        'message': 'Out of Stock.'
                      }
                    ]
                  },
                  'status': false
                },
                'pickup': {
                  'messages': null,
                  'status': true
                },
                'messages': null
              }
            }
          }
        ]
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should return concated saveForLaterItems when saveForLaterItems in state and action data is not empty', () => {
      const state = {
        saveForLaterItems: [
          {
            test: 'testData'
          }
        ]
      }
      const data = {
        movedItems: {
          saveForLaterItems: {
            items: [
              {
                sflItemId:'123',
                test: 'testData1',
                'eligibilityStatus': {
                  'addToBag': {
                    'ship': {
                      'messages': {
                        'items': [
                          {
                            'type': 'Error',
                            'message': 'Out of Stock.'
                          }
                        ]
                      },
                      'status': false
                    },
                    'pickup': {
                      'messages': null,
                      'status': true
                    },
                    'messages': null
                  }
                }
              }
            ]
          }
        }
      };
      let actionCreator = {
        type: getServiceType( 'addToSaveForLater', 'success' ),
        data
      }
      let expectedOutput = {
        itemEligibilityDetails:{
          '123':{
            isItemAvailable:false,
            messages:[[], [], []],
            shipEntireOrder:false
          }
        },
        saveForLaterItems: [
          {
            sflItemId:'123',
            test: 'testData1',
            'eligibilityStatus': {
              'addToBag': {
                'ship': {
                  'messages': {
                    'items': [
                      {
                        'type': 'Error',
                        'message': 'Out of Stock.'
                      }
                    ]
                  },
                  'status': false
                },
                'pickup': {
                  'messages': null,
                  'status': true
                },
                'messages': null
              }
            }
          },
          {
            test: 'testData'
          }
        ]
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should return concated saveForLaterItems when saveForLaterItems in action data is empty and action data is empty', () => {
      const state = {
        saveForLaterItems: [
          {
            test: 'testData'
          }
        ]
      }
      const data = {
        movedItems: {
          saveForLaterItems: null
        }
      };
      let actionCreator = {
        type: getServiceType( 'addToSaveForLater', 'success' ),
        data
      }
      let expectedOutput = {
        saveForLaterItems: [
          {
            test: 'testData'
          }
        ]
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should concatenate existing saveForLaterItems in state with the ones passed in action, after removing the duplicate entry if any ', () => {
      const state = {
        saveForLaterItems: [
          {
            sflItemId:'123',
            test: 'testData'
          },
          {
            sflItemId:'234',
            test: 'testData'
          }
        ]
      }
      const data = {
        movedItems: {
          saveForLaterItems: {
            items: [
              {
                sflItemId:'234',
                test: 'testData1',
                'eligibilityStatus': {
                  'addToBag': {
                    'ship': {
                      'messages': {
                        'items': [
                          {
                            'type': 'Error',
                            'message': 'Out of Stock.'
                          }
                        ]
                      },
                      'status': false
                    },
                    'pickup': {
                      'messages': null,
                      'status': true
                    },
                    'messages': null
                  }
                }
              }
            ]
          }
        }
      };
      let actionCreator = {
        type: getServiceType( 'addToSaveForLater', 'success' ),
        data
      }
      let expectedOutput = {
        itemEligibilityDetails:{
          '234':{
            isItemAvailable:false,
            messages:[[], [], []],
            shipEntireOrder:false
          }
        },
        saveForLaterItems: [
          {
            sflItemId:'234',
            test: 'testData1',
            'eligibilityStatus': {
              'addToBag': {
                'ship': {
                  'messages': {
                    'items': [
                      {
                        'type': 'Error',
                        'message': 'Out of Stock.'
                      }
                    ]
                  },
                  'status': false
                },
                'pickup': {
                  'messages': null,
                  'status': true
                },
                'messages': null
              }
            }
          },
          {
            sflItemId:'123',
            test: 'testData'
          }
        ]
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'addToSaveForLater success should set expected saveForLaterQuantity if totalNumRecs is defined', () => {
      const data = {
        movedItems:{
          totalNumRecs: 1,
          saveForLaterItems: {
            items:[
              {
                sflItemId:'234',
                test: 'testData1',
                'eligibilityStatus': {
                  'addToBag': {
                    'ship': {
                      'messages': {
                        'items': [
                          {
                            'type': 'Error',
                            'message': 'Out of Stock.'
                          }
                        ]
                      },
                      'status': false
                    },
                    'pickup': {
                      'messages': null,
                      'status': true
                    },
                    'messages': null
                  }
                }
              }
            ]
          }
        }
      };
      let actionCreator = {
        type:  getServiceType( 'addToSaveForLater', 'success' ),
        data
      }
      let expectedOutput = {
        itemEligibilityDetails:{
          '234':{
            isItemAvailable:false,
            messages:[[], [], []],
            shipEntireOrder:false
          }
        },
        saveForLaterQuantity: 1,
        saveForLaterItems: [
          {
            sflItemId:'234',
            test: 'testData1',
            'eligibilityStatus': {
              'addToBag': {
                'ship': {
                  'messages': {
                    'items': [
                      {
                        'type': 'Error',
                        'message': 'Out of Stock.'
                      }
                    ]
                  },
                  'status': false
                },
                'pickup': {
                  'messages': null,
                  'status': true
                },
                'messages': null
              }
            }
          }
        ]
        ,
        showViewMoreOption: false
      };
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'addToSaveForLater success should not set saveForLaterQuantity if saveForLater is empty', () => {
      const data = {
        movedItems:{
          saveForLaterItems:null
        }
      };
      let actionCreator = {
        type:  getServiceType( 'addToSaveForLater', 'success' ),
        data
      }
      let expectedOutput = {
        saveForLaterQuantity: 0,
        saveForLaterItems: [],
        showViewMoreOption: false,
        itemEligibilityDetails:{}
      };
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput );
    } );

  } );

  describe( 'prepareSFLList', () => {
    it( 'should return expected saveForLaterItems when action is prepend and saveForLaterItems is undefined from initial state', () => {
      const action = 'prepend';
      const newData = {
        saveForLaterItems: {
          items: [
            {
              sflItemId: '1',
              'eligibilityStatus': {
                'addToBag': {
                  'ship': {
                    'messages': null,
                    'status': true
                  },
                  'pickup': {
                    'messages': null,
                    'status': true
                  },
                  'messages': null
                }
              }
            }
          ]
        },
        totalNumRecs: 1
      }

      const expectedOutput = {
        itemEligibilityDetails:{
          '1':{
            isItemAvailable:false,
            messages:[[], [], []],
            shipEntireOrder:false
          }
        },
        saveForLaterItems : [
          {
            sflItemId: '1',
            'eligibilityStatus': {
              'addToBag': {
                'ship': {
                  'messages': null,
                  'status': true
                },
                'pickup': {
                  'messages': null,
                  'status': true
                },
                'messages': null
              }
            }
          }
        ],
        saveForLaterQuantity: 1,
        showViewMoreOption: false
      }
      expect( prepareSFLList( initialState, action, newData ) ).toEqual( expectedOutput );
    } );

    it( 'should return expected saveForLaterItems when action is prepend', () => {
      const state = {
        saveForLaterItems: [
          {
            sflItemId: '1'
          }
        ],
        saveForLaterQuantity: 2,
        showViewMoreOption: false
      }
      const action = 'prepend';
      const newData = {
        saveForLaterItems: {
          items: [
            {
              sflItemId: '2',
              'eligibilityStatus': {
                'addToBag': {
                  'ship': {
                    'status': false
                  },
                  'pickup': {},
                  'messages': null
                }
              }
            }
          ]
        },
        totalNumRecs: 1
      }

      const expectedOutput = {
        itemEligibilityDetails:{
          '2':{
            isItemAvailable:false,
            messages:[[], [], []],
            shipEntireOrder:false
          }
        },
        saveForLaterItems : [
          {
            sflItemId: '2',
            'eligibilityStatus': {
              'addToBag': {
                'ship': {
                  'status': false
                },
                'pickup': {},
                'messages': null
              }
            }
          },
          {
            sflItemId: '1'
          }
        ],
        saveForLaterQuantity: 1,
        showViewMoreOption: false
      }
      expect( prepareSFLList( state, action, newData ) ).toEqual( expectedOutput );
    } );

    it( 'should return expected saveForLaterItems when action is append', () => {
      const state = {
        saveForLaterItems: [
          {
            sflItemId: '1'
          }
        ],
        saveForLaterQuantity: 1,
        showViewMoreOption: false
      }
      const action = 'append';
      const newData = {
        saveForLaterItems: {
          items: [
            {
              sflItemId: '2',
              'eligibilityStatus': {
                'addToBag': {
                  'ship': {
                    'messages': {
                      'items': [
                        {
                          'type': 'Error',
                          'message': 'Out of Stock.'
                        }
                      ]
                    },
                    'status': false
                  },
                  'pickup': {
                    'messages': null,
                    'status': true
                  },
                  'messages': null
                }
              }
            }
          ]
        },
        totalNumRecs: 2,
        deliveryOption:'ship'
      }

      const expectedOutput = {
        itemEligibilityDetails:{
          '2':{
            isItemAvailable:false,
            messages:[[], [], []],
            shipEntireOrder:false
          }
        },
        saveForLaterItems : [
          {
            sflItemId: '1'
          },
          {
            sflItemId: '2',
            'eligibilityStatus': {
              'addToBag': {
                'ship': {
                  'messages': {
                    'items': [
                      {
                        'type': 'Error',
                        'message': 'Out of Stock.'
                      }
                    ]
                  },
                  'status': false
                },
                'pickup': {
                  'messages': null,
                  'status': true
                },
                'messages': null
              }
            }
          }
        ],
        saveForLaterQuantity: 2,
        showViewMoreOption: false
      }
      expect( prepareSFLList( state, action, newData ) ).toEqual( expectedOutput );
    } );

    it( 'should return showViewMoreOption as true when action is append and totalNumRecs in newData is greater than saveForLaterItems length of newData', () => {
      const action = 'append';
      const newData = {
        saveForLaterItems: {
          items: [
            {
              sflItemId: '1',
              'eligibilityStatus': {
                'addToBag': {
                  'ship': {
                    'messages': {
                      'items': [
                        {
                          'type': 'Error',
                          'message': 'Out of Stock.'
                        }
                      ]
                    },
                    'status': false
                  },
                  'pickup': {
                    'messages': null,
                    'status': true
                  },
                  'messages': null
                }
              }
            }
          ]
        },
        deliveryOption:'ship',
        totalNumRecs: 2
      }

      const expectedOutput = {
        itemEligibilityDetails:{
          '1':{
            isItemAvailable:false,
            messages:[[], [], []],
            shipEntireOrder:false
          }
        },
        saveForLaterItems : [
          {
            sflItemId: '1',
            'eligibilityStatus': {
              'addToBag': {
                'ship': {
                  'messages': {
                    'items': [
                      {
                        'type': 'Error',
                        'message': 'Out of Stock.'
                      }
                    ]
                  },
                  'status': false
                },
                'pickup': {
                  'messages': null,
                  'status': true
                },
                'messages': null
              }
            }
          }
        ],
        saveForLaterQuantity: 2,
        showViewMoreOption: true
      }
      expect( prepareSFLList( initialState, action, newData ) ).toEqual( expectedOutput );
    } );

    it( 'should return expected saveForLaterItems when action is remove', () => {
      const state = {
        saveForLaterItems: [
          {
            sflItemId: '1'
          },
          {
            sflItemId: '2'
          }
        ],
        saveForLaterQuantity: 2,
        showViewMoreOption: false
      }
      const action = 'remove';
      const newData = {
        saveForLaterItems: {
          items: [
            {
              sflItemId: '1'
            }
          ]
        },
        totalNumRecs: 1
      }

      const expectedOutput = {
        saveForLaterItems : [
          {
            sflItemId: '2'
          }
        ],
        saveForLaterQuantity: 1,
        showViewMoreOption: false
      }
      expect( prepareSFLList( state, action, newData ) ).toEqual( expectedOutput );
    } );

    it( 'should return empty saveForLaterItems array when action is remove and saveForLaterItems is undefined from initial state', () => {
      const action = 'remove';
      const newData = {
        saveForLaterItems: {
          items: [
            {
              sflItemId: '1'
            }
          ]
        },
        totalNumRecs: 1
      }

      const expectedOutput = {
        saveForLaterItems : [],
        saveForLaterQuantity: 1,
        showViewMoreOption: false,
        itemEligibilityDetails:{}
      }
      expect( prepareSFLList( initialState, action, newData ) ).toEqual( expectedOutput );
    } );

    it( 'should return saveForLaterItems as empty array when saveForLaterItems in newData is null', () => {
      const action = 'prepend';
      const newData = {
        saveForLaterItems: null
      }

      const expectedOutput = {
        itemEligibilityDetails:{},
        saveForLaterItems : [],
        saveForLaterQuantity: 0,
        showViewMoreOption: false
      }
      expect( prepareSFLList( initialState, action, newData ) ).toEqual( expectedOutput );
    } );
  } );
} );

describe( 'handling actions to populate itemEligibilityDetails', () => {
  it( 'should populate itemEligibilityDetails on loadCart Success', () => {

    const state = {
      itemEligibilityDetails:{},
      saveForLaterItems:[{
        sflItemId:'gc001',
        eligibilityStatus:{
          addToBag:{
            status:true,
            messages:null,
            ship:{
              status:true,
              messages:null
            },
            pickup:{
              status:false,
              messages:{
                items:[
                  {
                    message:'pickup unavailable'
                  }
                ]
              }
            }
          }
        }
      }]
    }
    let action = {
      type: getServiceType( 'loadCart', 'success' ),
      data:{ deliveryOption : 'pickup' }
    }

    const updateEligibilityDetails = {
      'gc001':{
        isItemAvailable:false,
        messages:[[], [], [{ message:'pickup unavailable' }]],
        shipEntireOrder:true

      }
    }
    expect( reducer( state, action ).itemEligibilityDetails ).toEqual( updateEligibilityDetails );
  } )
  it( 'should populate itemEligibilityDetails on deliveryOptionsUpdate Success', () => {
    const state = {
      itemEligibilityDetails:{},
      saveForLaterItems:[{
        sflItemId:'gc001',
        eligibilityStatus:{
          addToBag:{
            status:true,
            messages:null,
            ship:{
              status:true,
              messages:null
            },
            pickup:{
              status:false,
              messages:{
                items:[
                  {
                    message:'pickup unavailable'
                  }
                ]
              }
            }
          }
        }
      }]
    }
    let action = {
      type: getServiceType( 'deliveryOptionsUpdate', 'success' ),
      data:{ deliveryOption : 'pickup' }
    }

    const updateEligibilityDetails = {
      'gc001':{
        isItemAvailable:false,
        messages:[[], [], [{ message:'pickup unavailable' }]],
        shipEntireOrder:true

      }
    }
    expect( reducer( state, action ).itemEligibilityDetails ).toEqual( updateEligibilityDetails );
  } )

  it( 'should populate itemEligibilityDetails on pickupStoreInfoUpdate Success', () => {
    const state = {
      itemEligibilityDetails:{},
      saveForLaterItems:[{
        sflItemId:'gc001',
        eligibilityStatus:{
          addToBag:{
            status:true,
            messages:null,
            ship:{
              status:true,
              messages:null
            },
            pickup:{
              status:false,
              messages:{
                items:[
                  {
                    message:'pickup unavailable'
                  }
                ]
              }
            }
          }
        }
      }]
    }
    let action = {
      type: getServiceType( 'pickupStoreInfoUpdate', 'success' ),
      data:{
        storeAvailable:true,
        cartResponse:{
          deliveryOption : 'pickup'
        }
      }
    }

    const updateEligibilityDetails = {
      'gc001':{
        isItemAvailable:false,
        messages:[[], [], [{ message:'pickup unavailable' }]],
        shipEntireOrder:true

      }
    }
    expect( reducer( state, action ).itemEligibilityDetails ).toEqual( updateEligibilityDetails );
  } )

  it( 'should populate itemEligibilityDetails on moveToBagFromSaveForLater Success, when the action failed', () => {
    const state = {
      itemEligibilityDetails:{},
      deliveryOption:'pickup',
      saveForLaterItems:[{
        sflItemId:'gc001',
        eligibilityStatus:{
          addToBag:{
            status:true,
            messages:null,
            ship:{
              status:true,
              messages:null
            },
            pickup:{
              status:true,
              messages:null
            }
          }
        }
      }]
    }
    let action = {
      type: getServiceType( 'moveToBagFromSaveForLater', 'success' ),
      data:{
        cart:null,
        saveForLater:{
          saveForLaterItems:{
            items:[
              {
                sflItemId:'gc001',
                eligibilityStatus:{
                  addToBag:{
                    status:true,
                    messages:null,
                    ship:{
                      status:true,
                      messages:null
                    },
                    pickup:{
                      status:false,
                      messages:{
                        items:[
                          {
                            message:'pickup unavailable'
                          }
                        ]
                      }
                    }
                  }
                }
              }
            ]
          }
        }
      }
    }

    const updateEligibilityDetails = {
      'gc001':{
        isItemAvailable:false,
        messages:[[], [], [{ message:'pickup unavailable' }]],
        shipEntireOrder:true

      }
    }
    expect( reducer( state, action ).itemEligibilityDetails ).toEqual( updateEligibilityDetails );
  } )
} )

describe( 'populateEligibilityDetails', () => {
  it( 'should return itemMessages if there are messages at item level', () => {
    const sflItems = [
      {
        sflItemId:'gc001',
        eligibilityStatus:{
          addToBag:{
            status:true,
            messages:null,
            ship:{
              status:true,
              messages:null
            },
            pickup:{
              status:false,
              messages:{
                items:[
                  {
                    message:'pickup unavailable'
                  }
                ]
              }
            }
          }
        }
      }
    ]
    const updateEligibilityDetails = {
      'gc001':{
        isItemAvailable:false,
        messages:[[], [], [{ message:'pickup unavailable' }]],
        shipEntireOrder:true

      }
    }
    expect( populateEligibilityDetails( {}, sflItems, 'pickup' ) ).toEqual( updateEligibilityDetails );
  } )
  it( 'should return actionMessages if there are messages at action level', () => {
    const sflItems = [
      {
        sflItemId:'gc001',
        eligibilityStatus:{
          addToBag:{
            status:false,
            messages:{
              items:[
                {
                  message:'maximum quantity reached'
                }
              ]
            },
            ship:null,
            pickup:null
          }
        }
      }
    ]
    expect( populateEligibilityDetails( {}, sflItems, 'pickup' )['gc001'].messages[ 1 ] ).toEqual( [{ message:'maximum quantity reached' }] );
  } )

  it( 'should return messages if there are messages at delivery level - ship', () => {
    const sflItems = [
      {
        sflItemId:'gc001',
        eligibilityStatus:{
          addToBag:{
            status:true,
            messages:null,
            ship:{
              status:false,
              messages:{
                items:[
                  {
                    message:'Out of Stock'
                  }
                ]
              }
            },
            pickup:{
              status:true,
              messages:null
            }
          }
        }
      }
    ]
    expect( populateEligibilityDetails( {}, sflItems, 'ship' )['gc001'].messages[ 2 ] ).toEqual( [{ message:'Out of Stock' }] );
  } )

  it( 'should return messages if there are messages at delivery level - pickup', () => {
    const sflItems = [
      {
        sflItemId:'gc001',
        eligibilityStatus:{
          addToBag:{
            status:true,
            messages:null,
            ship:{
              status:true,
              messages:null
            },
            pickup:{
              status:false,
              messages:{
                items:[
                  {
                    message:'pickup unavailable'
                  }
                ]
              }
            }
          }
        }
      }
    ]
    expect( populateEligibilityDetails( {}, sflItems, 'pickup' )['gc001'].messages[ 2 ] ).toEqual( [{ message:'pickup unavailable' }] );
  } )
  it( 'should return isItemAvailble based on if item is available for the deliveryOption', () => {
    const sflItems = [
      {
        sflItemId:'gc001',
        eligibilityStatus:{
          addToBag:{
            status:true,
            messages:null,
            ship:{
              status:true,
              messages:null
            },
            pickup:{
              status:false,
              messages:{
                items:[
                  {
                    message:'pickup unavailable'
                  }
                ]
              }
            }
          }
        }
      }
    ]
    expect( populateEligibilityDetails( {}, sflItems, 'pickup' )['gc001'].isItemAvailable ).toEqual( false );
    expect( populateEligibilityDetails( {}, sflItems, 'ship' )['gc001'].isItemAvailable ).toEqual( true );
  } )

  it( 'should return shipEntireOrder as true if the delivery option is pickup and if it is not available and if the item is available for ship', () => {
    const sflItems = [
      {
        sflItemId:'gc001',
        eligibilityStatus:{
          addToBag:{
            status:true,
            messages:null,
            ship:{
              status:true,
              messages:null
            },
            pickup:{
              status:false,
              messages:{
                items:[
                  {
                    message:'pickup unavailable'
                  }
                ]
              }
            }
          }
        }
      }
    ]
    expect( populateEligibilityDetails( {}, sflItems, 'ship' )['gc001'].shipEntireOrder ).toEqual( false );
    expect( populateEligibilityDetails( {}, sflItems, 'pickup' )['gc001'].shipEntireOrder ).toEqual( true );
  } )
} )

describe( 'getSaveForLaterState', () => {
  it( 'should return SaveForLater state', () => {
    const state = {
      SaveForLater: {
        saveForLaterItems: undefined,
        saveForLaterQuantity: 0,
        showViewMoreOption:false,
        itemEligibilityDetails:{}
      }
    }
    expect( getSaveForLaterState( state ) ).toEqual( state.SaveForLater );
  } )
} )

