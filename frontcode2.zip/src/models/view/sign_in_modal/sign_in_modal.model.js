/**
 * SignInModal Redux reducer Module
 *
 */

import {
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import get from 'lodash/get';
import {
  OPEN_SIGN_IN_MODAL,
  CLOSE_SIGN_IN_MODAL
} from '../../../events/sign_in_modal/sign_in_modal.events';

/**
 * default state for the signInModal reducer
 */
export const initialState = {
  isSignInModalOpen: false, // is used to show/hide sign in modal
  loginSuccessHandler:undefined,
  sourcePage:'',
  redirectPage:false,
  successPath:undefined
}

/**
 * Reducer
 *
 * The reducer is a pure function that takes the previous state and an action, and returns the next state.
 * It should never Mutate its arguments, Perform side effects like API calls and routing transitions;
 * or call non-pure functions, e.g. Date.now( ) or Math.random( ).
 */
export default function reducer( state = initialState, action ){
  switch ( action.type ){
    case OPEN_SIGN_IN_MODAL:
      return {
        ...state,
        isSignInModalOpen:true,
        loginSuccessHandler:action.data.loginSuccessHandler,
        sourcePage: action.data.sourcePage,
        redirectPage: action.data.redirectPage,
        successPath: action.data.successPath
      }

    case CLOSE_SIGN_IN_MODAL:
      return {
        ...state,
        isSignInModalOpen:false
      }
    case getServiceType( 'login', 'success' ):
      return {
        ...state,
        ...( get( action, 'data.res.success' ) && { isSignInModalOpen: false } )
      }
    default:
      return state;

  }
}
