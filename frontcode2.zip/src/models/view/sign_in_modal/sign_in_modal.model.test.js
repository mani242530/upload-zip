import {
  registerServiceName,
  getServiceType
} from 'ulta-fed-core/dist/js/events/services/services.events';
import reducer, {
  initialState
} from './sign_in_modal.model';

import {
  OPEN_SIGN_IN_MODAL,
  CLOSE_SIGN_IN_MODAL
} from '../../../events/sign_in_modal/sign_in_modal.events';


describe( 'SignInModal reducer', () => {

  registerServiceName( 'login' );

  it( 'should have the proper default state', () =>{

    let expectedState = {
      isSignInModalOpen: false,
      loginSuccessHandler:undefined,
      sourcePage:'',
      redirectPage:false,
      successPath:undefined
    };

    expect( initialState ).toEqual( expectedState );
  } );

  it( 'should return the initial state', () => {

    expect( reducer( undefined, {} ) ).toEqual( initialState );
  } );

  describe( 'SignInModal action', () => {

    it( 'should open Sign In Modal if isSignInModalOpen equals true', () => {
      const loginSuccessHandlerMock = jest.fn();
      let actionCreator = {
        type: OPEN_SIGN_IN_MODAL,
        data: {
          isSignInModalOpen:true,
          sourcePage: 'bag/login',
          redirectPage: true,
          successPath: 'bag',
          loginSuccessHandler: loginSuccessHandlerMock
        }
      }
      let expectedOutput1 = {
        isSignInModalOpen:true,
        sourcePage: 'bag/login',
        redirectPage: true,
        successPath: 'bag',
        loginSuccessHandler: loginSuccessHandlerMock
      };
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput1 );
    } );

    it( 'should close Sign In Modal if isSignInModalOpen equals false', () => {
      let actionCreator = {
        type: CLOSE_SIGN_IN_MODAL,
        data: {
          isSignInModalOpen:false
        }
      }
      let expectedOutput1 = {
        isSignInModalOpen:false,
        sourcePage: '',
        redirectPage: false,
        successPath: undefined,
        loginSuccessHandler: undefined
      };
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput1 );
    } );

    it( 'should open Sign In Modal and set sourcePage if the value of isSignInModalOpen equals true and sourcePage is passed in action', () => {
      let actionCreator = {
        type: OPEN_SIGN_IN_MODAL,
        data: {
          isSignInModalOpen:true,
          redirectPage: false,
          sourcePage:{
            action:'Header'
          }
        }
      }
      let expectedOutput1 = {
        isSignInModalOpen:true,
        redirectPage: false,
        sourcePage:{
          action:'Header'
        },
        successPath: undefined
      };
      expect( reducer( initialState, actionCreator ) ).toEqual( expectedOutput1 );
    } );

    it( 'should set isSignInModalOpen as false if action.data.res.success is true', () => {
      const state = {
        isSignInModalOpen: true
      }
      const actionCreator = {
        type: getServiceType( 'login', 'success' ),
        data: {
          res: {
            success: true
          }
        }
      }
      const expectedOutput = {
        isSignInModalOpen: false
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );

    it( 'should set isSignInModalOpen as in state if action.data.res.success is false', () => {
      const state = {
        isSignInModalOpen: true
      }
      const actionCreator = {
        type: getServiceType( 'login', 'success' ),
        data: {
          res: {
            success: false
          }
        }
      }
      const expectedOutput = {
        isSignInModalOpen: true
      };
      expect( reducer( state, actionCreator ) ).toEqual( expectedOutput );
    } );
  } ) ;

} );
