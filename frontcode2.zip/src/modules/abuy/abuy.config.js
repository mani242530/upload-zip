import { mergeConfig } from '../../config';

// Used to overiride or add any config value specific to ABUY
const ABUY_CONFIG = {}

export default mergeConfig( ABUY_CONFIG );
