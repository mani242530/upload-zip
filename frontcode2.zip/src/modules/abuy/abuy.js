/**
 * index.js
 *
 * this is the entry file for the application and is only used for setup code
 *
 */

// Needed for redux-saga es6 generator support
import '@babel/polyfill';
import 'ulta-fed-core/dist/js/theme/theme.css';

// ReactJS specific imports
import React, { Fragment } from 'react';
import { isServer } from 'ulta-fed-core/dist/js/utils/device_detection/device_detection';

// Redux specific imports
import { Provider } from 'react-redux';

// i18n (internationalization) imports
import IntlFormatter from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import {
  Router,
  Route
} from 'react-router-dom';
import LanguageProvider from '../../views/LanguageProvider/LanguageProvider';

// Application component imports
import { translationMessages } from '../../views/LanguageProvider/i18n';
import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import { renderComponent } from '../../utils/dom/dom';
import { setConfig } from '../../utils/ajax/ajax';
import Header from '../../views/Header/Header';
import CreditCards from '../../views/CreditCards/CreditCards';
import Footer from '../../views/Footer/Footer';
import Global from '../../views/Global/Global';
import getHistory from '../../utils/history/history';

import configureStore from './abuy.store';

import CONFIG from './abuy.config';


setConfig( CONFIG );


import shimReady from '../../shared/shim';


const baseRoute = '/creditcards';
export const history = getHistory( baseRoute );

const persistedState = loadState();
const store = configureStore( persistedState, CONFIG );

store.subscribe( () => {
  let state = store.getState();

  saveState( {
    session: state.session,
    // To fix the sticky footer displayed multiple times in same session when switching between REACT page because SFD (Sticky Footer Displayed) session cookie is deleted or not persisting
    // To save & restore emailSignUp sfd session cookie
    emailSignUp: state.esu.stickyEmailSignUp.sessionData,
    searchInputValue: ( state.typeaheadsearch.inputValue || state.reflektionSearch.searchTermValue ),
    // selectedTerm for reflektionSearch is persisted from ReflektionSuggestion when user clicks on category item
    ...( state.reflektionSearch.typeaheadSearchEnabled && { selectedTerm: state.typeaheadsearch.selectedTerm } )
  } );
} );

export const render = ( messages, renderHeader = renderHeaderComponent ) => {

  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Fragment>
          <IntlFormatter/>
          <Global />
        </Fragment>
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-global' )
  );


  // HEADER
  renderComponent()(
    renderHeader( messages ),
    document.getElementById( 'js-mobileHeader' )
  );



  // ( process.env.NODE_ENV === 'production' ) ? '/ui/creditcards' : '/creditcards' ;

  // BODY
  renderComponent()(
    renderMainBodyComponent( messages, store, history ),
    document.getElementById( 'js-mobileBody' )
  );


  // FOOTER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Footer />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileFooter' )
  );
}

// Hot reloadable translation json fiels
if( module.hot ){
  // modules.hot.accept does not accept dynamic dependencies,
  // have to be constants at compile-time
  module.hot.accept( '../../views/LanguageProvider/i18n', () => {
    render( translationMessages );
  } );
}

export const renderMainBodyComponent = ( messages, storeInput, historyInput ) => {
  return (
    <Provider store={ storeInput }>
      <LanguageProvider messages={ messages }>

        <Router
          history={ historyInput }
        >
          <Route
            path='/'
            component={ CreditCards }
          />
        </Router>

      </LanguageProvider>
    </Provider>
  )
}

export const renderHeaderComponent = ( messages ) => {
  return (
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Header history={ history } />
      </LanguageProvider>
    </Provider>
  )
}

// new polyfill for browsers without Intl support
shimReady( () => {
  render( translationMessages )
} );
