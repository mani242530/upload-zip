import { fork } from 'redux-saga/effects';

import createAccount from '../../controllers/create_account/create_account.controller';
import RealtimeOLPS from '../../controllers/realtime_olps/realtime_olps.controller';
import lpslookupbyprescreenid from '../../controllers/lookup_by_prescreen_id/lookup_by_prescreen_id.controller';
import lpslookupsaga from '../../controllers/lps_service/lps_service.controller';
import applyformcreditcardsaga from '../../controllers/apply_form_credit_card/apply_form_credit_card.controller';
import bannersaga from '../../controllers/banner/banner.controller';
import CONFIG from './abuy.config';
import commonSagas from '../shared/common.sagas';
import saga from './abuy.sagas';


describe( 'ABUY sagas', () => {

  const abuySaga = saga();

  it( 'should load all sagas', () => {

    const yieldDescriptor = abuySaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      ...commonSagas( CONFIG ),
      fork( createAccount ),
      fork( bannersaga ),
      fork( applyformcreditcardsaga ),
      fork( lpslookupsaga ),
      fork( lpslookupbyprescreenid ),
      fork( RealtimeOLPS )
    ] ) ) ;

  } );
} );
