/**
 * cart.js
 *
 * this is the entry file for the cart application
 *
 */

// Needed for redux-saga es6 generator support
import '@babel/polyfill';
import 'ulta-fed-core/dist/js/theme/theme.css';

// ReactJS specific imports
import React, { Fragment } from 'react';
import { Provider } from 'react-redux';
import qProtocol from 'ulta-fed-core/dist/js/utils/qprotocol/qprotocol';
import IntlFormatter from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import {
  Router,
  Route
} from 'react-router-dom';
import isEqual from 'lodash/isEqual';
import { translationMessages } from '../../views/LanguageProvider/i18n';
import LanguageProvider from '../../views/LanguageProvider/LanguageProvider';
import { setConfig } from '../../utils/ajax/ajax';
import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import { renderComponent } from '../../utils/dom/dom';
import shimReady from '../../shared/shim';
import { saveUserSessionData } from '../../utils/user_storage/user_storage';


// Redux specific imports

// i18n (internationalization) imports

// Application component imports
import Header from '../../views/Header/Header';
import Footer from '../../views/Footer/Footer';
import LeftNav from '../../views/LeftNav/LeftNav';
import Global from '../../views/Global/Global';
import configureStore from './ccr.store';
import { initialState as footerInitialState } from '../../models/view/footer/footer.model';
import { initialState as headerInitialState } from '../../models/view/header/header.model';
import CartAndCheckoutApp from '../../views/CartAndCheckoutApp/CartAndCheckoutApp';
import getHistory from '../../utils/history/history';

import CONFIG from './ccr.config';
import appConstants from '../../shared/appConstants';


setConfig( CONFIG );


export const history = getHistory();

history.listen( ( location ) =>{
  // whenever route change, qubit pageview variable needs to be reset
  qProtocol.resetPageView();
} );

let persistedState = loadState( );

// set the displaymodes for the header and footer
persistedState = {
  ...persistedState,
  header:{
    ...headerInitialState,
    mobileHeaderDisplayMode: 'no_search'
  },
  footer:{
    ...footerInitialState,
    mobileFooterDisplaymode: 'customerService'
  }
}
const store = configureStore( persistedState, CONFIG );

store.subscribe( () => {
  let state = store.getState();
  saveState( {
    session: state.session,
    // To fix the sticky footer displayed multiple times in same session when switching between REACT page because SFD (Sticky Footer Displayed) session cookie is deleted or not persisting
    // To save & restore emailSignUp sfd session cookie
    emailSignUp: state.esu.stickyEmailSignUp.sessionData,
    searchInputValue: ( state.typeaheadsearch.inputValue || state.reflektionSearch.searchTermValue ),
    // selectedTerm for reflektionSearch is persisted from ReflektionSuggestion when user clicks on category item
    ...( state.reflektionSearch.typeaheadSearchEnabled && { selectedTerm: state.typeaheadsearch.selectedTerm } )
  } );
} );


export const render = ( messages, renderHeader = renderHeaderComponent ) => {

  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Fragment>
          <IntlFormatter/>
          <Global
            isCartPage={ true }
            history={ history }
          />
        </Fragment>
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-global' )
  );


  // HEADER
  renderComponent()(
    renderHeader( messages ),
    document.getElementById( 'js-mobileHeader' )
  );

  // LEFTNAV
  // as we are not giving 'exact' to the route path, the left nav will be rendered for all bag urls
  // which includes bag login and empty bag urls
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Router
          history={ history }
        >
          <Route
            path={ appConstants.ROUTES.BAG_PAGE }
            component={ LeftNav }
          />
        </Router>
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileNav' )
  );

  renderComponent()(
    renderMainBodyComponent( messages, store, history ),
    document.getElementById( 'js-cartpage' )
  );


  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Footer displayShippingPolicy={ true } />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileFooter' )
  );


}

// Hot reloadable translation json fiels
if( module.hot ){
  // modules.hot.accept does not accept dynamic dependencies,
  // have to be constants at compile-time
  module.hot.accept( '../../views/LanguageProvider/i18n', () => {
    render( translationMessages );
  } );
}

export const renderHeaderComponent = ( messages ) => {
  return (
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Header
          history={ history }
          module='checkout'
          displayShippingBanner={ false }
          usePushStateForBagRoute={ true }
        />
      </LanguageProvider>
    </Provider>
  )
}

export const renderMainBodyComponent = ( messages, storeInput, historyInput ) => {
  return (
    <Provider store={ storeInput }>
      <LanguageProvider messages={ messages }>
        <Router
          history={ historyInput }
        >
          <Route
            path='/'
            component={ CartAndCheckoutApp }
          />
        </Router>
      </LanguageProvider>
    </Provider>
  )
}

// new polyfill for browsers without Intl support
shimReady( () => {
  render( translationMessages )
} );
