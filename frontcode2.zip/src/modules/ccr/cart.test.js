import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import { mount } from 'enzyme';
import { translationMessages } from '../../views/LanguageProvider/i18n';
import getHistory from '../../utils/history/history';
import configureStore from './ccr.store';
import CONFIG from './ccr.config';
import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import * as shim from '../../shared/shim';
import {
  history, render, renderHeaderComponent, renderMainBodyComponent
} from './cart';
jest.mock( './../../shared/shim', () => {
  return jest.fn();
} );
jest.mock( '../../utils/local_storage/local_storage', ()=>{
  return {
    loadState:jest.fn(),
    saveState:jest.fn()
  }
} );


describe( 'cart test', () => {

  const history = getHistory();

  it( 'should be able to execute render method without crashing', () => {

    let appElement = document.createElement( 'div' );
    appElement.id = 'js-global';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileHeader';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileNav';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-cartpage';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileFooter';
    document.body.appendChild( appElement );

    render( translationMessages );
    expect( document.getElementById( 'js-mobileHeader' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'js-mobileFooter' ).innerHTML ).not.toBe( '' );

  } );

  it( 'should display left nav if path is bag', () => {

    history.location = {
      pathname:'/bag'
    }
    render( translationMessages );
    expect( document.getElementById( 'js-mobileNav' ).innerHTML ).not.toBe( '' );
  } );

  it( 'should display left nav if path is bag login', () => {

    history.location = {
      pathname:'/bag/login'
    }
    render( translationMessages );
    expect( document.getElementById( 'js-mobileNav' ).innerHTML ).not.toBe( '' );
  } );

  it( 'should display left nav if path is empty bag', () => {

    history.location = {
      pathname:'/bag/empty'
    }
    render( translationMessages );
    expect( document.getElementById( 'js-mobileNav' ).innerHTML ).not.toBe( '' );
  } );

  it( 'should not render left nav if path is not bag', () => {

    history.location = {
      pathname:'/checkout'
    }
    render( translationMessages );
    expect( document.getElementById( 'js-mobileNav' ).innerHTML ).toBe( '' );
  } );

  it( 'should have the value of history same as returned by getHistory', () => {
    expect( history ).toBe( getHistory() );
  } );

  it( 'should invoke renderHeader method when render method is invoked', () => {
    const renderHeaderMock = jest.fn();
    render( translationMessages, renderHeaderMock );
    expect( renderHeaderMock ).toHaveBeenCalled();
  } );

  it( 'should pass usePushStateForBagRoute as true to the Header component', () => {
    expect( mount( renderHeaderComponent( translationMessages ) ).find( 'Header' ).props().usePushStateForBagRoute ).toBe( true );
  } );
  it( 'should pass proper object as paramter to the saveState', () => {
    mount( renderHeaderComponent( translationMessages ) );
    expect( saveState ).toBeCalledWith( expect.objectContaining( { 'searchInputValue':'' } ) );
  } );

  it( 'should pass history as true to the router', () => {
    const store = configureStore( {}, CONFIG );
    const history = {
      location:{
        pathname:'/homePage'
      },
      listen:()=>{}
    }
    const bodyComponent = mount( renderMainBodyComponent( translationMessages, store, history ) );
    expect( bodyComponent.find( 'Router' ).props().history ).toBe( history );
  } );

} );