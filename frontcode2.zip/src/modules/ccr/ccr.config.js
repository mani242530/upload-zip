import { mergeConfig } from '../../config';

// Used to overiride or add any config value specific to CCR
const CCR_CONFIG = {}

export default mergeConfig( CCR_CONFIG );
