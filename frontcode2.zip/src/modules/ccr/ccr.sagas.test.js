import { fork } from 'redux-saga/effects';

import liveChatSaga from '../../controllers/live_chat/live_chat.controller';
import CONFIG from './ccr.config';

import loadCart from '../../controllers/load_cart/load_cart.controller';
import cart from '../../controllers/cart/cart.controller';
import cartPickupInfoUpdate from '../../controllers/cart_pickup_info_update/cart_pickup_info_update.controller';
import pickupStoreInfoUpdate from '../../controllers/pickup_store_info/pickup_store_info.controller';
import gwp from '../../controllers/gift_with_purchase/gift_with_purchase.controller';
import productCellSaga from '../../controllers/product_cell/product_cell.controller';
import productSamplesSaga from '../../controllers/product_samples/product_samples.controller';
import giftWrapSaga from '../../controllers/gift_wrap/gift_wrap.controller';
import coupon from '../../controllers/coupons/coupons.controller';
import checkout, { ccrRedirects } from '../../controllers/checkout/checkout.controller';
import initCart from '../../controllers/init_cart/init_cart.controller';
import shippingUpdate from '../../controllers/shipping_update/shipping_update.controller';
import addressbook from '../../controllers/address_book/address_book.controller';
import afterpayToken from '../../controllers/afterpay_token/afterpay_token.controller';
import afterpay from '../../controllers/afterpay/afterpay.controller';
import saveForLater from '../../controllers/save_for_later/save_for_later.controller';
import saveForLaterItemRemove from '../../controllers/remove_from_save_for_later/remove_from_save_for_later.controller';
import moveToBagFromSaveForLater from '../../controllers/move_to_bag/move_to_bag.controller';
import profileCreditCards from '../../controllers/profile_credit_cards/profile_credit_cards.controller';
import redeemPoints from '../../controllers/redeem_points/redeem_points.controller';
import paymentServiceResponse from '../../controllers/payment_service/payment_service.controller';
import rewardsLookup from '../../controllers/cart_rewards_lookup/cart_rewards_lookup.controller';
import applyPayPalPayment from '../../controllers/apply_paypal_payment/apply_paypal_payment.controller';
import submitOrderService from '../../controllers/submit_order/submit_order.controller';
import applyExpressPayPalPayment from '../../controllers/apply_express_paypal_payment/apply_express_paypal_payment.controller';
import estimatedDeliveryDate from '../../controllers/estimated_delivery_date/estimated_delivery_date.controller';
import RealtimeOLPS from '../../controllers/realtime_olps/realtime_olps.controller';
import userRewards from '../../controllers/user_rewards/user_rewards.controller';
import PaypalToken from '../../controllers/paypal_token/paypal_token.controller';
import paymentsCCKey from '../../controllers/payments_cc_key/payments_cc_key.controller';
import pickupStores from '../../controllers/pickup_stores/pickup_stores.controller';


import multipleItemsAdd from '../../controllers/add_multiple_items_to_bag/add_multiple_items_to_bag.controller';
import deliveryOptionsUpdate from '../../controllers/delivery_options/delivery_options.controller';
import pickupContactInfoUpdate from '../../controllers/pickup_contact_info/pickup_contact_info.controller';
import moveToSaveForLater from '../../controllers/move_to_save_for_later/move_to_save_for_later.controller';
import addToSaveForLater from '../../controllers/add_to_save_for_later/add_to_save_for_later.controller';
import commonSagas from '../shared/common.sagas';
import saga from './ccr.sagas';
import removeBagUpdateMessage from '../../controllers/remove_bag_update_message/remove_bag_update_message';


describe( 'CCR sagas', () => {

  const ccrSaga = saga();

  it( 'should load all sagas', () => {

    const yieldDescriptor = ccrSaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      ...commonSagas( CONFIG ),
      fork( loadCart( CONFIG ) ),
      fork( cart( CONFIG ) ),
      fork( deliveryOptionsUpdate ),
      fork( cartPickupInfoUpdate( CONFIG ) ),
      fork( pickupStoreInfoUpdate ),
      fork( gwp ),
      fork( productCellSaga ),
      fork( productSamplesSaga ),
      fork( giftWrapSaga ),
      fork( coupon ),
      fork( checkout ),
      fork( ccrRedirects ),
      fork( initCart ),
      fork( shippingUpdate ),
      fork( addressbook ),
      fork( afterpayToken ),
      fork( afterpay ),
      fork( saveForLater( CONFIG ) ),
      fork( saveForLaterItemRemove ),
      fork( moveToBagFromSaveForLater ),
      fork( profileCreditCards ),
      fork( redeemPoints ),
      fork( paymentServiceResponse ),
      fork( rewardsLookup ),
      fork( applyPayPalPayment ),
      fork( submitOrderService ),
      fork( applyExpressPayPalPayment ),
      fork( estimatedDeliveryDate ),
      fork( userRewards ),
      fork( RealtimeOLPS ),
      fork( PaypalToken ),
      fork( paymentsCCKey ),
      fork( pickupStores ),
      fork( multipleItemsAdd() ),
      fork( pickupContactInfoUpdate ),
      fork( liveChatSaga ),
      fork( moveToSaveForLater( CONFIG ) ),
      fork( addToSaveForLater( CONFIG ) ),
      fork( removeBagUpdateMessage )
    ] ) );

  } );

} );
