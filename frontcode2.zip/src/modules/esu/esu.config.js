import { mergeConfig } from '../../config';

const ESU_CONFIG = {

  DEBUGGING: {
    USER: {
      isSignedIn: false
    },
    ESU: {
      DISABLE_ON_SAME_SESSION: false,
      isNewUserOptIn: false,
      isErrorMessage: false
    }
  },
  ENABLE_QUBIT: false,
  ENABLE_REFLEKTION: false,

  SERVICES: {

    subscribe: '/services/v1/user/emailSubscribe'

  }
}

export default mergeConfig( ESU_CONFIG );
