
/**
 * stickyemailsignup.js
 *
 * this is the entry file for the sticky footer email signup application and is only used for setup code
 *
 */

// Needed for redux-saga es6 generator support
import '@babel/polyfill';

// ReactJS specific imports
import React, { Fragment } from 'react';

// Redux specific imports
import { Provider } from 'react-redux';

// i18n (internationalization) imports

import isUndefined from 'lodash/isUndefined';

// Application component imports
import IntlFormatter from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import HeroCarousel from 'ulta-fed-core/dist/js/views/HeroCarousel/HeroCarousel';
import LanguageProvider from '../../views/LanguageProvider/LanguageProvider';
import { translationMessages } from '../../views/LanguageProvider/i18n';
import { initialState as defaultCarouselData } from '../../models/view/hero_carousel/hero_carousel.model';

import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';


import { setConfig } from '../../utils/ajax/ajax';
import Global from '../../views/Global/Global';
setConfig( CONFIG );

import { renderComponent } from '../../utils/dom/dom';
import CONFIG from './esu.config';
import configureStore from './esu.store';
import StickyEmailSignUp from '../../views/StickyEmailSignUp/StickyEmailSignUp';
import shimReady from '../../shared/shim';

let persistedState = loadState();

// Store into the reducer that the carousel data list from window object
if( isUndefined( persistedState ) ){
  persistedState = {
    heroCarousel: defaultCarouselData
  }
}
else {
  persistedState.heroCarousel = defaultCarouselData;
}

if( !isUndefined( window.heroCarouselList ) ){
  persistedState.heroCarousel.carouselList = window.heroCarouselList;
}

const store = configureStore( persistedState, CONFIG );

store.subscribe( () => {
  let state = store.getState();

  saveState( {
    session: state.session,
    emailSignUp: state.esu.stickyEmailSignUp.sessionData
  } );
} )

export const render = ( messages ) => {
  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Fragment>
          <IntlFormatter/>
          <Global />
        </Fragment>
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-global' )
  );

  // HeroCarousel
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <HeroCarousel />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-heroCarousel' )
  );

  // STICKY EMAIL SIGNUP FOOTER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <StickyEmailSignUp config={ CONFIG } />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-stickyEmailSignUpFooter' )
  );
}

// Hot reloadable translation json fiels
if( module.hot ){
  // modules.hot.accept does not accept dynamic dependencies,
  // have to be constants at compile-time
  module.hot.accept( '../../views/LanguageProvider/i18n', () => {
    render( translationMessages );
  } );
}

// new polyfill for browsers without Intl support
shimReady( () => {
  render( translationMessages )
} );
