/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 **/

// import { fromJS } from 'immutable';
import { combineReducers } from 'redux';
import has from 'lodash/has';
import {
  reducer as formReducer,
  actionTypes as formActionTypes
} from 'redux-form';

import _ from 'lodash';
import global from '../../models/view/global/global.model';
import session from '../../models/view/session/session.model';
import user from '../../models/view/user/user.model';
import language from '../../models/view/language/language.model';
import esu from '../../models/view/email_sign_up/email_sign_up.model';

import asyncReducers, {
  removeUnregisteredFormValue
} from './esu.reducers';
// import reducers that are globally required in the ULTA app
//
describe( 'ESU reducer', ( ) => {

  it( 'should be a function', ( ) => {
    expect( _.isFunction( asyncReducers ) ).toBe( true );
  } );

  it( 'should return the combineReducers', ( ) => {
    expect( asyncReducers().toString ).toEqual( combineReducers( {
      global,
      session,
      user,
      language,
      esu,
      form: formReducer,
      ...asyncReducers
    } ).toString )
  } );

  it( 'should return the state if the action is not for unregistering a field', ( ) => {
    let actionCreator = {
      type: 'test',
      payload:{
        name:'test'
      }
    }

    let state = {
      values: {
        Field1:'test',
        Field2:'test',
        Field3:'test'
      }
    }

    expect( removeUnregisteredFormValue( state, actionCreator ) ).toEqual( state );

  } );

  it( 'should remove unregistered field', ( ) => {
    let actionCreator = {
      type: formActionTypes.UNREGISTER_FIELD,
      payload:{
        name:'Field1'
      }
    }

    let state = {
      values: {
        Field1:'test',
        Field2:'test',
        Field3:'test'
      }
    }

    let expectedOutput = {
      values: {
        Field2:'test',
        Field3:'test'
      }
    }

    expect( removeUnregisteredFormValue( state, actionCreator ) ).toEqual( expectedOutput );

  } );

} );