
import CONFIG from './esu.config';
import commonSagas from '../shared/common.sagas'


export default function*(){
  yield[
    ...commonSagas( CONFIG )
  ]
}