import CONFIG from './esu.config';
import commonSagas from '../shared/common.sagas';
import saga from './esu.sagas';

describe( 'esu sagas', () => {

  const esuSaga = saga();

  it( 'should load all sagas', () => {

    const yieldDescriptor = esuSaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      ...commonSagas( CONFIG )
    ] ) );

  } );

} );

