import { translationMessages } from '../../views/LanguageProvider/i18n';
import { render } from './esu';
import * as shim from '../../shared/shim';

jest.mock( './../../shared/shim', () => {
  return jest.fn();
} );

describe( 'esu test', () => {

  it( 'should be able to execute render method without crashing', () => {
    let appElement = document.createElement( 'div' );
    appElement.id = 'js-global';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-heroCarousel';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-stickyEmailSignUpFooter';
    document.body.appendChild( appElement );

    render( translationMessages );
    expect( document.getElementById( 'js-stickyEmailSignUpFooter' ).innerHTML ).not.toBe( '' );

  } );
} );