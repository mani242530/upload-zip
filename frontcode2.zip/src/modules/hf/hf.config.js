import { mergeConfig } from '../../config';

const HF_CONFIG = {

  DEBUGGING: {
    USER: {
      isSignedIn: false
    }
  }
}

export default mergeConfig( HF_CONFIG );