/**
 * external.js
 *
 * this is the entry file for the application and is only used for setup code
 *
 */

// Needed for redux-saga es6 generator support
import '@babel/polyfill';
import 'ulta-fed-core/dist/js/theme/theme.css';

// ReactJS specific imports
import React, { Fragment } from 'react';

// Redux specific imports
import { Provider } from 'react-redux';

// i18n (internationalization) imports

// Application component imports
import IntlFormatter from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { updateDataLayer } from 'ulta-fed-core/dist/js/utils/omniture/omniture';
import { fullyQualifyLink, host } from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import merge from 'lodash/merge';
import { translationMessages } from '../../views/LanguageProvider/i18n';
import LanguageProvider from '../../views/LanguageProvider/LanguageProvider';
import getHistory from '../../utils/history/history';
import { renderComponent } from '../../utils/dom/dom';


import { setConfig } from '../../utils/ajax/ajax';
setConfig( CONFIG );

import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import CONFIG from './hf.config';
import configureStore from './hf.store';
import Footer from '../../views/Footer/Footer'
import LeftNav from '../../views/LeftNav/LeftNav';
import Header from '../../views/Header/Header';
import Global from '../../views/Global/Global';
import shimReady from '../../shared/shim';


let store;
export const history = getHistory();

export const render = ( messages, renderHeader = renderHeaderComponent ) => {

  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Fragment>
          <IntlFormatter/>
          <Global />
        </Fragment>
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'ulta-global' )
  );

  // HEADER
  renderComponent()(
    renderHeader( messages ),
    document.getElementById( 'ulta-Header' )
  );

  // LEFTNAV
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <LeftNav />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'ulta-Nav' )
  );

  // FOOTER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Footer />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'ulta-Footer' )
  );

  // Default Omniture page data
  if( typeof globalPageData !== 'undefined' ){
    if( globalPageData.navigation.pageName === '' ){
      var btPage = document.getElementsByTagName( 'title' )[0].innerHTML.toLowerCase();
      var pageData = { 'globalPageData':{ 'navigation': { 'pageName':btPage, 'channel':btPage } } };
      updateDataLayer( pageData );
    }
  }

}

export const renderHeaderComponent = ( messages ) => {
  return (
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Header history={ history } />
      </LanguageProvider>
    </Provider>
  )
}

export const initialState = {
  header: {
    mobileHeaderDisplayMode: 'no_search',
    desktopHeaderDisplayMode: {
      displaySearchBar: true,
      displayLinks: true,
      displayMiniCartIcon: true,
      displayMiniCartFlyout: true,
      displayShippingBanner: true,
      isReactPage: true,
      isHeaderSticky:true
    },
    shippingBanner: {
      message: undefined,
      url: '/'
    },
    cartPageShippingBanner: {
      message: undefined
    }
  },
  footer: {
    mobileFooterDisplayMode: 'default',
    desktopFooterDisplayMode: 'default',
    footerNavCollapse: {
      contactus: false,
      orders: false,
      samples: false,
      gifts: false,
      coupons: false
    }
  }
}

export const getHeaderFooterConfiguration = () => {

  let headerFooterScript = document.getElementById( 'uhfjs' );

  if( headerFooterScript === null && process.env.NODE_ENV === 'test' ){
    // this code will make sure that the script element is in place for unit test scripts
    // in the production environment the script element will be loaded by the index.html file
    let appElement = document.createElement( 'div' );
    appElement.id = 'uhfjs';
    appElement.setAttribute( 'data-mobile-header', 'default' );
    appElement.setAttribute( 'data-mobile-footer', 'default' );
    appElement.setAttribute( 'data-desktop-header', 'default' );
    appElement.setAttribute( 'data-desktop-footer', 'default' );
    appElement.setAttribute( 'data-nav', 'default' );
    document.body.appendChild( appElement );
    headerFooterScript = appElement;
  }

  if( headerFooterScript.hasAttribute( 'data-mobile-header' ) ){
    const mHeader = headerFooterScript.getAttribute( 'data-mobile-header' );
    if( ['default', 'focused', 'no_search'].includes( mHeader ) ){
      initialState.header.mobileHeaderDisplayMode = mHeader;
    }
  }
  if( headerFooterScript.hasAttribute( 'data-mobile-footer' ) ){
    const mFooter = headerFooterScript.getAttribute( 'data-mobile-footer' );
    if( ['default', 'customerService'].includes( mFooter ) ){
      initialState.footer.mobileFooterDisplayMode = mFooter;
    }
  }
  if( headerFooterScript.hasAttribute( 'data-desktop-header' ) ){
    const dHeader = headerFooterScript.getAttribute( 'data-desktop-header' );
    if( ['default'].includes( dHeader ) ){
      initialState.header.desktopHeaderDisplayMode = {
        displaySearchBar: true,
        displayLinks: true,
        displayMiniCartIcon: true,
        displayMiniCartFlyout: true,
        displayShippingBanner: true,
        isHeaderSticky:true,
        displayLeftNav: true
      };
    }
    if( ['focused'].includes( dHeader ) ){
      initialState.header.desktopHeaderDisplayMode = {
        displayLeftNav: false,
        displaySearchBar: false,
        displayLinks: false,
        displayMiniCartIcon: true,
        displayMiniCartFlyout: false,
        displayShippingBanner: false,
        isHeaderSticky:false
      };
    }
  }
  if( headerFooterScript.hasAttribute( 'data-desktop-footer' ) ){
    const dFooter = headerFooterScript.getAttribute( 'data-desktop-footer' );
    if( ['default', 'customerService', 'none'].includes( dFooter ) ){
      initialState.footer.desktopFooterDisplayMode = dFooter;
    }
  }
  if( headerFooterScript.hasAttribute( 'data-nav' ) ){
    const dNav = ( headerFooterScript.getAttribute( 'data-nav' ).toLowerCase() === 'true' );
    initialState.header.desktopHeaderDisplayMode.displayLeftNav = dNav;
  }

  // To fix static page content for the desktop header, calculate the header height if available and set a top margin, otherwise use the default 60px;
  var hdrHeight = 60;
  var desktopHeaderDiv = document.getElementsByClassName( 'DesktopHeader__StickyHeader' )[0];
  if( desktopHeaderDiv ){
    hdrHeight = desktopHeaderDiv.clientHeight;
  }
  var tagStyle = document.createElement( 'style' );
  // Disable displaying header/leftnav/footer for mobile app webview
  if( document.cookie.indexOf( 'isNativeApp' ) !== -1 ){
    var hideElements = document.createTextNode( '#ulta-Header, #ulta-Nav, #ulta-Footer { display: none; }' );
    tagStyle.appendChild( hideElements );
  }
  var styleDef = document.createTextNode( '@media all and (min-width: 992px){ #ulta-Body { margin-top: ' + hdrHeight + 'px; } }' );
  tagStyle.appendChild( styleDef );
  document.getElementsByTagName( 'head' )[0].appendChild( tagStyle );

  store = configureStore( merge( initialState, loadState() ), CONFIG );
  store.subscribe( () => {
    let state = store.getState();

    saveState( {
      session: state.session,
      // To fix the sticky footer displayed multiple times in same session when switching between REACT page because SFD (Sticky Footer Displayed) session cookie is deleted or not persisting
      // To save & restore emailSignUp sfd session cookie
      emailSignUp: state.esu.stickyEmailSignUp.sessionData,
      searchInputValue: ( state.typeaheadsearch.inputValue || state.reflektionSearch.searchTermValue ),
      // selectedTerm for reflektionSearch is persisted from ReflektionSuggestion when user clicks on category item
      ...( state.reflektionSearch.typeaheadSearchEnabled && { selectedTerm: state.typeaheadsearch.selectedTerm } )
    } );

    return state;
  } );

  // Hot reloadable translation json fiels
  if( module.hot ){
    // modules.hot.accept does not accept dynamic dependencies,
    // have to be constants at compile-time
    module.hot.accept( '../../views/LanguageProvider/i18n', () => {
      render( translationMessages );
    } );
  }

  // new polyfill for browsers without Intl support
  shimReady( () => {
    render( translationMessages )
  } );

}

getHeaderFooterConfiguration();
