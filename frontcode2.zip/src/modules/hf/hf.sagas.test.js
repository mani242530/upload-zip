
import CONFIG from './hf.config';
import commonSagas from '../shared/common.sagas';
import saga from './hf.sagas';


describe( 'hf sagas', () => {

  const hfSaga = saga();

  it( 'should load all sagas', () => {

    const yieldDescriptor = hfSaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      ...commonSagas( CONFIG )
    ] ) );

  } );

} );