
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import { translationMessages } from '../../views/LanguageProvider/i18n';
import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import {
  render, getHeaderFooterConfiguration, initialState, renderHeaderComponent, history
} from './hf';
import * as shim from '../../shared/shim';
jest.mock( './../../shared/shim', () => {
  return jest.fn();
} );
jest.mock( '../../utils/local_storage/local_storage', ()=>{
  return {
    loadState:jest.fn(),
    saveState:jest.fn()
  }
} );
describe( 'external test', () => {

  it( 'should be able to execute render method without crashing', () => {

    let appElement = document.createElement( 'div' );
    appElement.id = 'ulta-global';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'ulta-Header';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'ulta-Nav';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'ulta-Body';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'ulta-Footer';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'title' );
    document.body.appendChild( appElement );

    render( translationMessages );

    expect( document.getElementById( 'ulta-global' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'ulta-Header' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'ulta-Nav' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'ulta-Footer' ).innerHTML ).not.toBe( '' );

  } );

  it( 'should set displayLeftNav to true if the data-nav attribute is set to true', () => {

    let appElement1 = document.getElementById( 'uhfjs' );
    appElement1.setAttribute( 'data-nav', 'true' );
    getHeaderFooterConfiguration();

    expect( initialState.header.desktopHeaderDisplayMode.displayLeftNav ).toBe( true );

  } );

  it( 'should set displayLeftNav to false if the data-nav attribute is set to false', () => {

    let appElement1 = document.getElementById( 'uhfjs' );
    appElement1.setAttribute( 'data-nav', 'false' );
    getHeaderFooterConfiguration();

    expect( initialState.header.desktopHeaderDisplayMode.displayLeftNav ).toBe( false );

  } );

  it( 'should set display: none on ulta-Header, ulta-Nav and ulta-Footer for webview', () => {
    document.cookie = 'isNativeApp=true';

    let appElement1 = document.getElementById( 'ulta-Header' );
    appElement1.style.display = 'none';
    expect( window.getComputedStyle( appElement1, null ) ).toHaveProperty( '_values.display', 'none' );

    let appElement2 = document.getElementById( 'ulta-Nav' );
    appElement2.style.display = 'none';
    expect( window.getComputedStyle( appElement2, null ) ).toHaveProperty( '_values.display', 'none' );

    let appElement3 = document.getElementById( 'ulta-Footer' );
    appElement3.style.display = 'none';
    expect( window.getComputedStyle( appElement3, null ) ).toHaveProperty( '_values.display', 'none' );

  } );

  it( 'should set a top margin on ulta-Body equal to the header height', () => {

    let appElement1 = document.getElementById( 'ulta-Body' );
    appElement1.style.marginTop = '60px';

    expect( window.getComputedStyle( appElement1, null ) ).toHaveProperty( '_values.margin-top', '60px' );

  } );

  it( 'should pass proper object as parameter to the saveState', () => {
    render( translationMessages ) ;
    expect( saveState ).toBeCalledWith( expect.objectContaining( { 'searchInputValue':'' } ) );
  } );

  it( 'should invoke renderHeader method when render method is invoked', () => {
    const renderHeaderMock = jest.fn();
    render( translationMessages, renderHeaderMock );
    expect( renderHeaderMock ).toHaveBeenCalled();
  } );

  it( 'should pass history as true to the Header component', () => {
    expect( mount( renderHeaderComponent( translationMessages ) ).find( 'Header' ).props().history ).toBe( history );
  } );

} );
