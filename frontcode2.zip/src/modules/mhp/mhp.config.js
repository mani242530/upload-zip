import { mergeConfig } from '../../config';

const MHP_CONFIG = {

  DEBUGGING: {
    LOGGING: {
      enableMesobaseLogs:false
    },

    ESU: {
      DISABLE_ON_SAME_SESSION: false,
      isNewUserOptIn: true,
      isErrorMessage: false
    }
  },
  ENABLE_MESOBASE: true,

  MESOBASE_CONFIG:{
    comId: 2997,
    msgCampId: 60398,
    tid: 60405
  },

  SERVICES: {

    subscribe: '/services/v1/user/emailSubscribe'

  },
  MOBILE_BREAK_POINT:768
}

export default mergeConfig( MHP_CONFIG );
