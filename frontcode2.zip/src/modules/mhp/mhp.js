/**
 * index.js
 *
 * this is the entry file for the application and is only used for setup code
 *
 */

// Needed for redux-saga es6 generator support
import '@babel/polyfill';
import 'ulta-fed-core/dist/js/theme/theme.css';
// ReactJS specific imports
import React, { Fragment } from 'react';
import isUndefined from 'lodash/isUndefined';



// Redux specific imports
import { Provider } from 'react-redux';
import IntlFormatter from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import HeroCarousel from 'ulta-fed-core/dist/js/views/HeroCarousel/HeroCarousel';

import {
  Router,
  Route
} from 'react-router-dom';
import { translationMessages } from '../../views/LanguageProvider/i18n';
import LanguageProvider from '../../views/LanguageProvider/LanguageProvider';
import { initialState as globalInitialState } from '../../models/view/global/global.model';
import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import { initialState as defaultCarouselData } from '../../models/view/hero_carousel/hero_carousel.model';
import { initialState as headerInitialState } from '../../models/view/header/header.model';
import { setConfig } from '../../utils/ajax/ajax';
import { renderComponent } from '../../utils/dom/dom';
import shimReady from '../../shared/shim';
import getHistory from '../../utils/history/history';


// Redux specific imports

// i18n (internationalization) imports

// Application component imports
import Header from '../../views/Header/Header';
import LeftNav from '../../views/LeftNav/LeftNav';
import MobileHomePage from '../../views/MobileHomepage/MobileHomepage';
import Footer from '../../views/Footer/Footer';
import Global from '../../views/Global/Global';
import StickyEmailSignUp from '../../views/StickyEmailSignUp/StickyEmailSignUp';
import configureStore from './mhp.store';



import CONFIG from './mhp.config';
import ESUCONFIG from '../esu/esu.config';

setConfig( CONFIG );

export const history = getHistory();

export const updatePersistedState = ( persistedState ) => {

  let updatedPersistedState = persistedState;
  // Store into the reducer that the carousel data list from window object
  if( isUndefined( updatedPersistedState ) ){
    updatedPersistedState = {
      heroCarousel: defaultCarouselData
    }
  }
  else {
    updatedPersistedState.heroCarousel = defaultCarouselData;
  }

  if( !isUndefined( window.heroCarouselList ) ){
    updatedPersistedState.heroCarousel.carouselList = window.heroCarouselList;
  }


  updatedPersistedState.header = {
    ...headerInitialState,
    ...updatedPersistedState.header,
    desktopHeaderDisplayMode:{
      ...headerInitialState.desktopHeaderDisplayMode,
      ...( updatedPersistedState.header && updatedPersistedState.header.desktopHeaderDisplayMode ),
      displayLeftNav:false
    }
  }

  updatedPersistedState.global = {
    ...globalInitialState,
    ...updatedPersistedState.global,
    mobileWidth:CONFIG.MOBILE_BREAK_POINT,
    isMobileDevice:window.innerWidth < CONFIG.MOBILE_BREAK_POINT
  }

  return updatedPersistedState;
}

let persistedState = loadState();

persistedState = updatePersistedState( persistedState );

if( document.getElementById( 'loginForm' ) && document.getElementById( 'loginForm' )._dynSessConf && persistedState.session ){
  persistedState.session.secureToken = document.getElementById( 'loginForm' )._dynSessConf.value
}

const store = configureStore( persistedState, CONFIG );

store.subscribe( () => {
  let state = store.getState();

  saveState( {
    session: state.session,
    emailSignUp: state.esu.stickyEmailSignUp.sessionData,
    searchInputValue: ( state.typeaheadsearch.inputValue || state.reflektionSearch.searchTermValue ),
    // selectedTerm for reflektionSearch is persisted from ReflektionSuggestion when user clicks on category item
    ...( state.reflektionSearch.typeaheadSearchEnabled && { selectedTerm: state.typeaheadsearch.selectedTerm } )
  } );
} )

export const render = ( messages, renderHeader = renderHeaderComponent ) => {

  // if the page is requested from mobile app ( not site ), then the header and footer should not be displayed
  if( document.cookie.indexOf( 'isNativeApp' ) !== -1 ){
    document.getElementById( 'js-mobileHeader' ).style.display = 'none';
    document.getElementById( 'js-mobileFooter' ).style.display = 'none';
  }
  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Fragment>
          <IntlFormatter/>
          <Global />
        </Fragment>
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-global' )
  );


  // HEADER
  renderComponent()(
    renderHeader( messages ),
    document.getElementById( 'js-mobileHeader' )
  );

  // LEFTNAV
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <LeftNav />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileNav' )
  );


  // BODY
  if( document.getElementById( 'js-mobileBody' ) ){
    renderComponent()(
      renderMainBodyComponent( messages, store, history ),
      document.getElementById( 'js-mobileBody' )
    );
  }

  // FOOTER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Footer />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileFooter' )
  );

  if( document.getElementById( 'js-heroCarousel' ) ){
    // HeroCarousel
    renderComponent()(
      <Provider store={ store }>
        <LanguageProvider messages={ messages }>
          <HeroCarousel />
        </LanguageProvider>
      </Provider>,
      document.getElementById( 'js-heroCarousel' )
    );
  }

  // STICKY EMAIL SIGNUP FOOTER
  if( document.getElementById( 'js-stickyEmailSignUpFooter' ) ){
    renderComponent()(
      <Provider store={ store }>
        <LanguageProvider messages={ messages }>
          <StickyEmailSignUp config={ ESUCONFIG }/>
        </LanguageProvider>
      </Provider>,
      document.getElementById( 'js-stickyEmailSignUpFooter' )
    );
  }
}

// Hot reloadable translation json fiels
if( module.hot ){
  // modules.hot.accept does not accept dynamic dependencies,
  // have to be constants at compile-time
  module.hot.accept( '../../views/LanguageProvider/i18n', () => {
    render( translationMessages );
  } );
}

export const renderHeaderComponent = ( messages ) => {
  return (
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Header
          enableQubitBasketEvents={ true }
          history={ history }
        />
      </LanguageProvider>
    </Provider>
  )
}

export const renderMainBodyComponent = ( messages, storeInput, historyInput ) => {
  return (
    <Provider store={ storeInput }>
      <LanguageProvider messages={ messages }>
        <Router
          history={ historyInput }
        >
          <Route
            path='/'
            render={
              ( props ) => {
                return (
                  <MobileHomePage />
                )
              }
            }
          />
        </Router>
      </LanguageProvider>
    </Provider>
  )
}

// new polyfill for browsers without Intl support
shimReady( () => {
  render( translationMessages )
} );
