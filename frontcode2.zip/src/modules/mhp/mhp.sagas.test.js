import { fork } from 'redux-saga/effects';

import CONFIG from './mhp.config';
import commonSagas from '../shared/common.sagas';

import saga from './mhp.sagas';


describe( 'MHP sagas', () => {

  const mhpSaga = saga();

  it( 'should load all sagas', () => {

    const yieldDescriptor = mhpSaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      ...commonSagas( CONFIG )
    ] ) )

  } );

} );
