import React from 'react';
import { Provider } from 'react-redux';
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import { mount } from 'enzyme';
import { translationMessages } from '../../views/LanguageProvider/i18n';
import { initialState as defaultCarouselData } from '../../models/view/hero_carousel/hero_carousel.model';
import * as rendering from '../../utils/dom/dom';
import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import CONFIG from './mhp.config';
import Header from '../../views/Header/Header';
import configureStore from './mhp.store';
import {
  render, renderHeaderComponent, renderMainBodyComponent, history, updatePersistedState
} from './mhp';
import * as shim from '../../shared/shim';
jest.mock( './../../shared/shim', () => {
  return jest.fn();
} );
jest.mock( '../../utils/local_storage/local_storage', ()=>{
  return {
    loadState:jest.fn(
      ()=> {
        return {}
      }
    ),
    saveState:jest.fn()
  }
} );

const store = configureStore( {}, CONFIG );

describe( 'mhp test', () => {

  it( 'should be able to execute render method without crashing', () => {
    let appElement = document.createElement( 'div' );
    appElement.id = 'js-global';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileHeader';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileNav';
    document.body.appendChild( appElement );


    appElement = document.createElement( 'div' );
    appElement.id = 'js-stickyEmailSignUpFooter';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileFooter';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-heroCarousel';
    document.body.appendChild( appElement );

    render( translationMessages );
    expect( document.getElementById( 'js-mobileHeader' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'js-mobileFooter' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'js-heroCarousel' ).innerHTML ).not.toBe( '' );

  } );

  it( 'should set display property as none for header and footer in native app', () => {
    document.cookie = 'isNativeApp=true';
    render( translationMessages );
    expect( document.getElementById( 'js-mobileHeader' ).style.display ).toBe( 'none' );
    expect( document.getElementById( 'js-mobileFooter' ).style.display ).toBe( 'none' );
  } );

  it( 'should update persistedState with data specific to jsp pages', () => {
    window.heroCarouselList = [
      {
        colorHtmlTag: '#69c2b5',
        name: 'WK47_ROTATOR 1 ANASTASIA',
        imageAlt: '',
        url: '//images.ulta.com/is/image/Ulta/wk4717_d_hero_promo_makeup_anastasia?scl=1',
        link: {
          showInNewPage: false,
          name: 'Dynamic Link',
          linkText: '',
          label: null,
          url: '/modern-renaissance-eyeshadow-palette?productId=xlsImpprod14291015',
          dataSlotPosition: '1_wk4717_d_hero_promo_makeup_anastasia'
        }
      }
    ];
    const persistedState = updatePersistedState( {} );
    expect( persistedState.heroCarousel ).toEqual( {
      ...defaultCarouselData,
      carouselList:window.heroCarouselList
    } );
    expect( persistedState.header.desktopHeaderDisplayMode.displayLeftNav ).toBe( false );
    expect( persistedState.global.mobileWidth ).toBe( 768 );
  } );


  it( 'should update persistedState while retaining the existing data in persistedState', () => {

    const persistedStateState = {
      header:{
        shippingBanner:{
          message:'shipping is free'
        }

      },
      global:{
        switchData:{
          switches:{
            enableQubit:true
          }
        }
      }
    }
    const updatedPersistedState = updatePersistedState( persistedStateState );
    expect( updatedPersistedState.header.desktopHeaderDisplayMode.displayLeftNav ).toBe( false );
    expect( updatedPersistedState.global.mobileWidth ).toBe( 768 );
    expect( updatedPersistedState.header.shippingBanner ).toEqual( persistedStateState.header.shippingBanner );
    expect( updatedPersistedState.global.switchData ).toEqual( persistedStateState.global.switchData );
  } );

  describe( 'mobileBody', () => {

    let spy = jest.spyOn( rendering, 'renderComponent' );

    beforeEach( () => {
      spy.mockClear();
    } );

    it( 'should render the mobile body if the mobileBody div exists', () => {

      let appElement = document.createElement( 'div' );
      appElement.id = 'js-mobileBody';
      document.body.appendChild( appElement );
      render( translationMessages );
      expect( spy ).toHaveBeenCalledTimes( 7 );


    } );

    it( 'should not render the mobile body if the mobileBody does not exists', () => {

      document.getElementById( 'js-mobileBody' ).remove();

      render( translationMessages );
      expect( spy ).toHaveBeenCalledTimes( 6 );

    } );

    it( 'should invoke renderHeader method when render method is invoked', () => {
      const renderHeaderMock = jest.fn();
      render( translationMessages, renderHeaderMock );
      expect( renderHeaderMock ).toHaveBeenCalled();
    } );

    it( 'should pass enableQubitBasketEvents as true to the Header component', () => {
      expect( mount( renderHeaderComponent( translationMessages ) ).find( 'Header' ).props().enableQubitBasketEvents ).toBe( true );
    } );

    it( 'should pass history as true to the Header component', () => {
      expect( mount( renderHeaderComponent( translationMessages ) ).find( 'Header' ).props().history ).toBe( history );
    } );

    it( 'should pass proper object as paramter to the saveState', () => {
      render( translationMessages ) ;
      expect( saveState ).toBeCalledWith( expect.objectContaining( { 'searchInputValue':'' } ) );
    } );

    it( 'should pass history as true to the router', () => {
      const history = {
        location:{
          pathname:'/homePage'
        },
        listen:()=>{}
      }
      const bodyComponent = mount( renderMainBodyComponent( translationMessages, store, history ) );
      expect( bodyComponent.find( 'Router' ).props().history ).toBe( history );
    } );

  } );
} );
