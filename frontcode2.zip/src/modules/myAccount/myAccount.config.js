import { mergeConfig } from '../../config';

// Used to overiride or add any config value specific to MYACCOUNT
const MYACCOUNT_CONFIG = {}

export default mergeConfig( MYACCOUNT_CONFIG );