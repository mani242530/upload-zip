import { combineReducers } from 'redux';
import {
  reducer as formReducer,
  actionTypes as formActionTypes
} from 'redux-form';
import _ from 'lodash';

import global from '../../models/view/global/global.model';
import session from '../../models/view/session/session.model';
import user from '../../models/view/user/user.model';
import language from '../../models/view/language/language.model';
import pagedata from '../../models/view/page/page.model';
import header from '../../models/view/header/header.model';
import footer from '../../models/view/footer/footer.model';
import cart from '../../models/view/cart/cart.model';
import esu from '../../models/view/email_sign_up/email_sign_up.model';
import mobileLeftNav from '../../models/view/mobile_left_nav/mobile_left_nav.model';
import typeaheadsearch from '../../models/view/type_ahead_search/type_ahead_search.model';
import miniBag from '../../models/view/mini_cart/mini_cart.model';
import signInModal from '../../models/view/sign_in_modal/sign_in_modal.model';
import account from '../../models/view/account/account.model';
import reflektionSearch from '../../models/view/reflektion_search/reflektion_search.model';

import asyncReducers, {
  removeUnregisteredFormValue
} from './myAccount.reducers';

describe( 'myAccount reducer', ( ) => {

  it( 'should be a function', ( ) => {
    expect( _.isFunction( asyncReducers ) ).toBe( true );
  } );

  it( 'should return the combineReducers', ( ) => {
    expect( asyncReducers().toString ).toEqual( combineReducers( {
      global,
      session,
      user,
      language,
      pagedata,
      header,
      footer,
      cart,
      esu,
      mobileLeftNav,
      typeaheadsearch,
      miniBag,
      form: formReducer,
      signInModal,
      account,
      reflektionSearch,
      ...asyncReducers
    } ).toString )
  } );

  it( 'should return the state if the action is not for unregistering a field', ( ) => {
    const actionCreator = {
      type: 'test',
      payload:{
        name:'Field1'
      }
    };

    const state = {
      values: {
        Field1:'test',
        Field2:'test'
      }
    };

    expect( removeUnregisteredFormValue( state, actionCreator ) ).toEqual( state );
  } );

  it( 'should remove unregistered field', ( ) => {
    const actionCreator = {
      type: formActionTypes.UNREGISTER_FIELD,
      payload:{
        name:'Field1'
      }
    };

    const state = {
      values: {
        Field1:'test',
        Field2:'test',
        Field3:'test'
      }
    };

    const expectedOutput = {
      values: {
        Field2:'test',
        Field3:'test'
      }
    };

    expect( removeUnregisteredFormValue( state, actionCreator ) ).toEqual( expectedOutput );
  } );
} );