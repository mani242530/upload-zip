import CONFIG from './myAccount.config';
import commonSagas from '../shared/common.sagas';


export default function*(){
  yield[
    ...commonSagas( CONFIG )
  ]
}
