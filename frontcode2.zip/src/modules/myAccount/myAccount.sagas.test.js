

import CONFIG from './myAccount.config';
import commonSagas from '../shared/common.sagas';

import saga from './myAccount.sagas';

describe( 'myAccount sagas', () => {

  const myAccountSaga = saga();

  it( 'should load all sagas', () => {
    const yieldDescriptor = myAccountSaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      ...commonSagas( CONFIG )
    ] ) ) ;
  } );
} );