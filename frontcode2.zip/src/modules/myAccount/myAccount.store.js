/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 */

import createReducer from './myAccount.reducers';

// Import global Sagas
import sagas from './myAccount.sagas';
import { setupStore } from '../shared/store';


export default function configureStore( initialState = {}, CONFIG ){

  const store = setupStore( initialState, CONFIG, sagas, createReducer );


  if( module.hot ){
    module.hot.accept( './myAccount.reducers', () => {
      import( './myAccount.reducers' ).then( ( reducerModule ) => {
        const createReducers = reducerModule.default;
        const nextReducers = createReducers( store.asyncReducers );

        store.replaceReducer( nextReducers );
      } );
    } );
  }

  return store;
}
