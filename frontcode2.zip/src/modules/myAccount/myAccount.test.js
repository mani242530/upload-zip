import React from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import { MemoryRouter } from 'react-router-dom';
import { translationMessages } from '../../views/LanguageProvider/i18n';
import {
  render, history, renderHeaderComponent, renderMainBodyComponent
} from './myAccount';
import getHistory from '../../utils/history/history';
import { saveState } from '../../utils/local_storage/local_storage';
import configureStore from './myAccount.store'
import CONFIG from './myAccount.config';
import LeftNav from '../../views/LeftNav/LeftNav';
import Global from '../../views/Global/Global';
import MyAccount from '../../views/MyAccount/MyAccount';
import Footer from '../../views/Footer/Footer';

jest.mock( './../../shared/shim', () => {
  return jest.fn();
} );
jest.mock( '../../utils/local_storage/local_storage', ()=>{
  return {
    loadState:jest.fn( () => {
      return {
        session:{
          activeSession: true
        },
        esu:{
          stickyEmailSignUp: {
            sessionData: {
              isStickyFooterDisplay: false
            }
          }
        },
        typeaheadsearch: {
          inputValue: 'test input value',
          selectedTerm: 'makeUp>lipStick'
        },
        reflektionSearch: {
          typeaheadSearchEnabled: true
        }
      }
    } ),
    saveState:jest.fn()
  }
} );

const store = configureStore( {}, CONFIG );

describe( 'myAccount', () => {
  it( 'should be able to execute render method without crashing', () => {
    let appElement = document.createElement( 'div' );
    appElement.id = 'js-global';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileHeader';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileNav';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-myAccountPage';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileFooter';
    document.body.appendChild( appElement );

    render( translationMessages );
    expect( document.getElementById( 'js-global' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'js-mobileHeader' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'js-mobileNav' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'js-myAccountPage' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'js-mobileFooter' ).innerHTML ).not.toBe( '' );
  } );

  it( 'should render Global component', () => {
    const component = mountWithIntl(
      <Provider store={ store }>
        <Global />
      </Provider>
    );
    const expectedOutput = component.find( 'Global' ).html();
    expect( document.getElementById( 'js-global' ).innerHTML ).toBe( expectedOutput );
  } );

  it( 'should render LeftNav component', () => {
    const component = mountWithIntl(
      <Provider store={ store }>
        <LeftNav />
      </Provider>
    );
    const expectedOutput = component.find( 'LeftNav' ).at( 0 ).html();
    expect( document.getElementById( 'js-mobileNav' ).innerHTML ).toBe( expectedOutput );
  } );

  it( 'should render MyAccount component', () => {
    const component = mountWithIntl(
      <Provider store={ store }>
        <MemoryRouter>
          <MyAccount />
        </MemoryRouter>
      </Provider>
    );
    const expectedOutput = component.find( 'MyAccount' ).html();
    expect( document.getElementById( 'js-myAccountPage' ).innerHTML ).toBe( expectedOutput );
  } );

  it( 'should render Footer component', () => {
    const component = mountWithIntl(
      <Provider store={ store }>
        <Footer />
      </Provider>
    );
    const expectedOutput = component.find( 'Footer' ).html();
    expect( document.getElementById( 'js-mobileFooter' ).innerHTML ).toBe( expectedOutput );
  } );

  it( 'should render Header component and pass history as prop', () => {
    const headerComponent = mount( renderHeaderComponent( translationMessages ) ).find( 'Header' );
    expect( headerComponent.length ).toBe( 1 );
    expect( headerComponent.props().history ).toBe( history );
  } );

  it( 'should have the value of history same as returned by getHistory', () => {
    expect( history ).toBe( getHistory() );
  } );

  it( 'should pass proper object as paramter to the saveState', () => {
    const expectedData = {
      session:{
        activeSession: true
      },
      emailSignUp: {
        isStickyFooterDisplay: false
      },
      searchInputValue: 'test input value',
      selectedTerm: 'makeUp>lipStick'
    }
    expect( saveState ).toBeCalledWith( expectedData );
  } );

  it( 'should invoke renderHeader method when render method is invoked', () => {
    const renderHeaderMock = jest.fn();
    render( translationMessages, renderHeaderMock );
    expect( renderHeaderMock ).toHaveBeenCalledWith( translationMessages );
  } );

  it( 'should pass history as true to the router', () => {
    const history = {
      location:{
        pathname:'/homePage'
      },
      listen:()=>{}
    }
    const bodyComponent = mount( renderMainBodyComponent( translationMessages, store, history ) );
    expect( bodyComponent.find( 'Router' ).props().history ).toBe( history );
  } );


} );