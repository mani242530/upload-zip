import { mergeConfig } from '../../config';

const PDP_CONFIG = {

  DEBUGGING: {
    PRODUCT: {
      onSale: true,
      eligibilityState:0
    }
  },
  OLAPIC_API_KEY: '35184924054d51039371a49df9c02bcda4613a636f7cb5223a0f08a19f9a0185',

  SCENE7_FLYOUTVIEWER:{
    SCENE7_CONTAINER :'scene7Container',
    SCENE7_ZOOM_CONTAINER :'scene7MobileContainer',
    SCENE7_URL : '//s7d1.scene7.com/s7viewers/html5/js/FlyoutViewer.js',
    SCENE7_ZOOM_URL : '//s7d1.scene7.com/s7viewers/html5/js/ZoomViewer.js',
    IMAGE_SERVER_URL : '//images.ulta.com/is/image/',
    SCENE7_STYLE_URL : '../../ui/static/css/scene7.css',
    SCENE7_CONFIG_PATH : 'Ulta/PDP_Flyout'
  },

  LOGIN_REDIRECT_URL:'ulta/myaccount/login.jsp?loginSuccessAppUrl=',
  FACEBOOK_SHARE_URL:'https://www.facebook.com/sharer/sharer.php',
  TWITTER_URL:'https://twitter.com/intent/tweet',
  PINTEREST_URL:'https://pinterest.com/pin/create/button/',

  ACCESS_TOKEN:'pk.eyJ1Ijoic3dlZXRpcSIsImEiOiJjamdlMWZ4cnozZTJ6MnFzMDhpZXVwaDR5In0.gnizgEdqMS1-mpCYP7TBTw'
}

export default mergeConfig( PDP_CONFIG );
