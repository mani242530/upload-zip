/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 **/

// import { fromJS } from 'immutable';
import { combineReducers } from 'redux';
import {
  reducer as formReducer,
  actionTypes as formActionTypes
} from 'redux-form';

import global from '../../models/view/global/global.model';
import session from '../../models/view/session/session.model';
import user from '../../models/view/user/user.model';
import language from '../../models/view/language/language.model';
import pagedata from '../../models/view/page/page.model';
import latLong from '../../models/view/lat_long/lat_long.model';
import miniBag from '../../models/view/mini_cart/mini_cart.model';
import header from '../../models/view/header/header.model';
import footer from '../../models/view/footer/footer.model';
import esu from '../../models/view/email_sign_up/email_sign_up.model';
import cart from '../../models/view/cart/cart.model';
import typeaheadsearch from '../../models/view/type_ahead_search/type_ahead_search.model';
import mobileLeftNav from '../../models/view/mobile_left_nav/mobile_left_nav.model';
import productPage from '../../models/view/product_page/product_page.model';
import findInStore from '../../models/view/find_in_store/find_in_store.model';
import addtobag from '../../models/view/add_to_bag/add_to_bag.model';
import quickShop from '../../models/view/quick_shop/quick_shop.model';
import reflektionSearch from '../../models/view/reflektion_search/reflektion_search.model';
import signInModal from '../../models/view/sign_in_modal/sign_in_modal.model';


// import reducers that are globally required in the ULTA app
//
export const removeUnregisteredFormValue  = ( state, action )=> {
  if( action.type !== formActionTypes.UNREGISTER_FIELD ){
    return state;
  }

  const { values: { [action.payload.name]: unregistered, ...values } } = state;
  return { ...state, values }

};

export default ( asyncReducers ) => {
  return combineReducers( {
    global,
    session,
    user,
    language,
    header,
    footer,
    esu,
    cart,
    mobileLeftNav,
    typeaheadsearch,
    reflektionSearch,
    productPage,
    miniBag,
    findInStore,
    addtobag,
    quickShop,
    latLong,
    pagedata,
    form: formReducer,
    signInModal,
    ...asyncReducers
  } )

}
