import { fork } from 'redux-saga/effects';


import CONFIG from './pdp.config';
import productdetails from '../../controllers/product_detail/product_detail.controller';
import emailNotification from '../../controllers/email_notification/email_notification.controller';
import storeDetail from '../../controllers/store_details/store_details.controller';
import storeProductAvailability from '../../controllers/store_product_availability/store_product_availability.controller';
import commonSagas from '../shared/common.sagas';
// All sagas to be loaded
// sessionSAGA must be the first in the list
export default function*(){
  yield[
    // SHARED Module
    ...commonSagas( CONFIG ),
    fork( productdetails( CONFIG ) ),
    fork( emailNotification( CONFIG ) ),
    // Header Footer Module
    fork( storeDetail ),
    fork( storeProductAvailability )
  ]
}
