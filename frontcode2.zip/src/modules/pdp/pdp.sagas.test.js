import { fork } from 'redux-saga/effects';

import CONFIG from './pdp.config';
import productdetails from '../../controllers/product_detail/product_detail.controller';
import emailNotification from '../../controllers/email_notification/email_notification.controller';
import storeDetail from '../../controllers/store_details/store_details.controller';
import storeProductAvailability from '../../controllers/store_product_availability/store_product_availability.controller';
import commonSagas from '../shared/common.sagas';

import saga from './pdp.sagas';


describe( 'PDP sagas', () => {

  const pdpSaga = saga();

  it( 'should load all sagas', () => {

    const yieldDescriptor = pdpSaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      ...commonSagas( CONFIG ),
      fork( productdetails( CONFIG ) ),
      fork( emailNotification( CONFIG ) ),
      fork( storeDetail ),
      fork( storeProductAvailability )
    ] ) ) ;

  } );
} );
