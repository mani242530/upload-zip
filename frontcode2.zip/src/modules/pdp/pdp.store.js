/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 */

import createReducer from './pdp.reducers';

// Import global Sagas
import sagas from './pdp.sagas';
import { setupStore } from '../shared/store';

export default function configureStore( initialState = {}, CONFIG ){

  const store = setupStore( initialState, CONFIG, sagas, createReducer );


  if( module.hot ){
    module.hot.accept( './pdp.reducers', () => {
      import( './pdp.reducers' ).then( ( reducerModule ) => {
        const createReducers = reducerModule.default;
        const nextReducers = createReducers( store.asyncReducers );

        store.replaceReducer( nextReducers );
      } );
    } );
  }

  return store;

}
