import React from 'react';
import { Provider } from 'react-redux';
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import { translationMessages } from '../../views/LanguageProvider/i18n';
import getHistory from '../../utils/history/history';
import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import configureStore from './pdp.store';
import Header from '../../views/Header/Header';
import {
  render, renderHeaderComponent, renderMainBodyComponent, history
} from './pdp';
import CONFIG from './pdp.config';
import * as shim from '../../shared/shim';
jest.mock( './../../shared/shim', () => {
  return jest.fn();
} );
jest.mock( '../../utils/local_storage/local_storage', ()=>{
  return {
    loadState:jest.fn(),
    saveState:jest.fn()
  }
} );

const store = configureStore( {}, CONFIG );


describe( 'pdp test', () => {

  it( 'should be able to execute render method without crashing', () => {

    let appElement = document.createElement( 'div' );
    appElement.id = 'js-global';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileHeader';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileNav';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileBody';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-mobileFooter';
    document.body.appendChild( appElement );

    render( translationMessages );
    expect( document.getElementById( 'js-mobileHeader' ).innerHTML ).not.toBe( '' );
    expect( document.getElementById( 'js-mobileFooter' ).innerHTML ).not.toBe( '' );
  } );

  it( 'should display the mobile view in noSearchMode', () => {
    expect( document.getElementsByClassName( 'navigation__item__noSearchmode' ).length ).toBe( 1 );
  } );

  it( 'should have the value of history same as returned by getHistory', () => {
    expect( history ).toBe( getHistory() );
  } );

  it( 'should pass proper object as paramter to the saveState', () => {
    render( translationMessages ) ;
    expect( saveState ).toBeCalledWith( expect.objectContaining( { 'searchInputValue':'' } ) );
  } );

  it( 'should invoke renderHeader method when render method is invoked', () => {
    const renderHeaderMock = jest.fn();
    render( translationMessages, renderHeaderMock );
    expect( renderHeaderMock ).toHaveBeenCalled();
  } );

  it( 'should pass history as true to the Header component', () => {
    expect( mount( renderHeaderComponent( translationMessages ) ).find( 'Header' ).props().history ).toBe( history );
  } );

  it( 'should pass history as true to the router', () => {
    const history = {
      location:{
        pathname:'/homePage'
      },
      listen:()=>{}
    }
    const bodyComponent = mount( renderMainBodyComponent( translationMessages, store, history ) );
    expect( bodyComponent.find( 'Router' ).props().history ).toBe( history );
  } );

} );
