import { mergeConfig } from '../../config';

const PWR_CONFIG = {

  DEBUGGING: {
    USER: {
      isSignedIn: false
    }
  },
  ENABLE_REFLEKTION: false,
  SERVICES: {

    resetCredential: '/services/v5/user/validatePasswordReset',

    resetPasswordReqest: '/services/v5/user/resetPassword',

    forgotUserName: '/services/v5/user/forgotUserName',

    validateAndResetPasswordRequest: '/services/v5/user/password/update'
  }
}

export default mergeConfig( PWR_CONFIG );