/* eslint no-console: ["error", { allow: ["warn", "error", "log"] }] */
/**
 * pdp.js
 *
 * this is the entry file for the pdp application
 *
 */

// Needed for redux-saga es6 generator support
import '@babel/polyfill';
import 'ulta-fed-core/dist/js/theme/theme.css';


// ReactJS specific imports
import React, { Fragment } from 'react';
import { Provider } from 'react-redux';
import IntlFormatter from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import {
  Router,
  Route
} from 'react-router-dom';
import LanguageProvider from '../../views/LanguageProvider/LanguageProvider';
import { translationMessages } from '../../views/LanguageProvider/i18n';
import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import { setConfig } from '../../utils/ajax/ajax';
import { renderComponent } from '../../utils/dom/dom';
import shimReady from '../../shared/shim';
import getHistory from '../../utils/history/history';


// Redux specific imports

// i18n (internationalization) imports

// Application component imports
import Header from '../../views/Header/Header';
import LeftNav from '../../views/LeftNav/LeftNav';
import Footer from '../../views/Footer/Footer';
import Global from '../../views/Global/Global';
import ResetPassword from '../../views/ResetPassword/ResetPassword';
import configureStore from './pwr.store';
import CONFIG from './pwr.config';


setConfig( CONFIG );

export const history = getHistory();

export const getPasswordResetBaseRoute = () =>{
  // we are using /pwr on localhost to route the requests to the index.html inside pwr folder
  // for other environments the appropriate urls are mapped to the index.html in the apache web server
  return process.env.NODE_ENV === 'development' ? '/pwr/' : '/' ;
}




let persistedState = loadState();


const store = configureStore( persistedState, CONFIG );

store.subscribe( () => {
  let state = store.getState();

  saveState( {
    session: state.session,
    // To fix the sticky footer displayed multiple times in same session when switching between REACT page because SFD (Sticky Footer Displayed) session cookie is deleted or not persisting
    // To save & restore emailSignUp sfd session cookie
    searchInputValue: ( state.typeaheadsearch.inputValue || state.reflektionSearch.searchTermValue ),
    // selectedTerm for reflektionSearch is persisted from ReflektionSuggestion when user clicks on category item
    ...( state.reflektionSearch.typeaheadSearchEnabled && { selectedTerm: state.typeaheadsearch.selectedTerm } )
  } );
} );

let passwordResetRoute  = getPasswordResetBaseRoute() ;

export const render = ( messages, renderHeader = renderHeaderComponent ) => {

  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Fragment>
          <IntlFormatter/>
          <Global />
        </Fragment>
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-global' )
  );

  // HEADER
  renderComponent()(
    renderHeader( messages ),
    document.getElementById( 'js-mobileHeader' )
  );

  // LEFTNAV
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Router
          history={ history }
        >
          <Route
            path={ `${passwordResetRoute}forgot-password-sent` }
            component={ LeftNav }
          />
        </Router>
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileNav' )
  );

  // PAGE CONTENT
  renderComponent()(
    renderMainBodyComponent( messages, store, history ),
    document.getElementById( 'js-mobileBody' )
  );

  // FOOTER
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Footer displayShippingPolicy={ true }/>
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-mobileFooter' )
  );
}

// Hot reloadable translation json fiels
if( module.hot ){
  // modules.hot.accept does not accept dynamic dependencies,
  // have to be constants at compile-time
  module.hot.accept( '../../views/LanguageProvider/i18n', () => {
    render( translationMessages );
  } );
}

export const renderHeaderComponent = ( messages ) => {
  return (
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Header history={ history } />
      </LanguageProvider>
    </Provider>
  )
}

export const renderMainBodyComponent = ( messages, storeInput, historyInput ) => {
  return (
    <Provider store={ storeInput }>
      <LanguageProvider messages={ messages }>
        <Router
          history={ historyInput }
        >
          <Route
            path='/'
            render={
              ( props ) => {
                return (
                  <ResetPassword
                    { ...props }
                    passwordResetBaseRoute={ passwordResetRoute }
                  />
                )
              }
            }
          />
        </Router>
      </LanguageProvider>
    </Provider>
  )
}

// new polyfill for browsers without Intl support
shimReady( () => {
  render( translationMessages )
} );
