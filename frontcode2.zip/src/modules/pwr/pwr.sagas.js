import { fork } from 'redux-saga/effects';

import resetCredential from '../../controllers/reset_account_credentials/reset_account_credentials.controller';
import passwordResetRequest from '../../controllers/password_reset_request/password_reset_request.controller';
import validateAndResetPassword from '../../controllers/validate_and_reset_password/validate_and_reset_password.controller';
import CONFIG from './pwr.config';
import commonSagas from '../shared/common.sagas';

// All sagas to be loaded
// sessionSAGA must be the first in the list
export default function*(){
  yield[
    // Shared Module
    ...commonSagas( CONFIG ),
    fork( resetCredential() ),
    fork( passwordResetRequest ),
    fork( validateAndResetPassword )
  ]
}