
import {
  createScriptTag
} from 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts';
import reflektion from '../../utils/reflektion/reflektion';

window.loadReflektion = ( refBeaconScriptUrl ) => {

  const prObj = {
    'attributes': {
      'id': 'reflektionScript',
      'type': 'text/javascript',
      'src': refBeaconScriptUrl
    },
    'options': {
      'onload': reflektion.listenReflektionLoad
    }
  };
  createScriptTag( prObj );
}


// This function dispatch the reflektion event action after configuring store state .
window.dispatchReflektionEvent = ( reflektionData ) => {
  reflektion.triggerEvent( reflektionData ) ;
}