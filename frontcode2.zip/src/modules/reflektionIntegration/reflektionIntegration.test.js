import './reflektionIntegration';
import { createScriptTag } from 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts';
jest.mock( 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts', () =>{
  return {
    createScriptTag: jest.fn()
  }
} );

import reflektion from '../../utils/reflektion/reflektion';
jest.mock( '../../utils/reflektion/reflektion', () => {
  return {
    triggerEvent:jest.fn(),
    listenReflektionLoad:jest.fn()
  }
} );

describe( ' Reflektion Event Wrapper Module tests  ', () => {

  it( 'should call createScript tag when the loadReflektion function is called ', () => {
    window.loadReflektion( 'reflektionBeaconURL' );
    expect( createScriptTag ).toHaveBeenCalledWith( {
      'attributes': {
        'id': 'reflektionScript',
        'type': 'text/javascript',
        'src': 'reflektionBeaconURL'
      },
      'options': {
        'onload': reflektion.listenReflektionLoad
      }
    } );
  } )

  it( 'should call the reflektion triggerEvent method when the dispatchReflektionEvent method is called ', () => {
    const reflektionEventData = {
      'type': 'a2c',
      'name': 'qview',
      'value': {
        'products': [
          {
            'sku': '12345'
          }
        ]
      }
    };

    window.dispatchReflektionEvent( reflektionEventData );
    expect( reflektion.triggerEvent ).toBeCalledWith( reflektionEventData );
  } )
} );

