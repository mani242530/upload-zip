import { mergeConfig } from '../../config';

const SEARCHBAR_CONFIG = {
}

export default mergeConfig( SEARCHBAR_CONFIG );