/**
 * external.js
 *
 * this is the entry file for the application and is only used for setup code
 *
 */

// Needed for redux-saga es6 generator support
import '@babel/polyfill';

// ReactJS specific imports
import React, { Fragment } from 'react';

// Redux specific imports
import { Provider } from 'react-redux';

// i18n (internationalization) imports
import IntlFormatter from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import LanguageProvider from '../../views/LanguageProvider/LanguageProvider';


// Application component imports
import { translationMessages } from '../../views/LanguageProvider/i18n';
import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import { renderComponent } from '../../utils/dom/dom';
import { setConfig } from '../../utils/ajax/ajax';
import SearchBar from '../../views/SearchBar/SearchBar';
import Global from '../../views/Global/Global';
import configureStore from './searchbar.store';

import CONFIG from './searchbar.config';

setConfig( CONFIG );


import shimReady from '../../shared/shim';


let persistedState = loadState();

if( document.getElementById( 'loginForm' ) && document.getElementById( 'loginForm' )._dynSessConf ){
  persistedState.session.secureToken = document.getElementById( 'loginForm' )._dynSessConf.value
}

const store = configureStore( persistedState, CONFIG );

store.subscribe( () => {
  let state = store.getState();

  saveState( {
    session: state.session,
    searchInputValue:state.reflektionSearch.searchTermValue
  } );
} )

export const render = ( messages ) => {

  // GLOBAL
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <Global />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-global' )
  );

  // SEARCHBAR
  renderComponent()(
    <Provider store={ store }>
      <LanguageProvider messages={ messages }>
        <SearchBar />
      </LanguageProvider>
    </Provider>,
    document.getElementById( 'js-searchBar' )
  );
}

// Hot reloadable translation json fiels
if( module.hot ){
  // modules.hot.accept does not accept dynamic dependencies,
  // have to be constants at compile-time
  module.hot.accept( '../../views/LanguageProvider/i18n', () => {
    render( translationMessages );
  } );
}

// new polyfill for browsers without Intl support
shimReady( () => {
  render( translationMessages )
} );