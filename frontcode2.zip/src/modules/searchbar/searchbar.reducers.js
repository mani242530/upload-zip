/**
 * Combine all reducers in this file and export the combined reducers.
 * If we were to do this in store.js, reducers wouldn't be hot reloadable.
 **/

import { combineReducers } from 'redux';
import {
  reducer as formReducer,
  actionTypes as formActionTypes
} from 'redux-form';

import global from '../../models/view/global/global.model';
import session from '../../models/view/session/session.model';
import user from '../../models/view/user/user.model';
import language from '../../models/view/language/language.model';
import reflektionSearch from '../../models/view/reflektion_search/reflektion_search.model';
// import reducers that are globally required in the ULTA app
//

export const removeUnregisteredFormValue  = ( state, action )=> {
  if( action.type !== formActionTypes.UNREGISTER_FIELD ){
    return state;
  }

  const { values: { [action.payload.name]: unregistered, ...values } } = state
  return { ...state, values }

}

export default ( asyncReducers ) => {
  return combineReducers( {
    global,
    session,
    user,
    language,
    reflektionSearch,
    form: formReducer,
    ...asyncReducers
  } )
}