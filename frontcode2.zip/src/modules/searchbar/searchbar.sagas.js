

import CONFIG from './searchbar.config';
import commonSagas from '../shared/common.sagas';


export default function*(){
  yield[
    ...commonSagas( CONFIG )
  ]
}

