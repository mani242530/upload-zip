
import CONFIG from './searchbar.config';
import commonSagas from '../shared/common.sagas';
import saga from './searchbar.sagas';

describe( 'search Bar sagas', () => {

  const searchBarSaga = saga();

  it( 'should load all sagas', () => {

    const yieldDescriptor = searchBarSaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      ...commonSagas( CONFIG )
    ] ) );

  } );

} );

