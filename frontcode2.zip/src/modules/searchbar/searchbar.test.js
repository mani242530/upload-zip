import { translationMessages } from '../../views/LanguageProvider/i18n';
import {
  loadState,
  saveState
} from '../../utils/local_storage/local_storage';
import { render } from './searchbar';
import * as shim from '../../shared/shim';
jest.mock( './../../shared/shim', () => {
  return jest.fn();
} );
jest.mock( '../../utils/local_storage/local_storage', ()=>{
  return {
    loadState:jest.fn(),
    saveState:jest.fn()
  }
} );
describe( 'searchbar test', () => {

  it( 'should be able to execute render method without crashing', () => {
    let appElement = document.createElement( 'div' );
    appElement.id = 'js-global';
    document.body.appendChild( appElement );

    appElement = document.createElement( 'div' );
    appElement.id = 'js-searchBar';
    document.body.appendChild( appElement );

    render( translationMessages );
    expect( document.getElementById( 'js-searchBar' ).innerHTML ).not.toBe( '' );

  } );
  it( 'should pass proper object as paramter to the saveState', () => {
    render( translationMessages ) ;
    expect( saveState ).toBeCalledWith( expect.objectContaining( { 'searchInputValue':'' } ) );
  } );
} );