import { fork } from 'redux-saga/effects';


import sessionsaga, { sessionManager } from '../../controllers/session/session.controller';
import { errorManager } from '../../controllers/bad_request_handler/bad_request_handler.controller';
import loadScripts from '../../controllers/3rdparty/3rdparty.controller';
import usersaga from '../../controllers/user/user.controller';
import profilesaga from '../../controllers/profile/profile.controller';
import loginsaga from '../../controllers/login/login.controller';
import navigationsaga from '../../controllers/navigation/navigation.controller';
import pagesaga from '../../controllers/page/page.controller';
import switches from '../../controllers/switches/switches.controller';
import analyticssaga from '../../controllers/analytics/analytics.controller';
import logout from '../../controllers/logout/logout.controller';

import quickShop from '../../controllers/quick_shop/quick_shop.controller';
import purchaseEligibility from '../../controllers/product_purchase_eligibility/product_purchase_eligibility.controller';
import addItem from '../../controllers/add_item/add_item.controller';
import skuDynamicData from '../../controllers/sku_data/sku_data.controller';
import findFavorite from '../../controllers/find_favorite/find_favorite.controller';
import addFavorite from '../../controllers/add_favorite/add_favorite.controller';
import removeFavorite from '../../controllers/remove_from_favorites/remove_from_favorites.controller';
import latLong from '../../controllers/lat_long/lat_long.controller';
import productRecsSaga from '../../controllers/product_recomendations/product_recomendations.controller';
import qProtocolBasketEvents from '../../controllers/qprotocol/qprotocol.controller';
import mesobaseEvents from '../../controllers/mesobase/mesobase.controller';
import reflektionEvents from '../../controllers/reflektion/reflektion.controller';
import subscribesaga from '../../controllers/email_sign_up/email_sign_up.controller';
import miniCart from '../../controllers/mini_cart/mini_cart.controller';
import searchtypeaheadsaga from '../../controllers/search_type_ahead/search_type_ahead.controller';
import reflektionSearch from '../../controllers/reflektion_search/reflektion_search.controller';
import emitFeedLessProduct from '../../controllers/power_reviews/power_reviews.controller';
import authorize from '../../controllers/authorization/authorization.controller';
import fetchOrderDetails from '../../controllers/fetch_order_details/fetch_order_details.controller';
import liveChatSaga from '../../controllers/live_chat/live_chat.controller';
import quaziEvents from '../../controllers/quazi_event/quazi_event.controller';
import commonSagas from './common.sagas';
import CONFIG from '../../config';


describe( 'commonSagas sagas', () => {

  it( 'should return all common sagas', () => {

    const sagas = commonSagas( CONFIG );

    expect( JSON.stringify( sagas ) ).toEqual( JSON.stringify( [
      fork( sessionManager ),
      fork( errorManager ),
      fork( sessionsaga( CONFIG ) ),
      fork( loginsaga( CONFIG ) ),
      fork( usersaga( CONFIG ) ),
      fork( loadScripts( CONFIG ) ),
      fork( profilesaga ),
      fork( navigationsaga ),
      fork( pagesaga ),
      fork( switches( CONFIG ) ),
      fork( analyticssaga ),
      fork( logout ),
      fork( authorize( CONFIG ) ),
      fork( fetchOrderDetails ),
      fork( miniCart( CONFIG ) ),
      fork( liveChatSaga ),
      fork( searchtypeaheadsaga ),
      fork( quickShop( CONFIG ) ),
      fork( skuDynamicData( CONFIG ) ),
      fork( purchaseEligibility( CONFIG ) ),
      fork( addItem( CONFIG ) ),
      fork( latLong ),
      fork( addFavorite( CONFIG ) ),
      fork( removeFavorite( CONFIG ) ),
      fork( findFavorite( CONFIG ) ),
      fork( productRecsSaga ),
      fork( subscribesaga( CONFIG ) ),
      fork( qProtocolBasketEvents ),
      fork( mesobaseEvents( CONFIG ) ),
      fork( reflektionEvents ),
      fork( quaziEvents( CONFIG ) ),
      fork( reflektionSearch ),
      fork( emitFeedLessProduct )
    ] ) );
  } );

} );
