import '@babel/polyfill';
import { createStore, applyMiddleware, compose } from 'redux';
import { persistState } from 'redux-devtools';
import createSagaMiddleware from 'redux-saga';
import forEach from 'lodash/forEach';
import keys from 'lodash/keys';
import { setWindowDebuggingFlag } from '../../utils/debugging/debugging.js';

let store;

export function setupStore( initialState, CONFIG, sagas, createReducer ){

  const sagaMiddleware = createSagaMiddleware();

  const middlewares = [
    sagaMiddleware
  ];

  const enhancers = [
    applyMiddleware( ...middlewares )
  ];

  if( process.env.NODE_ENV !== 'production' ){
    enhancers.push( persistState(
      global.location.href.match( /[?&]debug_session=([^&#]+)\b/ )
    ) );
  }

  const debugKeys = keys( CONFIG.DEBUGGING.LOGGING );
  // loop over all the falgs in the config file to dynamically create bindings
  forEach( debugKeys, ( key ) => {
    setWindowDebuggingFlag( key, CONFIG );
  } );

  const composeEnhancers =    global.TRACK_REDUX_EVENTS &&
    typeof global === 'object' &&
    global.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ?
    global.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : compose;

  store = createStore(
    createReducer(),
    initialState,
    composeEnhancers( ...enhancers )
  );

  // Run Global Sagas automatically
  sagaMiddleware.run( sagas );

  // extensions
  store.runSaga = sagaMiddleware.run;
  store.asyncReducers = {};

  return store;

}

export const getStore = () => {
  return store;
}