import { mergeConfig } from '../../config';

// Used to overiride or add any config value specific to VIRTUALTRYON
const VIRTUALTRYON_CONFIG = {
  DEBUGGING: {
    PRODUCT: {
      onSale: true,
      eligibilityState:0
    }
  }
}


export default mergeConfig( VIRTUALTRYON_CONFIG );