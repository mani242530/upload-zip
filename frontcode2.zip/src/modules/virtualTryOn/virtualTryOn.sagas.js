import { fork } from 'redux-saga/effects';

import CONFIG from './virtualTryOn.config';
import productdetails from '../../controllers/product_detail/product_detail.controller';
import addItem from '../../controllers/add_item/add_item.controller';
import skuDynamicData from '../../controllers/sku_data/sku_data.controller';
import purchaseEligibility from '../../controllers/product_purchase_eligibility/product_purchase_eligibility.controller';
import emailNotification from '../../controllers/email_notification/email_notification.controller';
import addFavorite from '../../controllers/add_favorite/add_favorite.controller';
import removeFavorite from '../../controllers/remove_from_favorites/remove_from_favorites.controller';
import findFavorite from '../../controllers/find_favorite/find_favorite.controller';
import commonSagas from '../shared/common.sagas';
// All sagas to be loaded
// sessionSAGA must be the first in the list
export default function*(){
  yield[
    // SHARED Module
    ...commonSagas( CONFIG ),
    fork( productdetails( CONFIG ) ),
    fork( skuDynamicData( CONFIG ) ),
    fork( purchaseEligibility( CONFIG ) ),
    fork( addItem( CONFIG ) ),
    fork( emailNotification( CONFIG ) ),
    fork( addFavorite( CONFIG ) ),
    fork( removeFavorite( CONFIG ) ),
    fork( findFavorite( CONFIG ) )
  ]
}
