import { fork } from 'redux-saga/effects';

import CONFIG from './virtualTryOn.config';
import productdetails from '../../controllers/product_detail/product_detail.controller';
import addItem from '../../controllers/add_item/add_item.controller';
import skuDynamicData from '../../controllers/sku_data/sku_data.controller';
import purchaseEligibility from '../../controllers/product_purchase_eligibility/product_purchase_eligibility.controller';
import emailNotification from '../../controllers/email_notification/email_notification.controller';
import addFavorite from '../../controllers/add_favorite/add_favorite.controller';
import removeFavorite from '../../controllers/remove_from_favorites/remove_from_favorites.controller';
import findFavorite from '../../controllers/find_favorite/find_favorite.controller';
import storeDetail from '../../controllers/store_details/store_details.controller';
import storeProductAvailability from '../../controllers/store_product_availability/store_product_availability.controller';
import quickShop from '../../controllers/quick_shop/quick_shop.controller';
import productRecsSaga from '../../controllers/product_recomendations/product_recomendations.controller';
import commonSagas from '../shared/common.sagas';

import saga from './virtualTryOn.sagas';


describe( 'virtualTryOn sagas', () => {

  const virtualTryOnSaga = saga();

  it( 'should load all sagas', () => {

    const yieldDescriptor = virtualTryOnSaga.next().value;

    expect( JSON.stringify( yieldDescriptor ) ).toEqual( JSON.stringify( [
      ...commonSagas( CONFIG ),
      fork( productdetails( CONFIG ) ),
      fork( skuDynamicData( CONFIG ) ),
      fork( purchaseEligibility( CONFIG ) ),
      fork( addItem( CONFIG ) ),
      fork( emailNotification( CONFIG ) ),
      fork( addFavorite( CONFIG ) ),
      fork( removeFavorite( CONFIG ) ),
      fork( findFavorite( CONFIG ) )
    ] ) ) ;

  } );
} );
