import 'raf/polyfill';
import * as controller from './ccr.controller';

describe( 'ccr.controller', () => {

  it( 'should exist', () => {
    expect( typeof controller.index ).toBe( 'function' );
  } );

} );
