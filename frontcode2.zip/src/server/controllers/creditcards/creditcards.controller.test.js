import 'raf/polyfill';

import * as controller from './creditcards.controller';

describe( 'creditcards.controller', () => {

  it( 'should exist', () => {
    expect( typeof controller.index ).toBe( 'function' );
  } );

} );
