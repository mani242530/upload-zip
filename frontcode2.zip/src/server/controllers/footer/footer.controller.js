import isUndefined from 'lodash/isUndefined';

import footerLayout from '../../layouts/footerLayout';

import createReducer from '../../../modules/mhp/mhp.reducers';
import MHPCONFIG from '../../../modules/mhp/mhp.config';

import { initialState as pagedata } from '../../../models/view/page/page.model';



export const getStore = async function( ctx ){
  const store =  await ctx.utils.redux.getStoreHeaderFooter(
    ctx,
    createReducer,
    pagedata
  );

  return store;
}
/* eslint-disable no-param-reassign */
export const index = function( defaultStore ){
  return async function( ctx, next ){

    try {
      let store = isUndefined( defaultStore ) ? await getStore( ctx ) : defaultStore;
      const global = await ctx.utils.render.getGlobal( store );
      const footer = await ctx.utils.render.getFooter( store );

      return ctx.body = footerLayout( {
        preloadedState: store.getState(),
        footer,
        buildHash:ctx.buildHash,
        moduleName: 'mhp',
        hideHeaderFooter:ctx.request.query.hideHeaderFooter === 'true'
      } );

    }
    catch ( err ){
      ctx.log.error( err, 'There has been an issue logged in index method of home.controller.' );
      return ctx.utils.redirect.notFound( ctx, 404, MHPCONFIG );
    }

  }
}
