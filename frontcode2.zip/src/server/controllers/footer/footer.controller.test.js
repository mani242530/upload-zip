import 'raf/polyfill';
import superagent from 'superagent';
import testConfig from 'superagent-mock';
import mockConfig from '../../../utils/ajax/superagent-mock-config';
import * as controller from './footer.controller';
import footerLayout from '../../layouts/footerLayout';

import { ctx } from '../../utils/enzyme/intl-enzyme-test-helper';


jest.mock( 'serialize-javascript' );

describe( 'footer.controller', () => {

  let superAgentMock;
  beforeEach( () => {
    superAgentMock = testConfig( superagent, mockConfig, ( log ) => {
    } );

  } );

  afterEach( () => {
    superAgentMock.unset();
  } );

  describe( 'index method', () => {
    it( 'should export index as a function', () => {
      expect( typeof controller.index ).toBe( 'function' );
    } );

    describe( 'Page Configuration', () => {

      ctx.request.url = 'www.ulta.com';
      ctx.buildHash = 'a12312fFFds';
      it( 'should output the foooter contents, preloaded state, buildhash, and the module name', async() => {

        const store = await controller.getStore( ctx );
        const response  = await controller.index( store )( ctx, ()=>{} );

        const footer = await ctx.utils.render.getFooter( store );


        const expectedOutput = footerLayout( {
          preloadedState: store.getState(),
          footer,
          buildHash:'a12312fFFds',
          moduleName: 'mhp'
        } )
        expect( ctx.body ).toBe( expectedOutput )

      } );

    } );
  } );
} );
