import isUndefined from 'lodash/isUndefined';
import headerLayout from '../../layouts/headerLayout';

import createReducer from '../../../modules/mhp/mhp.reducers';
import MHPCONFIG from '../../../modules/mhp/mhp.config';

import { initialState as pagedata } from '../../../models/view/page/page.model';



export const getStore = async function( ctx ){
  const store =  await ctx.utils.redux.getStoreHeaderFooter(
    ctx,
    createReducer,
    pagedata
  );

  return store;
}
/* eslint-disable no-param-reassign */
export const index = function( defaultStore ){
  return async function( ctx, next ){

    try {
      let store = isUndefined( defaultStore ) ? await getStore( ctx ) : defaultStore;
      const global = await ctx.utils.render.getGlobal( store );
      const header = await ctx.utils.render.getHeader( store );
      let leftnav = '';
      const isBotRequest = ctx.utils.deviceDetection.isBotRequest( ctx );
      const isMobileDevice = ctx.utils.deviceDetection.isMobileDevice( ctx );
      if( isMobileDevice && isBotRequest ){
        leftnav = await ctx.utils.render.getLeftNav( store );
      }
      return ctx.body = headerLayout( {
        global,
        header,
        leftnav,
        hideHeaderFooter:ctx.request.query.hideHeaderFooter === 'true'
      } );

    }
    catch ( err ){
      ctx.log.error( err, 'There has been an issue logged in index method of home.controller.' );
      return ctx.utils.redirect.notFound( ctx, 404, MHPCONFIG );
    }

  }
}
