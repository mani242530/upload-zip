import 'raf/polyfill';
import superagent from 'superagent';
import testConfig from 'superagent-mock';
import mockConfig from '../../../utils/ajax/superagent-mock-config';
import * as controller from './header.controller';
import headerLayout from '../../layouts/headerLayout';

import { ctx } from '../../utils/enzyme/intl-enzyme-test-helper';


jest.mock( 'serialize-javascript' );

describe( 'header.controller', () => {

  let superAgentMock;
  beforeEach( () => {
    superAgentMock = testConfig( superagent, mockConfig, ( log ) => {
    } );

  } );

  afterEach( () => {
    superAgentMock.unset();
  } );

  describe( 'index method', () => {
    it( 'should export index as a function', () => {
      expect( typeof controller.index ).toBe( 'function' );
    } );

    describe( 'Page Configuration', () => {

      ctx.request.url = 'www.ulta.com';
      ctx.buildHash = 'a12312fFFds';
      describe( 'desktop devices', () => {

        it( 'should output global and header, and left nav as empty for bot request', async() => {

          ctx.utils.deviceDetection.isBotRequest = () => true;
          ctx.utils.deviceDetection.isMobileDevice = () => false;
          const store = await controller.getStore( ctx );
          const response  = await controller.index( store )( ctx, ()=>{} );

          const global = await ctx.utils.render.getGlobal( store );
          const header = await ctx.utils.render.getHeader( store );


          const expectedOutput = headerLayout( {
            global,
            header,
            leftnav: ''
          } )
          expect( ctx.body ).toBe( expectedOutput )

        } );

        it( 'should output global and header, and left nav as empty for non bot request', async() => {

          ctx.utils.deviceDetection.isBotRequest = () => false;
          ctx.utils.deviceDetection.isMobileDevice = () => false;
          const store = await controller.getStore( ctx );
          const response  = await controller.index( store )( ctx, ()=>{} );

          const global = await ctx.utils.render.getGlobal( store );
          const header = await ctx.utils.render.getHeader( store );


          const expectedOutput = headerLayout( {
            global,
            header,
            leftnav: ''
          } )
          expect( ctx.body ).toBe( expectedOutput )

        } );

      } )

      describe( 'mobile devices', () => {

        it( 'should output global and header, and left nav should be present for bot request', async() => {

          ctx.utils.deviceDetection.isBotRequest = () => true;
          ctx.utils.deviceDetection.isMobileDevice = () => true;
          const store = await controller.getStore( ctx );
          const response  = await controller.index( store )( ctx, ()=>{} );

          const global = await ctx.utils.render.getGlobal( store );
          const header = await ctx.utils.render.getHeader( store );
          const leftnav = await ctx.utils.render.getLeftNav( store );


          const expectedOutput = headerLayout( {
            global,
            header,
            leftnav
          } )
          expect( ctx.body ).toBe( expectedOutput )

        } );

        it( 'should output global and header, and left nav as empty for non bot request', async() => {

          ctx.utils.deviceDetection.isBotRequest = () => false;
          ctx.utils.deviceDetection.isMobileDevice = () => true;
          const store = await controller.getStore( ctx );
          const response  = await controller.index( store )( ctx, ()=>{} );

          const global = await ctx.utils.render.getGlobal( store );
          const header = await ctx.utils.render.getHeader( store );


          const expectedOutput = headerLayout( {
            global,
            header,
            leftnav: ''
          } )
          expect( ctx.body ).toBe( expectedOutput )

        } );

      } )

    } );
  } );
} );
