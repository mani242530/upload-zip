import isUndefined from 'lodash/isUndefined';
import { Helmet } from 'react-helmet';
import skeleton from '../../layouts/skeleton';

import createReducer from '../../../modules/mhp/mhp.reducers';
import MHPCONFIG from '../../../modules/mhp/mhp.config';
import ESUCONFIG from '../../../modules/esu/esu.config';
import MobileHomepage from '../../../views/MobileHomepage/MobileHomepage';
import StickyEmailSignUp from '../../../views/StickyEmailSignUp/StickyEmailSignUp';
import { initialState as pagedata } from '../../../models/view/page/page.model';
import { initialState as esu } from '../../../models/view/email_sign_up/email_sign_up.model';
import appConstants from '../../../shared/appConstants';


export const requestHomepageData = function( ctx, url ){
  return ctx.utils.request.getData( ctx, url ).set( appConstants.AKAMAI_DEVICE_HEADER, appConstants.AKAMAI_MOBILE_HEADER_VALUE );
}

export const getHomePageData = async function( ctx ){
  const data = await requestHomepageData( ctx, `${ MHPCONFIG.SERVICES.page }/home` );
  return ctx.utils.request.parseResponse( data ).pageContent;
}

export const getStore = async function( ctx, homepage ){
  const store =  await ctx.utils.redux.getStore(
    ctx,
    createReducer,
    {
      esu,
      pagedata: {
        ...pagedata,
        homepage
      }
    }
  );

  return store;
}
/* eslint-disable no-param-reassign */
export const index = function( defaultStore ){
  return async function( ctx, next ){

    try {
      const homepage = await getHomePageData( ctx );
      let store = isUndefined( defaultStore ) ? await getStore( ctx, homepage ) : defaultStore;

      ctx.utils.render.setDefaultPageHeaders( ctx, next );


      const global = await ctx.utils.render.getGlobal( store );
      const header = await ctx.utils.render.getHeader( store );

      let leftnav = '';
      const isBotRequest = ctx.utils.deviceDetection.isBotRequest( ctx );
      const isMobileDevice = ctx.utils.deviceDetection.isMobileDevice( ctx );
      // left nav will be returned for non mobile or non bot requests
      if( !isMobileDevice || isBotRequest ){
        leftnav = await ctx.utils.render.getLeftNav( store );
      }

      const footer = await ctx.utils.render.getFooter( store );
      const body = await ctx.utils.render.renderComponent(
        {
          store,
          Component: MobileHomepage,
          ctx
        }
      );
      const stickyFooter = await ctx.utils.render.renderComponent(
        {
          store,
          Component: StickyEmailSignUp,
          config: {
            config: ESUCONFIG
          },
          ctx
        }
      )

      return ctx.body = skeleton( {
        title: 'Cosmetics, Fragrance, Skincare and Beauty Gifts | Ulta Beauty',
        preloadedState: store.getState(),
        global,
        header,
        leftnav,
        footer,
        body,
        stickyFooter,
        helmet:Helmet.renderStatic(),
        buildHash:ctx.buildHash,
        moduleName: 'mhp'
      } );

    }
    catch ( err ){
      ctx.log.error( err, 'There has been an issue logged in index method of home.controller.' );
      return ctx.utils.redirect.notFound( ctx, 404, MHPCONFIG );
    }

  }
}
