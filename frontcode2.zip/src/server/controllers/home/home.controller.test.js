import 'raf/polyfill';
import find from 'lodash/find';
import superagent from 'superagent';
import testConfig from 'superagent-mock';
import serialize from 'serialize-javascript';
import mockConfig from '../../../utils/ajax/superagent-mock-config';
import { bodyContent as mhpData } from '../../../utils/ajax/fixtures/mhp'
import * as controller from './home.controller';
import skeleton from '../../layouts/skeleton';
import ESUCONFIG from '../../../modules/esu/esu.config';
import MobileHomepage from '../../../views/MobileHomepage/MobileHomepage';
import StickyEmailSignUp from '../../../views/StickyEmailSignUp/StickyEmailSignUp';
import { ctx } from '../../utils/enzyme/intl-enzyme-test-helper';
import appConstants from '../../../shared/appConstants';

jest.mock( 'serialize-javascript' )
jest.mock( 'react-helmet', () => {
  return {
    Helmet: {
      renderStatic:jest.fn(
        ()=>{
          return {
            title:'Home',
            meta:[
              {
                ['http-equiv']: 'Content-Type',
                content: 'text/html; charset=UTF-8'
              },
              {
                ['http-equiv']: 'X-UA-Compatible',
                content: 'IE=edge'
              }
            ],
            link:{}
          }

        }
      )
    }
  }
} );
// we have to mock serliaze because you can't compare the output
serialize.mockImplementation( () => 1234 );

describe( 'home.controller', () => {

  let superAgentMock;
  beforeEach( () => {
    superAgentMock = testConfig( superagent, mockConfig, ( log ) => {
    } );

  } );

  afterEach( () => {
    superAgentMock.unset();
  } );

  describe( 'requestHomepageData function', () => {

    it( 'should have the proper URL and Header set', () => {
      const request = controller.requestHomepageData( ctx, '/services/v1/page/home' );
      expect( request.url ).toBe( ctx.utils.environment.createLinkPath( ctx, '/services/v1/page/home' ) );
      expect( find( request, { 'x-akamai-device-characteristics': 'is_mobile=true' } ) ).toBeTruthy();
    } );


  } );

  describe( 'getHomePageData function', () => {
    beforeEach( () => {
      jest.spyOn( controller, 'requestHomepageData' );
      jest.spyOn( controller, 'getHomePageData' );
    } );

    it( 'should call and process the request data', async() => {
      const data = await controller.getHomePageData( ctx );

      expect( data ).toEqual( JSON.parse( mhpData ).pageContent );


    } );

  } );


  describe( 'index method', () => {
    it( 'should export index as a function', () => {
      expect( typeof controller.index ).toBe( 'function' );
    } );

    it( 'should set the response headers appropiately', async() => {


      const store = await controller.getStore( ctx );
      ctx.request.url = 'www.ulta.com';
      const response  = await controller.index( store )( ctx, ()=>{} );
      // make sure that the page headers are set
      // check the page status
      expect( ctx.status ).toBe( 200 );
      // check the compress flag
      expect( ctx.compress ).toBeTruthy();
      // check the Content-Type header value
      expect( ctx.set ).toHaveBeenCalledWith( 'Content-Type', 'text/html' );

    } );

    describe( 'Page Configuration', () => {

      ctx.request.url = 'www.ulta.com';
      const mockMetaData = [
        {
          ['http-equiv']: 'Content-Type',
          content: 'text/html; charset=UTF-8'
        },
        {
          ['http-equiv']: 'X-UA-Compatible',
          content: 'IE=edge'
        }
      ];
      const helmet = {
        title:'Home',
        meta:mockMetaData,
        link:{}
      }

      it( 'should output the correct page display and display left nav when it is a mobile device and a bot request', async() => {

        ctx.utils.deviceDetection.isBotRequest = () => true; // is-bot header is enabled fro googlebot
        ctx.utils.deviceDetection.isMobileDevice = () => true;

        const store = await controller.getStore( ctx );
        const response  = await controller.index( store )( ctx, ()=>{} );

        const global = await ctx.utils.render.getGlobal( store );
        const header = await ctx.utils.render.getHeader( store );
        const leftnav = await ctx.utils.render.getLeftNav( store );
        const footer = await ctx.utils.render.getFooter( store );
        const body = await ctx.utils.render.renderComponent(
          {
            store,
            Component: MobileHomepage,
            ctx
          }
        );
        const stickyFooter = await ctx.utils.render.renderComponent(
          {
            store,
            Component: StickyEmailSignUp,
            config: {
              config: ESUCONFIG
            },
            ctx
          }
        )



        const expectedOutput = skeleton( {
          title: 'Cosmetics, Fragrance, Skincare and Beauty Gifts | Ulta Beauty',
          preloadedState: store.getState(),
          global,
          header,
          leftnav,
          footer,
          body,
          stickyFooter,
          helmet:helmet,
          buildHash:1234,
          moduleName: 'mhp'
        } )
        // compare the generated output
        expect( ctx.body ).toBe( expectedOutput )

      } );

      it( 'should output the correct page display and should not display left nav when it is a mobile device and a non bot request', async() => {

        ctx.utils.deviceDetection.isBotRequest = () => false; // is-bot header is disabled for users
        ctx.utils.deviceDetection.isMobileDevice = () => true;

        const store = await controller.getStore( ctx );
        const response  = await controller.index( store )( ctx, ()=>{} );

        const global = await ctx.utils.render.getGlobal( store );
        const header = await ctx.utils.render.getHeader( store );
        const leftnav = '';
        const footer = await ctx.utils.render.getFooter( store );
        const body = await ctx.utils.render.renderComponent(
          {
            store,
            Component: MobileHomepage,
            ctx
          }
        );
        const stickyFooter = await ctx.utils.render.renderComponent(
          {
            store,
            Component: StickyEmailSignUp,
            config: {
              config: ESUCONFIG
            },
            ctx
          }
        )



        const expectedOutput = skeleton( {
          title: 'Cosmetics, Fragrance, Skincare and Beauty Gifts | Ulta Beauty',
          preloadedState: store.getState(),
          global,
          header,
          leftnav,
          footer,
          body,
          stickyFooter,
          helmet:helmet,
          buildHash:1234,
          moduleName: 'mhp'
        } )
        // compare the generated output
        expect( ctx.body ).toBe( expectedOutput )

      } );

    } );
  } );
} );
