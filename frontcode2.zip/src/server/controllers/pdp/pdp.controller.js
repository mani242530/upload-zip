import isUndefined from 'lodash/isUndefined';
import find from 'lodash/find';
import { Helmet } from 'react-helmet';
import skeleton from '../../layouts/skeleton';

import createReducer from '../../../modules/pdp/pdp.reducers';
import appConstants from '../../../shared/appConstants';
import CONFIG from '../../../modules/pdp/pdp.config';


import ProductPage from '../../../views/ProductPage/ProductPage';
import {
  initialState as initialProductDetailState, getNextStateOnProductSuccess, setSeoProductData, getNextStateOnSkuSuccess
} from '../../../models/view/product_page/product_page.model';

export const getData = async function( ctx, url ){
  const data = await ctx.utils.request.getData( ctx, url );
  return ctx.utils.request.parseResponse( data );
}

export const checkProductValidity = function( ctx, productData ){

  let validResponse = false;
  // if the product isn't found or if the status returned doesnt indicationa productUnavalable case, the response will be considered invalid
  if( productData && productData.data && ( productData.data.product || productData.data.isProductUnavailable ) ){
    validResponse = true;
  }
  return validResponse;
}

export const validateSku = function( ctx, skuID, productData ){
  let valid = true;
  if( skuID ){
    // make sure that the sku that is passed is a valid sku for the product that is being requested
    let matchedSku = productData.data.swatches && find( productData.data.swatches.items, { 'skuId': skuID } );
    if( !matchedSku ){
      // if we don't get a match redirec the user as there is a invalid combination being requested
      valid = false;
    }
  }
  return valid;

}

// this method will check if a valid response is obtained for the skuId passed
export const isSkuValid = function( ctx, skuData ){
  let valid = true;
  if( !skuData.data.sku ){
    valid = false;
  }
  return valid;

}

export const getProductData = async function( ctx, requestData ){
  const {
    productID
  } = ctx.params;
  let pID;
  let productData;

  if( productID ){
    pID = productID;
  }
  else if( ctx.query.productId ){
    pID = ctx.query.productId;
  }
  else if( ctx.query.pr_page_id ){
    pID = ctx.query.pr_page_id;
  }

  if( pID ){
    let pdpSVC = ctx.utils.format.replaceURIParams( CONFIG.SERVICES.productDetails, { productid: pID } );
    // get product data
    try {
      productData = await requestData( ctx, pdpSVC );
    }
    // the catch block will handle any scenarios where the service doesnt return a 200 ok response
    catch ( error ){
      // if the status is 410, we are setting the isProductUnavailable to true, which will be used to display the product non available page to the guest
      if( error.status === 410 ){
        productData = {
          data:{
            product:null,
            isProductUnavailable:true
          }
        }
      }
    }
  }

  return productData;
}

export const getSkuData = async function( ctx, productData, request, checkSkuValidity, checkIfSkuIsValid ){

  // get the productID and SKU/ID
  const {
    skuID
  } = ctx.params;

  let skuData;

  let sID = isUndefined( skuID ) ? ctx.query.sku : skuID;
  // if there is a sku defined in the url then do a sku lookup
  if( sID && sID !== productData.data.sku.id ){

    let isSkuValid = checkSkuValidity( ctx, sID, productData );
    if( isSkuValid ){

      let skuSVC = ctx.utils.format.replaceURIParams( CONFIG.SERVICES.skuDetails, { skuid: sID } );

      // get the sku data
      skuData = await request( ctx, skuSVC );

      isSkuValid = checkIfSkuIsValid( ctx, skuData );
    }
    return {
      invalid:!isSkuValid,
      data:skuData
    }
  }

  return {};

}

/* eslint-disable no-param-reassign */
export const validateRequestURL = function( ctx, productData ){

  const {
    productID,
    skuID,
    url
  } = ctx.request;

  const urlProductName = productData.data.product.actionUrl.split( '/' )[3].split( '?' )[0];

  let properURL;

  // if the url doesn't contain the proper product name and if it not the review url or the gwp url, then rewrite it
  // gwp url will be pressent for the gift product urls and for the review page url
  if( url.indexOf( appConstants.URLS.GWP_PDP_PAGE ) === -1 && url.indexOf( appConstants.URLS.PDP_REVIEW_PAGE ) === -1 && url.indexOf( urlProductName ) === -1 ){

    // if we find productID in the params we are in a 'new' URL pattern
    if( productID ){
      properURL = `/p/${ urlProductName }/${ productID }`;
      properURL = !skuID ? properURL : `${ properURL }/s/${ skuID }`;
    }
    else {
      properURL = `/${ urlProductName }?productId=${ ctx.query.productId }`;
      properURL = !ctx.query.sku ? properURL : `${ properURL }&sku=${ ctx.query.sku }`;
    }

    return {
      status:301,
      url:ctx.origin + properURL
    }
  }
  return {
    status:200
  };

}

export const getStore = async function( ctx, svcData ){

  let productPageState = getNextStateOnProductSuccess( svcData.productData.data );
  if( !isUndefined( svcData.skuData ) ){
    productPageState = getNextStateOnSkuSuccess( productPageState, svcData.skuData.data );
  }
  let productPageSeoState = setSeoProductData( svcData.productData.data );

  const store = await ctx.utils.redux.getStore(
    ctx,
    createReducer,
    {
      productPage: {
        ...initialProductDetailState,
        ...productPageState,
        ...productPageSeoState
      }
    }
  );

  return store;
}

/* eslint-disable no-param-reassign */
export const index = function( defaultStore ){

  return async function( ctx, next ){


    // get the productID and SKU/ID
    const {
      productID,
      skuID
    } = ctx.params;

    try {


      // handle both routing options where productID comes as part of the path or as a query param
      const productData = await getProductData( ctx, getData );
      let skuData;
      // this must be preformed after we get the product data
      const validResponse = checkProductValidity( ctx, productData );
      if( !validResponse ){
        // if the product isn't found or if the status returned doesnt indicationa productUnavalable case, the response will be considered invalid
        ctx.log.warn( 'The requested product data is invalid' );
        return ctx.utils.redirect.notFound( ctx, 404, CONFIG );
      }
      if( productData.data.product ){

        const result = validateRequestURL( ctx, productData );
        // validateRequestURl method above will return an object with a status of 301 and the new url
        // for cases for which the user should be redirected to a different url
        // this happens for cases where the product name in the url doesnt match the productId parameter
        if( result && result.status === 301 ){
          ctx.status = 301;
          ctx.log.warn( 'The user is being redirected as the URL does not match the expected result' );
          return ctx.redirect( result.url );
        }
        const skuResponse = await getSkuData( ctx, productData, getData, validateSku, isSkuValid );
        if( skuResponse ){
          if( skuResponse.invalid ){
            ctx.log.warn( `The provided sku was found to be invalid` );
            return ctx.utils.redirect.notFound( ctx, 404, CONFIG );
          }
          skuData = skuResponse.data;
        }
      }

      const store = isUndefined( defaultStore ) ? await getStore( ctx, {
        productData,
        skuData
      } ) :
        defaultStore;

      const props = {
        scene7FlyoutViewerConfig:CONFIG.SCENE7_FLYOUTVIEWER
      }
      ctx.utils.render.setDefaultPageHeaders( ctx, next );

      // the below logic is for SEO purpose. If the product is unavailable, we should be responding with a status of 410
      // status code of 410 will ensure that the search engines will not consider these URLs any more while crawling
      if( productData.data.isProductUnavailable ){
        ctx.response.status = 410;
      }

      const global = await ctx.utils.render.getGlobal( store );
      const header = await ctx.utils.render.getHeader( store, {
        type:'generic',
        isMiniCartFlyoutEnabled:true
      } );
      let leftnav = '';
      const isBotRequest = ctx.utils.deviceDetection.isBotRequest( ctx );
      const isMobileDevice = ctx.utils.deviceDetection.isMobileDevice( ctx );
      // left nav will be returned for non mobile or non bot requests
      if( !isMobileDevice || isBotRequest ){
        leftnav = await ctx.utils.render.getLeftNav( store );
      }

      const footer = await ctx.utils.render.getFooter( store );
      const body = await ctx.utils.render.renderComponent(
        {
          store,
          Component: ProductPage,
          props,
          ctx
        }
      );

      ctx.body = skeleton( {
        title: productData.data.product ? productData.data.product.title : 'Ulta Beauty',
        preloadedState: store.getState(),
        global,
        header,
        leftnav,
        footer,
        body,
        helmet:Helmet.renderStatic(),
        buildHash:ctx.buildHash,
        moduleName: 'pdp'
      } ) ;
    }
    catch ( err ){
      ctx.log.error( err, 'There has been an issue logged in index method of pdp.controller.' );
      return ctx.utils.redirect.notFound( ctx, 404, CONFIG );
    }
  }
}
