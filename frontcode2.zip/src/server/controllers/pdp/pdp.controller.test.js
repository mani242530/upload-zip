import 'raf/polyfill';
import superagent from 'superagent';
import testConfig from 'superagent-mock';
import isEmpty from 'lodash/isEmpty';
import mockConfig from '../../../utils/ajax/superagent-mock-config';
import productDataFixture from '../../../utils/ajax/fixtures/productData';
import ProductPage from '../../../views/ProductPage/ProductPage';
import createReducer from '../../../modules/pdp/pdp.reducers';
import * as controller from './pdp.controller';
import skeleton from '../../layouts/skeleton';
import {
  initialState as initialProductDetailState, getNextStateOnProductSuccess, getNextStateOnSkuSuccess, setSeoProductData
} from '../../../models/view/product_page/product_page.model';

import CONFIG from '../../../modules/pdp/pdp.config';

import { ctx } from '../../utils/enzyme/intl-enzyme-test-helper';

jest.mock( 'react-helmet', () => {
  return {
    Helmet: {
      renderStatic:jest.fn(
        ()=>{
          return {
            title:'Lorac Travel Size TANtalizer Baked Bronzer | Ulta Beauty',
            meta:[
              {
                ['http-equiv']: 'Content-Type',
                content: 'text/html; charset=UTF-8'
              },
              {
                ['http-equiv']: 'X-UA-Compatible',
                content: 'IE=edge'
              }
            ],
            link:{}
          }

        }
      )
    }
  }
} );


describe( 'pdp.controller', () => {

  let superAgentMock;
  beforeEach( () => {
    superAgentMock = testConfig( superagent, mockConfig, ( log ) => {
    } );
  } );
  //
  afterEach( () => {
    superAgentMock.unset();
  } );


  describe( 'index method', () => {
    const mockData = {
      productData:{
        data: {
          product: {
            actionUrl: 'http://www.google.com/asdf/'
          }
        }
      },
      skuData: {
        data: {
        }
      }
    };

    it( 'index method should exist', () => {
      expect( typeof controller.index ).toBe( 'function' );
    } );


    it( 'should set the response headers appropriately', async() => {
      ctx.params.productID = 3330;
      ctx.params.skuID = '2204233';
      ctx.request.url = 'https://www.ulta.com/p/classic-nail-lacquer/224';
      ctx.request.productID = 224;

      const nextFn = ()=>{};
      const defaultPageHeadersSpy = jest.spyOn( ctx.utils.render, 'setDefaultPageHeaders' );

      const response = await controller.index( )( ctx, nextFn );
      // make sure that the page headers are set
      expect( defaultPageHeadersSpy ).toHaveBeenCalledWith( ctx, nextFn );

    } );

    describe( 'Page Configuration', () => {

      const mockData = {
        productData:{
          data: {
            product: {
              actionUrl: 'https://qa3.ulta.com/classic-nail-lacquer?productId=xlsImpprod5180201',
              displayName: 'Classic Nail Lacquer', // this value comes from the fixture
              title:'Lorac Travel Size TANtalizer Baked Bronzer | Ulta Beauty'
            },
            brand: {
              brandName: 'OPI'
            },
            sku: {
              description: 'The most-asked-for brand in the industry! Classic Nail Lacquer with a superior range of shades and the hottest special effects and textures, OPI is the go-to brand for nail fashion. From elegant classics to eye-popping brights, OPI has your color!',
              images: {
                mainImage: 'https://images.ulta.com/is/image/Ulta/2204232'
              },
              id: '2204232',
              price: {
                listPrice: {
                  amount: 10,
                  currencyCode: 'USD'
                }
              },
              variant: {
                variantType: 'Color',
                variantDesc: 'Feelin\' Hot-Hot-Hot!'
              }
            }
          }
        },
        skuData: {
          data: {
          }
        }
      };
      const mockMetaData = [
        {
          ['http-equiv']: 'Content-Type',
          content: 'text/html; charset=UTF-8'
        },
        {
          ['http-equiv']: 'X-UA-Compatible',
          content: 'IE=edge'
        }
      ];
      const helmet = {
        title:mockData.productData.data.product.title,
        meta:mockMetaData,
        link:{}
      }
      const nextFn = ()=>{};

      it( 'should ouput the correct page configuration in desktop for users and googlebot', async() => {
        const store = await controller.getStore( ctx, mockData );
        const response = await controller.index( store )( ctx, nextFn );
        store.getState().form = {};

        const props = {
          scene7FlyoutViewerConfig:CONFIG.SCENE7_FLYOUTVIEWER
        }

        const global = await ctx.utils.render.getGlobal( store );
        const header = await ctx.utils.render.getHeader( store, {
          type:'generic',
          isMiniCartFlyoutEnabled:true
        } );
        const leftnav = await ctx.utils.render.getLeftNav( store );
        const footer = await ctx.utils.render.getFooter( store );
        const body = await ctx.utils.render.renderComponent(
          {
            store,
            Component: ProductPage,
            props,
            ctx
          }
        );

        const expectedOutput = skeleton( {
          title:mockData.productData.data.product.title,
          preloadedState: store.getState(),
          vendorScript: 'vendor.js',
          vendorCss: 'vendor.css',
          global,
          header,
          leftnav,
          footer,
          body,
          helmet,
          buildHash:1234,
          moduleName: 'pdp'
        } )
        // compare the generated output
        expect( ctx.body ).toEqual( expectedOutput )

      } );

      it( 'should output the correct page display and should not display left nav when it is a mobile device and a non bot request', async() => {
        ctx.utils.deviceDetection.isBotRequest = () => false; // is-bot header is disabled for user
        ctx.utils.deviceDetection.isMobileDevice = () => true;
        const store = await controller.getStore( ctx, mockData );
        const response = await controller.index( store )( ctx, nextFn );
        store.getState().form = {};

        const props = {
          scene7FlyoutViewerConfig:CONFIG.SCENE7_FLYOUTVIEWER
        }

        const global = await ctx.utils.render.getGlobal( store );
        const header = await ctx.utils.render.getHeader( store, {
          type:'generic',
          isMiniCartFlyoutEnabled:true
        } );
        const leftnav = '';
        const footer = await ctx.utils.render.getFooter( store );
        const body = await ctx.utils.render.renderComponent(
          {
            store,
            Component: ProductPage,
            props,
            ctx
          }
        );

        const expectedOutput = skeleton( {
          title:mockData.productData.data.product.title,
          preloadedState: store.getState(),
          vendorScript: 'vendor.js',
          vendorCss: 'vendor.css',
          global,
          header,
          leftnav,
          footer,
          body,
          helmet,
          buildHash:1234,
          moduleName: 'pdp'
        } )
        // compare the generated output
        expect( ctx.body ).toEqual( expectedOutput )

      } );

      it( 'should output the correct page display and display left nav when it is a mobile device and a bot request', async() => {
        ctx.utils.deviceDetection.isBotRequest = () => true;// is-bot header is enabled for googlebot
        ctx.utils.deviceDetection.isMobileDevice = () => true;
        const store = await controller.getStore( ctx, mockData );
        const response = await controller.index( store )( ctx, nextFn );
        store.getState().form = {};

        const props = {
          scene7FlyoutViewerConfig:CONFIG.SCENE7_FLYOUTVIEWER
        }

        const global = await ctx.utils.render.getGlobal( store );
        const header = await ctx.utils.render.getHeader( store, {
          type:'generic',
          isMiniCartFlyoutEnabled:true
        } );
        const leftnav = await ctx.utils.render.getLeftNav( store );
        const footer = await ctx.utils.render.getFooter( store );
        const body = await ctx.utils.render.renderComponent(
          {
            store,
            Component: ProductPage,
            props,
            ctx
          }
        );

        const expectedOutput = skeleton( {
          title:mockData.productData.data.product.title,
          preloadedState: store.getState(),
          vendorScript: 'vendor.js',
          vendorCss: 'vendor.css',
          global,
          header,
          leftnav,
          footer,
          body,
          helmet,
          buildHash:1234,
          moduleName: 'pdp'
        } )
        // compare the generated output
        expect( ctx.body ).toEqual( expectedOutput )

      } );

    } );


    it( 'should return the data parse', async() => {
      const data = await controller.getData( ctx, 'http://uat.ulta.com/services/v5/catalog/product/213' );
      expect( data ).toEqual( JSON.parse( productDataFixture().res.text ) );
    } );

    it( 'should call the getData method with the proper url', async() => {
      const mock = jest.fn();
      mock.mockReturnValue( productDataFixture() );
      ctx.utils.request.getData = mock;
      const data = await controller.getData( ctx, 'asdf123' );
      expect( ctx.utils.request.getData ).toHaveBeenCalledWith( ctx, 'asdf123' );
      ctx.utils.request.getData.mockClear();
    } );

  } );


  describe( 'validateSku', () => {
    it( 'should return false if the sku data is not in the productdata entries or not passed ', () => {

      const isValid = controller.validateSku( ctx, '123', {
        data: {
          swatches: {
            items: [
              { skuId: '321' }
            ]
          }
        }
      } );

      expect( isValid ).toBe( false );

    } );

  } );

  describe( 'isSkuValid', () => {

    it( 'should return false if sku is not found', () => {

      const isValid = controller.isSkuValid( ctx, {
        data: {
          sku: null
        }
      } );

      expect( isValid ).toBe( false );

    } );

    it( 'should return true if the sku data is present', () => {
      const isValid = controller.isSkuValid( ctx, {
        data: {
          sku: '1232421'
        }
      } );

      expect( isValid ).toBe( true );

    } );

  } );

  describe( 'getProductData', () => {

    let productData;
    beforeEach( () => {
      productData = undefined;
    } );

    it( 'should return productData if data is actually returned', async() => {
      const mock = jest.fn();
      const getDataMock = jest.fn();
      productData = await controller.getProductData( ctx, getDataMock, mock );
      expect( getDataMock ).toHaveBeenCalled();
    } );

    describe( 'should return an empty object if a prductID is not found', async() => {

      beforeEach( ()=>{
        ctx.query = {};
        ctx.params = {};
      } );

      it( 'should return empty if all productID routes are empty', async()=> {
        productData = await controller.getProductData( ctx, controller.getData );

        expect( isEmpty( productData ) ).toBeTruthy();
      } );

      it( 'should not return empty if a productID is in the url as a param', async()=> {
        ctx.params.productID = '424211';

        productData = await controller.getProductData( ctx, controller.getData );

        expect( !isEmpty( productData ) ).toBeTruthy();
      } );

      it( 'should return empty if a productID is not in the url', async()=> {
        ctx.query.productId = '2421';

        productData = await controller.getProductData( ctx, controller.getData );

        expect( !isEmpty( productData ) ).toBeTruthy();
      } );

      it( 'should return empty if a productID is not in the url', async()=> {
        ctx.query.pr_page_id = '2421';

        productData = await controller.getProductData( ctx, controller.getData );

        expect( !isEmpty( productData ) ).toBeTruthy();
      } );

    } );
  } );

  describe( 'getSkuData', () => {

    it( 'should request skuData if a sku is in the URL', async() => {
      const getDataMock = jest.fn( ()=> {
        return 12241;
      } );
      const checkSkuValidityMock = jest.fn( () => true );
      const isSkuValidMock = jest.fn( () => true );
      const productData = {
        data: {
          swatches: {
            items:[{ skuId: 3321 }]
          },
          sku:{
            id:123
          }
        }
      };

      ctx.params.skuID = 3321;

      let skuData = await controller.getSkuData( ctx, productData, getDataMock, checkSkuValidityMock, isSkuValidMock );

      expect( checkSkuValidityMock ).toHaveBeenCalledWith( ctx, ctx.params.skuID, productData );
      expect( getDataMock ).toHaveBeenCalled();
      expect( isSkuValidMock ).toHaveBeenCalledWith( ctx, skuData.data );
      expect( skuData ).toEqual( { data:12241, invalid:false } );

    } );

    it( 'should not request sku data if there is no sku or query param with skuID data', async() => {
      ctx.params.skuID = undefined;
      delete ctx.params.skuID;
      ctx.query = {};
      const getDataMock = jest.fn();
      const checkSkuValidityMock = jest.fn();
      const isSkuValidMock = jest.fn();
      const productData = {
        data: {
          swatches: {
            items:[{ skuId: 321 }]
          },
          sku:{
            id:123
          }
        }
      };
      let skuData = await controller.getSkuData( ctx, productData, getDataMock, checkSkuValidityMock, isSkuValidMock );
      expect( checkSkuValidityMock ).not.toHaveBeenCalled();
      expect( isEmpty( skuData ) ).toBeTruthy();
    } );

  } );

  describe( 'validateRequestURL', () => {

    const pID = 11241;

    ctx.origin = 'https://www.ulta.com';
    const productData = {
      data: {
        product: {
          actionUrl: 'https://www.ulta.com/pName?productId=1234'
        }
      }
    };

    beforeEach( () => {
      ctx.redirect.mockReset();
    } );

    it( 'should return true if the url contains the proper product name in the URL', () => {

      ctx.request.url = 'https://www.ulta.com/pName?productID=1234';
      const validate = controller.validateRequestURL( ctx, productData );
      expect( validate.status ).toBe( 200 );

    } );

    describe( 'NEW URL HANDLING', () => {
      it( 'should redirect to the proper url if the product name is not correct in comparison to the productID using the NEW style url', () => {
        ctx.request.productID = pID;

        ctx.request.url = `www.ulta.com/p/this_is-amazing/${ pID }/`;
        const validate = controller.validateRequestURL( ctx, productData );
        expect( validate.status ).toBe( 301 );
        expect( validate.url ).toBe( `https://www.ulta.com/p/pName/${ pID }` );

      } );

      it( 'should redirect to the proper url if the product name is not correct in comparison to the productID and SKUID using the NEW style url', () => {

        ctx.request.productID = pID;
        const sku = 11124;
        ctx.request.skuID = sku;
        productData.data.product.actionURL = 'https://www.ulta.com/pName?productId=1234&skuId=4321'
        ctx.request.url = `www.ulta.com/p/this_is-amazing/${ pID }/s/${ sku }`;
        const validate = controller.validateRequestURL( ctx, productData );
        expect( validate.status ).toBe( 301 );
        expect( validate.url ).toBe( `https://www.ulta.com/p/pName/${ pID }/s/${ sku }` );
      } );

    } );

    describe( 'OLD URL HANDLING', () => {

      it( 'should redirect to the proper url is the productname is no correct in comparison to the propductID using the OLD style url', () => {
        delete ctx.request.productID;
        ctx.query.productId = pID;
        ctx.request.url = `www.ulta.com/newproduct-name?productId=${ pID }`;
        const validate = controller.validateRequestURL( ctx, productData );
        expect( validate.status ).toBe( 301 );
        expect( validate.url ).toBe( `https://www.ulta.com/pName?productId=${ pID }` );
      } );


      it( 'should redirect to the proper url is the productname is no correct in comparison to the propductID and skuID using the OLD style url', () => {
        delete ctx.request.productID;
        ctx.request.productId = pID;
        const sku = 11124;
        ctx.query.sku = sku;
        ctx.request.url = `www.ulta.com/newproduct-name?productId=${ pID }&sku=${ sku }`;
        const validate = controller.validateRequestURL( ctx, productData );
        expect( validate.status ).toBe( 301 );
        expect( validate.url ).toBe( `https://www.ulta.com/pName?productId=${ pID }&sku=${ sku }` );
      } );
    } );

    describe( 'GWP PDP URL HANDLING', () => {
      it( 'should not redirect old gwp pdp url to new pdp url', () => {
        delete ctx.request.productID;
        ctx.query.productId = pID;
        const sku = 11124;
        ctx.query.sku = sku;
        ctx.request.url = `https://www.ulta.com/ulta/browse/productDetail.jsp?productId=${ pID }&skuId=${ sku }`;
        const validate = controller.validateRequestURL( ctx, productData );
        expect( validate.status ).toBe( 200 );
      } );

      it( 'should not redirect review page URL', () => {
        delete ctx.request.productID;
        ctx.request.url = 'https://www.ulta.com/ulta/review/?pr_page_id=pimprod2007198&pr_source=web';
        const validate = controller.validateRequestURL( ctx, productData );
        expect( validate.status ).toBe( 200 );
      } );

      it( 'ulta in the url should redirect to new pdp url', () => {
        delete ctx.request.productID;
        delete ctx.query.sku;
        ctx.request.productId = pID;
        ctx.request.url = `https://www.ulta.com/ulta?productId=${ pID }`;
        const validate = controller.validateRequestURL( ctx, productData );
        expect( validate.status ).toBe( 301 );
        expect( validate.url ).toBe( `https://www.ulta.com/pName?productId=${ pID }` );
      } );
    } );
  } );
} );

describe( 'getStore()', () => {

  it( 'should return a properly formatted reduxStore', async()=> {

    const svcData = {
      productData:{
        data: {

        }
      },
      skuData: undefined
    };
    ctx.utils.redux.getStore = jest.fn();
    const productPageState = getNextStateOnProductSuccess( svcData.productData.data );
    const productPageState1 = setSeoProductData( svcData.productData.data );
    const store = await controller.getStore( ctx, svcData );
    expect( ctx.utils.redux.getStore ).toHaveBeenCalledWith(
      ctx,
      createReducer,
      {
        productPage: {
          ...initialProductDetailState,
          ...productPageState,
          ...productPageState1
        }
      }
    );
  } );
} );
