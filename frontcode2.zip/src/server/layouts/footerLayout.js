import {
  host
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';

import serialize from 'serialize-javascript';


// under no circumstances at all should the serialize method be removed from below.
// this is used to prevent XSS
export default function( config ){
  const pageScript = process.env.NODE_ENV === 'production' ? `https://${ host }/ui/static/javascripts/${ config.moduleName }.${ config.buildHash }.js` : `/javascripts/${ config.moduleName }.js`;
  const commonScript = process.env.NODE_ENV === 'production' ? `https://${ host }/ui/static/javascripts/common.${ config.buildHash }.js` : `/javascripts/common.js`;
  const vendorScript = process.env.NODE_ENV === 'production' ? `https://${ host }/ui/static/javascripts/vendor.${ config.buildHash }.js` : `/javascripts/vendor.js`;
  return `
    <div id='js-mobileFooter' ${ config.hideHeaderFooter ? `style='display:none'>` : '' }>${ config.footer }</div>
    <div role="region" id="globalAssertiveRegion" aria-live="assertive" aria-atomic="true" class="sr-only"></div>
    <script id='js_reduxstore'>
      window.__PRELOADED_STATE__ = ${ serialize( config.preloadedState, { isJSON: true } ) }
    </script>
    <script src='${ vendorScript }'></script>
    <script src='${ commonScript }'></script>
    <script src='${ pageScript }'></script>
  `;
}
