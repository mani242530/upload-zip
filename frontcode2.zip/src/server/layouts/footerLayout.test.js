import serialize from 'serialize-javascript';
import footerLayout from './footerLayout';
import * as controller from '../controllers/footer/footer.controller';
import { ctx } from '../utils/enzyme/intl-enzyme-test-helper';


describe( 'footerLayout', () => {

  it( 'should generate expected output if NODE_ENV is in production and hideHeaderFooter is defined / true', async() => {

    process.env.NODE_ENV = 'production';
    const store = await controller.getStore( ctx );

    const configMock = {
      preloadedState: store.getState(),
      footer: 'footerMock',
      buildHash: '112e3A4545333',
      moduleName: 'mhp',
      hideHeaderFooter: true
    }
    const expectedOutput = `
    <div id='js-mobileFooter' style='display:none'>>footerMock</div>
    <div role="region" id="globalAssertiveRegion" aria-live="assertive" aria-atomic="true" class="sr-only"></div>
    <script id='js_reduxstore'>
      window.__PRELOADED_STATE__ = ${ serialize( configMock.preloadedState, { isJSON: true } ) }
    </script>
    <script src='https://www.ulta.com/ui/static/javascripts/vendor.112e3A4545333.js'></script>
    <script src='https://www.ulta.com/ui/static/javascripts/common.112e3A4545333.js'></script>
    <script src='https://www.ulta.com/ui/static/javascripts/mhp.112e3A4545333.js'></script>
  `
    expect( footerLayout( configMock ) ).toBe( expectedOutput );

  } );

  it( 'should generate expected output if NODE_ENV is in production and hideHeaderFooter is undefined', async() => {

    process.env.NODE_ENV = 'production';
    const store = await controller.getStore( ctx );

    const configMock = {
      preloadedState: store.getState(),
      footer: 'footerMock',
      buildHash: '112e3A4545333',
      moduleName: 'mhp',
      hideHeaderFooter: undefined
    }

    const expectedOutput = `
    <div id='js-mobileFooter' >footerMock</div>
    <div role="region" id="globalAssertiveRegion" aria-live="assertive" aria-atomic="true" class="sr-only"></div>
    <script id='js_reduxstore'>
      window.__PRELOADED_STATE__ = ${ serialize( configMock.preloadedState, { isJSON: true } ) }
    </script>
    <script src='https://www.ulta.com/ui/static/javascripts/vendor.112e3A4545333.js'></script>
    <script src='https://www.ulta.com/ui/static/javascripts/common.112e3A4545333.js'></script>
    <script src='https://www.ulta.com/ui/static/javascripts/mhp.112e3A4545333.js'></script>
  `
    expect( footerLayout( configMock ) ).toBe( expectedOutput );

  } );

  it( 'should generate expected output if NODE_ENV is not in production and hideHeaderFooter is defined / true', async() => {

    process.env.NODE_ENV = 'dev';
    const store = await controller.getStore( ctx );

    const configMock = {
      preloadedState: store.getState(),
      footer: 'footerMock',
      buildHash: '112e3A4545333',
      moduleName: 'mhp',
      hideHeaderFooter: true
    }
    const expectedOutput = `
    <div id='js-mobileFooter' style='display:none'>>footerMock</div>
    <div role="region" id="globalAssertiveRegion" aria-live="assertive" aria-atomic="true" class="sr-only"></div>
    <script id='js_reduxstore'>
      window.__PRELOADED_STATE__ = ${ serialize( configMock.preloadedState, { isJSON: true } ) }
    </script>
    <script src='/javascripts/vendor.js'></script>
    <script src='/javascripts/common.js'></script>
    <script src='/javascripts/mhp.js'></script>
  `
    expect( footerLayout( configMock ) ).toBe( expectedOutput );

  } );

  it( 'should generate expected output if NODE_ENV is not in production and hideHeaderFooter is undefined', async() => {

    process.env.NODE_ENV = 'dev';
    const store = await controller.getStore( ctx );

    const configMock = {
      preloadedState: store.getState(),
      footer: 'footerMock',
      buildHash: '112e3A4545333',
      moduleName: 'mhp',
      hideHeaderFooter: undefined
    }

    const expectedOutput = `
    <div id='js-mobileFooter' >footerMock</div>
    <div role="region" id="globalAssertiveRegion" aria-live="assertive" aria-atomic="true" class="sr-only"></div>
    <script id='js_reduxstore'>
      window.__PRELOADED_STATE__ = ${ serialize( configMock.preloadedState, { isJSON: true } ) }
    </script>
    <script src='/javascripts/vendor.js'></script>
    <script src='/javascripts/common.js'></script>
    <script src='/javascripts/mhp.js'></script>
  `
    expect( footerLayout( configMock ) ).toBe( expectedOutput );

  } );

} );
