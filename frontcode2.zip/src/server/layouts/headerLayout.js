// this is used to prevent XSS
export default function( config ){

  return `
    <div id='js-global'>${ config.global }</div>
    <div id='js-mobileHeader' ${ config.hideHeaderFooter ? `style='display:none'>` : '' }>${ config.header }</div>
    <div id='js-mobileNav'>${ config.leftnav }</div>
  `;
}
