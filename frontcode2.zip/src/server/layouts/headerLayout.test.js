import headerLayout from './headerLayout';
import * as controller from '../controllers/footer/footer.controller';
import { ctx } from '../utils/enzyme/intl-enzyme-test-helper';

describe( 'headerLayout', () => {

  it( 'should generate expected output if hideHeaderFooter is defined / true', async() => {

    const store = await controller.getStore( ctx );
    const global = await ctx.utils.render.getGlobal( store );
    const header = await ctx.utils.render.getHeader( store );

    const mockConfig = {
      global,
      header,
      leftnav: '',
      hideHeaderFooter: true
    }

    const expectedOutput = `
    <div id='js-global'>${ mockConfig.global }</div>
    <div id='js-mobileHeader' style='display:none'>>${ mockConfig.header }</div>
    <div id='js-mobileNav'>${ mockConfig.leftnav }</div>
  `
    expect( headerLayout( mockConfig ) ).toBe( expectedOutput );

  } );

  it( 'should generate expected output if hideHeaderFooter is undefined', async() => {

    const store = await controller.getStore( ctx );
    const global = await ctx.utils.render.getGlobal( store );
    const header = await ctx.utils.render.getHeader( store );

    const mockConfig = {
      global,
      header,
      leftnav: '',
      hideHeaderFooter: undefined
    }

    const expectedOutput = `
    <div id='js-global'>${ mockConfig.global }</div>
    <div id='js-mobileHeader' >${ mockConfig.header }</div>
    <div id='js-mobileNav'>${ mockConfig.leftnav }</div>
  `
    expect( headerLayout( mockConfig ) ).toBe( expectedOutput );

  } );

} );