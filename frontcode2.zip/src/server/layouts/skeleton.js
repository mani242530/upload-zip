import {
  fullyQualifyLink,
  host
} from 'ulta-fed-core/dist/js/utils/formatters/formatters';

import serialize from 'serialize-javascript';


// under no circumstances at all should the serialize method be removed from below.
// this is used to prevent XSS
export default function( config ){
  const pageScript = process.env.NODE_ENV === 'production' ? `https://${ host }/ui/static/javascripts/${ config.moduleName }.${ config.buildHash }.js` : `/javascripts/${ config.moduleName }.js`;
  const commonScript = process.env.NODE_ENV === 'production' ? `https://${ host }/ui/static/javascripts/common.${ config.buildHash }.js` : `/javascripts/common.js`;
  const commonCssFile = process.env.NODE_ENV === 'production' ? `https://${ host }/ui/static/css/common.${ config.buildHash }.css` : `/css/common.css`;
  const vendorScript = process.env.NODE_ENV === 'production' ? `https://${ host }/ui/static/javascripts/vendor.${ config.buildHash }.js` : `/javascripts/vendor.js`;
  const vendorCssFile = process.env.NODE_ENV === 'production' ? `https://${ host }/ui/static/css/vendor.${ config.buildHash }.css` : `/css/vendor.css`;
  const cssFile = process.env.NODE_ENV === 'production' ? `https://${ host }/ui/static/css/${ config.moduleName }.${ config.buildHash }.css` : `/css/${ config.moduleName }.css`;

  return `
    <!DOCTYPE html>
    <html lang='en'>
      <head>
        ${ config.helmet.title.toString()}
        ${ config.helmet.meta.toString()}
        ${ config.helmet.link.toString()}
        <meta charset="utf-8">
        <meta name="theme-color" content="#e90b5a">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        ${ process.env.SSR_DEV ? '' :
    `<link href='${ commonCssFile }' rel='stylesheet'>
    <link href='${ vendorCssFile }' rel='stylesheet'>
    <link href='${ cssFile }' rel='stylesheet'>`}
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" async></script>
      </head>
      <body>
        <div id='js-pageContainer'>
          <div id='js-global'>${ config.global }</div>
          <div id='js-mobileHeader'>${ config.header }</div>
          <div id='js-mobileNav'>${ config.leftnav }</div>
          <div id='js-mobileBody'>${ config.body }</div>
          <div id='js-mobileFooter'>${ config.footer }</div>
          ${ config.stickyFooter ? `<div id='js-stickyEmailSignUpFooter'>${ config.stickyFooter }</div>` : '' }
          <div role="region" id="globalAssertiveRegion" aria-live="assertive" aria-atomic="true" class="sr-only"></div>
          <script id='js_reduxstore'>
            window.__PRELOADED_STATE__ = ${ serialize( config.preloadedState, { isJSON: true } ) }
          </script>
          ${ process.env.SSR_DEV ? `<script src='/static/pdp/js/bundle.js'></script>` :
    `<script src='${ vendorScript }'></script>
     <script src='${ commonScript }'></script>
     <script src='${ pageScript }'></script>`}

        </div>
      </body>
    </html>
  `;
}
