const notFound = async function( ctx, next ){
  try {
    await next();

  }
  catch ( err ){
    console.log( err.message );// eslint-disable-line
    if( ctx.status === 404 ){
      return ctx.redirect( ctx.utils.environment.createLinkPath( ctx, '/404.jsp' ) );
    }

  }
}

module.exports = {
  notFound
}
