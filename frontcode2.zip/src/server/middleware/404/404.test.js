import { notFound } from './404';
import { ctx } from '../../utils/enzyme/intl-enzyme-test-helper';

describe( '404 error scenarios', ()=> {

  describe( 'noFound', ()=> {

    beforeEach( () => {
      jest.spyOn( ctx.utils.environment, 'createLinkPath' );
      ctx.utils.environment.createLinkPath.mockReset();
    } );

    it( 'should call ctx.redirect if the status is 404', async()=>{

      ctx.status = 404;

      notFound( ctx, ()=>{
        throw { message: 'wow' }
      } );

      expect( ctx.utils.environment.createLinkPath ).toHaveBeenCalledWith( ctx, '/404.jsp' );

    } );

    it( 'should not call ctx.redirect if the status is no 404', async()=> {
      ctx.status = 200;
      notFound( ctx, ()=>{
        throw { message: 'tests are kind of cool' }
      } );
      expect( ctx.utils.environment.createLinkPath ).not.toHaveBeenCalled();

    } );
  } );

} );

