import { ctx } from '../../utils/enzyme/intl-enzyme-test-helper';
const rt = require( './response-time' ).default;



describe( 'response-time middleware', ()=> {

  it( 'should set the koa header value of X-Response-Time', async()=> {

    const nextMock = jest.fn();

    await rt.responseTime( ctx, nextMock );
    expect( nextMock ).toHaveBeenCalledTimes( 1 );
    expect( ctx.set ).toHaveBeenCalled();

  } );

} );
