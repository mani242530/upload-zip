const Router = require( 'koa-router' );
const ccr = require( './../../controllers/ccr/ccr.controller' );

const router = Router();

const paths = {
  bag: '/bag',
  checkout: '/checkout'
}

router.get( paths.bag, ccr.index );
router.get( paths.checkout, ccr.index );

module.exports = {
  router,
  paths
}
