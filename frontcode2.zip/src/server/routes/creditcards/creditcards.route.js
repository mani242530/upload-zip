import 'raf/polyfill';
const Router = require( 'koa-router' );
const creditcards = require( './../../controllers/creditcards/creditcards.controller' );

const router = Router();

const paths = {
  base: '/creditcards'
}
router.get( paths.base, creditcards.index );

module.exports = {
  router,
  paths
}
