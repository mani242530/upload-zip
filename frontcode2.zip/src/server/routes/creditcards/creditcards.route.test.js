
import Router from 'koa-router';
import find from 'lodash/find';
import {
  router,
  paths
} from './creditcards.route';

import { index } from '../../controllers/creditcards/creditcards.controller';



function getRoute( path ){
  return find( router.stack, { path } );
}

function getHandler( route, handler ){
  return route.stack[0] === handler;
}

describe( 'routes configuration', () => {

  it( 'should export a koa-router', () => {
    expect( router ).toBeInstanceOf( Router );
  } );

  it( `should have a route for ${ paths.base }`, () => {
    const route = getRoute( paths.base );
    expect( route ).toBeTruthy();
    expect( getHandler( route, index ) ).toBeTruthy();
  } );


} );
