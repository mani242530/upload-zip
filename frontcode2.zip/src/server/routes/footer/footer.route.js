const Router = require( 'koa-router' );
const footer = require( '../../controllers/footer/footer.controller' );

const router = Router();

const paths = {
  base: '/footer'
}

const indexMethod = footer.index();

router.get( paths.base, indexMethod );

module.exports = {
  router,
  paths,
  indexMethod
}
