const Router = require( 'koa-router' );
const header = require( '../../controllers/header/header.controller' );

const router = Router();

const paths = {
  base: '/header'
}

const indexMethod = header.index();

router.get( paths.base, indexMethod );

module.exports = {
  router,
  paths,
  indexMethod
}
