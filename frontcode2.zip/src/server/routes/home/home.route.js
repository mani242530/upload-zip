const Router = require( 'koa-router' );
const home = require( './../../controllers/home/home.controller' );

const router = Router();

const paths = {
  base: '/'
}

const indexMethod = home.index();

router.get( paths.base, indexMethod );

module.exports = {
  router,
  paths,
  indexMethod
}
