const fs = require( 'fs' );
const path = require( 'path' );
const Router = require( 'koa-router' );
const homeRoute = require( './home/home.route' ).router;
const headerRoute = require( './header/header.route' ).router;
const footerRoute = require( './footer/footer.route' ).router;
const productDetailRoute = require( './pdp/pdp.route' ).router;

const router = Router();

// HomePage Route
router.use( homeRoute.routes(), homeRoute.allowedMethods() );
router.use( headerRoute.routes(), headerRoute.allowedMethods() );
router.use( footerRoute.routes(), footerRoute.allowedMethods() );
// PDP router
router.use( productDetailRoute.routes(), productDetailRoute.allowedMethods() );

module.exports = {
  router
}

