import 'raf/polyfill';
import Router from 'koa-router';
import difference from 'lodash/difference';
import includes from 'lodash/includes';
import { router } from '.';

const homeRoute = require( './home/home.route' ).router;
const pdpRoute = require( './pdp/pdp.route' ).router;



describe( 'routes configuration', () => {

  it( 'should return an instance of Koa router', () => {
    expect( router ).toBeInstanceOf( Router );
  } );

  const routes = router.routes().router.stack;
  it( 'should contain the \'home\' routes', () => {
    const homeRoutes = homeRoute.stack;
    expect( difference( homeRoutes, routes ).length === 0 ).toBeTruthy();
  } );

  it( 'should  contain the \'pdp\' routes', () => {
    const pdpRoutes = pdpRoute.stack;
    expect( difference( pdpRoutes, routes ).length === 0 ).toBeTruthy();

  } );

} );
