const Router = require( 'koa-router' );
const pdp = require( './../../controllers/pdp/pdp.controller' );

const paths = {
  traditional:  '/:productName',
  traditionalReview: '/ulta/review',
  gwpPath: '/ulta/browse/productDetail.jsp',
  newPID: '/p/:productName/:productID',
  newSID: '/p/:productName/:productID/s/:skuID',
  newG: '/g/:productID'
}


const router = Router();

const indexMethod = pdp.index();

// handles the 'traditional' ULTA pdp url
router.get( paths.traditional, indexMethod );
router.get( paths.traditionalReview, indexMethod );

// GWP
router.get( paths.newG, indexMethod );
router.get( paths.gwpPath, indexMethod );


// handles the newly proposed ULTA pdp urls
router.get( paths.newPID, indexMethod );
router.get( paths.newSID, indexMethod );

module.exports = {
  router,
  paths,
  indexMethod
}
