import 'raf/polyfill';
import Router from 'koa-router';
import find from 'lodash/find';
import {
  router,
  paths,
  indexMethod
} from './pdp.route';

import pdp from '../../controllers/pdp/pdp.controller';



function getRoute( path ){
  return find( router.stack, { path } );
}

function getHandler( route, handler ){
  return route.stack[0] === handler;
}

describe( 'routes configuration', () => {

  it( 'should export a koa-router', () => {
    expect( router ).toBeInstanceOf( Router );
  } );

  it( `should have a route for ${ paths.traditional }`, () => {
    const route = getRoute( paths.traditional );
    expect( route ).toBeTruthy();
    expect( getHandler( route, indexMethod ) ).toBeTruthy();
  } );

  it( `should have a route for ${ paths.traditionalReview }`, () => {

    const route = getRoute( paths.traditionalReview );
    expect( route ).toBeTruthy();
    expect( getHandler( route, indexMethod ) ).toBeTruthy();
  } );

  it( `should have a route for ${ paths.newPID }`, () => {
    const route = getRoute( paths.newPID );
    expect( route ).toBeTruthy();
    expect( getHandler( route, indexMethod ) ).toBeTruthy();
  } );

  it( `should have a route for ${ paths.newSID }`, () => {
    const route = getRoute( paths.newSID );
    expect( route ).toBeTruthy();
    expect( getHandler( route, indexMethod ) ).toBeTruthy();
  } );

  it( `should have a route for ${ paths.newG }`, () => {
    const route =  getRoute( paths.newG );
    expect( route ).toBeTruthy();
    expect( getHandler( route, indexMethod ) ).toBeTruthy();
  } );

  it( `should have a route for ${ paths.gwpPath }`, () => {
    const route =  getRoute( paths.gwpPath );
    expect( route ).toBeTruthy();
    expect( getHandler( route, indexMethod ) ).toBeTruthy();
  } );
} );
