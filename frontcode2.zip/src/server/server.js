require( 'dotenv' ).config();
// the below block of code is ONLY for local development of the SSR server, thus the condition
// checking to see if the SSR_DEV flag is true.  This flag should NOT be set to true in
// a production environment!

require( '@babel/polyfill' ); //eslint-disable-line
// eslint-disable-block
if( process.env.SSR_DEV ){
  require( 'ignore-styles' ); //eslint-disable-line

  require( '@babel/register')( { //eslint-disable-line
    // ignore: [
    //   // this is necessary since we are importing modules directly
    //   // from node_modules and we want to ensure that the babel-node
    //   // command is not transforming them, which causes problems
    //   '/node_modules/(?!redux-form|lodash)'
    // ],
    plugins: [
      ['module-resolver', {
        alias: {
          ssr_server_config: './environments.json',
          './../controllers': './src/controllers',
          './../../events': './src/events',
          views: './src/views',
          models: './src/models',
          controllers: './src/server/controllers',
          shared: './src/shared',
          pdp: './src/modules/pdp',
          ccr: './src/modules/ccr',
          abuy:'./src/modules/abuy',
          emsu: './src/modules/esu',
          hf: './src/modules/hf',
          mhp: './src/modules/mhp',
          server: './src/server',
          static: './src/static',
          utils: './src/utils'
        }
      }]
    ]
  } );
}


const Koa = require( 'koa' );
const pino = require( 'koa-pino-logger' );
const pino_pretifier = require( 'pino-pretty' );
const chalk = require( 'chalk' );
const serve = require( 'koa-static' );
const compress = require( 'koa-compress' );
const Z_SYNC_FLUSH = require( 'zlib' ).Z_SYNC_FLUSH;
const rt = require( './middleware/response-time/response-time' ).default;
// const fourZeroFour= require( './middleware/404/404' );
const router = require( './routes' ).router;
const utils = require( './utils' ).default;

// setup the dynamic environment variables
utils.environment.setRuntimeVariables();
// get the environment variables
const ENVIRONMENT = utils.environment.getRuntimeVariables();
// setup dynatrace
utils.environment.setupDynaTrace( ENVIRONMENT );


const app =  new Koa();

// compression
app.use(
  compress( {
    filter: function( content_type ){
      return /text/i.test( content_type )
    },
    threshold: 2048,
    flush: Z_SYNC_FLUSH
  } )
);


// expose static data
app.use( serve( './build/static' ) );


const pinoConfig = process.env.SSR_DEV ? {
  prettyPrint: {
    colorize: true,
    levelFirst: true,
    crlf: true
  },
  prettier: pino_pretifier
} : {};
// logger
app.use( pino( pinoConfig ) );

// response time
app.use( rt.responseTime );

// 404 handling
// app.use( fourZeroFour.notFound );

// hostConfig
app.context.apihost = ENVIRONMENT.API_HOST;
// client config
app.context.clientConfig = {
  rerequestNavData: false
}

app.context.utils = utils;

if( typeof buildHash !== 'undefined' ){
  app.context.buildHash = buildHash;
}

// router
app.use( router.routes() );


const appPort = ( ENVIRONMENT.PORT || 5000 );
app.listen( appPort );
console.log( chalk.yellow( '/******* environment variables *********/' ) ); //eslint-disable-line
console.log( ENVIRONMENT ); // eslint-disable-line
console.log( chalk.yellow( '/***************************************/' ) );//eslint-disable-line
console.log( chalk.yellow( `The app is now running on ${ appPort } using the ${ process.env.ACTIVE_ENV } configuration` ) ); // eslint-disable-line

export default app;
