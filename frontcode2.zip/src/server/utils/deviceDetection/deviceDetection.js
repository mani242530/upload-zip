export const isMobileDevice = ( ctx ) => {

  if( ctx.request.query && ctx.request.query.isMobile === 'true' ){
    return true;
  }
  else {
    const akamaiHeader = ctx.request.header[ 'x-akamai-device-characteristics' ];
    if( akamaiHeader ){
      const deviceAttributes = akamaiHeader.split( ';' );
      let deviceAttribute;
      let keyValueAttr;
      for ( let count = 0; count < deviceAttributes.length; count++ ){
        deviceAttribute = deviceAttributes[ count ];
        if( deviceAttribute ){
          keyValueAttr = deviceAttribute.split( '=' )
          if( keyValueAttr.length === 2 && keyValueAttr[ 0 ] === 'is_mobile' ){
            return keyValueAttr[ 1 ] === 'true'
          }
        }
      }
    }
  }
  return false;
}

export const isBotRequest = ( ctx ) => {
  return ctx.request.header[ 'is-bot' ] === 'true';
}
export default {
  isMobileDevice,
  isBotRequest
};
