import { isMobileDevice, isBotRequest } from './deviceDetection';

describe( 'isMobileDevice', () => {

  it( 'should return true when the akamai header has the property is_mobile as true', () => {
    const ctx = {
      request:{
        header:{
          'x-akamai-device-characteristics':'is_mobile=true'
        }
      }
    }

    expect( isMobileDevice( ctx ) ).toBe( true );
  } );

  it( 'should return false when the akamai header has the property is_mobile as true', () => {
    const ctx = {
      request:{
        header:{
          'x-akamai-device-characteristics':'is_mobile=false'
        }
      }
    }

    expect( isMobileDevice( ctx ) ).toBe( false );
  } );

  it( 'should return true when the akamai header is not present in the request, but has isMobile param present in the query with value true', () => {
    const ctx = {
      request:{
        header:{},
        query:{
          'isMobile':'true'
        }
      }
    }
    expect( isMobileDevice( ctx ) ).toBe( true );
  } );

  it( 'should return false when the akamai header is not present in the request, and isMobile param not present in the query', () => {
    const ctx = {
      request:{
        header:{},
        query:{}
      }
    }
    expect( isMobileDevice( ctx ) ).toBe( false );
  } );

  it( 'should return false when the akamai header is not present in the request, but has isMobile param present in the query with value false', () => {
    const ctx = {
      request:{
        header:{},
        query:{
          'isMobile':'false'
        }
      }
    }
    expect( isMobileDevice( ctx ) ).toBe( false );
  } );

  it( 'should return false when the akamai header and query param present is not present in the request', () => {
    const ctx = {
      request:{
        header:{}
      }
    }
    expect( isMobileDevice( ctx ) ).toBe( false );
  } );

} );


describe( 'isBotRequest', () => {

  it( 'should return true when is-bot header is present with the value true', () => {
    const ctx = {
      request:{
        header:{
          'is-bot':'true'
        }
      }
    }

    expect( isBotRequest( ctx ) ).toBe( true );
  } );

  it( 'should return false when is-bot header is present but with the value as not true', () => {
    const ctx = {
      request:{
        header:{
          'is-bot':'false'
        }
      }
    }

    expect( isBotRequest( ctx ) ).toBe( false );
  } );

  it( 'should return false when is-bot request is not present', () => {
    const ctx = {
      request:{
        header:{
          'x-akamai-device-characteristics':'is_mobile=false'
        }
      }
    }

    expect( isBotRequest( ctx ) ).toBe( false );
  } );


} );

