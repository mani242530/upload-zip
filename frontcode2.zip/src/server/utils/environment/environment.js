import chalk from 'chalk';
import { setServerHost } from 'ulta-fed-core/dist/js/utils/formatters/formatters'
import SERVER_CONFIG from '../../../../environments.json';


const createLinkPath = function( ctx, link ){
  return `https://${ctx.apihost }${ link }`;
}

let ENVIRONMENT = {};

const setRuntimeVariables = function( ){
  ENVIRONMENT = SERVER_CONFIG.SSR[ process.env.ACTIVE_ENV ];
  // set the serverHOST based on the data configured in the SERVER_CONCIG
  setServerHost( ENVIRONMENT.API_HOST );
};

const getRuntimeVariables = function( ){
  return ENVIRONMENT;
}


const setupDynaTrace = function( environment ){
  if( environment.DT_COLLECTOR ){
    try {
      require( './dynatrace/onenodeloader' )({ //eslint-disable-line
        server: environment.DT_COLLECTOR,
        agentName: environment.DT_AGENT_NAME
      } );
    }
    catch ( err ){
      console.error( chalk.red( 'There was a problem connecting to the Dynatrace Agent' ) );//eslint-disable-line
      console.error( chalk.red( err.toString() ) );//eslint-disable-line
    }
  }
}



export default {
  createLinkPath,
  setRuntimeVariables,
  getRuntimeVariables,
  ENVIRONMENT,
  setupDynaTrace
}
