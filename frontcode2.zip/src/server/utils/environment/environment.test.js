import * as formatters from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import environment from './environment';
import EDATA from '../../../../environments.json';
import { ctx } from '../enzyme/intl-enzyme-test-helper';

describe( 'environment realted runtine processing', () => {

  describe( 'createLinkPath', () => {
    it( 'should return a link with the proper context based on the environment', ()=> {
      let link = 'doingsomething.com/wer';
      ctx.apihost = 'www.randomurl.ui/';
      let url = environment.createLinkPath( ctx, link );

      expect( url ).toBe( `https://${ctx.apihost}${link}` );

    } );
  } );

  describe( 'setupDynaTrace', () => {
    process.env.ACTIVE_ENV = 'ds5';

    it( 'should throw an error when there is a problem loading any of the data is invalid', () => {
      const config = {
        DT_AGENT_PATH: 'RRRT'
      };

      const mock = jest.fn();

      expect( environment.setupDynaTrace( config, mock ) ).toBeFalsy();
    } );



  } );

  describe( 'setRuntimeVariables', () => {
    process.env.ACTIVE_ENV = 'da2';
    it( 'should set the env data', () => {
      jest.spyOn( formatters, 'setServerHost' );

      environment.setRuntimeVariables();
      expect( environment.getRuntimeVariables() ).toBe( EDATA.SSR[ process.env.ACTIVE_ENV] );
      expect( formatters.setServerHost ).toHaveBeenCalledWith( EDATA.SSR[ process.env.ACTIVE_ENV ].API_HOST );

    } );
  } );

  describe( 'getRuntimeVariables', () => {
    process.env.ACTIVE_ENV = 'qa2';
    environment.setRuntimeVariables();
    it( 'should return the environment configured values', () => {
      const d = environment.getRuntimeVariables();
      expect( d ).toBe( EDATA.SSR[ process.env.ACTIVE_ENV ] );
    } );
  } );



} );
