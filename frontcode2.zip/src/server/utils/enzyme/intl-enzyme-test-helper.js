/**
  * Components using the react-intl module require access to the intl context.
  * This is not available when mounting single components in Enzyme.
  * These helper functions aim to address that and wrap a valid,
  * English-locale intl context around them.
  */
import 'raf/polyfill';
import React from 'react';
import renderer from 'react-test-renderer';
import { IntlProvider, intlShape } from 'react-intl';
// import { configure, mount, shallow } from 'enzyme';
import Enzyme, { shallow, render, mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Provider } from 'react-redux';
import configureStore from '../../../modules/ccr/ccr.store';
import CONFIG from '../../../modules/ccr/ccr.config';
import Global from '../../../views/Global/Global';
const intlProvider = new IntlProvider( { locale: 'en' }, {} );
const { intl } = intlProvider.getChildContext();
import serverUtils from '..';

// Make Enzyme functions available in all test files without importing
global.shallow = shallow;
global.render = render;
global.mount = mount;


// React 16 Enzyme adapter
// configure( { adapter: new Adapter() } );
Enzyme.configure( { adapter: new Adapter() } );

/**
 * Wehn using React-Intl  `injectIntl` on componets, props.intl is required
 */
const getNode = ( node ) => {
  return React.cloneElement( node, { intl } );
}

export const shallowWithIntl = ( node ) => {
  return shallow(
    getNode( node ),
    {
      context: { intl }
    }
  );
}

export let ctx = {
  set: jest.fn(),
  redirect: jest.fn(),
  params: {},
  request:{
    header:{},
    query: {
      mobile: false
    },
    url: ''
  },
  utils:{
    ...serverUtils
  },
  apihost: 'http://uat.ulta.com',
  log: {
    info: jest.fn(),
    warn: jest.fn(),
    fatal: jest.fn(),
    trace: jest.fn(),
    error: jest.fn(),
    debug: jest.fn(),
    child: jest.fn()
  }
}

export const mountWithIntlGlobal = ( node ) => {
  return mount(
    getNode( node ),
    {
      context: { intl },
      childContextTypes:  { intl: intlShape }
    }
  );
}

export const mountWithIntl = ( node ) => {
  let store = configureStore( {}, CONFIG );
  mountWithIntlGlobal(
    <Provider store={ store }>
      <Global />
      ( )
      {
        ()=> ( mount(
          node
        ) )
      }
      { ' ' }
)()
    </Provider>
  );
  return mount(
    node
  );
}


export const createComponentWithIntl = ( children, props = { locale: 'en' } ) => {
  return renderer.create(
    <IntlProvider { ...props }>
      { children }
    </IntlProvider>
  );
}
