// import { replaceURIParams  } from '../../utils/ajax/ajax';
import forEach from 'lodash/forEach';

export const replaceURIParams = ( endpoint, URIParams ) => {
  let url = endpoint;
  forEach( URIParams, ( val, key ) => {
    url = url.replace( ':' + key, val );
  } );
  return url;
}

export default {
  replaceURIParams
}
