import { replaceURIParams } from './format';

describe( 'replaceURIParams', () => {

  it( 'should replace uri params with the values passed', () => {
    const endpoint = '/services/v5/catalog/product/:productid';
    const URIParams = { productid:1233 }
    expect( replaceURIParams( endpoint, URIParams ) ).toBe( '/services/v5/catalog/product/1233' );
  } );

} );
