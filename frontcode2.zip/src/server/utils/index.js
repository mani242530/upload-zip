import deviceDetection from './deviceDetection/deviceDetection';
import redux from './redux/redux';
import render from './render/render';
import environment from './environment/environment';
import format from './format/format';
import redirect from './redirect/redirect';
import request from './request/request';

export default {
  deviceDetection,
  redux,
  render,
  environment,
  format,
  redirect,
  request
}
