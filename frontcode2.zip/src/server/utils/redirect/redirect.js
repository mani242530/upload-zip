const notFound = ( ctx, type, CONFIG ) => {
  let redirect;
  switch ( type ){
    case 404:
      redirect = ctx.redirect( ctx.utils.environment.createLinkPath( ctx, CONFIG.REDIRECTS['404'] ) );
  }
  return redirect;
}

export default {
  notFound
}
