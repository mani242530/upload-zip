import redirect from './redirect';
import { ctx } from '../enzyme/intl-enzyme-test-helper';

describe( 'redirect functionality', () => {


  describe( 'notFound', () => {

    it( 'should redirect to an environment specific page with the config defined 404 page', () => {

      const config = {
        REDIRECTS:{
          ['404']: 'dynamicroute.jsp'
        }
      }

      let RedirectPage = ctx.utils.environment.createLinkPath( ctx, config.REDIRECTS['404'] );

      redirect.notFound( ctx, 404, config );
      expect( ctx.redirect ).toHaveBeenCalledWith( RedirectPage );


    } );

  } );

} );
