import { createStore, compose, applyMiddleware } from 'redux';
import superagent from 'superagent';
import {
  registerServiceName,
  getServiceType,
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { initialState as initialSessionState } from '../../../models/view/session/session.model';
import { initialState as initialUserState } from '../../../models/view/user/user.model';


import { initialState as initialHeaderState } from '../../../models/view/header/header.model';
import { initialState as initialFooterState } from '../../../models/view/footer/footer.model';
import { initialState as initialCartState } from '../../../models/view/cart/cart.model';
import globalModel, { initialState as initialGlobalState } from '../../../models/view/global/global.model';
import { initialState as initialLanguageState } from '../../../models/view/language/language.model';
import typeAheadSearchReducer, { initialState as initialTypeAheadSearchState } from '../../../models/view/type_ahead_search/type_ahead_search.model';
import reflektionSearchReducer, { initialState as initialReflektionSearchState } from '../../../models/view/reflektion_search/reflektion_search.model';
import CONFIG from '../../../modules/pdp/pdp.config';
import MHP_CONFIG from '../../../modules/mhp/mhp.config';
import mobileLeftNavReducer,
{ initialState as initialMobileLeftNav }
  from '../../../models/view/mobile_left_nav/mobile_left_nav.model';

registerServiceName( 'navigation' );
registerServiceName( 'switches' );

const getData = async function( ctx, url ){

  const data = await ctx.utils.request.getData( ctx, url );
  ctx.log.info( `data requested from ${ url }` );
  return ctx.utils.request.parseResponse( data );
}


const getInitialState = async function( ctx ){

  let navData = await getData( ctx, CONFIG.SERVICES.navigation );
  let switchesData = await getData( ctx, CONFIG.SERVICES.switches );

  return {
    global: {
      ...globalModel( initialGlobalState, getActionDefinition( 'switches', 'success' )( switchesData ) ),
      // determine if we are in mobile/desktop display using query string
      isMobileDevice: ctx.utils.deviceDetection.isMobileDevice( ctx ),
      isServerSideRendered:true
    },
    session: {
      ...initialSessionState
    },
    user: {
      ...initialUserState
    },
    language: {
      ...initialLanguageState
    },
    header:{
      ...initialHeaderState,
      shippingBanner: {
        ...initialHeaderState.shippingBanner,
        mobileMessage: navData.mobileNavContent.shippingPromoContent.mobileContent,
        desktopMessage: navData.desktopNavContent.shippingPromoContent.content,
        message: navData.mobileNavContent.shippingPromoContent.mobileContent
      }
    },
    footer: {
      ...initialFooterState
    },
    cart: {
      ...initialCartState
    },
    mobileLeftNav: {
      ...initialMobileLeftNav,
      ...mobileLeftNavReducer( initialMobileLeftNav, getActionDefinition( 'navigation', 'success' )( navData ) )
    },
    typeaheadsearch: {
      ...typeAheadSearchReducer( initialTypeAheadSearchState, getActionDefinition( 'switches', 'success' )( switchesData ) )
    },
    reflektionSearch: {
      ...reflektionSearchReducer( initialReflektionSearchState, getActionDefinition( 'switches', 'success' )( switchesData ) )
    }
  }
}


const getStore = async function( ctx, createReducer, additionalState = {} ){


  const defaultState = await getInitialState( ctx, );

  const store = createStore(
    createReducer(),
    {
      ...defaultState,
      ...additionalState
    }
  );

  return store;
}

const getStoreHeaderFooter = async function( ctx, createReducer, additionalState = {} ){


  const defaultState = await getInitialState( ctx, );

  const store = createStore(
    createReducer(),
    {
      ...defaultState,
      header : {
        ...defaultState.header,
        desktopHeaderDisplayMode:{
          ...defaultState.header.desktopHeaderDisplayMode,
          displayLeftNav:false
        }
      },
      global:{
        ...defaultState.global,
        mobileWidth:MHP_CONFIG.MOBILE_BREAK_POINT
      },
      ...additionalState
    }
  );

  return store;
}

export default {
  getInitialState,
  getStore,
  getData,
  getStoreHeaderFooter
}
