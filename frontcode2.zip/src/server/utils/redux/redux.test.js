import {
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import { createStore } from 'redux';
import { ctx } from '../enzyme/intl-enzyme-test-helper';
import redux from './redux';
jest.mock( 'redux' );
import CONFIG from '../../../modules/pdp/pdp.config';
import createReducer from '../../../modules/pdp/pdp.reducers';


import reflektionSearchReducer, { initialState as initialReflektionSearchState } from '../../../models/view/reflektion_search/reflektion_search.model';

describe( 'redux utility methods', ()=> {

  describe( 'getData', ()=> {

    it( 'should call superagent get with the proper url', async() => {
      jest.spyOn( ctx.utils.request, 'getData' );
      await redux.getData( ctx, CONFIG.SERVICES.switches );
      expect( ctx.utils.request.getData ).toHaveBeenCalledWith( ctx, CONFIG.SERVICES.switches );
    } );

  } );


  describe( 'getInitialState', ()=> {

    it( 'should call getdata with the navigation and switches', async() => {
      let initialState;
      const getInitialState = redux.getInitialState( ctx );
      getInitialState.then( initialState => {
        expect( initialState.global.isServerSideRendered ).toBe( true );
      } );
      expect( ctx.utils.request.getData ).toHaveBeenCalledWith( ctx, CONFIG.SERVICES.navigation );
      expect( ctx.utils.request.getData ).toHaveBeenCalledWith( ctx, CONFIG.SERVICES.switches );
    } );

    it( 'should populate the store with the right reflektionSearch data', async() => {
      let initialState;
      const getInitialState = redux.getInitialState( ctx );
      getInitialState.then( initialState => {
        expect( initialState.reflektionSearch ).toEqual( reflektionSearchReducer( initialReflektionSearchState, getActionDefinition( 'switches', 'success' )( {
          switches:{
            visualSearchEnabled: true
          }
        } ) ) );
      } );
    } );

  } );

  describe( 'getStore', ()=> {
    it( 'should return a default store if no additional data is passed', async() => {

      const initialState = redux.getInitialState();
      const store = await redux.getStore( ctx, createReducer );

      expect( createStore ).toHaveBeenCalled();
    } );
  } );

  describe( 'getStoreHeaderFooter', ()=> {

    it( 'should return a default store if no additional data is passed', async() => {
      const initialState = await redux.getInitialState( ctx );
      const store = await redux.getStoreHeaderFooter( ctx, createReducer );
      expect( createStore ).toHaveBeenCalledWith( createReducer(), initialState );
    } );

  } );

} );
