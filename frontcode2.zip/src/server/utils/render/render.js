
import { Provider } from 'react-redux';
import React, { Fragment } from 'react';

import IntlFormatter from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import {
  StaticRouter as Router,
  Route
} from 'react-router-dom';
import LanguageProvider from '../../../views/LanguageProvider/LanguageProvider';
import { translationMessages } from '../../../views/LanguageProvider/i18n';
import Header from '../../../views/Header/Header';
import LeftNav from '../../../views/LeftNav/LeftNav.jsx';
import Global from '../../../views/Global/Global';
import Footer from '../../../views/Footer/Footer.jsx';

const renderToNodeStream = require( 'react-dom/server' ).renderToNodeStream;


const getGlobal = async function( store ){
  return new Promise( ( resolve, reject ) => {
    var stream = renderToNodeStream(
      <Provider store={ store }>
        <LanguageProvider messages={ translationMessages }>
          <Fragment>
            <IntlFormatter/>
            <Global />
          </Fragment>
        </LanguageProvider>
      </Provider>
    );

    var data = '';

    stream.on( 'error', err => reject( err ) );
    stream.on( 'data', chunk => data += chunk );
    stream.on( 'end', ()=> resolve( data ) );

  } );
}

const getHeader = async function( store, props ){
  return new Promise( ( resolve, reject ) => {

    var stream = renderToNodeStream(
      <Provider store={ store }>
        <LanguageProvider messages={ translationMessages }>
          <Header { ...props }/>
        </LanguageProvider>
      </Provider>
    )

    var data = '';

    stream.on( 'error', err => reject( err ) );
    stream.on( 'data', chunk => data += chunk );
    stream.on( 'end', ()=> resolve( data ) );

  } );
}

const getLeftNav = async function( store ){
  return new Promise( ( resolve, reject ) => {

    var stream = renderToNodeStream(
      <Provider store={ store }>
        <LanguageProvider messages={ translationMessages }>
          <LeftNav />
        </LanguageProvider>
      </Provider>
    )

    var data = '';

    stream.on( 'error', err => reject( err ) );
    stream.on( 'data', chunk => data += chunk );
    stream.on( 'end', ()=> resolve( data ) );
  } );
}

const getFooter = async function( store ){
  return new Promise( ( resolve, reject ) => {

    var stream = renderToNodeStream(
      <Provider store={ store }>
        <LanguageProvider messages={ translationMessages }>
          <Footer />
        </LanguageProvider>
      </Provider>
    )
    var data = '';

    stream.on( 'error', err => reject( err ) );
    stream.on( 'data', chunk => data += chunk );
    stream.on( 'end', ()=> resolve( data ) );
  } );
}


const renderComponent = async function( config ){

  const {
    store,
    Component,
    props,
    ctx
  } = config;

  return new Promise( ( resolve, reject ) => {

    var stream = renderToNodeStream(
      <Provider store={ store }>
        <LanguageProvider messages={ translationMessages }>
          <Router
            location={ ctx.request.url }
            context={ {} }
          >
            <Route
              path='/'
              render={
                () => {
                  return (
                    <Component
                      { ...( props && props.config && { config: props.config } ) }
                      { ...( props && props.scene7FlyoutViewerConfig && { scene7FlyoutViewerConfig: props.scene7FlyoutViewerConfig } ) }
                    />
                  )
                }
              }
            />
          </Router>
        </LanguageProvider>
      </Provider>
    )

    var data = '';

    stream.on( 'error', err => reject( err ) );
    stream.on( 'data', chunk => data += chunk );
    stream.on( 'end', ()=> resolve( data ) );
  } );
}

/* eslint-disable no-param-reassign */
const setDefaultPageHeaders = async function( ctx, next ){
  ctx.status = 200;
  ctx.set( 'Content-Type', 'text/html' );
  ctx.compress = true;
  await next();
}

export default {
  getGlobal,
  getHeader,
  getLeftNav,
  getFooter,
  renderComponent,
  setDefaultPageHeaders
}
