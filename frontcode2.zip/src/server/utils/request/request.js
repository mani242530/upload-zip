import superagent from 'superagent';

const getData = function( ctx, url ){
  const nUrl = ctx.utils.environment.createLinkPath( ctx, url );
  let request = superagent.get( nUrl )
  if( process.env.SSR_DEV ){
    request.set( 'user-Agent', 'gomez' );
  }
  return request;
};

const parseResponse = function( data ){
  return JSON.parse( data.res.text )
}


export default {
  getData,
  parseResponse
}
