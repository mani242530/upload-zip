import superagent from 'superagent';
jest.mock( 'superagent' );
import { ctx } from '../enzyme/intl-enzyme-test-helper';
import request from './request';




describe( 'request operations', () => {

  describe( 'getData', () => {

    it( 'should request an endpoint via superagent  with a correct environment Link page', ()=> {

      const getMock = jest.fn();
      superagent.mockImplementation( ()=> {
        return {
          get: getMock
        }
      } );

      const url = 'www.amazon.com';
      request.getData( ctx, url );
      expect( superagent.get ).toHaveBeenCalledWith( ctx.utils.environment.createLinkPath( ctx, url ) );

    } );
  } );

  describe( 'parseResponse', () => {

    it( 'should returend a JSPON parsed response ', () => {
      let data = {
        res: {
          text: '{ "asdf": "happyplace" }'
        }
      }

      const res =  request.parseResponse( data );

      expect( res ).toEqual( { asdf: 'happyplace' } );

    } );

  } );

} );
