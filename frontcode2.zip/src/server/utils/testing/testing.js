import utils from '..';

export default {
  ctx:{
    utils:{
      environment: utils.environment,
      redux: utils.redux,
      render: utils.render
    }
  }
}
