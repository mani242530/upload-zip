

export const appConstants = {
  ANALYTICS:{
    HEADER_LOGIN_SOURCE:'account:sign in',
    BAG_LOGIN_SOURCE:'bag:save for later',
    EMPTYBAG_LOGIN_SOURCE:'empty bag:save for later',
    REAUTH_PAGE_NAME:'account:reauthentication',
    ACCOUNT_CHANNEL_NAME:'account',
    ORDERSTATUS_PAGE_NAME:'account:order status',
    TRACK_ERROR_EVENT:'trackErrorDisplayed',
    ORDER_STATUS_ERRORS:'OrderStatusFormErrors',
    REWARDS_DATA_READY:'rewardsDataObjectReady',
    BOPIS_CHANGE_STORE_NOT_AVAILABLE: 'bopisChangeStoreNotAvailable',
    BOPIS_CHANGE_STORE: 'bopisChangeStore',
    STAY_SIGNEDIN_FLAG:'staySignedInFlag',
    BOPIS_SELECT_STORE_PICKUP_AVAILABILITY: 'bopisSelectStorePickupAvailability',
    PRODUCT_NO_RESULTS_PAGE_NAME:'product:no results',
    // TODO : This is a temporary solution. we need to think about how we handle dynamic Analytic page names.
    PRODUCT_PAGE_NAME : ( skuId, brandName, displayName ) => {
      return `product:${skuId}:${brandName}:${displayName}`;
    },
    BOPIS_PICKUP_SELECTED: 'bopisPickupSelected',
    VIRTUAL_STORE_TOUR: 'virtual store tour'
  },
  LOGIN_SOURCE_DEFAULT: 'default',
  SESSION_DATA: 'sessionData',
  TABLET_BREAK_POINT: 767,
  LOCAL_STORAGE:{
    USERS_AUTH_SUCCESSURL_DETAILS: 'authSuccessUrlDetails',
    REMOVED_ITEMS: 'removedItems',
    PICKUP_UNAVAILABLE_ITEMS: 'pickupUnavailableItems',
    PICKUP_SMS_INFO: 'pickupSmsInfo'
  },
  FIND_IN_STORE_CONFIG:{
    FORMNAME : 'FindInStore',
    FIELDNAME : 'searchField'
  },

  AKAMAI_DEVICE_HEADER:'x-akamai-device-characteristics',
  AKAMAI_MOBILE_HEADER_VALUE:'is_mobile=true',

  TREATMENT_TYPE:{
    RECTANGLE : 'rectangle',
    CIRCLE : 'circle',
    DEFAULT : 'default'
  },

  CROSS_SELL_LOCATION:{
    PRODUCT:'product',
    ADD_TO_BAG:'add to bag'
  },

  REC_TYPE:{
    PDP:'RECS_PDP',
    ATC:'RECS_A2CMODAL',
    CART:'RECS_CART',
    EMPTYCART:'RECS_EMPTYCART',
    NULLSEARCH:'NULLSEARCH',
    PAGE_404:'404',
    HOMEPAGE:'HOMEPG'
  },

  ORDER_STATUS_FORM:{
    EMAIL:'email',
    ORDER_NUMBER:'orderNumber',
    FORM_NAME:'OrderStatus'
  },

  ROUTES:{
    BASE_PATH: '/',
    ACCOUNT_PAGE:'/ulta/myaccount',
    BAG_PAGE: '/bag',
    BAG_EMPTY_PAGE: '/bag/empty',
    BAG_LOGIN_PAGE: '/bag/login',
    CHECKOUT_PAGE: '/checkout',
    ORDER_CONTENT_ANONYMOUS_PAGE: '/ulta/myaccount/pages/order_content_anonymous.jsp',
    REGISTER_PAGE: '/ulta/myaccount/register.jsp',
    FORGOT_PASSWORD_SENT: '/forgot-password-sent',
    FORGOT_USERNAME_SENT: '/forgot-username-sent',
    GUEST_SERVICE: '/ulta/guestservices',
    CREDITCARDS_APPLY: '/creditcards/apply',
    VIRTUAL_STORE_TOUR: '/innovation/store-tour/?utm_source=ulta&utm_medium=web&utm_campaign=footer',
    WAYS_TO_SHOP_ULTA: '/ways-to-shop-ulta-beauty',
    ORDER_STATUS: '/myaccount/orderstatus',
    MY_ACCOUNT_ORDER:'/ulta/myaccount/order.jsp',
    REWARDS_PAGE:'/ulta/myaccount/rewards.jsp',
    LEARNMORE_TEMPLATE_PAGE: '/ulta/myaccount/learnmore_template.jsp?learnMoreAccordion=true&page=benefits',
    LANDING_PAGE: '/ulta/creditcards/landingpage.jsp',
    ULTAMATE_REWARDS_CREDIT_PAGE: '//comenity.net/ultamaterewardscredit'
  },
  URLS:{
    COUPON_PAGE: '/coupons',
    VIRTUAL_TRYON_PAGE: '/virtualtryon',
    ERROR_404_PAGE: '404.jsp',
    GWP_PDP_PAGE: '/ulta/browse/productDetail.jsp',
    PDP_REVIEW_PAGE: '/ulta/review',
    STORE_LOCATOR: '/ulta/stores/storelocator.jsp',
    PRIVACY_POLICY: '/ulta/common/privacyPolicy.jsp',
    PURCHASE_PAYMENT_AGREEMENT: 'https://www.afterpay.com/purchase-payment-agreement'
  },
  RESPONSE_CODE:{
    SESSION_EXPIRED:409,
    TOKEN_MISMATCH:498,
    UNAUTHORIZED:401
  },
  SESSION_STORAGE:{
    CURRENT_LOCATION_DATA: 'currentLocationData'
  },
  EVENT_NAMES:{
    ADD_TO_CART:'add_to_cart',
    ADD_TO_FAVORITES:'add_to_favorites',
    PRODUCT_VIEWED:'product_view'
  }
}

export default appConstants;
