// pollyfill solution from: http://stackoverflow.com/questions/29804786/intl-js-polyfill-shim-with-webpack

// loads the shim dynamically and sends the passed
// in callback when finished to start the application
module.exports = function( callback ){

  if( !global.Intl ){

    require.ensure( [
      'intl',
      'intl/locale-data/jsonp/en.js'
    ], function( require ){
      require( 'intl' );
      require( 'intl/locale-data/jsonp/en.js' );
      callback();
    } );

  }
  else {

    setTimeout( callback, 0 ); // effectively forces async action

  }
};
