import superagent from 'superagent';
import nocache from 'superagent-no-cache';
import superagent_prefix from 'superagent-prefix';
import testConfig from 'superagent-mock';
import forEach from 'lodash/forEach';
import indexOf from 'lodash/indexOf';
import has from 'lodash/has';
import _isNaN from 'lodash/isNaN';
import { isServer } from 'ulta-fed-core/dist/js/utils/device_detection/device_detection';
import { replaceURIParams } from 'ulta-fed-core/dist/js/utils/formatters/formatters';
import { makeGetSessionInfo } from '../../models/view/session/session.model';

import {
  loadState
} from '../local_storage/local_storage';
import { getLocation } from '../domain/domain';

let CONFIG = {};
let mockConfig;

export const setConfig = function( val ){
  CONFIG = val;
}

// configuration for test environment
if( process.env.NODE_ENV === 'test' ){
  mockConfig = require ( './superagent-mock-config' ).default //eslint-disable-line
  testConfig( superagent, mockConfig, ( log ) => {
  } );
}

export const createLocalOrigin = ( origin ) => {
  var domain = origin.split( ':' );


  if( domain[2] ){
    domain[2] = parseInt( domain[2], 10 ) + 100
  }
  else {
    delete domain[2];
  }

  return ( domain.join( ':' ) );
}

export const setApiEnv = ( NODE_ENV, origin ) => {
  let env;
  if( !isServer() ){
    env = ( ( NODE_ENV === 'production' ) ? getLocation().origin : createLocalOrigin( origin ) );

    // 3rd party check for proper domain
    if( indexOf( CONFIG.SERVICES.HOST_BLACK_LIST, env.substring( env.lastIndexOf( '/' ) + 1 ) ) !== -1 ){
      env = global.location.protocol + '//www.ulta.com';
    }
  }

  return env;

};

export const getPrefix = ( NODE_ENV, origin, saprefix )=> ( saprefix( setApiEnv( NODE_ENV, origin ) ) );


export const successHandler = ( res ) => {
};

export const failureHandler = ( err ) => {
  if( !isServer() ){
    global.dispatch( 'trackErrorDisplayed', err )
  }
};


export const defaultDataConfig = {
  type: 'invalid',
  method: 'get',
  cache: false,
  success: successHandler,
  failure: failureHandler
}

export const checkStatus = ( res )=>{

  if( res.status === 200 || res.status === 409 ){
    return res;
  }

  // handle the 409 error
  if( res.status === 500 ){
    return 500;
  }

  const error = new Error( res.statusText );
  error.response = res;
  failureHandler( error )
  throw error;
};


export const prepareRequest = ( config )=> {
  let conf = {
    ...defaultDataConfig,
    ...config
  };

  const {
    type,
    method,
    cache,
    success,
    failure,
    values,
    URIParams,
    absoluteURL,
    customHeaders,
    dynamicURL
  } = conf;

  let endpoint;
  if( dynamicURL ){
    endpoint = dynamicURL;
  }
  else if( absoluteURL ){
    endpoint = CONFIG.SERVICES[absoluteURL];
  }
  else {
    endpoint = ( conf.page ) ? `${CONFIG.SERVICES[type]}${ '/' + conf.page.type}` : CONFIG.SERVICES[type];
  }

  let prefixPayloadOrigin = ( process.env.NODE_ENV === 'test' ) ? 'https://uat.ulta.com' : getLocation().origin ;
  if( URIParams ){
    endpoint = replaceURIParams( endpoint, URIParams );
  }

  let request =    superagent[method]( endpoint )
    .use( getPrefix( process.env.NODE_ENV, prefixPayloadOrigin, superagent_prefix ) )

  if( customHeaders ){
    forEach( customHeaders, ( val, key ) => {
      request.set( key, val );
    } );
  }

  if( method.toLowerCase() === 'post' ){
    request.set( 'Content-Type', 'application/json' );
    request.send( values );
  }


  // if the caller wants to use cache
  if( !cache ){
    request = request.use( nocache );
  }

  if( has( conf, 'query._dynSessConf' ) ){
    delete conf.query._dynSessConf;
  }

  // add query params if passed in the config obj
  if( conf.query ){
    forEach( conf.query, ( val, key ) => {
      request = request.query( `${key}=${val}` );
    } );
  }

  // only add the _dynSessConf if the user isn't manually adding it and it's not the session token request
  if( indexOf( CONFIG.SERVICES.SESSION_BLACK_LIST, type ) === -1 ){

    // add the sessionData
    const sessionData = makeGetSessionInfo()( loadState() );

    request = request.set( 'API-Access-Control', `dyn_session_conf=${ sessionData.secureToken }` );
  }

  return request;

}


export const ajax = ( config = defaultDataConfig, setupRequest = prepareRequest )=> {

  const request = setupRequest( config );
  let sanitizedData = request.then( checkStatus );
  return sanitizedData;
}

export default {
  ajax
}
