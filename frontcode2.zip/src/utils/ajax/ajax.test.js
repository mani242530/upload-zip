import _ from 'lodash';
import CONFIG from '../../config';
import {
  ajax,
  createLocalOrigin,
  setApiEnv,
  getPrefix,
  defaultDataConfig,
  successHandler,
  failureHandler,
  checkStatus,
  setConfig,
  prepareRequest
} from './Ajax';

jest.mock( '../../models/view/session/session.model', () => {
  return {
    makeGetSessionInfo: jest.fn( () => () => {
      return { secureToken:'2206040443193829401' }
    } )
  }
} );

describe( 'Ajax utilities', ()=> {
  let origin;

  setConfig( CONFIG );

  describe( 'defaultDataConfig', () => {
    it( 'should have the proper values', () => {
      var expected = {
        type: 'invalid',
        cache: false,
        method: 'get',
        success: successHandler,
        failure: failureHandler
      }

      expect( defaultDataConfig ).toEqual( expected );
    } );
  } );


  describe( 'method', () => {
    it( 'should allow the caller to set the HTTP method via a config', () => {
      const request  =        prepareRequest( {
        type:'session',
        method: 'post',
        query:{ _dynSessConf:'1234' }, // to avoid getting it from state
        success: ( res ) => {
        },
        failure: ( err ) => {
        }
      } );
      expect( request.method ).toBe( 'POST' );
    } );

  } );

  describe( 'response handlers', () => {
    beforeEach( () => {
      global.console = {
        error: jest.fn(),
        warn: jest.fn(),
        log: jest.fn()
      }
    } )


    it( 'failureHandler should log the proper message', () => {
      global.dispatch = jest.fn();
      failureHandler();
      expect( global.dispatch ).toHaveBeenCalled();

    } );
  } );

  describe( 'checkStatus', () => {
    let res;

    beforeEach( ()=>{

      res = {
        status: 0,
        statusText: 'test'
      }
    } );
    it( 'should handle status 200 > 300 successfully', () => {
      let result;
      res.status = 200;
      result = checkStatus( res );
      expect( result ).toBe( res );
    } );

    it( 'should throw an error if the status is over 200 and below 300', () => {

      res.status = _.random( 201, 299 );
      expect( ()=>{
        checkStatus( res )
      } ).toThrow();
    } );

    it( 'should return number 409 if that http code is returned by the service', ()=> {
      let res = {
        status: 409
      };

      let result = checkStatus( res );

      expect( result.status ).toBe( res.status );

    } );

    it( 'should throw an error if the status is below 200 or over 300', () => {

      res.status = _.random( 1, 199 );
      expect( ()=>{
        checkStatus( res )
      } ).toThrow();

      res.status = _.random( 300, 800 );
      expect( ()=>{
        checkStatus( res )
      } ).toThrow();
    } );

  } );

  describe( 'getPrefix', () => {
    let superagent_prefix = jest.fn();
    it( 'should create a superagent prefix object', () => {
      let prefix = getPrefix( 'production', origin, superagent_prefix );

      expect( superagent_prefix ).toHaveBeenCalledWith( setApiEnv( 'production', origin ) );
    } );
  } );


  describe( 'createLocalOrigin', () => {

    beforeEach( () => {
      origin = 'http://localhost:4000';
    } );
    it( 'should create a url that points to strongloop server by poiting to a port that is 100 greater than the UI port', () => {
      let devURL = createLocalOrigin( origin );
      expect( devURL ).toBe( 'http://localhost:4100' );
    } );
  } );

  describe( 'api_env', () => {

    beforeEach( () => {
      origin = 'http://localhost:4000';
    } );

    it( 'should set the prefix for services for development mode', () => {

      var api_env = setApiEnv( 'development', origin );

      expect( api_env ).not.toBe( 'http://uat.ulta.com' );
      expect( api_env ).toBe( createLocalOrigin( origin ) );
    } );

    it( 'setApiEnv should set env to http://www.ulta.com when called from a 3rd party and not from localhost', () => {
      CONFIG.SERVICES.HOST_BLACK_LIST.map( hostname => {
        var api_env = setApiEnv( 'development', 'http://' + hostname );
        expect( api_env ).toBe( 'http://www.ulta.com' );
      } );
    } );

    it( 'setApiEnv should not set the env to http://www.ulta.com when called from localhost', () => {
      var api_env = setApiEnv( 'development', 'http://localhost:5120' );
      expect( api_env ).not.toBe( 'http://www.ulta.com' );
    } );
  } );

  describe( 'prepareRequest', () => {
    it( 'should return proper data', ()=> {
      const conf = {
        type:'session',
        query:{ _dynSessConf:'1234' }
      };
      const request = prepareRequest( conf );
      const expectedOutput = {
        'data': undefined,
        'headers': {
          'cache-control': 'no-cache,no-store,must-revalidate,max-age=-1,private',
          'expires': '-1',
          'user-agent': 'node-superagent/3.8.3',
          'x-requested-with': 'XMLHttpRequest'
        },
        'method': 'GET',
        'url': 'https://uat.ulta.com/services/v1/session/token'
      };
      expect( request.toJSON() ).toEqual( expectedOutput );

    } );

    it( 'should return proper method', () => {
      const conf = {
        type:'session',
        method: 'post'
      };
      const request = prepareRequest( conf );
      const expectedMethod = 'POST';
      expect( request.method ).toBe( expectedMethod );
    } );

    it( 'should append _dynSessConf to API-Access-Control in request header', () => {
      setConfig( CONFIG );
      const request = prepareRequest( {
        absoluteURL:'findLocation',
        method:'get',
        URLParams:{ skudId: 2291305 }
      }, );
      expect( request.header[ 'API-Access-Control' ] ).toBeTruthy();
    } );

    it( 'should use cache headers if cache is passed', () => {
      const request = prepareRequest( {
        type: 'session',
        cache: true
      } );
      expect( request.toJSON().headers['cache-control'] ).toBe( undefined );

    } );

    it( 'should return proper data in url when absoluteURL is set', () => {
      setConfig( CONFIG );
      const conf = {
        absoluteURL:'findLocation',
        method:'get',
        query:{ _dynSessConf: '1234' },
        URLParams:{ skudId: 123123 }
      };
      const request = prepareRequest( conf );
      const expectedUrl = 'https://api.mapbox.com/geocoding/v5/mapbox.places/:searchValue.json';
      expect( request.url ).toBe( 'https://api.mapbox.com/geocoding/v5/mapbox.places/:searchValue.json' );
    } );

    it( 'should return proper data in url when dynamicURL is set', () => {
      setConfig( CONFIG );
      const conf = {
        dynamicURL:'https://test-dynamicURL.com',
        method:'post'
      };
      const request = prepareRequest( conf );
      expect( request.url ).toBe( 'https://test-dynamicURL.com' );
    } );

    it( 'should set customHeaders object as request header', () => {
      setConfig( CONFIG );
      const conf = {
        dynamicURL:'https://test-dynamicURL.com',
        method:'post',
        customHeaders:{ apiKey:'CXyyS9ghuVrNjZWoU5lBw6RI4elrSHth7Kg0TmQ42' }
      };
      const request = prepareRequest( conf );
      expect( request.header[ 'apiKey' ] ).toBe( 'CXyyS9ghuVrNjZWoU5lBw6RI4elrSHth7Kg0TmQ42' );
    } );

    it( 'should return proper data with _dynSessConf in headers when dynSessConf is not passed as query parameter', () => {
      setConfig( CONFIG );
      const conf = {
        absoluteURL:'findLocation',
        method:'get',
        URLParams:{ skudId: 123123 }
      };
      const request = prepareRequest( conf );
      const expectedOutput =  {
        'data': undefined,
        'headers': {
          'api-access-control': 'dyn_session_conf=2206040443193829401',
          'cache-control': 'no-cache,no-store,must-revalidate,max-age=-1,private',
          'expires': '-1',
          'user-agent': 'node-superagent/3.8.3',
          'x-requested-with': 'XMLHttpRequest'
        },
        'method': 'GET',
        'url': 'https://api.mapbox.com/geocoding/v5/mapbox.places/:searchValue.json'
      }
      expect( request.toJSON() ).toEqual( expectedOutput );
    } );

    it( 'should remove _dynSessConf if it is passed as query parameter', () => {
      setConfig( CONFIG );
      const conf = {
        absoluteURL:'findLocation',
        method:'get',
        URLParams:{ skudId: 123123 },
        query: { _dynSessConf: '1234', testParam: 'test' }
      }
      prepareRequest( conf );
      expect( conf.query ).toEqual( { testParam: 'test' } );
    } );

  } );

  describe( 'ajax method', () => {

    it( 'should call prepareRequest on ajax Method call', () => {
      const conf = {
        type:'session',
        method: 'post'
      };
      const prepareRequestMock = jest.fn( () => {
        return { then: jest.fn }
      } );
      const data = ajax( conf, prepareRequestMock );
      expect( prepareRequestMock ).toHaveBeenCalledWith( conf );
    } );

  } );

} );
