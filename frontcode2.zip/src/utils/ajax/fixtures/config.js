export const bodyContent = JSON.stringify(
  {
    'switches':{
      'brightTagSiteID': '6AfCeyh',
      'cartURL': '/bag',
      'checkoutCouponEnabled': true,
      'displayGWPEligibleLink': true,
      'emailSignUpURL': 'http://pages.exacttarget.com/ulta-email-signup/',
      'enableExpressPaypalCheckout': true,
      'enableIntlShipping': true,
      'enableLocalPowerReviewContent': true,
      'enableMoovweb': true,
      'enableQubitTag': true,
      'enableReflektionTag': true,
      'visualSearchEnabled': true,
      'enableSessionCamTag': true,
      'genericADSUrl': 'https://retailuat1.alldata.net/ultamaterewardscredit/pub/home.xhtml',
      'guestServiceHours': '7am-11pm',
      'guestServiceNumber': '1-866-983-8582',
      'googleSiteTagUrl': 'https://www.googletagmanager.com/gtag/js?id=AW-992679742',
      'learnMoreURL': '/ulta/creditcards/landingpage.jsp',
      'lpsTurnOff': false,
      'manageAccountCCUrl': 'https://retailuat1.alldata.net/ultamaterewardscreditcard',
      'manageAccountMCUrl': 'https://retailuat1.alldata.net/ultamaterewardsmastercard',
      'moovWebScriptURL': '//mc-assets.moovweb.net/ulta-staging/ba29ad9e-7699-475d-b314-74bd66ac80ba/loader/current/moovcheckout.js',
      'olapicPDPTurnOff': true,
      'paypalEnvironment': 'sandbox',
      'pdpOlapicDataInstance': '90a4d16c428660013a7739cc23936ee1',
      'powerReviewsMerchantId': '11984',
      'qubitScriptURL': '//d3c3cq33003psk.cloudfront.net/opentag-153688-ultadev.js',
      'qubitScriptURLSync': '//dd6zx4ibq538k.cloudfront.net/smartserve-4547.js',
      'realTimePreScreenEnabled': true,
      'refBeaconScriptUrl': '//168695269-prod.rfksrv.com/rf…260-168695269/init.js?cv=test',
      'saveForLaterEnabled': true,
      'scene7Host': '//images.ulta.com/',
      'scene7ImgPath': 'is/image/Ulta',
      'sessionCamScriptURL': '//d2oh4tlt9mrke9.cloudfront.net/Record/js/sessioncam.recorder.js',
      'siteHttpServerName': 'da3.ulta.com',
      'staticContentDomain': '//da3.ulta.com/',
      'staticContentImgPath': 'static/images',
      'storeLocatorURL': '/stores',
      'ultaBetaLogo': 'ULTAlogo_6_20?fmt=png-alpha',
      'storePickupEnabled': true,
      'ultaEmailSignUpConfig': {
        'confMsgDismissTime': 5,
        'guestUserWaitPeriod': 30,
        'showOnMobile': true,
        'regUserWaitPeriod': 90,
        'showOnDesktop': true,
        'waitTimeSFMobile': 0,
        'waitTimeSFDesktop': 0
      },
      'ultaGlobalSiteUrl': '//global-da3.ulta.com',
      'creditCardTokenForProduction': true,
      'creditCardTypeMapping': {
        'Ultamate Rewards MasterCard': '002',
        'AmericanExpress': '003',
        'Visa': '001',
        'Discover': '004',
        'Mastercard': '002'
      },
      'pageToRfkWidgetIdMapping': {
        'emptyCartPage': 'RFK_RECS_EMPTYCART',
        'productDetailsPage': 'RFK_RECS_PDP1',
        'friendly404Page': 'RFK_RECS_404',
        'addToCartPage': 'RFK_RECS_A2CMODAL',
        'nullSearchResultsPage': 'RFK_RECS_NULLSEARCH',
        'homePage': 'RFK_RECS_HOMEPG1,RFK_RECS_HOMEPG2',
        'cartPage': 'RFK_RECS_CART1,RFK_RECS_CART2'
      }
    }
  }
);

export default function( match, params, headers, context ){
  return {
    res: {
      text: bodyContent
    }
  }
}
