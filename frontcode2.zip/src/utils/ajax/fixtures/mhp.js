export const bodyContent = JSON.stringify(
  {
    serviceInfo: {
      lastFetchedTime: '2018-03-16 15:38:11.495-05:00'
    },
    pageContent: {
      hostName: 'qa3.ulta.com',
      omnitureContent: [[Object]],
      type: 'Page',
      httpsPort: '443',
      headerContent: null,
      port: '80',
      mainContent: []
    }
  }
)

export default function( match, params, headers, context ){
  return {
    res: {
      text: bodyContent
    }
  }
}

