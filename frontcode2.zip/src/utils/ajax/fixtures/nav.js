export const bodyContent = JSON.stringify( {
  'mobileNavContent':{
    'navType':'LeftNav',
    'shippingPromoContent':{
      'navElementType':'ShippingSlot',
      'navDisplayContent':'Shipping Slot',
      'content':'<div class="free-sample-cont cont-side">\n<div class="container">\n<div class="span9 float-right-cont inner-cont"><a href="#" class="free-samp-link" style="color:#222D3A;font:15px Helvetica"><strong>FREE SHIPPING<\/strong> <span style="color:#222D3A;font:15px Helvetica">on any $50 purchase. Test Alps<\/span><\/a><\/div>\n<\/div>\n<\/div>',
      'mobileContent':'<div class="container">\n<div class="span9 float-right-cont inner-cont"><a href="#" class="free-samp-link" style="color: white;font:15px Helvetica">FREE SHIPPING <span style="color:white;font:15px Helvetica">on any $50 purchase. <\/span><\/a><\/div>\n<\/div>'
    },
    'navList':[
      {
        'navDisplayContent':'SHOP',
        'navElementType':'SHOP',
        'categories':[
          {
            'navDisplayContent':'Brands',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/global/nav/allbrands.jsp',
              'data-nav-description':'m - brands',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'navDisplayContent':'New Arrivals',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/a/_/N-6?ciSelector=searchResults&pgName=whatsnew',
              'data-nav-description':'m - new arrivals',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'navDisplayContent':'Sale & Coupons',
            'navElementType':'rootCategory',
            'categories':[
              {
                'navElementType':'SubCategory',
                'categoryLink':{
                  'showInNewPage':false,
                  'navTargetLink':'https://qa3.ulta.com/promotion/buy-more-save-more/',
                  'data-nav-description':'m - sale & coupons:buy more save more',
                  'linkText':''
                },
                'navDisplayContent':'Buy More Save More'
              },
              {
                'navElementType':'SubCategory',
                'categoryLink':{
                  'showInNewPage':false,
                  'navTargetLink':'https://qa3.ulta.com/ulta/promotion/gift-with-purchase/',
                  'data-nav-description':'m - sale & coupons:gifts with purchase',
                  'linkText':''
                },
                'navDisplayContent':'Gifts With Purchase'
              },
              {
                'navElementType':'SubCategory',
                'categoryLink':{
                  'showInNewPage':false,
                  'navTargetLink':'https://qa3.ulta.com/ulta/a/_/N-1z13uvl?ciSelector=searchResults&pgName=specialOffers',
                  'data-nav-description':'m - sale & coupons:sale',
                  'linkText':''
                },
                'navDisplayContent':'Sale'
              },
              {
                'navElementType':'SubCategory',
                'categoryLink':{
                  'showInNewPage':false,
                  'navTargetLink':'https://qa3.ulta.com/ulta/global/ulta-coupon.jsp',
                  'data-nav-description':'m - sale & coupons:coupons',
                  'linkText':''
                },
                'navDisplayContent':'Coupons'
              }
            ],
            'categoryLink':{
              'dataNavDescription':'m - sale & coupons'
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'lineColor':'BK',
            'navElementType':'Filler',
            'navDisplayContent':'Filler',
            'insertBlank':false,
            'insertLine':false
          },
          {
            'displayFeatured':'false',
            'redirectURL':'https://qa3.ulta.com/makeup?N=26y1',
            'flyout':[

            ],
            'navDisplayContent':'MakeUp',
            'data-nav-description':'makeup:featured',
            'displayBookAppt':'true',
            'navElementType':'rootCategory',
            'categories':[
              {
                'navDisplayContent':'Face',
                'navTargetLink':'https://qa3.ulta.com/makeup-face?N=26y3',
                'data-nav-description':'m - makeup:face',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Foundation',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-foundation?N=26y5',
                    'data-nav-description':'m - makeup:face:foundation',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Face Powder',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-powder?N=26y8',
                    'data-nav-description':'m - makeup:face:face powder',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Concealer',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-concealer?N=26y6',
                    'data-nav-description':'m - makeup:face:concealer',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Color Correcting',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-color-correcting?N=dapq1e',
                    'data-nav-description':'m - makeup:face:color correcting',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Face Primer',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-primer?N=26y4',
                    'data-nav-description':'m - makeup:face:face primer',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'BB & CC Creams',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-bb-cc-creams?N=277u',
                    'data-nav-description':'m - makeup:face:bb & cc creams',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Blush',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-blush?N=277v',
                    'data-nav-description':'m - makeup:face:blush',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Bronzer',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-bronzer?N=26y9',
                    'data-nav-description':'m - makeup:face:bronzer',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Contouring',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-contouring?N=27eh',
                    'data-nav-description':'m - makeup:face:contouring',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Highlighter',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-highlighter?N=1v8rp2q',
                    'data-nav-description':'m - makeup:face:highlighter',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Setting Spray',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-setting-spray?N=qus6sj',
                    'data-nav-description':'m - makeup:face:setting spray',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Shine Control',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-shine-control?N=26yc',
                    'data-nav-description':'m - makeup:face:shine control',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Makeup Remover',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-makeup-remover?N=lycsxp',
                    'data-nav-description':'m - skin>ca=re changed test:cleansers:makeup remover',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Eyes',
                'navTargetLink':'https://qa3.ulta.com/makeup-eyes?N=26yd',
                'data-nav-description':'m - makeup:eyes',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Eyeshadow Palettes',
                    'navTargetLink':'https://qa3.ulta.com/makeup-eyes-eyeshadow-palettes?N=26ye',
                    'data-nav-description':'m - makeup:eyes:eyeshadow palettes',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Mascara',
                    'navTargetLink':'https://qa3.ulta.com/makeup-eyes-mascara?N=26yg',
                    'data-nav-description':'m - makeup:eyes:mascara',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Eyeliner',
                    'navTargetLink':'https://qa3.ulta.com/makeup-eyes-eyeliner?N=26yh',
                    'data-nav-description':'m - makeup:eyes:eyeliner',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Eyebrows',
                    'navTargetLink':'https://qa3.ulta.com/makeup-eyes-eyebrows?N=26yi',
                    'data-nav-description':'m - makeup:eyes:eyebrows',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Eyeshadow',
                    'navTargetLink':'https://qa3.ulta.com/makeup-eyes-eyeshadow?N=26yf',
                    'data-nav-description':'m - makeup:eyes:eyeshadow',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Eye Primer & Base',
                    'navTargetLink':'https://qa3.ulta.com/makeup-eye-primer-base?N=26yl',
                    'data-nav-description':'m - makeup:eyes:eye primer & base',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Eyelashes',
                    'navTargetLink':'https://qa3.ulta.com/makeup-eyes-eyelashes?N=26yj',
                    'data-nav-description':'m - makeup:eyes:eyelashes',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Eye Makeup Remover',
                    'navTargetLink':'https://qa3.ulta.com/makeup-eye-makeup-remover?N=26yk',
                    'data-nav-description':'m - makeup:eyes:eye makeup remover',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Lips',
                'navTargetLink':'https://qa3.ulta.com/makeup-lips?N=26yq',
                'data-nav-description':'m - makeup:lips',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Lipstick',
                    'navTargetLink':'https://qa3.ulta.com/makeup-lips-lipstick?N=26ys',
                    'data-nav-description':'m - makeup:lips:lipstick',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Lip Gloss',
                    'navTargetLink':'https://qa3.ulta.com/makeup-lip-gloss?N=26yt',
                    'data-nav-description':'m - makeup:lips:lip gloss',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Lip Liner',
                    'navTargetLink':'https://qa3.ulta.com/makeup-lip-liner?N=26yv',
                    'data-nav-description':'m - makeup:lips:lip liner',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Lip Stain',
                    'navTargetLink':'https://qa3.ulta.com/makeup-lip-stain?N=26yu',
                    'data-nav-description':'m - makeup:lips:lip stain',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Treatments & Balms',
                    'navTargetLink':'https://qa3.ulta.com/makeup-lips-treatments-balms?N=26yw',
                    'data-nav-description':'m - makeup:lips:treatments & balms',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Sets & Palettes',
                    'navTargetLink':'https://qa3.ulta.com/makeup-lips-sets-palettes?N=26yr',
                    'data-nav-description':'m - makeup:lips:sets & palettes',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Makeup Brushes & Tools',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools?N=hi56mr',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Brush Sets',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brush-sets?N=i4us25',
                    'data-nav-description':'m - tools & brushes:makeup brushes & tools:brush sets',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Makeup Brushes',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-makeup-brushes?N=s88qgw',
                    'data-nav-description':'m - tools & brushes:makeup brushes & tools:makeup brushes',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Sponges & Applicators',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-sponges-applicators?N=y7ddtv',
                    'data-nav-description':'m - tools & brushes:makeup brushes & tools:sponges & applicators',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Brush Cleaner',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brush-cleaner?N=k9zut0',
                    'data-nav-description':'m - tools & brushes:makeup brushes & tools:brush cleaner',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Brow & Lash Tools',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brow-lash-tools?N=o74qbj',
                    'data-nav-description':'m - tools & brushes:makeup brushes & tools:brow & lash tools',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Mirrors',
                    'navTargetLink':'https://qa3.ulta.com/makeup-brushes-tools-mirrors?N=277r',
                    'data-nav-description':'m - makeup:makeup brushes & tools:mirrors',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Sharpeners',
                    'navTargetLink':'https://qa3.ulta.com/makeup-brushes-tools-sharpeners?N=27cj',
                    'data-nav-description':'m - makeup:makeup brushes & tools:sharpeners',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Makeup Bags & Cases',
                'navTargetLink':'https://qa3.ulta.com/makeup-bags-cases?N=26zp',
                'data-nav-description':'m - makeup:makeup bags & cases',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'ULTA Collection',
                'navTargetLink':'https://qa3.ulta.com/makeup-ulta-collection?N=26zi',
                'data-nav-description':'m - makeup:ulta collection',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Travel Size',
                'navTargetLink':'https://qa3.ulta.com/makeup-travel-size?N=2782',
                'data-nav-description':'m - makeup:travel size',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Gifts & Value Sets',
                'navTargetLink':'https://qa3.ulta.com/makeup-gifts-value-sets?N=26zo',
                'data-nav-description':'m - makeup:gifts & value sets',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Makeup Palettes',
                    'navTargetLink':'https://qa3.ulta.com/makeup-gifts-value-sets-makeup-palettes?N=1jeq7ud',
                    'data-nav-description':'m - makeup:gifts & value sets:makeup palettes',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Value Sets',
                    'navTargetLink':'https://qa3.ulta.com/makeup-gifts-value-sets-value-sets?N=ubsuml',
                    'data-nav-description':'m - makeup:gifts & value sets:value sets',
                    'navElementType':'subCategory'
                  }
                ]
              }
            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/makeup?N=26y1',
              'data-nav-description':'m - makeup',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black',
            'bookApptLabel':'Book a Makeup Application',
            'bookApptLink':'https://qa3.ulta.com/ulta/stores/storelocator.jsp?fromsalon=true'
          },
          {
            'displayFeatured':'false',
            'flyout':[

            ],
            'navDisplayContent':'Nails',
            'data-nav-description':'nails:featured',
            'displayBookAppt':'true',
            'navElementType':'rootCategory',
            'categories':[
              {
                'navDisplayContent':'Nail Polish',
                'navTargetLink':'https://qa3.ulta.com/nail-polish?N=278s',
                'data-nav-description':'m - nails:nail polish',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Gel Manicure',
                'navTargetLink':'https://qa3.ulta.com/nails-gel-manicure?N=278j',
                'data-nav-description':'m - nails:gel manicure',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Top & Base Coats',
                'navTargetLink':'https://qa3.ulta.com/nails-top-base-coats?N=1pf4yzp',
                'data-nav-description':'m - nails:top & base coats',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Nail Art & Design',
                'navTargetLink':'https://qa3.ulta.com/nail-art-design?N=27br',
                'data-nav-description':'m - nails:nail art & design',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Nail Care',
                'navTargetLink':'https://qa3.ulta.com/nail-care?N=27bs',
                'data-nav-description':'m - nails:nail care',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Removers',
                    'navTargetLink':'https://qa3.ulta.com/nail-care-removers?N=27bt',
                    'data-nav-description':'m - nails:nail care:removers',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Cuticle Care',
                    'navTargetLink':'https://qa3.ulta.com/nail-care-cuticle-care?N=27bv',
                    'data-nav-description':'m - nails:nail care:cuticle care',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Nail Treatments',
                    'navTargetLink':'https://qa3.ulta.com/nail-care-nail-treatments?N=27bw',
                    'data-nav-description':'m - nails:nail care:nail treatments',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Manicure & Pedicure Tools',
                'navTargetLink':'https://qa3.ulta.com/bath-body-hand-foot-care-manicure-pedicure-tools?N=oy1nnu',
                'data-nav-description':'m - bath & body:hand & foot care:manicure & pedicure tools',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Gifts & Value Sets',
                'navTargetLink':'https://qa3.ulta.com/nails-gifts-value-sets?N=27c1',
                'data-nav-description':'m - nails:gifts & value sets',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'ULTA Collection',
                'navTargetLink':'https://qa3.ulta.com/nails-ulta-collection?N=27c5',
                'data-nav-description':'m - nails:ulta collection',
                'navElementType':'subCategory'
              }
            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/nails?N=271o',
              'data-nav-description':'m - nails',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black',
            'bookApptLabel':'Book a Nail Appointment',
            'bookApptLink':'https://qa3.ulta.com/ulta/stores/storelocator.jsp?fromsalon=true'
          },
          {
            'displayFeatured':'false',
            'flyout':[

            ],
            'navDisplayContent':'Skincare',
            'data-nav-description':'skincare:featured',
            'displayBookAppt':'true',
            'navElementType':'rootCategory',
            'categories':[
              {
                'navDisplayContent':'Cleansers',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers?N=2794',
                'data-nav-description':'m - skin>ca=re changed test:cleansers',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Face Wash',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-face-wash?N=ejr3qt',
                    'data-nav-description':'m - skin>ca=re changed test:cleansers:face wash',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Cleansing Oils',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-cleansing-oils?N=19bm2ov',
                    'data-nav-description':'m - skin>ca=re changed test:cleansers:cleansing oils',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Cleansing Wipes',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-cleansing-wipes?N=wd4464',
                    'data-nav-description':'m - skin>ca=re changed test:cleansers:cleansing wipes',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Exfoliators & Scrubs',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-exfoliators-scrubs?N=1rpwjr7',
                    'data-nav-description':'m - skin>ca=re changed test:cleansers:exfoliators & scrubs',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Toner',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-toner?N=4ui8iu',
                    'data-nav-description':'m - skin>ca=re changed test:cleansers:toner',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Makeup Remover',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-makeup-remover?N=lycsxp',
                    'data-nav-description':'m - skin>ca=re changed test:cleansers:makeup remover',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Cleansing Brushes',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-cleansing-brushes?N=e4ntnr',
                    'data-nav-description':'m - skin>ca=re changed test:cleansers:cleansing brushes',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Moisturizers',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers?N=2796',
                'data-nav-description':'m - skin>ca=re changed test:moisturizers',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Face Moisturizer',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-face-moisturizer?N=1an7g60',
                    'data-nav-description':'m - skin>ca=re changed test:moisturizers:face moisturizer',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Night Cream',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers-night-cream?N=7a2js3',
                    'data-nav-description':'m - skin>ca=re changed test:moisturizers:night cream',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Face Oil',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers-face-oil?N=1bvd8gl',
                    'data-nav-description':'m - skin>ca=re changed test:moisturizers:face oil',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Face Mist',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers-face-mist?N=q2cjc8',
                    'data-nav-description':'m - skin>ca=re changed test:moisturizers:face mist',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Decollete & Neck Cream',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers-decollete-neck-cream?N=nfabzb',
                    'data-nav-description':'m - skin>ca=re changed test:moisturizers:decollete & neck cream',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'BB & CC Creams',
                    'navTargetLink':'https://qa3.ulta.com/makeup-face-bb-cc-creams?N=277u',
                    'data-nav-description':'m - makeup:face:bb & cc creams',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Lip Care',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers-lip-care?N=l341or',
                    'data-nav-description':'m - skin>ca=re changed test:moisturizers:lip care',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Treatment & Serums',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums?N=27cs',
                'data-nav-description':'m - skin>ca=re changed test:treatment & serums',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Face Serums',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums-face-serums?N=xiyuqr',
                    'data-nav-description':'m - skin>ca=re changed test:treatment & serums:face serums',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Facial Peels',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums-facial-peels?N=k3cm80',
                    'data-nav-description':'m - skin>ca=re changed test:treatment & serums:facial peels',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Face Masks',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums-face-masks?N=17grb4h',
                    'data-nav-description':'m - skin>ca=re changed test:treatment & serums:face masks',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Sheet Masks',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums-sheet-masks?N=1rr85ua',
                    'data-nav-description':'m - skin>ca=re changed test:treatment & serums:sheet masks',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Acne & Blemish Treatments',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums-acne-blemish-treatments?N=7h6z66',
                    'data-nav-description':'m - skin>ca=re changed test:treatment & serums:acne & blemish treatments',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Eye Treatments--Test',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-eye-treatments-test?N=270k',
                'data-nav-description':'m - skin>ca=re changed test:eye treatments--test',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Eye Cream',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-eye-treatments-test-eye-cream?N=xd1men',
                    'data-nav-description':'m - skin>ca=re changed test:eye treatments--test:eye cream',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Eye Serums',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-eye-treatments-test-eye-serums?N=cb4sj0',
                    'data-nav-description':'m - skin>ca=re changed test:eye treatments--test:eye serums',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Eye Masks',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-eye-treatments-test-eye-masks?N=b8bsuf',
                    'data-nav-description':'m - skin>ca=re changed test:eye treatments--test:eye masks',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Suncare',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-suncare?N=27fe',
                'data-nav-description':'m - skin>ca=re changed test:suncare',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Sunscreen',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-suncare-sunscreen?N=27ff',
                    'data-nav-description':'m - skin>ca=re changed test:suncare:sunscreen',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Self-Tanning & Bronzing',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-suncare-self-tanning-bronzing?N=27fg',
                    'data-nav-description':'m - skin>ca=re changed test:suncare:self-tanning & bronzing',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'After Sun Care',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-suncare-after-sun-care?N=5ulj51',
                    'data-nav-description':'m - skin>ca=re changed test:suncare:after sun care',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Supplements',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-supplements?N=2712',
                'data-nav-description':'m - skin>ca=re changed test:supplements',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Mother & Baby',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-mother-baby?N=2715',
                'data-nav-description':'m - skin>ca=re changed test:mother & baby',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Tools',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-tools?N=2718',
                'data-nav-description':'m - skin>ca=re changed test:tools',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Cleansing Brushes',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-cleansing-brushes?N=e4ntnr',
                    'data-nav-description':'m - skin>ca=re changed test:cleansers:cleansing brushes',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Spa Tools',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-spa-tools?N=rlvnt5',
                    'data-nav-description':'m - skin>ca=re changed test:tools:spa tools',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Acne Removal',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-skincare-tools-acne-removal?N=6rsvyw',
                    'data-nav-description':'m - tools & brushes:skincare tools:acne removal',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'ULTA Collection',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-ulta-collection?N=2713',
                'data-nav-description':'m - skin>ca=re changed test:ulta collection',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Travel Size',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-travel-size?N=279d',
                'data-nav-description':'m - skin>ca=re changed test:travel size',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Gifts & Value Sets',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-gifts-value-sets?N=2717',
                'data-nav-description':'m - skin>ca=re changed test:gifts & value sets',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Korean Skin Care',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-korean-skin-care?N=1jrcu47',
                'data-nav-description':'m - skin>ca=re changed test:korean skin care',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Natural Skin Care',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-natural-skin-care?N=1hzlhrt',
                'data-nav-description':'m - skin>ca=re changed test:natural skin care',
                'navElementType':'subCategory'
              }
            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/skincare-changed-test?N=2707',
              'data-nav-description':'m - skincare',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black',
            'bookApptLabel':'Book a Skincare Service',
            'bookApptLink':'https://qa3.ulta.com/ulta/stores/storelocator.jsp?fromsalon=true'
          },
          {
            'displayFeatured':'false',
            'flyout':[

            ],
            'navDisplayContent':'Hair',
            'data-nav-description':'hair:featured',
            'displayBookAppt':'true',
            'navElementType':'rootCategory',
            'categories':[
              {
                'navDisplayContent':'Shampoo & Conditioner',
                'navTargetLink':'https://qa3.ulta.com/hair-shampoo-conditioner?N=mwxuai',
                'data-nav-description':'m - hair:shampoo & conditioner',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Shampoo',
                    'navTargetLink':'https://qa3.ulta.com/hair-shampoo-conditioner-shampoo?N=ecypd2',
                    'data-nav-description':'m - hair:shampoo & conditioner:shampoo',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Dry Shampoo',
                    'navTargetLink':'https://qa3.ulta.com/hair-shampoo-conditioner-dry-shampoo?N=15jnupp',
                    'data-nav-description':'m - hair:shampoo & conditioner:dry shampoo',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Conditioner',
                    'navTargetLink':'https://qa3.ulta.com/hair-shampoo-conditioner-conditioner?N=1jd6tgg',
                    'data-nav-description':'m - hair:shampoo & conditioner:conditioner',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Cleansing Conditioner',
                    'navTargetLink':'https://qa3.ulta.com/hair-shampoo-conditioner-cleansing-conditioner?N=wozuev',
                    'data-nav-description':'m - hair:shampoo & conditioner:cleansing conditioner',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Treatment',
                'navTargetLink':'https://qa3.ulta.com/hair-treatment?N=26xy',
                'data-nav-description':'m - hair:treatment',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Oils & Serums',
                    'navTargetLink':'https://qa3.ulta.com/hair-treatment-oils-serums?N=18462b',
                    'data-nav-description':'m - hair:treatment:oils & serums',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Masks',
                    'navTargetLink':'https://qa3.ulta.com/hair-treatment-masks?N=dqpmkn',
                    'data-nav-description':'m - hair:treatment:masks',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Hair Thinning & Hair Loss',
                    'navTargetLink':'https://qa3.ulta.com/hair-treatment-hair-thinning-hair-loss?N=1k7fo3k',
                    'data-nav-description':'m - hair:treatment:hair thinning & hair loss',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Leave-In Treatment',
                    'navTargetLink':'https://qa3.ulta.com/hair-leave-in-treatment?N=14wdtcy',
                    'data-nav-description':'m - hair:treatment:leave-in treatment',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Styling=Prod>ucts% new',
                'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new?N=26xf',
                'data-nav-description':'m - hair:styling=prod>ucts% new',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Hairspray',
                    'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-hairspray?N=dyokub',
                    'data-nav-description':'m - hair:styling=prod>ucts% new:hairspray',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Volume & Texture',
                    'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-volume-texture?N=1xvbie',
                    'data-nav-description':'m - hair:styling=prod>ucts% new:volume & texture',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Heat Protectant',
                    'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-heat-protectant?N=1tulu1d',
                    'data-nav-description':'m - hair:styling=prod>ucts% new:heat protectant',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Gloss & Shine',
                    'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-gloss-shine?N=48qfaq',
                    'data-nav-description':'m - hair:styling=prod>ucts% new:gloss & shine',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Smoothing',
                    'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-smoothing?N=1ach964',
                    'data-nav-description':'m - hair:styling=prod>ucts% new:smoothing',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Curl Enhancing',
                    'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-curl-enhancing?N=a65zzt',
                    'data-nav-description':'m - hair:styling=prod>ucts% new:curl enhancing',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Wax & Pomade',
                    'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-wax-pomade?N=mug6z5',
                    'data-nav-description':'m - hair:styling=prod>ucts% new:wax & pomade',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Hair Color',
                'navTargetLink':'https://qa3.ulta.com/hair-color?N=26xs',
                'data-nav-description':'m - hair:hair color',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hair Styling Tools',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools?N=w5a8a9',
                'data-nav-description':'m - tools & brushes:hair styling tools',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Flat Irons',
                    'navTargetLink':'https://qa3.ulta.com/hair-styling-tools-flat-irons?N=26xq',
                    'data-nav-description':'m - hair:hair styling tools:flat irons',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Hair Dryers',
                    'navTargetLink':'https://qa3.ulta.com/hair-styling-tools-hair-dryers?N=26xo',
                    'data-nav-description':'m - hair:hair styling tools:hair dryers',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Curling Irons & Stylers',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools-curling-irons-stylers?N=l3gmtv',
                    'data-nav-description':'m - tools & brushes:hair styling tools:curling irons & stylers',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Hot Rollers',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools-hot-rollers?N=d3uwph',
                    'data-nav-description':'m - tools & brushes:hair styling tools:hot rollers',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Hair Brushes & Combs',
                'navTargetLink':'https://qa3.ulta.com/hair-brushes-combs?N=2778',
                'data-nav-description':'m - hair:hair brushes & combs',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Accessories',
                'navTargetLink':'https://qa3.ulta.com/hair-accessories?N=26y0',
                'data-nav-description':'m - hair:accessories',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Hair Extensions',
                    'navTargetLink':'https://qa3.ulta.com/hair-accessories-hair-extensions?N=2774',
                    'data-nav-description':'m - hair:accessories:hair extensions',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Elastics',
                    'navTargetLink':'https://qa3.ulta.com/hair-accessories-elastics?N=2773',
                    'data-nav-description':'m - hair:accessories:elastics',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Headbands',
                    'navTargetLink':'https://qa3.ulta.com/hair-accessories-headbands?N=2776',
                    'data-nav-description':'m - hair:accessories:headbands',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Clips & Bobby Pins',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-accessories-clips-bobby-pins?N=lx44ft',
                    'data-nav-description':'m - tools & brushes:accessories:clips & bobby pins',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Styling Accessories',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-styling-accessories?N=fnixer',
                    'data-nav-description':'m - tools & brushes:accessories:styling accessories',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Trend Accessories',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-trend-accessories?N=r8p81m',
                    'data-nav-description':'m - tools & brushes:accessories:trend accessories',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Kid\'s Haircare',
                'navTargetLink':'https://qa3.ulta.com/hair-kids-haircare?N=26xz',
                'data-nav-description':'m - hair:kid\'s haircare',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'ULTA Collection',
                'navTargetLink':'https://qa3.ulta.com/hair-ulta-collection?N=26xx',
                'data-nav-description':'m - hair:ulta collection',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Travel Size',
                'navTargetLink':'https://qa3.ulta.com/hair-travel-size?N=27ci',
                'data-nav-description':'m - hair:travel size',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Gifts & Value Sets',
                'navTargetLink':'https://qa3.ulta.com/hair-gifts-value-sets?N=277l',
                'data-nav-description':'m - hair:gifts & value sets',
                'navElementType':'subCategory'
              }
            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/hair?N=26wz',
              'data-nav-description':'m - hair',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black',
            'bookApptLabel':'Book a Hair Appointment',
            'bookApptLink':'https://qa3.ulta.com/ulta/stores/storelocator.jsp?fromsalon=true'
          },
          {
            'displayFeatured':'false',
            'flyout':[

            ],
            'navDisplayContent':'Tools & Brushes',
            'data-nav-description':'tools & brushes:featured',
            'displayBookAppt':'false',
            'navElementType':'rootCategory',
            'categories':[
              {
                'navDisplayContent':'Hair Styling Tools',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools?N=w5a8a9',
                'data-nav-description':'m - tools & brushes:hair styling tools',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Flat Irons',
                    'navTargetLink':'https://qa3.ulta.com/hair-styling-tools-flat-irons?N=26xq',
                    'data-nav-description':'m - hair:hair styling tools:flat irons',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Hair Dryers',
                    'navTargetLink':'https://qa3.ulta.com/hair-styling-tools-hair-dryers?N=26xo',
                    'data-nav-description':'m - hair:hair styling tools:hair dryers',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Curling Irons & Stylers',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools-curling-irons-stylers?N=l3gmtv',
                    'data-nav-description':'m - tools & brushes:hair styling tools:curling irons & stylers',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Hot Rollers',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools-hot-rollers?N=d3uwph',
                    'data-nav-description':'m - tools & brushes:hair styling tools:hot rollers',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Skincare Tools',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-skincare-tools?N=19rs4ow',
                'data-nav-description':'m - tools & brushes:skincare tools',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Cleansing Brushes',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-cleansing-brushes?N=e4ntnr',
                    'data-nav-description':'m - skin>ca=re changed test:cleansers:cleansing brushes',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Spa Tools',
                    'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-spa-tools?N=rlvnt5',
                    'data-nav-description':'m - skin>ca=re changed test:tools:spa tools',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Acne Removal',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-skincare-tools-acne-removal?N=6rsvyw',
                    'data-nav-description':'m - tools & brushes:skincare tools:acne removal',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Hair Removal Tools',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-removal-tools?N=1sx5op9',
                'data-nav-description':'m - tools & brushes:hair removal tools',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Makeup Brushes & Tools',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools?N=hi56mr',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Brush Sets',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brush-sets?N=i4us25',
                    'data-nav-description':'m - tools & brushes:makeup brushes & tools:brush sets',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Makeup Brushes',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-makeup-brushes?N=s88qgw',
                    'data-nav-description':'m - tools & brushes:makeup brushes & tools:makeup brushes',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Sponges & Applicators',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-sponges-applicators?N=y7ddtv',
                    'data-nav-description':'m - tools & brushes:makeup brushes & tools:sponges & applicators',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Brush Cleaner',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brush-cleaner?N=k9zut0',
                    'data-nav-description':'m - tools & brushes:makeup brushes & tools:brush cleaner',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Brow & Lash Tools',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brow-lash-tools?N=o74qbj',
                    'data-nav-description':'m - tools & brushes:makeup brushes & tools:brow & lash tools',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Mirrors',
                    'navTargetLink':'https://qa3.ulta.com/makeup-brushes-tools-mirrors?N=277r',
                    'data-nav-description':'m - makeup:makeup brushes & tools:mirrors',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Sharpeners',
                    'navTargetLink':'https://qa3.ulta.com/makeup-brushes-tools-sharpeners?N=27cj',
                    'data-nav-description':'m - makeup:makeup brushes & tools:sharpeners',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Hair Brushes & Combs',
                'navTargetLink':'https://qa3.ulta.com/hair-brushes-combs?N=2778',
                'data-nav-description':'m - hair:hair brushes & combs',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Accessories',
                'navTargetLink':'https://qa3.ulta.com/hair-accessories?N=26y0',
                'data-nav-description':'m - hair:accessories',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Hair Extensions',
                    'navTargetLink':'https://qa3.ulta.com/hair-accessories-hair-extensions?N=2774',
                    'data-nav-description':'m - hair:accessories:hair extensions',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Elastics',
                    'navTargetLink':'https://qa3.ulta.com/hair-accessories-elastics?N=2773',
                    'data-nav-description':'m - hair:accessories:elastics',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Headbands',
                    'navTargetLink':'https://qa3.ulta.com/hair-accessories-headbands?N=2776',
                    'data-nav-description':'m - hair:accessories:headbands',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Clips & Bobby Pins',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-accessories-clips-bobby-pins?N=lx44ft',
                    'data-nav-description':'m - tools & brushes:accessories:clips & bobby pins',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Styling Accessories',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-styling-accessories?N=fnixer',
                    'data-nav-description':'m - tools & brushes:accessories:styling accessories',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Trend Accessories',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-trend-accessories?N=r8p81m',
                    'data-nav-description':'m - tools & brushes:accessories:trend accessories',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Gifts & Value Sets',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-gifts-value-sets?N=j55azv',
                'data-nav-description':'m - tools & brushes:gifts & value sets',
                'navElementType':'subCategory'
              }
            ],
            'categoryLink':{
              'showInNewPage':true,
              'navTargetLink':'https://qa3.ulta.com/tools-brushes?N=1qp05hl',
              'data-nav-description':'m - tools & brushes',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'displayFeatured':'false',
            'flyout':[

            ],
            'navDisplayContent':'Fragrance',
            'data-nav-description':'fragrance:featured',
            'displayBookAppt':'false',
            'navElementType':'rootCategory',
            'categories':[
              {
                'navDisplayContent':'Women\'s Fragrance',
                'navTargetLink':'https://qa3.ulta.com/womens-fragrance?N=26wn',
                'data-nav-description':'m - fragrance:women\'s fragrance',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Perfume',
                    'navTargetLink':'https://qa3.ulta.com/womens-fragrance-perfume?N=26wq',
                    'data-nav-description':'m - fragrance:women\'s fragrance:perfume',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Rollerballs & Purse Sprays',
                    'navTargetLink':'https://qa3.ulta.com/womens-fragrance-rollerballs-purse-sprays?N=26wo',
                    'data-nav-description':'m - fragrance:women\'s fragrance:rollerballs & purse sprays',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Body Lotions',
                    'navTargetLink':'https://qa3.ulta.com/womens-fragrance-body-lotions?N=26ws',
                    'data-nav-description':'m - fragrance:women\'s fragrance:body lotions',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Body Mist & Hair Mist',
                    'navTargetLink':'https://qa3.ulta.com/womens-fragrance-body-mist-hair-mist?N=26wr',
                    'data-nav-description':'m - fragrance:women\'s fragrance:body mist & hair mist',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Bath & Shower',
                    'navTargetLink':'https://qa3.ulta.com/womens-fragrance-bath-shower?N=10err6y',
                    'data-nav-description':'m - fragrance:women\'s fragrance:bath & shower',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Men\'s Fragrance',
                'navTargetLink':'https://qa3.ulta.com/mens-fragrance?N=26wf',
                'data-nav-description':'m - fragrance:men\'s fragrance',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Cologne',
                    'navTargetLink':'https://qa3.ulta.com/mens-fragrance-cologne?N=26wg',
                    'data-nav-description':'m - fragrance:men\'s fragrance:cologne',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Aftershave',
                    'navTargetLink':'https://qa3.ulta.com/mens-fragrance-aftershave?N=26wi',
                    'data-nav-description':'m - fragrance:men\'s fragrance:aftershave',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Bath & Shower',
                    'navTargetLink':'https://qa3.ulta.com/mens-fragrance-bath-shower?N=xh2wl7',
                    'data-nav-description':'m - fragrance:men\'s fragrance:bath & shower',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Fragrance Gift Sets',
                'navTargetLink':'https://qa3.ulta.com/fragrance-gift-sets?N=27dg',
                'data-nav-description':'m - gifts:fragrance gift sets',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Perfume Gift Sets',
                    'navTargetLink':'https://qa3.ulta.com/fragrance-gift-sets-perfume-gift-sets?N=1gschg4',
                    'data-nav-description':'m - gifts:fragrance gift sets:perfume gift sets',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Cologne Gift Sets',
                    'navTargetLink':'https://qa3.ulta.com/fragrance-gift-sets-cologne-gift-sets?N=81cgoh',
                    'data-nav-description':'m - fragrance:fragrance gift sets:cologne gift sets',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Candles',
                'data-nav-description':'m - :candles',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Fragrance Finder',
                'navTargetLink':'https://qa3.ulta.com/fragrance-finder?N=27fl',
                'data-nav-description':'m - fragrance:fragrance finder',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Fragrance Crush',
                'navTargetLink':'https://qa3.ulta.com/fragrance-crush?N=wi8zoa',
                'data-nav-description':'m - fragrance:fragrance crush',
                'navElementType':'subCategory'
              }
            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/fragrance?N=26wa',
              'data-nav-description':'m - fragrance',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'displayFeatured':'false',
            'flyout':[

            ],
            'navDisplayContent':'Bath & Body',
            'data-nav-description':'bath & body:featured',
            'displayBookAppt':'false',
            'navElementType':'rootCategory',
            'categories':[
              {
                'navDisplayContent':'Bath & Shower',
                'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower?N=26uy',
                'data-nav-description':'m - bath & body:bath & shower',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Shower Gel & Body Wash',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower-shower-gel-body-wash?N=26uz',
                    'data-nav-description':'m - bath & body:bath & shower:shower gel & body wash',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Body Scrubs & Exfoliants',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower-body-scrubs-exfoliants?N=2765',
                    'data-nav-description':'m - bath & body:bath & shower:body scrubs & exfoliants',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Bubble Bath & Oil',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower-bubble-bath-oil?N=1h01mtr',
                    'data-nav-description':'m - bath & body:bath & shower:bubble bath & oil',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Bath Salts & Soaks',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower-bath-salts-soaks?N=kk6gxq',
                    'data-nav-description':'m - bath & body:bath & shower:bath salts & soaks',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Hand Soap & Wash',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower-hand-soap-wash?N=26v1',
                    'data-nav-description':'m - bath & body:bath & shower:hand soap & wash',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Body Moisturizers',
                'navTargetLink':'https://qa3.ulta.com/bath-body-body-moisturizers?N=26v3',
                'data-nav-description':'m - bath & body:body moisturizers',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Body Lotion & Creams',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-body-moisturizers-body-lotion-creams?N=26v4',
                    'data-nav-description':'m - bath & body:body moisturizers:body lotion & creams',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Body Oils',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-body-moisturizers-body-oils?N=26v6',
                    'data-nav-description':'m - bath & body:body moisturizers:body oils',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Hand & Foot Care',
                'navTargetLink':'https://qa3.ulta.com/bath-body-hand-foot-care?N=gt9muu',
                'data-nav-description':'m - bath & body:hand & foot care',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Hand Cream & Foot Cream',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-hand-foot-care-hand-cream-foot-cream?N=1nlwj8i',
                    'data-nav-description':'m - bath & body:hand & foot care:hand cream & foot cream',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Hand & Foot Treatment',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-hand-foot-care-hand-foot-treatment?N=ghlrda',
                    'data-nav-description':'m - bath & body:hand & foot care:hand & foot treatment',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Manicure & Pedicure Tools',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-hand-foot-care-manicure-pedicure-tools?N=oy1nnu',
                    'data-nav-description':'m - bath & body:hand & foot care:manicure & pedicure tools',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Personal Care',
                'navTargetLink':'https://qa3.ulta.com/bath-body-personal-care?N=m6j326',
                'data-nav-description':'m - bath & body:personal care',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Cellulite & Stretch Marks',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-personal-care-cellulite-stretch-marks?N=18ms76q',
                    'data-nav-description':'m - bath & body:personal care:cellulite & stretch marks',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Hair Removal',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-personal-care-hair-removal?N=1fjm35s',
                    'data-nav-description':'m - bath & body:personal care:hair removal',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Deodorant',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-personal-care-deodorant?N=ca9qdp',
                    'data-nav-description':'m - bath & body:personal care:deodorant',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Teeth <White,ning&update',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-personal-care-teeth-whitening-update?N=16nzokk',
                    'data-nav-description':'m - bath & body:personal care:teeth <white,ning&update',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Bath & Body Accessories',
                'navTargetLink':'https://qa3.ulta.com/bath-body-accessories?N=i95dis',
                'data-nav-description':'m - bath & body:bath & body accessories',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Bath Sponges & Towels',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-accessories-bath-sponges-towels?N=eqo4ul',
                    'data-nav-description':'m - bath & body:bath & body accessories:bath sponges & towels',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Spa Essentials',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-accessories-spa-essentials?N=1134tzx',
                    'data-nav-description':'m - bath & body:bath & body accessories:spa essentials',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Trend Accessories',
                    'navTargetLink':'https://qa3.ulta.com/tools-brushes-trend-accessories?N=r8p81m',
                    'data-nav-description':'m - tools & brushes:accessories:trend accessories',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Suncare',
                'navTargetLink':'https://qa3.ulta.com/bath-body-suncare?N=276b',
                'data-nav-description':'m - bath & body:suncare',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Sunscreen',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-suncare-sunscreen?N=27fc',
                    'data-nav-description':'m - bath & body:suncare:sunscreen',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Self-Tanning & Bronzing',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-suncare-self-tanning-bronzing?N=276e',
                    'data-nav-description':'m - bath & body:suncare:self-tanning & bronzing',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'After Sun Care',
                    'navTargetLink':'https://qa3.ulta.com/bath-body-suncare-after-sun-care?N=27fd',
                    'data-nav-description':'m - bath & body:suncare:after sun care',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'ULTA Collection',
                'navTargetLink':'https://qa3.ulta.com/bath-body-ulta-collection?N=26vk',
                'data-nav-description':'m - bath & body:ulta collection',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Travel Size',
                'navTargetLink':'https://qa3.ulta.com/bath-body-travel-size?N=276l',
                'data-nav-description':'m - bath & body:travel size',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Gifts & Value Sets',
                'navTargetLink':'https://qa3.ulta.com/bath-body-gifts-value-sets?N=26vq',
                'data-nav-description':'m - bath & body:gifts & value sets',
                'navElementType':'subCategory'
              }
            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/bath-body?N=26us',
              'data-nav-description':'m - bath & body',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'displayFeatured':'false',
            'flyout':[

            ],
            'navDisplayContent':'Men',
            'data-nav-description':'men:featured',
            'displayBookAppt':'false',
            'navElementType':'rootCategory',
            'categories':[
              {
                'navDisplayContent':'Skin Care',
                'navTargetLink':'https://qa3.ulta.com/men-skin-care?N=27ck',
                'data-nav-description':'m - men:skin care',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Face Wash',
                    'navTargetLink':'https://qa3.ulta.com/men-skin-care-face-wash?N=27cl',
                    'data-nav-description':'m - men:skin care:face wash',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Moisturizers & Treatments',
                    'navTargetLink':'https://qa3.ulta.com/men-skin-care-moisturizers-treatments?N=27cm',
                    'data-nav-description':'m - men:skin care:moisturizers & treatments',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Shaving',
                'navTargetLink':'https://qa3.ulta.com/men-shaving?N=1czga4k',
                'data-nav-description':'m - men:shaving',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Shaving Cream & Razors',
                    'navTargetLink':'https://qa3.ulta.com/men-shaving-cream-razors?N=11jah3e',
                    'data-nav-description':'m - men:shaving:shaving cream & razors',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Aftershave',
                    'navTargetLink':'https://qa3.ulta.com/men-shaving-aftershave?N=zn154p',
                    'data-nav-description':'m - men:shaving:aftershave',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Beard Care',
                    'navTargetLink':'https://qa3.ulta.com/men-shaving-beard-care?N=14j6xlf',
                    'data-nav-description':'m - men:shaving:beard care',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Body Care',
                'navTargetLink':'https://qa3.ulta.com/men-body-care?N=fita0k',
                'data-nav-description':'m - men:body care',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Shower Gel & Body Wash',
                    'navTargetLink':'https://qa3.ulta.com/men-body-care-shower-gel-body-wash?N=vdu4am',
                    'data-nav-description':'m - men:body care:shower gel & body wash',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Body Lotion',
                    'navTargetLink':'https://qa3.ulta.com/men-body-care-body-lotion?N=gvefoe',
                    'data-nav-description':'m - men:body care:body lotion',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Deodorant',
                    'navTargetLink':'https://qa3.ulta.com/men-body-care-deodorant?N=1l7tvb9',
                    'data-nav-description':'m - men:body care:deodorant',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Hair',
                'navTargetLink':'https://qa3.ulta.com/men-hair?N=26zv',
                'data-nav-description':'m - men:hair',
                'navElementType':'subCategory',
                'categories':[
                  {
                    'navDisplayContent':'Shampoo',
                    'navTargetLink':'https://qa3.ulta.com/men-hair-shampoo?N=26zw',
                    'data-nav-description':'m - men:hair:shampoo',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Conditioner',
                    'navTargetLink':'https://qa3.ulta.com/men-hair-conditioner?N=26zx',
                    'data-nav-description':'m - men:hair:conditioner',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Hair Thinning & Hair Loss',
                    'navTargetLink':'https://qa3.ulta.com/men-hair-thinning-hair-loss?N=118uvdf',
                    'data-nav-description':'m - men:hair:hair thinning & hair loss',
                    'navElementType':'subCategory'
                  },
                  {
                    'navDisplayContent':'Styling',
                    'navTargetLink':'https://qa3.ulta.com/men-hair-styling?N=26zy',
                    'data-nav-description':'m - men:hair:styling',
                    'navElementType':'subCategory'
                  }
                ]
              },
              {
                'navDisplayContent':'Cologne',
                'navTargetLink':'https://qa3.ulta.com/men-cologne?N=1v9im2d',
                'data-nav-description':'m - men:cologne',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Travel Size',
                'navTargetLink':'https://qa3.ulta.com/men-travel-size?N=27cp',
                'data-nav-description':'m - men:travel size',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Gifts & Value Sets',
                'navTargetLink':'https://qa3.ulta.com/men-gifts-value-sets?N=27cq',
                'data-nav-description':'m - men:gifts & value sets',
                'navElementType':'subCategory'
              }
            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/men?N=26zq',
              'data-nav-description':'m - men',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'navDisplayContent':'Ulta Collection',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/brand/ulta',
              'data-nav-description':'m - ulta collection',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'lineColor':'PM',
            'navElementType':'Filler',
            'navDisplayContent':'Filler1',
            'insertBlank':false,
            'insertLine':true
          },
          {
            'navDisplayContent':'Gifts',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/gifts?N=26ww',
              'data-nav-description':'m - gifts',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'navDisplayContent':'Gift Cards',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/giftcards/giftCard.jsp?categoryId=cat120341',
              'data-nav-description':'m - gift cards',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'navDisplayContent':'Current Ad',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://storead.ulta.com/',
              'data-nav-description':'m - current ad',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'navDisplayContent':'BLACK FRIDAY',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ultablackfriday',
              'data-nav-description':'m - black friday',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          }
        ]
      },
      {
        'navElementType':'CategorySeparator',
        'navDisplayContent':'Filler1',
        'insertLine':true
      },
      {
        'navDisplayContent':'BEAUTY SERVICES',
        'navElementType':'SHOP',
        'categories':[
          {
            'navDisplayContent':'Book Appointment',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/stores',
              'data-nav-description':'m - book appointment',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'navDisplayContent':'Hair By The Salon',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/beautyservices/salon/',
              'data-nav-description':'m - hair by the salon',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'navDisplayContent':'Brows By Benefit',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/beautyservices/benefitbrowbar/index.html',
              'data-nav-description':'m - brows by benefit',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'navDisplayContent':'Skin By Dermalogica',
            'navElementType':'rootCategory',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/beautyservices/dermalogicaskinbar/index.html',
              'data-nav-description':'m - skin by dermalogica',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          }
        ]
      },
      {
        'navElementType':'CategorySeparator',
        'navDisplayContent':'Filler3',
        'insertLine':true
      },
      {
        'navElementType':'CategorySeparator',
        'navDisplayContent':'Filler',
        'insertLine':true
      },
      {
        'navDisplayContent':'What\'s Hot NOW',
        'navElementType':'SHOP',
        'categories':[
          {
            'displayFeatured':'true',
            'flyout':[

            ],
            'navDisplayContent':'Ulta Beauty Mix',
            'data-nav-description':'ulta beauty mix:featured',
            'displayBookAppt':'false',
            'navElementType':'rootCategory',
            'featuredLabel':'Featured',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa1.ulta.com/mix/',
              'data-nav-description':'m - ulta beauty mix',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          },
          {
            'displayFeatured':'true',
            'flyout':[

            ],
            'navDisplayContent':'Social Gallary',
            'data-nav-description':'social gallary:featured',
            'displayBookAppt':'false',
            'navElementType':'rootCategory',
            'featuredLabel':'Featured',
            'categories':[

            ],
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ultaShareGallery',
              'data-nav-description':'m - social gallary',
              'linkText':''
            },
            'fontColor':'nav-menu-style-black'
          }
        ]
      }
    ]
  },
  'serviceInfo':{
    'lastFetchedTime':'2018-03-19 10:10:40.751-05:00'
  },
  'desktopNavContent':{
    'navType':'LeftNav',
    'shippingPromoContent':{
      'navElementType':'ShippingSlot',
      'navDisplayContent':'Shipping Slot',
      'content':'<div class="free-sample-cont cont-side">\n<div class="container">\n<div class="span9 float-right-cont inner-cont"><a href="#" class="free-samp-link" style="color:#222D3A;font:15px Helvetica"><strong>FREE SHIPPING<\/strong> <span style="color:#222D3A;font:15px Helvetica">on any $50 purchase. Test Alps<\/span><\/a><\/div>\n<\/div>\n<\/div>',
      'mobileContent':'<div class="container">\n<div class="span9 float-right-cont inner-cont"><a href="#" class="free-samp-link" style="color: white;font:15px Helvetica">FREE SHIPPING <span style="color:white;font:15px Helvetica">on any $50 purchase. <\/span><\/a><\/div>\n<\/div>'
    },
    'navList': [
      {
        'primaryTitle': 'Featured Brands',
        'secondaryTitleColor': 'mad-for-magenta-ada',
        'flyout': [],
        'categoryImageAlt': '',
        'secondaryTitleLink': 'https://da1.ulta.com/global/nav/allbrands.jsp',
        'primaryTitleColor': 'nav-menu-style-black',
        'navDisplayContent': 'Shop By Brand-Heather!',
        'featuredDataNav': 'm - shop by brand-heather!:featured brands',
        'secondaryTitle': 'Shop All Brands',
        'navElementType': 'rootCategory',
        'categories': [
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_coverfx_logo?scl=1&fmt=png-alpha',
            'imageLink': 'https://da1.ulta.com/brand/cover-fx',
            'navDisplayContent': 'Cover FX',
            'navElementType': 'ImageSubCategory',
            'imageAlt': 'Cover FX',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:cover fx'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_dermalogica_logo?scl=1&fmt=png-alpha',
            'imageLink': 'https://da1.ulta.com/brand/dermalogica',
            'navDisplayContent': 'Dermalogica',
            'navElementType': 'ImageSubCategory',
            'imageAlt': 'Dermalogica',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:dermalogica'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_drybar_logo?scl=1&fmt=png-alpha',
            'imageLink': 'https://da1.ulta.com/brand/drybar',
            'navDisplayContent': 'Drybar',
            'navElementType': 'ImageSubCategory',
            'imageAlt': '',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:drybar'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_it_cos_logo?scl=1&fmt=png-alpha',
            'imageLink': 'https://da1.ulta.com/brand/it-cosmetics',
            'navDisplayContent': 'IT Cosmetics',
            'navElementType': 'ImageSubCategory',
            'imageAlt': 'IT Cosmetics',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:it cosmetics'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_mac_logo?scl=1&fmt=png-alpha',
            'imageLink': 'https://da1.ulta.com/brand/mac',
            'navDisplayContent': 'MAC',
            'navElementType': 'ImageSubCategory',
            'imageAlt': '',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:mac'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_morphe_logo?scl=1&fmt=png-alpha',
            'imageLink': 'https://da1.ulta.com/brand/morphe',
            'navDisplayContent': 'Morphe',
            'navElementType': 'ImageSubCategory',
            'imageAlt': 'Morphe',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:morphe'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_no7_logo?scl=1&fmt=png-alpha',
            'imageLink': 'https://da1.ulta.com/brand/no7',
            'navDisplayContent': 'No 7',
            'navElementType': 'ImageSubCategory',
            'imageAlt': '',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:no 7'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_nyx_logo?scl=1&fmt=png-alpha',
            'imageLink': '',
            'navDisplayContent': 'NYX',
            'navElementType': 'ImageSubCategory',
            'imageAlt': '',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:nyx'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_tarte_logo?scl=1&fmt=png-alpha',
            'imageLink': '',
            'navDisplayContent': 'Tarte',
            'navElementType': 'ImageSubCategory',
            'imageAlt': '',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:tarte'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_toofaced_logo?scl=1&fmt=png-alpha',
            'imageLink': '',
            'navDisplayContent': 'Too faced',
            'navElementType': 'ImageSubCategory',
            'imageAlt': '',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:too faced'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_ub_logo?scl=1&fmt=png-alpha',
            'imageLink': '',
            'navDisplayContent': 'Ulta',
            'navElementType': 'ImageSubCategory',
            'imageAlt': '',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:ulta'
          },
          {
            'image': 'https://images.ulta.com/is/image/Ulta/flyout_urban_decay_logo?scl=1&fmt=png-alpha',
            'imageLink': '',
            'navDisplayContent': 'Urban',
            'navElementType': 'ImageSubCategory',
            'imageAlt': '',
            'dataSlotPosition': 'm - shop by brand-heather!:featured brands:urban'
          }
        ],
        'shopAllDataNav': 'm - shop by brand-heather!:shop all brands',
        'categoryLink': {
          'showInNewPage': 'false',
          'navTargetLink': 'https://da1.ulta.com/global/nav/allbrands.jsp',
          'data-nav-description': 'm - shop by brand-heather!',
          'linkText': ''
        },
        'fontColor': true
      }
      ,
      {
        'displayFeatured':'true',
        'flyout':[

        ],
        'navDisplayContent':'MAKEUP - Test',
        'data-nav-description':'makeup - test:featured',
        'displayBookAppt':'false',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[
          {
            'navDisplayContent':'Face',
            'navTargetLink':'https://qa3.ulta.com/makeup-face?N=26y3',
            'data-nav-description':'m - makeup:face',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Foundation',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-foundation?N=26y5',
                'data-nav-description':'m - makeup:face:foundation',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Face Powder',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-powder?N=26y8',
                'data-nav-description':'m - makeup:face:face powder',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Concealer',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-concealer?N=26y6',
                'data-nav-description':'m - makeup:face:concealer',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Color Correcting',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-color-correcting?N=dapq1e',
                'data-nav-description':'m - makeup:face:color correcting',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Face Primer',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-primer?N=26y4',
                'data-nav-description':'m - makeup:face:face primer',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'BB & CC Creams',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-bb-cc-creams?N=277u',
                'data-nav-description':'m - makeup:face:bb & cc creams',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Blush',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-blush?N=277v',
                'data-nav-description':'m - makeup:face:blush',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Bronzer',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-bronzer?N=26y9',
                'data-nav-description':'m - makeup:face:bronzer',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Contouring',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-contouring?N=27eh',
                'data-nav-description':'m - makeup:face:contouring',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Highlighter',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-highlighter?N=1v8rp2q',
                'data-nav-description':'m - makeup:face:highlighter',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Setting Spray',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-setting-spray?N=qus6sj',
                'data-nav-description':'m - makeup:face:setting spray',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Shine Control',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-shine-control?N=26yc',
                'data-nav-description':'m - makeup:face:shine control',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Makeup Remover',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-makeup-remover?N=lycsxp',
                'data-nav-description':'m - skin>ca=re changed test:cleansers:makeup remover',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Eyes',
            'navTargetLink':'https://qa3.ulta.com/makeup-eyes?N=26yd',
            'data-nav-description':'m - makeup:eyes',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Eyeshadow Palettes',
                'navTargetLink':'https://qa3.ulta.com/makeup-eyes-eyeshadow-palettes?N=26ye',
                'data-nav-description':'m - makeup:eyes:eyeshadow palettes',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Mascara',
                'navTargetLink':'https://qa3.ulta.com/makeup-eyes-mascara?N=26yg',
                'data-nav-description':'m - makeup:eyes:mascara',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Eyeliner',
                'navTargetLink':'https://qa3.ulta.com/makeup-eyes-eyeliner?N=26yh',
                'data-nav-description':'m - makeup:eyes:eyeliner',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Eyebrows',
                'navTargetLink':'https://qa3.ulta.com/makeup-eyes-eyebrows?N=26yi',
                'data-nav-description':'m - makeup:eyes:eyebrows',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Eyeshadow',
                'navTargetLink':'https://qa3.ulta.com/makeup-eyes-eyeshadow?N=26yf',
                'data-nav-description':'m - makeup:eyes:eyeshadow',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Eye Primer & Base',
                'navTargetLink':'https://qa3.ulta.com/makeup-eye-primer-base?N=26yl',
                'data-nav-description':'m - makeup:eyes:eye primer & base',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Eyelashes',
                'navTargetLink':'https://qa3.ulta.com/makeup-eyes-eyelashes?N=26yj',
                'data-nav-description':'m - makeup:eyes:eyelashes',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Eye Makeup Remover',
                'navTargetLink':'https://qa3.ulta.com/makeup-eye-makeup-remover?N=26yk',
                'data-nav-description':'m - makeup:eyes:eye makeup remover',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Lips',
            'navTargetLink':'https://qa3.ulta.com/makeup-lips?N=26yq',
            'data-nav-description':'m - makeup:lips',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Lipstick',
                'navTargetLink':'https://qa3.ulta.com/makeup-lips-lipstick?N=26ys',
                'data-nav-description':'m - makeup:lips:lipstick',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Lip Gloss',
                'navTargetLink':'https://qa3.ulta.com/makeup-lip-gloss?N=26yt',
                'data-nav-description':'m - makeup:lips:lip gloss',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Lip Liner',
                'navTargetLink':'https://qa3.ulta.com/makeup-lip-liner?N=26yv',
                'data-nav-description':'m - makeup:lips:lip liner',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Lip Stain',
                'navTargetLink':'https://qa3.ulta.com/makeup-lip-stain?N=26yu',
                'data-nav-description':'m - makeup:lips:lip stain',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Treatments & Balms',
                'navTargetLink':'https://qa3.ulta.com/makeup-lips-treatments-balms?N=26yw',
                'data-nav-description':'m - makeup:lips:treatments & balms',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Sets & Palettes',
                'navTargetLink':'https://qa3.ulta.com/makeup-lips-sets-palettes?N=26yr',
                'data-nav-description':'m - makeup:lips:sets & palettes',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Makeup Brushes & Tools',
            'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools?N=hi56mr',
            'data-nav-description':'m - tools & brushes:makeup brushes & tools',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Brush Sets',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brush-sets?N=i4us25',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools:brush sets',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Makeup Brushes',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-makeup-brushes?N=s88qgw',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools:makeup brushes',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Sponges & Applicators',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-sponges-applicators?N=y7ddtv',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools:sponges & applicators',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Brush Cleaner',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brush-cleaner?N=k9zut0',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools:brush cleaner',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Brow & Lash Tools',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brow-lash-tools?N=o74qbj',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools:brow & lash tools',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Mirrors',
                'navTargetLink':'https://qa3.ulta.com/makeup-brushes-tools-mirrors?N=277r',
                'data-nav-description':'m - makeup:makeup brushes & tools:mirrors',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Sharpeners',
                'navTargetLink':'https://qa3.ulta.com/makeup-brushes-tools-sharpeners?N=27cj',
                'data-nav-description':'m - makeup:makeup brushes & tools:sharpeners',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Makeup Bags & Cases',
            'navTargetLink':'https://qa3.ulta.com/makeup-bags-cases?N=26zp',
            'data-nav-description':'m - makeup:makeup bags & cases',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'ULTA Collection',
            'navTargetLink':'https://qa3.ulta.com/makeup-ulta-collection?N=26zi',
            'data-nav-description':'m - makeup:ulta collection',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Travel Size',
            'navTargetLink':'https://qa3.ulta.com/makeup-travel-size?N=2782',
            'data-nav-description':'m - makeup:travel size',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Gifts & Value Sets',
            'navTargetLink':'https://qa3.ulta.com/makeup-gifts-value-sets?N=26zo',
            'data-nav-description':'m - makeup:gifts & value sets',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Makeup Palettes',
                'navTargetLink':'https://qa3.ulta.com/makeup-gifts-value-sets-makeup-palettes?N=1jeq7ud',
                'data-nav-description':'m - makeup:gifts & value sets:makeup palettes',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Value Sets',
                'navTargetLink':'https://qa3.ulta.com/makeup-gifts-value-sets-value-sets?N=ubsuml',
                'data-nav-description':'m - makeup:gifts & value sets:value sets',
                'navElementType':'subCategory'
              }
            ]
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/makeup?N=26y1',
          'data-nav-description':'m - makeup - test',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'displayFeatured':'true',
        'flyout':[
          {
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'',
              'linkText':'',
              'data-slot-position':'nails_null'
            },
            'navElementType':'subcategory',
            'navAttributes':'promoflyout',
            'imageAlt':''
          }
        ],
        'navDisplayContent':'NAILS',
        'data-nav-description':'nails:featured',
        'displayBookAppt':'false',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[
          {
            'navDisplayContent':'Nail Polish',
            'navTargetLink':'https://qa3.ulta.com/nail-polish?N=278s',
            'data-nav-description':'m - nails:nail polish',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Gel Manicure',
            'navTargetLink':'https://qa3.ulta.com/nails-gel-manicure?N=278j',
            'data-nav-description':'m - nails:gel manicure',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Top & Base Coats',
            'navTargetLink':'https://qa3.ulta.com/nails-top-base-coats?N=1pf4yzp',
            'data-nav-description':'m - nails:top & base coats',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Nail Art & Design',
            'navTargetLink':'https://qa3.ulta.com/nail-art-design?N=27br',
            'data-nav-description':'m - nails:nail art & design',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Nail Care',
            'navTargetLink':'https://qa3.ulta.com/nail-care?N=27bs',
            'data-nav-description':'m - nails:nail care',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Removers',
                'navTargetLink':'https://qa3.ulta.com/nail-care-removers?N=27bt',
                'data-nav-description':'m - nails:nail care:removers',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Cuticle Care',
                'navTargetLink':'https://qa3.ulta.com/nail-care-cuticle-care?N=27bv',
                'data-nav-description':'m - nails:nail care:cuticle care',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Nail Treatments',
                'navTargetLink':'https://qa3.ulta.com/nail-care-nail-treatments?N=27bw',
                'data-nav-description':'m - nails:nail care:nail treatments',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Manicure & Pedicure Tools',
            'navTargetLink':'https://qa3.ulta.com/bath-body-hand-foot-care-manicure-pedicure-tools?N=oy1nnu',
            'data-nav-description':'m - bath & body:hand & foot care:manicure & pedicure tools',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Gifts & Value Sets',
            'navTargetLink':'https://qa3.ulta.com/nails-gifts-value-sets?N=27c1',
            'data-nav-description':'m - nails:gifts & value sets',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'ULTA Collection',
            'navTargetLink':'https://qa3.ulta.com/nails-ulta-collection?N=27c5',
            'data-nav-description':'m - nails:ulta collection',
            'navElementType':'subCategory'
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/nails?N=271o',
          'data-nav-description':'m - nails',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'displayFeatured':'true',
        'flyout':[
          {
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod3850103',
              'linkText':'',
              'data-slot-position':'skin care_flyout_050916_hair'
            },
            'navElementType':'subcategory',
            'navAttributes':'promoflyout',
            'imageAlt':'',
            'imgSrc':'https://images.ulta.com/is/image/Ulta/flyout_050916_hair'
          }
        ],
        'navDisplayContent':'SKIN CARE',
        'data-nav-description':'skin care:featured',
        'displayBookAppt':'false',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[
          {
            'navDisplayContent':'Cleansers',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers?N=2794',
            'data-nav-description':'m - skin>ca=re changed test:cleansers',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Face Wash',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-face-wash?N=ejr3qt',
                'data-nav-description':'m - skin>ca=re changed test:cleansers:face wash',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Cleansing Oils',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-cleansing-oils?N=19bm2ov',
                'data-nav-description':'m - skin>ca=re changed test:cleansers:cleansing oils',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Cleansing Wipes',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-cleansing-wipes?N=wd4464',
                'data-nav-description':'m - skin>ca=re changed test:cleansers:cleansing wipes',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Exfoliators & Scrubs',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-exfoliators-scrubs?N=1rpwjr7',
                'data-nav-description':'m - skin>ca=re changed test:cleansers:exfoliators & scrubs',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Toner',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-toner?N=4ui8iu',
                'data-nav-description':'m - skin>ca=re changed test:cleansers:toner',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Makeup Remover',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-makeup-remover?N=lycsxp',
                'data-nav-description':'m - skin>ca=re changed test:cleansers:makeup remover',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Cleansing Brushes',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-cleansing-brushes?N=e4ntnr',
                'data-nav-description':'m - skin>ca=re changed test:cleansers:cleansing brushes',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Moisturizers',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers?N=2796',
            'data-nav-description':'m - skin>ca=re changed test:moisturizers',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Face Moisturizer',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-face-moisturizer?N=1an7g60',
                'data-nav-description':'m - skin>ca=re changed test:moisturizers:face moisturizer',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Night Cream',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers-night-cream?N=7a2js3',
                'data-nav-description':'m - skin>ca=re changed test:moisturizers:night cream',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Face Oil',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers-face-oil?N=1bvd8gl',
                'data-nav-description':'m - skin>ca=re changed test:moisturizers:face oil',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Face Mist',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers-face-mist?N=q2cjc8',
                'data-nav-description':'m - skin>ca=re changed test:moisturizers:face mist',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Decollete & Neck Cream',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers-decollete-neck-cream?N=nfabzb',
                'data-nav-description':'m - skin>ca=re changed test:moisturizers:decollete & neck cream',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'BB & CC Creams',
                'navTargetLink':'https://qa3.ulta.com/makeup-face-bb-cc-creams?N=277u',
                'data-nav-description':'m - makeup:face:bb & cc creams',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Lip Care',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-moisturizers-lip-care?N=l341or',
                'data-nav-description':'m - skin>ca=re changed test:moisturizers:lip care',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Treatment & Serums',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums?N=27cs',
            'data-nav-description':'m - skin>ca=re changed test:treatment & serums',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Face Serums',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums-face-serums?N=xiyuqr',
                'data-nav-description':'m - skin>ca=re changed test:treatment & serums:face serums',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Facial Peels',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums-facial-peels?N=k3cm80',
                'data-nav-description':'m - skin>ca=re changed test:treatment & serums:facial peels',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Face Masks',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums-face-masks?N=17grb4h',
                'data-nav-description':'m - skin>ca=re changed test:treatment & serums:face masks',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Sheet Masks',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums-sheet-masks?N=1rr85ua',
                'data-nav-description':'m - skin>ca=re changed test:treatment & serums:sheet masks',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Acne & Blemish Treatments',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-treatment-serums-acne-blemish-treatments?N=7h6z66',
                'data-nav-description':'m - skin>ca=re changed test:treatment & serums:acne & blemish treatments',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Eye Treatments--Test',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-eye-treatments-test?N=270k',
            'data-nav-description':'m - skin>ca=re changed test:eye treatments--test',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Eye Cream',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-eye-treatments-test-eye-cream?N=xd1men',
                'data-nav-description':'m - skin>ca=re changed test:eye treatments--test:eye cream',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Eye Serums',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-eye-treatments-test-eye-serums?N=cb4sj0',
                'data-nav-description':'m - skin>ca=re changed test:eye treatments--test:eye serums',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Eye Masks',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-eye-treatments-test-eye-masks?N=b8bsuf',
                'data-nav-description':'m - skin>ca=re changed test:eye treatments--test:eye masks',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Suncare',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-suncare?N=27fe',
            'data-nav-description':'m - skin>ca=re changed test:suncare',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Sunscreen',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-suncare-sunscreen?N=27ff',
                'data-nav-description':'m - skin>ca=re changed test:suncare:sunscreen',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Self-Tanning & Bronzing',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-suncare-self-tanning-bronzing?N=27fg',
                'data-nav-description':'m - skin>ca=re changed test:suncare:self-tanning & bronzing',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'After Sun Care',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-suncare-after-sun-care?N=5ulj51',
                'data-nav-description':'m - skin>ca=re changed test:suncare:after sun care',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Supplements',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-supplements?N=2712',
            'data-nav-description':'m - skin>ca=re changed test:supplements',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Mother & Baby',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-mother-baby?N=2715',
            'data-nav-description':'m - skin>ca=re changed test:mother & baby',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Tools',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-tools?N=2718',
            'data-nav-description':'m - skin>ca=re changed test:tools',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Cleansing Brushes',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-cleansing-brushes?N=e4ntnr',
                'data-nav-description':'m - skin>ca=re changed test:cleansers:cleansing brushes',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Spa Tools',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-spa-tools?N=rlvnt5',
                'data-nav-description':'m - skin>ca=re changed test:tools:spa tools',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Acne Removal',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-skincare-tools-acne-removal?N=6rsvyw',
                'data-nav-description':'m - tools & brushes:skincare tools:acne removal',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'ULTA Collection',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-ulta-collection?N=2713',
            'data-nav-description':'m - skin>ca=re changed test:ulta collection',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Travel Size',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-travel-size?N=279d',
            'data-nav-description':'m - skin>ca=re changed test:travel size',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Gifts & Value Sets',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-gifts-value-sets?N=2717',
            'data-nav-description':'m - skin>ca=re changed test:gifts & value sets',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Korean Skin Care',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-korean-skin-care?N=1jrcu47',
            'data-nav-description':'m - skin>ca=re changed test:korean skin care',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Natural Skin Care',
            'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-natural-skin-care?N=1hzlhrt',
            'data-nav-description':'m - skin>ca=re changed test:natural skin care',
            'navElementType':'subCategory'
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/skincare-changed-test?N=2707',
          'data-nav-description':'m - skin care',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'displayFeatured':'true',
        'flyout':[
          {
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'',
              'linkText':'',
              'data-slot-position':'hair_null'
            },
            'navElementType':'subcategory',
            'navAttributes':'promoflyout',
            'imageAlt':''
          }
        ],
        'navDisplayContent':'HAIR',
        'data-nav-description':'hair:featured',
        'displayBookAppt':'false',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[
          {
            'navDisplayContent':'Shampoo & Conditioner',
            'navTargetLink':'https://qa3.ulta.com/hair-shampoo-conditioner?N=mwxuai',
            'data-nav-description':'m - hair:shampoo & conditioner',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Shampoo',
                'navTargetLink':'https://qa3.ulta.com/hair-shampoo-conditioner-shampoo?N=ecypd2',
                'data-nav-description':'m - hair:shampoo & conditioner:shampoo',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Dry Shampoo',
                'navTargetLink':'https://qa3.ulta.com/hair-shampoo-conditioner-dry-shampoo?N=15jnupp',
                'data-nav-description':'m - hair:shampoo & conditioner:dry shampoo',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Conditioner',
                'navTargetLink':'https://qa3.ulta.com/hair-shampoo-conditioner-conditioner?N=1jd6tgg',
                'data-nav-description':'m - hair:shampoo & conditioner:conditioner',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Cleansing Conditioner',
                'navTargetLink':'https://qa3.ulta.com/hair-shampoo-conditioner-cleansing-conditioner?N=wozuev',
                'data-nav-description':'m - hair:shampoo & conditioner:cleansing conditioner',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Treatment',
            'navTargetLink':'https://qa3.ulta.com/hair-treatment?N=26xy',
            'data-nav-description':'m - hair:treatment',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Oils & Serums',
                'navTargetLink':'https://qa3.ulta.com/hair-treatment-oils-serums?N=18462b',
                'data-nav-description':'m - hair:treatment:oils & serums',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Masks',
                'navTargetLink':'https://qa3.ulta.com/hair-treatment-masks?N=dqpmkn',
                'data-nav-description':'m - hair:treatment:masks',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hair Thinning & Hair Loss',
                'navTargetLink':'https://qa3.ulta.com/hair-treatment-hair-thinning-hair-loss?N=1k7fo3k',
                'data-nav-description':'m - hair:treatment:hair thinning & hair loss',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Leave-In Treatment',
                'navTargetLink':'https://qa3.ulta.com/hair-leave-in-treatment?N=14wdtcy',
                'data-nav-description':'m - hair:treatment:leave-in treatment',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Styling=Prod>ucts% new',
            'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new?N=26xf',
            'data-nav-description':'m - hair:styling=prod>ucts% new',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Hairspray',
                'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-hairspray?N=dyokub',
                'data-nav-description':'m - hair:styling=prod>ucts% new:hairspray',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Volume & Texture',
                'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-volume-texture?N=1xvbie',
                'data-nav-description':'m - hair:styling=prod>ucts% new:volume & texture',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Heat Protectant',
                'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-heat-protectant?N=1tulu1d',
                'data-nav-description':'m - hair:styling=prod>ucts% new:heat protectant',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Gloss & Shine',
                'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-gloss-shine?N=48qfaq',
                'data-nav-description':'m - hair:styling=prod>ucts% new:gloss & shine',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Smoothing',
                'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-smoothing?N=1ach964',
                'data-nav-description':'m - hair:styling=prod>ucts% new:smoothing',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Curl Enhancing',
                'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-curl-enhancing?N=a65zzt',
                'data-nav-description':'m - hair:styling=prod>ucts% new:curl enhancing',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Wax & Pomade',
                'navTargetLink':'https://qa3.ulta.com/hair-stylingproducts-new-wax-pomade?N=mug6z5',
                'data-nav-description':'m - hair:styling=prod>ucts% new:wax & pomade',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Hair Color',
            'navTargetLink':'https://qa3.ulta.com/hair-color?N=26xs',
            'data-nav-description':'m - hair:hair color',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Hair Styling Tools',
            'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools?N=w5a8a9',
            'data-nav-description':'m - tools & brushes:hair styling tools',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Flat Irons',
                'navTargetLink':'https://qa3.ulta.com/hair-styling-tools-flat-irons?N=26xq',
                'data-nav-description':'m - hair:hair styling tools:flat irons',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hair Dryers',
                'navTargetLink':'https://qa3.ulta.com/hair-styling-tools-hair-dryers?N=26xo',
                'data-nav-description':'m - hair:hair styling tools:hair dryers',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Curling Irons & Stylers',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools-curling-irons-stylers?N=l3gmtv',
                'data-nav-description':'m - tools & brushes:hair styling tools:curling irons & stylers',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hot Rollers',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools-hot-rollers?N=d3uwph',
                'data-nav-description':'m - tools & brushes:hair styling tools:hot rollers',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Hair Brushes & Combs',
            'navTargetLink':'https://qa3.ulta.com/hair-brushes-combs?N=2778',
            'data-nav-description':'m - hair:hair brushes & combs',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Accessories',
            'navTargetLink':'https://qa3.ulta.com/hair-accessories?N=26y0',
            'data-nav-description':'m - hair:accessories',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Hair Extensions',
                'navTargetLink':'https://qa3.ulta.com/hair-accessories-hair-extensions?N=2774',
                'data-nav-description':'m - hair:accessories:hair extensions',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Elastics',
                'navTargetLink':'https://qa3.ulta.com/hair-accessories-elastics?N=2773',
                'data-nav-description':'m - hair:accessories:elastics',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Headbands',
                'navTargetLink':'https://qa3.ulta.com/hair-accessories-headbands?N=2776',
                'data-nav-description':'m - hair:accessories:headbands',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Clips & Bobby Pins',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-accessories-clips-bobby-pins?N=lx44ft',
                'data-nav-description':'m - tools & brushes:accessories:clips & bobby pins',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Styling Accessories',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-styling-accessories?N=fnixer',
                'data-nav-description':'m - tools & brushes:accessories:styling accessories',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Trend Accessories',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-trend-accessories?N=r8p81m',
                'data-nav-description':'m - tools & brushes:accessories:trend accessories',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Kid\'s Haircare',
            'navTargetLink':'https://qa3.ulta.com/hair-kids-haircare?N=26xz',
            'data-nav-description':'m - hair:kid\'s haircare',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'ULTA Collection',
            'navTargetLink':'https://qa3.ulta.com/hair-ulta-collection?N=26xx',
            'data-nav-description':'m - hair:ulta collection',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Travel Size',
            'navTargetLink':'https://qa3.ulta.com/hair-travel-size?N=27ci',
            'data-nav-description':'m - hair:travel size',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Gifts & Value Sets',
            'navTargetLink':'https://qa3.ulta.com/hair-gifts-value-sets?N=277l',
            'data-nav-description':'m - hair:gifts & value sets',
            'navElementType':'subCategory'
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/hair?N=26wz',
          'data-nav-description':'m - hair',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'displayFeatured':'true',
        'flyout':[
          {
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod13991017',
              'linkText':'',
              'data-slot-position':'tools & brushes_flyout_050916_tools'
            },
            'navElementType':'subcategory',
            'navAttributes':'promoflyout',
            'imageAlt':'',
            'imgSrc':'https://images.ulta.com/is/image/Ulta/flyout_050916_tools'
          }
        ],
        'navDisplayContent':'TOOLS & BRUSHES',
        'data-nav-description':'tools & brushes:featured',
        'displayBookAppt':'false',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[
          {
            'navDisplayContent':'Hair Styling Tools',
            'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools?N=w5a8a9',
            'data-nav-description':'m - tools & brushes:hair styling tools',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Flat Irons',
                'navTargetLink':'https://qa3.ulta.com/hair-styling-tools-flat-irons?N=26xq',
                'data-nav-description':'m - hair:hair styling tools:flat irons',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hair Dryers',
                'navTargetLink':'https://qa3.ulta.com/hair-styling-tools-hair-dryers?N=26xo',
                'data-nav-description':'m - hair:hair styling tools:hair dryers',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Curling Irons & Stylers',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools-curling-irons-stylers?N=l3gmtv',
                'data-nav-description':'m - tools & brushes:hair styling tools:curling irons & stylers',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hot Rollers',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-styling-tools-hot-rollers?N=d3uwph',
                'data-nav-description':'m - tools & brushes:hair styling tools:hot rollers',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Skincare Tools',
            'navTargetLink':'https://qa3.ulta.com/tools-brushes-skincare-tools?N=19rs4ow',
            'data-nav-description':'m - tools & brushes:skincare tools',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Cleansing Brushes',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-cleansers-cleansing-brushes?N=e4ntnr',
                'data-nav-description':'m - skin>ca=re changed test:cleansers:cleansing brushes',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Spa Tools',
                'navTargetLink':'https://qa3.ulta.com/skincare-changed-test-spa-tools?N=rlvnt5',
                'data-nav-description':'m - skin>ca=re changed test:tools:spa tools',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Acne Removal',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-skincare-tools-acne-removal?N=6rsvyw',
                'data-nav-description':'m - tools & brushes:skincare tools:acne removal',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Hair Removal Tools',
            'navTargetLink':'https://qa3.ulta.com/tools-brushes-hair-removal-tools?N=1sx5op9',
            'data-nav-description':'m - tools & brushes:hair removal tools',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Makeup Brushes & Tools',
            'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools?N=hi56mr',
            'data-nav-description':'m - tools & brushes:makeup brushes & tools',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Brush Sets',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brush-sets?N=i4us25',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools:brush sets',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Makeup Brushes',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-makeup-brushes?N=s88qgw',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools:makeup brushes',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Sponges & Applicators',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-sponges-applicators?N=y7ddtv',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools:sponges & applicators',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Brush Cleaner',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brush-cleaner?N=k9zut0',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools:brush cleaner',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Brow & Lash Tools',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-makeup-brushes-tools-brow-lash-tools?N=o74qbj',
                'data-nav-description':'m - tools & brushes:makeup brushes & tools:brow & lash tools',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Mirrors',
                'navTargetLink':'https://qa3.ulta.com/makeup-brushes-tools-mirrors?N=277r',
                'data-nav-description':'m - makeup:makeup brushes & tools:mirrors',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Sharpeners',
                'navTargetLink':'https://qa3.ulta.com/makeup-brushes-tools-sharpeners?N=27cj',
                'data-nav-description':'m - makeup:makeup brushes & tools:sharpeners',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Hair Brushes & Combs',
            'navTargetLink':'https://qa3.ulta.com/hair-brushes-combs?N=2778',
            'data-nav-description':'m - hair:hair brushes & combs',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Accessories',
            'navTargetLink':'https://qa3.ulta.com/hair-accessories?N=26y0',
            'data-nav-description':'m - hair:accessories',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Hair Extensions',
                'navTargetLink':'https://qa3.ulta.com/hair-accessories-hair-extensions?N=2774',
                'data-nav-description':'m - hair:accessories:hair extensions',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Elastics',
                'navTargetLink':'https://qa3.ulta.com/hair-accessories-elastics?N=2773',
                'data-nav-description':'m - hair:accessories:elastics',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Headbands',
                'navTargetLink':'https://qa3.ulta.com/hair-accessories-headbands?N=2776',
                'data-nav-description':'m - hair:accessories:headbands',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Clips & Bobby Pins',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-accessories-clips-bobby-pins?N=lx44ft',
                'data-nav-description':'m - tools & brushes:accessories:clips & bobby pins',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Styling Accessories',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-styling-accessories?N=fnixer',
                'data-nav-description':'m - tools & brushes:accessories:styling accessories',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Trend Accessories',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-trend-accessories?N=r8p81m',
                'data-nav-description':'m - tools & brushes:accessories:trend accessories',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Gifts & Value Sets',
            'navTargetLink':'https://qa3.ulta.com/tools-brushes-gifts-value-sets?N=j55azv',
            'data-nav-description':'m - tools & brushes:gifts & value sets',
            'navElementType':'subCategory'
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/tools-brushes?N=1qp05hl',
          'data-nav-description':'m - tools & brushes',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'displayFeatured':'true',
        'flyout':[
          {
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod13951035',
              'linkText':'',
              'data-slot-position':'fragrance_flyout_050916_fragrance'
            },
            'navElementType':'subcategory',
            'navAttributes':'promoflyout',
            'imageAlt':'',
            'imgSrc':'https://images.ulta.com/is/image/Ulta/flyout_050916_fragrance'
          }
        ],
        'navDisplayContent':'FRAGRANCE',
        'data-nav-description':'fragrance:featured',
        'displayBookAppt':'false',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[
          {
            'navDisplayContent':'Women\'s Fragrance',
            'navTargetLink':'https://qa3.ulta.com/womens-fragrance?N=26wn',
            'data-nav-description':'m - fragrance:women\'s fragrance',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Perfume',
                'navTargetLink':'https://qa3.ulta.com/womens-fragrance-perfume?N=26wq',
                'data-nav-description':'m - fragrance:women\'s fragrance:perfume',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Rollerballs & Purse Sprays',
                'navTargetLink':'https://qa3.ulta.com/womens-fragrance-rollerballs-purse-sprays?N=26wo',
                'data-nav-description':'m - fragrance:women\'s fragrance:rollerballs & purse sprays',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Body Lotions',
                'navTargetLink':'https://qa3.ulta.com/womens-fragrance-body-lotions?N=26ws',
                'data-nav-description':'m - fragrance:women\'s fragrance:body lotions',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Body Mist & Hair Mist',
                'navTargetLink':'https://qa3.ulta.com/womens-fragrance-body-mist-hair-mist?N=26wr',
                'data-nav-description':'m - fragrance:women\'s fragrance:body mist & hair mist',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Bath & Shower',
                'navTargetLink':'https://qa3.ulta.com/womens-fragrance-bath-shower?N=10err6y',
                'data-nav-description':'m - fragrance:women\'s fragrance:bath & shower',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Men\'s Fragrance',
            'navTargetLink':'https://qa3.ulta.com/mens-fragrance?N=26wf',
            'data-nav-description':'m - fragrance:men\'s fragrance',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Cologne',
                'navTargetLink':'https://qa3.ulta.com/mens-fragrance-cologne?N=26wg',
                'data-nav-description':'m - fragrance:men\'s fragrance:cologne',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Aftershave',
                'navTargetLink':'https://qa3.ulta.com/mens-fragrance-aftershave?N=26wi',
                'data-nav-description':'m - fragrance:men\'s fragrance:aftershave',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Bath & Shower',
                'navTargetLink':'https://qa3.ulta.com/mens-fragrance-bath-shower?N=xh2wl7',
                'data-nav-description':'m - fragrance:men\'s fragrance:bath & shower',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Fragrance Gift Sets',
            'navTargetLink':'https://qa3.ulta.com/fragrance-gift-sets?N=27dg',
            'data-nav-description':'m - gifts:fragrance gift sets',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Perfume Gift Sets',
                'navTargetLink':'https://qa3.ulta.com/fragrance-gift-sets-perfume-gift-sets?N=1gschg4',
                'data-nav-description':'m - gifts:fragrance gift sets:perfume gift sets',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Cologne Gift Sets',
                'navTargetLink':'https://qa3.ulta.com/fragrance-gift-sets-cologne-gift-sets?N=81cgoh',
                'data-nav-description':'m - fragrance:fragrance gift sets:cologne gift sets',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Candles',
            'data-nav-description':'m - :candles',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Fragrance Finder',
            'navTargetLink':'https://qa3.ulta.com/fragrance-finder?N=27fl',
            'data-nav-description':'m - fragrance:fragrance finder',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Fragrance Crush',
            'navTargetLink':'https://qa3.ulta.com/fragrance-crush?N=wi8zoa',
            'data-nav-description':'m - fragrance:fragrance crush',
            'navElementType':'subCategory'
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/fragrance?N=26wa',
          'data-nav-description':'m - fragrance',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'displayFeatured':'true',
        'flyout':[
          {
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/promotion/buy-more-save-more/detail/0000144792',
              'linkText':'',
              'data-slot-position':'bath & body_flyout_050916_bath'
            },
            'navElementType':'subcategory',
            'navAttributes':'promoflyout',
            'imageAlt':'',
            'imgSrc':'https://images.ulta.com/is/image/Ulta/flyout_050916_bath'
          }
        ],
        'navDisplayContent':'BATH & BODY',
        'data-nav-description':'bath & body:featured',
        'displayBookAppt':'false',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[
          {
            'navDisplayContent':'Bath & Shower',
            'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower?N=26uy',
            'data-nav-description':'m - bath & body:bath & shower',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Shower Gel & Body Wash',
                'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower-shower-gel-body-wash?N=26uz',
                'data-nav-description':'m - bath & body:bath & shower:shower gel & body wash',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Body Scrubs & Exfoliants',
                'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower-body-scrubs-exfoliants?N=2765',
                'data-nav-description':'m - bath & body:bath & shower:body scrubs & exfoliants',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Bubble Bath & Oil',
                'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower-bubble-bath-oil?N=1h01mtr',
                'data-nav-description':'m - bath & body:bath & shower:bubble bath & oil',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Bath Salts & Soaks',
                'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower-bath-salts-soaks?N=kk6gxq',
                'data-nav-description':'m - bath & body:bath & shower:bath salts & soaks',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hand Soap & Wash',
                'navTargetLink':'https://qa3.ulta.com/bath-body-bath-shower-hand-soap-wash?N=26v1',
                'data-nav-description':'m - bath & body:bath & shower:hand soap & wash',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Body Moisturizers',
            'navTargetLink':'https://qa3.ulta.com/bath-body-body-moisturizers?N=26v3',
            'data-nav-description':'m - bath & body:body moisturizers',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Body Lotion & Creams',
                'navTargetLink':'https://qa3.ulta.com/bath-body-body-moisturizers-body-lotion-creams?N=26v4',
                'data-nav-description':'m - bath & body:body moisturizers:body lotion & creams',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Body Oils',
                'navTargetLink':'https://qa3.ulta.com/bath-body-body-moisturizers-body-oils?N=26v6',
                'data-nav-description':'m - bath & body:body moisturizers:body oils',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Hand & Foot Care',
            'navTargetLink':'https://qa3.ulta.com/bath-body-hand-foot-care?N=gt9muu',
            'data-nav-description':'m - bath & body:hand & foot care',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Hand Cream & Foot Cream',
                'navTargetLink':'https://qa3.ulta.com/bath-body-hand-foot-care-hand-cream-foot-cream?N=1nlwj8i',
                'data-nav-description':'m - bath & body:hand & foot care:hand cream & foot cream',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hand & Foot Treatment',
                'navTargetLink':'https://qa3.ulta.com/bath-body-hand-foot-care-hand-foot-treatment?N=ghlrda',
                'data-nav-description':'m - bath & body:hand & foot care:hand & foot treatment',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Manicure & Pedicure Tools',
                'navTargetLink':'https://qa3.ulta.com/bath-body-hand-foot-care-manicure-pedicure-tools?N=oy1nnu',
                'data-nav-description':'m - bath & body:hand & foot care:manicure & pedicure tools',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Personal Care',
            'navTargetLink':'https://qa3.ulta.com/bath-body-personal-care?N=m6j326',
            'data-nav-description':'m - bath & body:personal care',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Cellulite & Stretch Marks',
                'navTargetLink':'https://qa3.ulta.com/bath-body-personal-care-cellulite-stretch-marks?N=18ms76q',
                'data-nav-description':'m - bath & body:personal care:cellulite & stretch marks',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hair Removal',
                'navTargetLink':'https://qa3.ulta.com/bath-body-personal-care-hair-removal?N=1fjm35s',
                'data-nav-description':'m - bath & body:personal care:hair removal',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Deodorant',
                'navTargetLink':'https://qa3.ulta.com/bath-body-personal-care-deodorant?N=ca9qdp',
                'data-nav-description':'m - bath & body:personal care:deodorant',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Teeth <White,ning&update',
                'navTargetLink':'https://qa3.ulta.com/bath-body-personal-care-teeth-whitening-update?N=16nzokk',
                'data-nav-description':'m - bath & body:personal care:teeth <white,ning&update',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Bath & Body Accessories',
            'navTargetLink':'https://qa3.ulta.com/bath-body-accessories?N=i95dis',
            'data-nav-description':'m - bath & body:bath & body accessories',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Bath Sponges & Towels',
                'navTargetLink':'https://qa3.ulta.com/bath-body-accessories-bath-sponges-towels?N=eqo4ul',
                'data-nav-description':'m - bath & body:bath & body accessories:bath sponges & towels',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Spa Essentials',
                'navTargetLink':'https://qa3.ulta.com/bath-body-accessories-spa-essentials?N=1134tzx',
                'data-nav-description':'m - bath & body:bath & body accessories:spa essentials',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Trend Accessories',
                'navTargetLink':'https://qa3.ulta.com/tools-brushes-trend-accessories?N=r8p81m',
                'data-nav-description':'m - tools & brushes:accessories:trend accessories',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Suncare',
            'navTargetLink':'https://qa3.ulta.com/bath-body-suncare?N=276b',
            'data-nav-description':'m - bath & body:suncare',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Sunscreen',
                'navTargetLink':'https://qa3.ulta.com/bath-body-suncare-sunscreen?N=27fc',
                'data-nav-description':'m - bath & body:suncare:sunscreen',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Self-Tanning & Bronzing',
                'navTargetLink':'https://qa3.ulta.com/bath-body-suncare-self-tanning-bronzing?N=276e',
                'data-nav-description':'m - bath & body:suncare:self-tanning & bronzing',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'After Sun Care',
                'navTargetLink':'https://qa3.ulta.com/bath-body-suncare-after-sun-care?N=27fd',
                'data-nav-description':'m - bath & body:suncare:after sun care',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'ULTA Collection',
            'navTargetLink':'https://qa3.ulta.com/bath-body-ulta-collection?N=26vk',
            'data-nav-description':'m - bath & body:ulta collection',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Travel Size',
            'navTargetLink':'https://qa3.ulta.com/bath-body-travel-size?N=276l',
            'data-nav-description':'m - bath & body:travel size',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Gifts & Value Sets',
            'navTargetLink':'https://qa3.ulta.com/bath-body-gifts-value-sets?N=26vq',
            'data-nav-description':'m - bath & body:gifts & value sets',
            'navElementType':'subCategory'
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/bath-body?N=26us',
          'data-nav-description':'m - bath & body',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'displayFeatured':'true',
        'flyout':[
          {
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/browse/productDetail.jsp?productId=VP12592',
              'linkText':'',
              'data-slot-position':'men_flyout_050916_men'
            },
            'navElementType':'subcategory',
            'navAttributes':'promoflyout',
            'imageAlt':'',
            'imgSrc':'https://images.ulta.com/is/image/Ulta/flyout_050916_men'
          }
        ],
        'navDisplayContent':'MEN',
        'data-nav-description':'men:featured',
        'displayBookAppt':'false',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[
          {
            'navDisplayContent':'Skin Care',
            'navTargetLink':'https://qa3.ulta.com/men-skin-care?N=27ck',
            'data-nav-description':'m - men:skin care',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Face Wash',
                'navTargetLink':'https://qa3.ulta.com/men-skin-care-face-wash?N=27cl',
                'data-nav-description':'m - men:skin care:face wash',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Moisturizers & Treatments',
                'navTargetLink':'https://qa3.ulta.com/men-skin-care-moisturizers-treatments?N=27cm',
                'data-nav-description':'m - men:skin care:moisturizers & treatments',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Shaving',
            'navTargetLink':'https://qa3.ulta.com/men-shaving?N=1czga4k',
            'data-nav-description':'m - men:shaving',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Shaving Cream & Razors',
                'navTargetLink':'https://qa3.ulta.com/men-shaving-cream-razors?N=11jah3e',
                'data-nav-description':'m - men:shaving:shaving cream & razors',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Aftershave',
                'navTargetLink':'https://qa3.ulta.com/men-shaving-aftershave?N=zn154p',
                'data-nav-description':'m - men:shaving:aftershave',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Beard Care',
                'navTargetLink':'https://qa3.ulta.com/men-shaving-beard-care?N=14j6xlf',
                'data-nav-description':'m - men:shaving:beard care',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Body Care',
            'navTargetLink':'https://qa3.ulta.com/men-body-care?N=fita0k',
            'data-nav-description':'m - men:body care',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Shower Gel & Body Wash',
                'navTargetLink':'https://qa3.ulta.com/men-body-care-shower-gel-body-wash?N=vdu4am',
                'data-nav-description':'m - men:body care:shower gel & body wash',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Body Lotion',
                'navTargetLink':'https://qa3.ulta.com/men-body-care-body-lotion?N=gvefoe',
                'data-nav-description':'m - men:body care:body lotion',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Deodorant',
                'navTargetLink':'https://qa3.ulta.com/men-body-care-deodorant?N=1l7tvb9',
                'data-nav-description':'m - men:body care:deodorant',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Hair',
            'navTargetLink':'https://qa3.ulta.com/men-hair?N=26zv',
            'data-nav-description':'m - men:hair',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Shampoo',
                'navTargetLink':'https://qa3.ulta.com/men-hair-shampoo?N=26zw',
                'data-nav-description':'m - men:hair:shampoo',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Conditioner',
                'navTargetLink':'https://qa3.ulta.com/men-hair-conditioner?N=26zx',
                'data-nav-description':'m - men:hair:conditioner',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hair Thinning & Hair Loss',
                'navTargetLink':'https://qa3.ulta.com/men-hair-thinning-hair-loss?N=118uvdf',
                'data-nav-description':'m - men:hair:hair thinning & hair loss',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Styling',
                'navTargetLink':'https://qa3.ulta.com/men-hair-styling?N=26zy',
                'data-nav-description':'m - men:hair:styling',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Cologne',
            'navTargetLink':'https://qa3.ulta.com/men-cologne?N=1v9im2d',
            'data-nav-description':'m - men:cologne',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Travel Size',
            'navTargetLink':'https://qa3.ulta.com/men-travel-size?N=27cp',
            'data-nav-description':'m - men:travel size',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Gifts & Value Sets',
            'navTargetLink':'https://qa3.ulta.com/men-gifts-value-sets?N=27cq',
            'data-nav-description':'m - men:gifts & value sets',
            'navElementType':'subCategory'
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/men?N=26zq',
          'data-nav-description':'m - men',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'displayFeatured':'true',
        'flyout':[
          {
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/promotion/buy-more-save-more/detail/0000144702',
              'linkText':'',
              'data-slot-position':'ulta collection_flyout_050916_ulta'
            },
            'navElementType':'subcategory',
            'navAttributes':'promoflyout',
            'imageAlt':'',
            'imgSrc':'https://images.ulta.com/is/image/Ulta/flyout_050916_ulta'
          }
        ],
        'navDisplayContent':'ULTA COLLECTION',
        'data-nav-description':'ulta collection:featured',
        'displayBookAppt':'false',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[
          {
            'navDisplayContent':'Makeup',
            'navTargetLink':'https://qa3.ulta.com/ulta-collection-makeup?N=26vs',
            'data-nav-description':'m - ulta collection:makeup',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Face',
                'navTargetLink':'https://qa3.ulta.com/ulta-collection-makeup-face?N=26vv',
                'data-nav-description':'m - ulta collection:makeup:face',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Eyes',
                'navTargetLink':'https://qa3.ulta.com/ulta-collection-makeup-eyes?N=26vt',
                'data-nav-description':'m - ulta collection:makeup:eyes',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Lips',
                'navTargetLink':'https://qa3.ulta.com/ulta-collection-makeup-lips?N=26vu',
                'data-nav-description':'m - ulta collection:makeup:lips',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Nails',
                'navTargetLink':'https://qa3.ulta.com/ulta-collection-makeup-nails?N=279p',
                'data-nav-description':'m - ulta collection:makeup:nails',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Skin',
            'navTargetLink':'https://qa3.ulta.com/ulta-collection-skin?N=26vx',
            'data-nav-description':'m - ulta collection:skin',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Suncare',
            'navTargetLink':'https://qa3.ulta.com/ulta-collection-suncare?N=27e9',
            'data-nav-description':'m - ulta collection:suncare',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Sunscreen',
                'navTargetLink':'https://qa3.ulta.com/ulta-collection-suncare-sunscreen?N=27eb',
                'data-nav-description':'m - ulta collection:suncare:sunscreen',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Self-Tanning & Bronzing',
                'navTargetLink':'https://qa3.ulta.com/ulta-collection-suncare-self-tanning-bronzing?N=27ea',
                'data-nav-description':'m - ulta collection:suncare:self-tanning & bronzing',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'After Sun Care',
                'navTargetLink':'https://qa3.ulta.com/ulta-collection-suncare-after-sun-care?N=1xrq7kc',
                'data-nav-description':'m - ulta collection:suncare:after sun care',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Hair',
            'navTargetLink':'https://qa3.ulta.com/ulta-collection-hair?N=26w6',
            'data-nav-description':'m - ulta collection:hair',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Bath & Body',
            'navTargetLink':'https://qa3.ulta.com/ulta-collection-bath-body?N=26vy',
            'data-nav-description':'m - ulta collection:bath & body',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Bath',
                'navTargetLink':'https://qa3.ulta.com/ulta-collection-bath-body-bath?N=27d0',
                'data-nav-description':'m - ulta collection:bath & body:bath',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Moisturizers',
                'navTargetLink':'https://qa3.ulta.com/ulta-collection-bath-body-moisturizers?N=27d1',
                'data-nav-description':'m - ulta collection:bath & body:moisturizers',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Hand Soap & Sanitizers',
                'navTargetLink':'https://qa3.ulta.com/ulta-collection-bath-body-hand-soap-sanitizers?N=27e4',
                'data-nav-description':'m - ulta collection:bath & body:hand soap & sanitizers',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Brushes & Tools',
            'navTargetLink':'https://qa3.ulta.com/ulta-collection-brushes-tools?N=26w7',
            'data-nav-description':'m - ulta collection:brushes & tools',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Travel Size',
            'navTargetLink':'https://qa3.ulta.com/ulta-collection-travel-size?N=1997zvk',
            'data-nav-description':'m - ulta collection:travel size',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Gifts & Value Sets',
            'navTargetLink':'https://qa3.ulta.com/ulta-collection-gifts-value-sets?N=26w8',
            'data-nav-description':'m - ulta collection:gifts & value sets',
            'navElementType':'subCategory'
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/ulta-collection?N=26vr',
          'data-nav-description':'m - ulta collection',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'displayFeatured':'true',
        'flyout':[
          {
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/browse/productDetail.jsp?productId=xlsImpprod14111354',
              'linkText':'',
              'data-slot-position':'gifts_flyout_050916_gifts'
            },
            'navElementType':'subcategory',
            'navAttributes':'promoflyout',
            'imageAlt':'',
            'imgSrc':'https://images.ulta.com/is/image/Ulta/flyout_050916_gifts'
          }
        ],
        'navDisplayContent':'GIFTS',
        'data-nav-description':'gifts:featured',
        'displayBookAppt':'false',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[
          {
            'navDisplayContent':'Makeup Gifts',
            'navTargetLink':'https://qa3.ulta.com/makeup-gifts?N=276x',
            'data-nav-description':'m - gifts:makeup gifts',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Nail Gifts',
            'navTargetLink':'https://qa3.ulta.com/nail-gifts?N=27df',
            'data-nav-description':'m - gifts:nail gifts',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Skin Gifts',
            'navTargetLink':'https://qa3.ulta.com/skin-gifts?N=27cd',
            'data-nav-description':'m - gifts:skin gifts',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Hair Gifts',
            'navTargetLink':'https://qa3.ulta.com/hair-gifts?N=276w',
            'data-nav-description':'m - gifts:hair gifts',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Fragrance Gift Sets',
            'navTargetLink':'https://qa3.ulta.com/fragrance-gift-sets?N=27dg',
            'data-nav-description':'m - gifts:fragrance gift sets',
            'navElementType':'subCategory',
            'categories':[
              {
                'navDisplayContent':'Perfume Gift Sets',
                'navTargetLink':'https://qa3.ulta.com/fragrance-gift-sets-perfume-gift-sets?N=1gschg4',
                'data-nav-description':'m - gifts:fragrance gift sets:perfume gift sets',
                'navElementType':'subCategory'
              },
              {
                'navDisplayContent':'Cologne Gift Sets',
                'navTargetLink':'https://qa3.ulta.com/fragrance-gift-sets-cologne-gift-sets?N=81cgoh',
                'data-nav-description':'m - fragrance:fragrance gift sets:cologne gift sets',
                'navElementType':'subCategory'
              }
            ]
          },
          {
            'navDisplayContent':'Bath & Body Gifts',
            'navTargetLink':'https://qa3.ulta.com/bath-body-gifts?N=27dh',
            'data-nav-description':'m - gifts:bath & body gifts',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'ULTA Gifts',
            'navTargetLink':'https://qa3.ulta.com/ulta-gifts?N=27di',
            'data-nav-description':'m - gifts:ulta gifts',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Gifts with Purchase',
            'navTargetLink':'https://qa3.ulta.com/gifts-with-purchase?N=26wy',
            'data-nav-description':'m - gifts:gifts with purchase',
            'navElementType':'subCategory'
          },
          {
            'navDisplayContent':'Gift Cards',
            'navTargetLink':'https://qa3.ulta.com/gift-cards?N=27fm',
            'data-nav-description':'m - gifts:gift cards',
            'navElementType':'subCategory'
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/gifts?N=26ww',
          'data-nav-description':'m - gifts',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'navDisplayContent':'WHAT\'S NEW',
        'navElementType':'rootCategory',
        'categories':[

        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/ulta/a/_/N-6?ciSelector=searchResults&pgName=whatsnew',
          'data-nav-description':'m - what\'s new',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'navDisplayContent':'SALE',
        'navElementType':'rootCategory',
        'categories':[
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/a/_/N-1z13uvl?ciSelector=searchResults&pgName=specialOffers',
              'data-nav-description':'m - sale:subcategory',
              'linkText':''
            },
            'navDisplayContent':'SubCategory'
          },
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/global/ulta-coupon.jsp',
              'data-nav-description':'m - sale:coupon',
              'linkText':''
            },
            'navDisplayContent':'COUPON'
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/promotion/buy-more-save-more/',
          'data-nav-description':'m - sale',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'lineColor':'BK',
        'navElementType':'Filler',
        'navDisplayContent':'Filler1',
        'insertBlank':false,
        'insertLine':true
      },
      {
        'navDisplayContent':'GET INSPIRED',
        'navElementType':'rootCategory',
        'categories':[
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://www.ulta.com/whatshot/',
              'data-nav-description':'m - get inspired:beauty trend',
              'linkText':''
            },
            'navDisplayContent':'BEAUTY TREND'
          },
          {
            'image':'https://images.ulta.com/is/image/Ulta/bd_flyout_GI_whatshot_022316',
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://www.ulta.com/whatshot/',
              'linkText':'',
              'data-slot-position':'get inspired_bd_flyout_GI_whatshot_022316'
            },
            'navDisplayContent':'GET INSPIRED FLYOUT',
            'navElementType':'ImageSubCategory',
            'imageAlt':'',
            'imageSubCat':true
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/getInspiredLanding.html?bd=true',
          'data-nav-description':'m - get inspired',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'navDisplayContent':'BEAUTY GUIDES',
        'navElementType':'rootCategory',
        'categories':[
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://www.ulta.com/shade-finders/?bd=true',
              'data-nav-description':'m - beauty guides:find your shade',
              'linkText':''
            },
            'navDisplayContent':'FIND YOUR SHADE'
          },
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/fragrancefinder/',
              'data-nav-description':'m - beauty guides:find your scent',
              'linkText':''
            },
            'navDisplayContent':'FIND YOUR SCENT'
          },
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/itbrushesforulta/index.html',
              'data-nav-description':'m - beauty guides:it brushes for ulta',
              'linkText':''
            },
            'navDisplayContent':'IT BRUSHES FOR ULTA'
          },
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/glossary/',
              'data-nav-description':'m - beauty guides:beauty glossary',
              'linkText':''
            },
            'navDisplayContent':'BEAUTY GLOSSARY'
          },
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/beautyConsultation.html?bd=true#liveChat',
              'data-nav-description':'m - beauty guides:beauty chat',
              'linkText':''
            },
            'navDisplayContent':'BEAUTY CHAT'
          },
          {
            'image':'https://images.ulta.com/is/image/Ulta/bd_flyout_ShadeFinder_021816',
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://www.ulta.com/shade-finders',
              'linkText':'',
              'data-slot-position':'beauty guides_bd_flyout_ShadeFinder_021816'
            },
            'navDisplayContent':'BEAUTY CONSULTATION FLYOUT',
            'navElementType':'ImageSubCategory',
            'imageAlt':'',
            'imageSubCat':true
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/beautyConsultation.html?bd=true',
          'data-nav-description':'m - beauty guides',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'navDisplayContent':'GIFT CARD',
        'navElementType':'rootCategory',
        'categories':[
          {
            'image':'https://images.ulta.com/is/image/Ulta/bd_flyout_UltaHaul_021816',
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/guestservices/giftCards.jsp',
              'linkText':'',
              'data-slot-position':'gift card_bd_flyout_UltaHaul_021816'
            },
            'navDisplayContent':'GiftCard1',
            'navElementType':'ImageSubCategory',
            'imageAlt':'',
            'imageSubCat':true
          },
          {
            'image':'https://images.ulta.com/is/image/Ulta/bd_flyout_GI_whatshot_022316',
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/guestservices/guestServicesCenterDetails.jsp#GiftWrap',
              'linkText':'',
              'data-slot-position':'gift card_bd_flyout_GI_whatshot_022316'
            },
            'navDisplayContent':'GiftCard-2',
            'navElementType':'ImageSubCategory',
            'imageAlt':'',
            'imageSubCat':true
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/ulta/giftcards/giftCard.jsp?categoryId=cat120341',
          'data-nav-description':'m - gift card',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'navDisplayContent':'SOCIAL GALLERY',
        'navElementType':'rootCategory',
        'categories':[

        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/ultaShareGallery/',
          'data-nav-description':'m - social gallery',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'lineColor':'PM',
        'navElementType':'Filler',
        'navDisplayContent':'Filler2',
        'insertBlank':false,
        'insertLine':true
      },
      {
        'navDisplayContent':'BEAUTY SERVICES',
        'navElementType':'rootCategory',
        'categories':[
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://www.ulta.com/beautyservices/salon/',
              'data-nav-description':'m - beauty services:the salon™',
              'linkText':''
            },
            'navDisplayContent':'THE SALON™'
          },
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://www.ulta.com/beautyservices/dermalogicaskinbar/index.html',
              'data-nav-description':'m - beauty services:skin bar',
              'linkText':''
            },
            'navDisplayContent':'SKIN BAR'
          },
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://www.ulta.com/beautyservices/benefitbrowbar/index.html',
              'data-nav-description':'m - beauty services:brow bar',
              'linkText':''
            },
            'navDisplayContent':'BROW BAR'
          },
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://www.ulta.com/beautyservices/menu.html',
              'data-nav-description':'m - beauty services:menu',
              'linkText':''
            },
            'navDisplayContent':'MENU'
          },
          {
            'navElementType':'SubCategory',
            'categoryLink':{
              'showInNewPage':false,
              'navTargetLink':'https://qa3.ulta.com/ulta/stores/storelocator.jsp?fromsalon=true',
              'data-nav-description':'m - beauty services:book appointment',
              'linkText':''
            },
            'navDisplayContent':'BOOK APPOINTMENT'
          },
          {
            'image':'https://images.ulta.com/is/image/Ulta/flyout_021416_bs',
            'imageLink':{
              'showInNewPage':false,
              'navTargetLink':'https://www.ulta.com/beautyservices',
              'linkText':'',
              'data-slot-position':'beauty services_flyout_021416_bs'
            },
            'navDisplayContent':'Beauty Service Flyout',
            'navElementType':'ImageSubCategory',
            'imageAlt':'',
            'imageSubCat':true
          }
        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/beautyservices/',
          'data-nav-description':'m - beauty services',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'navDisplayContent':'BOOK APPOINTMENT',
        'navElementType':'rootCategory',
        'categories':[

        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/stores',
          'data-nav-description':'m - book appointment',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'navDisplayContent':'CURRENT AD',
        'navElementType':'rootCategory',
        'categories':[

        ],
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://storead.ulta.com/',
          'data-nav-description':'m - current ad',
          'linkText':''
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'displayFeatured':'true',
        'redirectURL':'http://qa3.ulta.com/ultablackfriday',
        'flyout':[

        ],
        'data-nav-description':'black friday:featured',
        'displayBookAppt':'false',
        'navDisplayContent':'Black Friday',
        'navElementType':'rootCategory',
        'featuredLabel':'Featured',
        'categories':[

        ],
        'categoryLink':{
          'dataNavDescription':'m - black friday'
        },
        'fontColor':'nav-menu-style-black'
      },
      {
        'navElementType':'ImageCategory',
        'categoryImageAlt':'Beauty Mix',
        'categoryLink':{
          'showInNewPage':false,
          'navTargetLink':'https://qa3.ulta.com/mix/',
          'linkText':'',
          'data-slot-position':'m - ultabeautymix_logo_notag'
        },
        'Image':'https://images.ulta.com/is/image/Ulta/UltaBeautyMix_logo_notag',
        'navDisplayContent':'Image Category',
        'subCategories':[

        ]
      }
    ]
  }
} );



export default function( match, params, headers, context ){
  return {
    res: {
      text: bodyContent
    }
  }
}

