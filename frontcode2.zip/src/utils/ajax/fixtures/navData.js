

export const bodyContent = {
  sessionConfirmationNumber: 4618868565085887806
}

export default ( match, params, headers, context ) => ( bodyContent )

