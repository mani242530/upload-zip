export const bodyContent = JSON.stringify(
  {
    'data':{
      'product':{
        'gwp':false,
        'displayName':'Classic Nail Lacquer',
        'actionUrl':'https://qa3.ulta.com/classic-nail-lacquer?productId=xlsImpprod5180201',
        'defaultSku':'2204232',
        'parentCategory':{
          'name':'Nail Polish',
          'actionUrl':'https://qa3.ulta.com/nail-polish?N=278s',
          'parentCategory':{
            'name':'Nails',
            'actionUrl':'https://qa3.ulta.com/nails?N=271o',
            'parentCategory':null
          }
        },
        'id':'xlsImpprod5180201',
        'altImages':null,
        'title':'Lorac Travel Size TANtalizer Baked Bronzer | Ulta Beauty'
      },
      'swatches':{
        'items':[
          {
            'checkProfile':false,
            'variantDesc':'A-Rose at Dawn...Broke by Noon',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2083397?$sm$',
            'altImageText':'OPI Classic Nail Lacquer A-Rose at Dawn...Broke by Noon',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2083397?$md$',
            'skuId':'2083397'
          },
          {
            'checkProfile':false,
            'variantDesc':'Miami Beet',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2204233?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Miami Beet',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2204233?$md$',
            'skuId':'2204233'
          },
          {
            'checkProfile':false,
            'variantDesc':'Feelin\' Hot-Hot-Hot!',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2204232?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Feelin\' Hot-Hot-Hot!',
            'inStock':false,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2204232?$md$',
            'skuId':'2204232'
          },
          {
            'checkProfile':false,
            'variantDesc':'Happy Anniversary!',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2134009?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Happy Anniversary!',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2134009?$md$',
            'skuId':'2134009'
          },
          {
            'checkProfile':false,
            'variantDesc':'Koala Bear-y',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2141407?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Koala Bear-y',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2141407?$md$',
            'skuId':'2141407'
          },
          {
            'checkProfile':false,
            'variantDesc':'Chocolate Moose',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2103825?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Chocolate Moose',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2103825?$md$',
            'skuId':'2103825'
          },
          {
            'checkProfile':false,
            'variantDesc':'Pompeii Purple',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6051198?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Pompeii Purple',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6051198?$md$',
            'skuId':'6051198'
          },
          {
            'checkProfile':false,
            'variantDesc':'Lincoln Park After Dark',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2118403?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Lincoln Park After Dark',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2118403?$md$',
            'skuId':'2118403'
          },
          {
            'checkProfile':false,
            'variantDesc':'Bogota Blackberry',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6051142?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Bogota Blackberry',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6051142?$md$',
            'skuId':'6051142'
          },
          {
            'checkProfile':false,
            'variantDesc':'Aphrodite\'s Pink Nightie',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2097144?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Aphrodite\'s Pink Nightie',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2097144?$md$',
            'skuId':'2097144'
          },
          {
            'checkProfile':false,
            'variantDesc':'California Raspberry',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6051134?$sm$',
            'altImageText':'OPI Classic Nail Lacquer California Raspberry',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6051134?$md$',
            'skuId':'6051134'
          },
          {
            'checkProfile':false,
            'variantDesc':'Dutch Tulips',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6051156?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Dutch Tulips',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6051156?$md$',
            'skuId':'6051156'
          },
          {
            'checkProfile':false,
            'variantDesc':'Malaga Wine',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6051170?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Malaga Wine',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6051170?$md$',
            'skuId':'6051170'
          },
          {
            'checkProfile':false,
            'variantDesc':'OPI Red',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6051172?$sm$',
            'altImageText':'OPI Classic Nail Lacquer OPI Red',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6051172?$md$',
            'skuId':'6051172'
          },
          {
            'checkProfile':false,
            'variantDesc':'Samoan Sand',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6051192?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Samoan Sand',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6051192?$md$',
            'skuId':'6051192'
          },
          {
            'checkProfile':false,
            'variantDesc':'Chicago Champagne Toast',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6052129?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Chicago Champagne Toast',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6052129?$md$',
            'skuId':'6052129'
          },
          {
            'checkProfile':false,
            'variantDesc':'Chick Flick Cherry',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6052430?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Chick Flick Cherry',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6052430?$md$',
            'skuId':'6052430'
          },
          {
            'checkProfile':false,
            'variantDesc':'I\'m Not Really a Waitress',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6052436?$sm$',
            'altImageText':'OPI Classic Nail Lacquer I\'m Not Really a Waitress',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6052436?$md$',
            'skuId':'6052436'
          },
          {
            'checkProfile':false,
            'variantDesc':'Black Onyx',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2105693?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Black Onyx',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2105693?$md$',
            'skuId':'2105693'
          },
          {
            'checkProfile':false,
            'variantDesc':'Big Apple Red',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2051371?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Big Apple Red',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2051371?$md$',
            'skuId':'2051371'
          },
          {
            'checkProfile':false,
            'variantDesc':'You Don\'t Know Jacques!',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2163497?$sm$',
            'altImageText':'OPI Classic Nail Lacquer You Don\'t Know Jacques!',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2163497?$md$',
            'skuId':'2163497'
          },
          {
            'checkProfile':false,
            'variantDesc':'Tickle My France-y',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2163498?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Tickle My France-y',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2163498?$md$',
            'skuId':'2163498'
          },
          {
            'checkProfile':false,
            'variantDesc':'Cozu-melted in the Sun',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2126498?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Cozu-melted in the Sun',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2126498?$md$',
            'skuId':'2126498'
          },
          {
            'checkProfile':false,
            'variantDesc':'Strawberry Margarita',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2126494?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Strawberry Margarita',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2126494?$md$',
            'skuId':'2126494'
          },
          {
            'checkProfile':false,
            'variantDesc':'An Affair in Red Square',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2149252?$sm$',
            'altImageText':'OPI Classic Nail Lacquer An Affair in Red Square',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2149252?$md$',
            'skuId':'2149252'
          },
          {
            'checkProfile':false,
            'variantDesc':'Cosmo-Not Tonight Honey!',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2149257?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Cosmo-Not Tonight Honey!',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2149257?$md$',
            'skuId':'2149257'
          },
          {
            'checkProfile':false,
            'variantDesc':'Pink Flamenco',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2210902?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Pink Flamenco',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2210902?$md$',
            'skuId':'2210902'
          },
          {
            'checkProfile':false,
            'variantDesc':'Barefoot in Barcelona',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2210911?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Barefoot in Barcelona',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2210911?$md$',
            'skuId':'2210911'
          },
          {
            'checkProfile':false,
            'variantDesc':'Red My Fortune Cookie',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2216416?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Red My Fortune Cookie',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2216416?$md$',
            'skuId':'2216416'
          },
          {
            'checkProfile':false,
            'variantDesc':'Hot & Spicy',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2216424?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Hot & Spicy',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2216424?$md$',
            'skuId':'2216424'
          },
          {
            'checkProfile':false,
            'variantDesc':'Lucky Lucky Lavender',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2216429?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Lucky Lucky Lavender',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2216429?$md$',
            'skuId':'2216429'
          },
          {
            'checkProfile':false,
            'variantDesc':'Not So Bora-Bora-ing Pink',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6052030?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Not So Bora-Bora-ing Pink',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6052030?$md$',
            'skuId':'6052030'
          },
          {
            'checkProfile':false,
            'variantDesc':'Tutti Frutti Tonga',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/6052033?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Tutti Frutti Tonga',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/6052033?$md$',
            'skuId':'6052033'
          },
          {
            'checkProfile':false,
            'variantDesc':'Dulce de Leche',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2070018?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Dulce de Leche',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2070018?$md$',
            'skuId':'2070018'
          },
          {
            'checkProfile':false,
            'variantDesc':'Color So Hot It Berns',
            'skuImageURL':'https://images.ulta.com/is/image/Ulta/2222139?$sm$',
            'altImageText':'OPI Classic Nail Lacquer Color So Hot It Berns',
            'inStock':true,
            'hoverImage':'https://images.ulta.com/is/image/Ulta/2222139?$md$',
            'skuId':'2222139'
          }
        ]
      },
      'sku':{
        'longDescription':'The most-asked-for brand in the industry! With a superior range of shades and the hottest special effects and textures, OPI is the go-to brand for nail fashion. From elegant classics to eye-popping brights, OPI has your color! Formaldehyde-free.',
        'enableFindStore':false,
        'images':{
          'blowupImage':'https://images.ulta.com/is/image/Ulta/2204232?$detail$',
          'mainImage':'https://images.ulta.com/is/image/Ulta/2204232',
          'largeImage':'https://images.ulta.com/is/image/Ulta/2204232?$lg$',
          'smallImage':'https://images.ulta.com/is/image/Ulta/2204232?$sm$',
          'thumbnailImage':'https://images.ulta.com/is/image/Ulta/2204232?$tn$',
          'mediumImageUrl':'https://images.ulta.com/is/image/Ulta/2204232?$md$'
        },
        'displayName':'Classic Nail Lacquer',
        'description':'The most-asked-for brand in the industry! Classic Nail Lacquer with a superior range of shades and the hottest special effects and textures, OPI is the go-to brand for nail fashion. From elegant classics to eye-popping brights, OPI has your color!',
        'badges':null,
        'shippingRestricted':true,
        'UOM':'oz',
        'couponEligible':true,
        'directions':'Follow these steps for a mani that lasts:<ul><li>Start by applying OPI Base Coat or Treatment on clean, dry nails with cuticles pushed back.<li>For a perfect polish, apply one stroke of nail lacquer down the center of the nail, followed by one stroke along each side of the nail.<li>Smooth the surface of the nail with a final stroke of the brush. Then, apply a second coat of nail lacquer, pulling color over the tips of the nails.<li>Shine, seal, and protect with one coat of OPI Top Coat, pulling it over the tips of the nails to seal in color.<li>For a mani that\'s dry to the touch in minutes, apply 2 drops of OPI DripDry Lacquer Drying Drops to each nail.<\/li><\/ul>',
        'size':'0.5',
        'comingSoon':false,
        'price':{
          'salePrice':null,
          'listPrice':{
            'displayAmount':'$10.00',
            'amount':10,
            'currencyCode':'USD'
          }
        },
        'enableAskaQuestion':false,
        'variant':{
          'variantType':'Color',
          'variantDesc':'Feelin\' Hot-Hot-Hot!'
        },
        'ingredients':'Ethyl Acetate, Butyl Acetate, Nitrocellulose, Propyl Acetate, Tosylamide Formaldehyde Resin, Isopropyl Alcohol, Trimethyl Pentanyl Diisobutyrate, Triphenyl Phosphate, Ethyl Tosylamide, Camphor, Stearalkonium Bentonite, Diacetone Alcohol, Stearalkonium Hectorite, Benzophenone 1, Citric Acid, Dimethicone, CI 77120, Titanium Dioxide (CI 77891), CI 77499, FD&C Yellow 5 Aluminum Lake, FD&C Red 6.',
        'storeOnly':false,
        'id':'2204232',
        'maxQty':10
      },
      'brand':{
        'brandName':'OPI',
        'actionUrl':'https://qa3.ulta.com/brand/opi',
        'brandId':'xlsImp19400002'
      }
    },
    'meta':{
      'lastFetchedTime':'2018-03-19 10:23:47.033-05:00'
    }
  }
);


export default function( match, params, headers, context ){
  return {
    res: {
      text: bodyContent
    }
  }
}
