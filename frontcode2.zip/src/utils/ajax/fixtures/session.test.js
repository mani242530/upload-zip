

import _ from 'lodash';
import session from './session';


describe( 'session', ( ) => {

  it( 'should be a function', ( ) => {
    expect( _.isFunction( session ) ).toBe( true );
  } );

  it( 'should return the sessionConfirmationNumber', ( ) => {
    expect( JSON.stringify( session() ) ).toEqual( '{\"sessionConfirmationNumber\":4618868565085887000}' );
  } );

} );


