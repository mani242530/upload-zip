export const bodyContent = JSON.stringify(
  {
    'data': {
      'sku': {
        'longDescription': '<b>SHIPS FREE: Purchase bareMinerals foundation and ALWAYS get free shipping on your ENTIRE ORDER! No Minimum</b><br>(Purchase Original, Matte, Ready, or BareSkin Foundation, and you automatically get Free Shipping on your Entire Order)<br><br>bareMinerals Original Foundation is the #1 U.S. Prestige Loose Powder Foundation*<br><br>*Source: The NPD Group, Inc. / U.S. Prestige Beauty Total Department Specialty, Dollar & Unit Sales, Annual 2016<br><br>With just five pure ingredients, bareMinerals SPF 15 Foundation delivers flawless coverage and the creamy minerals are clinically proven to improve the appearance of skin over time. It looks like a powder, feels like a cream, and buffs on like silk, giving skin a natural luminosity while feeling as if you are not wearing any makeup at all.<br><br>Benefits:<ul><li>Clinically proven to promote clearer, healthier-looking skin.<li>Provides buildable, complete coverage.<li>Free of preservatives, talc, oil, waxes, fragrances, and other chemicals that can irritate skin and cause breakouts.<li>Free of parabens, sulfates, and phthalates.<li>Pure enough to sleep in, made with 5 mineral ingredients. Non-acnegenic, hypoallergenic, non-comedogenic. Formulated without binders, fillers or synthetic chemicals.</li></ul><br><a href="http://ulta.com/shade-finders/bareminerals-original-foundation-finder/"target="_blank">Click here to find your perfect bareMinerals Original shade!</a><br><br><iframe width="420" height="315" src="https://www.youtube.com/embed/AYDDxtUVFKA?rel=0" frameborder="0" allowfullscreen></iframe><br><br><iframe width="420" height="315" src="https://www.youtube.com/embed/jSfRkOjjf8U" frameborder="0" allowfullscreen></iframe></li></ul>\r',
        'enableFindStore': true,
        'images': {
          'blowupImage': 'https://images.ulta.com/is/image/Ulta/5081178?$detail$',
          'mainImage': 'https://images.ulta.com/is/image/Ulta/5081178',
          'largeImage': 'https://images.ulta.com/is/image/Ulta/5081178?$lg$',
          'smallImage': 'https://images.ulta.com/is/image/Ulta/5081178?$sm$',
          'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/5081178?$tn$',
          'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/5081178?$md$'
        },
        'price':{
          'salePrice': {
            'displayAmount': '$0.00',
            'amount': 0,
            'currencyCode': 'USD'
          },
          'listPrice': {
            'displayAmount': '$28.5',
            'amount': 28.5,
            'currencyCode': 'USD'
          }
        },
        'displayName': 'ORIGINAL Foundation Broad Spectrum SPF 15',
        'description': 'bareMinerals SPF 15 Foundation',
        'badges': {
          'items': [
            {
              'badgeName': 'fanFavorite_badge',
              'priority': 9,
              'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-fan-fave'
            }
          ]
        },
        'shippingRestricted': false,
        'UOM': 'oz',
        'couponEligible': false,
        'directions': 'Swirl a small amount of bareMinerals Foundation in the lid until it all disappears into the brush. Tap away excess. Buff onto the skin in a circular motion.<br><br>Pair with the Beautiful Finish Brush, which is designed with a skirted silhouette that fits perfectly into the ORIGINAL and MATTE Foundation lids to help capture (and contain) every mineral.',
        'size': '0.28',
        'comingSoon': false,
        'enableAskaQuestion': true,
        'variant': {
          'variantType': 'Color',
          'variantDesc': 'Fair 01 (fairest porcelain skin w/ cool undertones)'
        },
        'ingredients': 'Active: Titanium Dioxide 12.6%, Zinc Oxide 21%. Inactive: Bismuth Oxychloride, Mica, Iron Oxides, Zinc Oxide, Titanium Dioxide.',
        'onSale': false,
        'storeOnly': false,
        'id': '5081178',
        'maxQty': 10
      }
    },
    'meta': {
      'lastFetchedTime': '2018-02-26 07:09:43.083-06:00'
    }
  }
);


export default function( match, params, headers, context ){
  return {
    res: {
      text: bodyContent
    }
  }
}
