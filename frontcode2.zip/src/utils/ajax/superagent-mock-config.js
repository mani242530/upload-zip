import sessionFixture from './fixtures/session';
import mhp from './fixtures/mhp';
import nav from './fixtures/nav';
import skuData from './fixtures/skuData';
import productData from './fixtures/productData';
import config from './fixtures/config';
import navData from './fixtures/navData';

export default [
  {
    pattern: 'http://uat.ulta.com/services/v1/session/token',
    fixtures: sessionFixture,
    get:( match, data ) => ( data )
  },
  {
    pattern: 'http://uat.ulta.com/services/v1/page/home',
    fixtures: mhp,
    get: ( match, data ) => ( data )
  },
  {
    pattern: 'http://uat.ulta.com/services/v2/page/nav',
    fixtures: nav,
    get: ( match, data ) => ( data )
  },
  {
    pattern: 'http://uat.ulta.com/services/v5/catalog/sku/(.*)',
    fixtures: skuData,
    get: ( match, data ) => ( data )
  },
  {
    pattern: 'http://uat.ulta.com/services/v5/catalog/product/(.*)',
    fixtures: productData,
    get: ( match, data ) => ( data )
  },
  {
    pattern: 'http://uat.ulta.com/services/v1/global/config',
    fixtures: config,
    get: ( match, data ) => ( data )
  }
];
