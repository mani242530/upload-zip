import { createScriptTag } from 'ulta-fed-core/dist/js/utils/third_party_scripts/third_party_scripts';

export const injectFingerPrint = orderId => {

  let targetUrl = `/ulta/global/fp.jsp?order_id=${orderId}`;

  let pTag = document.createElement( 'p' );
  pTag.style.background = `url(${targetUrl}&type=p)`;


  let objectTag = document.createElement( 'object' );
  objectTag.type = 'application/x-shockwave-flash';
  objectTag.data = targetUrl + '&type=obj';
  objectTag.width = '1';
  objectTag.height = '1';
  objectTag.id = 'thm_fp';
  let paramTag = document.createElement( 'param' );
  paramTag.name = 'movie';
  paramTag.value = `${targetUrl}&type=obj`;
  objectTag.appendChild( paramTag );
  let divTag = document.createElement( 'div' );
  objectTag.appendChild( divTag );



  let imgTag = document.createElement( 'img' );
  imgTag.src = `${targetUrl}&type=img`;
  imgTag.alt = '';

  document.getElementsByTagName( 'body' )[0].appendChild( pTag );
  document.getElementsByTagName( 'body' )[0].appendChild( objectTag );
  document.getElementsByTagName( 'body' )[0].appendChild( imgTag );
  createScriptTag( { 'attributes': { 'id': 'CYBERSOURCE_SCRIPT', 'type': 'text/javascript', 'src': `${targetUrl}&type=script` } } );

}