import _ from 'lodash';
import { injectFingerPrint } from './cybersource';

describe( 'Cybsersource test', () => {

  it( 'check if the function injectFingerPrint is defined.', () => {
    expect( _.isFunction( injectFingerPrint ) ).toBe( true );
  } );

  injectFingerPrint( 'U123232' );

  it( 'check if the object node is getting created successfully', () => {
    expect( document.querySelectorAll( 'object' ).length ).toBe( 1 );
  } );

  it( 'check if the img node is getting created successfully', () => {
    expect( document.querySelectorAll( 'img' ).length ).toBe( 1 );
  } );

  it( 'check if the script element is getting created successfully', () => {
    expect( document.querySelectorAll( 'script' ).length ).toBe( 1 );
  } );

} );
