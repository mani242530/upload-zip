import { isServer } from 'ulta-fed-core/dist/js/utils/device_detection/device_detection';


export const setWindowDebuggingFlag = ( DEBUGGING_FLAG, CONFIG ) => {

  if( !isServer() ){

    const params = new URLSearchParams( global.location.search );
    // if we are in development mode
    if( process.env.NODE_ENV === 'development' ){
      global[ DEBUGGING_FLAG ] = CONFIG.DEBUGGING.LOGGING[ DEBUGGING_FLAG ];
    }

    const dataLayerParam = params.get( DEBUGGING_FLAG );

    global[ DEBUGGING_FLAG ] = ( dataLayerParam ) ?
      ( dataLayerParam === 'true' ) :
      global[ DEBUGGING_FLAG ];

  }

}
