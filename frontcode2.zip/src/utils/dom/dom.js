import ReactDOM from 'react-dom';
import { isServer } from 'ulta-fed-core/dist/js/utils/device_detection/device_detection';

export const renderComponent = function( calledFromServer = isServer() ){
  return calledFromServer ? ReactDOM.hydrate : ReactDOM.render;
}
