import ReactDOM from 'react-dom';
import { renderComponent } from './dom';


describe( 'ReactDOM helper methods for SSR', () => {

  it( 'should return the reactDOM `render` method when called from a non server configuration', () => {
    expect( renderComponent( false ) ).toEqual( ReactDOM.render );

  } );

  it( 'should return the ReactDom `hydrate` method when called from a server configuration', () => {
    expect( renderComponent( true ) ).toEqual( ReactDOM.hydrate );
  } );

  it( 'should default to using `isServer` if no value is passed', () => {
    expect( renderComponent() ).toEqual( ReactDOM.render );
  } );

} );
