import url from 'url';
import { isServer } from 'ulta-fed-core/dist/js/utils/device_detection/device_detection';

export const getLocation = function( req ){
  let location;
  if( isServer() ){
    location = {
      host: '',
      hostname: '',
      protocol: '',
      href: '',
      origin: '',
      reload: '',
      search: ''
    };
  }
  else {
    location = window.location;
  }

  return location;
}

export const isSecurePage = function( val ){
  let protocol = val || ( !isServer() && global.location.protocol );
  return protocol === 'https:';
}
