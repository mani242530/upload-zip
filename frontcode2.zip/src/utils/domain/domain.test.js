import { isSecurePage } from './Domain';

jest.mock( 'ulta-fed-core/dist/js/utils/device_detection/device_detection', () => {
  return {
    isServer:jest.fn( () => true )
  }
} )

describe( 'Domain util methods', () => {

  it( 'the isSecurePage should return false if the protocol is not secure', () => {
    expect( isSecurePage( 'http:' ) ).not.toBeTruthy();
  } );

  it( 'the isSecurePage should return true if the protocol is secure', () => {
    expect( isSecurePage( 'https:' ) ).toBeTruthy();
  } );

  it( 'the isSecurePage should return false if it is on Server', () => {
    expect( isSecurePage() ).toBe( false );
  } );


} );
