export const getExpirationInMilliseconds = ( expiryAgeInSeconds ) =>{

  return Date.now() + ( expiryAgeInSeconds * 1000 );

}