import { getExpirationInMilliseconds } from './formatters'

describe( 'Formatters - util methods for formatting date and time values', () => {

  Date.now = jest.fn( ()=>{
    return 1557511995274;
  } )
  it( 'should return an expiry duration in milliseconds', () => {

    let expiryAgeInSeconds = 2592000 // 30 days in seconds
    let expectedOutput = 1557511995274 + ( expiryAgeInSeconds * 1000 );

    expect( getExpirationInMilliseconds( expiryAgeInSeconds ) ).toBe( expectedOutput );
  } );

} );