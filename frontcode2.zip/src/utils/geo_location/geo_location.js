import CONFIG from '../../config';

// resolve position when success event
export const getPositionSuccess = ( resolve ) => {
  return function( position ){
    resolve( position );
  }
}

// resolve undefined when error event
export const getPositionError = ( resolve ) => {
  return function( err ){
    resolve( undefined );
  }
}

export const getGeoLocation = ( geoLocationTimeout, successMethod = getPositionSuccess, failureMethod = getPositionError, mockVal ) => {
  const geolocation = navigator.geolocation;

  return new Promise( ( resolve ) => {
    if( !geolocation ){
      // call failureMethod method the geolocation object is not available
      failureMethod( resolve )();
    }
    else {
      // call HTML5 getCurrentPosition method to get users current positions
      geolocation.getCurrentPosition(
        successMethod( resolve ),
        failureMethod( resolve ),
        {
          ...CONFIG.BOPIS.geoLocationOption,
          ...( !!geoLocationTimeout && { timeout: geoLocationTimeout } ) // timeout at milliseconds
        }
      );
    }
  } );
};
