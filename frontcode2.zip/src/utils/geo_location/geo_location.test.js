import '@babel/polyfill';
import isFunction from 'lodash/isFunction';
import {
  getGeoLocation,
  getPositionSuccess,
  getPositionError
} from './geo_location';

describe( 'GetLocation test', () => {
  const position = {
    coords: {
      latitude: 41.6796776,
      longitude: -88.10651899999999
    }
  };
  const mockGeolocation = {
    getCurrentPosition: jest.fn()
  };

  let successMethodMock = jest.fn( () => Promise.resolve( position ) );
  let failureMethodMock = jest.fn( () => Promise.resolve( undefined ) );

  beforeEach( () => {
    global.navigator.geolocation = mockGeolocation;
  } );

  afterEach( () => {
    mockGeolocation.getCurrentPosition.mockReset();
  } );

  it( 'should check if the functions getGeoLocation, getPositionSucces, getPositionError is defined.', () => {
    expect( isFunction( getGeoLocation ) ).toBe( true );
    expect( isFunction( getPositionSuccess ) ).toBe( true );
    expect( isFunction( getPositionError ) ).toBe( true );
  } );

  it( 'should call el with position object that passed to getPositionSucces function', () => {
    getPositionSuccess( ( el ) => {
      expect( el ).toEqual( position );
    } )( position );
  } );

  it( 'should call el with error object that passed to getPositionError function', () => {
    const expectedError = new Error( 'Geo location permission issue' );
    getPositionError( ( el ) => {
      expect( el ).toBeUndefined();
    } )( expectedError );
  } );

  it( 'should call the successMethod when the promise resolves with a position value', async() => {
    const geoLocationTimeout = 60;
    global.navigator.geolocation.getCurrentPosition.mockImplementationOnce( successMethodMock );
    getGeoLocation( geoLocationTimeout, successMethodMock, failureMethodMock );
    return expect( mockGeolocation.getCurrentPosition.mock.calls[0][0] ).resolves.toEqual( position );
  } );

  it( 'should call the getCurrentPosition without timeout if geoLocationTimeout is undefined', async() => {
    const geoLocationOption = {
      enableHighAccuracy: true,
      maximumAge: 30000
    };
    const geoLocationTimeout = undefined;

    getGeoLocation( geoLocationTimeout, successMethodMock, failureMethodMock );
    return expect( mockGeolocation.getCurrentPosition.mock.calls[0][2] ).toEqual( geoLocationOption );
  } );

  it( 'should call the getCurrentPosition with given timeout if geoLocationTimeout is defined', async() => {
    const geoLocationOption = {
      enableHighAccuracy: true,
      timeout: 1000,
      maximumAge: 30000
    };
    const geoLocationTimeout = 1000;

    getGeoLocation( geoLocationTimeout, successMethodMock, failureMethodMock );
    return expect( mockGeolocation.getCurrentPosition.mock.calls[0][2] ).toEqual( geoLocationOption );
  } );


  it( 'should call the failureMethod when the promise resolves with a undefined value', () => {
    global.navigator.geolocation.getCurrentPosition.mockImplementationOnce( failureMethodMock );
    getGeoLocation( undefined, successMethodMock, failureMethodMock );
    return expect( mockGeolocation.getCurrentPosition.mock.calls[0][1] ).resolves.toBeUndefined();
  } );

  it( 'should check if the getCurrentPosition function is called', () => {
    getGeoLocation();
    expect( mockGeolocation.getCurrentPosition ).toHaveBeenCalled();
  } );

  it( 'should return a navigator geolocation promise that resolves with a undefined value', () => {
    global.navigator.geolocation = undefined;

    return expect( getGeoLocation( successMethodMock, failureMethodMock ).resolves ).toBeUndefined();
  } );

} );
