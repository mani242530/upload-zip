import createBrowserHistory from 'history/createBrowserHistory';
import { authorizeReplace, authorizePush } from '../../events/authorize/authorize.events';
import { getStore } from '../../modules/shared/store';



let history;

// >  getHistory method returns the history object it is already initiated
// >  or it creates an instance of history using createBrowserHistory
// >  even if the history object exists, if getHistory is invoked using a baseName a new instance will be created
// >  the replace and push methods are overridden to apply authorization to the urls
const getHistory = ( basename ) => {

  if( basename || !history ){

    history = createBrowserHistory( { basename : basename || '/' } );

    history = moduleMethods.modifyHistoryMethods( history );
  }

  return history;
}

//  > modifyHistoryMethods will override replace and push methods to apply authorization to the urls
export const modifyHistoryMethods = ( historyObj ) => {

  const modifiedHistory = historyObj;

  const replaceOriginal = historyObj.replace;
  const pushOriginal = historyObj.push;

  // > replace method is overriden to dispatch an action which will apply authorization for the url
  modifiedHistory.replace = function( ...args ){
    const url = historyObj.createHref( {
      pathname: args[0]
    } );

    getStore().dispatch( authorizeReplace( url, args[0], args[1] ) );
  };

  // > a new method forceReplace is added to the history object, which in turn will invoke the original replace method
  // > forceReplace will change the route without applying any authorization
  modifiedHistory.forceReplace = function( ...args ){
    return replaceOriginal.apply( this, args );
  };

  // > push method is overriden to dispatch an action which will apply authorization for the url
  modifiedHistory.push = function( ...args ){
    const url = historyObj.createHref( {
      pathname: args[0]
    } );

    getStore().dispatch( authorizePush( url, args[0], args[1] ) );
  };

  // > a new method forcePush is added to the history object, which in turn will invoke the original push method
  // > forcePush will change the route without applying any authorization
  modifiedHistory.forcePush = function( ...args ){
    return pushOriginal.apply( this, args );
  };

  return modifiedHistory;
}

export const moduleMethods = {
  modifyHistoryMethods
}

export default getHistory;