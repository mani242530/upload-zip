
import createBrowserHistory from 'history/createBrowserHistory';
import getHistory, { moduleMethods } from './history';
import { getStore } from '../../modules/shared/store';
import { authorizeReplace, authorizePush } from '../../events/authorize/authorize.events';

jest.mock( 'history/createBrowserHistory', ()=>{
  return jest.fn( () => {
    return {
      location:{
        pathname:'/homePage'
      },
      listen:()=>{}
    }
  } )
} );

jest.mock( '../../modules/shared/store', ()=>{
  const dispatchMock = jest.fn();

  return {
    getStore: () => {
      return {
        dispatch:dispatchMock
      }
    }
  }
} );

describe( 'test cases for modifyHistoryMethods', () => {

  const modifyHistoryMethods = moduleMethods.modifyHistoryMethods;

  it( 'should return history object returned by createBrowseHistory', () => {
    const replaceMock = jest.fn();
    const pushMock = jest.fn();
    const createHrefMock = jest.fn( ( obj ) =>{
      return '/ulta' + obj.pathname;
    } );

    const historyMock = {
      replace:replaceMock,
      push:pushMock,
      createHref:createHrefMock
    }

    const state = { key:'value' };
    const modifiedHistory = modifyHistoryMethods( historyMock );
    modifiedHistory.forcePush( '/CreditCards', state );
    expect( pushMock ).toHaveBeenCalledWith( '/CreditCards', state );

    modifiedHistory.forceReplace( '/checkout', state );
    expect( replaceMock ).toHaveBeenCalledWith( '/checkout', state );

    modifiedHistory.push( '/CreditCards', state );
    expect( createHrefMock ).toHaveBeenCalledWith( { pathname: '/CreditCards' } );
    expect( getStore().dispatch ).toHaveBeenCalledWith( authorizePush( '/ulta/CreditCards', '/CreditCards', state ) );

    modifiedHistory.replace( '/checkout', state );
    expect( createHrefMock ).toHaveBeenCalledWith( { pathname: '/checkout' } );
    expect( getStore().dispatch ).toHaveBeenCalledWith( authorizeReplace( '/ulta/checkout', '/checkout', state ) );

  } );

} )


describe( 'test cases for history', () => {

  it( 'should return history object returned by createBrowseHistory', () => {
    expect( getHistory().location ).toEqual( { pathname:'/homePage' } ) ;
  } );

  it( 'should invoke createBrowseHistory with the basename value passed to getHistory', () => {
    const modifyHistoryMethods = jest.fn();
    moduleMethods.modifyHistoryMethods = modifyHistoryMethods;
    getHistory( '/creditcards' )
    expect( createBrowserHistory ).toHaveBeenCalledWith( { basename: '/creditcards' } );
    expect( modifyHistoryMethods ).toHaveBeenCalled();
  } );

  it( 'should invoke createBrowseHistory with / if no basename value is passed to it', () => {
    getHistory()
    expect( createBrowserHistory ).toHaveBeenCalledWith( { basename: '/' } );
  } );

} )