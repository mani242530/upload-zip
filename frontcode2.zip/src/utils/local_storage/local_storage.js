import Cookies from 'js-cookie';
import isUndefined from 'lodash/isUndefined';
import isEmpty from 'lodash/isEmpty';
import { isSecurePage } from '../domain/domain';
import { initialState as cartInitialState } from '../../models/view/cart/cart.model';
import appConstants from '../../shared/appConstants';

export const CookieKey = isSecurePage() ? 's_uTk' : 'u_uTk';


export const loadState = ( ) => {

  try {
    const persistedState = Cookies.get( CookieKey );
    let sD = {};

    const reduxStoreElement = document.getElementById( 'js_reduxstore' );
    // handle the server loaded state data and remove the state data from the server
    if( reduxStoreElement ){
      // grab the state from a global variable inject into the server-generated HTML
      const serverState = window.__PRELOADED_STATE__;
      // Allow the passed state to be garbase-collected
      delete window.__PRELOADED_STATE__;
      sD = serverState;
      reduxStoreElement.parentNode.removeChild( reduxStoreElement );
    }

    // if it is for the first time the react page is being accessed, the cookie will not be present
    // and persistedState will be undefined
    if( isUndefined( persistedState ) ){
      // if persistedState is undefined, and if serverState is also empty, then return undefined
      if( isEmpty( sD ) ){
        return undefined;
      }
      // if persistedSate is undefined, but if it has the server state populated, then it returns the server state
      else {
        return sD;
      }
    }

    let pdata = JSON.parse( persistedState );


    // change the keys of the persisted Data so it matches the data in the reducer
    sD = {
      ...sD,
      session: {
        ...sD.session,
        // anytime that the cookie is read from for instantiation,
        // we need to make suer that we are removing the active sessionFlag
        // to ensure that services that are being called properly.
        // the success event of the session saga will set the active session flag
        // which is used to render critical pages
        ...( pdata.a && { activeSession: false } ),
        secureToken:  pdata.s,
        unsecureToken:  pdata.u
      },
      esu: {
        ...sD.esu,
        stickyEmailSignUp: {
          sessionData: {
            isStickyFooterDisplay: pdata.sfd
          }
        }
      }
    }

    return sD;

  }
  catch ( err ){
    // return undefined;
    console.error( 'there was an issue loading the state', err.message ); // eslint-disable-line
  }
}


export const saveState = ( state ) => {
  try {
    // create a new object to store sessionData
    const sD = {
      a: state.session.activeSession,
      s: state.session.secureToken,
      u: state.session.unsecureToken,
      ...( state.emailSignUp && { sfd: state.emailSignUp.isStickyFooterDisplay } )
    }
    const serializedState = JSON.stringify( sD );
    // change the keys of the persisted Data so it isn't so readable in the cookie
    Cookies.set( CookieKey, serializedState, { secure: isSecurePage() } );
  }
  catch ( err ){
    return undefined;
  }
}

export const persistSearchDataForAnalytics = ( searchInputValue, selectedTerm ) => {
  // Check if the sessionStorage object exists
  if( sessionStorage ){
    try {
      // trim is required inorder not to add an empty search node if the searchTerm is ' '
      if( searchInputValue && searchInputValue.trim() !== '' ){
        // JSON.stringify is required here as the function reading from sessionStorage is using JSON.parse else it will not work
        sessionStorage.setItem( 'searchTerm', JSON.stringify( searchInputValue.toLowerCase() ) );
        sessionStorage.setItem( 'searchFlag', JSON.stringify( 'true' ) );
        sessionStorage.setItem( 'searchAutoSuggest', JSON.stringify( 'false' ) );
      }
      if( selectedTerm ){
        sessionStorage.setItem( 'searchAutoSuggest', JSON.stringify( 'true' ) );
        sessionStorage.setItem( 'selectedTerm', JSON.stringify( selectedTerm.toLowerCase() ) );
      }
    }
    catch ( e ){
      console.error( 'Error: Saving to storage.' );// eslint-disable-line
    }
  }
  else {
    console.error( 'Sorry, your browser doesn\'t support session storage.' );// eslint-disable-line
  }
}

export const persistDataForTopResultsClick = ( productIndex, visualTerm, searchTerm ) => {
  // Check if the sessionStorage object exists
  persistSearchDataForAnalytics( searchTerm, null );
  if( sessionStorage ){
    try {
      sessionStorage.setItem( 'productIndex', JSON.stringify( productIndex ) );
      sessionStorage.setItem( 'visualTerm', JSON.stringify( visualTerm.toLowerCase() ) );
    }
    catch ( e ){
      console.error( 'Error: Saving to storage.' );// eslint-disable-line
    }
  }
  else {
    console.error( 'Sorry, your browser doesn\'t support session storage.' );// eslint-disable-line
  }
}

export const persistDataOnViewAllResultClick = ( visualTerm, searchTerm ) => {
  // Check if the sessionStorage object exists
  persistSearchDataForAnalytics( searchTerm, null )
  if( sessionStorage ){
    try {
      sessionStorage.setItem( 'viewAllResultFlag', JSON.stringify( 'true' ) );
      sessionStorage.setItem( 'visualTerm', JSON.stringify( visualTerm.toLowerCase() ) );
    }
    catch ( e ){
      console.error( 'Error: Saving to storage.' );// eslint-disable-line
    }
  }
  else {
    console.error( 'Sorry, your browser doesn\'t support session storage.' );// eslint-disable-line
  }
}

export const removeSearchData = ( ) => {
  // Check if the sessionStorage object exists
  if( sessionStorage ){
    try {
      sessionStorage.removeItem( 'viewAllResultFlag' );
      sessionStorage.removeItem( 'productIndex' );
      sessionStorage.removeItem( 'visualTerm' );
      sessionStorage.removeItem( 'searchTerm' );
      sessionStorage.removeItem( 'selectedTerm' );
      sessionStorage.removeItem( 'searchAutoSuggest' );
    }
    catch ( e ){
      console.error( 'Error: Saving to storage.' );// eslint-disable-line
    }
  }
  else {
    console.error( 'Sorry, your browser doesn\'t support session storage.' );// eslint-disable-line
  }
}

export const retrieveViewAllResultFlag = () => {
  return JSON.parse( sessionStorage.getItem( 'viewAllResultFlag' ) );
}
export const retrieveProductIndex = () => {
  return sessionStorage.getItem( 'productIndex' );
}
export const retrieveVisualTerm = () => {
  return JSON.parse( sessionStorage.getItem( 'visualTerm' ) );
}
export const retrieveSearchTerm = () => {
  return JSON.parse( sessionStorage.getItem( 'searchTerm' ) );
}

export const retrieveSelectedTerm = () => {
  return JSON.parse( sessionStorage.getItem( 'selectedTerm' ) );
};

export const persistExternalAddInput = ( addToBag ) => {
  // Check if the sessionStorage object exists
  if( sessionStorage ){
    try {
      sessionStorage.setItem( 'addToBag', addToBag );
    }
    catch ( e ){
      console.error( 'Error: Saving to storage.' );// eslint-disable-line
    }
  }
  else {
    console.error( 'Sorry, your browser doesn\'t support session storage.' );// eslint-disable-line
  }
}

export const retrieveExternalAddInput = () => {
  return sessionStorage.getItem( 'addToBag' );
}

export const removeExternalAddInput = () => {
  return sessionStorage.removeItem( 'addToBag' );
}
/** *
 * In order to handle salon login event for MWEB ,
 fireReflektionLoginEvent used as a session storage variable added via jsp side ,
 from react side inorde to fire the login event it checks for the existance of this variable
*/

export const retrieveReflektionLoginEvent = () => {
  return sessionStorage.getItem( 'fireReflektionLoginEvent' );
}
// Remove the flag after the login event fire
export const removeReflektionLoginEvent = () => {
  return sessionStorage.removeItem( 'fireReflektionLoginEvent' );
}

// Retrieve the filter store information from session
export const retrieveFilterStores = () => {
  return Cookies.getJSON( 'filterStores' );
}
// Persist the filter store information to session
export const persistFilterStores = ( filterStores ) => {
  return Cookies.set( 'filterStores', filterStores );
}

// Persist the user searched input and lat/long information from Find In Store Modal
export const persistFindInStoreData = ( searchResultData ) => {
  // JSON.stringify is required here as the function reading from localStorage is using JSON.parse else it will not work
  localStorage.setItem( 'findInStoreSearchData', JSON.stringify( searchResultData ) );
}

// Retrieve the user searched input and lat/long information from Find In Store Modal
export const retrieveFindInStoreData = () => {
  return JSON.parse( localStorage.getItem( 'findInStoreSearchData' ) );
}

// Remove the cached Find In Store data
export const removeFindInStoreData = () => {
  return localStorage.removeItem( 'findInStoreSearchData' );
}

// Persist the user searched input and lat/long information from Find In Store Modal
export const saveAuthSuccessUrlDetails = ( authSuccessUrlDetails ) => {
  // JSON.stringify is required here as the function reading from localStorage is using JSON.parse else it will not work
  localStorage.setItem( 'authSuccessUrlDetails', JSON.stringify( authSuccessUrlDetails ) );
}

// Retrieve the user searched input and lat/long information from Find In Store Modal
export const retrieveAuthSuccessUrlDetails = () => {
  return JSON.parse( localStorage.getItem( 'authSuccessUrlDetails' ) || '{}' );
}

// Remove the cached Find In Store data
export const removeAuthSuccessUrlDetails = () => {
  return localStorage.removeItem( 'authSuccessUrlDetails' );
}



// save the signSignedIn flag value in local storage. this will be used by the signal code for analytics
export const saveStaySignedInFlagForAnalytics = ( staySignedIn ) => {
  localStorage.setItem( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, staySignedIn );
}

// Remove the signSignedIn flag
export const removeStaySignedInFlagForAnalytics = () => {
  localStorage.removeItem( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG );
}

export const persistPickupSmsInfo = ( smsInfo ) => {
  // JSON.stringify is required here as the function reading from localStorage is using JSON.parse else it will not work
  sessionStorage.setItem( appConstants.LOCAL_STORAGE.PICKUP_SMS_INFO, JSON.stringify( smsInfo ) );
}

export const retrievePickupSmsInfo = () => {
  return JSON.parse( sessionStorage.getItem( appConstants.LOCAL_STORAGE.PICKUP_SMS_INFO ) );
}

export const removePickupSmsInfo = () => {
  return sessionStorage.removeItem( appConstants.LOCAL_STORAGE.PICKUP_SMS_INFO );
}
