import Cookies from 'js-cookie';
import domain from '../domain/domain';
import {
  loadState, saveState, persistSearchDataForAnalytics,
  persistExternalAddInput, retrieveExternalAddInput,
  removeExternalAddInput, retrieveReflektionLoginEvent,
  removeReflektionLoginEvent, persistDataForTopResultsClick,
  persistDataOnViewAllResultClick, removeSearchData,
  retrieveViewAllResultFlag, retrieveProductIndex,
  retrieveVisualTerm, retrieveSearchTerm,
  retrieveSelectedTerm,
  retrieveFilterStores,
  persistFilterStores,
  persistFindInStoreData,
  retrieveFindInStoreData,
  removeFindInStoreData,
  saveAuthSuccessUrlDetails,
  retrieveAuthSuccessUrlDetails,
  removeAuthSuccessUrlDetails,
  saveStaySignedInFlagForAnalytics,
  removeStaySignedInFlagForAnalytics,
  persistPickupSmsInfo,
  retrievePickupSmsInfo,
  removePickupSmsInfo
} from './local_storage';
import appConstants from '../../shared/appConstants';

jest.mock( 'js-cookie', () => {
  return {
    get: jest.fn( ( ) => null ),
    set: jest.fn( )
  }
} );
jest.mock( '../domain/domain', () => {
  return {
    isSecurePage: jest.fn( () => false )
  }
} );

let originalSessionStorage;
let originalLocalStorage;
beforeAll( () => {
  originalSessionStorage = window.sessionStorage;
  originalLocalStorage = window.localStorage;
  delete window.sessionStorage;
  delete window.localStorage;
  Object.defineProperty( window, 'sessionStorage', {
    writable: true,
    value: {
      getItem: jest.fn( () => '{}' ).mockName( 'getItem' ),
      setItem: jest.fn().mockName( 'setItem' ),
      removeItem: jest.fn().mockName( 'removeItem' )
    }
  } );
  Object.defineProperty( window, 'localStorage', {
    writable: true,
    value: {
      getItem: jest.fn( () => '{}' ).mockName( 'getItem' ),
      setItem: jest.fn().mockName( 'setItem' ),
      removeItem: jest.fn().mockName( 'removeItem' )
    }
  } );
} );

beforeEach( () => {
  sessionStorage.getItem.mockClear();
  sessionStorage.setItem.mockClear();
  sessionStorage.removeItem.mockClear();
  localStorage.getItem.mockClear();
  localStorage.setItem.mockClear();
  localStorage.removeItem.mockClear();
} );

afterAll( () => {
  Object.defineProperty( window, 'sessionStorage', { writable: true, value: originalSessionStorage } );
  Object.defineProperty( window, 'localStorage', { writable: true, value: originalLocalStorage } );
} );

describe( 'LocalStorage', () => {

  it( 'loadState from Cookies : should get undefined if persistedState is null ', () => {
    const session = loadState();
    expect( session ).toBeUndefined();
  } );

  it( 'loadState from Cookies : should get sessionObj if persistedState is not null ', () => {
    Cookies.get = jest.fn( () => {
      return JSON.stringify( {
        a: true,
        s: '1234324243',
        u: '123',
        sfd: true
      } )
    } );

    const expectedState = {
      esu:{
        stickyEmailSignUp:{
          sessionData:{
            isStickyFooterDisplay:true
          }
        }
      },
      session:{
        activeSession: false,
        secureToken: '1234324243',
        unsecureToken: '123'
      }
    }
    const session = loadState();
    expect( session ).toEqual( expectedState )
  } );

  it( 'loadState from serverState  if persistedState is not null ', () => {
    Cookies.get = jest.fn( () => {
      return undefined;
    } );

    let containerElement = document.createElement( 'div' );
    containerElement.id = 'js-pageContainer';
    document.body.appendChild( containerElement );

    let appElement = document.createElement( 'div' );
    appElement.id = 'js_reduxstore';
    containerElement.appendChild( appElement );

    const serverState = {
      productPage:{
        productDetails:{
          id:'123'
        }
      }
    }

    window.__PRELOADED_STATE__ = serverState;

    const session = loadState();
    expect( session ).toEqual( serverState )
  } );

  it( 'loadState from Cookies : should handle the server loaded state data and remove the state data from the server ', () => {
    Cookies.get = jest.fn( () => {
      return JSON.stringify( {
        a: true,
        s: '1234324243',
        u: '123',
        sfd: true
      } )
    } );

    let containerElement = document.createElement( 'div' );
    containerElement.id = 'js-pageContainer';
    document.body.appendChild( containerElement );

    let appElement = document.createElement( 'div' );
    appElement.id = 'js_reduxstore';
    containerElement.appendChild( appElement );
    containerElement.removeChild = jest.fn();
    window.__PRELOADED_STATE__ = {};
    const session = loadState();

    expect( containerElement.removeChild ).toHaveBeenCalled( );
    expect( session ).toBeDefined();
  } );

  it( 'saveState to Cookies', () => {
    const state = {
      session: {
        activeSession: true,
        secureToken: '1234324243',
        unsecureToken: '123'
      },
      emailSignUp: { isStickyFooterDisplay: true },
      searchInputValue: 'armani'
    }
    const cookieSetMock = jest.fn(); //eslint-disable-line
    Cookies.set = cookieSetMock;
    saveState( state );
    expect( cookieSetMock ).toBeCalled();
  } );

  describe( 'SessionStorage', () => {
    const state = {
      session: {
        activeSession: true,
        secureToken: '1234324243',
        unsecureToken: '123'
      },
      emailSignUp: { isStickyFooterDisplay: true },
      searchInputValue: 'armani',
      selectedTerm:'makeUp>lipstick',
      addToBag: '2242016',
      productIndex:'1',
      visualTerm:'Conditioner',
      viewAllResultFlag:'true'
    }

    it( 'save to sessionStorage - If selectedTerm is not present then searchTerm value should be set to false ', () => {
      const setSearchAutoSuggestSpy = jest.spyOn( window.sessionStorage, 'setItem' );
      const setSearchTermSpy = jest.spyOn( window.sessionStorage, 'setItem' );

      persistSearchDataForAnalytics( state.searchInputValue );
      expect( setSearchAutoSuggestSpy ).toHaveBeenCalledWith( 'searchAutoSuggest', JSON.stringify( 'false' ) );
      expect( setSearchTermSpy ).toHaveBeenCalledWith( 'searchTerm', JSON.stringify( state.searchInputValue ) );
    } );

    it( 'save selectedTerm to sessionStorage ', () => {
      const setSearchAutoSuggestSpy = jest.spyOn( window.sessionStorage, 'setItem' );
      const setSelectedTermSpy = jest.spyOn( window.sessionStorage, 'setItem' );

      persistSearchDataForAnalytics( state.searchInputValue, state.selectedTerm );
      expect( setSearchAutoSuggestSpy ).toHaveBeenCalledWith( 'searchAutoSuggest', JSON.stringify( 'true' ) );
      expect( setSelectedTermSpy ).toHaveBeenCalledWith( 'selectedTerm', JSON.stringify( state.selectedTerm.toLowerCase() ) );
    } );
    it( 'save productIndex and visualTerm to sessionStorage ', () => {
      const setProductIndexSpy = jest.spyOn( window.sessionStorage, 'setItem' );
      const setVisualTermSpy = jest.spyOn( window.sessionStorage, 'setItem' );
      const setSearchTermSpy = jest.spyOn( window.sessionStorage, 'setItem' );

      persistDataForTopResultsClick( state.productIndex, state.visualTerm, state.searchInputValue );
      expect( setProductIndexSpy ).toHaveBeenCalledWith( 'productIndex', JSON.stringify( state.productIndex ) );
      expect( setVisualTermSpy ).toHaveBeenCalledWith( 'visualTerm', JSON.stringify( state.visualTerm.toLowerCase() ) );
      expect( setSearchTermSpy ).toHaveBeenCalledWith( 'searchTerm', JSON.stringify( state.searchInputValue ) );
    } );
    it( 'save visualTerm and viewAllResultFlag to sessionStorage ', () => {
      const setViewAllResultFlagSpy = jest.spyOn( window.sessionStorage, 'setItem' );
      const setVisualTermSpy = jest.spyOn( window.sessionStorage, 'setItem' );
      const setSearchTermSpy = jest.spyOn( window.sessionStorage, 'setItem' );

      persistDataOnViewAllResultClick( state.visualTerm, state.searchInputValue );
      expect( setViewAllResultFlagSpy ).toHaveBeenCalledWith( 'viewAllResultFlag', JSON.stringify( 'true' ) );
      expect( setVisualTermSpy ).toHaveBeenCalledWith( 'visualTerm', JSON.stringify( state.visualTerm.toLowerCase() ) );
      expect( setSearchTermSpy ).toHaveBeenCalledWith( 'searchTerm', JSON.stringify( state.searchInputValue ) );
    } );

    it( 'save addToBag to sessionStorage ', () => {
      const setAddToBagSpy = jest.spyOn( window.sessionStorage, 'setItem' );
      persistExternalAddInput( state.addToBag );
      expect( setAddToBagSpy ).toHaveBeenCalledWith( 'addToBag', state.addToBag );
    } );

    it( 'retrieve addToBag from sessionStorage ', () => {
      const getAddToBagSpy = jest.spyOn( window.sessionStorage, 'getItem' );
      retrieveExternalAddInput();
      expect( getAddToBagSpy ).toHaveBeenCalledWith( 'addToBag' );
    } );

    it( 'remove addToBag from sessionStorage ', () => {
      const removeAddToBagSpy = jest.spyOn( window.sessionStorage, 'removeItem' );
      removeExternalAddInput();
      expect( removeAddToBagSpy ).toHaveBeenCalledWith( 'addToBag' );
    } );
    it( 'retrieve viewAllResultFlag from sessionStorage ', () => {
      const getViewAllResultFlagSpy = jest.spyOn( window.sessionStorage, 'getItem' );
      // global.JSON.parse = jest.fn()
      const a = retrieveViewAllResultFlag();
      expect( getViewAllResultFlagSpy ).toHaveBeenCalledWith( 'viewAllResultFlag' );
    } );
    it( 'retrieve productIndex from sessionStorage ', () => {
      const getProductIndexSpy = jest.spyOn( window.sessionStorage, 'getItem' );
      retrieveProductIndex();
      expect( getProductIndexSpy ).toHaveBeenCalledWith( 'productIndex' );
    } );
    it( 'retrieve visualTerm from sessionStorage ', () => {
      const getVisualTermSpy = jest.spyOn( window.sessionStorage, 'getItem' );
      retrieveVisualTerm();
      expect( getVisualTermSpy ).toHaveBeenCalledWith( 'visualTerm' );
    } );
    it( 'retrieve searchTerm from sessionStorage ', () => {
      const getSearchTermSpy = jest.spyOn( window.sessionStorage, 'getItem' );
      retrieveSearchTerm();
      expect( getSearchTermSpy ).toHaveBeenCalledWith( 'searchTerm' );
    } );
    it( 'retrieve selectedTerm from sessionStorage ', () => {
      const getSelectedTermSpy = jest.spyOn( window.sessionStorage, 'getItem' );
      retrieveSelectedTerm();
      expect( getSelectedTermSpy ).toHaveBeenCalledWith( 'selectedTerm' );
    } );
    it( 'remove all the searchrelated datas from sessionStorage ', () => {
      const removeViewAllResultFlagSpy = jest.spyOn( window.sessionStorage, 'removeItem' );
      const removeProductIndexSpy = jest.spyOn( window.sessionStorage, 'removeItem' );
      const removeVisualTermSpy = jest.spyOn( window.sessionStorage, 'removeItem' );
      const removeSearchTermSpy = jest.spyOn( window.sessionStorage, 'removeItem' );
      const removeSearchAutoSuggestSpy = jest.spyOn( window.sessionStorage, 'removeItem' );

      removeSearchData();
      expect( removeViewAllResultFlagSpy ).toHaveBeenCalledWith( 'viewAllResultFlag' );
      expect( removeProductIndexSpy ).toHaveBeenCalledWith( 'productIndex' );
      expect( removeVisualTermSpy ).toHaveBeenCalledWith( 'visualTerm' );
      expect( removeSearchTermSpy ).toHaveBeenCalledWith( 'searchTerm' );
      expect( removeSearchAutoSuggestSpy ).toHaveBeenCalledWith( 'searchAutoSuggest' );
    } );

    it( 'retrieve fireReflektionLoginEvent from sessionStorage ', () => {
      const getFireReflektionLoginEventSpy = jest.spyOn( window.sessionStorage, 'getItem' );
      retrieveReflektionLoginEvent();
      expect( getFireReflektionLoginEventSpy ).toHaveBeenCalledWith( 'fireReflektionLoginEvent' );
    } );

    it( 'remove fireReflektionLoginEvent from sessionStorage ', () => {
      const removeReflektionLoginEventSpy = jest.spyOn( window.sessionStorage, 'removeItem' );
      removeReflektionLoginEvent();
      expect( removeReflektionLoginEventSpy ).toHaveBeenCalledWith( 'fireReflektionLoginEvent' );
    } );

  } );

  describe( 'Save Filter Store in cookie', ()=> {

    it( 'load filterStores from Cookies ', () => {
      const cookieGetMock = jest.fn();
      Cookies.getJSON = cookieGetMock;
      const session = retrieveFilterStores();
      expect( cookieGetMock ).toHaveBeenCalledWith( 'filterStores' );
    } );

    it( 'save filterStore value to Cookies', () => {
      const filterStores = true
      const cookieSetMock = jest.fn();
      Cookies.set = cookieSetMock;
      persistFilterStores( filterStores );
      expect( cookieSetMock ).toHaveBeenCalledWith( 'filterStores', true )
    } );

  } )

  describe( 'LocalStorage find In Store Data', () => {
    const state = {
      cachedData: {
        isLocationBlocked: false,
        latitude: 121,
        longitude: 123,
        searchValue: 60603
      },
      authSuccessUrlDetails: 'testUrl'
    }
    it( 'save to localStorage - If cachedData is set ', () => {
      const setPersistFindInStoreDataSpy = jest.spyOn( window.localStorage, 'setItem' );
      persistFindInStoreData( state.cachedData );
      expect( setPersistFindInStoreDataSpy ).toHaveBeenCalledWith( 'findInStoreSearchData', JSON.stringify( state.cachedData ) );
    } );

    it( 'remove from localStorage - If the remove function is called', () => {
      const removeFindInStoreDataSpy = jest.spyOn( window.localStorage, 'removeItem' );
      removeFindInStoreData();
      expect( removeFindInStoreDataSpy ).toHaveBeenCalledWith( 'findInStoreSearchData' );
    } );

    it( 'retrieve findInStoreSearchData from localStorage ', () => {
      const getFindInStoreDataSpy = jest.spyOn( window.localStorage, 'getItem' );
      retrieveFindInStoreData();
      expect( getFindInStoreDataSpy ).toHaveBeenCalledWith( 'findInStoreSearchData' );
    } );

    it( 'save to localStorage - save auth success url details', () => {
      const setAuthSuccessUrlDetailSpy = jest.spyOn( window.localStorage, 'setItem' );
      saveAuthSuccessUrlDetails( state.authSuccessUrlDetails );
      expect( setAuthSuccessUrlDetailSpy ).toHaveBeenCalledWith( 'authSuccessUrlDetails', JSON.stringify( state.authSuccessUrlDetails ) );
    } );

    it( 'retrieve the user searched input from local storage ', () => {
      const getAuthSuccessUrlDetailSpy = jest.spyOn( window.localStorage, 'getItem' );
      retrieveAuthSuccessUrlDetails();
      expect( getAuthSuccessUrlDetailSpy ).toHaveBeenCalledWith( 'authSuccessUrlDetails' );
    } );

    it( 'remove from localStorage - remove the auth Success url details ', () => {
      const removeAuthSuccessUrlDetailSpy = jest.spyOn( window.localStorage, 'removeItem' );
      removeAuthSuccessUrlDetails();
      expect( removeAuthSuccessUrlDetailSpy ).toHaveBeenCalledWith( 'authSuccessUrlDetails' );
    } );

  } );

  describe( 'transactional Text details', () => {
    const state = {
      pickupSmsInfo:{
        optInStatus: true,
        mobileNumber: '(888) 333-0000'
      }
    }

    it( 'save to session storage - User entered optInStatus and mobileNumber', () => {
      const setPickUpInfoSpy = jest.spyOn( window.sessionStorage, 'setItem' );
      persistPickupSmsInfo( state.pickupSmsInfo );
      expect( setPickUpInfoSpy ).toHaveBeenCalledWith( 'pickupSmsInfo', JSON.stringify( state.pickupSmsInfo ) );
    } );

    it( 'retrieve the user entered optInStatus and mobileNumber from localStorage ', () => {
      const getPickUpInfoSpy = jest.spyOn( window.sessionStorage, 'getItem' );
      retrievePickupSmsInfo( );
      expect( getPickUpInfoSpy ).toHaveBeenCalledWith( appConstants.LOCAL_STORAGE.PICKUP_SMS_INFO );
    } );

    it( 'remove from sessionStorage - remove the transactional SMS details ', () => {
      const removePickUpInfoSpy = jest.spyOn( window.sessionStorage, 'removeItem' );
      removePickupSmsInfo();
      expect( removePickUpInfoSpy ).toHaveBeenCalledWith( appConstants.LOCAL_STORAGE.PICKUP_SMS_INFO );
    } );

  } );

  describe( 'saveStaySignedInFlagForAnalytics function', () => {
    it( 'should set staySignedInFlag key to localStorage', () => {
      const setStaySignedInFlagSpy = jest.spyOn( window.localStorage, 'setItem' );
      const staySignedIn = true;
      saveStaySignedInFlagForAnalytics( staySignedIn );
      expect( setStaySignedInFlagSpy ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, staySignedIn );
    } );
  } );

  describe( 'removeStaySignedInFlagForAnalytics function', () => {
    it( 'should remove staySignedInFlag key from localStorage', () => {
      const removeStaySignedInFlagSpy = jest.spyOn( window.localStorage, 'removeItem' );
      removeStaySignedInFlagForAnalytics();
      expect( removeStaySignedInFlagSpy ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG );
    } );
  } );

} );
