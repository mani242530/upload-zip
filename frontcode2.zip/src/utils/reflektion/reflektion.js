import Cookies from 'js-cookie';

// this checks if global.rfk is defined, which indicates the reflektion script was initialized
// the method gets executed every 100 ms until global.rfk is available, at which it does a clearInterval
// it then invokes triggerEvents method which triggers any events which were stored in the queue waiting for global.rfk to be initialized
const listenReflektionLoad = () => {
  let initalizeReflektion = setInterval( () => {

    if( global.rfk ){
      clearInterval( initalizeReflektion );
      reflektion.triggerEvents();
    }
  }, 100 ); // check every 100ms
}

// this method will push the event to the reflektionEventsQueue and if
// global.rfk is alread defined will invoke triggerEvents to fire the events
// if global.rfk is not defined, it will not do anything, leaving the events in the queue waiting it to be fired when reflektion is initialized
const triggerEvent = ( data )=>{
  const category = 'trackEvent';
  reflektion.reflektionEventsQueue.push( { category, data } ) ;
  if( global.rfk ){
    reflektion.triggerEvents();
  }
}

const triggerEvents = ()=>{
  let event = reflektion.reflektionEventsQueue.shift();
  while ( event ){

    global.rfk.push( [event.category, event.data] );
    event = reflektion.reflektionEventsQueue.shift();
  }
}

const retrieveReflektionTrackingId = ()=>{
  return Cookies.get( '__ruid' );
}

const reflektion = {
  reflektionEventsQueue:[],
  triggerEvent,
  triggerEvents,
  listenReflektionLoad,
  retrieveReflektionTrackingId
}

// This function provides the ability to trigger the reflektion event from the dotcom/external code base
window.dispatchReflektionEvent = ( reflektionData ) => {
  reflektion.triggerEvent( reflektionData ) ;
}

export default reflektion;