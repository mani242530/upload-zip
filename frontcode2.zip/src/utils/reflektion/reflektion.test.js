import Cookies from 'js-cookie';
import reflektion from './reflektion'
describe( 'Reflektion  Utility method testing', () => {
  const {
    triggerEvent,
    triggerEvents
  } = reflektion ;

  it( 'should invoke global.rfk.push on the events in the queue when triggerEvents is invoked', () => {
    global.rfk = {
      push:jest.fn()
    }
    const event = { category:'trackEvent', data:{ 'type':'a2c', 'name':'home', 'value':{ 'products':[{ 'sku':'1012086' }] } } } ;
    const event1 = { category:'trackEvent', data:{ 'type':'a2c', 'name':'home', 'value':{ 'products':[{ 'sku':'1012086' }] } } } ;
    reflektion.reflektionEventsQueue = [];
    reflektion.reflektionEventsQueue.push( event );
    reflektion.reflektionEventsQueue.push( event1 );
    triggerEvents();
    expect( global.rfk.push ).toHaveBeenCalledTimes( 2 );
    expect( global.rfk.push ).toBeCalledWith( [event.category, event.data] );
    expect( global.rfk.push ).toBeCalledWith( [event1.category, event1.data] );
  } );

  it( 'should invoke triggerEvents if global.rfk is defined', () => {
    global.rfk = {
      push:jest.fn()
    }
    reflektion.triggerEvents = jest.fn();
    const data = { 'type':'a2c', 'name':'home', 'value':{ 'products':[{ 'sku':'1012086' }] } } ;
    const category = 'trackEvent';
    triggerEvent( data );
    expect( reflektion.reflektionEventsQueue[ 0 ] ).toEqual( { category, data } );
    expect( reflektion.triggerEvents ).toBeCalled();
  } );

  it( 'should not invoke triggerEvents if global.rfk is not defined', () => {
    global.rfk = undefined;
    reflektion.triggerEvents = jest.fn();
    const data = { 'type':'a2c', 'name':'home', 'value':{ 'products':[{ 'sku':'1012086' }] } } ;
    const category = 'trackEvent';
    triggerEvent( data );
    expect( reflektion.reflektionEventsQueue[ 0 ] ).toEqual( { category, data } );
    expect( reflektion.triggerEvents ).not.toBeCalled();
  } );

  it( 'should invoke triggerEvents when global.rfk is initialized', () => {
    jest.useFakeTimers( );
    global.rfk = undefined;
    reflektion.triggerEvents = jest.fn();
    reflektion.listenReflektionLoad();
    expect( reflektion.triggerEvents ).not.toBeCalled();
    global.rfk = {};
    jest.runAllTimers();
    expect( reflektion.triggerEvents ).toBeCalled();
  } );


  it( 'retrieve retrieveReflektionTrackingId from cookies ', () => {
    const getCookieMock = jest.fn( () => {
      return '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986'
    } );
    Cookies.get = getCookieMock;
    const id = reflektion.retrieveReflektionTrackingId();
    expect( id ).toEqual( '168695269-uk-2v-4t-1p-p10x5r8kl4v2im1l50wn-1541414192986' );
  } );


  it( 'should invoke  triggerEvent when dispatchReflektionEvent is invoked', () => {
    const triggerEventMock = jest.fn();
    reflektion.triggerEvent = triggerEventMock;
    const evt = { name: 'testEvent' };
    dispatchReflektionEvent( evt );
    expect( triggerEventMock ).toHaveBeenCalledWith( evt );
  } );

} );
