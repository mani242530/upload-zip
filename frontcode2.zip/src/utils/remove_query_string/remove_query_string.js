import getHistory from '../history/history';

const history = getHistory();

const {
  pathname,
  search
} = history.location;

// removeQueryString method will remove the required query string from url without refreshing the page
export const removeQueryString = ( data ) =>{
  // queryParams will be initialize with empty array if data is undefined
  let queryParams = data || [];
  // if no query param array is passed, then remove all the query params from url
  if( queryParams.length === 0 ){
    let originalUrl = pathname + search;
    originalUrl = originalUrl.replace( search, '' );
    history.replace( originalUrl );
    return originalUrl;
  }
  // if query params array is passed, then remove only the specific query params from url
  else {
    let modifiedSearch = history.location.search;
    let removeQuery;
    let removeQueryValue;

    for ( let queryParam of queryParams ){
      // removeQueryValue will be assigned with the value of query param to be removed
      removeQueryValue = getValueByQueryName( queryParam );
      removeQuery = queryParam + '=' + removeQueryValue;

      if( modifiedSearch.indexOf( '?' + removeQuery + '&' ) !== -1 ){
        modifiedSearch = modifiedSearch.replace( '?' + removeQuery + '&', '?' );
      }
      else if( modifiedSearch.indexOf( '&' + removeQuery + '&' ) !== -1 ){
        modifiedSearch = modifiedSearch.replace( '&' + removeQuery + '&', '&' );
      }
      else if( modifiedSearch.indexOf( '?' + removeQuery ) !== -1 ){
        modifiedSearch = modifiedSearch.replace( '?' + removeQuery, '' );
      }
      else if( modifiedSearch.indexOf( '&' + removeQuery ) !== -1 ){
        modifiedSearch = modifiedSearch.replace( '&' + removeQuery, '' );
      }
    }

    const modifiedUrl = history.location.pathname + modifiedSearch;
    history.replace( modifiedUrl );
    return modifiedUrl;
  }
}

// getValueByQueryName method will return the value of valid param present in url
// if invalid param is passed, it will retun null
export const getValueByQueryName = ( param ) =>{
  param.replace( /[\[]/, '\\[' ).replace( /[\]]/, '\\]' );
  var regex = new RegExp( '[\\?&]' + param + '=([^&#]*)' ),
      queryValue = regex.exec( search );

  return queryValue === null ? '' : decodeURIComponent( queryValue[1].split( '=' )[0] );
}

export default removeQueryString;