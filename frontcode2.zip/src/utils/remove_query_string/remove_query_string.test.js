
import getHistory from '../history/history';
import removeQueryString, { getValueByQueryName } from './remove_query_string';

jest.mock( '../history/history', () => {
  return jest.fn( () => {
    return {
      location:{
        pathname:'/checkout',
        search: '?status=true&orderToken=testToken&testData=testdata'
      },
      replace: jest.fn()
    };
  } )
} );

describe( 'removeQueryString', () => {

  it( 'should return url removing all search params if no param array is passed', () => {
    expect( removeQueryString() ).toBe( '/checkout' );
  } );

  it( 'should return url removing a single search param which is passed as param array', () => {
    const params = ['status'];
    expect( removeQueryString( params ) ).toBe( '/checkout?orderToken=testToken&testData=testdata' );
  } );

  it( 'should return url removing search params which are passed as param array', () => {
    const params = ['testData', 'orderToken'];
    expect( removeQueryString( params ) ).toBe( '/checkout?status=true' );
  } );

  describe( 'getValueByQueryName', () => {
    getHistory.mockClear();
    it( 'should return param value if valid param is passed', () => {
      expect( getValueByQueryName( 'status' ) ).toBe( 'true' );
      expect( getValueByQueryName( 'orderToken' ) ).toBe( 'testToken' );
      expect( getValueByQueryName( 'testData' ) ).toBe( 'testdata' );
    } );
    it( 'should return empty string if invalid param is passed', () => {
      expect( getValueByQueryName( 'test' ) ).toBe( '' );
    } );
  } )
} )
