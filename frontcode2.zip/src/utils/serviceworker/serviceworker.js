
if( 'serviceWorker' in navigator ){
  window.addEventListener( 'load', () => {

    // TODO the path to the service workeer needs to change based on prod or development
    // TODO figure out where int eh wrold the sw file is pushed in teh dev environment

    navigator.serviceWorker.register( `/service_workers/UltaSW__DEV.js` ).then( registration => {
      console.log( 'SW registered: ', registration ); //eslint-disable-line
    } ).catch( registrationError => {
      console.log( 'SW registration failed: ', registrationError ); //eslint-disable-line
    } );
  } );
}
