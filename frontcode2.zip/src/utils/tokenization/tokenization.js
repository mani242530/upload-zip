import flex from '@cybersource/flex-sdk-web';

// resolve response when success event
// error response will get as part of success response
export const getTokenSuccess = ( resolve ) => {
  return function( response ){
    if( response.error ){
      resolve( undefined );
    }
    else {
      resolve( response );
    }
  }
}

// set default values
export const defaultTokenConfig = {
  paymentsCCToken: {
    kid: null,
    e: 'AQAB',
    kty: 'RSA',
    use: 'enc'
  },
  cardInfoData: null,
  creditCardTokenForProduction: false
};

// Function used to generate the token from cybersource
// Pass card info & token key to generate maskpan & reference id
export const getTokenization = ( tokenConfig = defaultTokenConfig, successMethod = getTokenSuccess ) => {

  let conf = {
    ...defaultTokenConfig,
    ...tokenConfig
  };

  const {
    paymentsCCToken,
    cardInfoData,
    creditCardTokenForProduction
  } = conf;

  return new Promise( ( resolve ) => {
    let options = {
      kid: paymentsCCToken.kid,
      keystore: paymentsCCToken,
      encryptionType: 'RSAOaep',
      production: creditCardTokenForProduction || false,
      cardInfo: cardInfoData
    };

    // cybersource flex call to create token
    flex.createToken( options, successMethod( resolve ) );
  } );

}