import '@babel/polyfill';
import isFunction from 'lodash/isFunction';
import flex from '@cybersource/flex-sdk-web';
import {
  getTokenization,
  getTokenSuccess,
  defaultTokenConfig
} from './Tokenization';

describe( 'Tokenization test', () => {

  const responseSuccess = {
    maskedPan: '411111XXXXXX1111',
    creditCardToken: '4893749357731111'
  }

  const responseFailure = {
    error: {
      status: 400,
      message: 'Cannot find private RSA key with keyId',
      reason: 'VALIDATION_ERROR'
    }
  }

  let successMethodMock = jest.fn( () => Promise.resolve( responseSuccess ) );
  let failureMethodMock = jest.fn( () => Promise.resolve( undefined ) );

  it( 'should check if the functions getTokenization, getTokenSuccess is defined.', () => {
    expect( isFunction( getTokenization ) ).toBe( true );
    expect( isFunction( getTokenSuccess ) ).toBe( true );
  } );

  it( 'should call el with responseSuccess object that passed to getTokenSuccess function', () => {
    getTokenSuccess( ( el ) => {
      expect( el ).toEqual( responseSuccess );
    } )( responseSuccess );
  } );

  it( 'should call el with responseFailure object that passed to getTokenSuccess function', () => {
    getTokenSuccess( ( el ) => {
      expect( el ).toBeUndefined();
    } )( responseFailure );
  } );

  it( 'should check if the cybersource createToken function is called', () => {
    flex.createToken = jest.fn();
    getTokenization();
    expect( flex.createToken ).toBeCalled( );
  } );

  it( 'should check the default options that passed to getTokenSuccess function', () => {
    flex.createToken = jest.fn();
    getTokenization( defaultTokenConfig, successMethodMock );
    let expectOptionObject = {
      kid: defaultTokenConfig.paymentsCCToken.kid,
      keystore: defaultTokenConfig.paymentsCCToken,
      encryptionType: 'RSAOaep',
      production: defaultTokenConfig.creditCardTokenForProduction,
      cardInfo: defaultTokenConfig.cardInfoData
    };

    expect( flex.createToken.mock.calls[0][0] ).toEqual( expectOptionObject );
  } );

  it( 'should call the getTokenSuccess with success response when the promise resolves with a token value', async() => {

    flex.createToken = jest.fn();
    let tokenConfig = {
      paymentsCCToken: {
        e: 'AQAB',
        kid: '08M9NlqxHqAn1ytE2aqgfjrynHUB6Yw5',
        kty: 'RSA',
        n: 'tev92CxyXVx7yHr_ICaQoGtp7icbPG-az9rg3Zk-',
        use: 'enc'
      },
      cardInfoData: {
        cardNumber: '4111111111111111',
        cardType: '001',
        expiryMonth: '12',
        expiryYear: '2022'
      },
      creditCardTokenForProduction: false
    };

    let expectOptionObject = {
      kid: tokenConfig.paymentsCCToken.kid,
      keystore: tokenConfig.paymentsCCToken,
      encryptionType: 'RSAOaep',
      production: tokenConfig.creditCardTokenForProduction,
      cardInfo: tokenConfig.cardInfoData
    };

    getTokenization( tokenConfig, successMethodMock );
    expect( flex.createToken.mock.calls[0][0] ).toEqual( expectOptionObject );
    return expect( flex.createToken.mock.calls[0][1] ).resolves.toEqual( responseSuccess );

  } );

  it( 'should call the getTokenSuccess with failure response when the promise resolves with a undefined value', async() => {

    flex.createToken = jest.fn();
    getTokenization( defaultTokenConfig, failureMethodMock );
    return expect( flex.createToken.mock.calls[0][1] ).resolves.toBeUndefined();

  } );

} );