
import appConstants from '../../shared/appConstants';

// user data ------------------------------------------------------------------ start
export const saveUserData = ( key, value ) => {
  const saveValue = typeof value === 'object' ? JSON.stringify( value ) : value;
  localStorage.setItem( key, saveValue );
}

export const removeUserData = ( key ) => {
  localStorage.removeItem( key );
}

export const getUserData = ( key ) => {
  const value = localStorage.getItem( key );
  let returnValue = value;

  if( typeof value === 'string' && value.charAt( 0 ) === '{' && value.charAt( value.length - 1 ) === '}' ){
    returnValue = JSON.parse( value );
  }

  return returnValue;
}
// user data ------------------------------------------------------------------ end

// user session data ---------------------------------------------------------- start
export const saveUserSessionData = ( key, value ) => {
  const sessionData =  JSON.parse( localStorage.getItem( appConstants.SESSION_DATA ) );
  sessionData[ key ] = value;
  localStorage.setItem( appConstants.SESSION_DATA, JSON.stringify( sessionData ) );
}

export const removeUserSessionData = ( key ) => {
  const sessionData = JSON.parse( localStorage.getItem( appConstants.SESSION_DATA ) );
  delete sessionData[ key ];
  localStorage.setItem( appConstants.SESSION_DATA, JSON.stringify( sessionData ) );
}

export const getUserSessionData = ( key ) => {
  const sessionData = JSON.parse( localStorage.getItem( appConstants.SESSION_DATA ) );
  return sessionData[ key ];
}

// This function provides the ability to retrieve session data from JSP
window.GET_USER_SESSION_DATA = getUserSessionData ;

// This function provides the ability to retrieve user data from JSP
window.GET_USER_DATA = getUserData ;


// user session data ---------------------------------------------------------- end