import {
  saveUserData,
  removeUserData,
  getUserData,
  saveUserSessionData,
  getUserSessionData,
  removeUserSessionData
} from './user_storage';
import appConstants from '../../shared/appConstants';

const setItemSpy = jest.spyOn( Storage.prototype, 'setItem' );
const getItemSpy = jest.spyOn( Storage.prototype, 'getItem' );
const removeItemSpy = jest.spyOn( Storage.prototype, 'removeItem' );
const sessionData = { 'pid': '1234' };


describe( 'LocalStorage', () => {
  describe( 'user data functions', () => {
    it( 'should set passed params key, value to localStorage - value type', () => {
      const staySignedIn = true;
      saveUserData( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, staySignedIn );
      expect( setItemSpy ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG, staySignedIn );
    } );

    it( 'should get value for passed param key from localStorage - value type', () => {
      const localStorageVal = getUserData( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG );
      expect( localStorageVal ).toBe( 'true' );
      expect( getItemSpy ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG );
    } );

    it( 'should set passed params key, value to localStorage  - JSON type', () => {
      saveUserData( appConstants.SESSION_DATA, sessionData );
      expect( setItemSpy ).toHaveBeenCalledWith( appConstants.SESSION_DATA, JSON.stringify( sessionData ) );
    } );

    it( 'should get value for passed param key from localStorage - JSON type', () => {
      const localStorageVal = getUserData( appConstants.SESSION_DATA );
      expect( localStorageVal ).toEqual( sessionData );
      expect( getItemSpy ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG );
    } );

    it( 'should remove passed param key from localStorage', () => {
      removeUserData( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG );
      expect( removeItemSpy ).toHaveBeenCalledWith( appConstants.ANALYTICS.STAY_SIGNEDIN_FLAG );
    } );

  } );

  describe( 'user session data functions', () => {
    it( 'should set passed params key, value to localStorage with sessionData as key', () => {

      saveUserData( appConstants.SESSION_DATA, {} ); // to clear earlier data set in above test cases
      const expecteOutput = { pickupUnavailableItems: sessionData };
      saveUserSessionData( 'pickupUnavailableItems', sessionData );
      expect( setItemSpy ).toHaveBeenCalledWith( appConstants.SESSION_DATA, JSON.stringify( expecteOutput ) );
    } );

    it( 'should get value for passed param key from sessionData in localStorage', () => {

      const returnedValue = getUserSessionData( 'pickupUnavailableItems' );
      expect( getItemSpy ).toHaveBeenCalledWith( appConstants.SESSION_DATA );
      expect( returnedValue ).toEqual( sessionData );
    } );

    it( 'should remove key, value for passed param key from sessionData in localStorage', () => {

      saveUserSessionData( 'test', 'sample' );
      const testVal = getUserSessionData( 'test' );
      expect( testVal ).toEqual( 'sample' );

      removeUserSessionData( 'test' );
      const expecteOutput = { pickupUnavailableItems: sessionData };
      expect( setItemSpy ).toHaveBeenCalledWith( appConstants.SESSION_DATA, JSON.stringify( expecteOutput ) );
      const testValue = getUserSessionData( 'test' );
      expect( testValue ).toEqual( undefined );
      const pickupUnavailableItemsValue = getUserSessionData( 'pickupUnavailableItems' );
      expect( pickupUnavailableItemsValue ).toEqual( sessionData );
    } );

  } );

  describe( 'window function tests', () => {
    it( 'should call getUserSessionData when calling window.GET_USER_SESSION_DATA', () => {
      expect( GET_USER_SESSION_DATA ).toEqual( getUserSessionData );
    } );

    it( 'should call getUserData when calling window.GET_USER_DATA', () => {
      expect( GET_USER_DATA ).toEqual( getUserData );
    } );

  } );

} );