/**
 * AddToBag
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, getFormValues } from 'redux-form';

import './AddToBag.css';
import SelectField from 'ulta-fed-core/dist/js/views/SelectField/SelectField';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart } from '@fortawesome/pro-light-svg-icons/faHeart';
import { faHeart as faHeartSolid } from '@fortawesome/pro-solid-svg-icons/faHeart';
import Button20 from 'ulta-fed-core/dist/js/views/Button20/Button20';
import Text from 'ulta-fed-core/dist/js/views/Text/Text';
import Image from 'ulta-fed-core/dist/js/views/Image/Image';
import Anchor from 'ulta-fed-core/dist/js/views/Anchor/Anchor';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import SuccessSVG from 'ulta-fed-core/dist/js/views/Icons/Success';
import classNames from 'classnames';
import ResponseMessages from 'ulta-fed-core/dist/js/views/ResponseMessages/ResponseMessages';
import EmailStockAvailabilityModal from '../EmailStockAvailabilityModal/EmailStockAvailabilityModal';
import messages from './AddToBag.messages';
import platinumAnoynymous from '../../static/platinumAnoynymous.jpg';
import nonPlatinumMember from '../../static/nonPlatinumMember.png';
import {
  openSignInModal
} from '../../events/sign_in_modal/sign_in_modal.events';


class AddToBag extends Component{

  constructor( ){
    super();
    this.openSignInModal = this.openSignInModal.bind( this );
    this.handleFavoriteClick = this.handleFavoriteClick.bind( this );
    this.onHover = this.onHover.bind( this );
    this.state = { isFavoritesHovered: false };
  }

  openSignInModal( addToFav ){
    if( this.props.closeQuickShopModal ){
      this.props.closeQuickShopModal();
    }

    this.props.openSignInModal( addToFav );
  }

  onHover( ){
    this.setState( {
      isFavoritesHovered: !this.state.isFavoritesHovered
    } )
  }

  handleFavoriteClick(){

    if( this.props.isSignedIn ){

      if( this.props.favoriteId ){
        this.props.removeFromFavorites( this.props.favoriteId, this.props.skuId );
      }
      else {
        this.props.addToFavorites( this.props.productId, this.props.skuId )
      }
    }
    else {
      this.openSignInModal( true );
    }
  }

  componentDidUpdate( prevProps ){
    // if any error is returned by the add to bag service, we need to reset the quantity to 1 as per the requirement
    if( this.props.addToBagErrorMessages && !prevProps.addToBagErrorMessages ){
      this.props.change( 'selectedQuantity', 1 )
    }
    if( this.props.emailStockNotifyMessage && !prevProps.emailStockNotifyMessage ){
      // Close the notify me modal after a delay on emailaddress submit success
      setTimeout( () => {
        this.props.closeProductPageModal( 'isEmailMeModalOpen' );
        // Focus on Successmessage after the popup closes
        this.messageRef.focus();
      }, 3000 );
    }
  }


  render(){

    const { props } = this;
    const maximumQuantity = props.maxQuantity ? props.maxQuantity : 10;
    let faHeartIcon = props.favoriteId || this.state.isFavoritesHovered ? faHeartSolid : faHeart;

    return (
      <div className='AddToBag'>
        { props.addToBagErrorMessages && props.addToBagErrorMessages.items.map( ( message, index ) => {
          return (
            <ResponseMessages
              key={ index }
              message={ message.message }
            />
          )
        } ) }
        { props.addToFavoriteErrorMessages && props.addToFavoriteErrorMessages.items.map( ( message, index ) => {
          return (
            <ResponseMessages
              key={ index }
              message={ message.message }
            />
          )
        } ) }
        { /* Email Me When Stock Success message display */
          props.emailStockNotifyMessage &&
          (
            <div className='EmailStockAvailability'>
              <div className='EmailStockAvailability__success'>
                <SuccessSVG/>
                <div
                  tabIndex='-1'
                  ref={ ( ref ) => {
                    this.messageRef = ref
                  } }
                  className='EmailStockAvailabilitySuccess__message'
                >
                  { props.emailStockNotifyMessage }
                </div>
              </div>
            </div>
          )
        }
        { /* Out of stock info message display */
          props.outOfStockInfoMessage &&
          (
            <div className='ProductDetail__availabilitySection ProductDetail__availabilitySection--error'>
              { props.outOfStockInfoMessage }
            </div>
          )
        }
        { /* Other colors may be available info message  */
          props.otherColorInfoMessage &&
          (
            <div className='ProductDetail__availabilitySection ProductDetail__availabilitySection--message'>
              { props.otherColorInfoMessage }
            </div>
          )
        }
        { props.isAddToCartEligibleProduct &&
          <div className='AddToBag__selectButtonSection'>
            { ! props.isMobileDevice && ! props.isComingSoonProduct &&
              <div className='AddToBag__column AddToBag__select'>
                <SelectField
                  options={
                    [...Array( maximumQuantity )].map( ( x, i ) =>{
                      let quantity = i + 1;
                      return (
                        { value: quantity, label: quantity }
                      )
                    } ) }
                  value={ 1 }
                  name='selectedQuantity'
                  ariaLabel={ formatMessage( messages.qty ) }
                />
              </div>
            }
            <div className={
              classNames( 'AddToBag__column AddToBag__button',
                {
                  'AddToBag__button--comingSoon': props.isComingSoonProduct
                } )
            }
            >
              <Button20
                type='button'
                btnStyle='primary'
                size='large'
                disabled={ props.isComingSoonProduct }
                block={ true }
                dataNavDescription={ formatMessage( messages.addToBag ) }
                ariaLabel={ formatMessage( messages.addToBag ) }
                clickEventHandler={ ()=> props.addItemToBag( props.skuId, props.formValues.selectedQuantity, !props.isMobileDevice, props.history ) }
              >
                <span>{ formatMessage( messages.addToBag ) }</span>
              </Button20>
            </div>
          </div>
        }
        { props.isInStoreOnlyProduct &&
        <div className='ProductDetail__availablityInfo' >
          <div className='ProductDetail__availablityInfoMessage' >
            { formatMessage( messages.storeOnly ) }
          </div>
        </div>
        }
        { /* Email Me When Stock Button */
          props.isNotifyMeEligible &&
          (
            <div className='EmailStockAvailability'>
              <Button20
                btnStyle='secondary'
                block={ true }
                size='large'
                dataNavDescription='Email Stock Availability'
                clickEventHandler={ ()=> props.openProductPageModal( 'isEmailMeModalOpen' ) }
                analyticsEvent={ {
                  eventName: 'outOfStockEmailMeClick',
                  data: {
                    'productSku':props.skuId
                  }
                } }
              >
                <span>{ formatMessage( messages.emailStockAvailability ) }</span>
              </Button20>
            </div>
          )
        }
        { props.isPlatinumAndUserAnonymous &&
        <div className='ProductDetail__availablityInfo' >
          <div className='PlatinumPerk__anonymousUser' >
            <Image src={ platinumAnoynymous } alt={ formatMessage( messages.platinumPerkAltImage ) }/>
            <div
              className='PlatinumPerk__signInMessage'
              dangerouslySetInnerHTML={ { __html: props.platinumEligibilityMessage } }
            />
          </div>

          <Button20
            type='button'
            btnStyle='primary PlatinumPerk__signInButton'
            size='medium'
            clickEventHandler={ () => this.openSignInModal( false ) }
          >
            <span>{ formatMessage( messages.signin ) }</span>
          </Button20>

        </div >
        }
        { props.isPlatinumAndUserIneligible &&
        <div className='ProductDetail__availablityInfo' >
          <Image src={ nonPlatinumMember } alt={ formatMessage( messages.platinumPerkAltImage ) } />
          <div className='PlatinumPerk__nonPlatinumMember'>
            <div
              className='PlatinumPerk__signInMessage'
              dangerouslySetInnerHTML={ { __html: props.platinumEligibilityMessage } }
            />
            <Anchor
              className='PlatinumPerk__learnMessage'
              url='/ulta/myaccount/rewards_template.jsp?page=rewards&menu=benefits'
            >
              { formatMessage( messages.learn ) }
            </Anchor>
            { /* carrotImage is to accomplish the left arrow */ }
            <span className='carrotImage'></span>
          </div>
        </div>
        }
        { props.displayFavoritesButton &&
          <div className={
            classNames( 'AddToBag__column AddToBag__favorites bfx_hide' )
          }
          >
            <Button20
              type='button'
              btnStyle='icon'
              onMouseEnter={ () => this.onHover( ) }
              onMouseLeave={ () => this.onHover( ) }
              clickEventHandler={ this.handleFavoriteClick }
              ariaLabel={ `${formatMessage( messages.addToFavorites )}${( props.favoriteId ? formatMessage( messages.selected ) : formatMessage( messages.notSelected ) )}` }
            >

              <FontAwesomeIcon
                icon={ faHeartIcon }
                className={
                  classNames( {
                    'AddToBag__favorites--selected':props.favoriteId
                  } )
                }
              />
            </Button20>
          </div>
        }
        {
          props.displayAvailabilityDate &&
          <div className={
            classNames( 'ProductDetail__availabilityDate ',
              {
                'ProductDetail__availabilityDate--inStore': props.availabilityDateInStore
              } )
          }
          >
            { props.comingSoonDate &&
            <div className='ProductDetail__availabilityDate--comingSoonDate'>
              <Text
                type='body-2'
                htmlTag='span'
              >
                { `${formatMessage( messages.online )}` }
              </Text>
              <Text
                type='body-2'
                htmlTag='span'
                fontWeight='bold'
              >
                { props.comingSoonDate }
              </Text>
            </div>
            }
            { props.displayComingSoonInStoreDate &&
            <Text
              type='body-2'
              htmlTag='span'
              colorOverride='neutral-50'
            >
              { ' | ' }
            </Text>
            }
            { props.inStoreDate &&
            <div className='ProductDetail__availabilityDate--inStoreDate'>
              <Text
                type='body-2'
                htmlTag='span'
              >
                { `${formatMessage( messages.inStore )}` }
              </Text>
              <Text
                type='body-2'
                htmlTag='span'
                fontWeight='bold'
              >
                { props.inStoreDate }
              </Text>
            </div>
            }
          </div>
        }
        { /* Email Me when Stock Popup */
          <EmailStockAvailabilityModal
            skuId={ props.skuId }
            isModalOpen={ props.isEmailMeModalOpen }
            closeProductPageModal={ props.closeProductPageModal }
            submitEmailNotification={ props.submitEmailNotification }
            isNotifyMeEligible={ props.isNotifyMeEligible }
            emailStockNotifyMessage={ props.emailStockNotifyMessage }
            isSignedIn={ props.isSignedIn }
            profileInfo={ props.profileInfo }
          />
        }
      </div>
    );
  }
}


export const mapDispatchToProps = ( dispatch, props ) =>{

  return {

    openSignInModal: ( addToFav ) =>{
      // function is used to set the flag to show/hide the Sign In Product Detail Page on Add to favourite click.
      dispatch( openSignInModal( {
        sourcePage:'pdp',
        redirectPage:true,
        successPath: `${props.productActionUrl}${ addToFav ? '&fav=true' : '' }`
      } ) )
    }

  }
}

export const mapStateToProps = ( state, props ) => {
  return {
    formValues: ( function(){
      return getFormValues( props.form )( state );
    } )(),
    isAddToCartEligibleProduct: props.isAddToCartEligible || props.isComingSoonProduct,
    availabilityDateInStore: !props.isComingSoonProduct && props.inStoreDate,
    displayAvailabilityDate: props.comingSoonDate || props.inStoreDate,
    displayComingSoonInStoreDate: props.comingSoonDate && props.inStoreDate
  };
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return reduxForm( {
    // form property will be passed as a prop by the parent component of this component
    // there could be multiple instance of this form on a page for eg: Pdp and quick shop
    // and receiving the form name in the property  provides the flexibility to name the forms appropriately
    initialValues:{
      selectedQuantity:'1'
    }
  } )( connect( mapStateToProps, mapDispatchToProps )( AddToBag ) );
};
export default connectFunction( mapStateToProps, mapDispatchToProps );


