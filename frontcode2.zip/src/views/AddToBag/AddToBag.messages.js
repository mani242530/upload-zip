/*
 * AddToBag Messages
 *
 * This contains all the text for the AddToBag component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  addToBag: {
    id: 'i18n.AddToBag.header',
    defaultMessage: 'Add To Bag'
  },
  addToFavorites: {
    id: 'i18n.AddToBag.zipCode',
    defaultMessage: 'Add to favorites'
  },
  qty: {
    id: 'i18n.qty',
    defaultMessage: 'Quantity'
  },
  comingSoon:{
    id: 'i18n.item.comingSoon',
    defaultMessage: 'COMING SOON'
  },
  storeOnly:{
    id: 'i18n.item.storeOnly',
    defaultMessage: 'AVAILABLE IN STORE ONLY'
  },
  signin:{
    id: 'i18n.item.signin',
    defaultMessage: 'SIGN IN '
  },
  learn:{
    id: 'i18n.item.learn',
    defaultMessage: 'Learn how to qualify '
  },
  selected: {
    id: 'i18n.ProductSwatches.selected',
    defaultMessage: ' Selected'
  },
  notSelected: {
    id: 'i18n.ProductSwatches.notSelected',
    defaultMessage: ' Not selected'
  },
  emailStockAvailability: {
    id: 'i18n.EmailStockAvailability.message',
    defaultMessage: 'EMAIL ME WHEN IN STOCK'
  },
  stockAvailability: {
    id: 'i18n.stockAvailability.message',
    defaultMessage: 'We are currently out of stock of this item.'
  },
  colorAvailability: {
    id: 'i18n.colorAvailability.message',
    defaultMessage: 'Other colors may be available.'
  },
  online: {
    id: 'i18n.item.online',
    defaultMessage: 'Online '
  },
  inStore: {
    id: 'i18n.item.instore',
    defaultMessage: 'In Store '
  },
  platinumPerkAltImage: {
    id: 'i18n.item.platinumPerkAltImage',
    defaultMessage: 'Platinum perk'
  }
} );
