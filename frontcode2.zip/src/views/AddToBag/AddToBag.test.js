import React from 'react';
import ReactDOM from 'react-dom';
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import { Provider } from 'react-redux';
import Button20 from 'ulta-fed-core/dist/js/views/Button20/Button20';
import { faHeart } from '@fortawesome/pro-light-svg-icons/faHeart';
import { faHeart as faHeartSolid } from '@fortawesome/pro-solid-svg-icons/faHeart';
import AddToBag, {
  connectFunction,
  mapStateToProps,
  mapDispatchToProps
} from './AddToBag';
import messages from './AddToBag.messages';
import configureStore from '../../modules/pdp/pdp.store'
import CONFIG from '../../modules/pdp/pdp.config';
import { openSignInModal } from '../../events/sign_in_modal/sign_in_modal.events';


let appElement = document.createElement( 'div' );
appElement.id = 'js-pageContainer';
document.body.appendChild( appElement );


describe( '<AddToBag />', () =>{
  let component;
  const addItemToBagMock = jest.fn();
  const addToFavorites = jest.fn();
  const removeFromFavorites = jest.fn();
  const openSignInModal = jest.fn()
  const onHover = jest.fn()
  let props = {
    isAddToCartEligible:true,
    platinumEligibilityMessage:'sign in to see if you are eligible to buy the product',
    form:'pdpAddToBag',
    favoriteId:'gi12343',
    skuId:'1234',
    addItemToBag:addItemToBagMock,
    addToFavorites,
    onHover,
    removeFromFavorites,
    openSignInModal,
    productPageModal:{
      addToBag:false
    },
    history: {
      location: {
        pathname: '/bag'
      }
    },
    productDetails:{
      'product': {
        'id':123123,
        'actionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
      },
      'swatches':{},
      'sku': {
        'variant':{},
        'price':{},
        'images':{}
      },
      'brand': {}
    },
    'validProduct':true,
    'swatchesCountPerRow':5,
    profileInfo:{
      email:test
    },
    displayFavoritesButton : true
  }
  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <AddToBag { ...props } />
    </Provider>
  );
  it( 'renders without crashing', () =>{
    expect( component.find( 'AddToBag' ).length ).toBe( 1 );
  } );
  it( 'should contain AddToBag__column AddToBag__select', () =>{
    expect( component.find( '.AddToBag__column.AddToBag__select' ).length ).toBe( 1 );
  } )
  it( 'should contain AddToBag__column AddToBag__button', () =>{
    expect( component.find( '.AddToBag__column.AddToBag__button' ).length ).toBe( 1 );
  } )
  it( 'should contain AddToBag__column AddToBag__favorites', () =>{
    expect( component.find( '.AddToBag__column.AddToBag__favorites' ).length ).toBe( 1 );
  } )

  it( 'should contain bfx_hide section', () =>{
    expect( component.find( '.AddToBag__column.AddToBag__favorites.bfx_hide' ).length ).toBe( 1 );
  } )
  it( 'should display  solid font awsome heart  icon if favId is  present', () =>{
    expect( component.find( '.AddToBag__favorites FontAwesomeIcon' ).props().icon ).toBe( faHeartSolid );
  } )

  it( 'should invoke addItemToBag on click of add to bag button pssing skuId and quantity(default 1) as paramter', () =>{
    expect( addItemToBagMock ).not.toBeCalled();
    component.find( '.AddToBag__column.AddToBag__button button' ).at( 0 ).simulate( 'click' );
    expect( addItemToBagMock ).toHaveBeenCalledWith( props.skuId, '1', true, props.history );
  } );

  it( 'should render favorites button and its props', () =>{
    let component1;
    let props = {
      isAddToCartEligible:true,
      platinumEligibilityMessage:'sign in to see if you are eligible to buy the product',
      form:'pdpAddToBag',
      favoriteId:'gi12343',
      skuId:'1234',
      addItemToBag:addItemToBagMock,
      addToFavorites,
      onHover,
      removeFromFavorites,
      openSignInModal,
      productPageModal:{
        addToBag:false
      },
      history: {
        location: {
          pathname: '/bag'
        }
      },
      productDetails:{
        'product': {
          'id':123123,
          'actionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
        },
        'swatches':{},
        'sku': {
          'variant':{},
          'price':{},
          'images':{}
        },
        'brand': {}
      },
      'validProduct':true,
      'swatchesCountPerRow':5,
      profileInfo:{
        email:test
      },
      displayFavoritesButton : true
    }
    const store = configureStore( {}, CONFIG );
    component1 = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component1.find( '.AddToBag__favorites Button20' ).props().type ).toBe( 'button' );
    expect( component1.find( '.AddToBag__favorites Button20' ).props().btnStyle ).toBe( 'icon' );
    expect( component1.find( '.AddToBag__favorites Button20' ).props().onMouseEnter ).toBeTruthy();
    expect( component1.find( '.AddToBag__favorites Button20' ).props().onMouseLeave ).toBeTruthy();
    expect( component1.find( '.AddToBag__favorites Button20' ).props().clickEventHandler ).toBeTruthy();
  } )

  it( 'should change the isFavoritesHovered boolean false when onMouseLeave is called', () => {
    const instance = component.find( '.AddToBag__favorites Button20' ).instance();
    const node = component.find( 'AddToBag' ).instance();
    instance.props.onMouseEnter();
    expect( node.state.isFavoritesHovered ).toEqual( true );
    instance.props.onMouseLeave();
    expect( node.state.isFavoritesHovered ).toEqual( false );
  } );

  it( 'should invoke removeFromFavorites on click of add to favorite button passing favoriteId', () =>{
    props.isSignedIn = true
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    component.find( '.AddToBag__column.AddToBag__favorites Button20' ).simulate( 'click' );
    expect( removeFromFavorites ).toHaveBeenCalledWith( props.favoriteId, props.skuId );
  } );

  it( 'should invoke openSignInModal on click of add to favorite button for anonymous user on PDP Page', () =>{

    const openSignInModalMock = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) =>{
      return {
        loadProductDetails:jest.fn(),
        openSignInModal : jest.fn()
      }
    }
    const AddToBagMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    props.isSignedIn = false;
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBagMock { ...props } />
      </Provider>
    );

    const instance = component.find( 'AddToBag' ).instance();
    instance.openSignInModal = openSignInModalMock;
    component.find( '.AddToBag__column.AddToBag__favorites Button20' ).simulate( 'click' );
    expect( openSignInModalMock ).toBeCalledWith( true );

  } );

  it( 'should NOT invoke openSignInModal on click of add to favorite button for signed in user', () =>{

    const openSignInModalMock = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) =>{
      return {
        loadProductDetails:jest.fn(),
        openSignInModal : jest.fn()
      }
    }
    const AddToBagMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );
    props.isSignedIn = true;
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBagMock { ...props } />
      </Provider>
    );

    const instance = component.find( 'AddToBag' ).instance();
    instance.openSignInModal = openSignInModalMock;
    component.find( '.AddToBag__column.AddToBag__favorites Button20' ).simulate( 'click' );
    expect( openSignInModalMock ).not.toHaveBeenCalled();

  } );

  it( 'should contain 3 options for quantity', () =>{
    props.maxQuantity = 3
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.AddToBag__column.AddToBag__select' ).find( 'option' ).length ).toBe( 3 );
  } )

  it( 'should invoke addToFavorites on click of add to favorite button passing skuId , productId when favoriteId is not already present', () =>{
    props.isSignedIn = true
    props.favoriteId = null
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    component.find( '.AddToBag__column.AddToBag__favorites Button20' ).simulate( 'click' );
    expect( addToFavorites ).toHaveBeenCalledWith( props.productId, props.skuId );
  } );

  it( 'should invoke onHover method on mouseLeave of favorites button', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    const onHoverMock = jest.fn();
    const instance = component.find( 'AddToBag' ).instance();
    instance.onHover = onHoverMock;
    component.find( '.AddToBag__column.AddToBag__favorites Button20' ).simulate( 'mouseLeave' );
    expect( onHoverMock ).toBeCalled();
  } );

  it( 'should invoke onHover method on mouseLeave of favorites button', () => {
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    const onHoverMock = jest.fn();
    const instance = component.find( 'AddToBag' ).instance();
    instance.onHover = onHoverMock;
    component.find( '.AddToBag__column.AddToBag__favorites Button20' ).simulate( 'mouseEnter' );
    expect( onHoverMock ).toBeCalled();
  } );

  it( 'should display addToBagErrorMessages if it is available in props', () =>{

    props.addToBagErrorMessages = {
      items:[{
        message:'add to bag error message'
      }]
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( 'ResponseMessages' ).text() ).toBe( 'add to bag error message' );
  } )

  it( 'should display addToFavoriteErrorMessages if it is available in props', () =>{
    props.addToBagErrorMessages = null;
    props.addToFavoriteErrorMessages = {
      items:[{
        message:'favorite error message'
      }]
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( 'ResponseMessages' ).text() ).toBe( 'favorite error message' );
  } )

  it( 'should invoke redux form change method to reset the quantity dropdown to 1', () =>{
    props.addToBagErrorMessages = {
      items:[{
        message:'error'
      }]
    }
    props.onChange = jest.fn();
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    component.find( 'AddToBag' ).instance().componentDidUpdate( {} );
    expect( props.onChange ).toBeCalled();
  } )

  it( 'should close the modal after a delay when submit email address for stock notification is success', () =>{
    props.emailStockNotifyMessage = 'okay! notification success';

    props.closeProductPageModal = jest.fn();
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    jest.useFakeTimers();
    component.find( 'AddToBag' ).instance().componentDidUpdate( { } );
    expect( props.closeProductPageModal ).not.toBeCalled();
    jest.runAllTimers();
    expect( props.closeProductPageModal ).toBeCalled();
  } )

  it( 'should display coming soon message when eligibility service returns eligibilityState as 8', () =>{
    const props = {
      'eligibleForCart':false,
      'isInStoreOnlyProduct':true,
      'outOfStockInfoMessage':'Okay! We\'ve got you down to be emailed when this item is back in stock.',
      'otherColorInfoMessage':'Okay!',
      productPageModal:{
        addToBag:false
      },
      productDetails:{
        'product': {},
        'swatches':{},
        'sku': {
          'variant':{},
          'price':{},
          'images':{}
        },
        'brand': {}
      }
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.ProductDetail__availablityInfoMessage' ).text() ).toBe( messages.storeOnly.defaultMessage );
  } )

  it( 'should display in store date and coming soon date when eligibility service returns availabilitydate for findinstore and coming soon', () =>{
    const props = {
      'eligibleForCart':false,
      'comingSoonDate':'Nov 12',
      'inStoreDate':'Nov 14',
      productPageModal:{
        addToBag:false
      },
      productDetails:{
        'product': {},
        'swatches':{},
        'sku': {
          'variant':{},
          'price':{},
          'images':{}
        },
        'brand': {}
      }
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.ProductDetail__availabilityDate--comingSoonDate Text' ).at( 0 ) .text() ).toBe( 'Online ' );
    expect( component.find( '.ProductDetail__availabilityDate--comingSoonDate Text' ).at( 1 ) .text() ).toBe( 'Nov 12' );
    expect( component.find( '.ProductDetail__availabilityDate' ).text() ).toBe( 'Online Nov 12 | In Store Nov 14' );
    expect( component.find( '.ProductDetail__availabilityDate--inStoreDate Text' ).at( 0 ) .text() ).toBe( 'In Store ' );
    expect( component.find( '.ProductDetail__availabilityDate--inStoreDate Text' ).at( 1 ) .text() ).toBe( 'Nov 14' );
  } )
  it( 'should display coming soon date only when eligibility service returns availabilitydate for coming soon', () =>{
    const props = {
      'eligibleForCart':false,
      'comingSoonDate':'Nov 12',
      productPageModal:{
        addToBag:false
      },
      productDetails:{
        'product': {},
        'swatches':{},
        'sku': {
          'variant':{},
          'price':{},
          'images':{}
        },
        'brand': {}
      }
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.ProductDetail__availabilityDate--comingSoonDate Text' ).at( 0 ) .text() ).toBe( 'Online ' );
    expect( component.find( '.ProductDetail__availabilityDate--comingSoonDate Text' ).at( 1 ) .text() ).toBe( 'Nov 12' );
  } )
  it( 'should display instore date only when eligibility service returns availabilitydate for find in store', () =>{
    const props = {
      'eligibleForCart':false,
      'inStoreDate':'Nov 12',
      productPageModal:{
        addToBag:false
      },
      productDetails:{
        'product': {},
        'swatches':{},
        'sku': {
          'variant':{},
          'price':{},
          'images':{}
        },
        'brand': {}
      }
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.ProductDetail__availabilityDate--inStoreDate Text' ).at( 0 ) .text() ).toBe( 'In Store ' );
    expect( component.find( '.ProductDetail__availabilityDate--inStoreDate Text' ).at( 1 ) .text() ).toBe( 'Nov 12' )
  } )
  it( 'should display Sign in button and message when eligibility service returns eligibilityState as 2', () =>{
    const props = {
      'isPlatinumAndUserAnonymous': true,
      'platinumEligibilityMessage':'sign in to see if you are eligible to buy the product',
      'productId': 'xlsImpprod12251073',
      'productActionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
    }

    const openSignInModalMock = jest.fn();

    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    const instance = component.find( 'AddToBag' ).instance();
    instance.openSignInModal = openSignInModalMock;
    expect( component.find( '.ProductDetail__availablityInfo' ).find( 'Button20' ).length ).toBe( 1 );
    expect( component.find( '.ProductDetail__availablityInfo' ).find( 'Button20' ).text() ).toBe( messages.signin.defaultMessage );
    expect( component.find( '.ProductDetail__availablityInfo' ).find( 'Button20' ).props().clickEventHandler ).toBeTruthy();
    expect( component.find( '.ProductDetail__availablityInfo' ).find( 'Image' ).length ).toBe( 1 );
    expect( component.find( '.ProductDetail__availablityInfo' ).find( 'Image' ).props().alt ).toBe( 'Platinum perk' );
    expect( component.find( '.PlatinumPerk__signInMessage' ).length ).toBe( 1 );
    expect( component.find( '.PlatinumPerk__signInMessage' ).text() ).toBe( props.platinumEligibilityMessage );
  } );

  it( 'Should invoke openSignInModal and dispatch openSignInModal for Platinum Perk Sign In Button', () => {
    const props = {
      'isPlatinumAndUserAnonymous': true,
      'platinumEligibilityMessage':'sign in to see if you are eligible to buy the product',
      'productId': 'xlsImpprod12251073',
      'productActionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
    }
    const openSignInModalMock = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) =>{
      return {
        loadProductDetails:jest.fn(),
        openSignInModal : openSignInModalMock
      }
    }
    const AddToBagMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBagMock { ...props } />
      </Provider>
    );

    const instance = component.find( 'AddToBag' ).instance();
    instance.openSignInModal = openSignInModalMock;
    component.find( '.ProductDetail__availablityInfo' ).find( 'Button20' ).simulate( 'click' );
    expect( openSignInModalMock ).toBeCalledWith( false );
  } );

  it( 'should display Sign in button  message when eligibility service returns eligibilityState as 3', () =>{
    const props = {
      'isPlatinumAndUserIneligible': true,
      'platinumEligibilityMessage':'you are not eligible to buy this product',
      'productId': 'xlsImpprod12251073',
      'productActionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );

    expect( component.find( 'Anchor' ).length ).toBe( 1 );
    expect( component.find( 'Image' ).length ).toBe( 1 );
    expect( component.find( 'Image' ).props().alt ).toBe( 'Platinum perk' );
    expect( component.find( 'Anchor' ).props().url ).toBe( '/ulta/myaccount/rewards_template.jsp?page=rewards&menu=benefits' );
    expect( component.find( '.PlatinumPerk__signInMessage' ).length ).toBe( 1 );
    expect( component.find( '.PlatinumPerk__signInMessage' ).text() ).toBe( props.platinumEligibilityMessage );
  } )

  it( 'should display Email Me When Stock Success message ', () =>{
    const props = {
      emailStockNotifyMessage: 'Okay! We\'ve got you down to be emailed when this item is back in stock.',
      'productId': 'xlsImpprod12251073',
      'productActionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );

    expect( component.find( '.EmailStockAvailability' ).length ).toBe( 1 );
    expect( component.find( '.EmailStockAvailability__success svg' ).length ).toBe( 1 );
  } )

  it( 'should display Out of stock info message ', () =>{
    const props = {
      outOfStockInfoMessage: 'Okay! We\'ve got you down to be emailed when this item is back in stock.',
      'productId': 'xlsImpprod12251073',
      'productActionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );

    expect( component.find( '.ProductDetail__availabilitySection.ProductDetail__availabilitySection--error' ).length ).toBe( 1 );
  } )

  it( 'should display Email Me When Stock Button ', () =>{
    const props = {
      isNotifyMeEligible: true,
      'productId': 'xlsImpprod12251073',
      'productActionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );

    expect( component.find( '.EmailStockAvailability Button20' ).length ).toBe( 1 );
    expect( component.find( '.EmailStockAvailability Button20' ).props().btnStyle ).toEqual( 'secondary' );
    expect( component.find( '.EmailStockAvailability Button20' ).props().block ).toEqual( true );
    expect( component.find( '.EmailStockAvailability Button20' ).props().size ).toEqual( 'large' );
  } )

  it( 'should have analytics event as props with analytics data in Email Me When Stock Button ', () =>{
    const props = {
      isNotifyMeEligible: true,
      'productId': 'xlsImpprod12251073',
      'productActionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
    };
    const expectedData = {
      eventName: 'outOfStockEmailMeClick',
      data: {
        'productSku':props.skuId
      }
    };
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.EmailStockAvailability Button20' ).props().analyticsEvent ).toEqual( expectedData );
  } )

  it( 'should display Other colors may be available info message', () =>{
    const props = {
      otherColorInfoMessage: 'Okay! We\'ve got you down to be emailed when this item is back in stock.',
      'productId': 'xlsImpprod12251073',
      'productActionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );

    expect( component.find( '.ProductDetail__availabilitySection.ProductDetail__availabilitySection--message' ).length ).toBe( 1 );
  } )

  it( 'should render EmailStockAvailabilityModal', () =>{
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( 'EmailStockAvailabilityModal' ).length ).toBe( 1 );
  } )

  it( 'should read AddToFav button as selected if favId is present', () =>{
    props.favoriteId = 'gi12343';
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.AddToBag__column.AddToBag__favorites' ).find( Button20 ).props().ariaLabel ).toBe( messages.addToFavorites.defaultMessage + messages.selected.defaultMessage );
  } )

  it( 'should read AddToFav button as not selected if favId is not present', () =>{
    props.favoriteId = null;
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.AddToBag__column.AddToBag__favorites' ).find( Button20 ).props().ariaLabel ).toBe( messages.addToFavorites.defaultMessage + messages.notSelected.defaultMessage );
  } )

  it( 'should display  light font awsome heart  icon if favId is  not present', () =>{
    props.favoriteId = null;
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.AddToBag__favorites FontAwesomeIcon' ).props().icon ).toBe( faHeart );
  } )


  it( 'should add AddToBag__favorites--selected class if favId is present', () =>{
    props.favoriteId = 'gi12343';
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.AddToBag__favorites FontAwesomeIcon' ).props().className ).toBe( 'AddToBag__favorites--selected' );
  } )

  it( 'should not add AddToBag__favorites--selected class if favId is not present', () =>{
    let props1 = {
      ...props,
      favoriteId:null
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props1 } />
      </Provider>
    );
    expect( component.find( '.AddToBag__favorites FontAwesomeIcon' ).props().className ).toBe( '' );
  } )

  it( 'should pass correct btnStyle and type props to AddToFav button', () =>{
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.AddToBag__column.AddToBag__favorites' ).find( Button20 ).props().type ).toBe( 'button' );
    expect( component.find( '.AddToBag__column.AddToBag__favorites' ).find( Button20 ).props().btnStyle ).toBe( 'icon' );
  } )

  it( 'should display Other colors may be available info message', () =>{
    const props = {
      otherColorInfoMessage: 'Okay! We\'ve got you down to be emailed when this item is back in stock.',
      'productId': 'xlsImpprod12251073',
      'productActionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
    }
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );

    expect( component.find( '.ProductDetail__availabilitySection.ProductDetail__availabilitySection--message' ).length ).toBe( 1 );
  } )

  it( 'should render EmailStockAvailabilityModal', () =>{
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( 'EmailStockAvailabilityModal' ).length ).toBe( 1 );
  } )
  it( 'should change the class name to  AddToBag__column AddToBag__button AddToBag__button--comingSoon, if the isComingSoon date is present', () => {
    const props1 = {
      'eligibleForCart':false,
      'isComingSoonProduct':true
    }
    let component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props1 }/>
      </Provider>
    );
    expect( component.find( '.AddToBag__column.AddToBag__button.AddToBag__button--comingSoon' ).length ).toBe( 1 );
  } );
  it( ' Should disable Button if the isComingSoonProduct is true', () => {
    const props1 = {
      'eligibleForCart':false,
      'isComingSoonProduct':true
    }
    let component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props1 }/>
      </Provider>
    );
    expect( component.find( '.AddToBag__column.AddToBag__button.AddToBag__button--comingSoon' ).find( 'Button20' ).props().disabled ).toBe( true );

  } );
  it( 'should not add AddToBag__button--comingSoon class name, if the isComingSoon date is not present', () => {
    const props1 = {
      'eligibleForCart':true,
      'isComingSoonProduct':false
    }
    let component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props1 }/>
      </Provider>
    );
    expect( component.find( '.AddToBag__column.AddToBag__button.AddToBag__button--comingSoon' ).length ).toBe( 0 );
  } );
  it( 'should change the class name to  ProductDetail__availabilityDate ProductDetail__availabilityDate--inStore, if the isComingSoon is not available & inStoreDate is available', () => {
    const props1 = {
      'eligibleForCart':true,
      'isComingSoonProduct':false,
      'inStoreDate':true
    }
    let component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props1 }/>
      </Provider>
    );
    expect( component.find( '.ProductDetail__availabilityDate.ProductDetail__availabilityDate--inStore' ).length ).toBe( 1 );
  } );
  it( 'should not change the class name to  ProductDetail__availabilityDate ProductDetail__availabilityDate--inStore, if the isComingSoon is available & inStoreDate is not available', () => {
    const props1 = {
      'eligibleForCart':true,
      'isComingSoonProduct':true,
      'inStoreDate':false
    }
    let component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props1 }/>
      </Provider>
    );
    expect( component.find( '.ProductDetail__availabilityDate.ProductDetail__availabilityDate--inStore' ).length ).toBe( 0 );
  } );

  it( 'should not show the AddToFav button if the diaplayFavoritesButton is false', () =>{
    props.displayFavoritesButton = false;
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    expect( component.find( '.AddToBag__favorites' ).length ).toBe( 0 );
  } );

  it( 'should change the isFavoritesHovered boolean value when onHover is called', () => {
    const instance = component.find( 'AddToBag' ).instance();
    expect( instance.state.isFavoritesHovered ).toEqual( false );
    instance.onHover();
    expect( instance.state.isFavoritesHovered ).toEqual( true );
  } );

  it( 'should display light favourite icon if isFavoritesHovered false', () =>{
    let component1;
    let props = {
      isAddToCartEligible:true,
      platinumEligibilityMessage:'sign in to see if you are eligible to buy the product',
      form:'pdpAddToBag',
      favoriteId:null,
      skuId:'1234',
      addItemToBag:addItemToBagMock,
      addToFavorites,
      onHover,
      removeFromFavorites,
      openSignInModal,
      productPageModal:{
        addToBag:false
      },
      history: {
        location: {
          pathname: '/bag'
        }
      },
      productDetails:{
        'product': {
          'id':123123,
          'actionUrl':'https://www.ulta.com/cc-radiance-ombre-blush?productId=xlsImpprod12251073'
        },
        'swatches':{},
        'sku': {
          'variant':{},
          'price':{},
          'images':{}
        },
        'brand': {}
      },
      'validProduct':true,
      'swatchesCountPerRow':5,
      profileInfo:{
        email:test
      },
      displayFavoritesButton : true
    }
    const store = configureStore( {}, CONFIG );
    component1 = mountWithIntl(
      <Provider store={ store }>
        <AddToBag { ...props } />
      </Provider>
    );
    let instance = component1.find( 'AddToBag' ).instance();
    instance.state.isFavoritesHovered = false;
    expect( component1.find( '.AddToBag__favorites FontAwesomeIcon' ).props().icon ).toBe( faHeart );
  } )

} );