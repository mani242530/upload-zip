/**
 * AddToBagModal
 */

import React from 'react';
import './AddToBagModal.css';
import { connect } from 'react-redux';
import ModalWrapper from 'ulta-fed-core/dist/js/views/ModalWrapper/ModalWrapper';
import CloseSVG from 'ulta-fed-core/dist/js/views/Icons/close';
import has from 'lodash/has';
import ProductPricingPanel from 'ulta-fed-core/dist/js/views/ProductPricingPanel/ProductPricingPanel';
import Image from 'ulta-fed-core/dist/js/views/Image/Image';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import Button20 from 'ulta-fed-core/dist/js/views/Button20/Button20';
import AnchorButton from 'ulta-fed-core/dist/js/views/AnchorButton/AnchorButton';
import Divider from 'ulta-fed-core/dist/js/views/Divider/Divider';
import messages from './AddToBagModal.messages';
import ProductRecs from '../ProductRecs/ProductRecs';
import {
  closeAddToBagModal
} from '../../events/add_to_bag/add_to_bag.events';
import appConstants from '../../shared/appConstants';

/**
 * Class
 * @extends React.Component
 */
const AddToBagModal = ( props ) => {

  return (
    <div className='AddToBagModal'>
      <ModalWrapper
        isOpen={ true }
        contentLabel={ formatMessage( messages.addToBagModal ) }
        className='AddToBag__Modal'
        onRequestClose={ props.closeAddToBagModal }
        role='dialog'
        style={ {
          overlay: {
            backgroundColor: 'rgba(0,0,0,0.55)'
          }
        } }
        ariaHideApp={ false }
      >
        <div className='AddToBagModal__CloseButton'>
          <Button20
            btnStyle='icon'
            clickEventHandler={ props.closeAddToBagModal }
          >
            <CloseSVG/>
          </Button20>
        </div>

        <div className='AddToBagSummary'>
          <h3 className='AddToBagSummary__heading'>
            { formatMessage( messages.itemAdded ) }
          </h3>
          <div className='AddToBagSummary__mainSection'>
            <div className='AddToBagSummary__productImage'>
              <Image
                className='AddToBagSummary__thumbnail-image'
                src={ props.addToBagState.productImage }
                alt=''
              />
            </div>
            <div className='AddToBagSummary__productDetails'>
              <h5 className='AddToBagSummary__productName'>
                { props.addToBagState.brandName }
              </h5>
              <h2 className='AddToBagSummary__productDescriptionText'>
                { props.addToBagState.displayName }
              </h2>
              { props.variant &&
                (
                  <h3 className='AddToBagSummary__productInfo'>
                    { props.addToBagState.variant.variantDesc }
                  </h3>
                )
              }
              { props.addToBagState.listPrice &&
                <ProductPricingPanel
                  listPrice={ props.addToBagState.listPrice }
                  salePrice={ props.addToBagState.salePrice }
                  hasOnlyListPrice={ !props.addToBagState.salePrice && !!props.addToBagState.listPrice }
                />
              }
              <div className='AddToBagSummary__Quantity'>
                { `${ formatMessage( messages.quantity ) } : ${ props.addToBagState.selectedQuantity }` }
              </div>
              <div className='AddToBagSummary__Button'>
                <Button20
                  size='small'
                  btnStyle='secondary'
                  clickEventHandler={ props.closeAddToBagModal }
                >
                  { formatMessage( messages.continueShopping ) }
                </Button20>
                <AnchorButton
                  btnSize='small'
                  btnStyle='secondary'
                  url={ appConstants.ROUTES.BAG_PAGE }
                >
                  { formatMessage( messages.viewBagCheckout ) }
                </AnchorButton>
              </div>
            </div>
          </div>
          {
            !props.isMobileDevice &&
            <div
              className='AddToBagSummary__Recs'
              data-recWidgetId={ props.a2cRfkId }
            >
              {
                props.addToBagState.recommendedProducts &&
                  <div className='AddToBagSummary__ProductRecs'>
                    <Divider dividerType='gray' />
                    <ProductRecs
                      showOnlyListPrice={ true }
                      productRecList={ { recommendations : props.addToBagState.recommendedProducts } }
                      productCount={ 4 }
                      isQuickShopEnabled={ true }
                      crossSellLocation={ appConstants.CROSS_SELL_LOCATION.ADD_TO_BAG }
                    />
                  </div>
              }
            </div>
          }
          {
            !props.isMobileDevice &&
            props.reflektionEnabled &&
            (
              <div className='AddToBagSummary__reflekRecs'>
                <Divider dividerType='gray' />
                <div data-rfkid='rfkid_5'></div>
                <div id='suggest-you-section' data-rfkid='rfkid_x5'></div>
              </div>
            )
          }
        </div>
      </ModalWrapper>
    </div>
  );
}

export const mapStateToProps = ( state ) =>{
  return {
    addToBagState:state.addtobag,
    isMobileDevice:state.global.isMobileDevice,
    reflektionEnabled: has( state.global, 'switchData.switches.enableRfkRecommendation' ) && state.global.switchData.switches.enableRfkRecommendation,
    a2cRfkId:state.global.switchData?.switches?.pageToRfkWidgetIdMapping?.addToCartPage
  };
}

export const mapDispatchToProps = ( dispatch ) =>{
  return {
    closeAddToBagModal: () =>{
      dispatch( closeAddToBagModal() );
    }
  }
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( AddToBagModal ) );
};

export default connectFunction( mapStateToProps, mapDispatchToProps );
