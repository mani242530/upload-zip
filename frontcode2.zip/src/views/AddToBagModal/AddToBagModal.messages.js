/*
 * AddToBag Messages
 *
 * This contains all the text for the AddToBag component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  continueShopping: {
    id: 'i18n.AddToCartModal.continueShopping',
    defaultMessage: 'CONTINUE SHOPPING'
  },
  itemAdded: {
    id: 'i18n.AddToCartModal.itemAdded',
    defaultMessage: 'This item was added to your shopping bag.'
  },
  viewBagCheckout: {
    id: 'i18n.AddToCartModal.viewBagCheckout',
    defaultMessage: 'VIEW BAG & CHECKOUT'
  },
  quantity: {
    id: 'i18n.AddToCartModal.quantity',
    defaultMessage: 'Quantity'
  },
  youMayAlsoLike:{
    id: 'i18n.item.youMayAlsoLike',
    defaultMessage: 'You May Also Like'
  },
  addToBagModal:{
    id: 'i18n.item.addToBagModal',
    defaultMessage: 'Add To Bag Modal'
  }

} );
