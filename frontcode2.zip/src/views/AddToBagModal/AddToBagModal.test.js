/**
 * AddToBagModal
 */

import React from 'react';
import { connect, Provider } from 'react-redux';
import ReactDOM from 'react-dom';
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import configureStore from '../../modules/ccr/ccr.store'
import CONFIG from '../../modules/ccr/ccr.config';
import messages from './AddToBagModal.messages';
import AddToBagModal, {
  connectFunction,
  mapStateToProps,
  mapDispatchToProps
} from './AddToBagModal';
import {
  closeAddToBagModal
} from '../../events/add_to_bag/add_to_bag.events';



let appElement = document.createElement( 'div' );
appElement.id = 'js-pageContainer';
document.body.appendChild( appElement );
const dispatch = jest.fn();

describe( '<AddToBagModal />', () => {

  const store = configureStore( {}, CONFIG );
  const stateValues = {
    isAddToBagModalOpen:true,
    selectedQuantity:'5',
    productImage:'https://images.ulta.com/is/image/Ulta/2236259?$sm$',
    brandName:'OPI',
    displayName:'product display name',
    variant:{
      variantDesc:'product variant'
    },
    listPrice:{
      amount:'10.99',
      currencyCode:'USD'
    },
    salePrice:{
      amount:'8.99',
      currencyCode:'USD'
    },
    hasOnlyListPrice: false,
    recommendedProducts :{
      'items': [
        {
          'placementName': 'error_page.horizontal',
          'strategyMesssage': 'May We Suggest',
          'products': {
            'items': [
              {
                'adbugMessage': null,
                'product': {
                  'activeSkusCount': 1,
                  'displayName': 'Online Only On The Glow Highlighting Palette',
                  'actionUrl': '/on-glow-highlighting-palette?productId=xlsImpprod15931211',
                  'isGWP': false,
                  'id': 'xlsImpprod15931211',
                  'title': 'Ofra Cosmetics Online Only On The Glow Highlighting Palette | Ulta Beauty',
                  'multiSku': false,
                  'defaultSku': '2511222'
                },
                'category': {
                  'displayName': 'Contouring',
                  'id': 'cat510002'
                },
                'sku': {
                  'badges': {
                    'items': [
                      {
                        'badgeName': 'Online Only',
                        'priority': 7,
                        'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
                      }
                    ]
                  },
                  'images': {
                    'blowupImage': 'https://images.ulta.com/is/image/Ulta/2511222?$detail$',
                    'mainImage': 'https://images.ulta.com/is/image/Ulta/2511222',
                    'largeImage': 'https://images.ulta.com/is/image/Ulta/2511222?$lg$',
                    'smallImage': 'https://images.ulta.com/is/image/Ulta/2511222?$sm$',
                    'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2511222?$tn$',
                    'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2511222?$md$'
                  },
                  'displayName': null,
                  'price': {
                    'showListRange': true,
                    'lowRangeListPrice': 110,
                    'salePrice': null,
                    'showListAndSaleRange': false,
                    'highRangeSalePrice': 0,
                    'lowRangeSalePrice': 0,
                    'highRangeListPrice': 110,
                    'listPrice': {
                      'displayAmount': '$110.00',
                      'amount': 110,
                      'currencyCode': 'USD'
                    }
                  },
                  'variant': null,
                  'id': '2511222'
                },
                'brand': {
                  'brandName': 'Ofra Cosmetics',
                  'brandId': 'xlsImp52500002'
                },
                'reviewSummary': {
                  'reviewCount': 0,
                  'rating': 0
                },
                'promotion': null
              }
            ]
          }
        }
      ]
    }
  }


  store.getState().addtobag = stateValues;
  store.getState().global = {
    switchData:{
      switches:{
        pageToRfkWidgetIdMapping:{
          addToCartPage : 'RFK_ATC'
        }
      }
    }
  }


  let component = mountWithIntl(
    <Provider store={ store }>
      <AddToBagModal/>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'AddToBagModal' ).length ).toBe( 1 );
    expect( component.find( 'ModalWrapper' ).length ).toBe( 1 );
    expect( component.find( 'ModalWrapper' ).props().ariaHideApp ).toBe( false );
  } );

  it( 'renders AddToBag__Modal', () => {
    expect( component.find( 'Modal' ).length ).toBe( 1 );
    expect( component.find( 'Modal' ).props().className ).toBe( 'AddToBag__Modal' );
    expect( component.find( 'Modal' ).props().onRequestClose ).toBeTruthy();
  } );

  it( 'should render ( close modal ) anchor with SVG and ariaLabel', () => {
    expect( document.body.getElementsByTagName( 'button' )[0].innerHTML.indexOf( '<title>Close</title>' ) ).toBeGreaterThan( 0 );
  } );

  it( 'it should show the header message', () => {
    expect( component.find( '.AddToBagSummary__heading' ).length ).toBe( 1 );
    expect( component.find( '.AddToBagSummary__heading' ).text() ).toBe( messages.itemAdded.defaultMessage );
  } );

  it( 'Should render close button and its props', () => {
    const component = mountWithIntl(
      <Provider store={ store }>
        <AddToBagModal/>
      </Provider>
    );
    expect( component.find( '.AddToBagModal__CloseButton Button20' ).length ).toBe( 1 );
    expect( component.find( '.AddToBagModal__CloseButton Button20' ).props().btnStyle ).toBe( 'icon' );
  } );
  it( 'Should invoke closeAddToBagModal method ', () => {
    const closeAddToBagModalMock = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) =>{
      return {
        closeAddToBagModal : closeAddToBagModalMock
      }
    }
    const AddToBagModalMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBagModalMock/>
      </Provider>
    );
    component.find( '.AddToBagModal__CloseButton Button20' ).at( 0 ).simulate( 'click' );
    expect( closeAddToBagModalMock ).toBeCalled();
  } );

  it( 'Should render the AddToBagSummary__productImage ', () => {
    expect( component.find( '.AddToBagSummary__productImage' ).length ).toBe( 1 );
    expect( component.find( '.AddToBagSummary__productImage Image' ).props().src ).toBe( stateValues.productImage );
  } );

  it( 'Should render the AddToBagSummary__productName ', () => {
    expect( component.find( '.AddToBagSummary__productName' ).length ).toBe( 1 );
    expect( component.find( '.AddToBagSummary__productName' ).text() ).toBe( stateValues.brandName );
  } );

  it( 'Should render the AddToBagSummary__productDescriptionText ', () => {
    expect( component.find( '.AddToBagSummary__productDescriptionText' ).length ).toBe( 1 );
    expect( component.find( '.AddToBagSummary__productDescriptionText' ).text() ).toBe( stateValues.displayName );
  } );

  it( 'Should render the ProductPricingPanel ', () => {
    expect( component.find( '.ProductPricingPanel' ).length ).toBe( 1 );
    expect( component.find( '.ProductPricingPanel__salePrice Text' ).at( 0 ).text() ).toBe( 'Sale Price$' + stateValues.salePrice.amount );
    expect( component.find( '.ProductPricingPanel__salePrice Text' ).at( 1 ).text() ).toBe( 'Original Price$' + stateValues.listPrice.amount );
  } );

  // ToDo (should replace :1 with the props once the story for the same is completed)
  it( 'it should render the AddToBagSummary__Quantity', () => {
    expect( component.find( '.AddToBagSummary__Quantity' ).length ).toBe( 1 );
    expect( component.find( '.AddToBagSummary__Quantity' ).text() ).toBe( messages.quantity.defaultMessage + ' : ' + stateValues.selectedQuantity );
  } );

  it( 'it should render the AddToBagSummary__Button--continueShopping', () => {
    const closeAddToBagModalMock = jest.fn();
    let mapDispatchToPropsMock = ( dispatch ) =>{
      return {
        closeAddToBagModal : closeAddToBagModalMock
      }
    }
    const AddToBagModalMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBagModalMock/>
      </Provider>
    );
    expect( component.find( '.AddToBagSummary__Button' ).length ).toBe( 1 );
    expect( component.find( '.AddToBagSummary__Button Button20' ).length ).toBe( 1 );
    expect( component.find( '.AddToBagSummary__Button Button20' ).props().size ).toBe( 'small' );
    expect( component.find( '.AddToBagSummary__Button Button20' ).props().btnStyle ).toBe( 'secondary' );
    expect( component.find( '.AddToBagSummary__Button Button20' ).text() ).toBe( messages.continueShopping.defaultMessage );
    component.find( '.AddToBagSummary__Button Button20' ).simulate( 'click' );
    expect( closeAddToBagModalMock ).toBeCalled();
  } );

  it( 'it should render the AddToBagSummary__Button--viewBag', () => {
    expect( component.find( '.AddToBagSummary__Button AnchorButton' ).length ).toBe( 1 );
    expect( component.find( '.AddToBagSummary__Button AnchorButton' ).props().btnSize ).toBe( 'small' );
    expect( component.find( '.AddToBagSummary__Button AnchorButton' ).props().btnStyle ).toBe( 'secondary' );
    expect( component.find( '.AddToBagSummary__Button AnchorButton' ).props().url ).toBe( '/bag' );
    expect( component.find( '.AddToBagSummary__Button AnchorButton' ).find( 'Anchor' ).props() .url ).toBe( '/bag' );
    expect( component.find( '.AddToBagSummary__Button AnchorButton' ).text() ).toBe( messages.viewBagCheckout.defaultMessage );
  } );

  it( 'it should render the AddToBagSummary__ProductRecs', () => {
    expect( component.find( '.AddToBagSummary__ProductRecs' ).length ).toBe( 1 );
    expect( component.find( 'Divider' ).length ).toBe( 2 );
    expect( component.find( '.AddToBagSummary__Recs' ).props()[ 'data-recWidgetId'] ).toBe( 'RFK_ATC' );
    expect( component.find( 'ProductRecs' ).length ).toBe( 1 );
    expect( component.find( 'ProductRecs' ).props().isQuickShopEnabled ).toBe( true );
    expect( component.find( 'ProductRecs' ).props().productCount ).toBe( 4 );
    expect( component.find( 'ProductRecs' ).props().displayQuickShop ).toBe( component.find( 'AddToBagModal' ).props().displayQuickShop ) ;
    expect( component.find( 'ProductRecs' ).props().productRecList ).toEqual( { recommendations:component.find( 'AddToBagModal' ).props().addToBagState.recommendedProducts } );
    expect( component.find( 'ProductRecs' ).props().showOnlyListPrice ).toBe( true );
    expect( component.find( 'ProductRecs' ).props().crossSellLocation ).toBe( 'add to bag' );
  } );

  it( 'it should render the Reflektion container when enabled', () => {
    let switchDataMock = {
      switches: {
        enableRfkRecommendation: true
      }
    }
    store.getState().global.switchData = switchDataMock;
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBagModal/>
      </Provider>
    );
    expect( component.find( '.AddToBagSummary__reflekRecs' ).length ).toBe( 1 );
  } );

  it( 'should not render the AddToBagSummary__ProductRecs for mobile device', () => {
    store.getState().global.isMobileDevice = true;
    component = mountWithIntl(
      <Provider store={ store }>
        <AddToBagModal/>
      </Provider>
    );
    expect( component.find( '.AddToBagSummary__ProductRecs' ).length ).toBe( 0 );
  } );

  it( 'should not render ProductPricingPanel when the list price is null', () => {
    const stateValues = {
      isAddToBagModalOpen:true,
      selectedQuantity:'5',
      productImage:'https://images.ulta.com/is/image/Ulta/2236259?$sm$',
      brandName:'OPI',
      displayName:'product display name',
      variant:{
        variantDesc:'product variant'
      },
      listPrice:null,
      salePrice:{
        amount:'8.99',
        currencyCode:'USD'
      },
      hasOnlyListPrice: false,
      recommendedProducts :{
        'items': [
          {
            'placementName': 'error_page.horizontal',
            'strategyMesssage': 'May We Suggest',
            'products': {
              'items': [
                {
                  'adbugMessage': null,
                  'product': {
                    'activeSkusCount': 1,
                    'displayName': 'Online Only On The Glow Highlighting Palette',
                    'actionUrl': '/on-glow-highlighting-palette?productId=xlsImpprod15931211',
                    'isGWP': false,
                    'id': 'xlsImpprod15931211',
                    'title': 'Ofra Cosmetics Online Only On The Glow Highlighting Palette | Ulta Beauty',
                    'multiSku': false,
                    'defaultSku': '2511222'
                  },
                  'category': {
                    'displayName': 'Contouring',
                    'id': 'cat510002'
                  },
                  'sku': {
                    'badges': {
                      'items': [
                        {
                          'badgeName': 'Online Only',
                          'priority': 7,
                          'badgeImageUrl': 'https://images.ulta.com/is/image/Ulta/badge-online-only'
                        }
                      ]
                    },
                    'images': {
                      'blowupImage': 'https://images.ulta.com/is/image/Ulta/2511222?$detail$',
                      'mainImage': 'https://images.ulta.com/is/image/Ulta/2511222',
                      'largeImage': 'https://images.ulta.com/is/image/Ulta/2511222?$lg$',
                      'smallImage': 'https://images.ulta.com/is/image/Ulta/2511222?$sm$',
                      'thumbnailImage': 'https://images.ulta.com/is/image/Ulta/2511222?$tn$',
                      'mediumImageUrl': 'https://images.ulta.com/is/image/Ulta/2511222?$md$'
                    },
                    'displayName': null,
                    'price': {
                      'showListRange': true,
                      'lowRangeListPrice': 110,
                      'salePrice': null,
                      'showListAndSaleRange': false,
                      'highRangeSalePrice': 0,
                      'lowRangeSalePrice': 0,
                      'highRangeListPrice': 110,
                      'listPrice': {
                        'displayAmount': '$110.00',
                        'amount': 110,
                        'currencyCode': 'USD'
                      }
                    },
                    'variant': null,
                    'id': '2511222'
                  },
                  'brand': {
                    'brandName': 'Ofra Cosmetics',
                    'brandId': 'xlsImp52500002'
                  },
                  'reviewSummary': {
                    'reviewCount': 0,
                    'rating': 0
                  },
                  'promotion': null
                }
              ]
            }
          }
        ]
      }
    }


    store.getState().addtobag = stateValues;

    let component = mountWithIntl(
      <Provider store={ store }>
        <AddToBagModal/>
      </Provider>
    );
    expect( component.find( '.ProductPricingPanel' ).length ).toBe( 0 );
  } );

  it( 'closeAddToBagModal should dispatch the proper action', () => {

    const mdp = mapDispatchToProps( dispatch );
    mdp.closeAddToBagModal( {} );
    expect( dispatch ).toHaveBeenCalledWith( closeAddToBagModal() );
  } );

} );

describe( 'a2cRfkId cases', () => {

  it( 'should return a2cRfkId with the corresponding value from pageToRfkWidgetIdMapping  ', () => {
    const state = {
      global:{
        switchData:{
          switches:{
            pageToRfkWidgetIdMapping:{
              addToCartPage:'RFK_ATC'
            }
          }
        }
      }
    }
    const props = mapStateToProps( state );
    expect( props.a2cRfkId ).toBe( 'RFK_ATC' );
  } );

  it( 'should return a2cRfkId as undefined if switchData is not available ', () => {
    const state = {
      global:{
      }
    }
    const props = mapStateToProps( state );
    expect( props.a2cRfkId ).toBe( undefined );

  } );
} )
