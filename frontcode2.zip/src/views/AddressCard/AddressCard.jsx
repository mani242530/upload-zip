import React from 'react';
import PropTypes from 'prop-types';
import './AddressCard.css';

import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import Divider from 'ulta-fed-core/dist/js/views/Divider/Divider';
import Anchor from 'ulta-fed-core/dist/js/views/Anchor/Anchor';
import RadioButton from 'ulta-fed-core/dist/js/views/RadioButton/RadioButton';
import messages from './AddressCard.messages';
import 'ulta-fed-core/dist/js/views/Gutter/Gutter.css';


const propTypes = {
  selectShippingAddress: PropTypes.func,
  editShippingAddress: PropTypes.func
}


const AddressCard = ( props ) => {

  /**
   * Create a AddressCard
   */
  const {
    index,
    refId,
    isDefault,
    isSelected,
    firstName,
    lastName,
    address1,
    address2,
    city,
    state,
    postalCode,
    phoneNumber
  } = props;


  /**
   * Renders the AddressCard component
   */

  return (
    <div className='AddressCard Gutter'>
      <RadioButton
        id={ refId + '-' + index }
        name='changeShippingAddress'
        value={ refId }
        isChecked={ isSelected === true }
        onClick={ () => {
          props.selectShippingAddress( refId );
        } }
      >
        <div className='AddressCard__Item'>
          <div className='AddressCard__Item--bold'>
            <span>{ firstName }</span>
            <span>
              { ' ' }
              { lastName }
            </span>
            {
              isDefault &&
              <span> (Primary)</span>
            }
          </div>

          <div className='AddressCard__Item--normal'>
            <span>{ address1 }</span>
            {
              address2 &&
              (
                <span>
                  { ' ' }
                  { address2 }
                </span>
              )
            }
            <span>
,
              { city }
            </span>
            <span>
              { ' ' }
              { state }
            </span>
            <span>
              { ' ' }
              { postalCode }
            </span>
            <div>
              { ' ' }
              { phoneNumber }
              { ' ' }
            </div>
          </div>
        </div>
      </RadioButton>
      <div className='AddressCard__Item--bottom'>
        <div className='AddressCard__line'>
          <Divider dividerType='gray' />
        </div>
        <div className='AddressCard__Item--normal AddressCard__Item--data'>
          <Anchor
            url='#'
            clickHandler={ () => props.editShippingAddress( props ) }
            ariaLabel={ formatMessage( messages.edit ) + ' ' + address1 + ' ' + formatMessage( messages.address ) }
            title={ formatMessage( messages.edit ) + ' ' + address1 + ' ' + formatMessage( messages.address ) }
          >
            { formatMessage( messages.edit ) }
          </Anchor>
        </div>
      </div>

    </div>
  );
}

AddressCard.propTypes = propTypes;

export default AddressCard;
