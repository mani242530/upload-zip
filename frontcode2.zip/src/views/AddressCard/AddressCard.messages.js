/*
 * AddressCard Messages
 *
 * This contains all the text for the AddressCard component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.AddressCard.header',
    defaultMessage: 'This is the AddressCard component !'
  },
  remove: {
    id: 'i18n.AddressCard.remove',
    defaultMessage: 'Remove'
  },
  edit: {
    id: 'i18n.AddressCard.edit',
    defaultMessage: 'Edit'
  },
  address: {
    id: 'i18n.AddressCard.edit',
    defaultMessage: 'Address'
  }
} );
