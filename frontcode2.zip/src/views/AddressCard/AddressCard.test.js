import React from 'react';
import ReactDOM from 'react-dom';
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import { Provider } from 'react-redux';
import { reduxForm } from 'redux-form';
import AddressCard from './AddressCard';
import messages from './AddressCard.messages';
import configureStore from '../../modules/ccr/ccr.store'
import CONFIG from '../../modules/ccr/ccr.config';

const Decorator = reduxForm( { form:'testForm' } )( AddressCard );
describe( '<AddressCard />', () => {
  let component;
  let props = {
    selectShippingAddress:jest.fn(),
    address: {
      contactInfo: {
        address1: '2491 Warm Springs Lane',
        city :'Naperville',
        firstName:'',
        lastName:'Muller',
        phoneNumber:'510-213-8348',
        postalCode:'60564',
        state:'IL'
      },
      isDefault:false,
      isSelected:true
    },
    refId: 'forRadioButtonValue'
  };
  const store = configureStore( {}, CONFIG );
  component = mountWithIntl(
    <Provider store={ store }>
      <Decorator { ...props }/>
    </Provider>
  );
  it( 'renders without crashing', () => {
    expect( component.find( 'AddressCard' ).length ).toBe( 1 );
  } );
  it( 'renders without crashing', () => {
    expect( component.find( 'RadioButton' ).length ).toBe( 1 );
  } );
  it( 'renders without crashing', () => {
    expect( component.find( '.AddressCard__Item--bold' ).length ).toBe( 1 );
  } );
  it( 'renders without crashing', () => {
    expect( component.find( '.AddressCard__Item--normal' ).length ).toBe( 2 );
  } );
  it( 'renders without crashing', () => {
    expect( component.find( 'Divider' ).length ).toBe( 1 );
  } );
  it( 'renders without crashing', () => {
    let text = messages.edit.defaultMessage;
    expect( component.find( '.AddressCard__Item--data' ).text() ).toBe( text );
  } );
  it( 'Invokes selectShippingAddress on click of RadioButton', () => {
    const selectShippingAddressMock = jest.fn( ) ;
    props.selectShippingAddress = selectShippingAddressMock ;
    const component =  mountWithIntl(
      <Provider store={ store }>
        <Decorator { ...props }/>
      </Provider>
    );
    const node = component.find( 'AddressCard' );
    component.find( 'RadioButton' ).find( 'input' ).simulate( 'click' );
    expect( selectShippingAddressMock ).toBeCalled();
  } );


  it( 'Invokes editShippingAddress on click of Anchor ', () => {
    const editShippingAddress = jest.fn( ) ;
    props.editShippingAddress = editShippingAddress ;
    const component =  mountWithIntl(
      <Provider store={ store }>
        <Decorator { ...props }/>
      </Provider>
    );
    const node = component.find( 'AddressCard' );
    component.find( 'Anchor' ).simulate( 'click' );
    expect( editShippingAddress ).toBeCalled();
  } );

} );
