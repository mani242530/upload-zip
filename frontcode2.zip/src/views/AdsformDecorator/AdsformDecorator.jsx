/**
 * AdsformDecorator
 */

import React from 'react';
import PropTypes from 'prop-types';
import './AdsformDecorator.css';
import Divider from 'ulta-fed-core/dist/js/views/Divider/Divider';
import Image from 'ulta-fed-core/dist/js/views/Image/Image';
import CancelAndReturn from 'ulta-fed-core/dist/js/views/CancelAndReturn/CancelAndReturn';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import messages from './AdsformDecorator.messages';

const propTypes = {
  bannerImageUri: PropTypes.string,
  cancelSteps: PropTypes.number
}

const defaultProps = {
  bannerImageUri: 'https://images.ulta.com/is/image/Ulta/wk1117_m_banner_ccard_application_header_fallback'
}

/**
 * Class
 * @extends React.Component
 */
const AdsformDecorator = ( props ) => {

  /**
   * Create a AdsformDecorator
   */
  const {
    bannerImageUri
  } = props;


  /**
   * Renders the AdsformDecorator component
   */

  return (
    <div className='AdsformDecorator'>
      <div className='AdsformDecorator__divider'>

        <Divider dividerType='gray' />
      </div>

      <CancelAndReturn
        cancelText={ formatMessage( messages.cancel ) }
        history={ global.history }
        cancelSteps={ props.cancelSteps }
      />

      <div className='AdsformDecorator__banner'>
        <Image
          src={ bannerImageUri }
          alt={ formatMessage( messages.title ) }
          scale='scl=1'
        />
      </div>

      <div
        className='AdsformDecorator__container'
        id='js-AdsformDecorator__container'
      >
        { props.children }
      </div>

    </div>
  );
}

AdsformDecorator.propTypes = propTypes;
AdsformDecorator.defaultProps = defaultProps;

export default AdsformDecorator;
