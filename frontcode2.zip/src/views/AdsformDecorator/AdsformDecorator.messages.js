/*
 * AdsformDecorator Messages
 *
 * This contains all the text for the MobileBodi component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  title: {
    id: 'i18n.AdsformDecorator.title',
    defaultMessage: 'Apply for the Ultamate Rewards Credit Card'
  },
  cancel: {
    id: 'i18n.AdsformDecorator.cancel',
    defaultMessage: 'CANCEL & RETURN'
  }
} );
