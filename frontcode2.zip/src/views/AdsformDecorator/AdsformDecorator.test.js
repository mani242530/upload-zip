import React from 'react';
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import AdsformDecorator from './AdsformDecorator';

describe( '<AdsformDecorator />', () => {
  let component;

  it( 'renders without crashing', () => {
    component = mountWithIntl( <AdsformDecorator /> );
    expect( component.find( 'AdsformDecorator' ).length ).toBe( 1 );
  } );
} );
