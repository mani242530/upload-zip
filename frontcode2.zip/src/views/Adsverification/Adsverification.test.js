import React from 'react';
import ReactDOM from 'react-dom';
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import Adsverification from './Adsverification';


describe( '<Adsverification />', () => {
  let component;
  window.requestAnimationFrame = jest.fn();
  it( 'renders without crashing', () => {
    let props = {
      location:{
        state:{
          ADSValidated:false
        }
      }
    }
    component = mountWithIntl(
      <Adsverification bannerImageUri='http://images.ulta.com/is/image/Ulta/wk1117_m_banner_ccard_application_header'
        history='/CreditCardApplyForm'
        { ...props }
      />
    );
    expect( component.find( 'Adsverification' ).length ).toBe( 1 );
  } );
} );
