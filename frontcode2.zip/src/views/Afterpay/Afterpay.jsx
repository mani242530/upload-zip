/**
 * Afterpay
 */

import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import Button20 from 'ulta-fed-core/dist/js/views/Button20/Button20';
import Text from 'ulta-fed-core/dist/js/views/Text/Text';
import Anchor from 'ulta-fed-core/dist/js/views/Anchor/Anchor';
import { getActionDefinition } from 'ulta-fed-core/dist/js/events/services/services.events';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import ResponseMessages from 'ulta-fed-core/dist/js/views/ResponseMessages/ResponseMessages';
import AfterpaySvg from '../../static/Afterpay';
import messages from './Afterpay.messages';
import appConstants from '../../shared/appConstants';
import { resetUpdateAfterpayWidgetFlag } from '../../events/after_pay/after_pay.events'
import './Afterpay.css';

/**
 * Class
 * @extends React.Component
 */
class Afterpay extends Component{

  constructor( props ){
    super( props );
    this.initializeAfterpayWidget = this.initializeAfterpayWidget.bind( this );
    this.updateAfterpayWidget = this.updateAfterpayWidget.bind( this );
    this.handleAfterpayRedirect = this.handleAfterpayRedirect.bind( this );
  }

  afterpayTextClassName = 'Afterpay__interestFreePayments--Text'; // this classname is used for the container where afterpay text widget is loaded


  afterpayPieChartsClassName = 'Afterpay__interestFreePayments--pieCharts'; // this classname is used for the container where afterpay harveyBalls(pieChart) widget is loaded


  apConfig = {
    amount: this.props.estimatedTotalInCents,
    priceSelector: `.${ this.afterpayTextClassName }`,
    locale: 'en_US',
    currency: 'USD',
    replaceModalOpenIcon: formatMessage( messages.learnMore ),
    textType: 'none',
    payments: true,
    modalContent: 'ulta'
  };

  initializeAfterpayWidget(){
    // update the updateAfterpaywidget flag
    this.props.resetUpdateAfterpayWidgetFlag();
    // show the afterpay text widget by invoking init() from afterpay script loaded on page
    new presentAfterpay( this.apConfig ).init(); // eslint-disable-line
    // show afterpay pie chart widget by invoking harveyBalls() from afterpay script loaded on page
    new presentAfterpay( { ...this.apConfig, priceSelector: `.${ this.afterpayPieChartsClassName }` } ).harveyBalls(); //eslint-disable-line
  }

  updateAfterpayWidget(){
    // update the updateAfterpaywidget flag
    this.props.resetUpdateAfterpayWidgetFlag();
    // update the afterpay widgets with updated order total
    new presentAfterpay( { ...this.apConfig, amount: this.props.estimatedTotalInCents } ).refresh([`.${ this.afterpayTextClassName }`, `.${ this.afterpayPieChartsClassName }`]); // eslint-disable-line
  }

  componentDidMount(){
    if( this.props.afterpayEligible ){
      // show the afterpay widget
      this.initializeAfterpayWidget();
      if( this.props.isAfterpayTokenRequired ){
        this.props.getAfterpayToken();
      }
    }
  }

  handleAfterpayRedirect(){
    AfterPay.initialize( { countryCode: 'US' } );
    AfterPay.redirect( { token: this.props.afterpayClientToken } );
  }

  /**
   * Renders the Afterpay component
   */
  render(){
    // check if we need to update the afterpay widget this would check if order total has changed
    if( this.props.updateAfterpayWidget ){
      // update the after pay widgets if the order total has changed.
      this.updateAfterpayWidget();
    }
    return (
      <div className='Afterpay'>
        { this.props.afterpayErrorMessage &&
          <div className='Afterpay__errorMessage'>
            { this.props.afterpayErrorMessage.map( ( message, index ) =>{
              return (
                <ResponseMessages
                  messageType={ message.type }
                  message={ message.message }
                  key={ index }
                  broadCastAdaMessage={ true }
                />
              );
            } )
            }
          </div>
        }
        { this.props.afterpayEligible &&
          <Fragment>
            <div className={ this.afterpayTextClassName }></div>
            <div className={ this.afterpayPieChartsClassName }></div>
          </Fragment>
        }
        { // if renderAfterpayButton is true, show afterpay button with after pay instructional text
          this.props.renderAfterpayButton &&
          <div className='Afterpay__buttonContainer'>
            <Button20
              type='button'
              size='large'
              clickEventHandler={ this.handleAfterpayRedirect }
              { ...( this.props.isMobileDevice && { block: true } ) }
            >
              <Text
                htmlTag='span'
                type='body-1'
                fontWeight='bold'
              >
                { formatMessage( messages.payNowWith ) }
              </Text>
              <AfterpaySvg/>
            </Button20>
            <Text
              type='caption'
              textAlign='center'
            >
              { formatMessage( messages.afterpayInstructionalText ) }
            </Text>
          </div>
        }
        <Text
          type='caption'
          textAlign='center'
        >
          <Anchor
            displayType='secondary'
            url={ appConstants.URLS.PURCHASE_PAYMENT_AGREEMENT }
          >
            { formatMessage( messages.purchaseAgreement ) }
          </Anchor>
        </Text>
      </div>
    );
  }
}

export const mapStateToProps = ( state ) =>{
  return {
    isMobileDevice: state.global.isMobileDevice,
    updateAfterpayWidget: state.afterpay.updateAfterpayWidget,
    estimatedTotalInCents: state.afterpay.estimatedTotalInCents,
    afterpayEligible: state.afterpay.afterpayEligible,
    afterpayErrorMessage: state.afterpay.afterpayErrorMessage,
    renderAfterpayButton: state.afterpay.renderAfterpayButton,
    isAfterpayTokenRequired: state.afterpay.isAfterpayTokenRequired,
    afterpayClientToken: state.afterpay.afterpayClientToken
  };
}

export const mapDispatchToProps = ( dispatch ) =>{
  return {
    getAfterpayToken: ( ) =>{
      dispatch( getActionDefinition( 'afterpayToken', 'requested' )() );
    },
    resetUpdateAfterpayWidgetFlag: () =>{
      dispatch( resetUpdateAfterpayWidgetFlag() )
    }
  }
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return ( connect( mapStateToProps, mapDispatchToProps )( Afterpay ) );
};

export default connectFunction( mapStateToProps, mapDispatchToProps );
