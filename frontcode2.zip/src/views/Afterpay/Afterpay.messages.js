/*
 * Afterpay Messages
 *
 * This contains all the text for the Afterpay component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  afterpayInstructionalText: {
    id: 'i18n.Afterpay.afterpayInstructionalText',
    defaultMessage: 'You will be redirected to the Afterpay website to fill out your payment information. You will be redirected back to our site to complete your order.'
  },
  purchaseAgreement: {
    id: 'i18n.Afterpay.purchaseAgreement',
    defaultMessage: 'Purchase Payment Agreement'
  },
  payNowWith: {
    id: 'i18n.Afterpay.payNowWith',
    defaultMessage: 'Pay now with'
  },
  learnMore: {
    id: 'i18n.Afterpay.learnMore',
    defaultMessage: 'Learn More'
  }
} );
