import React from 'react';
import { Provider } from 'react-redux';
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import {
  getActionDefinition,
  registerServiceName
} from 'ulta-fed-core/dist/js/events/services/services.events';
import AfterpaySvg from '../../static/Afterpay';
import Afterpay, {
  connectFunction,
  mapStateToProps,
  mapDispatchToProps
} from './Afterpay';
import configureStore from '../../modules/ccr/ccr.store'
import CONFIG from '../../modules/ccr/ccr.config';
import appConstants from '../../shared/appConstants';
import { resetUpdateAfterpayWidgetFlag } from '../../events/after_pay/after_pay.events'

beforeAll( () => {
  Object.defineProperty( global, 'AfterPay', {
    writable: true,
    value: {
      initialize: jest.fn().mockName( 'initialize' ),
      redirect: jest.fn().mockName( 'redirect' )
    }
  } );
} );

afterAll( () => {
  Object.defineProperty( global, 'AfterPay', {
    writable: true,
    value: undefined
  } );
} );

const store = configureStore( {}, CONFIG );
store.getState().global = {
  isMobileDevice: true
}
describe( '<Afterpay />', () => {

  const props = {
    isMobileDevice: false,
    estimatedTotal: '$35.00'
  }
  let component = mountWithIntl(
    <Provider store={ store }>
      <Afterpay { ...props } />
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'Afterpay' ).length ).toBe( 1 );
  } );

  it( 'should render purchaseAgreement link', () => {
    expect( component.find( '.Afterpay Text' ).length ).toBe( 1 );
    expect( component.find( '.Afterpay Text' ).props().type ).toBe( 'caption' );
    expect( component.find( '.Afterpay Text' ).props().textAlign ).toBe( 'center' );
    expect( component.find( '.Afterpay Text' ).find( 'Anchor' ).props().displayType ).toBe( 'secondary' );
    expect( component.find( '.Afterpay Text' ).find( 'Anchor' ).props().url ).toBe( appConstants.URLS.PURCHASE_PAYMENT_AGREEMENT );
    expect( component.find( '.Afterpay Text' ).find( 'Anchor' ).text() ).toBe( 'Purchase Payment Agreement' );
  } );

  it( 'should render afterPayText and afterPayPieCharts if afterpayEligible is true', () => {
    store.getState().afterpay = {
      afterpayEligible: true
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <Afterpay { ...props } />
      </Provider>
    );
    expect( component.find( '.Afterpay__interestFreePayments--Text' ).length ).toBe( 1 );
    expect( component.find( '.Afterpay__interestFreePayments--pieCharts' ).length ).toBe( 1 );
  } );

  it( 'should not render afterPayText and afterPayPieCharts if afterpayEligible is false', () => {
    store.getState().afterpay = {
      afterpayEligible: false
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <Afterpay { ...props } />
      </Provider>
    );
    expect( component.find( '.Afterpay__interestFreePayments--Text' ).length ).toBe( 0 );
    expect( component.find( '.Afterpay__interestFreePayments--pieCharts' ).length ).toBe( 0 );
  } );

  it( 'should render Afterpay__buttonContainer and its props if renderAfterpayButton is true', () => {
    store.getState().afterpay = {
      renderAfterpayButton: true
    }
    store.getState().global = {
      isMobileDevice: false
    }

    const component = mountWithIntl(
      <Provider store={ store }>
        <Afterpay { ...props } />
      </Provider>
    );
    expect( component.find( '.Afterpay__buttonContainer' ).length ).toBe( 1 );
    expect( component.find( '.Afterpay__buttonContainer Button20' ).length ).toBe( 1 );
    expect( component.find( '.Afterpay__buttonContainer Button20' ).props().type ).toBe( 'button' );
    expect( component.find( '.Afterpay__buttonContainer Button20' ).props().size ).toBe( 'large' );
    expect( component.find( '.Afterpay__buttonContainer Button20' ).props().block ).toBeFalsy();
    expect( component.find( '.Afterpay__buttonContainer Button20 Text' ).length ).toBe( 1 );
    expect( component.find( '.Afterpay__buttonContainer Button20 Text' ).props().htmlTag ).toBe( 'span' );
    expect( component.find( '.Afterpay__buttonContainer Button20 Text' ).props().type ).toBe( 'body-1' );
    expect( component.find( '.Afterpay__buttonContainer Button20 Text' ).props().fontWeight ).toBe( 'bold' );
    expect( component.find( '.Afterpay__buttonContainer Button20 Text' ).text() ).toBe( 'Pay now with' );
    expect( component.find( '.Afterpay__buttonContainer Button20' ).find( AfterpaySvg ).length ).toBe( 1 );
  } );

  it( 'should call afterpay initialize and redirect methods on click of Afterpay button', () => {
    const initializeSpy = jest.spyOn( global.AfterPay, 'initialize' );
    const redirectSpy = jest.spyOn( global.AfterPay, 'redirect' );

    store.getState().afterpay = {
      renderAfterpayButton: true,
      afterpayClientToken: 'test token'
    }
    store.getState().global = {
      isMobileDevice: false
    }

    const component = mountWithIntl(
      <Provider store={ store }>
        <Afterpay { ...props } />
      </Provider>
    );
    component.find( '.Afterpay__buttonContainer Button20' ).simulate( 'click' );

    expect( initializeSpy ).toHaveBeenCalledWith( { countryCode: 'US' } );
    expect( redirectSpy ).toHaveBeenCalledWith( { token: 'test token' } );
  } );

  it( 'should pass block prop as true for Afterpay button if isMobileDevice is true', () => {
    store.getState().global = {
      switchData: {
        switches: {
          enableAfterpay: false
        }
      },
      isMobileDevice: true
    };
    const component = mountWithIntl(
      <Provider store={ store }>
        <Afterpay { ...props } />
      </Provider>
    );
    expect( component.find( '.Afterpay__buttonContainer Button20' ).props().block ).toBe( true );
  } );

  it( 'should render afterPayInstructionalText if renderAfterpayButton is true', () => {
    store.getState().afterpay = {
      renderAfterpayButton: true
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <Afterpay { ...props } />
      </Provider>
    );
    expect( component.find( '.Afterpay__buttonContainer Text' ).at( 1 ).length ).toBe( 1 );
    expect( component.find( '.Afterpay__buttonContainer Text' ).at( 1 ).props().type ).toBe( 'caption' );
    expect( component.find( '.Afterpay__buttonContainer Text' ).at( 1 ).props().textAlign ).toBe( 'center' );
    expect( component.find( '.Afterpay__buttonContainer Text' ).at( 1 ).text() ).toBe( 'You will be redirected to the Afterpay website to fill out your payment information. You will be redirected back to our site to complete your order.' );
  } );


  it( 'should not render Afterpay__buttonContainer button and afterPayInstructionalText if renderAfterpayButton is false', () => {
    store.getState().afterpay = {
      renderAfterpayButton: false
    }
    const props = {
      isMobileDevice: true
    }
    const component = mountWithIntl(
      <Provider store={ store }>
        <Afterpay { ...props } />
      </Provider>
    );
    expect( component.find( '.Afterpay__buttonContainer' ).length ).toBe( 0 );
    expect( component.find( '.Afterpay__buttonContainer Button20' ).length ).toBe( 0 );
    expect( component.find( '.Afterpay__buttonContainer Text' ).at( 1 ).length ).toBe( 0 );
  } );

  it( 'should trigger resetUpdateAfterpayWidgetFlag method if updateAfterpayWidget is true', () => {
    const resetUpdateAfterpayWidgetFlagMock = jest.fn();
    store.getState().afterpay = {
      updateAfterpayWidget: true
    }
    let mapDispatchToPropsMock = ( dispatch ) =>{
      return {
        getAfterpayToken : jest.fn(),
        resetUpdateAfterpayWidgetFlag: resetUpdateAfterpayWidgetFlagMock
      }
    }
    const AfterpayMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    const component = mountWithIntl(
      <Provider store={ store }>
        <AfterpayMock { ...props } />
      </Provider>
    );

    expect( resetUpdateAfterpayWidgetFlagMock ).toBeCalled();
  } );

  it( 'should not trigger resetUpdateAfterpayWidgetFlag if updateAfterpayWidget is false', () => {
    const resetUpdateAfterpayWidgetFlagMock = jest.fn();
    store.getState().afterpay = {
      updateAfterpayWidget: false
    }
    let mapDispatchToPropsMock = ( dispatch ) =>{
      return {
        getAfterpayToken : jest.fn(),
        resetUpdateAfterpayWidgetFlag: resetUpdateAfterpayWidgetFlagMock
      }
    }
    const AfterpayMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
    let component = mountWithIntl(
      <Provider store={ store }>
        <AfterpayMock { ...props } />
      </Provider>
    );

    expect( resetUpdateAfterpayWidgetFlagMock ).not.toBeCalled();
  } );

  it( 'should render Afterpay__errorMessage if afterPayErrorMessage is not empty', () => {
    store.getState().afterpay = {
      updateAfterpayWidget: false,
      afterpayErrorMessage: [
        {
          type: 'error',
          message: 'error message'
        }
      ]
    }
    let component = mountWithIntl(
      <Provider store={ store }>
        <Afterpay { ...props } />
      </Provider>
    );
    expect( component.find( '.Afterpay__errorMessage' ).length ).toBe( 1 );
    expect( component.find( '.Afterpay__errorMessage ResponseMessages' ).length ).toBe( 1 );
    expect( component.find( '.Afterpay__errorMessage ResponseMessages' ).props().messageType ).toBe( 'error' );
    expect( component.find( '.Afterpay__errorMessage ResponseMessages' ).props().message ).toBe( 'error message' );
    expect( component.find( '.Afterpay__errorMessage ResponseMessages' ).props().broadCastAdaMessage ).toBe( true );
  } );

  it( 'should not render Afterpay__errorMessage if afterPayErrorMessage is empty', () => {
    store.getState().afterpay = {
      afterPayErrorMessage: null
    }
    let component = mountWithIntl(
      <Provider store={ store }>
        <Afterpay { ...props } />
      </Provider>
    );
    expect( component.find( '.Afterpay__errorMessage' ).length ).toBe( 0 );
  } );

  describe( 'initializeAfterpayWidget', () => {
    window.presentAfterpay = jest.fn( () => {
      return {
        init: jest.fn(),
        harveyBalls: jest.fn(),
        refresh: jest.fn()
      }
    } );
    it( 'should trigger resetUpdateAfterpayWidgetFlag', () => {
      const resetUpdateAfterpayWidgetFlagMock = jest.fn();
      let mapDispatchToPropsMock = ( dispatch ) =>{
        return {
          getAfterpayToken : jest.fn(),
          resetUpdateAfterpayWidgetFlag: resetUpdateAfterpayWidgetFlagMock
        }
      }
      const AfterpayMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
      let component = mountWithIntl(
        <Provider store={ store }>
          <AfterpayMock { ...props } />
        </Provider>
      );
      component.find( 'Afterpay' ).instance().initializeAfterpayWidget();
      expect( resetUpdateAfterpayWidgetFlagMock ).toBeCalled();
    } );
    it( 'should trigger presentAfterpay method for afterPay text passing expected apConfig', () => {
      store.getState().afterpay = {
        estimatedTotalInCents: 3500
      }
      let component = mountWithIntl(
        <Provider store={ store }>
          <Afterpay { ...props } />
        </Provider>
      );
      component.find( 'Afterpay' ).instance().initializeAfterpayWidget();

      const expectedApConfig = {
        amount: props.estimatedTotalInCents,
        priceSelector: '.Afterpay__interestFreePayments--Text',
        locale: 'en_US',
        currency: 'USD',
        replaceModalOpenIcon: 'Learn More',
        textType: 'none',
        payments: true,
        modalContent: 'ulta'
      };
      expect( window.presentAfterpay ).toHaveBeenCalledWith( expectedApConfig );
    } );

    it( 'should trigger presentAfterpay method for pie charts passing expected apConfig', () => {
      store.getState().afterpay = {
        estimatedTotalInCents: 3500
      }
      let component = mountWithIntl(
        <Provider store={ store }>
          <Afterpay { ...props } />
        </Provider>
      );
      component.find( 'Afterpay' ).instance().initializeAfterpayWidget();

      const expectedApConfig = {
        amount: props.estimatedTotalInCents,
        priceSelector: '.Afterpay__interestFreePayments--pieCharts',
        locale: 'en_US',
        currency: 'USD',
        replaceModalOpenIcon: 'Learn More',
        textType: 'none',
        payments: true,
        modalContent: 'ulta'
      };
      expect( window.presentAfterpay ).toHaveBeenCalledWith( expectedApConfig );
    } );
  } );

  describe( 'updateAfterpayWidget', () => {
    const refreshMock = jest.fn();
    window.presentAfterpay = jest.fn( () => {
      return {
        init: jest.fn(),
        harveyBalls: jest.fn(),
        refresh: refreshMock
      }
    } );
    it( 'should trigger resetUpdateAfterpayWidgetFlag', () => {
      const resetUpdateAfterpayWidgetFlagMock = jest.fn();
      const props = {
        afterpayMessage: null,
        renderAfterpayButton: false
      }
      let mapDispatchToPropsMock = ( dispatch ) =>{
        return {
          getAfterpayToken : jest.fn(),
          resetUpdateAfterpayWidgetFlag: resetUpdateAfterpayWidgetFlagMock
        }
      }
      const AfterpayMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
      let component = mountWithIntl(
        <Provider store={ store }>
          <AfterpayMock { ...props } />
        </Provider>
      );
      component.find( 'Afterpay' ).instance().updateAfterpayWidget();
      expect( resetUpdateAfterpayWidgetFlagMock ).toBeCalled();
    } );
    it( 'should trigger presentAfterpay refresh method passing expected values', () => {
      store.getState().afterpay = {
        estimatedTotalInCents: 3500
      }
      store.getState().afterpay = {
        afterpayMessage: null,
        renderAfterpayButton: false
      }
      let component = mountWithIntl(
        <Provider store={ store }>
          <Afterpay { ...props } />
        </Provider>
      );
      component.find( 'Afterpay' ).instance().updateAfterpayWidget();

      const expectedApConfig = {
        amount: props.estimatedTotalInCents,
        priceSelector: '.Afterpay__interestFreePayments--Text',
        locale: 'en_US',
        currency: 'USD',
        replaceModalOpenIcon: 'Learn More',
        textType: 'none',
        payments: true,
        modalContent: 'ulta'
      };
      const expectedData = ['.Afterpay__interestFreePayments--Text', '.Afterpay__interestFreePayments--pieCharts'];
      expect( refreshMock ).toHaveBeenCalledWith( expectedData );
      expect( window.presentAfterpay ).toHaveBeenCalledWith( expectedApConfig );
    } );
  } );

  describe( 'componentDidMount', () => {
    it( 'should trigger initializeAfterpayWidget if afterpayEligible is true on component mount', () => {
      const initializeAfterpayWidgetMock = jest.fn();
      store.getState().afterpay = {
        afterpayEligible: true
      }
      let component = mountWithIntl(
        <Provider store={ store }>
          <Afterpay { ...props } />
        </Provider>
      );
      const node = component.find( 'Afterpay' ).instance();
      node.initializeAfterpayWidget = initializeAfterpayWidgetMock;
      node.componentDidMount();
      expect( initializeAfterpayWidgetMock ).toBeCalled();
    } );

    it( 'should not trigger initializeAfterpayWidget if afterpayEligible is false', () => {
      const initializeAfterpayWidgetMock = jest.fn();
      store.getState().afterpay = {
        afterpayEligible: false
      }
      let component = mountWithIntl(
        <Provider store={ store }>
          <Afterpay { ...props } />
        </Provider>
      );
      const node = component.find( 'Afterpay' ).instance();
      node.initializeAfterpayWidget = initializeAfterpayWidgetMock;
      node.componentDidMount();

      expect( initializeAfterpayWidgetMock ).not.toBeCalled();
    } );
    it( 'should trigger getAfterpayToken if isAfterpayTokenRequired is true', () => {
      const getAfterpayTokenMock = jest.fn();
      store.getState().afterpay = {
        afterpayEligible: true,
        isAfterpayTokenRequired: true
      }
      let mapDispatchToPropsMock = ( dispatch ) =>{
        return {
          getAfterpayToken : getAfterpayTokenMock,
          resetUpdateAfterpayWidgetFlag: jest.fn()
        }
      }
      const AfterpayMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
      let component = mountWithIntl(
        <Provider store={ store }>
          <AfterpayMock { ...props } />
        </Provider>
      );
      const node = component.find( 'Afterpay' ).instance();
      node.componentDidMount();

      expect( getAfterpayTokenMock ).toBeCalled();
    } );
    it( 'should not trigger getAfterpayToken if isAfterpayTokenRequired is false', () => {
      const getAfterpayTokenMock = jest.fn();
      store.getState().afterpay = {
        afterpayEligible: true,
        isAfterpayTokenRequired: false
      }
      let mapDispatchToPropsMock = ( dispatch ) =>{
        return {
          getAfterpayToken : getAfterpayTokenMock,
          resetUpdateAfterpayWidgetFlag: jest.fn()
        }
      }
      const AfterpayMock = connectFunction( mapStateToProps, mapDispatchToPropsMock )
      let component = mountWithIntl(
        <Provider store={ store }>
          <AfterpayMock { ...props } />
        </Provider>
      );
      const node = component.find( 'Afterpay' ).instance();
      node.componentDidMount();

      expect( getAfterpayTokenMock ).not.toBeCalled();
    } );
  } );

  describe( 'MapDispatchToProps', () => {
    const dispatch = jest.fn();
    beforeEach( ()=> {
      dispatch.mockClear();
    } )
    const mdp  = mapDispatchToProps( dispatch );

    it( 'getAfterPayToken should dispatch the proper action', () => {
      registerServiceName( 'afterPayToken' );
      mdp.getAfterpayToken();
      expect( dispatch ).toHaveBeenCalledWith( getActionDefinition( 'afterpayToken', 'requested' )() );
    } );

    it( 'resetUpdateAfterpayWidgetFlag should dispatch the proper action', () => {
      mdp.resetUpdateAfterpayWidgetFlag();
      expect( dispatch ).toHaveBeenCalledWith( resetUpdateAfterpayWidgetFlag() );
    } );

  } );

  describe( 'mapStateToProps', () => {
    it( 'should map afterPay prop', () => {
      const mockState = {
        afterpay: {
          updateAfterpayWidget: false,
          afterpayEligible: false,
          renderAfterpayButton: false,
          afterpayErrorMessage: undefined,
          isAfterpayTokenRequired: false,
          afterpayClientToken: undefined
        },
        global: {
          isMobileDevice: true
        }
      };
      const expectedData = {
        updateAfterpayWidget: false,
        afterpayEligible: false,
        renderAfterpayButton: false,
        afterpayErrorMessage: undefined,
        isAfterpayTokenRequired: false,
        isMobileDevice: true,
        afterpayClientToken: undefined
      }
      expect( mapStateToProps( mockState ) ).toEqual( expectedData );
    } );
    it( 'should set updateAfterpayWidget as true if state.afterpay.updateAfterpayWidget is true', () => {
      const mockState = {
        afterpay: {
          updateAfterpayWidget: true
        },
        global: {
          isMobileDevice: true
        }
      };
      expect( mapStateToProps( mockState ).updateAfterpayWidget ).toEqual( true );
    } );
    it( 'should set afterpayEligible as true if state.afterpay.afterpayEligible is true', () => {
      const mockState = {
        afterpay: {
          afterpayEligible: true
        },
        global: {
          isMobileDevice: true
        }
      };
      expect( mapStateToProps( mockState ).afterpayEligible ).toEqual( true );
    } );
    it( 'should set renderAfterpayButton as true if state.afterpay.renderAfterpayButton is true', () => {
      const mockState = {
        afterpay: {
          renderAfterpayButton: true
        },
        global: {
          isMobileDevice: true
        }
      };
      expect( mapStateToProps( mockState ).renderAfterpayButton ).toEqual( true );
    } );
    it( 'should set isAfterpayTokenRequired as true if state.afterpay.isAfterpayTokenRequired is true', () => {
      const mockState = {
        afterpay: {
          isAfterpayTokenRequired: true
        },
        global: {
          isMobileDevice: true
        }
      };
      expect( mapStateToProps( mockState ).isAfterpayTokenRequired ).toEqual( true );
    } );
    it( 'should set afterpayErrorMessage if state.afterpay.afterpayErrorMessage is defined', () => {
      const mockState = {
        afterpay: {
          afterpayErrorMessage: [
            {
              type : 'error',
              message: 'error message'
            }
          ]
        },
        global: {
          isMobileDevice: true
        }
      };
      expect( mapStateToProps( mockState ).afterpayErrorMessage ).toEqual( mockState.afterpay.afterpayErrorMessage );
    } );
    it( 'should set afterpayClientToken if state.afterpay.afterpayClientToken is defined', () => {
      const mockState = {
        afterpay: {
          afterpayClientToken: 'testToken'
        },
        global: {
          isMobileDevice: true
        }
      };
      expect( mapStateToProps( mockState ).afterpayClientToken ).toEqual( mockState.afterpay.afterpayClientToken );
    } );
  } );
} );
