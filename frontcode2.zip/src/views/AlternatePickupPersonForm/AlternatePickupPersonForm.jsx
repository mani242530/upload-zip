import React from 'react';
import './AlternatePickupPersonForm.css';

import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';

import InputField from 'ulta-fed-core/dist/js/views/InputField/InputField';
import ToggleButton from 'ulta-fed-core/dist/js/views/ToggleButton/ToggleButton';
import {
  requiredValidation,
  validate as validationMethod,
  validationKeys
} from 'ulta-fed-core/dist/js/utils/form_validations/form_validations';
import FormValidationMessages from 'ulta-fed-core/dist/js/utils/form_validations/form_validations.messages';
import {
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';

import isUndefined from 'lodash/isUndefined';
import isEmpty from 'lodash/isEmpty';
import has from 'lodash/has';
import get from 'lodash/get';
import Text from 'ulta-fed-core/dist/js/views/Text/Text';
import messages from './AlternatePickupPersonForm.messages';

export const validateAlternatePickupPersonForm = ( props ) => {
  const {
    values
  } = props.alternatePickupPersonForm;

  const postData = {
    data:{
      alternateContactInfo:{
        firstName: values.alternateFirstName,
        lastName: values.alternateLastName,
        email:values.alternateEmailaddress
      }
    }
  }
  props.saveAlternateContactInfo( { contactInfo: postData, isAlternatePickupPersonEnable:values.isAlternatePickupPersonEnable } );


}

export const resetAlternateContactInfo = ( props ) =>{

  props.removeAlternateContactInfo( { isAlternatePickupPersonEnable:!props.pickupInformation.isDisplayAlternatePickupPersonForm } );

}

const AlternatePickupPersonForm = ( props ) => {
  return (
    <div className='AlternatePickupPersonForm Gutter'>
      <form
        onBlur={ () => {
          const isErrors = props.alternatePickupPersonForm.values && props.validate( props.alternatePickupPersonForm.values );
          if( isErrors && isEmpty( isErrors ) ){
            validateAlternatePickupPersonForm( props )
          }
        } }
      >
        <div className='AlternatePickupPersonForm__toggleButtonContainer'>
          <div
            className='AlternatePickupPersonForm__toggleButtonHeader'
            id='js-checkoutPickupAlternateHeader' /* id used to auto scroll when fails on any input field validation in alternate pickup form  */
          >
            <Text
              htmlTag='span'
              colorOverride='neutral-80'
            >
              { formatMessage( messages.alternatePickupPersonLabel ) }
            </Text>
          </div>
          <div className='AlternatePickupPersonForm__toggleButton'>
            <label htmlFor='isAlternatePickupPersonEnable' className='sr-only'>{ formatMessage( messages.alternatePickupPersonLabel ) }</label>
            <ToggleButton
              id='isAlternatePickupPersonEnable'
              name='isAlternatePickupPersonEnable'
              isChecked={ props.pickupInformation.isDisplayAlternatePickupPersonForm }
              onClick={ ()=>resetAlternateContactInfo( props ) }
            />
          </div>
        </div>

        { props.pickupInformation.isDisplayAlternatePickupPersonForm &&
          (
            <div>
              <div className='CheckoutPage__Form__FirstLastNames'>
                <div className='CheckoutPage__Form__FirstName'>
                  <InputField
                    label={ formatMessage( messages.FirstName ) }
                    type='text'
                    name='alternateFirstName'
                    autoComplete='given-name'
                    trackAnalytics={ true }
                    { ...( has( props.pickupInfo, 'alternateContactInfo.firstName.value' ) && { value: props.pickupInfo.alternateContactInfo.firstName.value } ) }
                  />
                </div>

                <div className='CheckoutPage__Form__LastName'>
                  <InputField
                    label={ formatMessage( messages.LastName ) }
                    type='text'
                    name='alternateLastName'
                    autoComplete='family-name'
                    trackAnalytics={ true }
                    { ...( has( props.pickupInfo, 'alternateContactInfo.lastName.value' ) && { value: props.pickupInfo.alternateContactInfo.lastName.value } ) }
                  />
                </div>
              </div>

              <div className='CheckoutPage__Form__email'>
                <div className='CheckoutPage__Form__emailContainer'>
                  <InputField
                    label={ formatMessage( messages.emailaddress ) }
                    type='email'
                    name='alternateEmailaddress'
                    autoComplete='email'
                    trackAnalytics={ true }
                    { ...( has( props.pickupInfo, 'alternateContactInfo.emailAddress.value' ) && { value: props.pickupInfo.alternateContactInfo.emailAddress.value } ) }
                  />
                </div>
              </div>
            </div>
          )
        }
      </form>
    </div>
  );
}

export const mapStateToProps = ( state ) => {
  return {
    alternatePickupPersonForm: ( state.form.AlternatePickupPersonForm ),
    pickupInformation: state.BOPIS.pickupInformation,
    pickupInfo: state.checkoutPage.checkoutServicesData.pickupInfo
  };
}

export const mapDispatchToProps = ( dispatch ) => {
  return {
    saveAlternateContactInfo: ( data ) =>{
      dispatch( getActionDefinition( 'pickupContactInfoUpdate', 'requested' )( data ) );
    },
    removeAlternateContactInfo: ( data ) =>{
      dispatch( getActionDefinition( 'removeAlternateContactInfo', 'requested' )( data ) );
    }
  };
}

export const validate = ( values ) => {
  const errors = {};
  let requiredFields = [];

  requiredFields = ['alternateFirstName', 'alternateLastName', 'alternateEmailaddress'];
  requiredFields.map(
    field => {
      if( !values[field] ){
        errors[ field ] = requiredValidation( values[ field ] );
      }
    }
  );

  // check the alternateFirstName validation and add to error object, if any errros
  let validateAlternateFirstName = validationMethod( values['alternateFirstName'], validationKeys.firstValidateName, FormValidationMessages.validateFirstName );
  if( values['alternateFirstName'] && !isUndefined( validateAlternateFirstName ) ){
    errors['alternateFirstName'] = validateAlternateFirstName;
  }

  // check the alternateLastName validation and add to error object, if any errros
  let validateAlternateLastName = validationMethod( values['alternateLastName'], validationKeys.lastValidateName, FormValidationMessages.validateLastName );
  if( values['alternateLastName'] && !isUndefined( validateAlternateLastName ) ){
    errors['alternateLastName'] = validateAlternateLastName;
  }

  // check the alternateEmailaddress validation and add to error object, if any errros
  let validateAlternateEmailaddress = validationMethod( values['alternateEmailaddress'], validationKeys.validateEmail, FormValidationMessages.invalidEmail );
  if( values['alternateEmailaddress'] && !isUndefined( validateAlternateEmailaddress ) ){
    errors['alternateEmailaddress'] = validateAlternateEmailaddress;
  }

  return errors;
}

export const connectFunction = ( mapStateToProps, mapDispatchToProps ) => {
  return reduxForm( {
    form: 'AlternatePickupPersonForm',
    validate
  } )( connect( mapStateToProps, mapDispatchToProps )( AlternatePickupPersonForm ) );
};

export default connectFunction( mapStateToProps, mapDispatchToProps );
