/*
 * AlternatePickupPersonForm Messages
 *
 * This contains all the text for the AlternatePickupPersonForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  alternatePickupPersonLabel: {
    id: 'i18n.AlternatePickupPersonForm.alternatePickupPersonLabel',
    defaultMessage: 'Add an Alternate Pickup Person (optional)'
  },
  FirstName: {
    id: 'i18n.AlternatePickupPersonForm.FirstName',
    defaultMessage: 'First Name'
  },
  LastName: {
    id: 'i18n.AlternatePickupPersonForm.LastName',
    defaultMessage: 'Last Name'
  },
  emailaddress: {
    id: 'i18n.AlternatePickupPersonForm.emailaddress',
    defaultMessage: 'Email Address'
  }
} );
