import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { mountWithIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import {
  getActionDefinition
} from 'ulta-fed-core/dist/js/events/services/services.events';
import AlternatePickupPersonForm, {
  connectFunction,
  mapStateToProps,
  mapDispatchToProps,
  validateAlternatePickupPersonForm,
  validate
} from './AlternatePickupPersonForm';
import configureStore from '../../modules/ccr/ccr.store';
import CONFIG from '../../modules/ccr/ccr.config';
import messages from './AlternatePickupPersonForm.messages';


const dispatch = jest.fn();
let mockJestFn = jest.fn();
let removeAlternateContactInfoMock = jest.fn();
let mapDispatchToPropsMock = ( dispatch ) =>{
  return {
    saveAlternateContactInfo: mockJestFn,
    removeAlternateContactInfo:removeAlternateContactInfoMock
  }
};

let props = {
  saveAlternateContactInfo:mockJestFn,
  pickupInformation: {
    tempAlternatePickupPersonData: {},
    isDisplayAlternatePickupPersonForm: true
  },
  alternatePickupPersonForm: {
    values: {
      isAlternatePickupPersonEnable: true,
      alternateFirstName : 'hello',
      alternateLastName : 'world',
      alternateEmailaddress : 'abc@efhg.com'
    },
    syncErrors: {
      alternateFirstName : undefined,
      alternateLastName : undefined,
      alternateEmailaddress : undefined
    }
  }
}

let AlternatePickupPersonFormMock = connectFunction( mapStateToProps, mapDispatchToPropsMock );

describe( '<AlternatePickupPersonForm />', () => {

  const store = configureStore( {}, CONFIG );
  store.getState().BOPIS.pickupInformation = {
    tempAlternatePickupPersonData: {},
    isDisplayAlternatePickupPersonForm: true

  };
  store.getState().form.AlternatePickupPersonForm = {
    values: {
      isAlternatePickupPersonEnable: true
    }
  };
  let component = mountWithIntl(
    <Provider store={ store }>
      <AlternatePickupPersonFormMock { ...props } />
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'AlternatePickupPersonForm' ).length ).toBe( 1 );
  } );

  it( 'Should render alternate pickup person text ', () => {
    expect( component.find( 'Text' ).text() ).toBe( messages.alternatePickupPersonLabel.defaultMessage );
  } );


  it( 'Should render ToggleButton components', () => {
    expect( component.find( 'ToggleButton' ).length ).toBe( 1 );
  } );

  it( 'The id of the toggle button and the htmlFor of the label element should match', () => {
    expect( component.find( '.AlternatePickupPersonForm__toggleButton' ).children( 'label' ).text() ).toBe( messages.alternatePickupPersonLabel.defaultMessage );
    expect( component.find( '.ToggleButton__checkbox' ).props()['id'] ).toBe( component.find( '.AlternatePickupPersonForm__toggleButton' ).children( 'label' ).props()['htmlFor'] );
  } );

  it( 'Should renders Field components', () => {
    expect( component.find( '.AlternatePickupPersonForm' ).find( 'InputField' ).length ).toBe( 3 );
  } );

  it( 'Should displays label message for the input boxes', () => {

    expect( component.find( '.CheckoutPage__Form__FirstName' ).text() ).toBe( messages.FirstName.defaultMessage );
    expect( component.find( '.CheckoutPage__Form__LastName' ).text() ).toBe( messages.LastName.defaultMessage );
    expect( component.find( '.CheckoutPage__Form__email' ).text() ).toBe( messages.emailaddress.defaultMessage );

  } );

  it( 'Should invoke validateAlternatePickupPersonForm on input field blur', () => {
    const postData = {
      data:{
        alternateContactInfo:{
          firstName: 'hello',
          lastName: 'world',
          email: 'abc@efhg.com'
        }
      }
    }
    store.getState().form = {
      AlternatePickupPersonForm : {
        values: {
          isAlternatePickupPersonEnable: true,
          alternateFirstName : 'hello',
          alternateLastName : 'world',
          alternateEmailaddress : 'abc@efhg.com'
        },
        syncErrors: {}
      }
    };
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <AlternatePickupPersonFormMock { ...props } />
      </Provider>
    );

    component1.find( '.CheckoutPage__Form__emailContainer' ).find( 'InputField' ).simulate( 'blur' );
    expect( props.saveAlternateContactInfo ).toBeCalled();
    expect( props.saveAlternateContactInfo ).toHaveBeenCalledWith( { contactInfo: postData, isAlternatePickupPersonEnable:true } );
  } );

  it( 'Should check validateAlternatePickupPersonForm function', () => {

    validateAlternatePickupPersonForm( props );
    expect( props.saveAlternateContactInfo ).toBeCalled()
  } );

  it( 'Should not render alternate pickup person form when toggle flag is false ', () => {

    store.getState().BOPIS.pickupInformation.isDisplayAlternatePickupPersonForm = false;
    store.getState().form.AlternatePickupPersonForm = {};
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <AlternatePickupPersonFormMock { ...props } />
      </Provider>
    );
    expect( component1.find( '.AlternatePickupPersonForm' ).find( 'InputField' ).length ).toBe( 0 );

  } );

  it( 'mapDispatchToProps should dispatch the proper action', () => {

    const mdp = mapDispatchToProps( dispatch );
    mdp.saveAlternateContactInfo( {} );
    expect( dispatch ).toHaveBeenCalledWith( getActionDefinition( 'pickupContactInfoUpdate', 'requested' )( {} ) );
    mdp.removeAlternateContactInfo( {} );
    expect( dispatch ).toHaveBeenCalledWith( getActionDefinition( 'removeAlternateContactInfo', 'requested' )( {} ) );
  } );

  it( 'validate should call the proper action', () => {
    let values = ['alternateFirstName', 'alternateLastName', 'alternateEmailaddress'];

    const validateForms = validate( values );
    expect( validateForms.alternateFirstName ).toBe( 'Required' );
    expect( validateForms.alternateLastName ).toBe( 'Required' );
    expect( validateForms.alternateEmailaddress ).toBe( 'Required' );
  } );

  it( 'input field should be auto populated if pickupInfo contains alternateContactInfo', () => {
    store.getState().checkoutPage = {
      checkoutServicesData: {
        pickupInfo: {
          alternateContactInfo:{
            firstName: {
              value: 'firstname'
            },
            lastName: {
              value: 'lastName'
            },
            emailAddress: {
              value: 'emailAddress'
            }
          }
        }
      }
    };
    store.getState().BOPIS.pickupInformation.isDisplayAlternatePickupPersonForm = true;
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <AlternatePickupPersonFormMock { ...props } />
      </Provider>
    );
    expect( component1.find( '.CheckoutPage__Form__FirstName' ).find( 'InputField' ).props().value ).toBe( 'firstname' );
    expect( component1.find( '.CheckoutPage__Form__LastName' ).find( 'InputField' ).props().value ).toBe( 'lastName' );
    expect( component1.find( '.CheckoutPage__Form__email' ).find( 'InputField' ).props().value ).toBe( 'emailAddress' );
  } );

  it( 'input field should be empty if pickupInfo does not contains alternateContactInfo', () => {
    store.getState().checkoutPage = {
      checkoutServicesData: {
        pickupInfo: {
          alternateContactInfo: null
        }
      }
    };
    store.getState().BOPIS.pickupInformation.isDisplayAlternatePickupPersonForm = true;
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <AlternatePickupPersonFormMock { ...props } />
      </Provider>
    );
    expect( component1.find( '.CheckoutPage__Form__FirstName' ).find( 'InputField' ).props().value ).toBe( undefined );
    expect( component1.find( '.CheckoutPage__Form__LastName' ).find( 'InputField' ).props().value ).toBe( undefined );
    expect( component1.find( '.CheckoutPage__Form__email' ).find( 'InputField' ).props().value ).toBe( undefined );
  } );

  it( 'AlternatePickupPersonForm Toggle button should be toggle on if isDisplayAlternatePickupPersonForm is true', () => {
    store.getState().BOPIS.pickupInformation.isDisplayAlternatePickupPersonForm = true;
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <AlternatePickupPersonFormMock { ...props } />
      </Provider>
    );
    expect( component1.find( '.ToggleButton input' ).props().checked ).toBe( true );
  } );

  it( 'AlternatePickupPersonForm Toggle button should be toggle off if isDisplayAlternatePickupPersonForm is false', () => {
    store.getState().BOPIS.pickupInformation.isDisplayAlternatePickupPersonForm = false;
    let component1 = mountWithIntl(
      <Provider store={ store }>
        <AlternatePickupPersonFormMock { ...props } />
      </Provider>
    );
    expect( component1.find( '.ToggleButton input' ).props().checked ).toBe( false );
  } );

  it( 'Should invoke removeAlternateContactInfo on click of ToggleButton off with alternateContactInfo:null passed in the request', () => {
    const postData = {
      data:{
        alternateContactInfo:null
      }
    }
    expect( props.saveAlternateContactInfo.mock.calls.length ).toBe( 2 );
    store.getState().BOPIS.pickupInformation = {
      isDisplayAlternatePickupPersonForm:true,
      isAlternatePickupPersonUpdated:true
    }
    store.getState().form = {
      AlternatePickupPersonForm : {
        values: {
          isAlternatePickupPersonEnable: false,
          alternateFirstName : 'hello',
          alternateLastName : 'world',
          alternateEmailaddress : 'abc@efhg.com'
        },
        syncErrors: {}
      }
    };
    component = mountWithIntl(
      <Provider store={ store }>
        <AlternatePickupPersonFormMock { ...props } />
      </Provider>
    );

    component.find( '.ToggleButton input' ).simulate( 'click' );
    expect( removeAlternateContactInfoMock.mock.calls.length ).toBe( 1 );
    expect( removeAlternateContactInfoMock ).toHaveBeenCalledWith( { isAlternatePickupPersonEnable:false } )
  } );

} );
