
/**
 * ApplyAndBuyLoginForm
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
  Link
} from 'react-router-dom';
import CancelAndReturn from 'ulta-fed-core/dist/js/views/CancelAndReturn/CancelAndReturn';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import { reduxForm } from 'redux-form';
import './ApplyAndBuyLoginForm.css';
import Divider from 'ulta-fed-core/dist/js/views/Divider/Divider';
import LoginForm from 'ulta-fed-core/dist/js/views/LoginForm/LoginForm';
import Button20 from 'ulta-fed-core/dist/js/views/Button20/Button20';
import messages from './ApplyAndBuyLoginForm.messages';


const propTypes = {
  // an indicator for the login service so it knows what URL the request is coming from.
  sourcePage: PropTypes.string.isRequired,
  successPath: PropTypes.string,
  loginMessages: PropTypes.array,
  analyticsPageName: PropTypes.string,
  analyticsChannel: PropTypes.string
}



/**
 * Class
 * @extends React.Component
 */
class ApplyAndBuyLoginForm extends Component{


  componentDidMount(){
    this.props.getBannerImage();
  }

  /**
   * Renders the ApplyAndBuyLoginForm component
   */
  render(){

    return (
      <div className='ApplyAndBuyLoginForm'>
        <div className='ApplyAndBuyLoginForm__leftPanel'>
          <LoginForm
            { ...this.props }
            scrollElementSelector='js-AdsformDecorator__container'
            title={ formatMessage( messages.getStarted ) }
            formMessage={ formatMessage( messages.applicationMessage ) }
            buttonText={ formatMessage( messages.signandapply ) }
            analyticsSourcePage='creditcard'
          />
        </div>
        <div className='ApplyAndBuyLoginForm__rightPanel'>

          <div className='CreditCards__divider'>
            <Divider dividerType='gray' />
          </div>

          <div className='ApplyAndBuyLoginForm__container'>
            <div className='ApplyAndBuyLoginForm__createAccount'>
              <div className='ApplyAndBuyLoginForm__createAccount--noAccountText'>
                { formatMessage( messages.noUltaAccount ) }
              </div>
              <div className='ApplyAndBuyLoginForm__createAccount--createAccountText'>
                { formatMessage( messages.createAppProcess ) }
              </div>
              <div className='ApplyAndBuyLoginForm__createAccount--submitButton'>
                <Link
                  to={ {
                    pathname: '/apply',
                    state: { formType: 'anonymous' }
                  } }
                >
                  <Button20
                    type='submit'
                    size='large'
                    btnStyle='secondary'
                    block={ true }
                    tabIndex={ 4 }
                  >
                    { formatMessage( messages.applyNow ) }
                  </Button20>
                </Link>
              </div>
            </div>
          </div>
          <CancelAndReturn
            cancelSteps={ -1 }
            history={ global.history }
            cancelText={ formatMessage( messages.cancel ) }
          />

        </div>
      </div>
    )
  }
}

ApplyAndBuyLoginForm.propTypes = propTypes;

export default ApplyAndBuyLoginForm;
