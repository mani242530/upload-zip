/*
 * ApplyAndBuyLoginForm Messages
 *
 * This contains all the text for the ApplyAndBuyLoginForm component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  getStarted: {
    id: 'i18n.LoginForm.signinmessage',
    defaultMessage: 'Sign into your Ulta.com account to get started!'
  },
  applicationMessage: {
    id: 'i18n.LoginForm.applicationMessage',
    defaultMessage: 'We\'ll fill out the application form with your saved info to save you some time!'
  },
  signandapply: {
    id: 'i18n.LoginForm.signininfo',
    defaultMessage: 'SIGN IN & APPLY NOW'
  },
  noUltaAccount: {
    id: 'i18n.InputField.noUltaAccount',
    defaultMessage: ' No Ulta.com account? No worries!'
  },
  createAppProcess: {
    id: 'i18n.InputField.createAppProcess',
    defaultMessage: 'You can create one during the application process'
  },
  cancel: {
    id: 'i18n.InputField.cancel',
    defaultMessage: 'CANCEL & RETURN'
  },
  applyNow: {
    id: 'i18n.InputField.applyNow',
    defaultMessage: 'APPLY NOW'
  }
} );
