import React from 'react';
import ReactDOM from 'react-dom';
import { mountWithIntl, initializeIntl } from 'ulta-fed-core/dist/js/utils/enzyme/intl-enzyme-test-helper';
import { Provider } from 'react-redux';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import ApplyAndBuyLoginForm from './ApplyAndBuyLoginForm';
import configureStore from '../../modules/ccr/ccr.store'
import CONFIG from '../../modules/ccr/ccr.config';
import messages from './ApplyAndBuyLoginForm.messages';

// TO test formatMessage function, need to load the Global component
let store = configureStore( {}, CONFIG );
initializeIntl();

describe( '<ApplyAndBuyLoginForm />', () => {
  const store = configureStore( {}, CONFIG );
  store.getState().global = {
    switchData:{
      switches:{
        enablePersistentLogin:false
      }
    }
  };
  const props = {
    sourcePage:'ccLogin',
    getBannerImage : jest.fn()
  }
  const component = mountWithIntl(
    <Provider store={ store }>
      <Router>
        <ApplyAndBuyLoginForm { ...props }/>
      </Router>
    </Provider>
  );

  it( 'renders without crashing', () => {
    expect( component.find( 'ApplyAndBuyLoginForm' ).length ).toBe( 1 );
  } );

  it( 'should render LoginForm component', () => {
    expect( component.find( '.ApplyAndBuyLoginForm__leftPanel .LoginForm' ).length ).toBe( 1 );
  } );

  it( 'should render ApplyAndBuyLoginForm__leftPanel', () => {
    expect( component.find( 'ApplyAndBuyLoginForm .ApplyAndBuyLoginForm__leftPanel' ).length ).toBe( 1 );
  } );

  it( 'should render submit Button with label APPLY NOW ', () => {
    const component = mountWithIntl(
      <Provider store={ store }>
        <Router>
          <ApplyAndBuyLoginForm { ...props }/>
        </Router>
      </Provider>
    );

    expect( component.find( '.ApplyAndBuyLoginForm__createAccount--submitButton Button20' ).length ).toBe( 1 );
    expect( component.find( '.ApplyAndBuyLoginForm__createAccount--submitButton Button20' ).props().type ).toBe( 'submit' );
    expect( component.find( '.ApplyAndBuyLoginForm__createAccount--submitButton Button20' ).props().size ).toBe( 'large' );
    expect( component.find( '.ApplyAndBuyLoginForm__createAccount--submitButton Button20' ).props().btnStyle ).toBe( 'secondary' );
    expect( component.find( '.ApplyAndBuyLoginForm__createAccount--submitButton Button20' ).props().block ).toBe( true );
    expect( component.find( '.ApplyAndBuyLoginForm__createAccount--submitButton Button20' ).text() ).toBe( formatMessage( messages.applyNow ) );
  } );

  it( 'should render no account text', () => {
    expect( component.find( 'ApplyAndBuyLoginForm .ApplyAndBuyLoginForm__createAccount--noAccountText' ).text() ).toBe( messages.noUltaAccount.defaultMessage );
  } );

  it( 'should render create account text', () => {
    expect( component.find( 'ApplyAndBuyLoginForm .ApplyAndBuyLoginForm__createAccount--createAccountText' ).text() ).toBe( messages.createAppProcess.defaultMessage );
  } );
} );
