/**
 * AuthorizedBuyers
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import InputField from 'ulta-fed-core/dist/js/views/InputField/InputField';
import './AuthorizedBuyers.css';
import isUndefined from 'lodash/isUndefined';
import SelectField from 'ulta-fed-core/dist/js/views/SelectField/SelectField';
import {
  requiredValidation
} from 'ulta-fed-core/dist/js/utils/form_validations/form_validations';
import { formatMessage } from 'ulta-fed-core/dist/js/views/IntlFormatter/IntlFormatter';
import messages from './AuthorizedBuyers.messages';



const propTypes = {
  value: PropTypes.string,
  inputValue: PropTypes.string,
  disabled: PropTypes.bool,
  clearable: PropTypes.bool,
  placeHolder: PropTypes.string,
  name: PropTypes.string
}

const defaultProps = {
  inputValue: '',
  value: null,
  disabled: false,
  placeHolder: 'Relationship to You',
  name: 'authBuyerRelationship'
}


/**
 * Class
 * @extends React.Component
 */
class AuthorizedBuyers extends Component{

  /**
   * Create a AuthorizedBuyers
   */
  constructor( props ){
    super( props );

    this.updateValue = this.updateValue.bind( this );

  }

  updateValue = ( value ) => {
    let iVal = isUndefined( value ) ? null : value;

    this.props.change( 'authBuyerRelationship', iVal );
  }

  /**
   * Renders the AuthorizedBuyers component
   */

  render(){

    const options = [
      { value: formatMessage( messages.Husband ), label: formatMessage( messages.Husband ) },
      { value: formatMessage( messages.Wife ), label: formatMessage( messages.Wife ) },
      { value: formatMessage( messages.Son ), label: formatMessage( messages.Son ) },
      { value: formatMessage( messages.Daughter ), label: formatMessage( messages.Daughter ) },
      { value: formatMessage( messages.Mother ), label: formatMessage( messages.Mother ) },
      { value: formatMessage( messages.Father ), label: formatMessage( messages.Father ) },
      { value: formatMessage( messages.Brother ), label: formatMessage( messages.Brother ) },
      { value: formatMessage( messages.Sister ), label: formatMessage( messages.Sister ) },
      { value: formatMessage( messages.Grandparent ), label: formatMessage( messages.Grandparent ) },
      { value: formatMessage( messages.Aunt ), label: formatMessage( messages.Aunt ) },
      { value: formatMessage( messages.Uncle ), label: formatMessage( messages.Uncle ) },
      { value: formatMessage( messages.Cousin ), label: formatMessage( messages.Cousin ) },
      { value: formatMessage( messages.Other ), label: formatMessage( messages.Other ) }
    ]
    return (

      <div className='AuthorizedBuyers'>
        <div className='AuthorizedBuyers__SignupField'>
          <InputField
            label={ formatMessage( messages.authBuyerFirstName ) }
            type='text'
            name='authBuyerFirstName'
          />
        </div>

        <div className='AuthorizedBuyers__SignupField'>
          <InputField
            label={ formatMessage( messages.authBuyerLastName ) }
            type='text'
            name='authBuyerLastName'
          />
        </div>


        <div className='AuthorizedBuyers__SignupField'>
          <InputField
            label={ formatMessage( messages.authBuyerdateOfBirth ) }
            placeholder='MM/DD/YYYY'
            formatter={ { pattern: '99/99/9999' } }
            type='tel'
            name='authBuyerDOB'
          />
        </div>

        <div className='AuthorizedBuyers__SignupField'>
          <SelectField className='AuthorizedBuyers__SignupField__SelectRelationship'
            name='authBuyerRelationship'
            options={ options }
            validate={ requiredValidation }
            defaultOption={ formatMessage( messages.selectRelation ) }
          />
        </div>

      </div>



    );
  }
}

AuthorizedBuyers.propTypes = propTypes;
AuthorizedBuyers.defaultProps = defaultProps;

export default AuthorizedBuyers;
