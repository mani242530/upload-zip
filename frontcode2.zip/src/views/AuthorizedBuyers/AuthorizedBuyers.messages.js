/*
 * AuthorizedBuyers Messages
 *
 * This contains all the text for the AuthorizedBuyers component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages( {
  header: {
    id: 'i18n.AuthorizedBuyers.header',
    defaultMessage: 'This is the AuthorizedBuyers component !'
  },
  authBuyerFirstName: {
    id: 'i18n.AuthorizedBuyers.authBuyerFirstName',
    defaultMessage: 'First Name'
  },
  authBuyerLastName: {
    id: 'i18n.AuthorizedBuyers.authBuyerLastName',
    defaultMessage: 'Last Name'
  },
  authBuyerdateOfBirth: {
    id: 'i18n.AuthorizedBuyers.authBuyerdateOfBirth',
    defaultMessage: 'Date of Birth'
  },
  Husband: {
    id: 'i18n.AuthorizedBuyers.Husband',
    defaultMessage: 'Husband'
  },
  Wife: {
    id: 'i18n.AuthorizedBuyers.Wife',
    defaultMessage: 'Wife'
  },
  Son: {
    id: 'i18n.AuthorizedBuyers.Son',
    defaultMessage: 'Son'
  },
  Daughter: {
    id: 'i18n.AuthorizedBuyers.Daughter',
    defaultMessage: 'Daughter'
  },
  Mother: {
    id: 'i18n.AuthorizedBuyers.Mother',
    defaultMessage: 'Mother'
  },
  Father: {
    id: 'i18n.AuthorizedBuyers.Father',
    defaultMessage: 'Father'
  },
  Brother: {
    id: 'i18n.AuthorizedBuyers.Brother',
    defaultMessage: 'Brother'
  },
  Sister: {
    id: 'i18n.AuthorizedBuyers.Sister',
    defaultMessage: 'Sister'
  },
  Grandparent: {
    id: 'i18n.AuthorizedBuyers.Grandparent',
    defaultMessage: 'Grandparent'
  },
  Aunt: {
    id: 'i18n.AuthorizedBuyers.Aunt',
    defaultMessage: 'Aunt'
  },
  Uncle: {
    id: 'i18n.AuthorizedBuyers.Uncle',
    defaultMessage: 'Uncle'
  },
  Cousin: {
    id: 'i18n.AuthorizedBuyers.Cousin',
    defaultMessage: 'Cousin'
  },
  selectRelation: {
    id: 'i18n.AuthorizedBuyers.selectRelation',
    defaultMessage: 'Relationship to You'
  },
  Other: {
    id: 'i18n.AuthorizedBuyers.Other',
    defaultMessage: 'Other'
  },

  relation : {
    id: 'i18n.AuthorizedBuyers.relation',
    defaultMessage: 'Date of Birth'
  }

} );
