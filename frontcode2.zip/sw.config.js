/* eslint-disable */
/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

workbox.core.skipWaiting();

workbox.core.clientsClaim();
precacheFiles=[];
// ['https://statica.ultainc.com/static/javascripts/combineHeader.js',
// 'https://statica.ultainc.com/static/css/combineCommonHeader.css',
// 'https://statica.ultainc.com/static/javascripts/combineCommonHeader.js',
// 'https://statica.ultainc.com/static/javascripts/combineHeader.js',
// 'https://statica.ultainc.com/static/javascripts/combineUVJSON.js',
// 'https://statica.ultainc.com/static/javascripts/ulta-perf-trackingtag.js',
// 'https://statica.ultainc.com/static/javascripts/combineCommonFooter.js',
// 'https://statica.ultainc.com/static/javascripts/combineFooter.js',
// 'https://statica.ultainc.com/static/fonts/fontawesome/fa-solid-900.woff2',
// 'https://statica.ultainc.com/static/fonts/fontawesome/fa-regular-400.woff2',
// 'https://statica.ultainc.com/static/fonts/fontawesome/fa-solid-900.woff',
// 'https://staticb.ultainc.com/static/javascripts/combineHeader.js',
// 'https://staticb.ultainc.com/static/css/combineCommonHeader.css',
// 'https://staticb.ultainc.com/static/javascripts/combineCommonHeader.js',
// 'https://staticb.ultainc.com/static/javascripts/combineHeader.js',
// 'https://staticb.ultainc.com/static/javascripts/combineUVJSON.js',
// 'https://staticb.ultainc.com/static/javascripts/ulta-perf-trackingtag.js',
// 'https://staticb.ultainc.com/static/javascripts/combineCommonFooter.js',
// 'https://staticb.ultainc.com/static/javascripts/combineFooter.js',
// 'https://staticb.ultainc.com/static/fonts/fontawesome/fa-solid-900.woff2',
// 'https://staticb.ultainc.com/static/fonts/fontawesome/fa-regular-400.woff2',
// 'https://staticb.ultainc.com/static/fonts/fontawesome/fa-solid-900.woff',
// 'https://ulta.widget.custhelp.com/euf/assets/css/syndicated_widgets/standard/ConditionalChatLink.css',
// 'https://ulta.widget.custhelp.com/euf/rightnow/RightNow.Client.js'
// ]
/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [].concat( self.__precacheManifest || [], precacheFiles );
workbox.precaching.precacheAndRoute( self.__precacheManifest, {} );

// Cache the Static Api response with a stale-while-revalidate strategy.
workbox.routing.registerRoute(
  new RegExp( /services\/(v2\/page\/nav|v1\/global\/config)/ ),
  new workbox.strategies.StaleWhileRevalidate( {
    cacheName: 'static-api-cache',
    plugins: [
      new workbox.expiration.Plugin( {
        maxAgeSeconds: 24 * 60 * 60
      } )
    ]
  } )
);

// Cache the Static css response with a stale-while-revalidate strategy.
// workbox.routing.registerRoute(
//   new RegExp( /https:\/\/ulta\.widget\.custhelp\.com\/euf\/assets\/css\/syndicated_widgets\/standard\/ConditionalChatLink\.css/ ),
//   new workbox.strategies.StaleWhileRevalidate( {
//     cacheName: 'static-css-cache',
//     plugins: [
//       new workbox.expiration.Plugin( {
//         maxAgeSeconds: 24 * 60 * 60
//       } )
//     ]
//   } )
// );

// Cache the Statica domain's response with a stale-while-revalidate strategy.
// workbox.routing.registerRoute(
//   new RegExp( /https:\/\/statica\.ultainc\.com.*(\/css\/|\/javascripts\/|\/images\/|\/fonts\/).*(\.css|\.js|\.png|\.(woff2|woff))/ ),
//   new workbox.strategies.StaleWhileRevalidate( {
//     cacheName: 'Statica-Domain-cache',
//     plugins: [
//       new workbox.expiration.Plugin( {
//         maxAgeSeconds: 24 * 60 * 60
//       } )
//     ]
//   } )
// );